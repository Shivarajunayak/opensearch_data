import boto3
import json
import os
import urllib3

GOOGLE_CHAT_WEBHOOK_URL = os.environ.get("GOOGLE_CHAT_WEBHOOK_URL")

# List quotas we can measure via API
LISTABLE_QUOTAS = {
    "vehicles": {
        "method": "list_vehicles",
        "result_key": "vehicleSummaries",
        "quota_match": "Number of vehicles"
    },
    "campaigns": {
        "method": "list_campaigns",
        "result_key": "campaignSummaries",
        "quota_match": "Number of campaigns"
    },
    "model_manifests": {
        "method": "list_model_manifests",
        "result_key": "summaries",
        "quota_match": "Number of model manifests"
    },
    "decoder_manifests": {
        "method": "list_decoder_manifests",
        "result_key": "summaries",
        "quota_match": "Number of decoder manifests"
    },
    "signal_catalog_nodes": {
        "method": "list_signal_catalog_nodes",
        "result_key": "nodes",
        "quota_match": "Number of nodes in a signal catalog"
    },
    "state_templates": {
        "method": "list_vehicle_state_templates",
        "result_key": "templates",
        "quota_match": "Number of state templates"
    }
}

# Static resource configuration limits (not listable via API)
STATIC_QUOTAS = {
    "state_templates_per_vehicle": {
        "description": "Number of state templates per vehicle",
        "limit": 20
    },
    "signals_per_state_template": {
        "description": "Number of signals per state template",
        "limit": 500
    },
    "metadata_dimensions_per_state_template": {
        "description": "Number of metadata dimensions per state template",
        "limit": 5
    },
    "partitions_per_campaign": {
        "description": "Number of partitions in a campaign",
        "limit": 5
    },
    "data_dimensions_per_state_template": {
        "description": "Number of data dimensions per state template",
        "limit": 5
    },
    "decoder_manifests_per_model_manifest": {
        "description": "Number of decoder manifests per model manifest",
        "limit": 100
    },
    "signals_per_campaign": {
        "description": "Number of signals in a campaign",
        "limit": 225
    }
}

def fetch_quota(service_code, partial_name):
    client = boto3.client("service-quotas")
    try:
        paginator = client.get_paginator("list_service_quotas")
        for page in paginator.paginate(ServiceCode=service_code):
            for quota in page["Quotas"]:
                if partial_name.lower() in quota["QuotaName"].lower():
                    return int(quota["Value"])
    except Exception as e:
        print(f"Error fetching quota for {partial_name}: {str(e)}")
    return None

def get_resource_count(client, method_name, result_key):
    try:
        paginator = client.get_paginator(method_name)
        count = 0
        for page in paginator.paginate():
            if result_key in page:
                count += len(page[result_key])
        return count
    except Exception as e:
        print(f"Error fetching usage for {method_name}: {str(e)}")
        return None

def send_to_google_chat(message):
    if not GOOGLE_CHAT_WEBHOOK_URL:
        print("GOOGLE_CHAT_WEBHOOK_URL not set. Skipping Google Chat notification.")
        return

    http = urllib3.PoolManager()
    headers = {"Content-Type": "application/json"}
    payload = {"text": message}
    try:
        response = http.request(
            "POST",
            GOOGLE_CHAT_WEBHOOK_URL,
            body=json.dumps(payload),
            headers=headers
        )
        print(f"Google Chat response: {response.status}")
    except Exception as e:
        print(f"Failed to send to Google Chat: {str(e)}")

def format_report_as_text(dynamic_report, static_quotas):
    lines = ["📊*AWS IoT FleetWise Quota Report:*"]

    lines.append("\n*Measured Resource Quotas:*")
    for key, data in dynamic_report.items():
        lines.append(f"- {key}: Used: `{data['used']}` / Max: `{data['max']}` (Remaining: `{data['remaining']}`)")

    lines.append("\n*Static Configuration Limits:*")
    for key, data in static_quotas.items():
        lines.append(f"- {data['description']}: Max: `{data['limit']}`")

    return "\n".join(lines)

def lambda_handler(event, context):
    fleetwise = boto3.client("iotfleetwise")
    dynamic_report = {}

    # Collect dynamic quotas and usage
    for resource, config in LISTABLE_QUOTAS.items():
        used = get_resource_count(fleetwise, config["method"], config["result_key"])
        max_quota = fetch_quota("iotfleetwise", config["quota_match"])

        if used is not None and max_quota is not None:
            dynamic_report[resource] = {
                "used": used,
                "max": max_quota,
                "remaining": max_quota - used
            }

    # Compose final message
    message = format_report_as_text(dynamic_report, STATIC_QUOTAS)
    send_to_google_chat(message)

    return {
        "statusCode": 200,
        "body": json.dumps({
            "dynamic_quota_report": dynamic_report,
            "static_quota_reference": STATIC_QUOTAS
        }, indent=2)
    }
