import boto3
import requests
import json
import os

REGION = "ap-south-1"
client = boto3.client("secretsmanager", region_name=REGION)

# Load secret from AWS Secrets Manager
def get_secret(secret_name):
    secret_value = client.get_secret_value(SecretId=secret_name)
    secret_string = secret_value.get("SecretString", "")
    try:
        return json.loads(secret_string)
    except json.JSONDecodeError:
        return secret_string

# Write certs to temporary files
def write_file(path, content):
    with open(path, "w") as f:
        f.write(content)

# Send message to Google Chat
def send_google_chat_alert(message):
    try:
        webhook_url = os.environ.get("GOOGLE_CHAT_WEBHOOK_URL")
        if not webhook_url:
            print("GOOGLE_CHAT_WEBHOOK_URL not set.")
            return

        headers = {"Content-Type": "application/json"}
        payload = {"text": message}
        response = requests.post(webhook_url, headers=headers, data=json.dumps(payload))

        if response.status_code != 200:
            print(f"Google Chat alert failed: {response.status_code}, {response.text}")
    except Exception as e:
        print(f"Error sending Google Chat alert: {str(e)}")

def lambda_handler(event, context):
    try:
        print("Incoming event:", json.dumps(event))

        # If API Gateway wrapped the body
        if "body" in event and isinstance(event["body"], str):
            try:
                event = json.loads(event["body"])
            except Exception as e:
                msg = f"Invalid JSON body: {str(e)}"
                send_google_chat_alert(msg)
                return {
                    "statusCode": 400,
                    "body": json.dumps({"message": "Invalid JSON body", "error": str(e)})
                }

        # Extract request credentials
        request_user = event.get("username")
        request_pass = event.get("password")

        if not request_user or not request_pass:
            return {
                "statusCode": 400,
                "body": json.dumps({"message": "Missing username or password"})
            }

        # Get environment variables for secret names
        auth_secret_name = os.environ.get("AUTH_SECRET_NAME")
        root_cert_secret_name = os.environ.get("ROOT_CERT_SECRET_NAME")
        client_cert_secret_name = os.environ.get("CLIENT_CERT_SECRET_NAME")
        private_key_secret_name = os.environ.get("PRIVATE_KEY_SECRET_NAME")

        if not all([auth_secret_name, root_cert_secret_name, client_cert_secret_name, private_key_secret_name]):
            error_message = "Missing secret environment variable(s)."
            send_google_chat_alert(error_message)
            return {
                "statusCode": 500,
                "body": json.dumps({"error": error_message})
            }

        # Load expected credentials
        auth_secret = get_secret(auth_secret_name)
        expected_user = auth_secret.get("username")
        expected_pass = auth_secret.get("password")

        if request_user != expected_user or request_pass != expected_pass:
            return {
                "statusCode": 401,
                "body": json.dumps({"message": "Unauthorized"})
            }

        # Load certs
        root_cert = get_secret(root_cert_secret_name)
        client_cert = get_secret(client_cert_secret_name)
        private_key = get_secret(private_key_secret_name)

        root_cert_data = root_cert.get("root.pem") if isinstance(root_cert, dict) else root_cert
        client_cert_data = client_cert.get("api_cert.pem") if isinstance(client_cert, dict) else client_cert
        private_key_data = private_key.get("private.pem") if isinstance(private_key, dict) else private_key

        # Write certs to /tmp
        write_file("/tmp/root.pem", root_cert_data)
        write_file("/tmp/api_cert.pem", client_cert_data)
        write_file("/tmp/private.pem", private_key_data)

        # mTLS request
        url = "https://ota.hmclconnect.com:9086/snap/omaui/sapi/v1/licenseServerInfo"
        response = requests.get(
            url,
            cert=("/tmp/api_cert.pem", "/tmp/private.pem"),
            verify="/tmp/root.pem",
            timeout=10
        )

        print("Response status:", response.status_code)
        print("Response text:", response.text)

        try:
            parsed_data = response.json()
        except ValueError:
            parsed_data = response.text

        # Build full response
        success_payload = {
            "message": "Request successful",
            "data": parsed_data
        }

        #Send pretty-formatted JSON to Google Chat
        formatted_json = json.dumps(success_payload, indent=2)
        send_google_chat_alert(f"✅ Production Esync Cert Counts:\n```json\n{formatted_json}\n```")

        return {
            "statusCode": response.status_code,
            "body": json.dumps(success_payload)
        }

    except Exception as e:
        error_message = f"Prod Esync Cert Counts error: {str(e)}"
        print(error_message)
        send_google_chat_alert(error_message)
        return {
            "statusCode": 500,
            "body": json.dumps({"error": str(e)})
        }
