import boto3
import requests
import os
from datetime import datetime, timedelta
import json

def lambda_handler(event, context):
    try:
        # Initialize AWS Cost Explorer client
        client = boto3.client('ce')

        # Get Google Chat webhook URL from environment variable
        chat_webhook_url = os.environ['GOOGLE_CHAT_WEBHOOK_URL']

        # Define time range: previous calendar month
        today = datetime.utcnow().date()
        first_day_this_month = today.replace(day=1)
        last_day_last_month = first_day_this_month - timedelta(days=1)
        first_day_last_month = last_day_last_month.replace(day=1)

        # Query AWS Cost Explorer for monthly unblended cost by service
        response = client.get_cost_and_usage(
            TimePeriod={
                'Start': first_day_last_month.strftime('%Y-%m-%d'),
                'End': first_day_this_month.strftime('%Y-%m-%d')
            },
            Granularity='MONTHLY',
            Metrics=['UnblendedCost'],
            GroupBy=[
                {'Type': 'DIMENSION', 'Key': 'SERVICE'}
            ]
        )

        # Process response
        results = response.get('ResultsByTime', [])
        if not results or not results[0].get('Groups'):
            print("No service-level cost data available.")
            return {
                "statusCode": 200,
                "body": "No service-level cost data available."
            }

        # Format date range
        month_str = first_day_last_month.strftime('%B %Y')

        # Create message title
        title = f"🚨 AWS Monthly Production Environment Cost by Service ({month_str}) 🚨"

        # Cost threshold for highlighting
        threshold = 100.0  # USD

        # Build cost breakdown
        lines = []
        groups = results[0]['Groups']
        sorted_groups = sorted(groups, key=lambda x: float(x['Metrics']['UnblendedCost']['Amount']), reverse=True)

        for group in sorted_groups:
            service = group['Keys'][0]
            amount = float(group['Metrics']['UnblendedCost']['Amount'])
            emoji = "" if amount > threshold else ""
            lines.append(f"{emoji} {service}: ${amount:.2f}")

        # Final message
        message = f"{title}\n\n" + "\n".join(lines)

        # Send message to Google Chat
        response = requests.post(
            chat_webhook_url,
            data=json.dumps({"text": message}),
            headers={"Content-Type": "application/json"}
        )

        if response.status_code != 200:
            print(f"Google Chat notification failed: {response.text}")
            return {
                "statusCode": response.status_code,
                "body": f"Google Chat webhook failed: {response.text}"
            }

        return {
            "statusCode": 200,
            "body": f"Sent monthly cost breakdown for {month_str}"
        }

    except Exception as e:
        print(f"Error occurred: {str(e)}")
        return {
            "statusCode": 500,
            "body": str(e)
        }
