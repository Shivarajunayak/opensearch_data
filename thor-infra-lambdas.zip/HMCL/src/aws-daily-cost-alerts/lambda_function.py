import boto3
import requests
import os
from datetime import datetime, timedelta
import json

def lambda_handler(event, context):
    try:
        # Initialize AWS Cost Explorer client
        client = boto3.client('ce')

        # Get Google Chat webhook URL from environment variable
        chat_webhook_url = os.environ['GOOGLE_CHAT_WEBHOOK_URL']

        # Define time range: yesterday
        end = datetime.utcnow().date()
        start = end - timedelta(days=1)

        # Query AWS Cost Explorer for daily unblended cost by service
        response = client.get_cost_and_usage(
            TimePeriod={
                'Start': start.strftime('%Y-%m-%d'),
                'End': end.strftime('%Y-%m-%d')
            },
            Granularity='DAILY',
            Metrics=['UnblendedCost'],
            GroupBy=[
                {'Type': 'DIMENSION', 'Key': 'SERVICE'}
            ]
        )

        # Process response
        results = response.get('ResultsByTime', [])
        if not results or not results[0].get('Groups'):
            print("No service-level cost data available.")
            return {
                "statusCode": 200,
                "body": "No service-level cost data available."
            }

        # Format date
        date_str = start.strftime('%Y-%m-%d')

        # Create message title
        title = f"🚨 AWS Daily PROD Environment Cost by Service ({date_str}) 🚨"

        # Cost threshold for highlighting
        threshold = 10.0  # USD

        # Build cost breakdown
        lines = []
        groups = results[0]['Groups']
        sorted_groups = sorted(groups, key=lambda x: float(x['Metrics']['UnblendedCost']['Amount']), reverse=True)

        for group in sorted_groups:
            service = group['Keys'][0]
            amount = float(group['Metrics']['UnblendedCost']['Amount'])
            emoji = "" if amount > threshold else ""
            lines.append(f"{emoji} {service}: ${amount:.2f}")

        # Final message
        message = f"{title}\n\n" + "\n".join(lines)

        # Send message to Google Chat
        response = requests.post(
            chat_webhook_url,
            data=json.dumps({"text": message}),
            headers={"Content-Type": "application/json"}
        )

        if response.status_code != 200:
            print(f"Google Chat notification failed: {response.text}")
            return {
                "statusCode": response.status_code,
                "body": f"Google Chat webhook failed: {response.text}"
            }

        return {
            "statusCode": 200,
            "body": f"Sent cost breakdown for {date_str}"
        }

    except Exception as e:
        print(f"Error occurred: {str(e)}")
        return {
            "statusCode": 500,
            "body": str(e)
        }

