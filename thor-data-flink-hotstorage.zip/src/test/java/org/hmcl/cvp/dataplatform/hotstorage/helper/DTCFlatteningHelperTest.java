package org.hmcl.cvp.dataplatform.hotstorage.helper;

import org.hmcl.cvp.dataplatform.commons.catalogue.SignalCatalogue;
import org.hmcl.cvp.dataplatform.contract.telemetry.SignalInfo;
import org.hmcl.cvp.dataplatform.contract.telemetry.Telemetry;
import org.hmcl.cvp.dataplatform.contract.telemetry.Tenant;
import org.hmcl.cvp.dataplatform.hotstorage.contract.DtcWrapper;
import org.hmcl.cvp.dataplatform.hotstorage.contract.FlattenedDtcTelemetry;
import org.hmcl.cvp.dataplatform.hotstorage.utils.HotStorageData;
import org.junit.Assert;
import org.junit.Test;

import java.time.Instant;
import java.util.List;

public class DTCFlatteningHelperTest {

    @Test
    public void testDTCFlatteningHelper_getDtcInfoSignalValue() {
        Instant instant = Instant.now();
        int countOfEachSignal = 1;
        int countOfDTCCodes = 2;
        SignalInfo signalInfo = SignalCatalogue.getDTCInfo();
        Telemetry telemetry = HotStorageData.getTelemetryWithDTCInfo(Tenant.EV, instant, signalInfo, countOfEachSignal, countOfDTCCodes);

        List<DtcWrapper> dtcWrappers = DTCFlatteningHelper.getDtcInfoSignalValue(HotStorageData.VIRTUAL_ID, telemetry, signalInfo);
        Assert.assertEquals(1, dtcWrappers.size());
    }

    @Test
    public void testDTCFlatteningHelper_getFlattenedDtcTelemetries() {
        Instant instant = Instant.now();
        int countOfEachSignal = 2;
        int countOfDTCCodes = 3;
        SignalInfo signalInfo = SignalCatalogue.getDTCInfo();
        Telemetry telemetry = HotStorageData.getTelemetryWithDTCInfo(Tenant.EV, instant, signalInfo, countOfEachSignal, countOfDTCCodes);

        List<DtcWrapper> dtcWrappers = DTCFlatteningHelper.getDtcInfoSignalValue(HotStorageData.VIRTUAL_ID, telemetry, signalInfo);
        List<FlattenedDtcTelemetry> flattenedDtcTelemetries = DTCFlatteningHelper.getFlattenedDtcTelemetries(HotStorageData.VIRTUAL_ID, dtcWrappers, true);

        // There should be countOfEachSignal * countOfDTCCodes (number of detectedDTCs) * countOfDTCCodes (number if dtcCodes signals
        int numActualSize = countOfEachSignal * countOfDTCCodes * countOfDTCCodes;
        Assert.assertEquals(numActualSize, flattenedDtcTelemetries.size());

    }

}
