package org.hmcl.cvp.dataplatform.hotstorage.job;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.salesforce.kafka.test.KafkaTestCluster;
import com.salesforce.kafka.test.KafkaTestUtils;
import org.apache.flink.runtime.testutils.MiniClusterResourceConfiguration;
import org.apache.flink.test.util.MiniClusterWithClientResource;
import org.apache.http.HttpEntity;
import org.apache.http.HttpHost;
import org.apache.http.util.EntityUtils;
import org.apache.kafka.clients.producer.KafkaProducer;
import org.apache.kafka.clients.producer.Producer;
import org.apache.kafka.clients.producer.ProducerConfig;
import org.apache.kafka.clients.producer.ProducerRecord;
import org.hmcl.cvp.dataplatform.commons.constants.FlinkRuntime;
import org.hmcl.cvp.dataplatform.commons.testdata.CampaignDataGenerator;
import org.hmcl.cvp.dataplatform.contract.telemetry.Telemetry;
import org.hmcl.cvp.dataplatform.contract.telemetry.Tenant;
import org.hmcl.cvp.dataplatform.hotstorage.utils.HotStorageData;
import org.junit.*;
import org.opensearch.client.Request;
import org.opensearch.client.Response;
import org.opensearch.client.RestClient;
import org.opensearch.testcontainers.OpensearchContainer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testcontainers.utility.DockerImageName;

import java.io.IOException;
import java.time.Duration;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

public class OpenSearchHotStorageFlinkJobTest {
    private static final Logger LOGGER = LoggerFactory.getLogger(OpenSearchHotStorageFlinkJobTest.class);
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static final DockerImageName OPEN_SEARCH_IMAGE = DockerImageName.parse("opensearchproject/opensearch:2.13.0");

    private static final OpensearchContainer<?> CONTAINER = new OpensearchContainer<>(OPEN_SEARCH_IMAGE);

    private static final String TELEMETRY_INPUT_TOPIC = "TELEMETRY";
    private static final String CHARGING_INPUT_TOPIC = "CHARGING";

    private static KafkaTestUtils utils;
    private static KafkaTestCluster cluster;

    @ClassRule
    public static MiniClusterWithClientResource flinkCluster =
            new MiniClusterWithClientResource(
                    new MiniClusterResourceConfiguration.Builder()
                            .setNumberSlotsPerTaskManager(2)
                            .setNumberTaskManagers(1)
                            .build());

    @BeforeClass
    public static void startKafkaCluster() throws Throwable {
        // Setup InMemory  Kafka Cluster
        cluster = new KafkaTestCluster(1);
        cluster.start();
        utils = new KafkaTestUtils(cluster);

        utils.createTopic(TELEMETRY_INPUT_TOPIC, 1, (short) 1);
        utils.createTopic(CHARGING_INPUT_TOPIC, 1, (short) 1);
    }

    @BeforeClass
    public static void startOpenSearch() {
        // https://stackoverflow.com/questions/61108655/test-container-test-cases-are-failing-due-to-could-not-find-a-valid-docker-envi
        CONTAINER.start();
    }

    @AfterClass
    public static void stopKafkaCluster() throws Exception {
        cluster.close();
    }

    @AfterClass
    public static void closeOpenSearch() {
        LOGGER.info("Closing OpenSearch container");
        CONTAINER.stop();
    }

    private static void produceData(List<String> telemetryList, String topic) {
        Producer<String, String> producer = getProducer();
        LOGGER.info("Producing events");
        telemetryList.forEach(v -> {
            ProducerRecord<String, String> data = new ProducerRecord<>(topic, v);
            producer.send(data);
        });

        producer.flush();
        producer.close();
    }

    private static Producer<String, String> getProducer() {
        Properties props = new Properties();

        props.put(ProducerConfig.BOOTSTRAP_SERVERS_CONFIG, cluster.getKafkaConnectString());
        props.put("security.protocol", "PLAINTEXT");
        props.put(ProducerConfig.ACKS_CONFIG, "all");
        props.put(ProducerConfig.RETRIES_CONFIG, 2);
        props.put(ProducerConfig.LINGER_MS_CONFIG, 2);
        props.put(ProducerConfig.KEY_SERIALIZER_CLASS_CONFIG,"org.apache.kafka.common.serialization.StringSerializer");
        props.put(ProducerConfig.VALUE_SERIALIZER_CLASS_CONFIG,"org.apache.kafka.common.serialization.StringSerializer");

        return new KafkaProducer<>(props);
    }

    private static String[] getSystemArgs() {
        return new String[]{
                "--is.run.test.case", "TRUE",
                "--aws.region", "ap-south-1",

                // KAFKA Telemetry PROPERTY
                "--kafka.campaign.bootstrap.brokers", cluster.getKafkaConnectString(),
                "--kafka.telemetry.campaign.input.topic", TELEMETRY_INPUT_TOPIC,
                "--kafka.charging.campaign.input.topic", CHARGING_INPUT_TOPIC,
                "--kafka.campaign.group.id", "HotStorageGroup",
                "--kafka.campaign.role.arn", "XXXXX",
                "--kafka.campaign.session.name", "HotStorageSession",

                // OpenSearch PROPERTY - ONLY USED FOR TEST CASES
                "--opensearch.hostAddress", CONTAINER.getHttpHostAddress(),
                "--opensearch.username", CONTAINER.getUsername(),
                "--opensearch.password", CONTAINER.getPassword(),

                // Opensearch indecies
                "--master.telemetry.index.ev", HotStorageData.EV_MASTER_TELEMETRY_INDEX,
                "--master.telemetry.index.ice", HotStorageData.ICE_MASTER_TELEMETRY_INDEX,
                "--master.telemetry.index.harley", HotStorageData.HARLEY_MASTER_TELEMETRY_INDEX,
                "--master.flattened.telemetry.index.ev", HotStorageData.EV_FLATTENED_TELEMETRY_INDEX,
                "--master.flattened.telemetry.index.ice", HotStorageData.ICE_FLATTENED_TELEMETRY_INDEX,
                "--master.flattened.telemetry.index.harley", HotStorageData.HARLEY_FLATTENED_TELEMETRY_INDEX,
                "--master.dtc.telemetry.index.ev", HotStorageData.EV_DTC_TELEMETRY_INDEX,
                "--master.dtc.telemetry.index.ice", HotStorageData.ICE_DTC_TELEMETRY_INDEX,
                "--master.dtc.telemetry.index.harley", HotStorageData.HARLEY_DTC_TELEMETRY_INDEX,
                "--charging.index.ev", HotStorageData.EV_CHARGING_INDEX
        };
    }

    private int getNumberOfRecordsInOpenSearch(String index) {

        String endpoint = String.format("/%s/_search", index);
        LOGGER.info("OpenSearch endpoint: {}", endpoint);

        RestClient client = RestClient
                .builder(HttpHost.create(CONTAINER.getHttpHostAddress()))
                .build();

        try (client) {
            Request request = new Request("GET", endpoint);
            Response response =  client.performRequest(request);
            HttpEntity entity = response.getEntity();

            String responseString = EntityUtils.toString(entity);
            LOGGER.info("Repeatable: {}, Content Type: {}, Content: {}", entity.isRepeatable(), entity.getContentType(), responseString);

            JsonElement je = GSON.fromJson(responseString, JsonElement.class);
            JsonObject jo = je.getAsJsonObject();

            JsonObject totalHits = jo.getAsJsonObject("hits").getAsJsonObject("total");
            int numHits = totalHits.get("value").getAsInt();
            LOGGER.info("Number of records: {}", numHits);
            return numHits;

        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    @Test
    public void testOpenSearchSink() {

        int numOfEvents = 2;

        List<Telemetry> evTelemetries = CampaignDataGenerator.getTelemetries(Tenant.EV, numOfEvents);
        List<Telemetry> iceTelemetries = CampaignDataGenerator.getTelemetries(Tenant.ICE, numOfEvents);
        List<Telemetry> harleyTelemetries = CampaignDataGenerator.getTelemetries(Tenant.HARLEY, numOfEvents);

        List<Telemetry> telemetries = new ArrayList<>(evTelemetries);
        telemetries.addAll(iceTelemetries);
        telemetries.addAll(harleyTelemetries);

        List<String> data = HotStorageData.getJsonData(telemetries);
        produceData(data, TELEMETRY_INPUT_TOPIC);

        Telemetry charging = HotStorageData.getChargerCampaignData("test-vehicle", 1);
        ArrayList<Telemetry> chargingEvents = new ArrayList<>();
        chargingEvents.add(charging);
        List<String> chargingData = HotStorageData.getJsonData(chargingEvents);
        produceData(chargingData, CHARGING_INPUT_TOPIC);

        try {

            Thread startFlinkJob = new Thread(() -> {
                try {
                    OpenSearchHotStorageFlink.main(getSystemArgs());
                } catch (Exception e) {
                    throw new RuntimeException(e);
                }
            });
            startFlinkJob.start();
            // Interrupt the thread after 10 seconds
            startFlinkJob.join(Duration.ofSeconds(60).toMillis());

            int numOfRawEvHits = getNumberOfRecordsInOpenSearch(HotStorageData.EV_MASTER_TELEMETRY_INDEX);
            Assert.assertEquals(numOfEvents, numOfRawEvHits);

            int numOfRawIceHits = getNumberOfRecordsInOpenSearch(HotStorageData.ICE_MASTER_TELEMETRY_INDEX);
            Assert.assertEquals(numOfEvents, numOfRawIceHits);

            int numOfRawHarleyHits = getNumberOfRecordsInOpenSearch(HotStorageData.HARLEY_MASTER_TELEMETRY_INDEX);
            Assert.assertEquals(numOfEvents, numOfRawHarleyHits);

            int numOfChargingHits = getNumberOfRecordsInOpenSearch(HotStorageData.EV_CHARGING_INDEX);
            Assert.assertEquals(1, numOfChargingHits);

        } catch (Exception e) {
            LOGGER.error("Exception occurred while launching Flink opensearch consumer");
            throw new RuntimeException(e);
        }
    }
}
