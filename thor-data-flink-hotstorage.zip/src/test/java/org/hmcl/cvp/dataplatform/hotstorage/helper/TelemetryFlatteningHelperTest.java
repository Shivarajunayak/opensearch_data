package org.hmcl.cvp.dataplatform.hotstorage.helper;

import org.hmcl.cvp.dataplatform.commons.catalogue.SignalCatalogue;
import org.hmcl.cvp.dataplatform.commons.testdata.SignalGenerator;
import org.hmcl.cvp.dataplatform.contract.telemetry.SignalData;
import org.hmcl.cvp.dataplatform.contract.telemetry.SignalInfo;
import org.hmcl.cvp.dataplatform.contract.telemetry.Telemetry;
import org.hmcl.cvp.dataplatform.contract.telemetry.Tenant;
import org.hmcl.cvp.dataplatform.hotstorage.contract.NormalizedSignalData;
import org.hmcl.cvp.dataplatform.hotstorage.contract.NormalizedTelemetry;
import org.hmcl.cvp.dataplatform.hotstorage.utils.HotStorageData;
import org.junit.Assert;
import org.junit.Test;

import java.time.Instant;
import java.util.*;

public class TelemetryFlatteningHelperTest {

    @Test
    public void testTelemetryFlatteningHelper_normalizeTimestamps() {

        Instant instant = Instant.ofEpochMilli(1234567890123L);
        Set<SignalData> signalDataSet = SignalGenerator.getRandomSignals(SignalCatalogue.getTcuIgnitionInfo(), 1, instant);

        SignalInfo signalInfo =  SignalCatalogue.getDTCInfo();
        Map<String, Set<SignalData>> telemetrySignals = new HashMap<>();
        telemetrySignals.put(signalInfo.getKey(), signalDataSet);

        List<NormalizedSignalData> normalizedSignalDataList = TelemetryFlatteningHelper.normalizeTimestamps(telemetrySignals, signalInfo,2L);
        Assert.assertEquals(1, normalizedSignalDataList.size());

        NormalizedSignalData normalizedSignalData = normalizedSignalDataList.get(0);
        Assert.assertEquals(1234567890100L, normalizedSignalData.getNormalizedTime());
    }

    @Test
    public void testTelemetryFlatteningHelper_normalizeTimestamps_milliToSecond() {

        Instant instant = Instant.ofEpochMilli(1234567890123L);
        Set<SignalData> signalDataSet = SignalGenerator.getRandomSignals(SignalCatalogue.getTcuIgnitionInfo(), 1, instant);

        SignalInfo signalInfo =  SignalCatalogue.getDTCInfo();
        Map<String, Set<SignalData>> telemetrySignals = new HashMap<>();
        telemetrySignals.put(signalInfo.getKey(), signalDataSet);

        List<NormalizedSignalData> normalizedSignalDataList = TelemetryFlatteningHelper.normalizeTimestamps(telemetrySignals, signalInfo, 3L);
        Assert.assertEquals(1, normalizedSignalDataList.size());

        NormalizedSignalData normalizedSignalData = normalizedSignalDataList.get(0);
        Assert.assertEquals(1234567890000L, normalizedSignalData.getNormalizedTime());
    }

    @Test
    public void testTelemetryFlatteningHelper_getNormalizedTelemetries() {
        int countOfEachSignals = 2;
        long milliSecondsDiff = 5000L;
        Instant instant = Instant.now();
        Telemetry telemetry = HotStorageData.getTelemetryForFlattening(Tenant.EV, instant, countOfEachSignals, milliSecondsDiff);
        Map<String, Set<SignalData>> incomingSignals = telemetry.getSignals();

        Map<Long, NormalizedTelemetry> normalizedTelemetryMap = TelemetryFlatteningHelper.getNormalizedTelemetries(telemetry, 3);
        List<NormalizedTelemetry> normalizedTelemetries = new ArrayList<>(normalizedTelemetryMap.values());

        // There should be two documents corresponding to the count of signals
        Assert.assertEquals(countOfEachSignals, normalizedTelemetries.size());

        NormalizedTelemetry normalizedTelemetry1 = normalizedTelemetries.get(0);
        Map<String, NormalizedSignalData> normalizedSignalDataMap1 = normalizedTelemetry1.getNormalizedSignals();

        // The number of normalised signals should be equal to the number of signals
        Assert.assertEquals(incomingSignals.size(), normalizedSignalDataMap1.size());

        NormalizedTelemetry normalizedTelemetry2 = normalizedTelemetries.get(1);
        Map<String, NormalizedSignalData> normalizedSignalDataMap2 = normalizedTelemetry2.getNormalizedSignals();

        // The number of normalised signals should be equal to the number of signals
        Assert.assertEquals(incomingSignals.size(), normalizedSignalDataMap2.size());
    }

    @Test
    public void testTelemetryFlatteningHelper_getNormalizedTelemetries_sameNormalizedTime() {
        int countOfEachSignals = 2;
        long milliSecondsDiff = 100L;
        Instant instant = Instant.now();
        Telemetry telemetry = HotStorageData.getTelemetryForFlattening(Tenant.EV, instant, countOfEachSignals, milliSecondsDiff);
        Map<String, Set<SignalData>> incomingSignals = telemetry.getSignals();

        Map<Long, NormalizedTelemetry> normalizedTelemetryMap = TelemetryFlatteningHelper.getNormalizedTelemetries(telemetry, 3);
        List<NormalizedTelemetry> normalizedTelemetries = new ArrayList<>(normalizedTelemetryMap.values());

        // There should be just be one document since normalized time will be same for both the signal values
        Assert.assertEquals(1, normalizedTelemetries.size());

        NormalizedTelemetry normalizedTelemetry = normalizedTelemetries.get(0);
        Map<String, NormalizedSignalData> normalizedSignalDataMap = normalizedTelemetry.getNormalizedSignals();

        // The number of normalised signals should be equal to the number of signals
        Assert.assertEquals(incomingSignals.size(), normalizedSignalDataMap.size());
    }

}
