package org.hmcl.cvp.dataplatform.hotstorage.utils;

import com.google.gson.Gson;
import net.datafaker.Faker;
import org.apache.flink.streaming.runtime.streamrecord.StreamRecord;
import org.hmcl.cvp.dataplatform.commons.catalogue.SignalCatalogue;
import org.hmcl.cvp.dataplatform.commons.testdata.CampaignDataGenerator;
import org.hmcl.cvp.dataplatform.commons.testdata.SignalGenerator;
import org.hmcl.cvp.dataplatform.commons.testdata.faker.BikeFaker;
import org.hmcl.cvp.dataplatform.commons.utils.GsonUtils;
import org.hmcl.cvp.dataplatform.contract.telemetry.SignalData;
import org.hmcl.cvp.dataplatform.contract.telemetry.SignalInfo;
import org.hmcl.cvp.dataplatform.contract.telemetry.Telemetry;
import org.hmcl.cvp.dataplatform.contract.telemetry.Tenant;
import org.hmcl.cvp.dataplatform.hotstorage.contract.*;

import java.time.Instant;
import java.util.*;
import java.util.stream.Collectors;

public class HotStorageData {

    public static final String EV_MASTER_TELEMETRY_INDEX = "hmcl-cv-master-telemetry-ev-vida-stream";
    public static final String ICE_MASTER_TELEMETRY_INDEX = "hmcl-cv-master-telemetry-ice-hero-stream";
    public static final String HARLEY_MASTER_TELEMETRY_INDEX = "hmcl-cv-master-telemetry-ice-harley-stream";
    public static final String EV_FLATTENED_TELEMETRY_INDEX = "hmcl-cv-flattened-telemetry-ev-vida-stream";
    public static final String ICE_FLATTENED_TELEMETRY_INDEX = "hmcl-cv-flattened-telemetry-ice-hero-stream";
    public static final String HARLEY_FLATTENED_TELEMETRY_INDEX = "hmcl-cv-flattened-telemetry-ice-harley-stream";
    public static final String EV_DTC_TELEMETRY_INDEX = "hmcl-cv-dtc-telemetry-ev-vida-stream";
    public static final String ICE_DTC_TELEMETRY_INDEX = "hmcl-cv-dtc-telemetry-ice-hero-stream";
    public static final String HARLEY_DTC_TELEMETRY_INDEX = "hmcl-cv-dtc-telemetry-ice-harley-stream";
    public static final String EV_CHARGING_INDEX = "hmcl-ev-charging-screen-ev-vida-stream";

    public static final String VIRTUAL_ID = "test-vehicle";

    private static final Gson GSON = GsonUtils.getGson();
    private static final Faker FAKER = new Faker();
    private static final BikeFaker BIKE_FAKER = new BikeFaker();

    private HotStorageData() {
    }

    public static List<String> getJsonData(List<Telemetry> data) {
        return data.stream().map(GSON::toJson).collect(Collectors.toList());
    }

    public static List<StreamRecord<Telemetry>> getTelemetryStreamRecords(List<Telemetry> data) {
        return data.stream().map(StreamRecord::new).collect(Collectors.toList());
    }

    public static <T> List<T> getOutput(Collection<StreamRecord<T>> streamOutput) {
        return streamOutput.stream().map(StreamRecord::getValue).collect(Collectors.toList());
    }

    public static Telemetry getChargerCampaignData(String virtualId, int countOfEachSignals) {
        Instant instant = Instant.now();
        Telemetry telemetry = CampaignDataGenerator.getTelemetry(virtualId, Tenant.EV, instant, countOfEachSignals);

        addSoc(telemetry, instant);
        addChargerState(telemetry, instant);
        addBatteryTemperature(telemetry, instant);
        addAverageEnergyConsumption(telemetry, instant);
        addEstimatedChargingTime(telemetry, instant);
        addSoh(telemetry, instant);
        addChargerIdentity(telemetry, instant);
        addBatteryChargingStatus(telemetry, instant);

        return telemetry;
    }

    private static void addAverageEnergyConsumption(Telemetry telemetry, Instant instant) {
        SignalInfo signalInfo = SignalCatalogue.getAvgEnergyConsumptionInfo();
        Set<SignalData> signals = SignalGenerator.getRandomSignals(signalInfo, 1, instant);
        addSignals(telemetry, signalInfo, signals);
    }

    private static void addBatteryChargingStatus(Telemetry telemetry, Instant instant) {
        SignalInfo signalInfo = SignalCatalogue.getBatteryChargingStatusInfo();
        Set<SignalData> signals = SignalGenerator.getTrueBooleanSignals(instant);
        addSignals(telemetry, signalInfo, signals);
    }

    private static void addSoc(Telemetry telemetry, Instant instant) {
        SignalInfo signalInfo = SignalCatalogue.getSocUserPercentageInfo();
        Set<SignalData> signals = SignalGenerator.getRandomSignals(signalInfo, 1, instant);
        addSignals(telemetry, signalInfo, signals);
    }

    private static void addSoh(Telemetry telemetry, Instant instant) {
        SignalInfo signalInfo = SignalCatalogue.getSohInfo();
        Set<SignalData> signals = SignalGenerator.getRandomSignals(signalInfo, 1, instant);
        addSignals(telemetry, signalInfo, signals);
    }

    private static void addBatteryTemperature(Telemetry telemetry, Instant instant) {
        SignalInfo signalInfo = SignalCatalogue.getBatteryPackTemperatureInfo();
        Set<SignalData> signals = SignalGenerator.getRandomSignals(signalInfo, 1, instant);
        addSignals(telemetry, signalInfo, signals);
    }

    private static void addEstimatedChargingTime(Telemetry telemetry, Instant instant) {
        SignalInfo signalInfo = SignalCatalogue.getEstimatedChargingTimeInfo();
        Set<SignalData> signals = SignalGenerator.getRandomSignals(signalInfo, 1, instant);
        addSignals(telemetry, signalInfo, signals);
    }

    private static void addChargerState(Telemetry telemetry, Instant instant) {
        SignalInfo signalInfo = SignalCatalogue.getChargerStateInfo();
        Set<SignalData> signals = SignalGenerator.getRandomSignals(signalInfo, 15, 1, instant);
        addSignals(telemetry, signalInfo, signals);
    }

    private static void addChargerIdentity(Telemetry telemetry, Instant instant) {
        SignalInfo signalInfo = SignalCatalogue.getChargerIdentityInfo();
        Set<SignalData> signals = SignalGenerator.getRandomSignals(signalInfo, 3, 1, instant);
        addSignals(telemetry, signalInfo, signals);
    }

    public static void addChargingSessionStart(Telemetry telemetry, Instant instant) {
        SignalInfo signalInfo = SignalCatalogue.getChargingSessionStartInfo();
        ChargingSession session = ChargingSession.builder()
                .startTimestamp(instant.toEpochMilli())
                .chargingSessionId(UUID.randomUUID().toString())
                .build();
        SignalData signalData = new SignalData();
        signalData.setDataType("VARCHAR");
        signalData.setTime(instant.toEpochMilli());
        signalData.setValue(GSON.toJson(session));

        HashSet<SignalData> signals = new HashSet<>();
        signals.add(signalData);

        addSignals(telemetry, signalInfo, signals);
    }

    public static void addChargingSessionEnd(Telemetry telemetry, Instant instant) {
        SignalInfo signalInfo = SignalCatalogue.getChargingSessionEndInfo();
        ChargingSession session = ChargingSession.builder()
                .startTimestamp(instant.toEpochMilli())
                .chargingSessionId(UUID.randomUUID().toString())
                .endTimestamp(instant.plusSeconds(60 * 60).toEpochMilli())
                .build();

        SignalData signalData = new SignalData();
        signalData.setDataType("VARCHAR");
        signalData.setTime(instant.toEpochMilli());
        signalData.setValue(GSON.toJson(session));

        HashSet<SignalData> signals = new HashSet<>();
        signals.add(signalData);

        addSignals(telemetry, signalInfo, signals);
    }

    public static Set<SignalData> getDtcInfoSignals(Instant instant, int countOfSignals, int numOfCodes) {

        Set<SignalData> signalDataSet = new HashSet<>();
        for (int i = 0; i < countOfSignals; i++) {
            SignalData signalData = new SignalData();
            signalData.setDataType("VARCHAR");
            signalData.setTime(instant.toEpochMilli());

            List<DetectedDTC> detectedDTCS = new ArrayList<>();
            for (int k = 0; k < numOfCodes; k++) {
                DetectedDTC detectedDTC = getDetectedDTC(numOfCodes);
                detectedDTCS.add(detectedDTC);
            }

            DtcInfo dtcInfo = DtcInfo.builder()
                    .detectedDTCs(detectedDTCS)
                    .build();

            signalData.setValue(GSON.toJson(dtcInfo));

            signalDataSet.add(signalData);
        }

        return signalDataSet;
    }

    public static DetectedDTC getDetectedDTC(int numOfCodes) {
        List<DTCCode> dtcCodes = new ArrayList<>(numOfCodes);

        for (int i = 0; i < numOfCodes; i++) {
            DTCCode dtcCode = getDTCCode();
            dtcCodes.add(dtcCode);
        }

        DTCAndSnapshot dtcAndSnapshot = DTCAndSnapshot.builder()
                .dtcStatusAvailabilityMask("FF")
                .dtcCodes(dtcCodes)
                .build();

        return DetectedDTC.builder()
                .ecuId(FAKER.cosmere().allomancers())
                .dtcAndSnapshot(dtcAndSnapshot)
                .build();
    }

    public static DTCCode getDTCCode() {
        return DTCCode.builder()
                .dtc(FAKER.color().hex(false))
                .dtcExtendedData(FAKER.funnyName().name())
                .dtcSnapshotRecord(FAKER.random().hex())
                .build();
    }

    public static Telemetry getTelemetryWithDTCInfo(Tenant tenant, Instant instant, SignalInfo signalInfo, int countOfEachSignals, int countOfDTCCodes, boolean stripOtherSignals) {
        Telemetry telemetry = CampaignDataGenerator.getTelemetry(VIRTUAL_ID, tenant, instant, countOfEachSignals);
        Map<String, Set<SignalData>> signals;
        if(stripOtherSignals) {
            signals = new HashMap<>();
        } else {
            signals = telemetry.getSignals();
        }

        Set<SignalData> signalData = getDtcInfoSignals(instant, countOfEachSignals, countOfDTCCodes);
        signals.put(signalInfo.getKey(), signalData);

        telemetry.setSignals(signals);
        return telemetry;
    }

    public static Telemetry getTelemetryWithDTCInfo(Tenant tenant, Instant instant, SignalInfo signalInfo, int countOfEachSignals, int countOfDTCCodes) {
        return getTelemetryWithDTCInfo(tenant, instant, signalInfo, countOfEachSignals, countOfDTCCodes, false);
    }

    public static Telemetry getTelemetryForFlattening(Tenant tenant, Instant instant, int countOfEachSignals, long milliSecondDiff) {
        Telemetry telemetry = CampaignDataGenerator.getTelemetry(VIRTUAL_ID, tenant, instant, countOfEachSignals);
        telemetry.setSignals(new HashMap<>());

        Map<String, Set<SignalData>> signals = telemetry.getSignals();

        addSignals(signals, SignalCatalogue.getAltitudeInfo(), instant, countOfEachSignals, milliSecondDiff);
        addSignals(signals, SignalCatalogue.getBatteryPackTemperatureInfo(), instant, countOfEachSignals, milliSecondDiff);
        addSignals(signals, SignalCatalogue.getBMS1BatteryPackTempInfo(), instant, countOfEachSignals, milliSecondDiff);
        addSignals(signals, SignalCatalogue.getBMS2BatteryPackTempInfo(), instant, countOfEachSignals, milliSecondDiff);
        addSignals(signals, SignalCatalogue.getBMSBDUConnectionRequestInfo(), instant, countOfEachSignals, milliSecondDiff);
        addSignals(signals, SignalCatalogue.getVehicleSpeedDisplayInfo(), instant, countOfEachSignals, milliSecondDiff);
        addSignals(signals, SignalCatalogue.getCogInfo(), instant, countOfEachSignals, milliSecondDiff);
        addSignals(signals, SignalCatalogue.getDrivingModeInfo(), instant, countOfEachSignals, milliSecondDiff);
        addSignals(signals, SignalCatalogue.getEngineTemperatureInfo(), instant, countOfEachSignals, milliSecondDiff);
        addSignals(signals, SignalCatalogue.getFuelLevelInfo(), instant, countOfEachSignals, milliSecondDiff);
        addSignals(signals, SignalCatalogue.getFuelLevelIndicationInfo(), instant, countOfEachSignals, milliSecondDiff);
        addSignals(signals, SignalCatalogue.getGpsFixInfo(), instant, countOfEachSignals, milliSecondDiff);
        addSignals(signals, SignalCatalogue.getGpsValidInfo(), instant, countOfEachSignals, milliSecondDiff);
        addSignals(signals, SignalCatalogue.getHDopInfo(), instant, countOfEachSignals, milliSecondDiff);
        addSignals(signals, SignalCatalogue.getInternalBatteryChargeVoltageInfo(), instant, countOfEachSignals, milliSecondDiff);
        addSignals(signals, SignalCatalogue.getLatitudeInfo(), instant, countOfEachSignals, milliSecondDiff);
        addSignals(signals, SignalCatalogue.getLongitudeInfo(), instant, countOfEachSignals, milliSecondDiff);
        addSignals(signals, SignalCatalogue.getTcuMainVoltageInfo(), instant, countOfEachSignals, milliSecondDiff);
        addSignals(signals, SignalCatalogue.getOdometerHRInfo(), instant, countOfEachSignals, milliSecondDiff);
        addSignals(signals, SignalCatalogue.getPackVoltageInfo(), instant, countOfEachSignals, milliSecondDiff);
        addSignals(signals, SignalCatalogue.getPDopInfo(), instant, countOfEachSignals, milliSecondDiff);
        addSignals(signals, SignalCatalogue.getRemainingRangeInfo(), instant, countOfEachSignals, milliSecondDiff);
        addSignals(signals, SignalCatalogue.getSocUserBMS1Info(), instant, countOfEachSignals, milliSecondDiff);
        addSignals(signals, SignalCatalogue.getSocUserBMS2Info(), instant, countOfEachSignals, milliSecondDiff);
        addSignals(signals, SignalCatalogue.getSocUserPercentageInfo(), instant, countOfEachSignals, milliSecondDiff);
        addSignals(signals, SignalCatalogue.getSohInfo(), instant, countOfEachSignals, milliSecondDiff);
        addSignals(signals, SignalCatalogue.getBMS1SohPercentage(), instant, countOfEachSignals, milliSecondDiff);
        addSignals(signals, SignalCatalogue.getBMS2SohPercentage(), instant, countOfEachSignals, milliSecondDiff);
        addSignals(signals, SignalCatalogue.getTotalUsableEnergyInfo(), instant, countOfEachSignals, milliSecondDiff);
        addSignals(signals, SignalCatalogue.getTotalUsableEnergyBMS1Info(), instant, countOfEachSignals, milliSecondDiff);
        addSignals(signals, SignalCatalogue.getTotalUsableEnergyBMS2Info(), instant, countOfEachSignals, milliSecondDiff);
        addSignals(signals, SignalCatalogue.getVDopInfo(), instant, countOfEachSignals, milliSecondDiff);

        telemetry.setSignals(signals);

        return telemetry;

    }

    private static void addSignals(Map<String, Set<SignalData>> signals, SignalInfo signalInfo, Instant instant, int countOfEachSignals, long milliSecondDiff) {
        Set<SignalData> signalDataSet = new HashSet<>();
        for (int i = 0; i < countOfEachSignals; i++) {
            Instant newInstant = instant.plusMillis(milliSecondDiff * i);
            SignalData signalData = getRandomSignals(signalInfo, newInstant);
            signalDataSet.add(signalData);
        }

        signals.put(signalInfo.getKey(), signalDataSet);
    }

    private static void addSignals(Telemetry telemetry, SignalInfo signalInfo, Set<SignalData> signals) {
        removeSignals(telemetry, signalInfo);

        Map<String, Set<SignalData>> signalMap = telemetry.getSignals();
        signalMap.put(signalInfo.getKey(), signals);

        telemetry.setSignals(signalMap);
    }

    private static void removeSignals(Telemetry telemetry, SignalInfo signalInfo) {
        Map<String, Set<SignalData>> signalMap = telemetry.getSignals();
        signalMap.remove(signalInfo.getKey());
        telemetry.setSignals(signalMap);
    }

    private static SignalData getRandomSignals(SignalInfo signalInfo, Instant instant) {
        SignalData signalData = new SignalData();
        signalData.setTime(instant.toEpochMilli());

        if (signalInfo.isDouble()) {
            signalData.setDataType("DOUBLE");
            signalData.setValue(BIKE_FAKER.signal().random());
        }

        if (signalInfo.isInteger()) {
            signalData.setDataType("INTEGER");
            signalData.setValue(BIKE_FAKER.signal().randomInt(1, 5));
        }

        if (signalInfo.isBoolean()) {
            signalData.setDataType("BOOLEAN");
            signalData.setValue(true);
        }

        return signalData;
    }

}
