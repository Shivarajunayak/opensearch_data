package org.hmcl.cvp.dataplatform.hotstorage.operator;

import org.apache.flink.api.java.utils.ParameterTool;
import org.apache.flink.runtime.jobgraph.OperatorID;
import org.apache.flink.runtime.metrics.groups.InternalOperatorMetricGroup;
import org.apache.flink.runtime.metrics.util.InterceptingOperatorMetricGroup;
import org.apache.flink.runtime.metrics.util.InterceptingTaskMetricGroup;
import org.apache.flink.runtime.operators.testutils.MockEnvironment;
import org.apache.flink.runtime.operators.testutils.MockEnvironmentBuilder;
import org.apache.flink.runtime.testutils.MiniClusterResourceConfiguration;
import org.apache.flink.streaming.api.operators.StreamFlatMap;
import org.apache.flink.streaming.runtime.streamrecord.StreamRecord;
import org.apache.flink.streaming.util.OneInputStreamOperatorTestHarness;
import org.apache.flink.test.util.MiniClusterWithClientResource;
import org.hmcl.cvp.dataplatform.commons.constants.FlinkRuntime;
import org.hmcl.cvp.dataplatform.commons.utils.FlinkUtils;
import org.hmcl.cvp.dataplatform.contract.telemetry.SignalData;
import org.hmcl.cvp.dataplatform.contract.telemetry.Telemetry;
import org.hmcl.cvp.dataplatform.hotstorage.contract.OpenSearchDocument;
import org.hmcl.cvp.dataplatform.hotstorage.utils.HotStorageData;
import org.junit.Assert;
import org.junit.ClassRule;
import org.junit.Test;

import java.time.Instant;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;

public class ChargingAnalyticsMapperFunctionTest {

    @ClassRule
    public static MiniClusterWithClientResource flinkCluster =
            new MiniClusterWithClientResource(
                    new MiniClusterResourceConfiguration.Builder()
                            .setNumberSlotsPerTaskManager(2)
                            .setNumberTaskManagers(1)
                            .build());

    private final InterceptingOperatorMetricGroup interceptingOperatorMetricGroup = new InterceptingOperatorMetricGroup();
    private final InterceptingTaskMetricGroup interceptingTaskMetricGroup = new InterceptingTaskMetricGroup() {
        @Override
        public InternalOperatorMetricGroup getOrAddOperator(OperatorID operatorID, String name) {
            return interceptingOperatorMetricGroup;
        }
    };

    private final MockEnvironment mockEnvironment = new MockEnvironmentBuilder().setMetricGroup(interceptingTaskMetricGroup).build();
    private final ChargingAnalyticsMapperFunction mapperFunction = new ChargingAnalyticsMapperFunction();

    private OneInputStreamOperatorTestHarness<Telemetry, OpenSearchDocument> testHarness() throws Exception {
        ParameterTool parameterTool = ParameterTool.fromMap(new HashMap<>());
        parameterTool = FlinkUtils.addProperties(parameterTool, Map.of(FlinkRuntime.HotStorage.EV_CHARGING_INDEX, HotStorageData.EV_CHARGING_INDEX));
        mockEnvironment.getExecutionConfig().setGlobalJobParameters(parameterTool);

        return new OneInputStreamOperatorTestHarness<>(new StreamFlatMap<>(mapperFunction), mockEnvironment);
    }

    @Test
    public void testMasterTelemetryMapperFunction_Ev() {
        try(OneInputStreamOperatorTestHarness<Telemetry, OpenSearchDocument> testHarness = testHarness()) {

            testHarness.setup();
            testHarness.open();

            String virtualId = "test-vehicle";
            Telemetry telemetry = HotStorageData.getChargerCampaignData(virtualId, 1);

            SignalData chargingSessionSignalData = new SignalData();
            chargingSessionSignalData.setDataType("VARCHAR");
            chargingSessionSignalData.setValue("IQOhxYDXi5lgGnWH7d56S1aoGDdgTVzXbg1u");
            chargingSessionSignalData.setTime(Instant.now().toEpochMilli());

            telemetry.getSignals().put("hmcl.common.custom.charging_session_id",new HashSet<>(List.of(chargingSessionSignalData)));
            testHarness.processElement(new StreamRecord<>(telemetry));

            List<OpenSearchDocument> output = HotStorageData.getOutput(testHarness.getRecordOutput());

            boolean isEvIndex = output.stream().allMatch(v -> v.getIndex().equals(HotStorageData.EV_CHARGING_INDEX));

            Assert.assertTrue(isEvIndex);
            Assert.assertEquals(1, output.size());
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    @Test
    public void testMasterTelemetryMapperFunction_EvChargingStart() {
        try(OneInputStreamOperatorTestHarness<Telemetry, OpenSearchDocument> testHarness = testHarness()) {

            testHarness.setup();
            testHarness.open();

            String virtualId = "test-vehicle";
            Telemetry telemetry = HotStorageData.getChargerCampaignData(virtualId, 1);
            HotStorageData.addChargingSessionStart(telemetry, Instant.now());
            testHarness.processElement(new StreamRecord<>(telemetry));

            List<OpenSearchDocument> output = HotStorageData.getOutput(testHarness.getRecordOutput());

            boolean isEvIndex = output.stream().allMatch(v -> v.getIndex().equals(HotStorageData.EV_CHARGING_INDEX));

            Assert.assertTrue(isEvIndex);
            Assert.assertEquals(1, output.size());
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    @Test
    public void testMasterTelemetryMapperFunction_EvChargingEnd() {
        try(OneInputStreamOperatorTestHarness<Telemetry, OpenSearchDocument> testHarness = testHarness()) {

            testHarness.setup();
            testHarness.open();

            String virtualId = "test-vehicle";
            Telemetry telemetry = HotStorageData.getChargerCampaignData(virtualId, 1);
            HotStorageData.addChargingSessionEnd(telemetry, Instant.now());

            testHarness.processElement(new StreamRecord<>(telemetry));

            List<OpenSearchDocument> output = HotStorageData.getOutput(testHarness.getRecordOutput());

            boolean isEvIndex = output.stream().allMatch(v -> v.getIndex().equals(HotStorageData.EV_CHARGING_INDEX));

            Assert.assertTrue(isEvIndex);
            Assert.assertEquals(1, output.size());
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    @Test
    public void testMasterTelemetryMapperFunctionWithoutSessionId_Ev() {
        try(OneInputStreamOperatorTestHarness<Telemetry, OpenSearchDocument> testHarness = testHarness()) {

            testHarness.setup();
            testHarness.open();

            String virtualId = "test-vehicle";
            Telemetry telemetry = HotStorageData.getChargerCampaignData(virtualId, 1);

            testHarness.processElement(new StreamRecord<>(telemetry));

            List<OpenSearchDocument> output = HotStorageData.getOutput(testHarness.getRecordOutput());

            boolean isEvIndex = output.stream().allMatch(v -> v.getIndex().equals(HotStorageData.EV_CHARGING_INDEX));

            Assert.assertTrue(isEvIndex);
            Assert.assertEquals(0, output.size());
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }
}
