package org.hmcl.cvp.dataplatform.hotstorage.operator;

import org.apache.flink.api.java.utils.ParameterTool;
import org.apache.flink.runtime.jobgraph.OperatorID;
import org.apache.flink.runtime.metrics.groups.InternalOperatorMetricGroup;
import org.apache.flink.runtime.metrics.util.InterceptingOperatorMetricGroup;
import org.apache.flink.runtime.metrics.util.InterceptingTaskMetricGroup;
import org.apache.flink.runtime.operators.testutils.MockEnvironment;
import org.apache.flink.runtime.operators.testutils.MockEnvironmentBuilder;
import org.apache.flink.runtime.testutils.MiniClusterResourceConfiguration;
import org.apache.flink.streaming.api.operators.StreamFlatMap;
import org.apache.flink.streaming.runtime.streamrecord.StreamRecord;
import org.apache.flink.streaming.util.OneInputStreamOperatorTestHarness;
import org.apache.flink.test.util.MiniClusterWithClientResource;
import org.hmcl.cvp.dataplatform.commons.constants.FlinkRuntime;
import org.hmcl.cvp.dataplatform.commons.testdata.CampaignDataGenerator;
import org.hmcl.cvp.dataplatform.commons.utils.FlinkUtils;
import org.hmcl.cvp.dataplatform.contract.telemetry.Telemetry;
import org.hmcl.cvp.dataplatform.contract.telemetry.Tenant;
import org.hmcl.cvp.dataplatform.hotstorage.contract.OpenSearchDocument;
import org.hmcl.cvp.dataplatform.hotstorage.utils.HotStorageData;
import org.junit.Assert;
import org.junit.ClassRule;
import org.junit.Test;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class MasterTelemetryMapperFunctionTest {

    @ClassRule
    public static MiniClusterWithClientResource flinkCluster =
            new MiniClusterWithClientResource(
                    new MiniClusterResourceConfiguration.Builder()
                            .setNumberSlotsPerTaskManager(2)
                            .setNumberTaskManagers(1)
                            .build());

    private final InterceptingOperatorMetricGroup interceptingOperatorMetricGroup = new InterceptingOperatorMetricGroup();
    private final InterceptingTaskMetricGroup interceptingTaskMetricGroup = new InterceptingTaskMetricGroup() {
        @Override
        public InternalOperatorMetricGroup getOrAddOperator(OperatorID operatorID, String name) {
            return interceptingOperatorMetricGroup;
        }
    };

    private final MockEnvironment mockEnvironment = new MockEnvironmentBuilder().setMetricGroup(interceptingTaskMetricGroup).build();
    private final MasterTelemetryMapperFunction telemetryMapperFunction = new MasterTelemetryMapperFunction();

    private OneInputStreamOperatorTestHarness<Telemetry, OpenSearchDocument> testHarness() throws Exception {
        ParameterTool parameterTool = ParameterTool.fromMap(new HashMap<>());
        parameterTool = FlinkUtils.addProperties(parameterTool, Map.of(FlinkRuntime.HotStorage.EV_MASTER_TELEMETRY_INDEX,
                HotStorageData.EV_MASTER_TELEMETRY_INDEX));
        parameterTool = FlinkUtils.addProperties(parameterTool, Map.of(FlinkRuntime.HotStorage.ICE_MASTER_TELEMETRY_INDEX,
                HotStorageData.ICE_MASTER_TELEMETRY_INDEX));
        parameterTool = FlinkUtils.addProperties(parameterTool, Map.of(FlinkRuntime.HotStorage.HARLEY_MASTER_TELEMETRY_INDEX,
                HotStorageData.HARLEY_MASTER_TELEMETRY_INDEX));
        mockEnvironment.getExecutionConfig().setGlobalJobParameters(parameterTool);
        return new OneInputStreamOperatorTestHarness<>(new StreamFlatMap<>(telemetryMapperFunction), mockEnvironment);
    }

    @Test
    public void testMasterTelemetryMapperFunction_Ev() {
        try(OneInputStreamOperatorTestHarness<Telemetry, OpenSearchDocument> testHarness = testHarness()) {

            testHarness.setup();
            testHarness.open();

            int numOfEvents = 5;
            List<Telemetry> jsonData = CampaignDataGenerator.getTelemetries(Tenant.EV, numOfEvents);
            List<StreamRecord<Telemetry>> streamRecords = HotStorageData.getTelemetryStreamRecords(jsonData);

            testHarness.processElements(streamRecords);
            List<OpenSearchDocument> output = HotStorageData.getOutput(testHarness.getRecordOutput());

            boolean isEvIndex = output.stream().allMatch(v -> v.getIndex().equals(HotStorageData.EV_MASTER_TELEMETRY_INDEX));

            Assert.assertTrue(isEvIndex);
            Assert.assertEquals(numOfEvents, output.size());
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    @Test
    public void testMasterTelemetryMapperFunction_Ice() {
        try(OneInputStreamOperatorTestHarness<Telemetry, OpenSearchDocument> testHarness = testHarness()) {

            testHarness.setup();
            testHarness.open();

            int numOfEvents = 5;
            List<Telemetry> jsonData = CampaignDataGenerator.getTelemetries(Tenant.ICE, numOfEvents);
            List<StreamRecord<Telemetry>> streamRecords = HotStorageData.getTelemetryStreamRecords(jsonData);

            testHarness.processElements(streamRecords);
            List<OpenSearchDocument> output = HotStorageData.getOutput(testHarness.getRecordOutput());

            boolean isIceIndex = output.stream().allMatch(v -> v.getIndex().equals(HotStorageData.ICE_MASTER_TELEMETRY_INDEX));

            Assert.assertTrue(isIceIndex);
            Assert.assertEquals(numOfEvents, output.size());
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    @Test
    public void testMasterTelemetryMapperFunction_Harley() {
        try(OneInputStreamOperatorTestHarness<Telemetry, OpenSearchDocument> testHarness = testHarness()) {

            testHarness.setup();
            testHarness.open();

            int numOfEvents = 5;
            List<Telemetry> jsonData = CampaignDataGenerator.getTelemetries(Tenant.HARLEY, numOfEvents);
            List<StreamRecord<Telemetry>> streamRecords = HotStorageData.getTelemetryStreamRecords(jsonData);

            testHarness.processElements(streamRecords);
            List<OpenSearchDocument> output = HotStorageData.getOutput(testHarness.getRecordOutput());

            boolean isHarleyIndex = output.stream().allMatch(v -> v.getIndex().equals(HotStorageData.HARLEY_MASTER_TELEMETRY_INDEX));

            Assert.assertTrue(isHarleyIndex);
            Assert.assertEquals(numOfEvents, output.size());
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

}
