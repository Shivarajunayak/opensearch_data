package org.hmcl.cvp.dataplatform.hotstorage.operator;

import org.apache.flink.api.java.utils.ParameterTool;
import org.apache.flink.runtime.jobgraph.OperatorID;
import org.apache.flink.runtime.metrics.groups.InternalOperatorMetricGroup;
import org.apache.flink.runtime.metrics.util.InterceptingOperatorMetricGroup;
import org.apache.flink.runtime.metrics.util.InterceptingTaskMetricGroup;
import org.apache.flink.runtime.operators.testutils.MockEnvironment;
import org.apache.flink.runtime.operators.testutils.MockEnvironmentBuilder;
import org.apache.flink.runtime.testutils.MiniClusterResourceConfiguration;
import org.apache.flink.streaming.api.operators.StreamFlatMap;
import org.apache.flink.streaming.runtime.streamrecord.StreamRecord;
import org.apache.flink.streaming.util.OneInputStreamOperatorTestHarness;
import org.apache.flink.test.util.MiniClusterWithClientResource;
import org.hmcl.cvp.dataplatform.commons.catalogue.SignalCatalogue;
import org.hmcl.cvp.dataplatform.commons.constants.FlinkRuntime;
import org.hmcl.cvp.dataplatform.commons.utils.FlinkUtils;
import org.hmcl.cvp.dataplatform.contract.telemetry.SignalInfo;
import org.hmcl.cvp.dataplatform.contract.telemetry.Telemetry;
import org.hmcl.cvp.dataplatform.contract.telemetry.Tenant;
import org.hmcl.cvp.dataplatform.hotstorage.contract.OpenSearchDocument;
import org.hmcl.cvp.dataplatform.hotstorage.utils.HotStorageData;
import org.junit.Assert;
import org.junit.ClassRule;
import org.junit.Test;

import java.time.Instant;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class TelemetryFlattenedMapperFunctionTest {

    @ClassRule
    public static MiniClusterWithClientResource flinkCluster =
            new MiniClusterWithClientResource(
                    new MiniClusterResourceConfiguration.Builder()
                            .setNumberSlotsPerTaskManager(2)
                            .setNumberTaskManagers(1)
                            .build());

    private final InterceptingOperatorMetricGroup interceptingOperatorMetricGroup = new InterceptingOperatorMetricGroup();
    private final InterceptingTaskMetricGroup interceptingTaskMetricGroup = new InterceptingTaskMetricGroup() {
        @Override
        public InternalOperatorMetricGroup getOrAddOperator(OperatorID operatorID, String name) {
            return interceptingOperatorMetricGroup;
        }
    };

    private final MockEnvironment mockEnvironment = new MockEnvironmentBuilder().setMetricGroup(interceptingTaskMetricGroup).build();

    private final TelemetryFlattenedMapperFunction telemetryFlattenedMapperFunction = new TelemetryFlattenedMapperFunction();

    private OneInputStreamOperatorTestHarness<Telemetry, OpenSearchDocument> testHarness() throws Exception {
        ParameterTool parameterTool = ParameterTool.fromMap(new HashMap<>());
        parameterTool = FlinkUtils.addProperties(parameterTool, Map.of(FlinkRuntime.HotStorage.EPOCH_DIGITS_TO_IGNORE_WHILE_FLATTENING, "3"));

        parameterTool = FlinkUtils.addProperties(parameterTool, Map.of(FlinkRuntime.HotStorage.EV_MASTER_FLATTENED_TELEMETRY_INDEX, HotStorageData.EV_FLATTENED_TELEMETRY_INDEX));
        parameterTool = FlinkUtils.addProperties(parameterTool, Map.of(FlinkRuntime.HotStorage.ICE_MASTER_FLATTENED_TELEMETRY_INDEX, HotStorageData.ICE_FLATTENED_TELEMETRY_INDEX));
        parameterTool = FlinkUtils.addProperties(parameterTool, Map.of(FlinkRuntime.HotStorage.HARLEY_MASTER_FLATTENED_TELEMETRY_INDEX, HotStorageData.HARLEY_FLATTENED_TELEMETRY_INDEX));

        parameterTool = FlinkUtils.addProperties(parameterTool, Map.of(FlinkRuntime.HotStorage.EV_MASTER_DTC_TELEMETRY_INDEX, HotStorageData.EV_DTC_TELEMETRY_INDEX));
        parameterTool = FlinkUtils.addProperties(parameterTool, Map.of(FlinkRuntime.HotStorage.ICE_MASTER_DTC_TELEMETRY_INDEX, HotStorageData.ICE_DTC_TELEMETRY_INDEX));
        parameterTool = FlinkUtils.addProperties(parameterTool, Map.of(FlinkRuntime.HotStorage.HARLEY_MASTER_DTC_TELEMETRY_INDEX, HotStorageData.HARLEY_DTC_TELEMETRY_INDEX));

        mockEnvironment.getExecutionConfig().setGlobalJobParameters(parameterTool);

        return new OneInputStreamOperatorTestHarness<>(new StreamFlatMap<>(telemetryFlattenedMapperFunction), mockEnvironment);

    }

    @Test
    public void testMasterTelemetryMapperFunction_evFlattenMasterTelemetry() {
        flattenMasterTelemetry(Tenant.EV, HotStorageData.EV_FLATTENED_TELEMETRY_INDEX);
    }

    @Test
    public void testMasterTelemetryMapperFunction_iceFlattenMasterTelemetry() {
        flattenMasterTelemetry(Tenant.ICE, HotStorageData.ICE_FLATTENED_TELEMETRY_INDEX);
    }

    @Test
    public void testMasterTelemetryMapperFunction_harleyFlattenMasterTelemetry() {
        flattenMasterTelemetry(Tenant.HARLEY, HotStorageData.HARLEY_FLATTENED_TELEMETRY_INDEX);
    }

    private void flattenMasterTelemetry(Tenant tenant, String indexName) {

        try(OneInputStreamOperatorTestHarness<Telemetry, OpenSearchDocument> testHarness = testHarness()) {

            testHarness.setup();
            testHarness.open();

            int countOfEachSignals = 2;
            long milliSecondsDiff = 5000L;
            Instant instant = Instant.now();
            Telemetry telemetry = HotStorageData.getTelemetryForFlattening(tenant, instant, countOfEachSignals, milliSecondsDiff);

            testHarness.processElement(new StreamRecord<>(telemetry));
            List<OpenSearchDocument> output = HotStorageData.getOutput(testHarness.getRecordOutput());
            Assert.assertEquals(countOfEachSignals, output.size());

            output.forEach(o -> {
                Assert.assertEquals(indexName, o.getIndex());
            });


        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    @Test
    public void testMasterTelemetryMapperFunction_evFlattenDtcTelemetry() {
        flattenDtcTelemetry(Tenant.EV, HotStorageData.EV_DTC_TELEMETRY_INDEX);
    }

    @Test
    public void testMasterTelemetryMapperFunction_iceFlattenDtcTelemetry() {
        flattenDtcTelemetry(Tenant.ICE, HotStorageData.ICE_DTC_TELEMETRY_INDEX);
    }

    @Test
    public void testMasterTelemetryMapperFunction_harleyFlattenDtcTelemetry() {
        flattenDtcTelemetry(Tenant.HARLEY, HotStorageData.HARLEY_DTC_TELEMETRY_INDEX);
    }

    private void flattenDtcTelemetry(Tenant tenant, String indexName) {
        try(OneInputStreamOperatorTestHarness<Telemetry, OpenSearchDocument> testHarness = testHarness()) {

            testHarness.setup();
            testHarness.open();

            Instant instant = Instant.now();
            int countOfEachSignal = 2;
            int countOfDTCCodes = 3;
            SignalInfo signalInfo = SignalCatalogue.getDTCInfo();
            Telemetry telemetry = HotStorageData.getTelemetryWithDTCInfo(tenant, instant, signalInfo, countOfEachSignal, countOfDTCCodes, true);

            testHarness.processElement(new StreamRecord<>(telemetry));
            List<OpenSearchDocument> output = HotStorageData.getOutput(testHarness.getRecordOutput());
            int numActualSize = countOfEachSignal * countOfDTCCodes * countOfDTCCodes;
            Assert.assertEquals(numActualSize, output.size());

            output.forEach(o -> {
                Assert.assertEquals(indexName, o.getIndex());
            });

        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    @Test
    public void testMasterTelemetryMapperFunction_evFlattenMasterAndDtcTelemetry() {
        flattenMasterAndDtcTelemetry(Tenant.EV);
    }

    @Test
    public void testMasterTelemetryMapperFunction_iceFlattenMasterAndDtcTelemetry() {
        flattenMasterAndDtcTelemetry(Tenant.ICE);
    }

    @Test
    public void testMasterTelemetryMapperFunction_harleyFlattenMasterAndDtcTelemetry() {
        flattenMasterAndDtcTelemetry(Tenant.HARLEY);
    }

    private void flattenMasterAndDtcTelemetry(Tenant tenant) {
        try(OneInputStreamOperatorTestHarness<Telemetry, OpenSearchDocument> testHarness = testHarness()) {

            testHarness.setup();
            testHarness.open();

            Instant instant = Instant.now();
            int countOfEachSignal = 2;
            int countOfDTCCodes = 3;
            SignalInfo signalInfo = SignalCatalogue.getDTCInfo();
            Telemetry telemetry = HotStorageData.getTelemetryWithDTCInfo(tenant, instant, signalInfo, countOfEachSignal, countOfDTCCodes, false);

            testHarness.processElement(new StreamRecord<>(telemetry));
            List<OpenSearchDocument> output = HotStorageData.getOutput(testHarness.getRecordOutput());
            // 18 dtc objects and 2 master telemetry
            int numDtcDocs = countOfEachSignal * countOfDTCCodes * countOfDTCCodes;
            int numFlattenMasterDocs = countOfEachSignal;
            int numActualSize = numDtcDocs + numFlattenMasterDocs;
            Assert.assertEquals(numActualSize, output.size());

            long dtcDocuments = output.stream().filter(OpenSearchDocument::getIsFlattenedDtc).count();
            Assert.assertEquals(numDtcDocs, dtcDocuments);

            long flattenMasterDocuments = output.stream().filter(OpenSearchDocument::getIsFlattenedTelemetry).count();
            Assert.assertEquals(numFlattenMasterDocs, flattenMasterDocuments);

        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

}
