package org.hmcl.cvp.dataplatform.hotstorage.operator;

import org.apache.flink.api.common.typeinfo.Types;
import org.apache.flink.streaming.api.operators.StreamFlatMap;
import org.apache.flink.streaming.runtime.streamrecord.StreamRecord;
import org.apache.flink.streaming.util.KeyedOneInputStreamOperatorTestHarness;
import org.hmcl.cvp.dataplatform.contract.telemetry.Telemetry;
import org.hmcl.cvp.dataplatform.hotstorage.utils.HotStorageData;
import org.junit.Assert;
import org.junit.Test;

import java.util.List;

public class OutOfOrderFilterFunctionTest {

    @Test
    public void filtersOutOfOrderEvents() throws Exception {
        try (KeyedOneInputStreamOperatorTestHarness<String, Telemetry, Telemetry> testHarness =
                     new KeyedOneInputStreamOperatorTestHarness<>(
                             new StreamFlatMap<>(new OutOfOrderFilterFunction()),
                             telemetry->telemetry.getDimensions().get("hmcl.virtualId"), // Key selector
                             Types.STRING // Key type information
                     )) {

            testHarness.setup();
            testHarness.open();

            String virtualId = "test-vehicle";
            Telemetry firstEvent = HotStorageData.getChargerCampaignData(virtualId, 1);
            firstEvent.setCollectionEventTime(1000L);

            Telemetry secondEvent = HotStorageData.getChargerCampaignData(virtualId, 1);
            secondEvent.setCollectionEventTime(500L);

            testHarness.processElement(new StreamRecord<>(firstEvent));
            testHarness.processElement(new StreamRecord<>(secondEvent));

            List<Telemetry> output = HotStorageData.getOutput(testHarness.getRecordOutput());

            Assert.assertEquals(1, output.size());
            Assert.assertEquals(1000L, output.get(0).getCollectionEventTime());

        }
    }

    @Test
    public void allowsInOrderEvents() throws Exception {
        try (KeyedOneInputStreamOperatorTestHarness<String, Telemetry, Telemetry> testHarness =
                     new KeyedOneInputStreamOperatorTestHarness<>(
                             new StreamFlatMap<>(new OutOfOrderFilterFunction()),
                             telemetry->telemetry.getDimensions().get("hmcl.virtualId"), // Key selector
                             Types.STRING // Key type information
                     )) {

            testHarness.setup();
            testHarness.open();

            String virtualId = "test-vehicle";
            Telemetry firstEvent = HotStorageData.getChargerCampaignData(virtualId, 1);
            firstEvent.setCollectionEventTime(1000L);

            Telemetry secondEvent = HotStorageData.getChargerCampaignData(virtualId, 1);
            secondEvent.setCollectionEventTime(2000L);

            testHarness.processElement(new StreamRecord<>(firstEvent));
            testHarness.processElement(new StreamRecord<>(secondEvent));

            List<Telemetry> output = HotStorageData.getOutput(testHarness.getRecordOutput());

            Assert.assertEquals(2, output.size());
            Assert.assertEquals(1000L, output.get(0).getCollectionEventTime());
            Assert.assertEquals(2000L, output.get(1).getCollectionEventTime());
        }
    }

    @Test
    public void handlesNullLastProcessedEventTime() throws Exception {
        try (KeyedOneInputStreamOperatorTestHarness<String, Telemetry, Telemetry> testHarness =
                     new KeyedOneInputStreamOperatorTestHarness<>(
                             new StreamFlatMap<>(new OutOfOrderFilterFunction()),
                             telemetry->telemetry.getDimensions().get("hmcl.virtualId"), // Key selector
                             Types.STRING // Key type information
                     )) {

            testHarness.setup();
            testHarness.open();

            String virtualId = "test-vehicle";
            Telemetry event = HotStorageData.getChargerCampaignData(virtualId, 1);
            event.setCollectionEventTime(1000L);

            testHarness.processElement(new StreamRecord<>(event));

            List<Telemetry> output = HotStorageData.getOutput(testHarness.getRecordOutput());

            Assert.assertEquals(1, output.size());
            Assert.assertEquals(1000L, output.get(0).getCollectionEventTime());
        }
    }

    @Test
    public void acceptsEventsWithSameTimestamp() throws Exception {
        try (KeyedOneInputStreamOperatorTestHarness<String, Telemetry, Telemetry> testHarness =
                     new KeyedOneInputStreamOperatorTestHarness<>(
                             new StreamFlatMap<>(new OutOfOrderFilterFunction()),
                             telemetry->telemetry.getDimensions().get("hmcl.virtualId"), // Key selector
                             Types.STRING // Key type information
                     )) {
            testHarness.setup();
            testHarness.open();

            String virtualId = "test-vehicle";
            Telemetry firstEvent = HotStorageData.getChargerCampaignData(virtualId, 1);
            firstEvent.setCollectionEventTime(1000L);

            Telemetry secondEvent = HotStorageData.getChargerCampaignData(virtualId, 1);
            secondEvent.setCollectionEventTime(1000L);

            testHarness.processElement(new StreamRecord<>(firstEvent));
            testHarness.processElement(new StreamRecord<>(secondEvent));

            List<Telemetry> output = HotStorageData.getOutput(testHarness.getRecordOutput());

            Assert.assertEquals(2, output.size());
            Assert.assertEquals(1000L, output.get(0).getCollectionEventTime());
            Assert.assertEquals(1000L, output.get(0).getCollectionEventTime());
        }
    }
}