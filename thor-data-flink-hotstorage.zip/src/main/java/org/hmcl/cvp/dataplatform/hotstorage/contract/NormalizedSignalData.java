package org.hmcl.cvp.dataplatform.hotstorage.contract;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Objects;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class NormalizedSignalData {

    private Object value;

    private long time;

    private long normalizedTime;

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof NormalizedSignalData)) return false;
        NormalizedSignalData that = (NormalizedSignalData) o;
        return time == that.time && normalizedTime == that.normalizedTime && Objects.equals(value, that.value);
    }

    @Override
    public int hashCode() {
        return Objects.hash(value, time, normalizedTime);
    }
}
