package org.hmcl.cvp.dataplatform.hotstorage.contract;

import com.google.gson.annotations.SerializedName;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class FlattenedDtcTelemetry implements Serializable {

    @SerializedName("vid")
    private String vid;

    @SerializedName("tenantId")
    private String tenantId;

    @SerializedName("campaignName")
    private String campaignName;

    @SerializedName("eventId")
    private String eventId;

    @SerializedName("collectionEventTime")
    private Long collectionEventTime;

    @SerializedName("collectionEventTimeTsp")
    private String collectionEventTimeTsp;

    @SerializedName("systemTime")
    private Long systemTime;

    @SerializedName("systemTimeTsp")
    private String systemTimeTsp;

    @SerializedName("daTime")
    private Long daTime;

    @SerializedName("daStatusAvailabilityMask")
    private String daStatusAvailabilityMask;

    @SerializedName("daEcuID")
    private String daEcuID;

    @SerializedName("daExtendedData")
    private String daExtendedData;

    @SerializedName("daSnapshotRecord")
    private String daSnapshotRecord;

    @SerializedName("daCode")
    private String daCode;

    @SerializedName("diaTime")
    private Long diaTime;

    @SerializedName("diaStatusAvailabilityMask")
    private String diaStatusAvailabilityMask;

    @SerializedName("diaEcuID")
    private String diaEcuID;

    @SerializedName("diaExtendedData")
    private String diaExtendedData;

    @SerializedName("diaSnapshotRecord")
    private String diaSnapshotRecord;

    @SerializedName("diaCode")
    private String diaCode;

}
