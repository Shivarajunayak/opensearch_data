package org.hmcl.cvp.dataplatform.hotstorage.contract;

import com.google.gson.annotations.SerializedName;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class ChargingSession {

    @SerializedName("chargingSessionId")
    private String chargingSessionId;

    @SerializedName("startTimestamp")
    private Long startTimestamp;

    @SerializedName("endTimestamp")
    private Long endTimestamp;

}
