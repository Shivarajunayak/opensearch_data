package org.hmcl.cvp.dataplatform.hotstorage.operator;

import lombok.extern.slf4j.Slf4j;
import org.apache.flink.api.common.functions.RichFlatMapFunction;
import org.apache.flink.api.java.tuple.Tuple2;
import org.apache.flink.api.java.utils.ParameterTool;
import org.apache.flink.configuration.Configuration;
import org.apache.flink.metrics.Counter;
import org.apache.flink.util.Collector;
import org.hmcl.cvp.dataplatform.commons.catalogue.SignalCatalogue;
import org.hmcl.cvp.dataplatform.commons.constants.Constants;
import org.hmcl.cvp.dataplatform.commons.constants.FlinkRuntime;
import org.hmcl.cvp.dataplatform.commons.utils.DateUtils;
import org.hmcl.cvp.dataplatform.commons.utils.TelemetryUtils;
import org.hmcl.cvp.dataplatform.contract.telemetry.SignalInfo;
import org.hmcl.cvp.dataplatform.contract.telemetry.Telemetry;
import org.hmcl.cvp.dataplatform.contract.telemetry.Tenant;
import org.hmcl.cvp.dataplatform.hotstorage.contract.DtcWrapper;
import org.hmcl.cvp.dataplatform.hotstorage.contract.FlattenedDtcTelemetry;
import org.hmcl.cvp.dataplatform.hotstorage.contract.FlattenedMasterTelemetry;
import org.hmcl.cvp.dataplatform.hotstorage.contract.NormalizedSignalData;
import org.hmcl.cvp.dataplatform.hotstorage.contract.NormalizedTelemetry;
import org.hmcl.cvp.dataplatform.hotstorage.contract.OpenSearchDocument;
import org.hmcl.cvp.dataplatform.hotstorage.helper.DTCFlatteningHelper;
import org.hmcl.cvp.dataplatform.hotstorage.helper.TelemetryFlatteningHelper;
import org.opensearch.action.DocWriteRequest;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Objects;

@Slf4j
public class TelemetryFlattenedMapperFunction extends RichFlatMapFunction<Telemetry, OpenSearchDocument> {

    private static final Integer CONVERT_MILLI_TO_SECONDS = 3;

    private transient Counter numSuccessEventCounter;
    private transient Counter numErrorEventCounter;
    private transient Counter numEvTenantCounter;
    private transient Counter numIceTenantCounter;
    private transient Counter numHarleyTenantCounter;

    private transient String evFlattenedIndex;
    private transient String iceFlattenedIndex;
    private transient String harleyFlattenedIndex;
    private transient String evDtcIndex;
    private transient String iceDtcIndex;
    private transient String harleyDtcIndex;

    private transient int epochDigitsToIgnore;

    private Counter counterInitializer(String counterName) {
        return getRuntimeContext()
                .getMetricGroup()
                .addGroup(Constants.METRIC_GROUP_NAME)
                .addGroup(Constants.METRIC_SUB_GROUP_KEY, "FlattenedMasterTelemetry")
                .counter(counterName);
    }

    @Override
    public void open(Configuration parameters) throws Exception {
        super.open(parameters);
        numSuccessEventCounter = counterInitializer("numSuccessEvents");
        numErrorEventCounter = counterInitializer("numErrorEvents");
        numEvTenantCounter = counterInitializer("numEvEvents");
        numIceTenantCounter = counterInitializer("numIceEvents");
        numHarleyTenantCounter = counterInitializer("numHarleyEvents");

        ParameterTool parameterTool = (ParameterTool) getRuntimeContext().getExecutionConfig().getGlobalJobParameters();

        evFlattenedIndex = parameterTool.getRequired(FlinkRuntime.HotStorage.EV_MASTER_FLATTENED_TELEMETRY_INDEX);
        iceFlattenedIndex = parameterTool.getRequired(FlinkRuntime.HotStorage.ICE_MASTER_FLATTENED_TELEMETRY_INDEX);
        harleyFlattenedIndex = parameterTool.getRequired(FlinkRuntime.HotStorage.HARLEY_MASTER_FLATTENED_TELEMETRY_INDEX);

        evDtcIndex = parameterTool.getRequired(FlinkRuntime.HotStorage.EV_MASTER_DTC_TELEMETRY_INDEX);
        iceDtcIndex = parameterTool.getRequired(FlinkRuntime.HotStorage.ICE_MASTER_DTC_TELEMETRY_INDEX);
        harleyDtcIndex = parameterTool.getRequired(FlinkRuntime.HotStorage.HARLEY_MASTER_DTC_TELEMETRY_INDEX);

        epochDigitsToIgnore = parameterTool.getInt(FlinkRuntime.HotStorage.EPOCH_DIGITS_TO_IGNORE_WHILE_FLATTENING, CONVERT_MILLI_TO_SECONDS);
    }

    @Override
    public void flatMap(Telemetry value, Collector<OpenSearchDocument> out) {
        String vid = TelemetryUtils.getVirtualId(value);

        try {
            Tenant tenant = TelemetryUtils.getTenant(value);
            String tenantId = TelemetryUtils.getTenantId(value);
            Tuple2<String, String> indexes = getOpenSearchIndex(tenant);
            String flattenedMasterIndex = indexes.f0;
            String flattenedDtcIndex = indexes.f1;

            log.debug("flattenedMasterIndex is {} and flattenedDtcIndex is {}", flattenedMasterIndex, flattenedDtcIndex);

            List<FlattenedMasterTelemetry> flattenedMasterTelemetries = flattenMasterTelemetrySignals(vid, tenantId, value);
            List<FlattenedDtcTelemetry> flattenedDtcTelemetries = flattenDtcTelemetrySignals(vid, tenantId, value);

            flattenedMasterTelemetries.forEach(flattenedMasterTelemetry -> {
                OpenSearchDocument openSearchDocument = OpenSearchDocument.builder()
                        .vid(vid)
                        .index(flattenedMasterIndex)
                        .docId(getDocumentId(vid, flattenedMasterTelemetry.getNormalizedSignalTime()))
                        .opType(DocWriteRequest.OpType.UPDATE)
                        .isFlattenedTelemetry(true)
                        .flattenedMasterTelemetry(flattenedMasterTelemetry)
                        .build();

                out.collect(openSearchDocument);
            });

            flattenedDtcTelemetries.forEach(flattenedDtcTelemetry -> {
                OpenSearchDocument openSearchDocument = OpenSearchDocument.builder()
                        .vid(vid)
                        .index(flattenedDtcIndex)
                        .opType(DocWriteRequest.OpType.CREATE)
                        .isFlattenedDtc(true)
                        .flattenedDtcTelemetry(flattenedDtcTelemetry)
                        .build();

                out.collect(openSearchDocument);

            });

            numSuccessEventCounter.inc();

        } catch (Exception e) {
            numErrorEventCounter.inc();
            log.error("Exception while processing telemetry for vehicle {}", vid, e);
        }
    }

    private List<FlattenedMasterTelemetry> flattenMasterTelemetrySignals(String vid, String tenantId, Telemetry value) {

        Map<Long, NormalizedTelemetry> normalizedTelemetryMap = TelemetryFlatteningHelper.getNormalizedTelemetries(value, epochDigitsToIgnore);
        if (normalizedTelemetryMap.isEmpty()) {
            log.debug("No normalized signals found for vehicle {}", vid);
            return new ArrayList<>();
        }

        int normalizedTelemetrySize = normalizedTelemetryMap.size();
        log.debug("There are {} distinct normalized documents for vehicle {}", normalizedTelemetrySize, vid);

        List<FlattenedMasterTelemetry> flattenedTelemetries = new ArrayList<>(normalizedTelemetrySize);

        String campaignName = value.getCampaignName();
        String eventId = String.valueOf(value.getEventId());
        long collectionEventTime = value.getCollectionEventTime();
        String collectionEventTimeTsp = DateUtils.formatToISO(collectionEventTime);

        long systemTime = DateUtils.currentEpochTime();
        String systemTimeTsp = DateUtils.formatToISO(systemTime);

        normalizedTelemetryMap.forEach((normalizedTime, normalizedTelemetry) -> {
            FlattenedMasterTelemetry flattenedTelemetry = createFlattenedTelemetry(vid, tenantId, normalizedTelemetry);
            String normalizedTimeTsp = DateUtils.formatToISO(normalizedTime);
            if(Objects.nonNull(flattenedTelemetry)) {
                flattenedTelemetry.setCampaignName(campaignName);
                flattenedTelemetry.setEventId(eventId);
                flattenedTelemetry.setCollectionEventTime(collectionEventTime);
                flattenedTelemetry.setCollectionEventTimeTsp(collectionEventTimeTsp);
                flattenedTelemetry.setSystemTime(systemTime);
                flattenedTelemetry.setSystemTimeTsp(systemTimeTsp);
                flattenedTelemetry.setNormalizedSignalTime(normalizedTime);
                flattenedTelemetry.setNormalizedSignalTimeTsp(normalizedTimeTsp);

                flattenedTelemetries.add(flattenedTelemetry);
            }
        });

        return flattenedTelemetries;
    }

    private List<FlattenedDtcTelemetry> flattenDtcTelemetrySignals(String vid, String tenantId, Telemetry value) {
        List<DtcWrapper> dtcWrappersActiveList = DTCFlatteningHelper.getDtcInfoSignalValue(vid, value, SignalCatalogue.getDTCInfo());
        List<DtcWrapper> dtcWrappersInActiveList = DTCFlatteningHelper.getDtcInfoSignalValue(vid, value, SignalCatalogue.getDTCInfoInActiveInfo());

        List<FlattenedDtcTelemetry> flattenedDtcTelemetriesActive = DTCFlatteningHelper.getFlattenedDtcTelemetries(vid, dtcWrappersActiveList, true);
        List<FlattenedDtcTelemetry> flattenedDtcTelemetriesInActive = DTCFlatteningHelper.getFlattenedDtcTelemetries(vid, dtcWrappersInActiveList, false);

        flattenedDtcTelemetriesActive.addAll(flattenedDtcTelemetriesInActive);

        String campaignName = value.getCampaignName();
        String eventId = String.valueOf(value.getEventId());
        long collectionEventTime = value.getCollectionEventTime();
        String collectionEventTimeTsp = DateUtils.formatToISO(collectionEventTime);

        long systemTime = DateUtils.currentEpochTime();
        String systemTimeTsp = DateUtils.formatToISO(systemTime);

        flattenedDtcTelemetriesActive.forEach(f -> {
            f.setVid(vid);
            f.setTenantId(tenantId);
            f.setCampaignName(campaignName);
            f.setEventId(eventId);
            f.setCollectionEventTime(collectionEventTime);
            f.setCollectionEventTimeTsp(collectionEventTimeTsp);
            f.setSystemTime(systemTime);
            f.setSystemTimeTsp(systemTimeTsp);
        });

        return flattenedDtcTelemetriesActive;
    }

    private FlattenedMasterTelemetry createFlattenedTelemetry(String vid, String tenantId, NormalizedTelemetry normalizedTelemetry) {
        Map<String, NormalizedSignalData> normalizedSignals = normalizedTelemetry.getNormalizedSignals();
        if(normalizedSignals.isEmpty()) return null;

        FlattenedMasterTelemetry flattenedTelemetry = FlattenedMasterTelemetry.builder()
                .vid(vid)
                .tenantId(tenantId)
                .build();

        setGpsRelatedSignals(normalizedSignals, flattenedTelemetry);

        setBatteryRelatedSignals(normalizedSignals, flattenedTelemetry);

        Tuple2<Boolean, Double> altitude = getDoubleSignalValue(normalizedSignals, SignalCatalogue.getAltitudeInfo());
        if(Boolean.TRUE.equals(altitude.f0)) flattenedTelemetry.setAltitude(altitude.f1);

        Tuple2<Boolean, Integer> clusterSpeed = getIntegerSignalValue(normalizedSignals, SignalCatalogue.getVehicleSpeedDisplayInfo());
        if(Boolean.TRUE.equals(clusterSpeed.f0)) flattenedTelemetry.setClusterSpeed(clusterSpeed.f1);

        Tuple2<Boolean, Integer> driveMode = getIntegerSignalValue(normalizedSignals, SignalCatalogue.getDrivingModeInfo());
        if(Boolean.TRUE.equals(driveMode.f0)) flattenedTelemetry.setDriveMode(driveMode.f1);

        Tuple2<Boolean, Integer> engineTemperature = getIntegerSignalValue(normalizedSignals, SignalCatalogue.getEngineTemperatureInfo());
        if(Boolean.TRUE.equals(engineTemperature.f0)) flattenedTelemetry.setEngineTemperature(engineTemperature.f1);

        Tuple2<Boolean, Double> fuelLevel = getDoubleSignalValue(normalizedSignals, SignalCatalogue.getFuelLevelInfo());
        if(Boolean.TRUE.equals(fuelLevel.f0)) flattenedTelemetry.setFuelLevel(fuelLevel.f1);

        Tuple2<Boolean, Integer> fuelLevelIndication = getIntegerSignalValue(normalizedSignals, SignalCatalogue.getFuelLevelIndicationInfo());
        if(Boolean.TRUE.equals(fuelLevelIndication.f0)) flattenedTelemetry.setFuelLevelIndication(fuelLevelIndication.f1);

        Tuple2<Boolean, Double> internalBatteryChargeVoltage = getDoubleSignalValue(normalizedSignals, SignalCatalogue.getInternalBatteryChargeVoltageInfo());
        if(Boolean.TRUE.equals(internalBatteryChargeVoltage.f0)) flattenedTelemetry.setInternalBatteryChargeVoltage(internalBatteryChargeVoltage.f1);

        Tuple2<Boolean, Double> odoReadingHr = getDoubleSignalValue(normalizedSignals, SignalCatalogue.getOdometerHRInfo());
        if(Boolean.TRUE.equals(odoReadingHr.f0)) flattenedTelemetry.setOdoReadingHr(odoReadingHr.f1);

        Tuple2<Boolean, Double> packVoltage = getDoubleSignalValue(normalizedSignals, SignalCatalogue.getPackVoltageInfo());
        if(Boolean.TRUE.equals(packVoltage.f0)) flattenedTelemetry.setPackVoltage(packVoltage.f1);

        Tuple2<Boolean, Integer> remainingRange = getIntegerSignalValue(normalizedSignals, SignalCatalogue.getRemainingRangeInfo());
        if(Boolean.TRUE.equals(remainingRange.f0)) flattenedTelemetry.setRemainingRange(remainingRange.f1);

        Tuple2<Boolean, Double> tcuMainBatteryVoltage = getDoubleSignalValue(normalizedSignals, SignalCatalogue.getTcuMainVoltageInfo());
        if(Boolean.TRUE.equals(tcuMainBatteryVoltage.f0)) flattenedTelemetry.setTcuMainBatteryVoltage(tcuMainBatteryVoltage.f1);

        Tuple2<Boolean, Integer> totalUsableEnergy = getIntegerSignalValue(normalizedSignals, SignalCatalogue.getTotalUsableEnergyInfo());
        if(Boolean.TRUE.equals(totalUsableEnergy.f0)) flattenedTelemetry.setTotalUsableEnergy(totalUsableEnergy.f1);

        Tuple2<Boolean, Integer> totalUsableEnergyBms1 = getIntegerSignalValue(normalizedSignals, SignalCatalogue.getTotalUsableEnergyBMS1Info());
        if(Boolean.TRUE.equals(totalUsableEnergyBms1.f0)) flattenedTelemetry.setTotalUsableEnergyBms1(totalUsableEnergyBms1.f1);

        Tuple2<Boolean, Integer> totalUsableEnergyBms2 = getIntegerSignalValue(normalizedSignals, SignalCatalogue.getTotalUsableEnergyBMS2Info());
        if(Boolean.TRUE.equals(totalUsableEnergyBms2.f0)) flattenedTelemetry.setTotalUsableEnergyBms2(totalUsableEnergyBms2.f1);

        return flattenedTelemetry;
    }

    private void setGpsRelatedSignals( Map<String, NormalizedSignalData> normalizedSignals, FlattenedMasterTelemetry flattenedTelemetry) {

        Tuple2<Boolean, Double> cog = getDoubleSignalValue(normalizedSignals, SignalCatalogue.getCogInfo());
        if(Boolean.TRUE.equals(cog.f0)) flattenedTelemetry.setCog(cog.f1);

        Tuple2<Boolean, Integer> gpsFix = getIntegerSignalValue(normalizedSignals, SignalCatalogue.getGpsFixInfo());
        if(Boolean.TRUE.equals(gpsFix.f0)) flattenedTelemetry.setGpsFix(gpsFix.f1);

        Tuple2<Boolean, Boolean> gpsValid = getBooleanSignalValue(normalizedSignals, SignalCatalogue.getGpsValidInfo());
        if(Boolean.TRUE.equals(gpsValid.f0)) flattenedTelemetry.setGpsValid(gpsValid.f1);

        Tuple2<Boolean, Double> hDop = getDoubleSignalValue(normalizedSignals, SignalCatalogue.getHDopInfo());
        if(Boolean.TRUE.equals(hDop.f0)) flattenedTelemetry.setHDop(hDop.f1);

        Tuple2<Boolean, Double> latitude = getDoubleSignalValue(normalizedSignals, SignalCatalogue.getLatitudeInfo());
        if(Boolean.TRUE.equals(latitude.f0)) flattenedTelemetry.setLatitude(latitude.f1);

        Tuple2<Boolean, Double> longitude = getDoubleSignalValue(normalizedSignals, SignalCatalogue.getLongitudeInfo());
        if(Boolean.TRUE.equals(longitude.f0)) flattenedTelemetry.setLongitude(longitude.f1);

        Tuple2<Boolean, Double> vDop = getDoubleSignalValue(normalizedSignals, SignalCatalogue.getVDopInfo());
        if(Boolean.TRUE.equals(vDop.f0)) flattenedTelemetry.setVDop(vDop.f1);

        Tuple2<Boolean, Double> packCurrent = getDoubleSignalValue(normalizedSignals, SignalCatalogue.getPackCurrentInfo());
        if(Boolean.TRUE.equals(packCurrent.f0)) flattenedTelemetry.setPackCurrent(packCurrent.f1);

        Tuple2<Boolean, Double> packCurrentBMS1 = getDoubleSignalValue(normalizedSignals, SignalCatalogue.getBMS1PackCurrentInfo());
        if(Boolean.TRUE.equals(packCurrentBMS1.f0)) flattenedTelemetry.setPackCurrentBMS1(packCurrentBMS1.f1);

        Tuple2<Boolean, Double> packCurrentBMS2 = getDoubleSignalValue(normalizedSignals, SignalCatalogue.getBMS2PackCurrentInfo());
        if(Boolean.TRUE.equals(packCurrentBMS2.f0)) flattenedTelemetry.setPackCurrentBMS2(packCurrentBMS2.f1);

        Tuple2<Boolean, Double> estimatedOutputTorque = getDoubleSignalValue(normalizedSignals, SignalCatalogue.getEstimatedOutputTorqueInfo());
        if(Boolean.TRUE.equals(estimatedOutputTorque.f0)) flattenedTelemetry.setEstimatedOutputTorque(estimatedOutputTorque.f1);

        Tuple2<Boolean, Integer> vcuRegBraking = getIntegerSignalValue(normalizedSignals, SignalCatalogue.getVcuRegBrakingInfo());
        if(Boolean.TRUE.equals(vcuRegBraking.f0)) flattenedTelemetry.setVcuRegBraking(vcuRegBraking.f1);

        Tuple2<Boolean, Boolean> tcuIgnition = getBooleanSignalValue(normalizedSignals, SignalCatalogue.getTcuIgnitionInfo());
        if(Boolean.TRUE.equals(tcuIgnition.f0)) flattenedTelemetry.setTcuIgnition(tcuIgnition.f1);
    }

    private void setBatteryRelatedSignals( Map<String, NormalizedSignalData> normalizedSignals, FlattenedMasterTelemetry flattenedTelemetry) {

        Tuple2<Boolean, Double> batteryPackTemperature = getDoubleSignalValue(normalizedSignals, SignalCatalogue.getBatteryPackTemperatureInfo());
        if(Boolean.TRUE.equals(batteryPackTemperature.f0)) flattenedTelemetry.setBatteryPackTemperature(batteryPackTemperature.f1);

        Tuple2<Boolean, Double> batteryPackTemperatureBms1 = getDoubleSignalValue(normalizedSignals, SignalCatalogue.getBMS1BatteryPackTempInfo());
        if(Boolean.TRUE.equals(batteryPackTemperatureBms1.f0)) flattenedTelemetry.setBatteryPackTemperatureBms1(batteryPackTemperatureBms1.f1);

        Tuple2<Boolean, Double> batteryPackTemperatureBms2 = getDoubleSignalValue(normalizedSignals, SignalCatalogue.getBMS2BatteryPackTempInfo());
        if(Boolean.TRUE.equals(batteryPackTemperatureBms2.f0)) flattenedTelemetry.setBatteryPackTemperatureBms2(batteryPackTemperatureBms2.f1);

        Tuple2<Boolean, Integer> bmsBduConnectionRequest = getIntegerSignalValue(normalizedSignals, SignalCatalogue.getBMSBDUConnectionRequestInfo());
        if(Boolean.TRUE.equals(bmsBduConnectionRequest.f0)) flattenedTelemetry.setBmsBduConnectionRequest(bmsBduConnectionRequest.f1);

        Tuple2<Boolean, Double> socUserBms1 = getDoubleSignalValue(normalizedSignals, SignalCatalogue.getSocUserBMS1Info());
        if(Boolean.TRUE.equals(socUserBms1.f0)) flattenedTelemetry.setSocUserBms1(socUserBms1.f1);

        Tuple2<Boolean, Double> socUserBms2 = getDoubleSignalValue(normalizedSignals, SignalCatalogue.getSocUserBMS2Info());
        if(Boolean.TRUE.equals(socUserBms2.f0)) flattenedTelemetry.setSocUserBms2(socUserBms2.f1);

        Tuple2<Boolean, Double> socUser = getDoubleSignalValue(normalizedSignals, SignalCatalogue.getSocUserPercentageInfo());
        if(Boolean.TRUE.equals(socUser.f0)) flattenedTelemetry.setSocUser(socUser.f1);

        Tuple2<Boolean, Double> soh = getDoubleSignalValue(normalizedSignals, SignalCatalogue.getSohInfo());
        if(Boolean.TRUE.equals(soh.f0)) flattenedTelemetry.setSoh(soh.f1);

        Tuple2<Boolean, Double> sohBms1 = getDoubleSignalValue(normalizedSignals, SignalCatalogue.getBMS1SohPercentage());
        if(Boolean.TRUE.equals(sohBms1.f0)) flattenedTelemetry.setSohBms1(sohBms1.f1);

        Tuple2<Boolean, Double> sohBms2 = getDoubleSignalValue(normalizedSignals, SignalCatalogue.getBMS2SohPercentage());
        if(Boolean.TRUE.equals(sohBms2.f0)) flattenedTelemetry.setSohBms2(sohBms2.f1);
    }

    // Tuple2<Master Flattened Index, DTC Index>
    private Tuple2<String, String> getOpenSearchIndex(Tenant tenant) {

        switch (tenant) {
            case EV:
                numEvTenantCounter.inc();
                return new Tuple2<>(evFlattenedIndex, evDtcIndex);
            case HARLEY:
                numHarleyTenantCounter.inc();
                return new Tuple2<>(harleyFlattenedIndex, harleyDtcIndex);
            case ICE:
                numIceTenantCounter.inc();
                return new Tuple2<>(iceFlattenedIndex, iceDtcIndex);
            default:
                numErrorEventCounter.inc();
                throw new IllegalArgumentException("Unsupported tenant type: " + tenant);
        }
    }

    private String getDocumentId(String vid, Long normalizedSignalTime) {
        return vid + ":" + normalizedSignalTime;
    }

    private Tuple2<Boolean, Double> getDoubleSignalValue(Map<String, NormalizedSignalData> normalizedSignals, SignalInfo signalInfo) {
        NormalizedSignalData normalizedSignalData = normalizedSignals.getOrDefault(signalInfo.getKey(), null);
        boolean signalPresent = Objects.nonNull(normalizedSignalData);
        return new Tuple2<>(signalPresent, getDoubleValue(normalizedSignalData));
    }

    private Tuple2<Boolean, Integer> getIntegerSignalValue(Map<String, NormalizedSignalData> normalizedSignals, SignalInfo signalInfo) {
        NormalizedSignalData normalizedSignalData = normalizedSignals.getOrDefault(signalInfo.getKey(), null);
        boolean signalPresent = Objects.nonNull(normalizedSignalData);
        return new Tuple2<>(signalPresent, getIntegerValue(normalizedSignalData));
    }

    private Tuple2<Boolean, Boolean> getBooleanSignalValue(Map<String, NormalizedSignalData> normalizedSignals, SignalInfo signalInfo) {
        NormalizedSignalData normalizedSignalData = normalizedSignals.getOrDefault(signalInfo.getKey(), null);
        boolean signalPresent = Objects.nonNull(normalizedSignalData);
        return new Tuple2<>(signalPresent, getBooleanValue(normalizedSignalData));
    }

    private Double getDoubleValue(NormalizedSignalData normalizedSignalData) {
        if(Objects.isNull(normalizedSignalData)) return null;
        return (double) normalizedSignalData.getValue();
    }

    private Boolean getBooleanValue(NormalizedSignalData normalizedSignalData) {
        if(Objects.isNull(normalizedSignalData)) return false;
        return (Boolean) normalizedSignalData.getValue();
    }

    private Integer getIntegerValue(NormalizedSignalData normalizedSignalData) {
        if(Objects.isNull(normalizedSignalData)) return null;
        return normalizedSignalData.getValue() instanceof Double
                ? ((Double) normalizedSignalData.getValue()).intValue()
                : (int) normalizedSignalData.getValue();
    }

}
