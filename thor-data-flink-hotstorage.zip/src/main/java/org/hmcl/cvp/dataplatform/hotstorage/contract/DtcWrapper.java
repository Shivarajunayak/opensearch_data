package org.hmcl.cvp.dataplatform.hotstorage.contract;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class DtcWrapper implements Serializable {

    private DtcInfo dtcInfo;

    private Long time;
}
