package org.hmcl.cvp.dataplatform.hotstorage.contract;

import com.google.gson.annotations.SerializedName;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class ChargingAnalytics implements Serializable {

    @SerializedName("vid")
    private String vid;

    @SerializedName("tenantId")
    private String tenantId;

    @SerializedName("campaignName")
    private String campaignName;

    @SerializedName("collectionEventTime")
    private Long collectionEventTime;

    @SerializedName("collectionEventTimeTsp")
    private String collectionEventTimeTsp;

    @SerializedName("eventId")
    private String eventId;

    @SerializedName("systemTime")
    private Long systemTime;

    @SerializedName("systemTimeTsp")
    private String systemTimeTsp;

    // Signals

    @SerializedName("altitude")
    private Double altitude;

    @SerializedName("ambientTemperature")
    private Integer ambientTemperature;

    @SerializedName("avgEnergyConsumption")
    private Integer avgEnergyConsumption;

    @SerializedName("batteryChargingStatus")
    private String batteryChargingStatus;

    @SerializedName("batteryDetection")
    private Integer batteryDetection;

    @SerializedName("batteryOperationMode")
    private Integer batteryOperationMode;

    @SerializedName("batteryPackTemperature")
    private Double batteryPackTemperature;

    @SerializedName("batterySlotIdentityFront")
    private Integer batterySlotIdentityFront;

    @SerializedName("batterySlotIdentityRear")
    private Integer batterySlotIdentityRear;

    @SerializedName("bleConnectivity")
    private Boolean bleConnectivity;

    @SerializedName("bmsBduStatus")
    private Integer bmsBduStatus;

    @SerializedName("bmsBduConnectionRequest")
    private Integer bmsBduConnectionRequest;

    @SerializedName("bmsChargeStartRequest")
    private Integer bmsChargeStartRequest;

    @SerializedName("bmsStatus")
    private Integer bmsStatus;

    @SerializedName("bms1BatteryPackTemperature")
    private Double bms1BatteryPackTemperature;

    @SerializedName("bms1SocUserPercentage")
    private Double bms1SocUserPercentage;

    @SerializedName("bms1SohPercentage")
    private Double bms1SohPercentage;

    @SerializedName("bms2BatteryOperationMode")
    private Integer bms2BatteryOperationMode;

    @SerializedName("bms2BatteryPackTemperature")
    private Double bms2BatteryPackTemperature;

    @SerializedName("bms2SocUserPercentage")
    private Double bms2SocUserPercentage;

    @SerializedName("bms2SohPercentage")
    private Double bms2SohPercentage;

    @SerializedName("brakeStatus")
    private Integer brakeStatus;

    @SerializedName("chargeCurrentSet")
    private Double chargeCurrentSet;

    @SerializedName("chargerIdentity")
    private Integer chargerIdentity;

    @SerializedName("chargerPowerState")
    private Integer chargerPowerState;

    @SerializedName("chargerState")
    private Integer chargerState;

    @SerializedName("chargerStateDesc")
    private String chargerStateDesc;

    @SerializedName("chargerStatus")
    private Boolean chargerStatus;

    @SerializedName("chargerIdentityDesc")
    private String chargerIdentityDesc;

    @SerializedName("chargerVoltageSet")
    private Double chargerVoltageSet;

    @SerializedName("chargerOutputVoltage")
    private Double chargerOutputVoltage;

    @SerializedName("chargerOutputCurrent")
    private Double chargerOutputCurrent;

    @SerializedName("cog")
    private Double cog;

    @SerializedName("cutOffCurrent")
    private Double cutOffCurrent;

    @SerializedName("estimatedChargingTime")
    private Integer estimatedChargingTime;

    @SerializedName("gpsFix")
    private Integer gpsFix;

    @SerializedName("gpsSpeed")
    private Double gpsSpeed;

    @SerializedName("gpsValid")
    private Boolean gpsValid;

    @SerializedName("hdop")
    private Double hDop;

    @SerializedName("latitude")
    private Double latitude;

    @SerializedName("longitude")
    private Double longitude;

    @SerializedName("motorStatus")
    private Integer motorStatus;

    @SerializedName("odoVcu")
    private Integer odoVcu;

    @SerializedName("packCurrent")
    private Double packCurrent;

    @SerializedName("packVoltage")
    private Double packVoltage;

    @SerializedName("pdop")
    private Double pDop;

    @SerializedName("preChargeCurrent")
    private Double preChargeCurrent;

    @SerializedName("remainingCapacity")
    private Integer remainingCapacity;

    @SerializedName("remainingRange")
    private Integer remainingRange;

    @SerializedName("satelliteInUse")
    private Integer satelliteInUse;

    @SerializedName("satelliteInView")
    private Integer satelliteInView;

    @SerializedName("soc")
    private Double soc;

    @SerializedName("soh")
    private Double soh;

    @SerializedName("temperatureStatusVcu")
    private Boolean temperatureStatusVcu;

    @SerializedName("thermalRunStatusAggregate")
    private Integer thermalRunStatusAggregate;

    @SerializedName("thermalRunawayWarning")
    private Integer thermalRunawayWarning;

    @SerializedName("totalUsableCapacity")
    private Integer totalUsableCapacity;

    @SerializedName("totalUsableEnergy")
    private Integer totalUsableEnergy;

    @SerializedName("totalUsableEnergyBms1")
    private Integer totalUsableEnergyBms1;

    @SerializedName("totalUsableEnergyBms2")
    private Integer totalUsableEnergyBms2;

    @SerializedName("userId")
    private String userId;

    @SerializedName("userProfile")
    private Long userProfile;

    @SerializedName("vehicleModeSignal")
    private Integer vehicleModeSignal;

    @SerializedName("vdop")
    private Double vDop;

    @SerializedName("chargingSessionId")
    private String chargingSessionId;

    @SerializedName("startTimestamp")
    private Long startTimestamp;

    @SerializedName("endTimestamp")
    private Long endTimestamp;

}
