package org.hmcl.cvp.dataplatform.hotstorage.operator;

import lombok.extern.slf4j.Slf4j;
import org.apache.flink.api.common.functions.RichFlatMapFunction;
import org.apache.flink.api.java.utils.ParameterTool;
import org.apache.flink.configuration.Configuration;
import org.apache.flink.metrics.Counter;
import org.apache.flink.util.Collector;
import org.hmcl.cvp.dataplatform.commons.catalogue.SignalCatalogue;
import org.hmcl.cvp.dataplatform.commons.constants.Constants;
import org.hmcl.cvp.dataplatform.commons.constants.FlinkRuntime;
import org.hmcl.cvp.dataplatform.commons.utils.DateUtils;
import org.hmcl.cvp.dataplatform.commons.utils.SignalUtils;
import org.hmcl.cvp.dataplatform.commons.utils.TelemetryUtils;
import org.hmcl.cvp.dataplatform.contract.telemetry.SignalData;
import org.hmcl.cvp.dataplatform.contract.telemetry.SignalInfo;
import org.hmcl.cvp.dataplatform.contract.telemetry.Telemetry;
import org.hmcl.cvp.dataplatform.contract.telemetry.Tenant;
import org.hmcl.cvp.dataplatform.hotstorage.contract.MasterTelemetry;
import org.hmcl.cvp.dataplatform.hotstorage.contract.OpenSearchDocument;
import org.opensearch.action.DocWriteRequest;

import java.util.Map;
import java.util.Objects;
import java.util.Set;

@Slf4j
public class MasterTelemetryMapperFunction extends RichFlatMapFunction<Telemetry, OpenSearchDocument> {

    private transient Counter numSuccessEventCounter;
    private transient Counter numErrorEventCounter;
    private transient Counter numEvTenantCounter;
    private transient Counter numIceTenantCounter;
    private transient Counter numHarleyTenantCounter;

    private transient String evIndex;
    private transient String iceIndex;
    private transient String harleyIndex;

    private Counter counterInitializer(String counterName) {
        return getRuntimeContext()
                .getMetricGroup()
                .addGroup(Constants.METRIC_GROUP_NAME)
                .addGroup(Constants.METRIC_SUB_GROUP_KEY, "MasterTelemetry")
                .counter(counterName);
    }

    @Override
    public void open(Configuration parameters) throws Exception {
        super.open(parameters);
        numSuccessEventCounter = counterInitializer("numSuccessEvents");
        numErrorEventCounter = counterInitializer("numErrorEvents");
        numEvTenantCounter = counterInitializer("numEvEvents");
        numIceTenantCounter = counterInitializer("numIceEvents");
        numHarleyTenantCounter = counterInitializer("numHarleyEvents");

        ParameterTool parameterTool = (ParameterTool) getRuntimeContext().getExecutionConfig().getGlobalJobParameters();

        evIndex = parameterTool.getRequired(FlinkRuntime.HotStorage.EV_MASTER_TELEMETRY_INDEX);
        iceIndex = parameterTool.getRequired(FlinkRuntime.HotStorage.ICE_MASTER_TELEMETRY_INDEX);
        harleyIndex = parameterTool.getRequired(FlinkRuntime.HotStorage.HARLEY_MASTER_TELEMETRY_INDEX);
    }

    @Override
    public void flatMap(Telemetry value, Collector<OpenSearchDocument> out) {
        String vid = TelemetryUtils.getVirtualId(value);

        try {
            Tenant tenant = TelemetryUtils.getTenant(value);
            String openSearchIndex = getOpenSearchIndex(tenant);
            MasterTelemetry masterTelemetry = getMasterTelemetry(vid, value);

            if(Objects.isNull(masterTelemetry)) {
                numErrorEventCounter.inc();
                log.debug("Telemetry event does not have signals");
                return;
            }

            OpenSearchDocument openSearchDocument = OpenSearchDocument.builder()
                    .index(openSearchIndex)
                    .opType(DocWriteRequest.OpType.CREATE)
                    .vid(vid)
                    .isTelemetry(true)
                    .masterTelemetry(masterTelemetry)
                    .build();

            out.collect(openSearchDocument);
            numSuccessEventCounter.inc();

        } catch (Exception e) {
            log.error("Error while mapping telemetry to master telemetry for vid {}", vid, e);
            numErrorEventCounter.inc();
        }
    }

    private String getOpenSearchIndex(Tenant tenant) {

        switch (tenant) {
            case EV:
                numEvTenantCounter.inc();
                return evIndex;
            case HARLEY:
                numHarleyTenantCounter.inc();
                return harleyIndex;
            case ICE:
                numIceTenantCounter.inc();
                return iceIndex;
            default:
                numErrorEventCounter.inc();
                throw new IllegalArgumentException("Unsupported tenant type: " + tenant);
        }
    }

    private MasterTelemetry getMasterTelemetry( String vid, Telemetry value) {
        Map<String, Set<SignalData>> telemetrySignals = value.getSignals();
        if(telemetrySignals.isEmpty()) return null;

        long currentTime = DateUtils.currentEpochTime();
        String currentTimeTs = DateUtils.formatToISO(currentTime);

        long latencyInMs = currentTime - value.getCollectionEventTime();

        return MasterTelemetry.builder()
                // String values
                .vid(vid)
                .tenantId(TelemetryUtils.getTenantId(value))
                .b2bClientId(TelemetryUtils.getB2BClientId(value))
                .campaignName(value.getCampaignName())
                .collectionEventTime(value.getCollectionEventTime())
                .collectionEventTimeTS(DateUtils.formatToISO(value.getCollectionEventTime()))
                .eventId(String.valueOf(value.getEventId()))
                // Set<SignalData>
                // A
                .absFrontWheelPressurePlus(getSignals(telemetrySignals, SignalCatalogue.getABSFrontWheelPressureStatusInfo()))
                .absTelltaleStatus(getSignals(telemetrySignals, SignalCatalogue.getABSTelltaleStatusInfo()))
                .altitude(getSignals(telemetrySignals, SignalCatalogue.getAltitudeInfo()))
                .ambientTemperature(getSignals(telemetrySignals, SignalCatalogue.getAmbientTemperatureInfo()))
                .avgEnergyConsumption(getSignals(telemetrySignals, SignalCatalogue.getAvgEnergyConsumptionInfo()))
                .apn(getSignals(telemetrySignals, SignalCatalogue.getApnInfo()))
                //B
                .batteryDetection(getSignals(telemetrySignals, SignalCatalogue.getBatteryDetectionInfo()))
                .batteryOperationMode(getSignals(telemetrySignals, SignalCatalogue.getBatteryOperationModeInfo()))
                .batteryOperationModeBms2(getSignals(telemetrySignals, SignalCatalogue.getBMS2BatteryOperationModeInfo()))
                .batteryPackTemperature(getSignals(telemetrySignals, SignalCatalogue.getBatteryPackTemperatureInfo()))
                .batterySlotIdentityFront(getSignals(telemetrySignals, SignalCatalogue.getBatterySlotIdentityFrontInfo()))
                .batterySlotIdentityRear(getSignals(telemetrySignals, SignalCatalogue.getBatterySlotIdentityRearInfo()))
                .bleConnectivity(getSignals(telemetrySignals, SignalCatalogue.getBLEConnectivityInfo()))
                .bmsBduStatus(getSignals(telemetrySignals, SignalCatalogue.getBMSBDUStatusInfo()))
                .bmsBduConnectionRequest(getSignals(telemetrySignals, SignalCatalogue.getBMSBDUConnectionRequestInfo()))
                .bmsStatus(getSignals(telemetrySignals, SignalCatalogue.getBMSStatusInfo()))
                .bms1BatteryPackTemperature(getSignals(telemetrySignals, SignalCatalogue.getBMS1BatteryPackTempInfo()))
                .bms2BatteryPackTemperature(getSignals(telemetrySignals, SignalCatalogue.getBMS2BatteryPackTempInfo()))
                .boostModeStatus(getSignals(telemetrySignals, SignalCatalogue.getBoostModeStatusInfo()))
                .brakeInputSignal(getSignals(telemetrySignals, SignalCatalogue.getBrakeStatusInfo()))
                .bleKey(getSignals(telemetrySignals, SignalCatalogue.getBleKeyInfo()))
                // C
                .chargerIdentity(getSignals(telemetrySignals, SignalCatalogue.getChargerIdentityInfo()))
                .chargerPowerLineState(getSignals(telemetrySignals, SignalCatalogue.getChargerPowerStateInfo()))
                .cog(getSignals(telemetrySignals, SignalCatalogue.getCogInfo()))
                // D
                .distanceAccumulation(getSignals(telemetrySignals, SignalCatalogue.getDistanceAccumulationInfo()))
                .distanceTravelledWithMil(getSignals(telemetrySignals, SignalCatalogue.getDistanceTravelledWithMilInfo()))
                .driveModeSignal(getSignals(telemetrySignals, SignalCatalogue.getDrivingModeInfo()))
                .dtcInfo(getSignals(telemetrySignals, SignalCatalogue.getDTCInfo()))
                .dtcInfoInActive(getSignals(telemetrySignals, SignalCatalogue.getDTCInfoInActiveInfo()))
                // E
                .engineSpeed(getSignals(telemetrySignals, SignalCatalogue.getEngineSpeedInfo()))
                .engineTemperature(getSignals(telemetrySignals, SignalCatalogue.getEngineTemperatureInfo()))
                .eolXmlId(getSignals(telemetrySignals, SignalCatalogue.getEolXmlIdInfo()))
                // F
                .fuelLevel(getSignals(telemetrySignals, SignalCatalogue.getFuelLevelInfo()))
                .fuelLevelIndication(getSignals(telemetrySignals, SignalCatalogue.getFuelLevelIndicationInfo()))
                .frWss(getSignals(telemetrySignals, SignalCatalogue.getFrontWheelSpeedInfo()))
                .frWssPlus(getSignals(telemetrySignals, SignalCatalogue.getFrontWheelSpeedStatusInfo()))
                // G
                .gearPositionSensor(getSignals(telemetrySignals, SignalCatalogue.getGearPositionSensorInfo()))
                .gpsFix(getSignals(telemetrySignals, SignalCatalogue.getGpsFixInfo()))
                .gpsSpeed(getSignals(telemetrySignals, SignalCatalogue.getGpsSpeedInfo()))
                .gpsValid(getSignals(telemetrySignals, SignalCatalogue.getGpsValidInfo()))
                // H
                .harshDrivingAlert(getSignals(telemetrySignals, SignalCatalogue.getHarshDrivingAlertInfo()))
                .hDop(getSignals(telemetrySignals, SignalCatalogue.getHDopInfo()))
                // I
                .intBatChargePercent(getSignals(telemetrySignals, SignalCatalogue.getInternalBatteryChargePercentageInfo()))
                .intBatChargeVoltage(getSignals(telemetrySignals, SignalCatalogue.getInternalBatteryChargeVoltageInfo()))
                .immobSignalAck(getSignals(telemetrySignals, SignalCatalogue.getImmobSignalAckInfo()))
                .idBMS1(getSignals(telemetrySignals, SignalCatalogue.getBMS1Id()))
                .idBMS2(getSignals(telemetrySignals, SignalCatalogue.getBMS2Id()))
                // L
                .latitude(getSignals(telemetrySignals, SignalCatalogue.getLatitudeInfo()))
                .longitude(getSignals(telemetrySignals, SignalCatalogue.getLongitudeInfo()))
                .latencyMs(latencyInMs)
                // M
                .mainVoltage(getSignals(telemetrySignals, SignalCatalogue.getTcuMainVoltageInfo()))
                .mileageTrip(getSignals(telemetrySignals, SignalCatalogue.getTripMileageInfo()))
                .motorSpeed(getSignals(telemetrySignals, SignalCatalogue.getMotorSpeedInfo()))
                .motorStatus(getSignals(telemetrySignals, SignalCatalogue.getMotorStatusInfo()))
                // O
                .odoSignalHr(getSignals(telemetrySignals, SignalCatalogue.getOdometerHRInfo()))
                // P
                .packCurrent(getSignals(telemetrySignals, SignalCatalogue.getPackCurrentInfo()))
                .packVoltage(getSignals(telemetrySignals, SignalCatalogue.getPackVoltageInfo()))
                .pDop(getSignals(telemetrySignals, SignalCatalogue.getPDopInfo()))
                // R
                .remainingCapacity(getSignals(telemetrySignals, SignalCatalogue.getRemainingCapacityInfo()))
                .remainingRangeInKm(getSignals(telemetrySignals, SignalCatalogue.getRemainingRangeInfo()))
                .riderInfoUserid(getSignals(telemetrySignals, SignalCatalogue.getUserIdInfo()))
                .riderInfoUsertype(getSignals(telemetrySignals, SignalCatalogue.getUserProfileInfo()))
                .rrWss(getSignals(telemetrySignals, SignalCatalogue.getRearWheelSpeedInfo()))
                .rrWssPlus(getSignals(telemetrySignals, SignalCatalogue.getRearWheelSpeedStatusInfo()))
                .recordTimestamp(currentTime)
                .recordTimestampTs(currentTimeTs)
                // S
                .satelliteInUse(getSignals(telemetrySignals, SignalCatalogue.getSatelliteInUseInfo()))
                .satelliteInView(getSignals(telemetrySignals, SignalCatalogue.getSatelliteInViewInfo()))
                .socUser(getSignals(telemetrySignals, SignalCatalogue.getSocUserPercentageInfo()))
                .socUserBms1(getSignals(telemetrySignals, SignalCatalogue.getSocUserBMS1Info()))
                .socUserBms2(getSignals(telemetrySignals, SignalCatalogue.getSocUserBMS2Info()))
                .soe(getSignals(telemetrySignals, SignalCatalogue.getSoeInfo()))
                .soh(getSignals(telemetrySignals, SignalCatalogue.getSohInfo()))
                .sohBms1(getSignals(telemetrySignals, SignalCatalogue.getBMS1SohPercentage()))
                .sohBms2(getSignals(telemetrySignals, SignalCatalogue.getBMS2SohPercentage()))
                .speedLimitSignal(getSignals(telemetrySignals, SignalCatalogue.getUserSpeedLimitInfo()))
                .statusAbs(getSignals(telemetrySignals, SignalCatalogue.getABSStatusInfo()))
                // T
                .tcuIgnition(getSignals(telemetrySignals, SignalCatalogue.getTcuIgnitionInfo()))
                .tempStatus(getSignals(telemetrySignals, SignalCatalogue.getTemperatureStatusVCUInfo()))
                .thermalRunCommand(getSignals(telemetrySignals, SignalCatalogue.getThermalRunawayWarningInfo()))
                .thermalRunStatusAggregate(getSignals(telemetrySignals, SignalCatalogue.getThermalRunStatusAggregateInfo()))
                .throttle(getSignals(telemetrySignals, SignalCatalogue.getThrottlePercentageInfo()))
                .throttleGripSensor(getSignals(telemetrySignals, SignalCatalogue.getThrottleGripPercentageInfo()))
                .throttlePositionSensor(getSignals(telemetrySignals, SignalCatalogue.getThrottlePositionInfo()))
                .totalUsableCapacity(getSignals(telemetrySignals, SignalCatalogue.getTotalUsableCapacityInfo()))
                .totalUsableEnergy(getSignals(telemetrySignals, SignalCatalogue.getTotalUsableEnergyInfo()))
                .totalUsableEnergyBms1(getSignals(telemetrySignals, SignalCatalogue.getTotalUsableEnergyBMS1Info()))
                .totalUsableEnergyBms2(getSignals(telemetrySignals, SignalCatalogue.getTotalUsableEnergyBMS2Info()))
                .tripStartSignal(getSignals(telemetrySignals, SignalCatalogue.getTripStartFlag()))
                .tripEndSignal(getSignals(telemetrySignals, SignalCatalogue.getTripEndFlag()))
                .tcuSwVersionMajor(getSignals(telemetrySignals, SignalCatalogue.getTcuSwMajorVersionInfo()))
                // U
                .userId(getSignals(telemetrySignals, SignalCatalogue.getUserIdInfo()))
                .userType(getSignals(telemetrySignals, SignalCatalogue.getUserProfileInfo()))
                // V
                .vDop(getSignals(telemetrySignals, SignalCatalogue.getVDopInfo()))
                .vehicleSpeed(getSignals(telemetrySignals, SignalCatalogue.getVehicleSpeedInfo()))
                .vehicleSpeedDisplay(getSignals(telemetrySignals, SignalCatalogue.getVehicleSpeedDisplayInfo()))
                .vehicleSpeedHighRes(getSignals(telemetrySignals, SignalCatalogue.getVehicleSpeedHighResInfo()))
                .vehicleSpeedHighRes1(getSignals(telemetrySignals, SignalCatalogue.getVehicleSpeedHighRes1Info()))
                .build();
    }

    private Set<SignalData> getSignals(Map<String, Set<SignalData>> telemetrySignals, SignalInfo signalInfo) {
        return SignalUtils.getSignals(telemetrySignals, signalInfo);
    }

}
