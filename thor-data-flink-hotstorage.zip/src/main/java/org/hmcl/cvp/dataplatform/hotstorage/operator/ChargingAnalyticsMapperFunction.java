package org.hmcl.cvp.dataplatform.hotstorage.operator;

import com.google.gson.Gson;
import lombok.extern.slf4j.Slf4j;
import org.apache.flink.api.common.functions.RichFlatMapFunction;
import org.apache.flink.api.java.tuple.Tuple2;
import org.apache.flink.api.java.utils.ParameterTool;
import org.apache.flink.configuration.Configuration;
import org.apache.flink.metrics.Counter;
import org.apache.flink.util.Collector;
import org.hmcl.cvp.dataplatform.commons.catalogue.SignalCatalogue;
import org.hmcl.cvp.dataplatform.commons.constants.Constants;
import org.hmcl.cvp.dataplatform.commons.constants.FlinkRuntime;
import org.hmcl.cvp.dataplatform.commons.utils.DateUtils;
import org.hmcl.cvp.dataplatform.commons.utils.GsonUtils;
import org.hmcl.cvp.dataplatform.commons.utils.SignalUtils;
import org.hmcl.cvp.dataplatform.commons.utils.TelemetryUtils;
import org.hmcl.cvp.dataplatform.contract.telemetry.SignalData;
import org.hmcl.cvp.dataplatform.contract.telemetry.SignalInfo;
import org.hmcl.cvp.dataplatform.contract.telemetry.Telemetry;
import org.hmcl.cvp.dataplatform.hotstorage.contract.ChargingAnalytics;
import org.hmcl.cvp.dataplatform.hotstorage.contract.ChargingSession;
import org.hmcl.cvp.dataplatform.hotstorage.contract.OpenSearchDocument;
import org.opensearch.action.DocWriteRequest;

import java.time.Instant;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.Set;

import static org.hmcl.cvp.dataplatform.commons.utils.SignalUtils.getLatestSignal;

@Slf4j
public class ChargingAnalyticsMapperFunction extends RichFlatMapFunction<Telemetry, OpenSearchDocument> {

    private static final Gson GSON = GsonUtils.getGson();

    private transient Counter numSuccessEventCounter;
    private transient Counter numErrorEventCounter;

    private transient String evIndex;

    private Counter counterInitializer(String counterName) {
        return getRuntimeContext()
                .getMetricGroup()
                .addGroup(Constants.METRIC_GROUP_NAME)
                .addGroup(Constants.METRIC_SUB_GROUP_KEY, "ChargingAnalytics")
                .counter(counterName);
    }

    @Override
    public void open(Configuration parameters) throws Exception {
        super.open(parameters);
        numSuccessEventCounter = counterInitializer("numSuccessEvents");
        numErrorEventCounter = counterInitializer("numErrorEvents");

        ParameterTool parameterTool = (ParameterTool) getRuntimeContext().getExecutionConfig().getGlobalJobParameters();

        evIndex = parameterTool.getRequired(FlinkRuntime.HotStorage.EV_CHARGING_INDEX);
    }

    @Override
    public void flatMap(Telemetry value, Collector<OpenSearchDocument> out) {
        String vid = TelemetryUtils.getVirtualId(value);

        try {
            ChargingAnalytics chargingAnalytics = getChargingAnalytics(vid, value);

            if(Objects.isNull(chargingAnalytics)) {
                numErrorEventCounter.inc();
                log.debug("Telemetry event does not have signals");
                return;
            }

            OpenSearchDocument openSearchDocument = OpenSearchDocument.builder()
                    .index(evIndex)
                    .vid(vid)
                    .opType(DocWriteRequest.OpType.INDEX)
                    .isChargingScreen(true)
                    .chargingAnalytics(chargingAnalytics)
                    .build();

            out.collect(openSearchDocument);
            numSuccessEventCounter.inc();

        } catch (Exception e) {
            log.error("Error while mapping telemetry to charging analytics for vid {}", vid, e);
            numErrorEventCounter.inc();
        }
    }

    private ChargingAnalytics getChargingAnalytics(String vid, Telemetry telemetry) {
        Map<String, Set<SignalData>> telemetrySignals = telemetry.getSignals();
        if(telemetrySignals.isEmpty()) return null;

        long systemTime = Instant.now().toEpochMilli();

        ChargingAnalytics chargingAnalytics = ChargingAnalytics.builder()
                .vid(vid)
                .tenantId(TelemetryUtils.getTenantId(telemetry))
                .campaignName(telemetry.getCampaignName())
                .collectionEventTime(telemetry.getCollectionEventTime())
                .collectionEventTimeTsp(DateUtils.formatToISO(telemetry.getCollectionEventTime()))
                .eventId(String.valueOf(telemetry.getEventId()))
                .systemTime(systemTime)
                .systemTimeTsp(DateUtils.formatToISO(systemTime))
                .build();

        chargingAnalytics.setBatteryChargingStatus(getBatteryChargingStatus(telemetrySignals));

        populateCommonSignals(chargingAnalytics, telemetrySignals);

        populateBatterySignals(chargingAnalytics, telemetrySignals);

        populateBmsSignals(chargingAnalytics, telemetrySignals);

        populateChargerSignals(chargingAnalytics, telemetrySignals);

        populateOtherSignals(chargingAnalytics, telemetrySignals);

        populateChargingSessionSignals(chargingAnalytics, telemetrySignals);

        // don't write charging data packet to charging-screen index 
        if (chargingAnalytics.getChargingSessionId() == null || chargingAnalytics.getChargingSessionId().isEmpty()) {
            return null;
        }

        Tuple2<Boolean, Boolean> temperatureStatusVcu = getLatestBooleanValue(SignalCatalogue.getTemperatureStatusVCUInfo(), telemetrySignals);
        if(Boolean.TRUE.equals(temperatureStatusVcu.f0)) chargingAnalytics.setTemperatureStatusVcu(temperatureStatusVcu.f1);

        Tuple2<Boolean, Integer> thermalRunStatusAggregate = getLatestIntegerValue(SignalCatalogue.getThermalRunStatusAggregateInfo(), telemetrySignals);
        if(Boolean.TRUE.equals(thermalRunStatusAggregate.f0)) chargingAnalytics.setThermalRunStatusAggregate(thermalRunStatusAggregate.f1);

        Tuple2<Boolean, Integer> thermalRunawayWarning = getLatestIntegerValue(SignalCatalogue.getThermalRunawayWarningInfo(), telemetrySignals);
        if(Boolean.TRUE.equals(thermalRunawayWarning.f0)) chargingAnalytics.setThermalRunawayWarning(thermalRunawayWarning.f1);

        Tuple2<Boolean, Integer> totalUsableCapacity = getLatestIntegerValue(SignalCatalogue.getTotalUsableCapacityInfo(), telemetrySignals);
        if(Boolean.TRUE.equals(totalUsableCapacity.f0)) chargingAnalytics.setTotalUsableCapacity(totalUsableCapacity.f1);

        Tuple2<Boolean, Integer> totalUsableEnergy = getLatestIntegerValue(SignalCatalogue.getTotalUsableEnergyInfo(), telemetrySignals);
        if(Boolean.TRUE.equals(thermalRunawayWarning.f0)) chargingAnalytics.setTotalUsableEnergy(totalUsableEnergy.f1);

        Tuple2<Boolean, Integer> totalUsableEnergyBms1 = getLatestIntegerValue(SignalCatalogue.getTotalUsableEnergyBMS1Info(), telemetrySignals);
        if(Boolean.TRUE.equals(totalUsableEnergyBms1.f0)) chargingAnalytics.setTotalUsableEnergyBms1(totalUsableEnergyBms1.f1);

        Tuple2<Boolean, Integer> totalUsableEnergyBms2 = getLatestIntegerValue(SignalCatalogue.getTotalUsableEnergyBMS2Info(), telemetrySignals);
        if(Boolean.TRUE.equals(totalUsableEnergyBms2.f0)) chargingAnalytics.setTotalUsableEnergyBms2(totalUsableEnergyBms2.f1);

        return chargingAnalytics;
    }

    private void populateCommonSignals(ChargingAnalytics chargingAnalytics, Map<String, Set<SignalData>> telemetrySignals) {
        Tuple2<Boolean, Double> altitude = getLatestDoubleValue(SignalCatalogue.getAltitudeInfo(), telemetrySignals);
        if(Boolean.TRUE.equals(altitude.f0)) chargingAnalytics.setAltitude(altitude.f1);

        Tuple2<Boolean, Boolean> bleConnectivity = getLatestBooleanValue(SignalCatalogue.getBLEConnectivityInfo(), telemetrySignals);
        if(Boolean.TRUE.equals(bleConnectivity.f0)) chargingAnalytics.setBleConnectivity(bleConnectivity.f1);

        Tuple2<Boolean, Double> cog = getLatestDoubleValue(SignalCatalogue.getCogInfo(), telemetrySignals);
        if(Boolean.TRUE.equals(cog.f0)) chargingAnalytics.setCog(cog.f1);

        Tuple2<Boolean, Integer> gpsFix = getLatestIntegerValue(SignalCatalogue.getGpsFixInfo(), telemetrySignals);
        if(Boolean.TRUE.equals(gpsFix.f0)) chargingAnalytics.setGpsFix(gpsFix.f1);

        Tuple2<Boolean, Double> gpsSpeed = getLatestDoubleValue(SignalCatalogue.getGpsSpeedInfo(), telemetrySignals);
        if(Boolean.TRUE.equals(gpsSpeed.f0)) chargingAnalytics.setGpsSpeed(gpsSpeed.f1);

        Tuple2<Boolean, Boolean> gpsValid = getLatestBooleanValue(SignalCatalogue.getGpsValidInfo(), telemetrySignals);
        if(Boolean.TRUE.equals(gpsValid.f0)) chargingAnalytics.setGpsValid(gpsValid.f1);

        Tuple2<Boolean, Double> hDop = getLatestDoubleValue(SignalCatalogue.getHDopInfo(), telemetrySignals);
        if(Boolean.TRUE.equals(hDop.f0)) chargingAnalytics.setHDop(hDop.f1);

        Tuple2<Boolean, Double> latitude = getLatestDoubleValue(SignalCatalogue.getLatitudeInfo(), telemetrySignals);
        if(Boolean.TRUE.equals(latitude.f0)) chargingAnalytics.setLatitude(latitude.f1);

        Tuple2<Boolean, Double> longitude = getLatestDoubleValue(SignalCatalogue.getLongitudeInfo(), telemetrySignals);
        if(Boolean.TRUE.equals(longitude.f0)) chargingAnalytics.setLongitude(longitude.f1);

        Tuple2<Boolean, Double> pDop = getLatestDoubleValue(SignalCatalogue.getPDopInfo(), telemetrySignals);
        if(Boolean.TRUE.equals(pDop.f0)) chargingAnalytics.setPDop(pDop.f1);

        Tuple2<Boolean, Integer> satelliteInUse = getLatestIntegerValue(SignalCatalogue.getSatelliteInUseInfo(), telemetrySignals);
        if(Boolean.TRUE.equals(satelliteInUse.f0)) chargingAnalytics.setSatelliteInUse(satelliteInUse.f1);

        Tuple2<Boolean, Integer> satelliteInView = getLatestIntegerValue(SignalCatalogue.getSatelliteInViewInfo(), telemetrySignals);
        if(Boolean.TRUE.equals(satelliteInView.f0)) chargingAnalytics.setSatelliteInView(satelliteInView.f1);

        Tuple2<Boolean, String> userId = getLatestStringValue(SignalCatalogue.getUserIdInfo(), telemetrySignals);
        if(Boolean.TRUE.equals(userId.f0)) chargingAnalytics.setUserId(userId.f1);

        Tuple2<Boolean, Long> userProfile = getLatestLongValue(SignalCatalogue.getUserProfileInfo(), telemetrySignals);
        if(Boolean.TRUE.equals(userProfile.f0)) chargingAnalytics.setUserProfile(userProfile.f1);

        Tuple2<Boolean, Double> vDop = getLatestDoubleValue(SignalCatalogue.getVDopInfo(), telemetrySignals);
        if(Boolean.TRUE.equals(vDop.f0)) chargingAnalytics.setVDop(vDop.f1);

    }

    private void populateBatterySignals(ChargingAnalytics chargingAnalytics, Map<String, Set<SignalData>> telemetrySignals) {
        Tuple2<Boolean, Integer> batteryDetection = getLatestIntegerValue(SignalCatalogue.getBatteryDetectionInfo(), telemetrySignals);
        if(Boolean.TRUE.equals(batteryDetection.f0)) chargingAnalytics.setBatteryDetection(batteryDetection.f1);

        Tuple2<Boolean, Integer> batteryOperationMode = getLatestIntegerValue(SignalCatalogue.getBatteryOperationModeInfo(), telemetrySignals);
        if(Boolean.TRUE.equals(batteryOperationMode.f0)) chargingAnalytics.setBatteryOperationMode(batteryOperationMode.f1);

        Tuple2<Boolean, Double> batteryPackTemperature = getLatestDoubleValue(SignalCatalogue.getBatteryPackTemperatureInfo(), telemetrySignals);
        if(Boolean.TRUE.equals(batteryPackTemperature.f0)) chargingAnalytics.setBatteryPackTemperature(batteryPackTemperature.f1);

        Tuple2<Boolean, Integer> batterySlotIdentityFront = getLatestIntegerValue(SignalCatalogue.getBatterySlotIdentityFrontInfo(), telemetrySignals);
        if(Boolean.TRUE.equals(batterySlotIdentityFront.f0)) chargingAnalytics.setBatterySlotIdentityFront(batterySlotIdentityFront.f1);

        Tuple2<Boolean, Integer> batterySlotIdentityRear = getLatestIntegerValue(SignalCatalogue.getBatterySlotIdentityRearInfo(), telemetrySignals);
        if(Boolean.TRUE.equals(batterySlotIdentityRear.f0)) chargingAnalytics.setBatterySlotIdentityRear(batterySlotIdentityRear.f1);
    }

    private void populateBmsSignals(ChargingAnalytics chargingAnalytics, Map<String, Set<SignalData>> telemetrySignals) {
        Tuple2<Boolean, Integer> bmsBduStatus = getLatestIntegerValue(SignalCatalogue.getBMSBDUStatusInfo(), telemetrySignals);
        if(Boolean.TRUE.equals(bmsBduStatus.f0)) chargingAnalytics.setBmsBduStatus(bmsBduStatus.f1);

        Tuple2<Boolean, Integer> bmsBduConnectionRequest = getLatestIntegerValue(SignalCatalogue.getBMSBDUConnectionRequestInfo(), telemetrySignals);
        if(Boolean.TRUE.equals(bmsBduConnectionRequest.f0)) chargingAnalytics.setBmsBduConnectionRequest(bmsBduConnectionRequest.f1);

        Tuple2<Boolean, Integer> bmsChargeStartRequest = getLatestIntegerValue(SignalCatalogue.getBMSChargeStartRequestInfo(), telemetrySignals);
        if(Boolean.TRUE.equals(bmsChargeStartRequest.f0)) chargingAnalytics.setBmsChargeStartRequest(bmsChargeStartRequest.f1);

        Tuple2<Boolean, Integer> bmsStatus = getLatestIntegerValue(SignalCatalogue.getBMSStatusInfo(), telemetrySignals);
        if(Boolean.TRUE.equals(bmsStatus.f0)) chargingAnalytics.setBmsStatus(bmsStatus.f1);

        Tuple2<Boolean, Double> bms1BatteryPackTemperature = getLatestDoubleValue(SignalCatalogue.getBMS1BatteryPackTempInfo(), telemetrySignals);
        if(Boolean.TRUE.equals(bms1BatteryPackTemperature.f0)) chargingAnalytics.setBms1BatteryPackTemperature(bms1BatteryPackTemperature.f1);

        Tuple2<Boolean, Double> bms2BatteryPackTemperature = getLatestDoubleValue(SignalCatalogue.getBMS2BatteryPackTempInfo(), telemetrySignals);
        if(Boolean.TRUE.equals(bms2BatteryPackTemperature.f0)) chargingAnalytics.setBms2BatteryPackTemperature(bms2BatteryPackTemperature.f1);

        Tuple2<Boolean, Double> bms1SocUserPercentage = getLatestDoubleValue(SignalCatalogue.getSocUserBMS1Info(), telemetrySignals);
        if(Boolean.TRUE.equals(bms1SocUserPercentage.f0)) chargingAnalytics.setBms1SocUserPercentage(bms1SocUserPercentage.f1);

        Tuple2<Boolean, Double> bms2SocUserPercentage = getLatestDoubleValue(SignalCatalogue.getSocUserBMS2Info(), telemetrySignals);
        if(Boolean.TRUE.equals(bms2SocUserPercentage.f0)) chargingAnalytics.setBms2SocUserPercentage(bms2SocUserPercentage.f1);

        Tuple2<Boolean, Double> bms1SohPercentage = getLatestDoubleValue(SignalCatalogue.getBMS1SohPercentage(), telemetrySignals);
        if(Boolean.TRUE.equals(bms1SohPercentage.f0)) chargingAnalytics.setBms1SohPercentage(bms1SohPercentage.f1);

        Tuple2<Boolean, Double> bms2SohPercentage = getLatestDoubleValue(SignalCatalogue.getBMS2SohPercentage(), telemetrySignals);
        if(Boolean.TRUE.equals(bms2SohPercentage.f0)) chargingAnalytics.setBms2SohPercentage(bms2SohPercentage.f1);

        Tuple2<Boolean, Integer> bms2BatteryOperationMode = getLatestIntegerValue(SignalCatalogue.getBMS2BatteryOperationModeInfo(), telemetrySignals);
        if(Boolean.TRUE.equals(bms2BatteryOperationMode.f0)) chargingAnalytics.setBms2BatteryOperationMode(bms2BatteryOperationMode.f1);

    }

    private void populateChargerSignals(ChargingAnalytics chargingAnalytics, Map<String, Set<SignalData>> telemetrySignals) {
        Tuple2<Boolean, Double> chargeCurrentSet = getLatestDoubleValue(SignalCatalogue.getChargeCurrentSetInfo(), telemetrySignals);
        if(Boolean.TRUE.equals(chargeCurrentSet.f0)) chargingAnalytics.setChargeCurrentSet(chargeCurrentSet.f1);

        Tuple2<Boolean, Integer> chargerIdentity = getLatestIntegerValue(SignalCatalogue.getChargerIdentityInfo(), telemetrySignals);
        if(Boolean.TRUE.equals(chargerIdentity.f0)) chargingAnalytics.setChargerIdentity(chargerIdentity.f1);

        Tuple2<Boolean, Integer> chargerPowerState = getLatestIntegerValue(SignalCatalogue.getChargerPowerStateInfo(), telemetrySignals);
        if(Boolean.TRUE.equals(chargerPowerState.f0)) chargingAnalytics.setChargerPowerState(chargerPowerState.f1);

        Tuple2<Boolean, Integer> chargerState = getLatestIntegerValue(SignalCatalogue.getChargerStateInfo(), telemetrySignals);
        if(Boolean.TRUE.equals(chargerState.f0)) chargingAnalytics.setChargerState(chargerState.f1);

        Tuple2<Boolean, String> chargerStateDesc = getChargerStateDesc(telemetrySignals);
        if(Boolean.TRUE.equals(chargerStateDesc.f0)) chargingAnalytics.setChargerStateDesc(chargerStateDesc.f1);

        Tuple2<Boolean, Boolean> chargerStatus = getLatestBooleanValue(SignalCatalogue.getChargerStatusInfo(), telemetrySignals);
        if(Boolean.TRUE.equals(chargerStatus.f0)) chargingAnalytics.setChargerStatus(chargerStatus.f1);

        Tuple2<Boolean, String> chargerIdentityDesc = getChargerIdentityDesc(telemetrySignals);
        if(Boolean.TRUE.equals(chargerIdentityDesc.f0)) chargingAnalytics.setChargerIdentityDesc(chargerIdentityDesc.f1);

        Tuple2<Boolean, Double> chargerVoltageSet = getLatestDoubleValue(SignalCatalogue.getChargerVoltageSetInfo(), telemetrySignals);
        if(Boolean.TRUE.equals(chargerVoltageSet.f0)) chargingAnalytics.setChargerVoltageSet(chargerVoltageSet.f1);

        Tuple2<Boolean, Double> chargerOutputVoltage = getLatestDoubleValue(SignalCatalogue.getChargerOutputVoltage(), telemetrySignals);
        if(Boolean.TRUE.equals(chargerOutputVoltage.f0)) chargingAnalytics.setChargerOutputVoltage(chargerOutputVoltage.f1);

        Tuple2<Boolean, Double> chargerOutputCurrent = getLatestDoubleValue(SignalCatalogue.getChargerOutputCurrent(), telemetrySignals);
        if(Boolean.TRUE.equals(chargerOutputCurrent.f0)) chargingAnalytics.setChargerOutputCurrent(chargerOutputCurrent.f1);

        Tuple2<Boolean, Double> preChargeCurrent = getLatestDoubleValue(SignalCatalogue.getPreChargeCurrentInfo(), telemetrySignals);
        if(Boolean.TRUE.equals(preChargeCurrent.f0)) chargingAnalytics.setPreChargeCurrent(preChargeCurrent.f1);
    }

    private void populateOtherSignals(ChargingAnalytics chargingAnalytics, Map<String, Set<SignalData>> telemetrySignals) {

        Tuple2<Boolean, Integer> averageEnergyConsumption = getLatestIntegerValue(SignalCatalogue.getAvgEnergyConsumptionInfo(), telemetrySignals);
        if(Boolean.TRUE.equals(averageEnergyConsumption.f0)) chargingAnalytics.setAvgEnergyConsumption(averageEnergyConsumption.f1);

        Tuple2<Boolean, Integer> brakeStatus = getLatestIntegerValue(SignalCatalogue.getBrakeStatusInfo(), telemetrySignals);
        if(Boolean.TRUE.equals(brakeStatus.f0)) chargingAnalytics.setBrakeStatus(brakeStatus.f1);

        Tuple2<Boolean, Double> cutOffCurrent = getLatestDoubleValue(SignalCatalogue.getCutOffCurrentInfo(), telemetrySignals);
        if(Boolean.TRUE.equals(cutOffCurrent.f0)) chargingAnalytics.setCutOffCurrent(cutOffCurrent.f1);

        Tuple2<Boolean, Integer> estimatedChargingTime = getLatestIntegerValue(SignalCatalogue.getEstimatedChargingTimeInfo(), telemetrySignals);
        if(Boolean.TRUE.equals(estimatedChargingTime.f0)) chargingAnalytics.setEstimatedChargingTime(estimatedChargingTime.f1);

        Tuple2<Boolean, Integer> motorStatus = getLatestIntegerValue(SignalCatalogue.getMotorStatusInfo(), telemetrySignals);
        if(Boolean.TRUE.equals(motorStatus.f0)) chargingAnalytics.setMotorStatus(motorStatus.f1);

        Tuple2<Boolean, Integer> odoVcu = getLatestIntegerValue(SignalCatalogue.getDistanceAccumulationInfo(), telemetrySignals);
        if(Boolean.TRUE.equals(odoVcu.f0)) chargingAnalytics.setOdoVcu(odoVcu.f1);

        Tuple2<Boolean, Double> packCurrent = getLatestDoubleValue(SignalCatalogue.getPackCurrentInfo(), telemetrySignals);
        if(Boolean.TRUE.equals(packCurrent.f0)) chargingAnalytics.setPackCurrent(packCurrent.f1);

        Tuple2<Boolean, Double> packVoltage = getLatestDoubleValue(SignalCatalogue.getPackVoltageInfo(), telemetrySignals);
        if(Boolean.TRUE.equals(packVoltage.f0)) chargingAnalytics.setPackVoltage(packVoltage.f1);

        Tuple2<Boolean, Integer> remainingCapacity = getLatestIntegerValue(SignalCatalogue.getRemainingCapacityInfo(), telemetrySignals);
        if(Boolean.TRUE.equals(remainingCapacity.f0)) chargingAnalytics.setRemainingCapacity(remainingCapacity.f1);

        Tuple2<Boolean, Integer> remainingRange = getLatestIntegerValue(SignalCatalogue.getRemainingRangeInfo(), telemetrySignals);
        if(Boolean.TRUE.equals(remainingRange.f0)) chargingAnalytics.setRemainingRange(remainingRange.f1);

        Tuple2<Boolean, Integer> satelliteInUse = getLatestIntegerValue(SignalCatalogue.getSatelliteInUseInfo(), telemetrySignals);
        if(Boolean.TRUE.equals(satelliteInUse.f0)) chargingAnalytics.setSatelliteInUse(satelliteInUse.f1);

        Tuple2<Boolean, Integer> satelliteInView = getLatestIntegerValue(SignalCatalogue.getSatelliteInViewInfo(), telemetrySignals);
        if(Boolean.TRUE.equals(satelliteInView.f0)) chargingAnalytics.setSatelliteInView(satelliteInView.f1);

        Tuple2<Boolean, Double> soc = getLatestDoubleValue(SignalCatalogue.getSocUserPercentageInfo(), telemetrySignals);
        if(Boolean.TRUE.equals(soc.f0)) chargingAnalytics.setSoc(soc.f1);

        Tuple2<Boolean, Double> soh = getLatestDoubleValue(SignalCatalogue.getSohInfo(), telemetrySignals);
        if(Boolean.TRUE.equals(soh.f0)) chargingAnalytics.setSoh(soh.f1);

    }

    private void populateChargingSessionSignals(ChargingAnalytics chargingAnalytics, Map<String, Set<SignalData>> telemetrySignals) {

        Tuple2<Boolean, ChargingSession> chargingSessionTuple = getLatestChargingSession(telemetrySignals);

        if(Boolean.TRUE.equals(chargingSessionTuple.f0)) {
            ChargingSession chargingSession = chargingSessionTuple.f1;
            String sessionId = chargingSession.getChargingSessionId();
            Long startTimestamp = chargingSession.getStartTimestamp();
            Long endTimestamp = chargingSession.getEndTimestamp();
            if(Objects.nonNull(sessionId)) chargingAnalytics.setChargingSessionId(chargingSession.getChargingSessionId());
            if(Objects.nonNull(startTimestamp)) chargingAnalytics.setStartTimestamp(startTimestamp);
            if(Objects.nonNull(endTimestamp)) chargingAnalytics.setEndTimestamp(endTimestamp);
        } else {
            log.info("Charging session_start or session_end not found in telemetry signals, inferring session ids from charging_session_id signal");
            Set<SignalData> chargingSessionIds = SignalUtils.getSignals(telemetrySignals, SignalCatalogue.getChargingSessionId());

            Optional<SignalData> latestChargingSessionId = chargingSessionIds.stream().max(Comparator.comparing(SignalData::getTime));
            if (latestChargingSessionId.isPresent()) {
                String sessionId = String.valueOf(latestChargingSessionId.get().getValue());
                if (Objects.isNull(sessionId) || sessionId.isEmpty()) {
                    log.info("Charging session id is not present charging Kafka input payload");
                } else {
                    chargingAnalytics.setChargingSessionId(sessionId);
                }
            }
        }
    }

    private Tuple2<Boolean, ChargingSession> getLatestChargingSession(Map<String, Set<SignalData>> telemetrySignals) {
        Set<SignalData> chargingStartSignals = SignalUtils.getSignals(telemetrySignals, SignalCatalogue.getChargingSessionStartInfo());
        Set<SignalData> chargingEndSignals = SignalUtils.getSignals(telemetrySignals, SignalCatalogue.getChargingSessionEndInfo());

        boolean isChargingStart = !chargingStartSignals.isEmpty();
        boolean isChargingEnd = !chargingEndSignals.isEmpty();

        List<SignalData> signalList = new ArrayList<>();
        if(isChargingStart) signalList.addAll(chargingStartSignals);
        if(isChargingEnd) signalList.addAll(chargingEndSignals);

        Optional<SignalData> latestData = signalList.stream().max(Comparator.comparing(SignalData::getTime));

        if(latestData.isEmpty()) return new Tuple2<>(false, null);

        String value = String.valueOf(latestData.get().getValue());
        if(Objects.isNull(value)) return new Tuple2<>(false, null);

        ChargingSession chargingSession = GSON.fromJson(value, ChargingSession.class);
        if(Objects.isNull(chargingSession)) return new Tuple2<>(false, null);

        return new Tuple2<>(true, chargingSession);

    }

    private Tuple2<Boolean, Integer> getLatestIntegerValue(SignalInfo signalInfo, Map<String, Set<SignalData>> telemetrySignals) {
        Set<SignalData> signals = SignalUtils.getSignals(telemetrySignals, signalInfo);
        return SignalUtils.getLatestIntegerValue(signals);
    }

    private Tuple2<Boolean, Double> getLatestDoubleValue(SignalInfo signalInfo, Map<String, Set<SignalData>> telemetrySignals) {
        Set<SignalData> signals = SignalUtils.getSignals(telemetrySignals, signalInfo);
        return SignalUtils.getLatestDoubleValue(signals);
    }

    private Tuple2<Boolean, Boolean> getLatestBooleanValue(SignalInfo signalInfo, Map<String, Set<SignalData>> telemetrySignals) {
        Set<SignalData> signals = SignalUtils.getSignals(telemetrySignals, signalInfo);
        boolean valuePresent = !signals.isEmpty();
        return new Tuple2<>(valuePresent, SignalUtils.getLatestSignalBooleanValue(signals));
    }

    private Tuple2<Boolean, Long> getLatestLongValue(SignalInfo signalInfo, Map<String, Set<SignalData>> telemetrySignals) {
        Set<SignalData> signals = SignalUtils.getSignals(telemetrySignals, signalInfo);
       return SignalUtils.getLatestLongValue(signals);
    }


    private Tuple2<Boolean, String> getLatestStringValue(SignalInfo signalInfo, Map<String, Set<SignalData>> telemetrySignals) {
        Set<SignalData> signals = SignalUtils.getSignals(telemetrySignals, signalInfo);
        return getLatestStringValue(signals);
    }

    public static Tuple2<Boolean, String> getLatestStringValue(Set<SignalData> signals) {
        if(signals.isEmpty()) return new Tuple2<>(false, null);

        Optional<SignalData> latestSignal = getLatestSignal(signals);
        return latestSignal
                .map(signalData -> new Tuple2<>(true, getStringSignalValue(signalData)))
                .orElseGet(() -> new Tuple2<>(false, null));
    }

    public static String getStringSignalValue(SignalData signalData) {
        return ((String) signalData.getValue());
    }

    private String getBatteryChargingStatus(Map<String, Set<SignalData>> telemetrySignals) {
        Set<SignalData> signals = SignalUtils.getSignals(telemetrySignals, SignalCatalogue.getBatteryChargingStatusInfo());
        boolean batteryCharging = SignalUtils.getLatestSignalBooleanValue(signals);
        return batteryCharging ? "not charging" : "charging";
    }

    private Tuple2<Boolean, Integer> getChargerState(Map<String, Set<SignalData>> telemetrySignals) {
        Set<SignalData> signals = SignalUtils.getSignals(telemetrySignals, SignalCatalogue.getChargerStateInfo());
        return SignalUtils.getLatestIntegerValue(signals);
    }

    private Tuple2<Boolean, String> getChargerStateDesc(Map<String, Set<SignalData>> telemetrySignals) {
        Tuple2<Boolean, Integer> latestValue = getChargerState(telemetrySignals);
        if(Boolean.FALSE.equals(latestValue.f0)) return new Tuple2<>(false, null);

        Integer value = latestValue.f1;
        String state;

        switch (value) {
            case 0:
                state = "not ready";
                break;
            case 1:
                state = "ready";
                break;
            case 2:
                state = "charging";
                break;
            case 3:
                state = "charger error";
                break;
            case 4:
                state = "charged";
                break;
            case 5:
                state = "force stop";
                break;
            case 6:
                state = "deep discharging";
                break;
            case 7:
                state = "nr_hw internal error";
                break;
            case 8:
                state = "nr_authentication error";
                break;
            case 9:
                state = "nr_Battery error";
                break;
            case 10:
                state = "nr_over voltage";
                break;
            case 11:
                state = "r_over temperature";
                break;
            case 12:
                state = "r_overcurrent/short circuit";
                break;
            case 13:
                state = "r_cAN communication error";
                break;
            case 14:
                state = "r_ac fail/out of range";
                break;
            default:
                state = "na";
                return new Tuple2<>(false, state);
        }

        return new Tuple2<>(true, state);

    }

    private Tuple2<Boolean, Integer> getChargerIdentity(Map<String, Set<SignalData>> telemetrySignals) {
        Set<SignalData> signals = SignalUtils.getSignals(telemetrySignals, SignalCatalogue.getChargerIdentityInfo());
        return SignalUtils.getLatestIntegerValue(signals);
    }

    private Tuple2<Boolean, String> getChargerIdentityDesc(Map<String, Set<SignalData>> telemetrySignals) {
        Tuple2<Boolean, Integer> latestValue = getChargerIdentity(telemetrySignals);
        if(Boolean.FALSE.equals(latestValue.f0)) return new Tuple2<>(false, null);

        Integer value = latestValue.f1;
        String identity;

        switch (value) {
            case 0:
                identity = "not specific";
                break;
            case 1:
                identity = "hero fast charger";
                break;
            case 2:
                identity = "hero portable charger";
                break;
            case 3:
                identity = "ather fast charger";
                break;
            default:
                identity = "na";
                return new Tuple2<>(false, identity);
        }

        return new Tuple2<>(true, identity);

    }

}
