package org.hmcl.cvp.dataplatform.hotstorage.operator;

import lombok.extern.slf4j.Slf4j;
import org.apache.flink.api.connector.sink2.SinkWriter;
import org.apache.flink.connector.opensearch.sink.OpensearchEmitter;
import org.apache.flink.connector.opensearch.sink.RequestIndexer;
import org.hmcl.cvp.dataplatform.commons.utils.FlinkUtils;
import org.hmcl.cvp.dataplatform.hotstorage.contract.OpenSearchDocument;
import org.opensearch.action.DocWriteRequest;
import org.opensearch.action.index.IndexRequest;
import org.opensearch.action.update.UpdateRequest;
import org.opensearch.client.Requests;

import java.util.HashMap;
import java.util.Map;

@Slf4j
public class HotStorageOpenSearchEmitter implements OpensearchEmitter<OpenSearchDocument> {

    private IndexRequest createIndexRequest(String index, DocWriteRequest.OpType opType, Map<String, Object> sourceDoc) {
        // Let the id be auto generated
        return Requests.indexRequest()
                .index(index)
                .source(sourceDoc)
                .opType(opType); // This is required for writing to stream indexes
    }

    private UpdateRequest createUpdateRequest(String index, String id, Map<String, Object> sourceDoc) {
        UpdateRequest updateRequest = new UpdateRequest();
        updateRequest.docAsUpsert(true);
        updateRequest.id(id);
        updateRequest.index(index);
        updateRequest.doc(sourceDoc);
        return updateRequest;
    }

    @Override
    public void emit(OpenSearchDocument element, SinkWriter.Context context, RequestIndexer indexer) {
        String vid = element.getVid();
        Map<String, Object> sourceDoc = getSourceDocument(element);
        if(sourceDoc.isEmpty()) {
            log.warn("Nothing to insert to OpenSearch for vehicle {}", vid);
        }

        if(element.getIsFlattenedTelemetry()) {
            log.debug("Inserting flattened master and dtc documents using POST Update API");
            UpdateRequest updateRequest = createUpdateRequest(element.getIndex(), getId(element), sourceDoc);
            indexer.add(updateRequest);
        } else {
            log.debug("Inserting charging or master telemetry or dtc documents using PUT Index API");
            IndexRequest indexRequest = createIndexRequest(element.getIndex(), element.getOpType(), sourceDoc);
            indexer.add(indexRequest);
        }

    }

    private Map<String, Object> getSourceDocument(OpenSearchDocument element) {
        if(element.getIsTelemetry()) return FlinkUtils.toMap(element.getMasterTelemetry());

        if (element.getIsChargingScreen()) return FlinkUtils.toMap(element.getChargingAnalytics());

        if (element.getIsFlattenedDtc()) return FlinkUtils.toMap(element.getFlattenedDtcTelemetry());

        if(element.getIsFlattenedTelemetry()) return FlinkUtils.toMap(element.getFlattenedMasterTelemetry());

        return new HashMap<>();
    }

    private String getId(OpenSearchDocument openSearchDocument) {
        return openSearchDocument.getDocId();
    }


}
