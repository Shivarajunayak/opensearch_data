package org.hmcl.cvp.dataplatform.hotstorage.contract;

import com.google.gson.annotations.SerializedName;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class FlattenedMasterTelemetry implements Serializable {

    @SerializedName("vid")
    private String vid;

    @SerializedName("tenantId")
    private String tenantId;

    @SerializedName("campaignName")
    private String campaignName;

    @SerializedName("eventId")
    private String eventId;

    @SerializedName("collectionEventTime")
    private Long collectionEventTime;

    @SerializedName("collectionEventTimeTsp")
    private String collectionEventTimeTsp;

    @SerializedName("systemTime")
    private Long systemTime;

    @SerializedName("systemTimeTsp")
    private String systemTimeTsp;

    @SerializedName("normalizedSignalTime")
    private Long normalizedSignalTime;

    @SerializedName("normalizedSignalTimeTsp")
    private String normalizedSignalTimeTsp;

    // Signals

    @SerializedName("altitude")
    private Double altitude;

    @SerializedName("batteryPackTemperature")
    private Double batteryPackTemperature;

    @SerializedName("batteryPackTemperatureBms1")
    private Double batteryPackTemperatureBms1;

    @SerializedName("batteryPackTemperatureBms2")
    private Double batteryPackTemperatureBms2;

    @SerializedName("bmsBduConnectionRequest")
    private Integer bmsBduConnectionRequest;

    @SerializedName("clusterSpeed")
    private Integer clusterSpeed;

    @SerializedName("cog")
    private Double cog;

    @SerializedName("driveMode")
    private Integer driveMode;

    @SerializedName("engineTemperature")
    private Integer engineTemperature;

    @SerializedName("fuelLevel")
    private Double fuelLevel;

    @SerializedName("fuelLevelIndication")
    private Integer fuelLevelIndication;

    @SerializedName("gpsFix")
    private Integer gpsFix;

    @SerializedName("gpsValid")
    private Boolean gpsValid;

    @SerializedName("hdop")
    private Double hDop;

    @SerializedName("internalBatteryChargeVoltage")
    private Double internalBatteryChargeVoltage;

    @SerializedName("latitude")
    private Double latitude;

    @SerializedName("longitude")
    private Double longitude;

    @SerializedName("odoReadingHr")
    private Double odoReadingHr;

    @SerializedName("packVoltage")
    private Double packVoltage;

    @SerializedName("pdop")
    private Double pDop;

    @SerializedName("remainingRange")
    private Integer remainingRange;

    @SerializedName("socUserBms1")
    private Double socUserBms1;

    @SerializedName("socUserBms2")
    private Double socUserBms2;

    @SerializedName("socUser")
    private Double socUser;

    @SerializedName("soh")
    private Double soh;

    @SerializedName("sohBms1")
    private Double sohBms1;

    @SerializedName("sohBms2")
    private Double sohBms2;

    @SerializedName("mainVoltage")
    private Double tcuMainBatteryVoltage;

    @SerializedName("totalUsableEnergy")
    private Integer totalUsableEnergy;

    @SerializedName("totalUsableEnergyBms1")
    private Integer totalUsableEnergyBms1;

    @SerializedName("totalUsableEnergyBms2")
    private Integer totalUsableEnergyBms2;

    @SerializedName("vdop")
    private Double vDop;

    @SerializedName("packCurrent")
    private Double packCurrent;

    @SerializedName("packCurrentBMS1")
    private Double packCurrentBMS1;

    @SerializedName("packCurrentBMS2")
    private Double packCurrentBMS2;

    @SerializedName("estimatedOutputTorque")
    private Double estimatedOutputTorque;

    @SerializedName("vcuRegBraking")
    private Integer vcuRegBraking;

    @SerializedName("tcuIgnition")
    private Boolean tcuIgnition;

}
