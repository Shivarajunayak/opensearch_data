package org.hmcl.cvp.dataplatform.hotstorage.job;

import lombok.extern.slf4j.Slf4j;
import org.apache.flink.api.common.eventtime.WatermarkStrategy;
import org.apache.flink.api.java.utils.ParameterTool;
import org.apache.flink.connector.base.DeliveryGuarantee;
import org.apache.flink.connector.kafka.source.KafkaSource;
import org.apache.flink.connector.opensearch.sink.FlushBackoffType;
import org.apache.flink.connector.opensearch.sink.Opensearch2Sink;
import org.apache.flink.connector.opensearch.sink.Opensearch2SinkBuilder;
import org.apache.flink.streaming.api.datastream.DataStream;
import org.apache.flink.streaming.api.environment.StreamExecutionEnvironment;
import org.hmcl.cvp.dataplatform.commons.connector.KafkaConnector;
import org.hmcl.cvp.dataplatform.commons.connector.OpenSearchConnector;
import org.hmcl.cvp.dataplatform.commons.constants.FlinkRuntime;
import org.hmcl.cvp.dataplatform.commons.exception.OpenSearchFailureHandler;
import org.hmcl.cvp.dataplatform.commons.operator.TelemetryFlatMapFunction;
import org.hmcl.cvp.dataplatform.commons.utils.ConnectorUtils;
import org.hmcl.cvp.dataplatform.contract.telemetry.Telemetry;
import org.hmcl.cvp.dataplatform.hotstorage.contract.OpenSearchDocument;
import org.hmcl.cvp.dataplatform.hotstorage.operator.ChargingAnalyticsMapperFunction;
import org.hmcl.cvp.dataplatform.hotstorage.operator.HotStorageOpenSearchEmitter;
import org.hmcl.cvp.dataplatform.hotstorage.operator.MasterTelemetryMapperFunction;
import org.hmcl.cvp.dataplatform.hotstorage.operator.OperatorNames;
import org.hmcl.cvp.dataplatform.hotstorage.operator.TelemetryFlattenedMapperFunction;


@Slf4j
public class OpenSearchHotStorageFlink {

    private static final Integer DEFAULT_MAX_RETRIES = 5;
    private static final Integer DEFAULT_RETRY_DELAY_MILLI = 1000;
    private static final Integer DEFAULT_MAX_ACTIONS_TO_BUFFER = 1;
    private static final Integer DEFAULT_BULK_FLUSH_SIZE_MB = -1;
    private static final Integer DEFAULT_BULK_FLUSH_INTERVAL = -1;

    // Telemetry JSON deserializer
    private static final TelemetryFlatMapFunction telemetryFunction = new TelemetryFlatMapFunction();

    // Function to map incoming telemetry to master telemetry object
    private static final MasterTelemetryMapperFunction masterTelemetryMapperFunction = new MasterTelemetryMapperFunction();

    // Function to map incoming telemetry to charging analytics object
    private static final ChargingAnalyticsMapperFunction chargingAnalyticsMapperFunction = new ChargingAnalyticsMapperFunction();

    // Function to map incoming telemetry to flattening objects
    private static final TelemetryFlattenedMapperFunction telemetryFlattenedMapperFunction = new TelemetryFlattenedMapperFunction();

    // Function to convert flattened telemetry object to opensearch document
    private static final HotStorageOpenSearchEmitter hotStorageOpenSearchEmitter = new HotStorageOpenSearchEmitter();

    private static final OpenSearchFailureHandler opensearchFailureHandler = new OpenSearchFailureHandler();

    public static void main(String[] args) throws Exception {
        final StreamExecutionEnvironment env = StreamExecutionEnvironment.getExecutionEnvironment();

        final ParameterTool parameterTool = ConnectorUtils.loadApplicationParameters(args, env);
        env.getConfig().setGlobalJobParameters(parameterTool);

        boolean isTest = parameterTool.getBoolean(FlinkRuntime.IS_TEST, Boolean.FALSE);
        log.info("Is this being executed as part of test case? {}", isTest);

        try {
            OpenSearchConnector.OpenSearchProperties openSearchProperties = OpenSearchConnector.getOpenSearchProperties(parameterTool);
            Opensearch2Sink<OpenSearchDocument> openSearchSink = getOpenSearchSink(parameterTool, openSearchProperties, isTest);

            DataStream<Telemetry> telemetryStream = getTelemetryStream(env, parameterTool, isTest);

            // Master Telemetry OpenSearch document
            DataStream<OpenSearchDocument> masterTelemetryDocumentStream = telemetryStream
                    .flatMap(masterTelemetryMapperFunction)
                    .name(OperatorNames.MASTER_TELEMETRY_MAP_FUNCTION)
                    .uid(OperatorNames.MASTER_TELEMETRY_MAP_FUNCTION);

            // Flattened Telemetry OpenSearch document
            DataStream<OpenSearchDocument> flattenedTelemetryDocumentStream = telemetryStream
                    .flatMap(telemetryFlattenedMapperFunction)
                    .name(OperatorNames.FLATTENED_TELEMETRY_MAP_FUNCTION)
                    .uid(OperatorNames.FLATTENED_TELEMETRY_MAP_FUNCTION);

            DataStream<Telemetry> chargingStream = getChargingStream(env, parameterTool, isTest);

            // Charging Screen OpenSearch document
            DataStream<OpenSearchDocument> chargingScreenDocumentStream = chargingStream
                    .flatMap(chargingAnalyticsMapperFunction)
                    .name(OperatorNames.CHARGING_MAP_FUNCTION)
                    .uid(OperatorNames.CHARGING_MAP_FUNCTION);

            // Union all three OpenSearchDocument streams
            masterTelemetryDocumentStream
                    .union(flattenedTelemetryDocumentStream)
                    .union(chargingScreenDocumentStream)
                    .keyBy(OpenSearchDocument::getVid)
                    .sinkTo(openSearchSink)
                    .uid(OperatorNames.OPEN_SEARCH_SINK)
                    .name(OperatorNames.OPEN_SEARCH_SINK);

            env.execute();

        } catch (Exception e) {
            log.error("Exception in while sinking master telemetry data into opensearch: ", e);
        }

    }

    private static DataStream<Telemetry> getTelemetryStream(final StreamExecutionEnvironment env,
                                                            final ParameterTool parameterTool,
                                                            final boolean isTest) {

        KafkaConnector.KafkaProperties kafkaProperties = KafkaConnector.getTelemetryKafkaProperties(parameterTool);

        KafkaSource<String> telemetrySource = KafkaConnector.createStringKafkaSource(kafkaProperties, parameterTool, isTest);

        String topicName = kafkaProperties.getTopics()[0];
        return env.fromSource(telemetrySource,
                        WatermarkStrategy.noWatermarks(),
                        topicName)
                .assignTimestampsAndWatermarks(WatermarkStrategy.noWatermarks())
                .flatMap(telemetryFunction)
                .name(OperatorNames.MASTER_TELEMETRY_SOURCE)
                .uid(OperatorNames.MASTER_TELEMETRY_SOURCE);
    }

    private static DataStream<Telemetry> getChargingStream(final StreamExecutionEnvironment env,
                                                            final ParameterTool parameterTool,
                                                            final boolean isTest) {

        String chargingCampaignTopic = parameterTool.get(FlinkRuntime.Kafka.CHARGING_CAMPAIGN_TOPIC);
        KafkaConnector.KafkaProperties chargingKafkaProps = KafkaConnector.getTelemetryKafkaProperties(parameterTool, chargingCampaignTopic);
        KafkaSource<String> campaignSource = KafkaConnector.createStringKafkaSource(chargingKafkaProps, parameterTool, isTest);

        return env.fromSource(campaignSource,
                        WatermarkStrategy.noWatermarks(),
                        chargingCampaignTopic)
                .assignTimestampsAndWatermarks(WatermarkStrategy.noWatermarks())
                .flatMap(telemetryFunction)
                .name(OperatorNames.CHARGING_SOURCE)
                .uid(OperatorNames.CHARGING_SOURCE);
    }

    public static Opensearch2Sink<OpenSearchDocument> getOpenSearchSink(final ParameterTool parameterTool, OpenSearchConnector.OpenSearchProperties openSearchProperties, boolean isTest) {
        int maxRetries = parameterTool.getInt(FlinkRuntime.OpenSearch.MAX_RETRIES, DEFAULT_MAX_RETRIES);
        int retryDelayInMs = parameterTool.getInt(FlinkRuntime.OpenSearch.RETRY_DELAY_IN_MS, DEFAULT_RETRY_DELAY_MILLI);
        int maxActionsToBuffer = parameterTool.getInt(FlinkRuntime.OpenSearch.MAX_ACTIONS_TO_BUFFER, DEFAULT_MAX_ACTIONS_TO_BUFFER);
        int bulkFlushSize = parameterTool.getInt(FlinkRuntime.OpenSearch.BULK_FLUSH_SIZE_MB, DEFAULT_BULK_FLUSH_SIZE_MB);
        int bulkFlushInterval = parameterTool.getInt(FlinkRuntime.OpenSearch.BULK_FLUSH_INTERVAL_MILLI, DEFAULT_BULK_FLUSH_INTERVAL);

        Opensearch2SinkBuilder<OpenSearchDocument> builder = new Opensearch2SinkBuilder<>()
                .setHosts(openSearchProperties.getHttpHost())
                .setEmitter(hotStorageOpenSearchEmitter)
                .setConnectionUsername(openSearchProperties.getUsername())
                .setConnectionPassword(openSearchProperties.getPassword())
                .setDeliveryGuarantee(DeliveryGuarantee.AT_LEAST_ONCE)
                .setBulkFlushBackoffStrategy(FlushBackoffType.EXPONENTIAL, maxRetries, retryDelayInMs)
                .setBulkFlushMaxSizeMb(bulkFlushSize)
                .setBulkFlushInterval(bulkFlushInterval)
                .setBulkFlushMaxActions(maxActionsToBuffer)
                .setFailureHandler(opensearchFailureHandler);

        if (isTest) {
            // Enabling insecure access for integration testing
            builder.setAllowInsecure(true);
        }

        return builder.build();
    }
}
