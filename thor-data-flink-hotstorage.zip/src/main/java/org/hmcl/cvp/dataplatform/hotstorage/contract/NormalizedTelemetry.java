package org.hmcl.cvp.dataplatform.hotstorage.contract;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import java.util.Map;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class NormalizedTelemetry {

    private String vid;

    private Map<String, NormalizedSignalData> normalizedSignals;

}
