package org.hmcl.cvp.dataplatform.hotstorage.contract;

import com.google.gson.annotations.SerializedName;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.util.List;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class DTCAndSnapshot implements Serializable {

    @SerializedName("DTCStatusAvailabilityMask")
    private String dtcStatusAvailabilityMask;

    @SerializedName("dtcCodes")
    private List<DTCCode> dtcCodes;
}
