package org.hmcl.cvp.dataplatform.hotstorage.helper;

import com.google.gson.Gson;
import com.google.gson.JsonSyntaxException;
import lombok.extern.slf4j.Slf4j;
import org.hmcl.cvp.dataplatform.commons.utils.GsonUtils;
import org.hmcl.cvp.dataplatform.commons.utils.SignalUtils;
import org.hmcl.cvp.dataplatform.contract.telemetry.SignalData;
import org.hmcl.cvp.dataplatform.contract.telemetry.SignalInfo;
import org.hmcl.cvp.dataplatform.contract.telemetry.Telemetry;
import org.hmcl.cvp.dataplatform.hotstorage.contract.*;

import java.util.*;

@Slf4j
public class DTCFlatteningHelper {

    private static final Gson GSON = GsonUtils.getGson();

    private DTCFlatteningHelper() {}

    public static List<DtcWrapper> getDtcInfoSignalValue(String vid, Telemetry telemetry, SignalInfo signalInfo) {
        Map<String, Set<SignalData>> signals = telemetry.getSignals();
        if(signals.isEmpty()) return new ArrayList<>();

        Set<SignalData> dtcSignals = SignalUtils.getSignals(signals, signalInfo.getKey());
        if(dtcSignals.isEmpty()) return new ArrayList<>();

        List<DtcWrapper> dtcWrappers = new ArrayList<>(dtcSignals.size());
        for(SignalData dtcSignal: dtcSignals) {
            String value = String.valueOf(dtcSignal.getValue());
            if(Objects.nonNull(value)) {
                try {
                    DtcInfo dtcInfo = GSON.fromJson(value, DtcInfo.class);
                    DtcWrapper dtcWrapper = DtcWrapper.builder()
                            .dtcInfo(dtcInfo)
                            .time(dtcSignal.getTime())
                            .build();
                    dtcWrappers.add(dtcWrapper);
                } catch (JsonSyntaxException e) {
                    log.error("Exception while deserializing dtc signal value {} for vehicle {}", value, vid);
                }
            }
        }

        return dtcWrappers;
    }

    public static List<FlattenedDtcTelemetry> getFlattenedDtcTelemetries(String vid, List<DtcWrapper> dtcWrappers, boolean isActive) {
        if(dtcWrappers.isEmpty()) return new ArrayList<>();

        List<FlattenedDtcTelemetry> flattenedDtcTelemetries = new ArrayList<>();

        for(DtcWrapper dtcWrapper: dtcWrappers) {

            List<FlattenedDtcTelemetry> flattenedDtcTelemetryList = getFlattenedDtcTelemetries(vid, dtcWrapper, isActive);
            flattenedDtcTelemetries.addAll(flattenedDtcTelemetryList);
        }

        return flattenedDtcTelemetries;

    }

    public static List<FlattenedDtcTelemetry> getFlattenedDtcTelemetries(String vid, DtcWrapper dtcWrapper, boolean isActive) {
        DtcInfo dtcInfo = dtcWrapper.getDtcInfo();
        if(Objects.isNull(dtcInfo)) return new ArrayList<>();

        List<DetectedDTC> detectedDTCs = dtcInfo.getDetectedDTCs();
        if(detectedDTCs.isEmpty()) return new ArrayList<>();

        List<FlattenedDtcTelemetry> flattenedDtcTelemetries = new ArrayList<>();
        long time = dtcWrapper.getTime();

        for(DetectedDTC detectedDTC: detectedDTCs) {

            String ecuId = detectedDTC.getEcuId();
            DTCAndSnapshot dtcAndSnapshot = detectedDTC.getDtcAndSnapshot();
            if(Objects.isNull(dtcAndSnapshot)) continue;

            String dtcStatusAvailabilityMask = dtcAndSnapshot.getDtcStatusAvailabilityMask();
            List<DTCCode> dtcCodes = dtcAndSnapshot.getDtcCodes();

            for (DTCCode dtcCode: dtcCodes) {

                FlattenedDtcTelemetry flattenedDtcTelemetry = FlattenedDtcTelemetry.builder()
                        .vid(vid)
                        .build();

                if(isActive) {
                    flattenedDtcTelemetry.setDaTime(time);
                    flattenedDtcTelemetry.setDaCode(dtcCode.getDtc());
                    flattenedDtcTelemetry.setDaEcuID(ecuId);
                    flattenedDtcTelemetry.setDaStatusAvailabilityMask(dtcStatusAvailabilityMask);
                    flattenedDtcTelemetry.setDaSnapshotRecord(dtcCode.getDtcSnapshotRecord());
                    flattenedDtcTelemetry.setDaExtendedData(dtcCode.getDtcExtendedData());
                } else {
                    flattenedDtcTelemetry.setDiaTime(time);
                    flattenedDtcTelemetry.setDiaCode(dtcCode.getDtc());
                    flattenedDtcTelemetry.setDiaEcuID(ecuId);
                    flattenedDtcTelemetry.setDiaStatusAvailabilityMask(dtcStatusAvailabilityMask);
                    flattenedDtcTelemetry.setDiaSnapshotRecord(dtcCode.getDtcSnapshotRecord());
                    flattenedDtcTelemetry.setDiaExtendedData(dtcCode.getDtcExtendedData());
                }

                flattenedDtcTelemetries.add(flattenedDtcTelemetry);
            }
        }
        return flattenedDtcTelemetries;
    }
}
