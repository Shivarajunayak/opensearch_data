package org.hmcl.cvp.dataplatform.hotstorage.contract;

import com.google.gson.annotations.SerializedName;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class DTCCode implements Serializable {

    @SerializedName("DTC")
    private String dtc;

    @SerializedName("DTCExtendedData")
    private String dtcExtendedData;

    @SerializedName("DTCSnapshotRecord")
    private String dtcSnapshotRecord;
}
