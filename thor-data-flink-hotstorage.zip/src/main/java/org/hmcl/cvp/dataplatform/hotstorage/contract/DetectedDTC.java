package org.hmcl.cvp.dataplatform.hotstorage.contract;

import com.google.gson.annotations.SerializedName;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class DetectedDTC implements Serializable {

    @SerializedName("DTCAndSnapshot")
    private DTCAndSnapshot dtcAndSnapshot;

    @SerializedName("ECUID")
    private String ecuId;

}
