package org.hmcl.cvp.dataplatform.hotstorage.contract;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.opensearch.action.DocWriteRequest;

import java.io.Serializable;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class OpenSearchDocument implements Serializable {

    private String vid;

    private String index;

    private String docId;

    private DocWriteRequest.OpType opType;

    private boolean isTelemetry;

    private boolean isFlattenedTelemetry;

    private boolean isChargingScreen;

    private boolean isFlattenedDtc;

    private MasterTelemetry masterTelemetry;

    private ChargingAnalytics chargingAnalytics;

    private FlattenedMasterTelemetry flattenedMasterTelemetry;

    private FlattenedDtcTelemetry flattenedDtcTelemetry;

    public boolean getIsTelemetry() {
        return isTelemetry;
    }

    public void setIsTelemetry(boolean telemetry) {
        isTelemetry = telemetry;
    }

    public boolean getIsFlattenedTelemetry() {
        return isFlattenedTelemetry;
    }

    public void setIsFlattenedTelemetry(boolean flattenedTelemetry) {
        isFlattenedTelemetry = flattenedTelemetry;
    }

    public boolean getIsChargingScreen() {
        return isChargingScreen;
    }

    public void setIsChargingScreen(boolean chargingScreen) {
        isChargingScreen = chargingScreen;
    }

    public boolean getIsFlattenedDtc() {
        return isFlattenedDtc;
    }

    public void setIsFlattenedDtc(boolean flattenedDtc) {
        isFlattenedDtc = flattenedDtc;
    }
}
