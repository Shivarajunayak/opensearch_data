package org.hmcl.cvp.dataplatform.hotstorage.contract;

import com.google.gson.annotations.SerializedName;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.hmcl.cvp.dataplatform.contract.telemetry.SignalData;

import java.io.Serializable;
import java.util.Set;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class MasterTelemetry implements Serializable {

    @SerializedName("vid")
    private String vid;

    @SerializedName("b2b_client_id")
    private String b2bClientId;
    
    @SerializedName("tenant_id")
    private String tenantId;

    @SerializedName("campaign_name")
    private String campaignName;

    @SerializedName("collectioneventtime")
    private Long collectionEventTime;

    @SerializedName("collectioneventtimets")
    private String collectionEventTimeTS;

    @SerializedName("event_id")
    private String eventId;

    @SerializedName("last_connection_time")
    private String lastConnectionTime;

    @SerializedName("wifi_connection_status")
    private String wifiConnectionStatus;

    @SerializedName("abs_front_wheel_pressure_plus")
    private Set<SignalData> absFrontWheelPressurePlus;

    @SerializedName("abs_telltale_status")
    private Set<SignalData> absTelltaleStatus;

    @SerializedName("altitude")
    private Set<SignalData> altitude;

    @SerializedName("ambient_temperature")
    private Set<SignalData> ambientTemperature;

    @SerializedName("apn")
    private Set<SignalData> apn;

    @SerializedName("avg_energy_consumption")
    private Set<SignalData> avgEnergyConsumption;

    @SerializedName("battery_detection")
    private Set<SignalData> batteryDetection;

    @SerializedName("battery_operation_mode")
    private Set<SignalData> batteryOperationMode;

    @SerializedName("battery_operation_mode_bms2")
    private Set<SignalData> batteryOperationModeBms2;

    @SerializedName("battery_pack_temperature")
    private Set<SignalData> batteryPackTemperature;

    @SerializedName("battery_slot_identity_front")
    private Set<SignalData> batterySlotIdentityFront;

    @SerializedName("battery_slot_identity_rear")
    private Set<SignalData> batterySlotIdentityRear;

    @SerializedName("ble_connectivity")
    private Set<SignalData> bleConnectivity;

    @SerializedName("bms_bdu_status")
    private Set<SignalData> bmsBduStatus;

    @SerializedName("bms_status")
    private Set<SignalData> bmsStatus;

    @SerializedName("bms_bdu_connection_request")
    private Set<SignalData> bmsBduConnectionRequest;

    @SerializedName("bms1_battery_pack_temperature")
    private Set<SignalData> bms1BatteryPackTemperature;

    @SerializedName("bms2_battery_pack_temperature")
    private Set<SignalData> bms2BatteryPackTemperature;

    @SerializedName("boost_mode_status")
    private Set<SignalData> boostModeStatus;

    @SerializedName("ble_key")
    private Set<SignalData> bleKey;

    @SerializedName("brake_input_signal")
    private Set<SignalData> brakeInputSignal;

    @SerializedName("charger_power_line_state")
    private Set<SignalData> chargerPowerLineState;

    @SerializedName("charger_identity")
    private Set<SignalData> chargerIdentity;

    @SerializedName("cog")
    private Set<SignalData> cog;

    @SerializedName("distance_accumulation")
    private Set<SignalData> distanceAccumulation;

    @SerializedName("distance_travelled_with_mil")
    private Set<SignalData> distanceTravelledWithMil;

    @SerializedName("drive_mode_signal")
    private Set<SignalData> driveModeSignal;

    @SerializedName("dtc_info")
    private Set<SignalData> dtcInfo;

    @SerializedName("dtc_info_inactive")
    private Set<SignalData> dtcInfoInActive;

    @SerializedName("engine_speed")
    private Set<SignalData> engineSpeed;

    @SerializedName("engine_temperature")
    private Set<SignalData> engineTemperature;

    @SerializedName("eol_xml_id")
    private Set<SignalData> eolXmlId;

    @SerializedName("fr_wss")
    private Set<SignalData> frWss;

    @SerializedName("fr_wss_plus")
    private Set<SignalData> frWssPlus;

    @SerializedName("fuel_level")
    private Set<SignalData> fuelLevel;

    @SerializedName("fuel_level_indication")
    private Set<SignalData> fuelLevelIndication;

    @SerializedName("gear_position_sensor")
    private Set<SignalData> gearPositionSensor;

    @SerializedName("gps_fix")
    private Set<SignalData> gpsFix;

    @SerializedName("gps_speed")
    private Set<SignalData> gpsSpeed;

    @SerializedName("gps_valid")
    private Set<SignalData> gpsValid;

    @SerializedName("harsh_driving_alert")
    private Set<SignalData> harshDrivingAlert;

    @SerializedName("hdop")
    private Set<SignalData> hDop;

    @SerializedName("motor_speed")
    private Set<SignalData> motorSpeed;

    @SerializedName("motor_status")
    private Set<SignalData> motorStatus;

    @SerializedName("int_bat_charge_percent")
    private Set<SignalData> intBatChargePercent;

    @SerializedName("int_bat_charge_voltage")
    private Set<SignalData> intBatChargeVoltage;

    @SerializedName("immobilisation_signal_ack")
    private Set<SignalData> immobSignalAck;

    @SerializedName("latitude")
    private Set<SignalData> latitude;

    @SerializedName("longitude")
    private Set<SignalData> longitude;

    @SerializedName("mainVoltage")
    private Set<SignalData> mainVoltage;

    @SerializedName("mileage_trip")
    private Set<SignalData> mileageTrip;

    @SerializedName("odo_signal_hr")
    private Set<SignalData> odoSignalHr;

    @SerializedName("pack_current")
    private Set<SignalData> packCurrent;

    @SerializedName("pack_voltage")
    private Set<SignalData> packVoltage;

    @SerializedName("pdop")
    private Set<SignalData> pDop;

    @SerializedName("ready_status")
    private Set<SignalData> readyStatus;

    @SerializedName("remaining_capacity")
    private Set<SignalData> remainingCapacity;

    @SerializedName("remaining_range_in_km")
    private Set<SignalData> remainingRangeInKm;

    @SerializedName("rider_info_userid")
    private Set<SignalData> riderInfoUserid;

    @SerializedName("rider_info_usertype")
    private Set<SignalData> riderInfoUsertype;

    @SerializedName("rr_wss")
    private Set<SignalData> rrWss;

    @SerializedName("rr_wss_plus")
    private Set<SignalData> rrWssPlus;

    @SerializedName("sats_in_use")
    private Set<SignalData> satelliteInUse;

    @SerializedName("sats_in_view")
    private Set<SignalData> satelliteInView;

    @SerializedName("soc_user")
    private Set<SignalData> socUser;

    @SerializedName("soc_user_bms1")
    private Set<SignalData> socUserBms1;

    @SerializedName("soc_user_bms2")
    private Set<SignalData> socUserBms2;

    @SerializedName("soe")
    private Set<SignalData> soe;

    @SerializedName("soh")
    private Set<SignalData> soh;

    @SerializedName("soh_bms1")
    private Set<SignalData> sohBms1;

    @SerializedName("soh_bms2")
    private Set<SignalData> sohBms2;

    @SerializedName("speed_limit_signal")
    private Set<SignalData> speedLimitSignal;

    @SerializedName("status_abs")
    private Set<SignalData> statusAbs;

    @SerializedName("tcu_ignition")
    private Set<SignalData> tcuIgnition;

    @SerializedName("temp_status")
    private Set<SignalData> tempStatus;

    @SerializedName("thermal_run_command")
    private Set<SignalData> thermalRunCommand;

    @SerializedName("thermal_run_status_aggr")
    private Set<SignalData> thermalRunStatusAggregate;

    @SerializedName("throttle")
    private Set<SignalData> throttle;

    @SerializedName("throttle_grip_sensor")
    private Set<SignalData> throttleGripSensor;

    @SerializedName("throttle_position_sensor")
    private Set<SignalData> throttlePositionSensor;

    @SerializedName("total_usable_capacity")
    private Set<SignalData> totalUsableCapacity;

    @SerializedName("total_usable_energy")
    private Set<SignalData> totalUsableEnergy;

    @SerializedName("total_usable_energy_bms1")
    private Set<SignalData> totalUsableEnergyBms1;

    @SerializedName("total_usable_energy_bms2")
    private Set<SignalData> totalUsableEnergyBms2;

    @SerializedName("trip_start_signal")
    private Set<SignalData> tripStartSignal;

    @SerializedName("trip_end_signal")
    private Set<SignalData> tripEndSignal;

    @SerializedName("tcu_sw_version_major")
    private Set<SignalData> tcuSwVersionMajor;

    @SerializedName("user_id")
    private Set<SignalData> userId;

    @SerializedName("user_type")
    private Set<SignalData> userType;

    @SerializedName("vdop")
    private Set<SignalData> vDop;

    @SerializedName("vehicle_speed")
    private Set<SignalData> vehicleSpeed;

    @SerializedName("vehicle_speed_display")
    private Set<SignalData> vehicleSpeedDisplay;

    @SerializedName("vehicle_speed_high_res")
    private Set<SignalData> vehicleSpeedHighRes;

    @SerializedName("vehicle_speed_high_res_1")
    private Set<SignalData> vehicleSpeedHighRes1;

    @SerializedName("recordTimestamp")
    private long recordTimestamp;

    @SerializedName("recordTimestampTs")
    private String recordTimestampTs;

    @SerializedName("latency_ms")
    private long latencyMs;

    @SerializedName("id_bms1")
    private Set<SignalData> idBMS1;

    @SerializedName("id_bms2")
    private Set<SignalData> idBMS2;

}
