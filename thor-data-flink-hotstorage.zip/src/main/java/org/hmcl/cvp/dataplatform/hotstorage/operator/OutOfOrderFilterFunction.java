package org.hmcl.cvp.dataplatform.hotstorage.operator;

import lombok.extern.slf4j.Slf4j;
import org.apache.flink.api.common.functions.RichFlatMapFunction;
import org.apache.flink.api.common.state.MapState;
import org.apache.flink.api.common.state.MapStateDescriptor;
import org.apache.flink.api.common.typeinfo.Types;
import org.apache.flink.configuration.Configuration;
import org.apache.flink.util.Collector;
import org.hmcl.cvp.dataplatform.commons.utils.TelemetryUtils;
import org.hmcl.cvp.dataplatform.contract.telemetry.Telemetry;

@Slf4j
public class OutOfOrderFilterFunction extends RichFlatMapFunction<Telemetry, Telemetry> {

    private transient MapState<String, Long> lastProcessedEventTimeState;

    @Override
    public void open(Configuration parameters) {
        MapStateDescriptor<String, Long> descriptor = new MapStateDescriptor<>(
                "lastProcessedEventTimeByVid",
                Types.STRING, // Tuple2<String, String> for documentType and vid
                Types.LONG // Long for last processed event time
        );
        lastProcessedEventTimeState = getRuntimeContext().getMapState(descriptor);
    }

    @Override
    public void flatMap(Telemetry value, Collector<Telemetry> out) throws Exception {


        String vid = TelemetryUtils.getVirtualId(value);
        Long currentEventTime = value.getCollectionEventTime();
        int eventId = value.getEventId();

        // Get the last processed event time for this key
        Long lastProcessedEventTime = lastProcessedEventTimeState.get(vid);

        log.debug("Analyzing Telemetry data for VID: {} eventTSP: {}, lastProcessedEventTime: {}", vid, currentEventTime, lastProcessedEventTime);

        if (lastProcessedEventTime == null || currentEventTime >= lastProcessedEventTime) {
            // Update the state for this key
            lastProcessedEventTimeState.put(vid, currentEventTime);

            // Forward the event
            out.collect(value);
        } else {
            log.info("ignoring Telemetry data for VID: {} with event Id: {}, due to late event, event TSP: {} against cached lastProcessedEventTime: {}", vid, eventId, currentEventTime, lastProcessedEventTime);
        }
    }
}