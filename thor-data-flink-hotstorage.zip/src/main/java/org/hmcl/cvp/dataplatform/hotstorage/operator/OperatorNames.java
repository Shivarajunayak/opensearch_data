package org.hmcl.cvp.dataplatform.hotstorage.operator;

public class OperatorNames {

    private OperatorNames() {}

    public static final String MASTER_TELEMETRY_SOURCE = "telemetry-master-source";
    public static final String MASTER_TELEMETRY_MAP_FUNCTION = "telemetry-master-mapper";
    public static final String FLATTENED_TELEMETRY_MAP_FUNCTION = "flattened-telemetry-mapper";
    public static final String CHARGING_SOURCE = "charging-source";
    public static final String CHARGING_MAP_FUNCTION = "charging-mapper";
    public static final String OPEN_SEARCH_SINK = "opensearch-sink";
}
