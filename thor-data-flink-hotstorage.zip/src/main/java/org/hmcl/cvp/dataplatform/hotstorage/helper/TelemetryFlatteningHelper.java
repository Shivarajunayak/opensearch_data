package org.hmcl.cvp.dataplatform.hotstorage.helper;

import lombok.extern.slf4j.Slf4j;
import org.hmcl.cvp.dataplatform.commons.catalogue.SignalCatalogue;
import org.hmcl.cvp.dataplatform.commons.utils.DateUtils;
import org.hmcl.cvp.dataplatform.commons.utils.SignalUtils;
import org.hmcl.cvp.dataplatform.contract.telemetry.SignalData;
import org.hmcl.cvp.dataplatform.contract.telemetry.SignalInfo;
import org.hmcl.cvp.dataplatform.contract.telemetry.Telemetry;
import org.hmcl.cvp.dataplatform.hotstorage.contract.*;

import java.util.*;
import java.util.stream.Collectors;

@Slf4j
public class TelemetryFlatteningHelper {

    private TelemetryFlatteningHelper() {}

    /**
     * From the given Set of signals, normalize the signal time.
     * If there are multiple signal values for a normalized time, then consider the latest signal value only
     */
    public static List<NormalizedSignalData> normalizeTimestamps(Map<String, Set<SignalData>> telemetrySignals, SignalInfo signalInfo, long epochDigitsToIgnore) {
        Set<SignalData> signals = SignalUtils.getSignals(telemetrySignals, signalInfo);
        if(signals.isEmpty()) return new ArrayList<>();

        Set<NormalizedSignalData> normalizedSignalData = signals.stream().parallel()
                .map(s -> ignoreDigitsInEpoch(s, epochDigitsToIgnore))
                .collect(Collectors.toSet());

        return getLatestNormalizedSignalValues(normalizedSignalData);
    }

    /**
     * Strip the last digits in the epoch milli and replace them with zeroes
     */
    public static NormalizedSignalData ignoreDigitsInEpoch(SignalData signalData, long epochDigitsToIgnore) {
        long signalTime = signalData.getTime();
        long normalizedTime = DateUtils.normalizeEpochMilli(signalTime, epochDigitsToIgnore);
        return NormalizedSignalData.builder()
                .value(signalData.getValue())
                .time(signalData.getTime())
                .normalizedTime(normalizedTime)
                .build();
    }

    /**
     * For a given normalized time, if there are multiple signal values for a given signal, consider only the latest value.
     * Example, consider latitude signal. Suppose we have two signal values captured every 5 seconds,
     * and when the digits to ignore is configured to 4 digits, then for the normalized time, we will have both the latitude values.
     * Here, only the latest latitude value is considered for that normalized time.
     */
    public static List<NormalizedSignalData> getLatestNormalizedSignalValues(Set<NormalizedSignalData> normalizedSignals) {
        Map<Long, NormalizedSignalData> normalizedSignalMap = new HashMap<>(normalizedSignals.size());
        normalizedSignals.forEach(signal -> {
            long timeKey = signal.getNormalizedTime();
            NormalizedSignalData mapValue = normalizedSignalMap.getOrDefault(timeKey, signal);
            if (signal.getTime() >= mapValue.getTime()) normalizedSignalMap.put(timeKey, signal);
        });

        return new ArrayList<>(normalizedSignalMap.values());
    }

    /*
     * Normalize only the needed signals and collect it into a map.
     * Map<Long, NormalizedTelemetry> - Key is normalized time and value is NormalizedTelemetry object having all the signals captured at the normalized time
     */
    public static Map<Long, NormalizedTelemetry> getNormalizedTelemetries(Telemetry value, long epochDigitsToIgnore) {
        Map<String, Set<SignalData>> signals = value.getSignals();

        Map<Long, NormalizedTelemetry> normalizedTelemetryMap = new HashMap<>();

        populateNormalizedTelemetry(normalizedTelemetryMap, signals, SignalCatalogue.getAltitudeInfo(), epochDigitsToIgnore);
        populateNormalizedTelemetry(normalizedTelemetryMap, signals, SignalCatalogue.getBatteryPackTemperatureInfo(), epochDigitsToIgnore);
        populateNormalizedTelemetry(normalizedTelemetryMap, signals, SignalCatalogue.getBMS1BatteryPackTempInfo(), epochDigitsToIgnore);
        populateNormalizedTelemetry(normalizedTelemetryMap, signals, SignalCatalogue.getBMS2BatteryPackTempInfo(), epochDigitsToIgnore);
        populateNormalizedTelemetry(normalizedTelemetryMap, signals, SignalCatalogue.getBMSBDUConnectionRequestInfo(), epochDigitsToIgnore);
        populateNormalizedTelemetry(normalizedTelemetryMap, signals, SignalCatalogue.getVehicleSpeedDisplayInfo(), epochDigitsToIgnore);
        populateNormalizedTelemetry(normalizedTelemetryMap, signals, SignalCatalogue.getCogInfo(), epochDigitsToIgnore);
        populateNormalizedTelemetry(normalizedTelemetryMap, signals, SignalCatalogue.getDrivingModeInfo(), epochDigitsToIgnore);
        populateNormalizedTelemetry(normalizedTelemetryMap, signals, SignalCatalogue.getEngineTemperatureInfo(), epochDigitsToIgnore);
        populateNormalizedTelemetry(normalizedTelemetryMap, signals, SignalCatalogue.getFuelLevelInfo(), epochDigitsToIgnore);
        populateNormalizedTelemetry(normalizedTelemetryMap, signals, SignalCatalogue.getFuelLevelIndicationInfo(), epochDigitsToIgnore);
        populateNormalizedTelemetry(normalizedTelemetryMap, signals, SignalCatalogue.getGpsFixInfo(), epochDigitsToIgnore);
        populateNormalizedTelemetry(normalizedTelemetryMap, signals, SignalCatalogue.getGpsValidInfo(), epochDigitsToIgnore);
        populateNormalizedTelemetry(normalizedTelemetryMap, signals, SignalCatalogue.getHDopInfo(), epochDigitsToIgnore);
        populateNormalizedTelemetry(normalizedTelemetryMap, signals, SignalCatalogue.getInternalBatteryChargeVoltageInfo(), epochDigitsToIgnore);
        populateNormalizedTelemetry(normalizedTelemetryMap, signals, SignalCatalogue.getLatitudeInfo(), epochDigitsToIgnore);
        populateNormalizedTelemetry(normalizedTelemetryMap, signals, SignalCatalogue.getLongitudeInfo(), epochDigitsToIgnore);
        populateNormalizedTelemetry(normalizedTelemetryMap, signals, SignalCatalogue.getTcuMainVoltageInfo(), epochDigitsToIgnore);
        populateNormalizedTelemetry(normalizedTelemetryMap, signals, SignalCatalogue.getOdometerHRInfo(), epochDigitsToIgnore);
        populateNormalizedTelemetry(normalizedTelemetryMap, signals, SignalCatalogue.getPackVoltageInfo(), epochDigitsToIgnore);
        populateNormalizedTelemetry(normalizedTelemetryMap, signals, SignalCatalogue.getPDopInfo(), epochDigitsToIgnore);
        populateNormalizedTelemetry(normalizedTelemetryMap, signals, SignalCatalogue.getRemainingRangeInfo(),epochDigitsToIgnore);
        populateNormalizedTelemetry(normalizedTelemetryMap, signals, SignalCatalogue.getSocUserBMS1Info(), epochDigitsToIgnore);
        populateNormalizedTelemetry(normalizedTelemetryMap, signals, SignalCatalogue.getSocUserBMS2Info(), epochDigitsToIgnore);
        populateNormalizedTelemetry(normalizedTelemetryMap, signals, SignalCatalogue.getSocUserPercentageInfo(), epochDigitsToIgnore);
        populateNormalizedTelemetry(normalizedTelemetryMap, signals, SignalCatalogue.getSohInfo(), epochDigitsToIgnore);
        populateNormalizedTelemetry(normalizedTelemetryMap, signals, SignalCatalogue.getBMS1SohPercentage(), epochDigitsToIgnore);
        populateNormalizedTelemetry(normalizedTelemetryMap, signals, SignalCatalogue.getBMS2SohPercentage(), epochDigitsToIgnore);
        populateNormalizedTelemetry(normalizedTelemetryMap, signals, SignalCatalogue.getTotalUsableEnergyInfo(), epochDigitsToIgnore);
        populateNormalizedTelemetry(normalizedTelemetryMap, signals, SignalCatalogue.getTotalUsableEnergyBMS1Info(), epochDigitsToIgnore);
        populateNormalizedTelemetry(normalizedTelemetryMap, signals, SignalCatalogue.getTotalUsableEnergyBMS2Info(), epochDigitsToIgnore);
        populateNormalizedTelemetry(normalizedTelemetryMap, signals, SignalCatalogue.getVDopInfo(), epochDigitsToIgnore);

        populateNormalizedTelemetry(normalizedTelemetryMap, signals, SignalCatalogue.getPackCurrentInfo(), epochDigitsToIgnore);
        populateNormalizedTelemetry(normalizedTelemetryMap, signals, SignalCatalogue.getBMS1PackCurrentInfo(), epochDigitsToIgnore);
        populateNormalizedTelemetry(normalizedTelemetryMap, signals, SignalCatalogue.getBMS2PackCurrentInfo(), epochDigitsToIgnore);
        populateNormalizedTelemetry(normalizedTelemetryMap, signals, SignalCatalogue.getEstimatedOutputTorqueInfo(), epochDigitsToIgnore);
        populateNormalizedTelemetry(normalizedTelemetryMap, signals, SignalCatalogue.getVcuRegBrakingInfo(), epochDigitsToIgnore);
        populateNormalizedTelemetry(normalizedTelemetryMap, signals, SignalCatalogue.getTcuIgnitionInfo(), epochDigitsToIgnore);

        return normalizedTelemetryMap;
    }

    public static void populateNormalizedTelemetry(Map<Long, NormalizedTelemetry> normalizedTelemetryMap,
                                             Map<String, Set<SignalData>> telemetrySignals,
                                             SignalInfo signalInfo,
                                             long epochDigitsToIgnore) {

        List<NormalizedSignalData> normalizedSignalsData = normalizeTimestamps(telemetrySignals, signalInfo, epochDigitsToIgnore);

        for (NormalizedSignalData normalizedSignalData : normalizedSignalsData) {
            long normalizedTimeKey = normalizedSignalData.getNormalizedTime();

            // Get or default the normalized telemetry for the normalized time
            NormalizedTelemetry existingNormalizedTelemetry = normalizedTelemetryMap.getOrDefault(normalizedTimeKey, null);

            if (Objects.isNull(existingNormalizedTelemetry)) {
                existingNormalizedTelemetry = NormalizedTelemetry.builder()
                        .normalizedSignals(new HashMap<>())
                        .build();
            }

            Map<String, NormalizedSignalData> normalizedSignals = existingNormalizedTelemetry.getNormalizedSignals();
            normalizedSignals.put(signalInfo.getKey(), normalizedSignalData);
            existingNormalizedTelemetry.setNormalizedSignals(normalizedSignals);

            normalizedTelemetryMap.put(normalizedTimeKey, existingNormalizedTelemetry);
        }

    }
}
