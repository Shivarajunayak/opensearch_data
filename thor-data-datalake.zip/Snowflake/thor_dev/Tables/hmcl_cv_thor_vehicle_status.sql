create or replace TABLE THOR_DATABASE.THOR_DEV.HMCL_CV_THOR_VEHICLE_STATUS (
	ID NUMBER(38,0) autoincrement start 1 increment 1 noorder,
	VID VARCHAR(16777216) NOT NULL,
	TCU_ID VARCHAR(16777216),
	LAST_CONNECT TIMESTAMP_NTZ(9),
	ACTIVE_INACTIVE VARCHAR(16777216),
	primary key (VID)
)COMMENT='The table contains records of vehicle statuses in the THOR system. Each record represents the current status of a specific vehicle and includes the vehicle identification number, the ID of the telematics unit associated with the vehicle, the last time the vehicle was connected to the system, and a flag indicating whether the vehicle is currently active or inactive.'
;