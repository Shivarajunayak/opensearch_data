CREATE OR REPLACE PROCEDURE THOR_DATABASE.THOR_DEV.PROCESS_THOR_TELEMETRY_TENANTS("SIGNAL_LIST" VARCHAR, "RAW_TABLE" VARCHAR, "STAGE2_TABLE" VARCHAR, "BASE_SCHEMA" VARCHAR, "TEMP_TABLE_NAME" VARCHAR, "FINAL_TABLE_NAME" VARCHAR)
RETURNS VARCHAR
LANGUAGE SQL
EXECUTE AS OWNER
AS '
DECLARE
    table_exists BOOLEAN DEFAULT FALSE;
    temp_table_exists BOOLEAN DEFAULT FALSE;
    res RESULTSET;
    intersect_vid_list ARRAY;
    flag_update_condition STRING;
    update_query STRING;
    pivot_query STRING;
    final_update_query STRING;
    insert_query STRING;
    intersect_sql STRING;
    tenant_id VARCHAR;
    temp_table VARCHAR;
    final_table VARCHAR;
    tenants ARRAY := ARRAY_CONSTRUCT(''EV-VIDA'', ''ICE-HARLEY'', ''ICE-HERO'');
    i INTEGER;
    return_message STRING := '''';

BEGIN
    LET column_list VARCHAR := :SIGNAL_LIST;

    LET pivot_column_list VARCHAR := (
        SELECT ARRAY_TO_STRING(
            ARRAY_AGG('''''''' || TRIM(value) || ''''''''),
            '', ''
        )
        FROM TABLE(SPLIT_TO_TABLE(:column_list, '',''))
    );

    -- Check if Stage2 table exists
    BEGIN
        EXECUTE IMMEDIATE ''DESCRIBE TABLE '' || :STAGE2_TABLE;
        SET table_exists := TRUE;
    EXCEPTION
        WHEN OTHER THEN
            SET table_exists := FALSE;
    END;

    -- If Stage2 table does not exist, create it
    IF (table_exists = FALSE) THEN
        EXECUTE IMMEDIATE ''
        CREATE TABLE '' || :STAGE2_TABLE || '' (
            VID VARCHAR(16777216),
            TENANTID VARCHAR(16777216),
            B2BCLIENTID VARCHAR(16777216),
            YEAR NUMBER(4,0),
            MONTH NUMBER(2,0),
            DAY NUMBER(2,0),
            COLLECTIONEVENTTIME NUMBER(13,0),
            SIGNAL_VALUE VARCHAR(16777216),
            SIGNAL_TIME NUMBER(38,0),
            SIGNAL_NAME VARCHAR(16777216),
            FLAG NUMBER(1,0)
        )'';
    END IF;

    -- Step 3: Update Flag = 0 for existing records (skip for first load)
    IF (table_exists = TRUE) THEN
        EXECUTE IMMEDIATE ''
            UPDATE '' || :STAGE2_TABLE || ''
            SET FLAG = 0
            '';
    END IF;

    -- Step 2: Flatten and Explode Data into Stage 2 (older approach)
    LET dynamic_sql STRING := (
        WITH signal_list AS (
            SELECT TRIM(value) AS signal_name
            FROM TABLE(SPLIT_TO_TABLE(:SIGNAL_LIST, '',''))
        ),
        numbered_signals AS (
            SELECT
                signal_name,
                ROW_NUMBER() OVER (ORDER BY signal_name) AS rn
            FROM signal_list
        )
        SELECT
            ''INSERT INTO '' || :STAGE2_TABLE || '' WITH '' || LISTAGG(
                ''exploded_'' || rn || '' AS (
                    SELECT
                        VID,
                        TENANTID,
                        YEAR,
                        MONTH,
                        DAY,
                        COLLECTIONEVENTTIME,
                        f.value:value::VARCHAR(16777216) AS SIGNAL_VALUE,
                        FLOOR(f.value:time / 1000) AS SIGNAL_TIME,
                        '''''' || signal_name || '''''' AS SIGNAL_NAME,
                        1 AS FLAG,
                        B2BCLIENTID
                    FROM '' || :RAW_TABLE || '',
                    LATERAL FLATTEN(input => '' || signal_name || '') f
                )''
                , '', '')
              || '' SELECT * FROM ('' || LISTAGG(''SELECT * FROM exploded_'' || rn, '' UNION ALL '') || '')''
        FROM numbered_signals
    );
    EXECUTE IMMEDIATE :dynamic_sql;

	-- temporary table for intersected data
	LET temp_intersect_table STRING := :BASE_SCHEMA || ''.'' || :TEMP_TABLE_NAME || ''_INTERSECT'';
	LET flag_update_sql STRING := ''
          CREATE OR REPLACE TEMP TABLE '' || :temp_intersect_table || '' AS
          SELECT VID, SIGNAL_TIME, TENANTID  FROM '' || STAGE2_TABLE || ''
          WHERE FLAG = 0
          INTERSECT
          SELECT VID, SIGNAL_TIME, TENANTID FROM '' || STAGE2_TABLE || ''
          WHERE FLAG = 1
        '';
        EXECUTE IMMEDIATE flag_update_sql; -- data to be updated in target table

	LET update_query_sql STRING := ''
          UPDATE '' || STAGE2_TABLE || '' AS tgt
          SET FLAG = 1
          FROM '' || :temp_intersect_table || '' AS temp
          WHERE tgt.VID = temp.VID
            AND tgt.SIGNAL_TIME = temp.SIGNAL_TIME
			AND tgt.TENANTID = temp.TENANTID
        '';
    EXECUTE IMMEDIATE :update_query_sql;

    -- Loop through each tenant
    FOR i IN 0 TO ARRAY_SIZE(:tenants) - 1 DO
        SET tenant_id := :tenants[i];
        -- Construct table names with tenant suffix (replace hyphen with underscore)
        SET temp_table := :BASE_SCHEMA || ''.'' || :TEMP_TABLE_NAME || ''_'' || UPPER(REPLACE(:tenant_id, ''-'', ''_''));
        SET final_table := :BASE_SCHEMA || ''.'' || :FINAL_TABLE_NAME || ''_'' || UPPER(REPLACE(:tenant_id, ''-'', ''_''));

        -- drop temp table as signal list changes
        EXECUTE IMMEDIATE ''DROP TABLE '' || :temp_table;
        LET create_temp_table_query STRING := ''
                CREATE TABLE '' || :temp_table || '' AS
                SELECT
                    VID,
                    TENANTID,
                    B2BCLIENTID,
                    YEAR,
                    MONTH,
                    DAY,
                    SIGNAL_TIME,
                    '' || (
                        SELECT LISTAGG(''NULL AS '' || UPPER(TRIM(value)), '', '')  -- No quotes around signal names
                        FROM TABLE(SPLIT_TO_TABLE(:column_list, '',''))
                    ) || ''
                FROM '' || :STAGE2_TABLE || ''
                WHERE 1=0'';
        EXECUTE IMMEDIATE create_temp_table_query;

        -- Step 6: Pivot Stage 2 Data to Pre-Target table for this tenant (use original tenant_id with hyphen)
        pivot_query := ''
            INSERT INTO '' || :temp_table || ''
            SELECT * FROM (
                SELECT VID, TENANTID, B2BCLIENTID, YEAR, MONTH, DAY, SIGNAL_VALUE, SIGNAL_TIME, SIGNAL_NAME
                FROM '' || :STAGE2_TABLE || ''
                WHERE FLAG = 1 AND TENANTID = '''''' || :tenant_id || ''''''
            )
            PIVOT (
                MAX(SIGNAL_VALUE) FOR SIGNAL_NAME IN ('' || :pivot_column_list || '')
            )'';
        EXECUTE IMMEDIATE pivot_query;

        -- Step 7: Merge from Pre-Target to Target table (Update)
		final_update_query := ''
			UPDATE '' || :final_table || '' AS target
			SET '' || (
				SELECT LISTAGG(''target.'' || TRIM(value) || '' = source.'' || TRIM(value), '', '')
				FROM TABLE(SPLIT_TO_TABLE(:column_list, '',''))
			) || ''
			FROM (
				SELECT tgt.*
				FROM '' || :TEMP_TABLE || '' AS tgt
				JOIN '' || :temp_intersect_table || '' AS temp
				  ON tgt.VID = temp.VID
				  AND tgt.SIGNAL_TIME = temp.SIGNAL_TIME
				  AND tgt.TENANTID = temp.TENANTID
			) AS source
			WHERE target.VID = source.VID AND target.SIGNAL_TIME = source.SIGNAL_TIME
			'';
		EXECUTE IMMEDIATE final_update_query;

        -- Step 7: Merge from Pre-Target to Target table (Insert)
        insert_query := ''
            INSERT INTO '' || :final_table || '' (
                VID, TENANTID, B2BCLIENTID, YEAR, MONTH, DAY, SIGNAL_TIME, '' || :column_list || ''
            )
            SELECT
                VID, TENANTID, B2BCLIENTID, YEAR, MONTH, DAY, SIGNAL_TIME, '' || :column_list || ''
            FROM '' || :temp_table || '' AS temp
            WHERE NOT EXISTS (
                SELECT 1
                FROM '' || :final_table || '' AS final
                WHERE final.VID = temp.VID AND final.SIGNAL_TIME = temp.SIGNAL_TIME
            )'';

        EXECUTE IMMEDIATE insert_query;

        -- Append to return message
        return_message := :return_message || ''Processed tenant '' || :tenant_id || ''; '';
    END FOR;

    -- Step 8: Delete Old Records from Stage 2 (older than 4 hours)
    EXECUTE IMMEDIATE ''
        DELETE FROM '' || :STAGE2_TABLE || ''
        WHERE COLLECTIONEVENTTIME < (EXTRACT(EPOCH FROM CURRENT_TIMESTAMP) * 1000 - 14400000)'';

    RETURN TRIM(:return_message || ''Stage 2 cleanup completed'');
END;
';