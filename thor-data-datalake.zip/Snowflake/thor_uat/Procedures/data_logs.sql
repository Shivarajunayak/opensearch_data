CREATE OR REPLACE PROCEDURE THOR_DATABASE.THOR_UAT.DATA_LOGS("SIGNAL1" VARCHAR(16777216), "SIGNAL2" VARCHAR(16777216), "SIGNAL3" VARCHAR(16777216), "SIGNAL4" VARCHAR(16777216), "SIGNAL5" VARCHAR(16777216), "SIGNAL6" VARCHAR(16777216), "VID" VARCHAR(60), "START_TIME" NUMBER(38,0), "END_TIME" NUMBER(38,0), "LIMIT" NUMBER(38,0), "OFFSET" NUMBER(38,0))
RETURNS VARIANT
LANGUAGE SQL
EXECUTE AS OWNER
AS '

DECLARE
    null_column_count NUMBER DEFAULT 0;  -- Number of NULL columns to add
    -- null_columns STRING;                -- String to hold the dynamic NULL columns
    query STRING;                       -- Final query string
    res RESULTSET;                      -- Resultset of the query
    CHARGING_ARRAY ARRAY;
    result VARIANT;
    default_value STRING DEFAULT ''DEFAULT_VALUE'';  -- Define default value for NULLs
BEGIN


    LET c1 CURSOR FOR SELECT COLUMN_NAME
                      FROM information_schema.columns
                      WHERE TABLE_SCHEMA = ''THOR_UAT''
                        AND TABLE_NAME = ''HMCL_CV_THOR_TELEMETRY'';


    LET TELEMETRY_COLUMNS := '''';
    LET TELEMETRY_COLUMNS_FINAL :='''';
    LET CHARGING_COLUMNS :='''';
    LET ALL_COLUMNS :='''';
    LET signals := ARRAY_CONSTRUCT(signal1, signal2,signal3,signal4,signal5,signal6);
    LET signal_names := ARRAY_CONSTRUCT(''signal1'', ''signal2'', ''signal3'', ''signal4'', ''signal5'', ''signal6'');

    -- Loop through the columns of the telemetry table

    FOR record IN c1 DO
        -- Check if the column matches any of the signals
        FOR i IN 0 TO ARRAY_SIZE(signals) - 1 DO
            IF (signals[i] = record.COLUMN_NAME) THEN
                IF (TELEMETRY_COLUMNS != '''') THEN
                    TELEMETRY_COLUMNS := TELEMETRY_COLUMNS || '','' || signals[i];
                    TELEMETRY_COLUMNS_FINAL := TELEMETRY_COLUMNS_FINAL || '','' || ''IFNULL(MAX(T1.'' || signals[i] || ''), '''''''') AS '' || signals[i] || '' '';

                ELSE
                    TELEMETRY_COLUMNS := signals[i];
                    TELEMETRY_COLUMNS_FINAL := ''IFNULL(MAX(T1.'' || signals[i] || ''), '''''''') AS '' || signals[i] || '' '';

                END IF;
            END IF;
        END FOR;
    END FOR;

    -- Convert TELEMETRY_COLUMNS to an array
    LET TELEMETRY_ARRAY := SPLIT(TELEMETRY_COLUMNS, '','');

    -- Extract CHARGING columns (only if not already in TELEMETRY_COLUMNS)
    FOR i IN 0 TO ARRAY_SIZE(signals) - 1 DO
    -- Skip NULL signals explicitly before processing
        IF (signals[i] IS NOT NULL) THEN
        -- Check if signal is not already in TELEMETRY_ARRAY
            IF (NOT ARRAY_CONTAINS(signals[i]::VARIANT,TELEMETRY_ARRAY)) THEN
            -- If it''s not in TELEMETRY_ARRAY, check if it''s not NULL and add to CHARGING_COLUMNS
                IF (CHARGING_COLUMNS != '''') THEN
                    CHARGING_COLUMNS := CHARGING_COLUMNS || '','' || ''IFNULL(MAX(T2.''|| signals[i] || ''), '''''''') AS '' || signals[i] || '' '';
                ELSE
                    CHARGING_COLUMNS := ''IFNULL(MAX(T2.''|| signals[i] || ''), '''''''') AS '' || signals[i] || '' '';
                END IF;
            END IF;
        END IF;
    END FOR;


    LET TELE_LEN :=length(TELEMETRY_COLUMNS);
    LET CHARG_LEN :=length(CHARGING_COLUMNS);

    -- Combine TELEMETRY_COLUMNS and CHARGING_COLUMNS into one variable
    ALL_COLUMNS := TELEMETRY_COLUMNS || '','' || CHARGING_COLUMNS;

    IF (RIGHT(ALL_COLUMNS, 1) = '','') THEN
        ALL_COLUMNS := LEFT(ALL_COLUMNS, LENGTH(ALL_COLUMNS) - 1);
    END IF;

    LET null_columns := '''';

     FOR i IN 0 TO ARRAY_SIZE(signals) - 1 DO
        IF (signals[i] IS NULL) THEN
            -- Append null column placeholder for null signals
            IF (null_columns != '''') THEN
                null_columns := null_columns || '', NULL AS '' || signal_names[i];
            ELSE
                null_columns := ''NULL AS '' || signal_names[i];
            END IF;
        END IF;
    END FOR;

    -- Remove the trailing comma and space from null_columns

    IF (RIGHT(null_columns, 2) = '', '') THEN
        null_columns := LEFT(null_columns, LENGTH(null_columns) - 2);
    END IF;

    IF (TELE_LEN > 0 AND CHARG_LEN > 0) THEN
    -- Case: Both TELEMETRY_COLUMNS and null_columns are present
        query := ''SELECT T1.VID, FLOOR(T1.SIGNAL_TIME / 60) * 60 AS SIGNAL_TIME, '' ||
              TELEMETRY_COLUMNS_FINAL || '', ''
              || CHARGING_COLUMNS ||
             CASE WHEN null_columns IS NOT NULL AND LENGTH(null_columns) > 0
                  THEN '', '' || null_columns
                  ELSE ''''
             END ||
             '', COUNT(1) OVER() AS TOTAL_ROWS '' ||
             ''FROM THOR_DATABASE.THOR_UAT.HMCL_CV_THOR_TELEMETRY T1 '' ||
             ''LEFT JOIN THOR_DATABASE.THOR_UAT.HMCL_CV_THOR_CHARGING_TELEMETRY T2 '' ||
             ''ON T1.signal_time = T2.signal_time '' ||
             ''WHERE T1.VID = '''''' || :VID || '''''' '' ||
             ''AND T1.signal_time BETWEEN '''''' || :start_time || '''''' AND '''''' || :end_time || '''''' '' ||
             ''GROUP BY T1.VID,FLOOR(T1.SIGNAL_TIME / 60) * 60 '' ||
             ''ORDER BY SIGNAL_TIME ASC '' ||
             ''LIMIT '' || :LIMIT || '' OFFSET '' || :OFFSET || '';'';


    ELSEIF (TELE_LEN > 0 AND CHARG_LEN = 0) THEN

    -- Case: Only TELEMETRY_COLUMNS has values

        query := ''SELECT VID,FLOOR(SIGNAL_TIME / 60) * 60 AS SIGNAL_TIME , '' || TELEMETRY_COLUMNS_FINAL ||
             CASE WHEN null_columns IS NOT NULL AND LENGTH(null_columns) > 0
                  THEN '', '' || null_columns
                  ELSE ''''
             END ||
             '', COUNT(1) OVER() AS TOTAL_ROWS '' ||
             ''FROM THOR_DATABASE.THOR_UAT.HMCL_CV_THOR_TELEMETRY T1 '' ||
             ''WHERE VID = '''''' || :VID || '''''' '' ||
             ''AND signal_time BETWEEN '''''' || :start_time || '''''' AND '''''' || :end_time || '''''' '' ||
             ''GROUP BY VID, FLOOR(SIGNAL_TIME / 60) * 60 '' ||
             ''ORDER BY SIGNAL_TIME ASC '' ||
             ''LIMIT '' || :LIMIT || '' OFFSET '' || :OFFSET || '';'';


    ELSEIF (CHARG_LEN > 0 AND TELE_LEN = 0) THEN
    -- Case: Only CHARGING_COLUMNS has values
        query := ''SELECT VID, FLOOR(SIGNAL_TIME / 60) * 60 AS SIGNAL_TIME, '' || CHARGING_COLUMNS ||
             CASE WHEN null_columns IS NOT NULL AND LENGTH(null_columns) > 0
                  THEN '', '' || null_columns
                  ELSE ''''
             END ||
             '', COUNT(1) OVER() AS TOTAL_ROWS '' ||
             ''FROM THOR_DATABASE.THOR_UAT.HMCL_CV_THOR_CHARGING_TELEMETRY T2 '' ||
             ''WHERE VID = '''''' || :VID || '''''' '' ||
             ''AND signal_time BETWEEN '''''' || :start_time || '''''' AND '''''' || :end_time || '''''' '' ||
             ''GROUP BY VID, FLOOR(SIGNAL_TIME / 60) * 60 '' ||
             ''ORDER BY SIGNAL_TIME ASC '' ||
             ''LIMIT '' || :LIMIT || '' OFFSET '' || :OFFSET || '';'';

    ELSE
    -- Case: No matching columns found
        query := ''SELECT ''''No matching column found'''' AS MESSAGE;'';
    END IF;

    -- return query;
    EXECUTE IMMEDIATE :query;
    result := (SELECT ARRAY_AGG(OBJECT_CONSTRUCT(*) )
               FROM TABLE(RESULT_SCAN(LAST_QUERY_ID())));
    RETURN result;
END;
';