CREATE OR REPLACE PROCEDURE THOR_DATABASE.THOR_QA.PROCESS_THOR_TELEMETRY("SIGNAL_LIST" VARCHAR, "RAW_TABLE" VARCHAR, "STAGE2_TABLE" VARCHAR, "TEMP_TABLE" VARCHAR, "FINAL_TABLE" VARCHAR)
RETURNS VARCHAR
LANGUAGE SQL
EXECUTE AS OWNER
AS '
DECLARE
    table_exists BOOLEAN DEFAULT FALSE;
    temp_table_exists BOOLEAN DEFAULT FALSE;
    res RESULTSET;
    intersect_vid_list ARRAY;
    flag_update_condition STRING;
    update_query STRING;
    pivot_query STRING;
    final_update_query STRING;
    insert_query STRING;
    intersect_sql STRING;
    flag_update_sql STRING;
    update_query_sql STRING;

BEGIN
    LET column_list VARCHAR := :SIGNAL_LIST;

    LET pivot_column_list VARCHAR := (
        SELECT ARRAY_TO_STRING(
            ARRAY_AGG('''''''' || TRIM(value) || ''''''''),
            '', ''
        )
        FROM TABLE(SPLIT_TO_TABLE(:column_list, '',''))
    );

    -- Check if Stage2 table exists (corrected concatenation)
    BEGIN
        EXECUTE IMMEDIATE ''DESCRIBE TABLE '' || :STAGE2_TABLE;
        SET table_exists := TRUE;
    EXCEPTION
        WHEN OTHER THEN
            SET table_exists := FALSE;
    END;

    -- If table does not exist, create it
    IF (table_exists = FALSE) THEN
        EXECUTE IMMEDIATE ''
        CREATE TABLE '' || :STAGE2_TABLE || '' (
            VID VARCHAR(16777216),
            TENANTID VARCHAR(16777216),
            YEAR NUMBER(4,0),
            MONTH NUMBER(2,0),
            DAY NUMBER(2,0),
            COLLECTIONEVENTTIME NUMBER(13,0),
            SIGNAL_VALUE VARCHAR(16777216),
            SIGNAL_TIME NUMBER(38,0),
            SIGNAL_NAME VARCHAR(16777216),
            FLAG NUMBER(1,0)
        )'';
    END IF;

    BEGIN
        EXECUTE IMMEDIATE ''DESCRIBE TABLE '' || :TEMP_TABLE;
        SET temp_table_exists := TRUE;
    EXCEPTION
        WHEN OTHER THEN
            SET temp_table_exists := FALSE;
    END;

    -- If Temp table does not exist, create it with the pivoted schema
    IF (temp_table_exists = FALSE) THEN
        LET create_temp_table_query STRING := ''
            CREATE TABLE '' || :TEMP_TABLE || '' AS
            SELECT
                VID,
                TENANTID,
                YEAR,
                MONTH,
                DAY,
                SIGNAL_TIME,
                '' || (
                    SELECT LISTAGG(''NULL AS "'' || UPPER(TRIM(value)) || ''"'', '', '')
                    FROM TABLE(SPLIT_TO_TABLE(:column_list, '',''))
                ) || ''
            FROM '' || :STAGE2_TABLE || ''
            WHERE 1=0'';  -- No rows, just schema

        EXECUTE IMMEDIATE create_temp_table_query;
    END IF;


    -- Step 3: Update Flag = 0 for existing records (skip for first load)
    IF (table_exists = TRUE) THEN
        EXECUTE IMMEDIATE ''
            UPDATE '' || :STAGE2_TABLE || ''
            SET FLAG = 0
            WHERE (VID, SIGNAL_NAME) IN (
                SELECT VID, SIGNAL_NAME
                FROM '' || :STAGE2_TABLE || ''
            )'';
    END IF;

    -- Step 2: Flatten and Explode Data into Stage 2
    LET dynamic_sql STRING := (
        WITH signal_list AS (
            SELECT TRIM(value) AS signal_name
            FROM TABLE(SPLIT_TO_TABLE(:SIGNAL_LIST, '',''))
        ),
        numbered_signals AS (
            SELECT
                signal_name,
                ROW_NUMBER() OVER (ORDER BY signal_name) AS rn
            FROM signal_list
        )
        SELECT
            ''INSERT INTO '' || :STAGE2_TABLE || '' WITH '' || LISTAGG(
                ''exploded_'' || rn || '' AS (
                    SELECT
                        VID,
                        TENANTID,
                        YEAR,
                        MONTH,
                        DAY,
                        COLLECTIONEVENTTIME,
                        f.value:value::VARCHAR(16777216) AS SIGNAL_VALUE,
                        FLOOR(f.value:time / 1000) AS SIGNAL_TIME,
                        '''''' || signal_name || '''''' AS SIGNAL_NAME,
                        1 AS FLAG
                    FROM '' || :RAW_TABLE || '',
                    LATERAL FLATTEN(input => '' || signal_name || '') f
                )''
                , '', '')
              || '' SELECT * FROM ('' || LISTAGG(''SELECT * FROM exploded_'' || rn, '' UNION ALL '') || '')''
        FROM numbered_signals
    );

    EXECUTE IMMEDIATE :dynamic_sql;

    -- Step 4: Find intersection (duplicates by VID & SIGNAL_TIME)
    intersect_sql := ''
        SELECT ARRAY_AGG(OBJECT_CONSTRUCT(''''VID'''', VID, ''''SIGNAL_TIME'''', SIGNAL_TIME)) AS result
        FROM (
            SELECT VID, SIGNAL_TIME
            FROM '' || STAGE2_TABLE || ''
            WHERE FLAG = 0
            INTERSECT
            SELECT VID, SIGNAL_TIME
            FROM '' || STAGE2_TABLE || ''
            WHERE FLAG = 1
        )'';
    res := (EXECUTE IMMEDIATE :intersect_sql);
    SELECT $1 INTO :intersect_vid_list FROM TABLE(RESULT_SCAN(LAST_QUERY_ID()));

    -- creating temp table
    EXECUTE IMMEDIATE ''
        CREATE OR REPLACE TEMP TABLE THOR_DATABASE.THOR_QA_STAGE.HMCL_CV_THOR_CHARGING_TELEMETRY_TEMP_KEYS (
            VID STRING,
            SIGNAL_TIME BIGINT
        )
    '';

    IF (ARRAY_SIZE(intersect_vid_list) > 0) THEN
        flag_update_sql := ''
          INSERT INTO THOR_DATABASE.THOR_QA_STAGE.HMCL_CV_THOR_CHARGING_TELEMETRY_TEMP_KEYS (VID, SIGNAL_TIME)
          SELECT VID, SIGNAL_TIME FROM '' || STAGE2_TABLE || ''
          WHERE FLAG = 0
          INTERSECT
          SELECT VID, SIGNAL_TIME FROM '' || STAGE2_TABLE || ''
          WHERE FLAG = 1
        '';
        EXECUTE IMMEDIATE :intersect_sql;

        -- Step 2: Update stage2 table flag=1 for existing records
        update_query_sql := ''
          UPDATE '' || STAGE2_TABLE || '' AS tgt
          SET FLAG = 1
          FROM THOR_DATABASE.THOR_QA_STAGE.HMCL_CV_THOR_CHARGING_TELEMETRY_TEMP_KEYS AS temp
          WHERE tgt.VID = temp.VID
            AND tgt.SIGNAL_TIME = temp.SIGNAL_TIME
        '';
        EXECUTE IMMEDIATE :update_query_sql;
    ELSE
        flag_update_condition := ''1=2''; -- No matches, so no updates; use a false condition
    END IF;

    EXECUTE IMMEDIATE ''TRUNCATE TABLE '' || :TEMP_TABLE;

    -- Step 6: Pivot Stage 2 Data to Pre-Target table
    pivot_query := ''
        INSERT INTO '' || :TEMP_TABLE || ''
        SELECT * FROM (
            SELECT VID, TENANTID, YEAR, MONTH, DAY, SIGNAL_VALUE, SIGNAL_TIME, SIGNAL_NAME
            FROM '' || :STAGE2_TABLE || ''
            WHERE FLAG = 1
        )
        PIVOT (
            MAX(SIGNAL_VALUE) FOR SIGNAL_NAME IN ('' || pivot_column_list || '')
        )'';

    EXECUTE IMMEDIATE pivot_query;

    -- Step 7: Merge from Pre-Target to Target table (Update)
    IF (ARRAY_SIZE(intersect_vid_list) > 0) THEN
        final_update_query := ''
            UPDATE '' || :FINAL_TABLE || '' AS target
            SET '' || (
                SELECT LISTAGG(''target.'' || TRIM(value) || '' = source.'' || TRIM(value), '', '')
                FROM TABLE(SPLIT_TO_TABLE(:column_list, '',''))
            ) || ''
            FROM (
                SELECT tgt.*
                FROM '' || :TEMP_TABLE || '' AS tgt
                JOIN THOR_DATABASE.THOR_QA_STAGE.HMCL_CV_THOR_CHARGING_TELEMETRY_TEMP_KEYS AS temp
                  ON tgt.VID = temp.VID
                 AND tgt.SIGNAL_TIME = temp.SIGNAL_TIME
            ) AS source
            WHERE target.VID = source.VID AND target.SIGNAL_TIME = source.SIGNAL_TIME'';

        EXECUTE IMMEDIATE final_update_query;

    END IF;

    -- Step 7: Merge from Pre-Target to Target table (Insert)
    insert_query := ''
        INSERT INTO '' || :FINAL_TABLE || '' (
            VID, TENANTID, YEAR, MONTH, DAY, SIGNAL_TIME, '' || :column_list || ''
        )
        SELECT
            VID, TENANTID, YEAR, MONTH, DAY, SIGNAL_TIME, '' || :column_list || ''
        FROM '' || :TEMP_TABLE || '' AS temp
        WHERE NOT EXISTS (
            SELECT 1
            FROM '' || :FINAL_TABLE || '' AS final
            WHERE final.VID = temp.VID AND final.SIGNAL_TIME = temp.SIGNAL_TIME
        )'';

    EXECUTE IMMEDIATE insert_query;


    -- Step 8: Delete Old Records from Stage 2 (older than 4 hours)
    EXECUTE IMMEDIATE ''
        DELETE FROM '' || :STAGE2_TABLE || ''
        WHERE COLLECTIONEVENTTIME < (EXTRACT(EPOCH FROM CURRENT_TIMESTAMP) * 1000 - 14400000)'';

    RETURN ''Processing completed, including Stage 2 cleanup'';
END;
';