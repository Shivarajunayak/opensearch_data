CREATE OR REPLACE PROCEDURE thor_database.THOR_QA.GET_Telemetry_Data(
    "VID" VARCHAR(60),
    "START_TIME" NUMBER(38,0),
    "END_TIME" NUMBER(38,0),
    "LIMIT" NUMBER(38,0),
    "OFFSET" NUMBER(38,0)
)
RETURNS TABLE()  
LANGUAGE SQL
AS
$$
DECLARE
    tenant_value STRING;
    tenant_var STRING;
    table_schema STRING;
    table_name STRING;
    table_name_tenant STRING;
    telemetry_data VARIANT;
    sql_text STRING;
    query_id STRING;
    
BEGIN
    table_schema := 'THOR_QA';
    table_name := 'HMCL_CV_THOR_TELEMETRY';
    table_name_tenant := 'hmcl_cv_thor_vehicle_live_status';
    table_name_tenant := table_schema || '.' || table_name_tenant;
    
    --1. Get tenant for the given VID
    sql_text := 'SELECT tenant FROM ' || table_name_tenant || ' WHERE vid = ''' || VID || ''' Limit 1' ;
    EXECUTE IMMEDIATE :sql_text;
    SELECT tenant INTO tenant_value FROM TABLE(RESULT_SCAN(LAST_QUERY_ID()));

    --2. Assign value to tenant_var
    tenant_var := CASE 
        WHEN tenant_value = 'EV-VIDA' THEN '_EV_VIDA'
        WHEN tenant_value = 'ICE-HERO' THEN '_ICE_HERO'
        WHEN tenant_value = 'ICE-HARLEY' THEN '_ICE_HARLEY'
        ELSE '_UNKNOWN'
    END;
    

    --3. sql text creation
    IF (tenant_var = '_UNKNOWN') THEN
        let text_unknown := 'No matching tenant found';
        sql_text := 
            'SELECT '''|| text_unknown ||''' AS MESSAGE;';
    ELSE
        table_name := table_schema || '.' || table_name || tenant_var;
        sql_text := 
            'SELECT ROW_NUMBER() OVER (ORDER BY signal_time) as "S No"
            ,COUNT(1) OVER() as "Total Count"
            ,*
             FROM ' || table_name || '
             WHERE vid = ''' || VID || ''' 
               AND signal_time >= ' || START_TIME || '
               AND signal_time <= ' || END_TIME || '
             ORDER BY signal_time ASC
             LIMIT ' || LIMIT || ' OFFSET ' || OFFSET;
    END IF;
    
    EXECUTE IMMEDIATE :sql_text;

    --4. Use RESULT_SCAN to get the data as array of objects
    LET results RESULTSET := (EXECUTE IMMEDIATE :sql_text);
    RETURN TABLE(results);
END;
$$;
