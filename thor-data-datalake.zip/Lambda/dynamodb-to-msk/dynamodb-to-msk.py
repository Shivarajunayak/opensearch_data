# pylint: disable=import-error
import socket
import json
import os
import logging
import traceback
from datetime import timedelta
from datetime import datetime as dt
from decimal import Decimal
import boto3
from kafka.errors import KafkaError
from kafka import KafkaProducer
from aws_msk_iam_sasl_signer import MSKAuthTokenProvider
from boto3.dynamodb.types import TypeDeserializer

# Configure logging
logger = logging.getLogger()
logger.setLevel(logging.INFO)


class MSKTokenProvider:
    """
    This class is for token autherisation for MSK cluster
    """

    def token(self):
        """
        This method to get the token value
        """
        try:
            region = os.environ["AWS_REGION"]
            token, _ = MSKAuthTokenProvider.generate_auth_token(region)
            return token
        except Exception as e:
            logger.error("An error occurred while getting token: %s", str(e))
            logger.error("Stack trace: %s", traceback.format_exc())
            raise


def topic_exists(admin, topic):
    """
    This method to find weather given topic exists or not
    """
    try:
        metadata = admin.list_topics()
        for t in metadata:
            if t.lower() == topic.lower():
                return True
        return False
    except Exception as e:
        logger.error("An error occurred while checking is topic exists : %s", str(e))
        logger.error("Stack trace: %s", traceback.format_exc())
        raise


def unmarshal_dynamodb_item(item, operation):
    """
    This method to convert dynamo stream object to python object
    """
    try:

        deserializer = TypeDeserializer()
        unmarshalled_item = {k: deserializer.deserialize(v) for k, v in item.items()}
        unmarshalled_item["operation"] = operation
        return unmarshalled_item
    except Exception as e:
        logger.error("An error occurred in unmarshelling method: %s", str(e))
        logger.error("Stack trace: %s", traceback.format_exc())
        raise


def custom_json_serializer(data):
    """
    This is to convert dynamo db json object to normal json object
    """

    def default_serializer(obj):
        if isinstance(obj, Decimal):
            return float(obj)
        if isinstance(obj, (list, tuple)):
            return [default_serializer(item) for item in obj]
        if isinstance(obj, dict):
            return {key: default_serializer(value) for key, value in obj.items()}
        return obj

    try:
        serialized_data = json.dumps(data, default=default_serializer).encode("utf-8")
        return serialized_data

    except Exception as e:
        logger.error("An error occurred in serialising the json data: %s", str(e))
        logger.error("Stack trace: %s", traceback.format_exc())
        raise


def send_sns_notification(subject, message, sns_secret_name):
    """
    This method to send SNS notification to mail
    """
    try:
        session = boto3.session.Session()
        client = session.client(
            service_name="secretsmanager", region_name=session.region_name
        )
        get_secret_value_response = client.get_secret_value(SecretId=sns_secret_name)
        secret = get_secret_value_response["SecretString"]
        secret_dict = json.loads(secret)
        sns_topic_arn = secret_dict["sns_topic_arn"]
        sns_client = boto3.client("sns", region_name=session.region_name)
        sns_client.publish(TopicArn=sns_topic_arn, Subject=subject, Message=message)
        logging.info("SNS publish response succeeded")
    except Exception as e:
        logging.error(f"Error sending notification using SNS service: {e}")
        logger.error("Stack trace: %s", traceback.format_exc())
        raise


def lambda_handler(event, context):
    """
    This is main method
    """
    sns_secret_name = os.getenv("sns_secret_name")
    bootstrap = os.environ["BOOTSTRAP"]
    table_topic_map = json.loads(os.environ["TABLE_TOPIC_MAP"])
    tp = MSKTokenProvider()

    try:
        logger.info("event data:%s", event)
        logger.info("Intialising kafka producer")
        # defining  kafka producer to  prodcue message to kafak topic
        # Defining value_serializer as custom json serialiser method to handle decimal types
        # Setting KAFKA_RETRIES to minimum 1

        producer = KafkaProducer(
            security_protocol="SASL_SSL",
            bootstrap_servers=bootstrap,
            sasl_mechanism="OAUTHBEARER",
            sasl_oauth_token_provider=tp,
            client_id="dynamodb-to-msk",
            value_serializer=custom_json_serializer,
            retries=int(os.getenv("KAFKA_RETRIES", 1)),
            acks=os.getenv("KAFKA_ACKS", "all"),
        )

        processed_records, failed_records = 0, 0

        logger.info("Processing each record in the event")

        # Looing thorugh batch of events and process one event at a time

        error_mesg = ""

        for record in event["Records"]:
            try:
                event_name = record["eventName"]

                if event_name not in ["INSERT", "MODIFY", "REMOVE"]:
                    logger.warning(f"Unknown event type: {event_name}")
                    continue

                operation = event_name

                # IF the record in dynamod table inserted or modified then we are taking new image for latest data
                # If the record deleted in dynamoDB table then we are taking the old image
                data = (
                    record["dynamodb"]["NewImage"]
                    if event_name in ["INSERT", "MODIFY"]
                    else record["dynamodb"]["OldImage"]
                )

                # Calling the method to convert Dynamo DB json object ot pytjon object

                data = unmarshal_dynamodb_item(data, operation)
                logger.info("Unmarshalled data: %s", data)

                # Getting the DynamoDB table name from the event in order to find the respectibe topic name from table to topic mapping

                table_name = record["eventSourceARN"].split("/")[1]
                topic_name = table_topic_map.get(table_name)
                logger.info(
                    "Publishing table :%s stream data to topic_name:%s",
                    table_name,
                    topic_name,
                )

                # Producing data to Kafka topic

                future = producer.send(topic_name, key=None, value=data)

                future.get(timeout=10)  # Wait for the send to complete with a timeout
                processed_records += 1
            except KafkaError as ke:
                logger.info("Kafka error : %s", str(ke))
                error_mesg += "\n" + str(ke)
                failed_records += 1
                logger.error("Stack trace: %s", traceback.format_exc())
            except Exception as e:
                logger.info("Error processing record: %s", str(e))
                error_mesg += "\n" + str(e)
                failed_records += 1
                logger.error("Stack trace: %s", traceback.format_exc())
    except Exception as e:
        logger.error("An error occurred in main method : %s", str(e))
        logger.error("Stack trace: %s", traceback.format_exc())
        message = f"Lambda function failed .\
             \n\n cloudwatch log strean name : {context.log_stream_name}\
              \n\n Please find the stack trace information below \n\n {traceback.format_exc()}"
        send_sns_notification(
            "Lambda function dynamodb-to-msk Failed",
            message,
            sns_secret_name,
        )

        raise  # Re-raise the exception to mark the Lambda execution as failed

    finally:
        # Ensure all messages are sent and producer is closed
        if "producer" in locals():
            try:
                producer.flush(timeout=10)
                producer.close(timeout=10)
            except Exception as e:
                logger.info("Error closing Kafka producer: %s", str(e))
                logger.error("Stack trace: %s", traceback.format_exc())

        # sending notification mail if processing failed for records

        if failed_records > 0:
            message = f"Lambda function dynamodb-to-msk Succeeded but few records processing failed\
                \n\n Failed to process {failed_records} records \
                \n\n Please find the error information below \
                \n\n {error_mesg} \
                \n\n Please check cloudwatch logs for moredetails \
                \n\n cloudwatch log strean name : {context.log_stream_name} "

            send_sns_notification(
                "Lambda function dynamodb-to-msk Succeeded but few records processing failed",
                message,
                sns_secret_name,
            )

    return {
        "statusCode": 200,
        "body": json.dumps(
            f"Processed {processed_records} records, Failed {failed_records} records"
        ),
    }
