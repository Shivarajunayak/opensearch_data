"""
This lambda function to get failure infirmation from glue error 
cloud watch logs and send email notification 
"""

# pylint: disable=import-error
import logging
import os
import json
import traceback
from datetime import datetime, timezone
import boto3


logger = logging.getLogger()
logger.setLevel(logging.INFO)
# Initialize AWS clients
logs_client = boto3.client("logs")


def epoch_millis_to_timestamp(epoch_millis):
    """
    This method Convert epoch milliseconds to seconds
    """
    try:

        epoch_seconds = epoch_millis / 1000.0

        # Create a datetime object from the epoch time in UTC
        utc_dt = datetime.fromtimestamp(epoch_seconds, tz=timezone.utc)

        # Format the datetime as a string
        timestamp_str = utc_dt.strftime("%Y-%m-%d %H:%M:%S.%f")[
            :-3
        ]  # Format to include milliseconds

        return timestamp_str
    except Exception as e:
        logging.error(f"Error in getting epoch millis to timestamp: {e}")
        traceback.print_exc()
        raise


def get_traceback_messages(log_group, log_stream_name):
    """
    This method to get the stack trace information from cloudwath logstream
    based on Traceback string
    """
    try:
        messages = []
        next_token = None

        while True:
            # Prepare parameters for the filter_log_events call
            params = {
                "logGroupName": log_group,
                "logStreamNames": [log_stream_name],
                "filterPattern": "?Traceback ?Stack ?Trace",
            }

            if next_token:
                params["nextToken"] = next_token

            # Fetch log events with pagination
            response = logs_client.filter_log_events(**params)

            # Process log events
            for log_event in response.get("events", []):
                message = log_event["message"]
                if "Traceback" in message or "Stack Trace" in message:
                    messages.append(message)

            # Check if there are more pages
            next_token = response.get("nextToken")
            if not next_token:
                break  # Exit the loop if no more tokens are present

        return messages
    except Exception as e:
        logging.error(f"Error in getting traceback messages: {e}")
        traceback.print_exc()
        raise


def send_sns_notification(subject, message, sns_secret_name):
    try:
        session = boto3.session.Session()
        client = session.client(
            service_name="secretsmanager", region_name=session.region_name
        )
        get_secret_value_response = client.get_secret_value(SecretId=sns_secret_name)
        secret = get_secret_value_response["SecretString"]
        secret_dict = json.loads(secret)
        sns_topic_arn = secret_dict["sns_topic_arn"]
        sns_client = boto3.client("sns", region_name=session.region_name)
        sns_client.publish(TopicArn=sns_topic_arn, Subject=subject, Message=message)
        logging.info("SNS publish response succeeded")
    except Exception as e:
        logging.error(f"Error sending notification using SNS service: {e}")
        traceback.print_exc()
        raise


def lambda_handler(event, context):
    """
    AWS lambda function handler
    """
    # Define time range for searching logs (last 15 minutes)
    # end_time = int(datetime.utcnow().timestamp() * 1000)
    # start_time = end_time - (15 * 60 * 1000)  # 15 minutes ago in milliseconds

    try:
        logger.info("Lambda function processing started")
        # SNS Topic ARN

        logger.info("Reading environment variables")
        sns_secret_name = os.getenv("sns_secret_name")
        log_group = os.getenv("LOG_GROUP")
        result_path = os.getenv("STEP_FUNC_RESULT_PATH")

        if not sns_secret_name or not log_group or not result_path:
            logger.error(
                "Environment variables sns_topic_arn, log_group, or errorinfo are not set."
            )
            return
        logger.info("Printing environemnt variables")
        logger.info("SNS topic ARN: %s", sns_secret_name)
        logger.info("log group name: %s", log_group)
        logger.info("result path of step function: %s", result_path)

        errorinfo = event.get(result_path)
        cause = json.loads(errorinfo.get("Cause"))

        log_stream_name = cause.get("Id")
        job_name = cause.get("JobName")
        failed_time_epoch = cause.get("CompletedOn")
        failed_time = epoch_millis_to_timestamp(failed_time_epoch)

        logger.info("log_stream_name: %s", log_stream_name)
        messages = get_traceback_messages(log_group, log_stream_name)

        subject = "Glue Job " + job_name + " Failed"
        # Send SNS notification if any stack trace found
        if not messages:
            messages = [
                "Stack trace information not found in the error log. Please check the cloudwatch logs for detail errors"
            ]

        if messages:
            logger.info("Publishing messages to SNS topic with suject and body")

            sns_message = (
                f"Glue Job {job_name} Failed at {failed_time}\n\n"
                + f"Please find more details on this log stream {log_stream_name} under this log group {log_group}\n\n"
                + "Stack trace details: \n\n"
                + "\n\n".join(messages)
            )
            sns_message_size = len(sns_message.encode("utf-8"))
            logger.info("message body size in KB:%s", sns_message_size / 1024)
            if sns_message_size >= 256 * 1024:
                logger.info("messages size is greater than 256KB so truncating it")
                sns_message = sns_message[
                    :250000
                ]  # 250 KB to ensure we stay within the 256 KB limit

            send_sns_notification(
                subject,
                sns_message,
                sns_secret_name,
            )

        else:
            logger.info("No messages were found")

        return {
            "statusCode": 200,
            "body": json.dumps(f"Found {len(messages)} stack trace messages."),
        }
    except Exception as e:
        logger.error("failed with Error: %s", str(e))
        return {"statusCode": 500, "body": json.dumps(f"Error occurred: {str(e)}")}
