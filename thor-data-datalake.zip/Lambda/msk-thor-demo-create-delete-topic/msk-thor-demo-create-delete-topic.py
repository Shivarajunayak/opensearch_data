from kafka.admin import KafkaAdminClient, NewTopic
import socket
import boto3
from aws_msk_iam_sasl_signer import MSKAuthTokenProvider
from kafka.admin.new_partitions import NewPartitions
import os
from datetime import timedelta,datetime as dt 
import sys,traceback


class MSKTokenProvider():
    def token(self):
        REGION = os.environ['AWS_REGION']
        token, _ = MSKAuthTokenProvider.generate_auth_token(REGION)
        return token

tp = MSKTokenProvider()

def topic_exists(admin, topic):
    metadata = admin.list_topics()
    for t in metadata:
        if t.lower()==topic.lower():
            return True
    return False

def create_topic(BOOTSTRAP, topic_name,PARTITIONS,REPLICATION,DELETE_FLG):

    admin_client = KafkaAdminClient(
    security_protocol='SASL_SSL',
    bootstrap_servers=BOOTSTRAP, 
    sasl_mechanism='OAUTHBEARER',
    sasl_oauth_token_provider=tp,    
    client_id=socket.gethostname(),
    )

    topic_list = []
    
    ##create topic if does not exist
        
    if not topic_exists(admin_client,topic_name):

        topic_list.append(NewTopic(name=topic_name, num_partitions=int(PARTITIONS), replication_factor=int(REPLICATION)))
        response=admin_client.create_topics(new_topics=topic_list, validate_only=False)
        str_ret='topic created '+ topic_name
        return str_ret
    
    ##delete topic
    
    elif topic_exists(admin_client,topic_name) and str(DELETE_FLG).upper()=='Y':
        topic_list_del=[]
        topic_list_del.append(topic_name)
        rsp_del =admin_client.delete_topics(topics=topic_list_del, timeout_ms=None)
        str_ret='topic deleted ' + topic_name
        return str_ret
    
    
    ##update topic partition   
    
    else:
        topic_metadata=admin_client.describe_topics()
        i=0
        
        for t in iter(topic_metadata):
            #print(t)
            if topic_name.lower() in str(t).lower():
                print(t)
                for val in t['partitions']:
                    i=i+1
                    
        if int(PARTITIONS)> i and i>0 :
            rsp = admin_client.create_partitions({topic_name: NewPartitions(int(PARTITIONS))})
            str_ret='partition updated to '+ PARTITIONS
            return str_ret
        else:
            str_ret='Nothing to update, topic exists'
            return str_ret
    
def lambda_handler(event, context):
    
    try:
    
        BOOTSTRAP = event['BOOTSTRAP']
        TOPIC_NAME = event['TOPIC_NAME']
        PARTITIONS = event['PARTITIONS']
        REPLICATION = event['REPLICATION']
        DELETE_FLG = event['DELETE_FLG']
    
        val_ret=create_topic(BOOTSTRAP,TOPIC_NAME,PARTITIONS,REPLICATION,DELETE_FLG)
    
    except:
        return {
            'statusCode': 500,
            'body': 'Lambda hmcl-cv-dev-msk-thor-demo-create-delete-topic failed !',
            'errorMessage': str(sys.exc_info()) + "\n\r" + str(traceback.extract_stack())
        }
  
    return {
        'statusCode': 200,
        'body': val_ret
    }