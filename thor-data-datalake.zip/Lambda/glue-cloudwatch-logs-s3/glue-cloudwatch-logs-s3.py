"""
This function to archive cloud watch logs to s3
"""

import time
import datetime
import logging
import traceback
import os
import gzip
import json
import re
import boto3


# Initialize clients
logs_client = boto3.client("logs")
s3_client = boto3.client("s3")

# Configure logging
logger = logging.getLogger()
logger.setLevel(logging.INFO)
job_name_runid_map = {}


def get_start_time_epoch(log_fetch_interval):
    """
    This method to get the start time whihc will be reference to archive the streams
    """
    try:
        # Get the current time and subtract 4 hours to get the timestamp
        four_hours_ago = datetime.datetime.now(
            datetime.timezone.utc
        ) - datetime.timedelta(hours=int(log_fetch_interval))
        return int(four_hours_ago.timestamp() * 1000)  # Convert to milliseconds
    except Exception as e:
        logger.error("An error occurred getting log fetch interval: %s", str(e))
        logger.error("Stack trace: %s", traceback.format_exc())
        raise


def fetch_and_process_log_streams(
    log_group_name, s3_bucket, s3_prefix, log_fetch_interval
):
    """
    This methid fetches the stream files from start time and process move the each stream to s3
    """
    start_time_epoch = get_start_time_epoch(log_fetch_interval)
    next_token = None
    recent_streams_found = False
    older_parent_streams = False
    older_child_streams = False

    log_group_suffix = log_group_name.split("/")[-1]

    while True:
        try:
            params = {
                "logGroupName": log_group_name,
                "orderBy": "LastEventTime",
                "descending": True,
            }
            if next_token:
                params["nextToken"] = next_token

            response = logs_client.describe_log_streams(**params)
            log_streams = response.get("logStreams", [])
            logger.info("Fetched %s log streams", len(log_streams))

            parent_streams = []
            child_streams = []

            for stream in log_streams:
                underscore_count = stream["logStreamName"].count("_")
                if underscore_count == 1 and log_group_suffix == "output":
                    parent_streams.append(stream)
                else:
                    child_streams.append(stream)
            if not older_parent_streams and len(parent_streams) > 0:
                for stream in parent_streams:
                    last_event_time = stream.get("lastEventTimestamp", 0)

                    if last_event_time < start_time_epoch:
                        logger.info(
                            "Log stream %s is older than \
                            %s. Stopping further processing.",
                            stream["logStreamName"],
                            start_time_epoch,
                        )
                        older_parent_streams = (
                            True  # Stop processing further log streams
                        )
                        break

                    # Process the log stream if it's recent
                    process_log_stream(
                        log_group_name, stream, s3_bucket, s3_prefix, True
                    )
                    recent_streams_found = True
            else:
                older_parent_streams = True

            if not older_child_streams:
                for stream in child_streams:
                    last_event_time = stream.get("lastEventTimestamp", 0)

                    if last_event_time < start_time_epoch:
                        logger.info(
                            "Log stream %s is older than \
                                %s.Stopping further processing.",
                            stream["logStreamName"],
                            start_time_epoch,
                        )
                        older_child_streams = (
                            True  # Stop processing further log streams
                        )
                        break

                    # Process the log stream if it's recent
                    process_log_stream(
                        log_group_name, stream, s3_bucket, s3_prefix, False
                    )
                    recent_streams_found = True

            if older_parent_streams and older_child_streams:
                logger.info("Stop processing further logstreams")
                return
            next_token = response.get("nextToken")
            if not next_token:
                break

            time.sleep(1)

        except logs_client.exceptions.ClientError as e:
            logger.error("ClientError: %s", str(e))
            time.sleep(5)
        except Exception as e:
            logger.error(
                "An error occurred in fetch_and_process_log_streams: %s", str(e)
            )
            logger.error("Stack trace: %s", traceback.format_exc())
            raise

    if not recent_streams_found:
        logger.info("No recent log streams found.")


def fetch_log_events(log_group_name, log_stream_name):
    """
    This method to getch the event messages from the stream
    """
    log_events = []
    next_token = None

    while True:
        try:
            params = {
                "logGroupName": log_group_name,
                "logStreamName": log_stream_name,
                "startFromHead": True,
            }
            if next_token:
                params["nextToken"] = next_token

            response = logs_client.get_log_events(**params)
            log_events.extend(response.get("events", []))
            logger.info(
                "Fetched %s log events from %s",
                len(response.get("events", [])),
                log_stream_name,
            )

            next_token = response.get("nextForwardToken")
            if next_token == response.get("nextForwardToken"):
                break

            time.sleep(1)

        except logs_client.exceptions.ClientError as e:
            logger.error(
                "ClientErrorin fetching log event for stream :%s and error is: %s",
                log_stream_name,
                str(e),
            )
            logger.error("Stack trace: %s", traceback.format_exc())
            time.sleep(5)

        except Exception as e:
            logger.error(
                "An error occurred in fetching log events for stream :%s and error is : %s",
                log_stream_name,
                str(e),
            )
            logger.error("Stack trace: %s", traceback.format_exc())
            raise

    return log_events


def process_log_stream(log_group_name, log_stream, s3_bucket, s3_prefix, is_parent):
    """
    This method writes event messages of the stream to
    S3 with same stream name under hourly partions
    """
    try:
        stream_name = log_stream["logStreamName"]
        logger.info("Processing log stream: %s", stream_name)

        log_events = fetch_log_events(log_group_name, stream_name)

        log_data = json.dumps(log_events)

        log_group_suffix = log_group_name.split("/")[-1]

        job_name = "default"
        if is_parent and log_group_suffix == "output":
            for event in log_events:
                match = re.search(r"job_name=\s*(\S+)", event["message"])
                if match:
                    job_name = match.group(1)
                    job_name_runid_map[stream_name] = job_name

                    logger.info("job_name : %s", job_name)
                    break
        else:
            match = re.match(r"^([^_]+_[^_-]+)", stream_name)
            if match:
                parent_stream_name = match.group(1)
                job_name = job_name_runid_map.get(parent_stream_name, "default")
            else:
                parent_stream_name = stream_name
                job_name = job_name_runid_map.get(parent_stream_name, "default")

        epoch_seconds = log_stream["lastEventTimestamp"] / 1000.0
        dt = datetime.datetime.fromtimestamp(epoch_seconds, tz=datetime.timezone.utc)

        year = dt.year
        month = dt.month
        day = dt.day
        hour = dt.hour
        s3_key = f"{s3_prefix}/{job_name}/{year}/{month}/{day}/{hour}/{log_group_suffix}/{log_stream['logStreamName']}"

        s3_client.put_object(
            Bucket=s3_bucket,
            Key=s3_key,
            Body=log_data,
            ContentType="application/json",
        )

        logger.info(
            "Log events from %s have been uploaded to %s.",
            log_stream["logStreamName"],
            s3_key,
        )
    except Exception as e:
        logger.error(
            "An error occurred in processing logstrem for stream :%s and error is : %s",
            log_stream,
            str(e),
        )
        logger.error("Stack trace: %s", traceback.format_exc())
        raise


def send_sns_notification(subject, message, sns_secret_name):
    try:
        session = boto3.session.Session()
        client = session.client(
            service_name="secretsmanager", region_name=session.region_name
        )
        get_secret_value_response = client.get_secret_value(SecretId=sns_secret_name)
        secret = get_secret_value_response["SecretString"]
        secret_dict = json.loads(secret)
        sns_topic_arn = secret_dict["sns_topic_arn"]
        sns_client = boto3.client("sns", region_name=session.region_name)
        sns_client.publish(TopicArn=sns_topic_arn, Subject=subject, Message=message)
        logging.info("SNS publish response succeeded")
    except Exception as e:
        logging.error("Error sending notification using SNS service: %s", e)
        logger.error("Stack trace: %s", traceback.format_exc())
        raise


def lambda_handler(event, context):
    """
    AWS lambda function handler
    """
    sns_secret_name = os.getenv("sns_secret_name")
    log_group_name = os.getenv("LOG_GROUP_NAME")
    s3_bucket = os.getenv("S3_BUCKET")
    s3_prefix = os.getenv("S3_PREFIX")
    log_fetch_interval = os.getenv("LOG_FETCH_INTERVAL")
    try:

        log_group_name = json.loads(log_group_name)

        if (
            not log_group_name
            or not s3_bucket
            or not s3_prefix
            or not log_fetch_interval
            or not sns_secret_name
        ):
            logger.error(
                "Environment variables LOG_GROUP_NAME, S3_BUCKET, or S3_PREFIX, log_fetch_interval, sns_secret_name are not set."
            )
            return

        logger.info("Log Group: %s", log_group_name)
        logger.info("S3 Bucket: %s", s3_bucket)
        logger.info("S3 Prefix: %s", s3_prefix)
        logger.info("Log fetch interval: %s", log_fetch_interval)
        logger.info("sns secret name: %s", sns_secret_name)

        for log_group_name in log_group_name:

            logger.info("processing for log group:%s", log_group_name)
            fetch_and_process_log_streams(
                log_group_name, s3_bucket, s3_prefix, log_fetch_interval
            )
    except Exception as e:
        logger.error("An error occurred in main method : %s", str(e))
        logger.error("Stack trace: %s", traceback.format_exc())
        message = f"Lambda function failed . \
            \n\n cloudwatch log strean name : {context.log_stream_name}\
             \n\n  Please find the stack trace information below \n\n {traceback.format_exc()}"
        send_sns_notification(
            f"Lambda function glue-cloudwatch-logs-s3 Failed",
            message,
            sns_secret_name,
        )

        raise
