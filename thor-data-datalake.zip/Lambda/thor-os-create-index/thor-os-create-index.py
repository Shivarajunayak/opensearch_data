import requests
import awswrangler as wr
import json
import boto3
import sys,traceback
import urllib
from urllib.error import HTTPError


def lambda_handler(event, context):
    
    try:
    
        index_name = event['index_name']
        host_name = event['host_name']
        secret_name = event['secret_name']
        
        secrets_client = boto3.client('secretsmanager')
        secret_response = secrets_client.get_secret_value(SecretId=secret_name).get('SecretString')
        secret_list = json.loads(secret_response)
        username_inp = secret_list.get('opensearch.net.http.auth.user')
        password_inp = secret_list.get('opensearch.net.http.auth.pass')
    
        os_connection=wr.opensearch.connect(host=host_name,port=443,username=username_inp,password=password_inp)
        
        response=wr.opensearch.create_index(client=os_connection,index=index_name)
        
        if "status" in response:
    
            if response['status'] == 200:
                str_ret="Index "+index_name+" created successfully."
                
            else:
                str_ret=f"Index: {response['error']}"
        
        elif "acknowledged" in response:
            str_ret="Index created "+index_name
            
    except:
        return {
            'statusCode': 500,
            'body': 'Lambda hmcl-cv-dev-thor-os-create-index failed !',
            'errorMessage': str(sys.exc_info()) + "\n\r" + str(traceback.extract_stack())
        }
  
    return {
        'statusCode': 200,
        'body': str_ret
    }