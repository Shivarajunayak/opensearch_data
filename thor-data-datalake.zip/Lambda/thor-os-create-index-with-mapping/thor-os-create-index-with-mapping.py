import requests
import boto3
from requests.auth import HTTPBasicAuth
import json
from requests_aws4auth import AWS4Auth
import sys, traceback


# Function to create a index mapping
def create_index(OPENSEARCH_ENDPOINT, INDEX_NAME, payload, auth):

    url = f"{OPENSEARCH_ENDPOINT}/{INDEX_NAME}"

    headers = {"Content-Type": "application/json"}

    # response = requests.put(url, auth = HTTPBasicAuth(username, password),headers=headers)
    response = requests.put(url, json=payload, auth=auth, headers=headers)
    str_ret = ""

    if response.status_code == 200:
        str_ret = "Data index " + INDEX_NAME + " created successfully."

    else:
        str_ret = f"Data index: {response.text}"
    return str_ret


def lambda_handler(event, context):

    try:

        OPENSEARCH_ENDPOINT = event["OPENSEARCH_ENDPOINT"]
        opensearch_name = event["opensearch_name"]

        INDEX_NAME = opensearch_name
        region = event["region"]
        service = event["service"]
        secret_name = event["secret_name"]
        payload_inp = event["payload"]

        payload_str = str(payload_inp).replace("'", '"')

        payload = json.loads(payload_str)

        secrets_client = boto3.client("secretsmanager")
        secret_response = secrets_client.get_secret_value(SecretId=secret_name).get(
            "SecretString"
        )
        secret_list = json.loads(secret_response)
        username = secret_list.get("opensearch.net.http.auth.user")
        password = secret_list.get("opensearch.net.http.auth.pass")
        auth = HTTPBasicAuth(username, password)
        # AWS credentials can be managed using boto3
        session = boto3.Session()

        val_ret_2 = create_index(OPENSEARCH_ENDPOINT, INDEX_NAME, payload, auth)

    except:
        return {
            "statusCode": 500,
            "body": "Lambda failed !",
            "errorMessage": str(sys.exc_info())
            + "\n\r"
            + str(traceback.extract_stack()),
        }

    return {"statusCode": 200, "body": val_ret_2}
