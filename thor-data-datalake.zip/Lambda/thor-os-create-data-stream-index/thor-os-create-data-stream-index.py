import requests
import boto3
from requests.auth import HTTPBasicAuth
import json
from requests_aws4auth import AWS4Auth
import sys,traceback

# Function to create an index template with the given index structure
def create_index_template(OPENSEARCH_ENDPOINT,INDEX_TEMPLATE_NAME,payload,auth):

            url = f"{OPENSEARCH_ENDPOINT}/_index_template/{INDEX_TEMPLATE_NAME}"
        
            headers = {
                'Content-Type': 'application/json'
            }
            
            str_ret=''
            response = requests.put(url, json=payload, auth = auth,headers=headers)
        
            if response.status_code == 200:
                str_ret="Data template "+INDEX_TEMPLATE_NAME+" created successfully."
                
            else:
                str_ret=f"Index template:{response.text}"
            
            return str_ret
        
# Function to create a data stream
def create_data_stream(OPENSEARCH_ENDPOINT,DATA_STREAM_NAME,auth):
    
            url = f"{OPENSEARCH_ENDPOINT}/_data_stream/{DATA_STREAM_NAME}"
        
            headers = {
                'Content-Type': 'application/json'
            }
        
            #response = requests.put(url, auth = HTTPBasicAuth(username, password),headers=headers)
            response = requests.put(url,auth = auth,headers=headers)
            str_ret=''
            
            if response.status_code == 200:
                str_ret="Data stream "+DATA_STREAM_NAME+" created successfully."
                
            else:
                 str_ret=f"Data stream: {response.text}"
            return str_ret
            
def lambda_handler(event, context):
    
    try:
    
        OPENSEARCH_ENDPOINT = event['OPENSEARCH_ENDPOINT']
        opensearch_name = event['opensearch_name']
        
        INDEX_TEMPLATE_NAME = opensearch_name+'template'
        DATA_STREAM_NAME = opensearch_name+'stream'
        region = event['region']
        service = event['service']
        secret_name = event['secret_name']
        payload_inp = event['payload']
        
        payload_str = str(payload_inp).replace("opensearch_name", str(opensearch_name)+"*").replace("'",'"')
        
        payload=json.loads(payload_str)
        
        secrets_client = boto3.client('secretsmanager')
        secret_response = secrets_client.get_secret_value(SecretId=secret_name).get('SecretString')
        secret_list = json.loads(secret_response)
        username = secret_list.get('opensearch.net.http.auth.user')
        password = secret_list.get('opensearch.net.http.auth.pass')
        auth=HTTPBasicAuth(username,password) 
        # AWS credentials can be managed using boto3
        session = boto3.Session()
        

        val_ret_1=create_index_template(OPENSEARCH_ENDPOINT,INDEX_TEMPLATE_NAME,payload,auth)
        val_ret_2=create_data_stream(OPENSEARCH_ENDPOINT,DATA_STREAM_NAME,auth)

    except:
        return {
            'statusCode': 500,
            'body': 'Lambda hmcl-cv-dev-thor-os-create-data-stream-index failed !',
            'errorMessage': str(sys.exc_info()) + "\n\r" + str(traceback.extract_stack())
        }
  
    return {
        'statusCode': 200,
        'body': val_ret_1+ ' '+val_ret_2
    }