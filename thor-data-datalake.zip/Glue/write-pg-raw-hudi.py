
# pylint: disable=import-error, invalid-name, too-many-locals, too-many-statements, broad-except
import sys
import logging
from datetime import datetime
import boto3
import json
import yaml
import time
import traceback
import psycopg2
import re

# import logging

from awsglue.utils import getResolvedOptions
from awsglue.context import GlueContext
from awsglue.job import Job
from pyspark.sql import SparkSession
from pyspark.sql import functions as F
from pyspark.sql.functions import lit 

from hmcl_cv_common_utilities import log_audit,get_cloudwatch_url,send_sns_notification,load_yaml_config,fetch_postgres_credentials,validate_audit_table_with_s3_partition,get_watermark_timestamp,update_watermark_file,initialize_spark_session,get_postgres_jdbc_properties,format_watermark

logging.basicConfig(
    level=logging.INFO, format="%(asctime)s - %(name)s - %(levelname)s - %(message)s"
)

postgresl_driver = "org.postgresql.Driver"

#Allow only alphanumeric characters and underscores in identifiers.
def sanitize_identifier(identifier):
    if not re.match(r'^[a-zA-Z_][a-zA-Z0-9_]*$', identifier):
        raise ValueError(f"Invalid identifier: {identifier}")
    return identifier



def get_column_data_type(db_host,db_port, db_name, db_user, db_password,source_schema,source_table, db_table, updated_time_col):
    """
    Get the data type of a specific column in the PostgreSQL table.
    """
    try:
         # Split db_table into schema and table names
        if '.' in db_table:
            source_schema, source_table = db_table.split('.')
        logging.info(f"db_host: {db_host}, db_port: {db_port}, db_name: {db_name}, db_user: {db_user}")
        # Build the correct connection string for psycopg2
        conn = psycopg2.connect(
            host=db_host,
            port=db_port,
            dbname=db_name,
            user=db_user,
            password=db_password
        )

        cursor = conn.cursor()
        query = f"""
            SELECT data_type
            FROM information_schema.columns
            WHERE table_schema = '{source_schema}' 
              AND table_name = '{source_table}' 
              AND column_name = '{updated_time_col}';
        """
        cursor.execute(query)
        result = cursor.fetchone()
        if result:
            data_type = result[0]
            return data_type
        else:
            raise ValueError(f"Column {updated_time_col} not found in table {db_table}.")
    except Exception as e:
        logging.error(f"Error getting column data type: {str(e)}")
        raise
    finally:
        cursor.close()
        conn.close()
 

def read_postgres_table(spark, jdbc_url, source_schema, source_table, db_table, latest_watermark, db_user, db_password, postgres_driver, updated_time_col, db_host, db_port, db_name, timestamp_dtype):
    """
    Read data incrementally from PostgreSQL using a timestamp or bigint column, handling both cases dynamically.
    """
    try:
        # Get JDBC properti
        jdbc_properties = get_postgres_jdbc_properties(db_user, db_password, postgres_driver)

        # Sanitize table and column names
        schema = db_table.split('.')[0]
        table_name = db_table.split('.')[1]
        schema = sanitize_identifier(schema)
        table_name = sanitize_identifier(table_name)
        updated_time_col = sanitize_identifier(updated_time_col)
        logging.info(f"Sanitized table name: {db_table}, column name: {updated_time_col}")

        # Fetch the data type of the updated_time_col
        data_type = get_column_data_type(db_host, db_port, db_name, db_user, db_password, source_schema, source_table, db_table, updated_time_col)
        logging.info(f"Data type of {updated_time_col}: {data_type}")

        # Format the watermark based on the column type
        watermark_condition = format_watermark(latest_watermark, data_type, timestamp_dtype)
        logging.info(f"Watermark condition: {watermark_condition}")

        # Construct the SQL query
        query = f"(SELECT * FROM {db_table} WHERE {updated_time_col} >= {watermark_condition}) AS temp"
        logging.info(f"Constructed SQL query: {query}")

        # Execute the query and fetch data
        df = spark.read.jdbc(url=jdbc_url, table=query, properties=jdbc_properties)
        new_pg_rows = df.count()
        logging.info(f"Fetched {new_pg_rows} rows from PostgreSQL")

        return df

    except Exception as e:
        logging.exception(f"Error fetching PostgreSQL data for table {db_table} and column {updated_time_col}: {str(e)}")
        raise

def fetch_schemas(spark, source_table_name, landing_table, jdbc_url, db_user, db_password, postgresl_driver):
    """
    Fetches schemas from PostgreSQL and compares them with landing table schema.
    """
    hudi_columns = {
        '_hoodie_record_key', '_hoodie_commit_seqno', '_hoodie_commit_time',
        '_hoodie_file_name', '_hoodie_partition_path', '_hoodie_commit_time_land_cal',
        'p_year', 'p_month', 'p_day', 'Master_tenant'
    }
    
    # Fetch schema from PostgreSQL
    jdbc_properties = {"user": db_user, "password": db_password, "driver": postgresl_driver}
    query = f"(SELECT * FROM {source_table_name} LIMIT 1) AS temp"
    df = spark.read.jdbc(url=jdbc_url, table=query, properties=jdbc_properties)
    
    pg_table_columns = set([col_schema.name for col_schema in df.schema])
    landing_columns = set(landing_table.columns) - hudi_columns
    
    return pg_table_columns, landing_columns


def compare_schemas(pg_table_columns, landing_columns):
    """
    Compares the schemas and identifies missing and new columns.
    """
    missing_columns = list(landing_columns - pg_table_columns)
    new_columns = list(pg_table_columns - landing_columns)
    return missing_columns, new_columns


def handle_schema_mismatch(spark, job_name, source_table_name, target_table_name, start_time, audit_path, audit_table, sns_secret_name, missing_columns,region_name):
    """
    Handles schema mismatches by logging and raising a notification.
    """
    schema_status = "Aborted"
    error_message = f"Missing columns in source table: {', '.join(missing_columns)}"
    logging.error(error_message)
    
    # Log the error
    end_time = datetime.now()
    duration = (end_time - start_time).seconds
    log_audit(spark, job_name, source_table_name, "source_type", target_table_name, "target_type", schema_status, start_time, end_time, None, audit_path, audit_table)
    
    # Send SNS notification
    subject = f"Job {job_name} - Aborted for table {source_table_name} - Schema Validation Failed"
    send_sns_notification(subject[:98] + '..' if len(subject) > 100 else subject, error_message, sns_secret_name,region_name)
    
    raise ValueError(error_message)


def handle_new_columns(sns_secret_name, job_name, source_table_name, new_columns,region_name):
    """
    Handles the detection of new columns by sending a notification.
    """
    schema_status = "New columns detected"
    new_columns_message = f"New columns detected in source table: {', '.join(new_columns)}"
    logging.warning(new_columns_message)
    
    # Send SNS notification
    subject = f"Job - {job_name} Succeeded for table {source_table_name}- with new Schema "
    send_sns_notification(subject[:98] + '..' if len(subject) > 100 else subject, new_columns_message, sns_secret_name,region_name)

    
def get_evaluated_schema(spark, landing_table, target_path, target_database, target_table_name, sns_secret_name, source_table_name, start_time, job_name, audit_path, audit_table, db_user, db_password, postgresl_driver, jdbc_url,region_name):
    """
    Adjust schema based on target table schema and send notifications if there are discrepancies.
    """
    try:
        schema_status = "Success"
        
        # Fetch schema from PostgreSQL and validate
        pg_table_schema, landing_columns = fetch_schemas(spark, source_table_name, landing_table, jdbc_url, db_user, db_password, postgresl_driver)
        
        # Compare schemas and detect missing/new columns
        missing_columns, new_columns = compare_schemas(pg_table_schema, landing_columns)
        
        if missing_columns:
            handle_schema_mismatch(spark, job_name, source_table_name, target_table_name, start_time, audit_path, audit_table, sns_secret_name, missing_columns,region_name)
        elif new_columns:
            handle_new_columns(sns_secret_name, job_name, source_table_name, new_columns,region_name)
        return schema_status

    except Exception as e:
        logging.error("An error occurred while fetching schema from source table: %s", str(e))
        logging.error("Traceback: %s", traceback.format_exc())
        raise

def transform_source_data(db_host,db_port, db_name, db_user, db_password,source_schema,source_table, source_table_name, updated_time_col,precombine_field,source_df,timestamp_dtype):
    """Performs transformations on the source data."""
    source_df_schema = source_df.columns
    if 'tenant_id' not in source_df_schema and 'tenant' not in source_df_schema:
        source_df = source_df.withColumn('Master_tenant', lit('Master'))
    
    # Filter and convert timestamp to required format
    source_df = source_df.filter(F.col(precombine_field).isNotNull())
    data_type =get_column_data_type(db_host,db_port, db_name, db_user, db_password,source_schema,source_table, source_table_name, updated_time_col)
    
    if data_type in ["bigint", "integer"]:
        source_df = source_df.withColumn(
        "_hoodie_commit_time_land_cal", F.date_format((F.col(updated_time_col) / 1000).cast("timestamp"), "yyyy-MM-dd HH:mm:ss.SSSSSS"))
    elif data_type == timestamp_dtype:
        # Directly format the timestamp column
        source_df = source_df.withColumn("_hoodie_commit_time_land_cal",F.date_format(F.col(updated_time_col).cast("timestamp"),
                "yyyy-MM-dd HH:mm:ss.SSSSSS"))
    else:
        raise ValueError(f"Unsupported data type for {updated_time_col}: {data_type}")
    
    return source_df,data_type


def main():
    """
    Main method.
    """
    #initiating log
    log = {}
    timestamp_dtype = "timestamp without time zone"
    s3_client = boto3.client('s3')
    
    try:
        logging.info("Job started")

        start_time = datetime.now()
        

        # Initialize Spark session
        spark=initialize_spark_session()
        
        try:
                
            # Define arguments
            arguments = [
                "JOB_NAME",
                "yaml_s3_bucket",
                "yaml_file_key",
                "source_table_name",
                "audit_database",
                "source_type",
                "target_type"
            ]
    
            # Get the arguments
            args = getResolvedOptions(sys.argv, arguments)
            job_name = args.get("JOB_NAME")
            source_table_name = args.get("source_table_name")
            logging.info("job_name=%s", job_name+"/"+source_table_name)
            JOB_RUN_ID = args.get("JOB_RUN_ID")
            logging.info(f"JOB_RUN_ID is :{JOB_RUN_ID}")
            yaml_s3_bucket = args.get("yaml_s3_bucket")
            yaml_file_key = args.get("yaml_file_key")
            audit_database = args.get("audit_database")
            source_type = args.get("source_type")
            # target_type = args.get("target_type")
            logging.info("Arguments resolved successfully.")
            logging.info(f"The job name is {job_name}")
        except Exception as e:
            logging.error(f"Error resolving arguments: {str(e)}")
            traceback.print_exc()
            raise
        
         # Load configurations
        try:
            yaml_dict = load_yaml_config(s3_client,yaml_s3_bucket,yaml_file_key)
            logging.info("Configurations loaded successfully.")
        except Exception as e:
            logging.error(f"Error loading configurations or credentials: {str(e)}")
            traceback.print_exc()
            raise

        # Extract and process configurations
        try:
            table_names = set(yaml_dict.get('tables', {}).keys())
            schema = yaml_dict['tables'][source_table_name]['columns']
            logging.info(f'schema is : {schema}')
            precombine_field = yaml_dict['tables'][source_table_name]['precombine_field']
            updated_time_col = yaml_dict['tables'][source_table_name]['updated_time_col']
            log_path = yaml_dict['tables'][source_table_name]['log_path']
            partition_extract_col = yaml_dict['tables'][source_table_name]['partition_extract_col']
            target_table_name = yaml_dict['tables'][source_table_name]['target_table_name_landing']
            landing_bucket = yaml_dict['tables'][source_table_name]['landing_bucket']
            table_prefix = yaml_dict['tables'][source_table_name]['table_prefix']
            table_append = yaml_dict['tables'][source_table_name]['table_append_land']
            recordkey = yaml_dict['tables'][source_table_name]['recordkey']
            rds_secret_name = yaml_dict['tables'][source_table_name]['rds_secret_name'] 
            sns_secret_name = yaml_dict['tables'][source_table_name]['sns_secret_name'] 
            target_database = yaml_dict['tables'][source_table_name]['target_database'] 
            partition_field = yaml_dict['tables'][source_table_name]['partition_field']
            watermark_bucket = yaml_dict['tables'][source_table_name]['watermark_bucket']
            region_name = yaml_dict['tables'][source_table_name]['region']
            audit_path = yaml_dict['tables'][source_table_name]['audit_path']
            audit_table = yaml_dict['tables'][source_table_name]['audit_table']
            target_type = yaml_dict['tables'][source_table_name]['target_type']
            json_columns = yaml_dict['tables'][source_table_name].get('json_columns')
            logging.info(f"json_columns: {json_columns}")
            # Check if json_columns is missing, None, or empty
            if not json_columns:
                raw_bucket = yaml_dict['tables'][source_table_name]['raw_bucket']
                watermark_file_key = yaml_dict['tables'][source_table_name]['watermark_file_key_raw']
            else:
                # Writes data to the landing layer for subsequent JSON column parsing.
                raw_bucket = yaml_dict['tables'][source_table_name]['landing_bucket']
                watermark_file_key = yaml_dict['tables'][source_table_name]['watermark_file_key_landing']

            if '.' in source_table_name:
                source_schema, source_table = source_table_name.split('.')
            
            year_partitioned=start_time.year
            month_partitioned=start_time.month
            #Validate the audit table to process the job based on job_status
            is_validate = validate_audit_table_with_s3_partition(spark,sns_secret_name,start_time,audit_path,audit_table,source_table_name,target_table_name,job_name,region_name,year_partitioned,month_partitioned)
            
            if is_validate == False:
                logging.error("Job is being aborted due to concurrent execution.")
                return
            
            log_audit(
            spark,
            job_name,
            source_table_name,
            source_type,
            target_table_name,
            target_type,
            "Started",
            start_time,
            None,
            None,
            audit_path,
            audit_table,
        )
             # Extract PostgreSQL credentials from secret
            secret_dict = fetch_postgres_credentials(rds_secret_name,region_name)
            logging.info("rds_secret_name loaded successfully.")
            db_host = secret_dict['db.host']
            db_port = secret_dict['db.port']
            db_name = secret_dict['db.database']
            db_user = secret_dict['db.username']
            db_password = secret_dict['db.password']
            jdbc_url = f"jdbc:postgresql://{db_host}:{db_port}/{db_name}?user={db_user}&password={db_password}"
            logging.info("Configurations extracted and processed successfully.")
        except KeyError as e:
            logging.error(f"Configuration key error: {str(e)}")
            traceback.print_exc()
            raise
        except Exception as e:
            logging.error(f"Error processing configurations: {str(e)}")
            traceback.print_exc()
            raise
        
        
        # checking source table name is in predefined list of tables to avoid any sql injection vector through the query
        if source_table_name not in table_names:
            raise ValueError(f"Table {source_table_name} is not allowed.")

        #cloudwatch url for tracking the logs in the email alert.
        cloudwatch_url = get_cloudwatch_url(region_name,job_name,JOB_RUN_ID)
        

        target_path = "s3://" + raw_bucket + "/" + table_prefix + "_" + table_append + "/"
        
         # Check if the target table exists
        if spark._jsparkSession.catalog().tableExists(target_database, target_table_name):
            try:
                # Read the existing landing table
                landing_table = spark.read.format("hudi").load(target_path).limit(0)
                logging.info(f"Landing table schema: {landing_table.schema}")
                
                
                # Perform schema evaluation and possible evolution
                schema_status = get_evaluated_schema(spark,landing_table, target_path, target_database, target_table_name, sns_secret_name, source_table_name,start_time,job_name,audit_path,audit_table,db_user,db_password,postgresl_driver,jdbc_url,region_name)
                
                logging.info(f"Schema status after evaluation: {schema_status}")
                
                if schema_status == "Aborted":
                    sys.exit(1)
            except Exception as e:
                logging.error(f"Unexpected error: {str(e)}")
        
        else:
            logging.info("Landing table does not exist. No schema validation performed.")
        
        latest_watermark = get_watermark_timestamp(s3_client,watermark_bucket,watermark_file_key)
        # read_watermark_from_s3(watermark_bucket, watermark_file_key,s3_client,source_table_name)
        logging.info(f"latest_watermark is for :{latest_watermark}")
        logging.info(f"db_host: {db_host}, db_port: {db_port}, db_name: {db_name}, db_user: {db_user}")
        
        source_df = read_postgres_table(spark, jdbc_url, source_schema,source_table, source_table_name, latest_watermark, db_user, db_password,postgresl_driver, updated_time_col, db_host, db_port, db_name,timestamp_dtype)
        
        num_records = source_df.count()
        if num_records > 0:
            source_df,data_type=transform_source_data(db_host,db_port, db_name, db_user, db_password,source_schema,source_table, source_table_name, updated_time_col,precombine_field,source_df,timestamp_dtype)
            
    
            if data_type in ["bigint", "integer"]:
                df_evaluated = source_df.withColumn("p_year", F.year((F.col(partition_extract_col) / 1000).cast("timestamp")))
                df_evaluated = df_evaluated.withColumn("p_month", F.month((F.col(partition_extract_col) / 1000).cast("timestamp")))
                df_evaluated = df_evaluated.withColumn("p_day", F.dayofmonth((F.col(partition_extract_col) / 1000).cast("timestamp")))
    
           
            elif data_type == timestamp_dtype:
                # Directly use the timestamp column
                df_evaluated = source_df.withColumn(
                    "p_year", F.year(F.col(partition_extract_col).cast("timestamp"))
                )
                df_evaluated = df_evaluated.withColumn(
                    "p_month", F.month(F.col(partition_extract_col).cast("timestamp"))
                )
                df_evaluated = df_evaluated.withColumn(
                    "p_day", F.dayofmonth(F.col(partition_extract_col).cast("timestamp"))
                )
                
            else:
                raise ValueError(f"Unsupported data type for {partition_extract_col}: {data_type}")
    
            # Log the schema and sample data after transformations
            logging.info(f"Schema after transformations: {df_evaluated.schema}")

            # Define Hudi options
            logging.info("Defining Hudi options")
            hudi_options = {
                "hoodie.table.name": target_table_name,
                "hoodie.datasource.write.storage.type": "COPY_ON_WRITE",
                "hoodie.datasource.write.recordkey.field": recordkey,
                "hoodie.datasource.write.operation": "upsert",
                "hoodie.datasource.write.precombine.field": precombine_field,
                "hoodie.datasource.write.partitionpath.field": partition_field,
                "hoodie.datasource.hive_sync.enable": "true",
                "hoodie.datasource.hive_sync.database": target_database,
                "hoodie.datasource.hive_sync.table": target_table_name,
                "hoodie.datasource.hive_sync.use_jdbc": "false",
                "hoodie.datasource.hive_sync.mode": "hms",
                "hoodie.datasource.hive_sync.sync_as_datasource": "false",
                "hoodie.datasource.hive_sync.support_timestamp": "true",
                "hoodie.avro.schema.allow.empty": "true",
                "hoodie.schema.on.read.enable": "true",
                "hoodie.datasource.hive_sync.partition_fields": partition_field,
                "path": target_path,
                "hoodie.parquet.max.file.size": "134217728",
            }
            
            logging.info(f"Hudi options: {hudi_options}")
            logging.info(f"Data schema: {df_evaluated.schema}")
            
            # Write the DataFrame to Hudi
            try:
                logging.info(f"Writing DataFrame to Hudi table: {target_table_name}")
                df_evaluated.write.format("hudi").options(**hudi_options).mode("append").save()
                logging.info("Data successfully written to Hudi table")
                
                # Update the watermark if data was successfully written
                new_watermark = df_evaluated.agg({updated_time_col: "max"}).collect()[0][0]
                update_watermark_file(s3_client,new_watermark,watermark_bucket,watermark_file_key,source_table_name)
                # write_watermark_to_s3(watermark_bucket, watermark_file_key, source_table_name, new_watermark,s3_client)
            except Exception as e:
                logging.error(f"Failed to write data to Hudi table: {str(e)}")
                raise

        else:
            logging.info("No incremental data to write. Skipping Hudi write operation.")
            
        logging.info("Job completed successfully")
       

        end_time = datetime.now()

        duration = (end_time - start_time).seconds
        
        
        log_audit(
            spark,
            job_name,
            source_table_name,
            source_type,
            target_table_name,
            target_type,
            "Completed",
            start_time,
            end_time,
            num_records,
            audit_path,
            audit_table,
        )
        
        log = {
            "status": "success",
            "job_name": job_name,
            "source_table": source_table_name,
            "target_table": target_table_name,
            "start_time": start_time.isoformat(),
            "end_time": end_time.isoformat(),
            "duration": duration,
            "num_records": num_records
        }
     
        log_message = "\n".join([f"{key}: {value}" for key, value in log.items()])

        message = f"Job- write-{source_table_name}-pg-raw-hudi completed successfully. Processed {num_records} records in {duration} seconds.\n\n{log_message}.\n\nView the logs in CloudWatch:{cloudwatch_url}"
        subject = f"Job -write-{source_table_name}-pg-raw-hudi completed successfully"
        if len(subject) > 100:
            subject = subject[:97] + '...'  # Truncate if needed

        # send_sns_notification(subject, message, sns_secret_name)
    except Exception as e:
        logging.error("Job failed with error :%s", str(e))
        end_time = datetime.now()
        duration = (end_time - start_time).seconds
        traceback.print_exc()
        
        cloudwatch_url = get_cloudwatch_url(region_name,job_name, JOB_RUN_ID)
        error_code = getattr(e, 'code', 'N/A')  # Some exceptions might have a 'code' attribute
        if error_code == 'N/A':
            # Try to parse error code from the exception message if it's in a known format
            error_code = "Specific logic to parse error code from the exception message if possible"
            
        log = {
            "status": "failure",
            "job_name": job_name,
            "source_table": source_table_name,
            "target_table": target_table_name,
            "start_time": start_time.isoformat(),
            "end_time": end_time.isoformat(),
            "duration": duration,
            "error_code": error_code,
            "error": f"Error: {str(e)}\nTraceback: {traceback.format_exc()}"
        }
        
        try :
            
            log_audit(
                spark,
                job_name,
                source_table_name,
                source_type,
                target_table_name,
                target_type,
                "Failed",
                start_time,
                end_time,
                None,
                audit_path,
                audit_table,
            )
        except Exception as audit_exception:
            logging.error("An error occurred while entering logs to audit table: %s", str(audit_exception))
            logging.error("Traceback: %s", traceback.format_exc())
               
        
        log_message = "\n".join([f"{key}: {value}" for key, value in log.items()])
        
        message = f"Job {job_name} failed. Error: {str(e)}\nTraceback: {traceback.format_exc()} \n\n{log_message}.\n\nView the logs in CloudWatch:{cloudwatch_url}"
        
        subject =f'{job_name} failed for {source_table_name} table'
        if len(subject) > 100:
            subject = subject[:98] + '..'  # Truncate if needed
        
        send_sns_notification(subject, message, sns_secret_name,region_name)
        logging.error(f"Error: {str(e)}\nTraceback: {traceback.format_exc()}")
        raise
    finally:
        final_log = log.copy()  # Copy the current log
        yaml_params = {
        "job_name": job_name,
        "table_name": source_table_name,
        "log_path":log_path, 
        "audit_table": audit_table, 
        "audit_path":audit_path,
        "yaml_s3_bucket": yaml_s3_bucket,
        "yaml_file_path": yaml_file_key,
        "rds_secret_name": rds_secret_name, 
        "updated_time_col": updated_time_col,
        "partition_extract_col": partition_extract_col, 
        "target_table_name": target_table_name,
        "landing_bucket": landing_bucket,
        "raw_bucket": raw_bucket,
        "table_prefix": table_prefix,
        "table_append": table_append,
        "recordkey": recordkey, 
        "target_database": target_database,
        "partition_field": partition_field,
        "watermark_bucket":watermark_bucket,
        "watermark_folder":watermark_file_key
        }

        final_log.update(yaml_params)
        dt = datetime.now()
        epoch_time = int(dt.timestamp() * 1000)
        s3_client.put_object(Bucket=log_path, Key=f'logs/{job_name}-{source_table_name}_{epoch_time}_logs.json', Body=json.dumps(final_log))


if __name__ == "__main__":
    main()
