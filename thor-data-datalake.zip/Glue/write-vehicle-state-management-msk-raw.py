import sys
import boto3
from pyspark.sql import functions as F
from awsglue.utils import getResolvedOptions
from pyspark.sql.types import StringType,MapType
import logging
from pyspark.sql.functions import col
from datetime import datetime
import traceback

from hmcl_cv_common_utilities import (
    log_audit,
    load_yaml_config,
    send_sns_notification,
    get_cloudwatch_url,
    validate_audit_table_with_s3_partition,
    initialize_spark_session
    )

logging.basicConfig(
    level=logging.INFO, format="%(asctime)s - %(name)s - %(levelname)s - %(message)s"
)

def read_job_parameters():
    try:
        # Define arguments
        arguments = [
            "JOB_NAME",
            "yaml_s3_bucket",
            "yaml_file_key",
        ]
        # Get the arguments
        args = getResolvedOptions(sys.argv, arguments)
        job_name = args.get("JOB_NAME")
        job_run_id = args.get("JOB_RUN_ID")
        yaml_s3_bucket = args.get("yaml_s3_bucket")
        yaml_file_key = args.get("yaml_file_key")
        logging.info("Job parameters read successfully")
        return job_name,job_run_id,yaml_s3_bucket,yaml_file_key
    
    except Exception as e:
        logging.error(f"Error while reading job parameters: {str(e)}")
        traceback.print_exc()
        raise
    
def read_yaml_file(s3_client,yaml_s3_bucket,yaml_file_key):
    try:
        # Read YAML file from S3
        yaml_dict = load_yaml_config(s3_client,yaml_s3_bucket,yaml_file_key)
        brokers = yaml_dict["brokers"]
        kafka_topic = yaml_dict["kafka_topic"]
        offset = yaml_dict["offset"]
        audit_table = yaml_dict["audit_table"]
        audit_path = yaml_dict["audit_path"]
        region_name = yaml_dict["region"]
        source_type = yaml_dict["source_type"]
        target_type = yaml_dict["target_type"]
        sns_secret_name = yaml_dict["sns_secret_name"]
        check_point_bucket = yaml_dict["check_point_bucket"]
        check_point_path = yaml_dict["check_point_path"]
        hudi_table_name = yaml_dict["hudi_table_name"]
        hudi_database = yaml_dict["hudi_database"]
        hudi_s3_output_path = yaml_dict["hudi_s3_output_path"]
        check_point_full_path = "s3://"+ check_point_bucket + "/" +check_point_path
        
        logging.info("yaml parameters read successfully")
        return brokers, kafka_topic, offset,audit_table, audit_path,region_name,source_type,target_type,\
        sns_secret_name,check_point_full_path,hudi_table_name,hudi_database,hudi_s3_output_path
        
    except Exception as e:
        logging.error(f"Error while reading yaml parameters: {str(e)}")
        traceback.print_exc()
        raise

def read_kafka_topic(spark,brokers,kafka_topic,offset):
    try :
        kafka_stream_df = spark.readStream.format('kafka') \
        .option("kafka.bootstrap.servers", brokers) \
        .option("subscribe", kafka_topic) \
        .option("failOnDataLoss", "false") \
        .option("kafka.security.protocol","SASL_SSL") \
        .option("kafka.sasl.mechanism","AWS_MSK_IAM") \
        .option("kafka.sasl.jaas.config","software.amazon.msk.auth.iam.IAMLoginModule required;") \
        .option("kafka.sasl.client.callback.handler.class", "software.amazon.msk.auth.iam.IAMClientCallbackHandler") \
        .option("startingOffsets", offset) \
        .load()
        return kafka_stream_df
    except Exception as e:
        logging.error(f"Error while reading kafka topic: {str(e)}")
        traceback.print_exc()
        raise
    
def add_missing_columns_into_sourcedf(spark,source_df,table_name,target_hudi_table_path):
    
    try:
        existing_column_names = spark.read.format("hudi").load(target_hudi_table_path).schema.fieldNames()
        target_schema_columns = [col for col in existing_column_names if not col.startswith('_hoodie_')]
        
        target_schema_columns = set(target_schema_columns)
        source_schema_columns = set(source_df.columns)
        logging.info(f"Target_Schema_columns: {target_schema_columns}")
        logging.info(f"Source_Schema_columns: {source_schema_columns}")
        logging.info(f"Difference between target - source coulums : {target_schema_columns - source_schema_columns}")
        # Add missing columns with null values
        for column_name in target_schema_columns - source_schema_columns:
            source_df = source_df.withColumn(column_name, F.lit(None).cast("string"))
            
        logging.info("flattenning data frame after adding into missing columns")
        logging.info(f"flattening df  columns names: {source_df.columns}")
        logging.info(f"Existing column names in {table_name} Table :{existing_column_names}")

    except Exception as e:
        logging.info(f"not able to read the table {table_name}, error: %s", str(e))
        raise
        
    return source_df  
  
def s3_path_exists(bucket_name, prefix, s3_client):
    
    response = s3_client.list_objects_v2(Bucket=bucket_name, Prefix=prefix, MaxKeys=1)
    return "Contents" in response

def load_batch_into_hudi_table(spark,df,table_name,database,s3_output_path,s3_client):
    try:
        bucket_name = s3_output_path.split('/',3)[2]
        table_path = s3_output_path.split('/',3)[3]
        if s3_path_exists(bucket_name, table_path, s3_client):
            logging.info(f"bucket_name:{bucket_name}")
            logging.info(f"table_path:{table_path}")
            df = add_missing_columns_into_sourcedf(spark,df,table_name,s3_output_path)
        
        hudi_options = {
                "hoodie.table.name": table_name,
                "hoodie.datasource.write.operation": "insert",
                "hoodie.table.type": "COPY_ON_WRITE",
                "hoodie.avro.schema.allow.empty": "true",
                "hoodie.datasource.write.schema.evolution.enable": "true",
                "hoodie.schema.on.read.enable": "true",
                "hoodie.bulkinsert.shuffle.parallelism": "200",
                "hoodie.insert.shuffle.parallelism": "200",
                "hoodie.datasource.write.partitionpath.field": "tenantId,year,month,day",
                "hoodie.datasource.write.recordkey.field": "vid,createdTsp,updatedTsp",
                "hoodie.datasource.hive_sync.enable": "true",
                "hoodie.datasource.hive_sync.database": database,
                "hoodie.datasource.hive_sync.table": table_name,
                "hoodie.datasource.hive_sync.use_jdbc": "false",
                "hoodie.datasource.hive_sync.mode": "hms",
                "hoodie.datasource.hive_sync.support_timestamp": "true",
                "path": s3_output_path,
                "hoodie.parquet.max.file.size": "134217728",
            }
        df.write.format("hudi").options(**hudi_options).mode("append").save()
        logging.info("Data successfully written to Hudi table")
        
    except Exception as e:
        logging.error(f"Error while loading data into Hudi Table: {str(e)}")
        traceback.print_exc()
        raise



# Function to display the stream data
def process_batch(df,spark,job_name,kafka_topic,source_type,target_type,start_time,audit_path,audit_table,\
        hudi_table_name,hudi_database,hudi_s3_output_path,s3_client):
    try:
        num_records = df.count()
        logging.info(f"dataframe count:{num_records}")
        if num_records > 0:
            df_kafka = df.select("value")
            json_schema = MapType(StringType(), StringType())
            
            # Parse the JSON into columns
            df_kafka = df_kafka.withColumn("parsed_value", F.from_json(col("value"), json_schema))
            
            parsed_keys = df_kafka.select(F.explode("parsed_value").alias("key", "value")).select("key").distinct().rdd.flatMap(lambda x: x).collect()

            flattened_columns = [F.col("parsed_value." + key).alias(key) for key in parsed_keys]
            
            df_kafka = df_kafka.select(*flattened_columns)
            
            
            
            df_kafka = df_kafka.withColumn("updatedTsp", col("updatedTsp").cast("long"))
            df_kafka = df_kafka.withColumn("date", F.to_date(F.from_unixtime((col("updatedTsp") / 1000).cast("long"))))
            df_kafka = df_kafka.withColumn("year", F.year("date")) \
                .withColumn("month", F.month("date")) \
                .withColumn("day",F.dayofmonth("date"))

            load_batch_into_hudi_table(spark,df_kafka,hudi_table_name,hudi_database,hudi_s3_output_path, s3_client)
                
        end_time = datetime.now()
        log_audit(
                spark,job_name,kafka_topic,source_type,hudi_table_name,target_type,"Completed",start_time,end_time,\
                    num_records,audit_path,audit_table)
        logging.info(f"load completed")
    except Exception as e:
        logging.error(f"Error batch load : {str(e)}")
        traceback.print_exc()
        raise
    
    
def load_metrics_into_datalake(kafka_stream_df,spark,job_name,kafka_topic,source_type,target_type,\
        start_time,audit_path,audit_table,check_point_path,hudi_table_name,hudi_database,hudi_s3_output_path,s3_client):
    try:
        # Use foreachBatch to display the stream data in real-time
        query = kafka_stream_df.writeStream \
            .foreachBatch(lambda df,_: process_batch(df,spark,job_name,kafka_topic,source_type,target_type,start_time,audit_path,audit_table,\
                                    hudi_table_name,hudi_database,hudi_s3_output_path,s3_client))  \
            .option("checkpointLocation", check_point_path) \
            .outputMode("update") \
            .trigger(once=True) \
            .start()
        query.awaitTermination()
    except Exception as e:
        logging.error(f"Error while kafka write operation: {str(e)}")
        traceback.print_exc()
        raise
    
def main():
    try:
        start_time = datetime.now()
        logging.info(f"Job started at {start_time}")
        spark = initialize_spark_session()
        job_name,job_run_id,yaml_s3_bucket,yaml_file_key = read_job_parameters()
        s3_client = boto3.client('s3')
        brokers, kafka_topic, offset,audit_table, audit_path,region_name,source_type,target_type,\
        sns_secret_name,check_point_path,hudi_table_name,hudi_database,hudi_s3_output_path,\
                = read_yaml_file(s3_client,yaml_s3_bucket,yaml_file_key)
        logging.info("job_name=%s", job_name)
    except Exception as e:
        logging.error(f"Error in initial steps: {str(e)}")
        traceback.print_exc()
        raise
    
    
    try:
        year_partitioned=start_time.year
        month_partitioned=start_time.month
        is_validate = validate_audit_table_with_s3_partition(spark,sns_secret_name,start_time,audit_path,audit_table,\
            kafka_topic,hudi_table_name,job_name,region_name,year_partitioned,month_partitioned)
        if is_validate == False:
            return
        log_audit(spark,job_name,kafka_topic,source_type,hudi_table_name,target_type,\
                    "Started",start_time,None,None,audit_path,audit_table)
        
        kafka_stream_df = read_kafka_topic(spark,brokers,kafka_topic,offset)
        kafka_stream_df = kafka_stream_df.selectExpr("CAST(value AS STRING)")

        load_metrics_into_datalake(kafka_stream_df,spark,job_name,kafka_topic,source_type,target_type,\
        start_time,audit_path,audit_table,check_point_path,hudi_table_name,hudi_database,hudi_s3_output_path,s3_client)
        
         #get cloudwatch details
        cloudwatch_url = get_cloudwatch_url(region_name, job_name, job_run_id)
        end_time = datetime.now()
        duration = (end_time - start_time).seconds
        
        logging.info(f"Job completed successfully in {duration} seconds")
        
        log = {
            "status": "success",
            "job_name": job_name,
            "source_table": kafka_topic,
            "target_table": hudi_table_name,
            "start_time": start_time.isoformat(),
            "end_time": end_time.isoformat(),
            "duration": duration,
        }
    except Exception as e:
        logging.error("Job failed with error: %s", str(e))
        traceback.print_exc()
        end_time = datetime.now()
        duration = end_time - start_time
        logging.error(f"Job failed in {duration} seconds")
        #get cloudwatch details 
        
        cloudwatch_url = get_cloudwatch_url(region_name, job_name, job_run_id)
        log = {
                "status": "failure",
                "job_name": job_name,
                "source_table": kafka_topic,
                "target_table": hudi_table_name,
                "start_time": start_time.isoformat(),
                "end_time": end_time.isoformat(),
                "duration": duration,
                "error": f"Error: {str(e)}\nTraceback: {traceback.format_exc()}"
            }
        
        # Log audit
        log_audit(
                spark,job_name,kafka_topic,source_type,hudi_table_name,target_type,\
                "Failed",start_time,end_time,None,audit_path,audit_table,
                )
            
        log_message = "\n".join([f"{key}: {value}" for key, value in log.items()])
        message = f"Job -{job_name} failed. Transformation returned None.\n\n{log_message}.\n\nView the logs in CloudWatch:{cloudwatch_url}"
        subject=f"Job Failed : Job - {job_name}"
        send_sns_notification(subject[:95], message, sns_secret_name,region_name)
        raise


if __name__ == "__main__":
    main()