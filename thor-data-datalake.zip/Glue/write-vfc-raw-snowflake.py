import json
import sys
import logging
from datetime import datetime, timedelta
import boto3
import traceback
import snowflake.connector
from awsglue.context import GlueContext
from awsglue.utils import getResolvedOptions
from pyspark.sql import functions as F
from pyspark.sql.types import IntegerType, StructType, StructField, StringType, LongType

from hmcl_cv_common_utilities import (
    log_audit,
    load_yaml_config,
    validate_audit_table_with_s3_partition,
    send_sns_notification,
    get_watermark_timestamp,
    get_cloudwatch_url,
    update_watermark_file,
    initialize_spark_session,
    fetch_snowflake_credentials
)

logging.basicConfig(
    level=logging.INFO, format="%(asctime)s - %(name)s - %(levelname)s - %(message)s"
)


def read_job_param():
    try:
        # Define arguments
        arguments = [
            "JOB_NAME",
            "yaml_s3_bucket",
            "yaml_file_key",
            "source_table_name"
        ]
        # Get the arguments
        args = getResolvedOptions(sys.argv, arguments)

        job_params = {
            "job_name": args.get("JOB_NAME"),
            "job_run_id": args.get("JOB_RUN_ID"),
            "yaml_s3_bucket": args.get("yaml_s3_bucket"),
            "yaml_file_key": args.get("yaml_file_key"),
            "source_table_name": args.get("source_table_name"),
            # "audit_database": args.get("audit_database"),
        }

        logging.info("Job parameters read successfully")
        return job_params
    except Exception as e:
        logging.error(f"Error while reading job parameters: {str(e)}")
        raise


def read_yaml_file(s3_client, job_params):
    try:
        # Read YAML file from S3
        yaml_dict = load_yaml_config(s3_client, job_params['yaml_s3_bucket'], job_params['yaml_file_key'])
        table_config = yaml_dict['paths'].get(job_params['source_table_name'], {})

        yaml_keys_to_extract = [
            "audit_path", "audit_table", "log_path", "region_name", "source_type", "firmware_path",
            "tcu_detail_path", "tcu_mapping_path", "vfc_path", "os_connector_name", "vehicle_connected_index",
            "vehicle_snapshot_index",
            "target_type", "sns_secret_name", "snowflake_secret_name", "target_table_name", "stage_table_name",
            "raw_table_name", "partition_field", "record_key","target_database","raw_target_path"
        ]
        job_config = {key: table_config.get(key) for key in yaml_keys_to_extract}

        job_config.update(job_params)
        logging.info("YAML parameters read successfully")
        logging.info(f"job_config : {job_config}")
        return job_config

    except Exception as e:
        logging.error(f"Error while reading YAML parameters: {str(e)}")
        raise


def get_snowflake_connection(sfUser, sfPassword, sfURL):
    """
    Establish and return a Snowflake connection.
    """
    try:
        conn = snowflake.connector.connect(
            user=sfUser,
            password=sfPassword,
            account=sfURL.split('//')[1].split('.snowflakecomputing.com')[0]
        )
        logging.info("Snowflake connection established.")
        return conn
    except Exception as e:
        logging.error(f"Error establishing Snowflake connection: {e}")
        raise


def get_snowflake_options(secret_dict):
    """
    Create a dictionary of Snowflake options for Spark DataFrame writes.
    """
    return {
        "sfURL": secret_dict['url'],
        "sfDatabase": secret_dict['database'],
        "sfSchema": secret_dict['schema'],
        "sfWarehouse": secret_dict['warehouse'],
        "sfRole": secret_dict['role'],
        "sfUser": secret_dict['username'],
        "sfPassword": secret_dict['password']
    }


def write_to_snowflake(df, table_name, snowflake_secret_name):
    try:
        # Fetch Snowflake credentials
        secret_dict = fetch_snowflake_credentials(snowflake_secret_name)
        logging.info("Snowflake credentials loaded successfully.")

        # Prepare Snowflake options
        options = get_snowflake_options(secret_dict)

        # Write DataFrame to Snowflake
        logging.info(f"Starting data write to Snowflake table: {table_name}")
        df.write \
            .format("snowflake") \
            .options(**options) \
            .option("dbtable", table_name) \
            .mode("overwrite") \
            .save()
        logging.info(f"Data written successfully to Snowflake table: {table_name}")
    except Exception as e:
        logging.error(f"Failed to write to Snowflake: {str(e)}")
        raise


def read_spark_snapshot(spark, path):
    try:
        return spark.read.format("hudi").load(path)
    except Exception as e:
        logging.error(f"Error while reading path : {path}  and Error : {str(e)}")
        raise


def read_tcu_mapping(spark, job_config):
    logging.info("Reading raw tcu_mapping data")
    try:
        required_columns = ["vid", "tcu_id", "created_tsp", "updated_tsp", "is_active"]
        df = (read_spark_snapshot(spark, job_config['tcu_mapping_path'])
              .select(*required_columns)).distinct()

        # TCU link count
        df_tcu_link_count = df.groupBy('vid').count()

        # VIN-TCU link count
        df_vid_tcu_link_count_rec = df.groupBy('vid', 'tcu_id').count()
        df_vid_tcu_link_count = df_vid_tcu_link_count_rec.groupBy('vid').agg(F.max("count").alias("count"))

        # active tcu
        df_active = df.filter(F.col("is_active") == True).select(*required_columns).drop("is_active")
        return df_active, df_tcu_link_count, df_vid_tcu_link_count
    except Exception as e:
        logging.error(f"Error while reading tcu_mapping : {str(e)}")
        raise


def read_firmware(spark, job_config):
    try:
        schema = StructType([
            StructField("vid", StringType(), True),
            StructField("ecuId", StringType(), True),
            StructField("ecuAbbreviation", StringType(), True),
            StructField("ecuName", StringType(), True),
            StructField("softwareVersion", StringType(), True),
            StructField("hardwareVersion", StringType(), True),
            StructField("last_connected_tsp", LongType(), True)
        ])
        current_date = datetime.now()
        formatted_date = current_date.strftime("%Y-%m-%d")

        # Construct the full filename
        file_name = f"esync_connectivity_{formatted_date}.csv"
        firmware_file_path = job_config['firmware_path'] + file_name
        logging.info(f"Processing firmware for file: {firmware_file_path}")

        required_columns = ["vid", "softwareVersion", "last_connected_tsp"]
        df_firmware = spark.read.csv(firmware_file_path, header=True, schema=schema)
        df_filter = df_firmware.filter(F.col('ecuAbbreviation') == 'TCU')
        df = df_filter.select(*required_columns).distinct()

        logging.info(f"Total TCU data in {file_name} is {df.count()}")
        return df
    except Exception as e:
        logging.error(f"Error while reading firmware S3: {str(e)}")
        raise


def read_tcu_detail(spark, job_config):
    logging.info("Reading raw tcu_detail data")
    try:
        required_columns = ["tcu_id", "software_detail"]
        df_source = read_spark_snapshot(spark, job_config['tcu_detail_path'])
        df = df_source.select(*required_columns).distinct()
        return df
    except Exception as e:
        logging.error(f"Error while reading tcu_detail : {str(e)}")
        raise


def read_connected_index(glue_context, job_config):
    logging.info("Reading vehicle_connected_index data")
    try:
        query = {
            "query": {
                "match_all": {}
            }
        }

        query_agg = {
            "aggs": {
                "clients": {
                    "terms": {
                        "field": "clientId"
                    },
                    "aggs": {
                        "timestamp": {
                            "min": {
                                "field": "timestamp"
                            }
                        }
                    }
                }
            }
        }

        df_connected = glue_context.create_dynamic_frame.from_options(
            connection_type="opensearch",
            connection_options={
                "connectionName": job_config["os_connector_name"],
                "opensearch.port": 443,
                "opensearch.resource": job_config["vehicle_connected_index"],
                "opensearch.query": json.dumps(query),
                "pushdown": "true",
                "opensearch.read.field.include": "clientId,timestamp"
            },
        ).toDF()
        df = df_connected.groupBy("clientId").agg(F.min(F.col('timestamp')).alias("timestamp"))

        return df
    except Exception as e:
        logging.error(f"Error while reading vehicle-connected-index : {str(e)}")
        raise


def read_snapshot_index(glue_context, job_config):
    logging.info("Reading vehicle-snapshot index data")
    try:
        query = {
            "query": {
                "bool": {
                    "must": [
                        {
                            "range": {
                                "updatedTsp": {
                                    "gte": 0
                                }
                            }
                        }
                    ]
                }
            }
        }

        df_snapshot = glue_context.create_dynamic_frame.from_options(
            connection_type="opensearch",
            connection_options={
                "connectionName": job_config["os_connector_name"],
                "opensearch.port": 443,
                "opensearch.resource": job_config["vehicle_snapshot_index"],
                "opensearch.query": json.dumps(query),
                "pushdown": "true",
                "opensearch.read.field.include": "vid,updatedTsp"
            },
        ).toDF()
        df = df_snapshot.select('vid', 'updatedTsp')
        df = df.groupBy("vid").agg(F.max(F.col('updatedTsp')).alias("cloud_connected_tsp"))
        return df
    except Exception as e:
        logging.error(f"Error while reading vehicle-snapshot index : {str(e)}")
        raise


def execute_sf_query(conn, query):
    try:
        cursor = conn.cursor()
        cursor.execute(query)
    finally:
        cursor.close()
        conn.close()

def merge_to_target(df, conn, job_config):
    target_table_name = job_config['target_table_name']
    stage_table_name = job_config['stage_table_name']
    try:

        sf_columns = df.columns
        # Creates a string like: "vid, tcu_id, created_tsp, ..."
        target_cols_str = ", ".join(sf_columns)

        # Creates a string like: "stage.vid, .."
        source_cols_str = ", ".join([f"stage.{col}" for col in sf_columns])

        target_merge_query = f"""
        MERGE INTO {target_table_name} AS target
        USING {stage_table_name} AS stage
        ON target.vid = stage.vid
        WHEN MATCHED THEN
            UPDATE SET
                target.tcu_id = stage.tcu_id,
                target.created_tsp = stage.created_tsp,
                target.updated_tsp = stage.updated_tsp,
                target.firmware_stage_1 = stage.firmware_stage_1,
                target.firmware_vehicle_reported = stage.firmware_vehicle_reported,
                target.esync_connected = stage.esync_connected,
                target.fleetwise_connected_firsttime 
                        = LEAST(target.fleetwise_connected_firsttime, stage.fleetwise_connected_firsttime),
                target.cloud_connected = stage.cloud_connected,
                target.tcu_link_count = stage.tcu_link_count,
                target.vin_tcu_link_count = stage.vin_tcu_link_count,
                target.time_diff_in_mins = stage.time_diff_in_mins

        WHEN NOT MATCHED THEN
            INSERT ({target_cols_str})
            VALUES ({source_cols_str});
        """
        execute_sf_query(conn, target_merge_query)
        logging.info(f"Data written successfully to Snowflake table: {job_config['target_table_name']}")
    except Exception as e:
        logging.error(f"Error while writing to target table : {str(e)}")
        raise


def write_to_s3(df, job_config):
    try:
        logging.info("Defining Hudi options")
        hudi_options = {
            "hoodie.table.name": job_config['raw_table_name'],
            "hoodie.datasource.write.operation": "insert",
            "hoodie.datasource.write.partitionpath.field": job_config['partition_field'],
            "hoodie.datasource.write.recordkey.field": job_config['record_key'],
            "hoodie.datasource.hive_sync.enable": "true",
            "hoodie.datasource.hive_sync.database": job_config['target_database'],
            "hoodie.datasource.hive_sync.table": job_config['raw_table_name'],
            "hoodie.datasource.hive_sync.use_jdbc": "false",
            "hoodie.datasource.hive_sync.mode": "hms",
            "hoodie.datasource.hive_sync.support_timestamp": "true",
            "path": job_config['raw_target_path'],
            "hoodie.parquet.max.file.size": "134217728",
        }
        logging.info(f"hudi_options: {hudi_options}")

        df.write.format("org.apache.hudi").options(**hudi_options).mode("append").save()

    except Exception as e:
        logging.error(f"Error in hudi steps: {str(e)}")
        raise


def write_to_snowflake_tables(df, job_config):
    try:
        # Fetch Snowflake credentials
        sf_dict = fetch_snowflake_credentials(job_config['snowflake_secret_name'])
        logging.info("Snowflake credentials loaded successfully")

        # Initialize Snowflake connection
        conn = get_snowflake_connection(sf_dict['username'], sf_dict['password'], sf_dict['url'])

        # Overwrite to Stage table
        write_to_snowflake(df, job_config['stage_table_name'], job_config['snowflake_secret_name'])

        merge_to_target(df, conn, job_config)

    except Exception as e:
        logging.error(f"Error in Snowflake steps: {str(e)}")
        raise

def main():
    start_time = datetime.now()

    # 1. Read job_params and job_config
    try:
        logging.info(f"Job started at {start_time}")

        # create an S3 client
        s3 = boto3.client('s3')

        # initialize spark job
        spark = initialize_spark_session()

        # Read Job Parameters
        job_params = read_job_param()

        # Read .yml file
        job_config = read_yaml_file(s3, job_params)

    except Exception as e:
        logging.error(f"Error in initial steps: {str(e)}")
        traceback.print_exc()
        raise
    # Provide validation
    year_partitioned = start_time.year
    month_partitioned = start_time.month
    is_validate = validate_audit_table_with_s3_partition(spark, job_config['sns_secret_name'], start_time,
                                                         job_config['audit_path'],
                                                         job_config['audit_table'], job_config['source_table_name'],
                                                         job_config['target_table_name'], job_params['job_name'],
                                                         job_config['region_name'],
                                                         year_partitioned, month_partitioned)

    if is_validate == False:
        return

    # Log audit
    log_audit(
        spark, job_config['job_name'], job_config['source_table_name'], job_config['source_type'],
        job_config['target_table_name'], job_config['target_type'], "Started", start_time,
        None, None, job_config['audit_path'], job_config['audit_table'],
    )
    logging.info("logs written to audit table")
    try:
        # Read csv from S3 # "vid", "softwareVersion", "last_connected_tsp"
        df_firmware = read_firmware(spark, job_config)
        # df_firmware.show(2, False)

        # # Read tcu_mapping # "vid", "tcu_id", "created_tsp", "updated_tsp"
        df_tcu_mapping, df_tcu_link, df_vid_tcu_link = read_tcu_mapping(spark, job_config)
        # df_tcu_mapping.show(2, False)
        # df_tcu_link.show(2, False)
        # df_vid_tcu_link.show(2, False)

        # Read tcu_detail # "tcu_id", "software_detail"
        df_tcu_detail = read_tcu_detail(spark, job_config)
        # df_tcu_detail.show(2, False)

        # Read connected index # "clientId,timestamp"
        glue_context = GlueContext(spark.sparkContext)
        df_connected = read_connected_index(glue_context, job_config)
        # df_connected.show(2, False)

        # Read vehicle-snapshot index # vid, cloud_connected_tsp
        df_snapshot = read_snapshot_index(glue_context, job_config)
        # df_snapshot.show(2, False)

        # joins
        df_joined = (df_firmware
                     .join(df_tcu_mapping, on="vid", how="left")
                     .join(df_tcu_detail, on="tcu_id", how="left")
                     .join(df_connected, df_tcu_mapping["tcu_id"] == df_connected["clientId"], "left")
                     .join(df_snapshot, df_firmware["vid"] == df_snapshot["vid"], "left")
                     .join(df_tcu_link, "vid", "left")
                     .join(df_vid_tcu_link, "vid", "left")
                     .select(df_firmware['vid'],
                             df_tcu_mapping['tcu_id'], df_tcu_mapping['created_tsp'], df_tcu_mapping['updated_tsp'],
                             df_tcu_detail['software_detail'].alias('firmware_stage_1'),
                             df_firmware['softwareVersion'].alias('firmware_vehicle_reported'),
                             df_firmware['last_connected_tsp'].alias('esync_connected'),
                             df_connected['timestamp'].alias('fleetwise_connected_firsttime'),
                             df_snapshot['cloud_connected_tsp'].alias('cloud_connected'),
                             df_tcu_link['count'].alias('tcu_link_count'),
                             df_vid_tcu_link['count'].alias('vin_tcu_link_count')
                             ).distinct()
                     )
        logging.info("joins done")

        # Calculate the difference in minutes
        time_diff_minutes = (F.col("esync_connected") - F.col("cloud_connected")) / 60

        # Apply the time_diff_in_mins condition using a .when() expression
        df_final = df_joined.withColumn(
            "time_diff_in_mins",
            F.when((time_diff_minutes >= 0) & (time_diff_minutes <= 60), time_diff_minutes).otherwise(F.lit(None))
        )

        # df_final.show(10, False)
        # write_to_s3(df_final, job_config)
        write_to_snowflake_tables(df_final, job_config)

        logging.info(f"Job Completed")
        # Log audit
        end_time = datetime.now()
        log_audit(
            spark, job_params['job_name'], job_config['source_table_name'], job_config['source_type'],
            job_config['target_table_name'], job_config['target_type'], "Completed", start_time, end_time,
            None, job_config['audit_path'], job_config['audit_table'],
        )

    except Exception as e:
        logging.error("Job failed with error: %s", str(e))
        traceback.print_exc()
        end_time = datetime.now()
        duration = end_time - start_time
        logging.error(f"Job failed in {duration} seconds")
        # get cloudwatch details
        cloudwatch_url = get_cloudwatch_url(job_config['region_name'], job_params['job_name'], job_params['job_run_id'])
        log = {
            "status": "failure",
            "job_name": job_params['job_name'],
            "source_table": job_config['source_table_name'],
            "target_table": job_config['target_table_name'],
            "start_time": start_time.isoformat(),
            "end_time": end_time.isoformat(),
            "duration": duration,
            "error": f"Error: {str(e)}\nTraceback: {traceback.format_exc()}"
        }

        # Log audit
        log_audit(
            spark, job_params['job_name'], job_config['source_table_name'], job_config['source_type'],
            job_config['target_table_name'], job_config['target_type'], "Failed", start_time, end_time,
            None, job_config['audit_path'], job_config['audit_table'],
        )

        log_message = "\n".join([f"{key}: {value}" for key, value in log.items()])
        message = f"Job -{job_params['job_name']} failed. Transformation returned None.\n\n{log_message}.\n\nView the logs in CloudWatch:{cloudwatch_url}"
        subject = f"Job Failed : Job - {job_params['job_name']}"
        send_sns_notification(subject, message, job_config['sns_secret_name'], job_config['region_name'])
        raise

    finally:
        end_time = datetime.now()
        duration = (end_time - start_time).seconds
        logging.info(f"Job completed in {duration} seconds")


if __name__ == "__main__":
    main()
