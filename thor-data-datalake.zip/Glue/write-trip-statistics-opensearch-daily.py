"""
This code loads the data from opensearch to S3layer and opensearch daily
"""

import sys
import logging
import re
import json
from datetime import datetime
from datetime import timedelta
from pyspark.sql import SparkSession
from pyspark.sql.functions import row_number
from pyspark.sql import functions as F
from pyspark.sql.functions import lit
from pyspark.sql.window import Window
from pyspark.sql.types import DoubleType, TimestampType, StringType, \
    IntegerType, LongType, ArrayType, MapType, StructType, \
    StructField
from awsglue.context import GlueContext
from awsglue.dynamicframe import DynamicFrame
from awsglue.utils import getResolvedOptions  # pylint: disable=import-error
from glue_job_audit_logger import log_audit  # pylint: disable=import-error

# Create a Spark session and Glue context

spark = SparkSession.builder.config('spark.serializer',
                                    'org.apache.spark.serializer.KryoSerializer'
                                    ).config('spark.kryoserializer.buffer.max'
        , '256m').config('spark.hudi.query.metadata.enable', 'true'
                         ).config('spark.sql.adaptive.enabled', 'true'
                                  ).config('spark.sql.adaptive.skewJoin.enabled'
        , 'true').config('spark.sql.adaptive.forceOptimizeSkewedJoin',
                         'false'
                         ).config('spark.sql.adaptive.coalescePartitions.enabled'
                                  , 'true'
                                  ).config('spark.sql.shuffle.partitions'
        , 300).config('spark.sql.join.preferSortMergeJoin', 'true'
                      ).config('spark.yarn.executor.memoryOverhead',
                               '7g').config('spark.driver.memory', '10g'
        ).getOrCreate()

sc = spark

# .conf.set("spark.sql.shuffle.partitions", spark.sparkContext.defaultParallelism)

glueContext = GlueContext(sc)

# Define an accumulator

count_accum = spark.sparkContext.accumulator(0)

args = getResolvedOptions(sys.argv, [
    'JOB_NAME',
    'table_name',
    'landing_bucket',
    'database',
    'tele_table_name',
    'raw_bucket',
    'os_trip_start_index',
    'os_trip_end_index',
    'os_trip_break_index',
    'os_trip_stat_index',
    'os_connector_name',
    'source_type',
    'target_type',
    'audit_path',
    'audit_table',
    'os_telemetry_index',
    'days',
    'hours',
    ])

table_name = args.get('table_name')
landing_bucket = args.get('landing_bucket')
table_name = args.get('table_name')
database = args.get('database')
tele_table_name = args.get('tele_table_name')
s3_tele_output_path = args.get('s3_tele_output_path')
os_trip_start_index = args.get('os_trip_start_index')
os_trip_end_index = args.get('os_trip_end_index')
os_trip_break_index = args.get('os_trip_break_index')
os_trip_stat_index = args.get('os_trip_stat_index')
os_connector_name = args.get('os_connector_name')
raw_bucket = args.get('raw_bucket')
source_type = args.get('source_type')
target_type = args.get('target_type')
audit_path = args.get('audit_path')
audit_table = args.get('audit_table')
os_telemetry_index = args.get('os_telemetry_index')

days_par = args.get('days')
hours_par = args.get('hours')
interval = 'INTERVAL ' + str(hours_par) + ' HOURS'

s3_output_path = 's3://' + raw_bucket + '/' + table_name
s3_tele_output_path = 's3://' + raw_bucket + '/cvp-telemetry-hudi'
source_name = os_trip_start_index + '-' + os_trip_end_index + '-' \
    + os_trip_end_index
target = table_name + '-' + os_trip_stat_index

today = datetime.today()
date_val = datetime.today() - timedelta(days=int(days_par),
        hours=int(hours_par), minutes=0)

year_inp = date_val.year  # the current year
month_inp = date_val.month  # the current month
day_inp = date_val.day  # the current day


# print(day_inp)

##UDF to extract specific data based on latest time.

def get_latest_value(col):
    """
    This is user defined method to get the latets value from array of signal samples
    """

    if not col:
        return None  # Handle empty case
    latest_entry = max(col, key=lambda x: x['time'])
    return latest_entry['value']


def count_elements(row):
    global count_accum
    count_accum.add(1)


def func_case_col(dataframe_ip, value):
    new_columns = [col + value for col in dataframe_ip.columns]
    df_renamed = dataframe_ip
    for (old_col, new_col) in zip(dataframe_ip.columns, new_columns):
        df_renamed = df_renamed.withColumnRenamed(old_col.lower(),
                new_col.lower())
    return df_renamed


def func_rename_col(dataframe_ip):
    """
    replace . with _
    """

    # new_columns = [col.replace(".", "_") for col in dataframe_ip.columns]

    new_columns = [re.sub(r'[.-]', '_', col) for col in
                   dataframe_ip.columns]
    df_renamed_val = dataframe_ip
    for (old_col, new_col) in zip(dataframe_ip.columns, new_columns):
        df_renamed_val = \
            df_renamed_val.withColumnRenamed(old_col.lower(),
                new_col.lower())
    return df_renamed_val


def extract(
    os_trip_start_index,
    os_trip_end_index,
    os_trip_break_index,
    os_trip_stat_index,
    tenantid_in,
    ):
    """
    This function extracts the data from OS loads to hudi and OS
    """

    try:
        logging.info('Job started')
        start_time = datetime.now()

        logging.info('job_name=%s', args.get('JOB_NAME'))
        logging.info('Calling log audit to log the status is job started'
                     )

        log_audit(
            spark,
            args['JOB_NAME'],
            source_name,
            source_type,
            target,
            target_type,
            'Started',
            start_time,
            None,
            None,
            audit_path,
            audit_table,
            )

        opensearch_read_trip_start = \
            glueContext.create_dynamic_frame.from_options(connection_type='opensearch'
                ,
                connection_options={'connectionName': os_connector_name,
                'opensearch.port': 443,
                'opensearch.resource': os_trip_start_index}).toDF()

        opensearch_read_trip_end = \
            glueContext.create_dynamic_frame.from_options(connection_type='opensearch'
                ,
                connection_options={'connectionName': os_connector_name,
                'opensearch.port': 443,
                'opensearch.resource': os_trip_end_index}).toDF()

        opensearch_read_trip_break = \
            glueContext.create_dynamic_frame.from_options(connection_type='opensearch'
                ,
                connection_options={'connectionName': os_connector_name,
                'opensearch.port': 443,
                'opensearch.resource': os_trip_break_index}).toDF()

        s3_tele_extract_output_path = 's3://' + raw_bucket \
            + '/cvp-telemetry-hudi/' + tenantid_in + '/' \
            + 'hmcl-thor-rfw-telemetry-per-mstr-v1-k2' + '/' \
            + str(year_inp) + '/' + str(month_inp) + '/' + str(day_inp) \
            + '/'
        
        # s3_tele_extract_output_path = 's3://' + raw_bucket \
        #     + '/cvp-telemetry-hudi/' + tenantid_in + '/' \
        #     + 'hmcl-thor-rfw-telemetry-per-mstr-v1-k2' + '/' \
        #     + str(year_inp) + '/'

        s3_tele_extract_output_path_other = 's3://' + raw_bucket \
            + '/cvp-telemetry-hudi/'

        # #for testing take the month

        s3_trip_output_path = 's3://' + raw_bucket + '/' + table_name \
            + '/' + tenantid_in + '/' + str(year_inp) + '/' \
            + str(month_inp) + '/' + str(day_inp) + '/'
        # s3_trip_output_path = 's3://' + raw_bucket + '/' + table_name \
        #     + '/' + tenantid_in + '/' + str(year_inp) + '/'
        # print(s3_tele_extract_output_path)
        # print(s3_trip_output_path)

        tenantid = '%' + tenantid_in + '%'

        # print(tenantid)

        opensearch_read_trip_start = \
            opensearch_read_trip_start.withColumn('timestamp',
                opensearch_read_trip_start['timestamp'
                ].cast(TimestampType()))

        opensearch_read_trip_end = \
            opensearch_read_trip_end.withColumn('timestamp',
                opensearch_read_trip_end['timestamp'
                ].cast(TimestampType()))

        opensearch_read_trip_break = \
            opensearch_read_trip_break.withColumn('break_start_timestamp'
                , opensearch_read_trip_break['break_start_timestamp'
                ].cast(TimestampType())).withColumn('break_end_timestamp'
                , opensearch_read_trip_break['break_end_timestamp'
                ].cast(TimestampType()))

        opensearch_read_trip_start = \
            func_case_col(opensearch_read_trip_start, '_trip_start')
        opensearch_read_trip_end = \
            func_case_col(opensearch_read_trip_end, '_trip_end')

        df_trip_start_end = \
            opensearch_read_trip_start.join(opensearch_read_trip_end,
                (opensearch_read_trip_start['vehicle_id_trip_start']
                == opensearch_read_trip_end['vehicle_id_trip_end'])
                & (opensearch_read_trip_start['trip_id_trip_start']
                == opensearch_read_trip_end['trip_id_trip_end']), 'left'
                )

                # # Merging logic started here

        windowspec_1 = Window.partitionBy('vehicle_id_trip_start'
                ).orderBy('timestamp_trip_start')

        df_trip_start_end_inter1 = \
            df_trip_start_end.withColumn('unix_timestamp_trip_end',
                F.unix_timestamp(F.to_timestamp(F.col('timestamp_trip_end'
                )))).withColumn('unix_timestamp_trip_start',
                                F.unix_timestamp(F.to_timestamp(F.col('timestamp_trip_start'
                                ))))

        df_trip_start_end_inter1 = \
            df_trip_start_end_inter1.withColumn('trips_break_time_ref1'
                , (F.lead(F.col('unix_timestamp_trip_start'
                )).over(windowspec_1) - F.col('unix_timestamp_trip_end'
                )) / 60).withColumn('trips_break_time_ref2',
                                    (F.col('unix_timestamp_trip_start')
                                    - F.lag(F.col('unix_timestamp_trip_end'
                                    )).over(windowspec_1)) / 60)

        df_trip_start_end_inter1 = \
            df_trip_start_end_inter1.drop('unix_timestamp_trip_end',
                'unix_timestamp_trip_start')

        df_trip_start_end_inter1 = \
            df_trip_start_end_inter1.withColumn('is_trips_break_ref1',
                F.when(F.col('trips_break_time_ref1'
                ).cast(IntegerType()) < 3,
                True).otherwise(False)).withColumn('is_trips_break_ref2'
                , F.when(F.col('trips_break_time_ref2'
                ).cast(IntegerType()) < 3, True).otherwise(False))

        df_trip_start_end_inter2 = \
            df_trip_start_end_inter1.withColumn('trip_break_session_change'
                , F.when((F.lag(F.col('is_trips_break_ref2'
                )).over(windowspec_1) == True)
                & (F.col('is_trips_break_ref2') == False),
                1).otherwise(0))

        df_trip_start_end_inter3 = \
            df_trip_start_end_inter2.withColumn('trip_session',
                F.sum('trip_break_session_change').over(windowspec_1))

        df_trip_no_ign_breaks = \
            df_trip_start_end_inter3.filter((F.col('is_trips_break_ref1'
                ) == False) & (F.col('is_trips_break_ref2') == False))

        df_trip_with_ign_breaks = \
            df_trip_start_end_inter3.filter((F.col('is_trips_break_ref1'
                ) == True) | (F.col('is_trips_break_ref2') == True))

        trip_merge_columns = [(F.first(col).alias(col) if '_trip_start'
                              in col and col != 'vehicle_id_trip_start'
                               else (F.last(col).alias(col) if '_trip_end'
                               in col else '')) for col in
                              df_trip_with_ign_breaks.columns]
        trip_merge_columns = [col for col in trip_merge_columns if col
                              is not '']

        derived_cols_for_merge = [
            'trips_break_time_ref1',
            'trips_break_time_ref2',
            'is_trips_break_ref1',
            'is_trips_break_ref2',
            'trip_break_session_change',
            'trip_session',
            ]

        df_trip_no_ign_breaks = \
            df_trip_no_ign_breaks.drop(*derived_cols_for_merge)

        df_trip_start_end_merge = \
            df_trip_with_ign_breaks.groupBy('vehicle_id_trip_start',
                'trip_session').agg(*trip_merge_columns)

        df_trip_start_end_merge = \
            df_trip_start_end_merge.drop('trip_session')

        df_trip_start_end_merge = \
            df_trip_start_end_merge.withColumn('trip_id_trip_end',
                F.col('trip_id_trip_start'
                )).select(*df_trip_start_end.columns)

        df_trip_start_end = \
            df_trip_start_end_merge.union(df_trip_no_ign_breaks)

        windowspec_2 = Window.partitionBy('vehicle_id_trip_start',
                'trip_session').orderBy('timestamp_trip_start')

        df_trip_ign_breaks = \
            df_trip_with_ign_breaks.withColumn('trip_break_id',
                F.first(F.col('trip_id_trip_start')).over(windowspec_2))

        df_trip_ign_breaks = df_trip_ign_breaks.select(
            F.col('vehicle_id_trip_start').alias('vehicle_id'),
            F.col('tenant_id_trip_start').alias('tenant_id'),
            F.col('campaign_name_trip_start').alias('campaign_name'),
            F.col('trip_break_id').alias('trip_id'),
            F.lead(F.col('trip_id_trip_start'
                   )).over(windowspec_2).alias('trip_sub_id'),
            F.col('timestamp_trip_end').alias('break_start_timestamp'),
            F.lead(F.col('timestamp_trip_start'
                   )).over(windowspec_2).alias('break_end_timestamp'),
            F.col('longitude_trip_end').alias('longitude'),
            F.col('latitude_trip_end').alias('latitude'),
            )

        df_trip_ign_breaks = \
            df_trip_ign_breaks.filter(F.col('break_end_timestamp'
                ).isNotNull())

        df_trip_non_ign_breaks = \
            opensearch_read_trip_break.alias('source_breaks'
                ).join(df_trip_ign_breaks.alias('ign_breaks'),
                       F.col('source_breaks.trip_id')
                       == F.col('ign_breaks.trip_sub_id'), how='left'
                       ).select(
            'source_breaks.vehicle_id',
            'source_breaks.tenant_id',
            'source_breaks.campaign_name',
            F.coalesce(F.col('ign_breaks.trip_id'),
                       F.col('source_breaks.trip_id')).alias('trip_id'
                    ),
            F.lit('').alias('trip_sub_id'),
            'source_breaks.break_start_timestamp',
            'source_breaks.break_end_timestamp',
            'source_breaks.longitude',
            'source_breaks.latitude',
            )

        df_trip_breaks = \
            df_trip_non_ign_breaks.union(df_trip_ign_breaks)
        df_trip_breaks = df_trip_breaks.drop('trip_sub_id')

        df_trip_start_end = \
            df_trip_start_end.withColumn('usable_energy_trip_start',
                F.col('usable_energy_trip_start'
                ).cast(DoubleType())).withColumn('fuel_value_trip_start'
                , F.col('fuel_value_trip_start'
                ).cast(DoubleType())).withColumn('odometer_reading_trip_start'
                , F.col('odometer_reading_trip_start'
                ).cast(DoubleType())).withColumn('soc_trip_start',
                F.col('soc_trip_start'
                ).cast(DoubleType())).withColumn('longitude_trip_start'
                , F.col('longitude_trip_start'
                ).cast(DoubleType())).withColumn('latitude_trip_start',
                F.col('latitude_trip_start').cast(DoubleType()))

        df_trip_start_end = \
            df_trip_start_end.withColumn('timestamp_trip_start',
                df_trip_start_end['timestamp_trip_start'
                ].cast(TimestampType())).withColumn('timestamp_trip_end'
                , df_trip_start_end['timestamp_trip_end'
                ].cast(TimestampType()))

        df_trip_breaks = func_case_col(df_trip_breaks, '_trip_break')

        df_trip_start_end = df_trip_start_end.join(df_trip_breaks,
                (df_trip_breaks['vehicle_id_trip_break']
                == df_trip_start_end['vehicle_id_trip_start'])
                & (df_trip_breaks['trip_id_trip_break']
                == df_trip_start_end['trip_id_trip_start']), 'left')

        df_trip_start_end = \
            df_trip_start_end.withColumn('trip_end_flag_trip_end',
                F.when(df_trip_start_end.vehicle_id_trip_end.isNull(),
                'True'
                ).otherwise(df_trip_start_end.trip_end_flag_trip_end)) \
                .withColumn('timestamp_trip_end'
                ,
                F.when(df_trip_start_end.vehicle_id_trip_end.isNull(),
                F.col('timestamp_trip_start'
                )).otherwise(df_trip_start_end.timestamp_trip_end)). \
                withColumn('trip_accuracy_trip_end'
                ,
                F.when(df_trip_start_end.vehicle_id_trip_end.isNull(),
                lit('Provisional'
                )).otherwise(df_trip_start_end.trip_accuracy_trip_end)) \
                .withColumn('trip_id_trip_end'
                ,
                F.when(df_trip_start_end.vehicle_id_trip_end.isNull(),
                F.col('trip_id_trip_start'
                )).otherwise(df_trip_start_end.trip_id_trip_end)). \
                withColumn('latitude_trip_end'
                ,
                F.when(df_trip_start_end.vehicle_id_trip_end.isNull(),
                F.col('latitude_trip_start'
                )).otherwise(df_trip_start_end.latitude_trip_end)). \
                withColumn('longitude_trip_end'
                ,
                F.when(df_trip_start_end.vehicle_id_trip_end.isNull(),
                F.col('longitude_trip_start'
                )).otherwise(df_trip_start_end.longitude_trip_end))
        
        ts_start='1970-01-01'
        if spark._jsparkSession.catalog().tableExists(database,
                table_name):

            if tenantid_in == 'EV-VIDA':
                df_target_ext = spark.read.format('hudi'
                        ).load(s3_trip_output_path)
                df_target_ext_tgt_1 = df_target_ext
                df_target_date = \
                    df_target_ext.select(F.max('timestamp_trip_start'
                        ).alias('timestamp_trip_start'))
                df_target_date = \
                    df_target_date.withColumn('timestamp_trip_start',
                        F.from_unixtime(F.unix_timestamp(df_target_date['timestamp_trip_start'
                        ])))

                if len(df_target_date.head(1)) > 0:
                    ts_start_var = \
                        df_target_date.withColumn('timestamp_trip_start'
                            , df_target_date['timestamp_trip_start']
                            - F.expr(interval))

                    ts_start = ts_start_var.collect()[0][0]
            else:

                df_val = spark.read.format('hudi').load(s3_output_path)
                df_target_ext_tgt_1 = df_val
                df_val = df_val.withColumn('timestamp_trip_start',
                        df_val['timestamp_trip_start']
                        - F.expr(interval))

                ts_start = df_val.agg({'timestamp_trip_start': 'max'
                        }).collect()[0][0]
        
        #ts_start='1970-01-01'

        df_trip_start_end_1 = \
            df_trip_start_end.where((df_trip_start_end['timestamp_trip_start'
                                    ] >= F.lit(ts_start))
                                    | (df_trip_start_end['timestamp_trip_end'
                                    ] >= F.lit(ts_start)))

        df_trip_start_end_uni = df_trip_start_end_1.withColumn('year',
                F.year(F.col('timestamp_trip_start'
                ))).withColumn('month',
                               F.month(F.col('timestamp_trip_start'
                               ))).withColumn('day',
                F.dayofmonth(F.col('timestamp_trip_start'
                ))).withColumn('hour',
                               F.hour(F.col('timestamp_trip_start')))

        df_trip_start_end_uni = \
            df_trip_start_end_uni.withColumn('total_distance_covered',
                F.col('odometer_reading_trip_end')
                - F.col('odometer_reading_trip_start'
                )).withColumn('overall_odo_reading',
                              df_trip_start_end_uni['odometer_reading_trip_end'
                              ]).withColumn('total_trip_time_minutes',
                F.round((F.unix_timestamp(F.to_timestamp('timestamp_trip_end'
                ))
                - F.unix_timestamp(F.to_timestamp('timestamp_trip_start'
                ))) / 60))

        df_trip_start_end_uni = \
            df_trip_start_end_uni.withColumn('soc_consumed',
                F.coalesce(df_trip_start_end_uni['soc_trip_end'],
                F.lit(0.0)) - df_trip_start_end_uni['soc_trip_start'])
        df_trip_start_end_uni = \
            df_trip_start_end_uni.withColumn('fuel_consumed',
                F.coalesce(df_trip_start_end_uni['fuel_value_trip_end'
                ], F.lit(0.0))
                - df_trip_start_end_uni['fuel_value_trip_start'])

        df_trip_start_end_uni = \
            df_trip_start_end_uni.withColumn('kwh_consumed',
                df_trip_start_end_uni['usable_energy_trip_end']
                - df_trip_start_end_uni['usable_energy_trip_start'])

        df_trip_start_end_uni = \
            df_trip_start_end_uni.withColumn('kwh_consumed_vs_dist',
                df_trip_start_end_uni['kwh_consumed']
                / df_trip_start_end_uni['total_distance_covered'])

        opensearch_read_trip_break = \
            func_case_col(opensearch_read_trip_break, '_trip_break')

        # # join with trip break

        df_trip_start_end_uni = \
            df_trip_start_end_uni.withColumn('trip_break_duration',
                F.round((F.unix_timestamp(F.to_timestamp('break_end_timestamp_trip_break'
                ))
                - F.unix_timestamp(F.to_timestamp('break_start_timestamp_trip_break'
                ))) / 60))

        df_trip_start_end_uni = \
            df_trip_start_end_uni.withColumn('latitude_trip_break',
                F.expr('CASE WHEN vehicle_id_trip_break is NULL THEN 0.0 \
                ELSE latitude_trip_break END AS latitude_trip_break'
                )).withColumn('longitude_trip_break',
                              F.expr('CASE WHEN vehicle_id_trip_break is NULL \
                              THEN 0.0 ELSE longitude_trip_break END AS longitude_trip_break'
                              ))

        # load telemetry data from hudi start

        if tenantid_in == 'EV-VIDA':
            df_target_tele = spark.read.format('hudi'
                    ).load(s3_tele_extract_output_path)

            df_target_tele = \
                df_target_tele.where(df_target_tele.tenantid.like(tenantid))
        else:
            df_target_tele = spark.read.format('hudi'
                    ).load(s3_tele_extract_output_path_other)
            df_target_tele = \
                df_target_tele.where(df_target_tele.tenantid.like(tenantid))

        df_target_tele = \
            df_target_tele.where(df_target_tele['collectioneventtime_ts'
                                 ] >= ts_start)

        # df_target_tele.cache()
        # #2609changed hmcl_ev_can0_vehicle_speed_vcu to hmcl_ev_can0_cluster_speed

        df_target_tele = \
            df_target_tele.withColumn('collectioneventtime_ts',
                df_target_tele['collectioneventtime_ts'
                ].cast(TimestampType()))

        df_target_tele = df_target_tele.select(
            'vid',
            'hmcl_ev_can0_cluster_speed',
            'hmcl_ev_can0_odo_vcu',
            'collectioneventtime',
            'collectioneventtime_ts',
            'hmcl_common_vcan0_latitude',
            'hmcl_common_vcan0_longitude',
            'hmcl_ev_can0_total_usable_energy',
            'hmcl_ev_can0_vehicle_mode_signal',
            'hmcl_ev_can0_soc_user_percentage',
            'hmcl_common_vcan0_fuel_level_volts',
            'hmcl_ev_can0_battery_pack_temperature',
            'hmcl_ev_can0_bms1_battery_pack_temperature',
            'hmcl_ev_can0_ambient_temperature',
            'hmcl_ice_can0_engine_temperture',
            'b2bclientid',
            )

        df_target_tele = df_target_tele.withColumn('collectioneventtime'
                , F.trim(F.col('collectioneventtime'
                ))).withColumn('collectioneventtime_ts',
                               F.trim(F.col('collectioneventtime_ts'
                               ))).withColumn('vid', F.trim(F.col('vid'
                )))

        df_target_tele = df_target_tele.withColumn('collectioneventtime'
                , df_target_tele['collectioneventtime'
                ].cast(LongType())).withColumn('collectioneventtime_ts'
                ,
                F.from_unixtime(F.unix_timestamp(F.col('collectioneventtime_ts'
                )), 'yyyy-MM-dd HH:mm:ss'))

        array_attr = [
            'hmcl_ev_can0_soc_user_percentage',
            'hmcl_common_vcan0_fuel_level_volts',
            'hmcl_ev_can0_battery_pack_temperature',
            'hmcl_ev_can0_bms1_battery_pack_temperature',
            'hmcl_ev_can0_ambient_temperature',
            'hmcl_ice_can0_engine_temperture',
            'hmcl_ev_can0_cluster_speed',
            'hmcl_ev_can0_odo_vcu',
            'hmcl_common_vcan0_latitude',
            'hmcl_common_vcan0_longitude',
            'hmcl_ev_can0_total_usable_energy',
            'hmcl_ev_can0_vehicle_mode_signal',
            ]

        latest_value_udf = F.udf(get_latest_value, StringType())
        for col in array_attr:
            df_target_tele = df_target_tele.withColumn(col,
                    latest_value_udf(F.col(col)))

        df_target_tele = \
            df_target_tele.withColumn('hmcl_ev_can0_soc_user_percentage'
                , F.col('hmcl_ev_can0_soc_user_percentage'
                ).cast(DoubleType())).withColumn('hmcl_common_vcan0_fuel_level_volts'
                , F.col('hmcl_common_vcan0_fuel_level_volts'
                ).cast(DoubleType())).withColumn('hmcl_ev_can0_battery_pack_temperature'
                , F.col('hmcl_ev_can0_battery_pack_temperature'
                ).cast(DoubleType())).withColumn('hmcl_ev_can0_bms1_battery_pack_temperature'
                , F.col('hmcl_ev_can0_bms1_battery_pack_temperature'
                ).cast(DoubleType())).withColumn('hmcl_ev_can0_ambient_temperature'
                , F.col('hmcl_ev_can0_ambient_temperature'
                ).cast(DoubleType())).withColumn('hmcl_ice_can0_engine_temperture'
                , F.col('hmcl_ice_can0_engine_temperture'
                ).cast(DoubleType()))

        df_target_tele = \
            df_target_tele.withColumn('hmcl_ev_can0_soc_user_percentage'
                , F.coalesce(F.col('hmcl_ev_can0_soc_user_percentage'),
                F.lit(0.0))).withColumn('hmcl_common_vcan0_fuel_level_volts'
                , F.coalesce(F.col('hmcl_common_vcan0_fuel_level_volts'
                ),
                F.lit(0.0))).withColumn('hmcl_ev_can0_battery_pack_temperature'
                ,
                F.coalesce(F.col('hmcl_ev_can0_battery_pack_temperature'
                ),
                F.lit(0.0))).withColumn('hmcl_ev_can0_bms1_battery_pack_temperature'
                ,
                F.coalesce(F.col('hmcl_ev_can0_bms1_battery_pack_temperature'
                ),
                F.lit(0.0))).withColumn('hmcl_ev_can0_ambient_temperature'
                , F.coalesce(F.col('hmcl_ev_can0_ambient_temperature'),
                F.lit(0.0))).withColumn('hmcl_ice_can0_engine_temperture'
                , F.coalesce(F.col('hmcl_ice_can0_engine_temperture'),
                F.lit(0.0)))

        df_target_tele = df_target_tele.withColumn('speed_value',
                F.coalesce(F.col('hmcl_ev_can0_cluster_speed'),
                F.lit(0.0))).withColumn('tele_trip_start_usable_energy'
                , F.coalesce(F.col('hmcl_ev_can0_total_usable_energy'),
                F.lit(0.0))).withColumn('tele_longitude',
                F.coalesce(F.col('hmcl_common_vcan0_longitude'),
                F.lit(0.0))).withColumn('tele_latitude',
                F.coalesce(F.col('hmcl_common_vcan0_latitude'),
                F.lit(0.0))).withColumn('tele_trip_start_vehicle_mode',
                F.coalesce(F.col('hmcl_ev_can0_vehicle_mode_signal'),
                F.lit(0))).withColumn('odometer_tele',
                F.coalesce(F.col('hmcl_ev_can0_odo_vcu'), F.lit(0)))

        # #odo end max of vid,tripid and collection

        df_trip_start_end_uni = \
            df_trip_start_end_uni.withColumn('timestamp_trip_start',
                F.from_unixtime(F.unix_timestamp('timestamp_trip_start'
                ), 'yyyy-MM-dd HH:mm:ss'
                )).withColumn('timestamp_trip_end',
                              F.from_unixtime(F.unix_timestamp('timestamp_trip_end'
                              ), 'yyyy-MM-dd HH:mm:ss'))

        df_trip_start_end_uni = \
            df_trip_start_end_uni.withColumn('vehicle_id_trip_start',
                F.trim(F.col('vehicle_id_trip_start'
                ))).withColumn('timestamp_trip_start',
                               F.trim(F.col('timestamp_trip_start'
                               ))).withColumn('timestamp_trip_end',
                F.trim(F.col('timestamp_trip_end')))

        df_trip_start_end_uni_1 = \
            df_trip_start_end_uni.where(F.col('trip_accuracy_trip_end')
                != 'Provisional')
        df_trip_start_end_uni_2 = \
            df_trip_start_end_uni.where((F.col('trip_accuracy_trip_end'
                ) == 'Provisional') | F.col('trip_accuracy_trip_end'
                ).isNull())

        df_trip_start_end_final_1 = \
            df_target_tele.join(F.broadcast(df_trip_start_end_uni_1),
                                (df_target_tele['vid']
                                == df_trip_start_end_uni_1['vehicle_id_trip_start'
                                ])
                                & (df_target_tele['collectioneventtime_ts'
                                ]
                                >= df_trip_start_end_uni_1['timestamp_trip_start'
                                ])
                                & (df_target_tele['collectioneventtime_ts'
                                ]
                                <= df_trip_start_end_uni_1['timestamp_trip_end'
                                ]), 'inner')

        df_trip_start_end_final_2 = \
            df_target_tele.join(F.broadcast(df_trip_start_end_uni_2),
                                (df_target_tele['vid']
                                == df_trip_start_end_uni_2['vehicle_id_trip_start'
                                ])
                                & (df_target_tele['collectioneventtime_ts'
                                ]
                                >= df_trip_start_end_uni_2['timestamp_trip_start'
                                ]), 'inner')

        df_trip_start_end_final = \
            df_trip_start_end_final_1.union(df_trip_start_end_final_2)

        w_tele = Window.partitionBy(F.col('trip_id_trip_start'),
                                    F.col('vehicle_id_trip_start'
                                    )).orderBy(F.col('collectioneventtime_ts'
                ).desc())

        df_trip_start_end_final = \
            df_trip_start_end_final.withColumn('odometer_end_tele',
                F.max('odometer_tele').over(w_tele))

        df_trip_start_end_final = \
            df_trip_start_end_final.withColumn('speed_value',
                F.coalesce(F.col('speed_value'),
                F.lit(0))).withColumn('odometer_end_tele',
                F.coalesce(F.col('odometer_end_tele'), F.lit(0)))

        w = Window.partitionBy(F.col('trip_id_trip_start'),
                               F.col('vehicle_id_trip_start'
                               )).orderBy('timestamp_trip_start')
        df_trip_start_end_final = \
            df_trip_start_end_final.withColumn('average_speed',
                F.avg('speed_value').over(w))

        # Renamed top_speed to max_speed

        df_trip_start_end_final = \
            df_trip_start_end_final.withColumn('max_speed',
                F.max('speed_value').over(w))

        df_trip_start_end_final = \
            df_trip_start_end_final.withColumn('average_engine_temperature'
                , F.avg('hmcl_ice_can0_engine_temperture').over(w))

        w = Window.partitionBy(F.col('trip_id_trip_start'),
                               F.col('vehicle_id_trip_start'
                               )).orderBy(F.col('collectioneventtime_ts'
                ).desc())
        w2 = Window.partitionBy(F.col('trip_id_trip_start'),
                                F.col('vehicle_id_trip_start'))

        df_trip_start_end_final = \
            df_trip_start_end_final.withColumn('row_num',
                row_number().over(w))

        w_energy = Window.partitionBy('vehicle_id_trip_start',
                'trip_id_trip_start').orderBy(F.col('row_num').asc())

        df_trip_start_end_final = \
            df_trip_start_end_final.withColumn('tele_trip_end_usable_energy'
                , F.lead(F.col('tele_trip_start_usable_energy'
                )).over(w_energy))

        df_trip_start_end_final = \
            df_trip_start_end_final.withColumn('tele_trip_end_odometer_tele'
                , F.lead(F.col('odometer_tele')).over(w_energy))

        df_trip_start_end_final = \
            df_trip_start_end_final.withColumn('last_val_fil',
                F.last(F.col('row_num')).over(w2))
        df_trip_start_end_final = \
            df_trip_start_end_final.filter((df_trip_start_end_final['row_num'
                ] < df_trip_start_end_final['last_val_fil'])
                | (df_trip_start_end_final['row_num'] == 1))

        df_trip_start_end_final = \
            df_trip_start_end_final.withColumn('tele_trip_end_usable_energy'
                , F.coalesce(F.col('tele_trip_end_usable_energy'),
                F.lit(0.0))).withColumn('tele_trip_start_usable_energy'
                , F.coalesce(F.col('tele_trip_start_usable_energy'),
                F.lit(0.0))).withColumn('tele_trip_end_odometer_tele',
                F.coalesce(F.col('tele_trip_end_odometer_tele'),
                F.lit(0))).withColumn('odometer_tele',
                F.coalesce(F.col('odometer_tele'), F.lit(0)))


        df_trip_start_end_final = \
            df_trip_start_end_final.withColumn('mode_wise_kwh_consumed'
                , F.col('tele_trip_end_usable_energy')
                - F.col('tele_trip_start_usable_energy'))

        df_trip_start_end_final = \
            df_trip_start_end_final.withColumn('mode_wise_kwh_consumed'
                , F.coalesce(F.col('mode_wise_kwh_consumed'),
                F.lit(0.0)))

        w_sum = Window.partitionBy(F.col('trip_id_trip_start'),
                                   F.col('vehicle_id_trip_start'),
                                   F.col('tele_trip_start_vehicle_mode'
                                   )).orderBy(F.col('collectioneventtime_ts'
                ).asc())

        w_sum_ener_1 = Window.partitionBy(F.col('trip_id_trip_start'),
                F.col('vehicle_id_trip_start'),
                F.col('tele_trip_start_vehicle_mode'
                )).orderBy(F.col('collectioneventtime_ts').desc())

        df_trip_start_end_final = \
            df_trip_start_end_final.withColumn('mode_wise_kwh_consumed'
                , F.sum(F.col('mode_wise_kwh_consumed')).over(w_sum))

        df_trip_start_end_final = \
            df_trip_start_end_final.withColumn('mode_wise_distance_covered'
                , F.col('tele_trip_end_odometer_tele')
                - F.col('odometer_tele'))

        df_trip_start_end_final = \
            df_trip_start_end_final.withColumn('mode_wise_distance_covered'
                , F.coalesce(F.col('mode_wise_distance_covered'),
                F.lit(0.0)))

        df_trip_start_end_final = \
            df_trip_start_end_final.withColumn('mode_wise_distance_covered'
                , F.sum(F.col('mode_wise_distance_covered'
                )).over(w_sum))

        df_trip_start_end_final = \
            df_trip_start_end_final.withColumn('mode_wise_kwh_consumed'
                , F.col('mode_wise_kwh_consumed'
                ).cast(DoubleType())).withColumn('mode_wise_distance_covered'
                , F.col('mode_wise_distance_covered'
                ).cast(DoubleType()))

        df_trip_start_end_final = \
            df_trip_start_end_final.withColumn('mode_wise_kwh_consumed_vs_dist'
                , F.col('mode_wise_kwh_consumed')
                / F.col('mode_wise_distance_covered'))

        df_trip_start_end_final = \
            df_trip_start_end_final.withColumn('mode_wise_kwh_consumed_vs_dist'
                , F.col('mode_wise_kwh_consumed_vs_dist'
                ).cast(DoubleType()))

        df_trip_start_end_final = \
            df_trip_start_end_final.withColumn('mode_wise_kwh_consumed_vs_dist'
                , F.coalesce(F.col('mode_wise_kwh_consumed_vs_dist'),
                F.lit(0.0)))

        df_trip_start_end_final = \
            df_trip_start_end_final.withColumn('row_num_ener',
                row_number().over(w_sum_ener_1))

        df_trip_start_end_final = \
            df_trip_start_end_final.where(F.col('row_num_ener') == 1)

        df_trip_start_end_final = \
            df_trip_start_end_final.drop('row_num_ener')

        df_trip_start_end_final = \
            df_trip_start_end_final.withColumn('tele_trip_start_vehicle_mode'
                ,
                F.expr("CASE WHEN tele_trip_start_vehicle_mode='0' THEN 'Eco mode' \
        WHEN tele_trip_start_vehicle_mode='1' THEN 'Ride mode' \
        WHEN tele_trip_start_vehicle_mode='2' THEN 'Sport mode' \
        WHEN tele_trip_start_vehicle_mode='3' THEN 'Park mode' \
        WHEN tele_trip_start_vehicle_mode='4' THEN '4' \
        WHEN tele_trip_start_vehicle_mode='5' THEN '5' \
        WHEN tele_trip_start_vehicle_mode='6' THEN '6' \
        WHEN tele_trip_start_vehicle_mode='7' THEN '7' \
        WHEN tele_trip_start_vehicle_mode='8' THEN 'Segment on' \
        WHEN tele_trip_start_vehicle_mode='9' THEN 'Segment off' \
        WHEN tele_trip_start_vehicle_mode='10' THEN 'All Blink_500ms' \
        WHEN tele_trip_start_vehicle_mode='11' THEN 'Custom mode' \
        WHEN tele_trip_start_vehicle_mode='12' THEN 'Safe mode on' \
        WHEN tele_trip_start_vehicle_mode='13' THEN 'Boost mode' \
        WHEN tele_trip_start_vehicle_mode='14' THEN 'Speed Limot' \
        else 'reserved' END as tele_trip_start_vehicle_mode"
                ))

        df_trip_start_end_agg = \
            df_trip_start_end_final.groupby(F.col('vehicle_id_trip_start'
                ), F.col('trip_id_trip_start'
                )).agg(F.collect_list(F.create_map(F.col('tele_trip_start_vehicle_mode'
                       ), F.col('mode_wise_kwh_consumed_vs_dist'
                       ))).alias('mode_wise_kwh_consumed_vs_dist'),
                       F.concat_ws(',',
                       F.last(F.col('tele_trip_start_vehicle_mode'
                       ))).alias('tele_trip_start_vehicle_mode_str'),
                       F.collect_list(F.create_map(F.col('tele_trip_start_vehicle_mode'
                       ), F.col('mode_wise_kwh_consumed'
                       ))).alias('mode_wise_kwh_consumed'),
                       F.collect_list(F.create_map(F.col('tele_trip_start_vehicle_mode'
                       ), F.col('mode_wise_distance_covered'
                       ))).alias('mode_wise_distance_covered'))  # F.concat_ws(",",F.last(F.col("mode_kwh_dict"))).alias("mode_wise_kwh_consumed_str"), \

        df_trip_start_end_agg = \
            df_trip_start_end_agg.withColumn('tele_trip_start_vehicle_mode'
                ,
                F.split(df_trip_start_end_agg['tele_trip_start_vehicle_mode_str'
                ], ','))

        df_trip_start_end_agg = \
            df_trip_start_end_agg.drop('mode_kwh_dict', 'mode_dist_dict'
                , 'vehicle_id_trip_start_mer', 'trip_id_trip_start_mer')

        df_trip_start_end_agg = \
            df_trip_start_end_agg.drop('mode_wise_kwh_consumed_str',
                'mode_wise_kwh_consumed_vs_dist_str',
                'tele_trip_start_vehicle_mode_str',
                'mode_wise_distance_covered_str')

        df_trip_start_end_final = \
            df_trip_start_end_final.drop('mode_wise_kwh_consumed',
                'mode_wise_kwh_consumed_vs_dist',
                'tele_trip_start_vehicle_mode',
                'mode_wise_distance_covered')

        df_trip_start_end_agg = \
            df_trip_start_end_agg.withColumn('vehicle_id_trip_start_agg'
                , F.col('vehicle_id_trip_start'
                )).withColumn('trip_id_trip_start_agg',
                              F.col('trip_id_trip_start'))

        df_trip_start_end_agg = \
            df_trip_start_end_agg.drop('trip_id_trip_start',
                'vehicle_id_trip_start')

        df_trip_start_end_final = \
            df_trip_start_end_final.join(df_trip_start_end_agg,
                (df_trip_start_end_final['vehicle_id_trip_start']
                == df_trip_start_end_agg['vehicle_id_trip_start_agg'])
                & (df_trip_start_end_final['trip_id_trip_start']
                == df_trip_start_end_agg['trip_id_trip_start_agg']),
                'left')

        df_trip_start_end_final = \
            df_trip_start_end_final.drop('vehicle_id_trip_start_agg',
                'trip_id_trip_start_agg')

        df_trip_start_end_final = \
            df_trip_start_end_final.withColumn('last_val',
                F.last(F.col('row_num')).over(w2))
        df_trip_start_end_final = \
            df_trip_start_end_final.filter(df_trip_start_end_final['row_num'
                ] == df_trip_start_end_final['last_val'])

        df_trip_start_end_final = \
            df_trip_start_end_final.withColumn('odometer_reading_trip_end'
                ,
                F.when(df_trip_start_end_final.vehicle_id_trip_end.isNull(),
                F.expr('CASE WHEN odometer_end_tele is NULL or odometer_end_tele==0 THEN \
                odometer_reading_trip_start ELSE odometer_end_tele END'
                )).otherwise(df_trip_start_end_final.odometer_reading_trip_end)).withColumn \
                ('timestamp_trip_end'
                ,
                F.when(df_trip_start_end_final.vehicle_id_trip_end.isNull(),
                F.expr('CASE WHEN collectioneventtime_ts is NULL THEN timestamp_trip_start \
                ELSE collectioneventtime_ts END'
                )).otherwise(df_trip_start_end_final.timestamp_trip_end)).withColumn('latitude_trip_end'
                ,
                F.when(df_trip_start_end_final.vehicle_id_trip_end.isNull(),
                F.col('tele_latitude'
                )).otherwise(df_trip_start_end_final.latitude_trip_end)).withColumn('longitude_trip_end'
                ,
                F.when(df_trip_start_end_final.vehicle_id_trip_end.isNull(),
                F.col('tele_longitude'
                )).otherwise(df_trip_start_end_final.longitude_trip_end)).withColumn('usable_energy_trip_end'
                ,
                F.when(df_trip_start_end_final.vehicle_id_trip_end.isNull(),
                F.col('tele_trip_end_usable_energy'
                ).cast(DoubleType())).otherwise(df_trip_start_end_final.usable_energy_trip_end)) \
                .withColumn('soc_trip_end'
                ,
                F.when(df_trip_start_end_final.vehicle_id_trip_end.isNull(),
                F.col('hmcl_ev_can0_soc_user_percentage'
                ).cast(DoubleType())).otherwise(df_trip_start_end_final.soc_trip_end)). \
                withColumn('fuel_value_trip_end'
                , F.col('hmcl_common_vcan0_fuel_level_volts'
                ).cast(DoubleType())).withColumn('battery_pack_temp_trip_end'
                , F.col('hmcl_ev_can0_battery_pack_temperature'
                )).withColumn('bms1_battery_pack_temperature_trip_end',
                              F.col('hmcl_ev_can0_bms1_battery_pack_temperature'
                              ).cast(DoubleType())).withColumn('ambient_temperature_trip_end'
                ,
                F.when(df_trip_start_end_final.vehicle_id_trip_end.isNull(),
                F.col('hmcl_ev_can0_ambient_temperature'
                ).cast(DoubleType())).otherwise(df_trip_start_end_final.ambient_temperature_trip_end))

        df_trip_start_end_final = \
            df_trip_start_end_final.withColumn('soc_consumed',
                F.coalesce(df_trip_start_end_final['soc_trip_end'],
                F.lit(0.0)) - df_trip_start_end_final['soc_trip_start'])
        df_trip_start_end_final = \
            df_trip_start_end_final.withColumn('fuel_consumed',
                F.coalesce(df_trip_start_end_final['fuel_value_trip_end'
                ], F.lit(0.0))
                - df_trip_start_end_final['fuel_value_trip_start'])

        df_trip_start_end_final = \
            df_trip_start_end_final.withColumn('trip_row_count',
                df_trip_start_end_final['last_val'])

        df_trip_start_end_final = df_trip_start_end_final.drop(
            'speed_value',
            'row_num',
            'hmcl_ev_can0_odo_vcu',
            'hmcl_ev_can0_cluster_speed',
            'hmcl_common_vcan0_longitude',
            'hmcl_common_vcan0_latitude',
            'speed_col',
            'odo_col',
            'vehicle_speed',
            'distance_accumulation',
            'collectioneventtimets',
            'hmcl_ev_can0_soc_user_percentage',
            'hmcl_common_vcan0_fuel_level_volts',
            'hmcl_ev_can0_battery_pack_temperature',
            'hmcl_ev_can0_bms1_battery_pack_temperature',
            'hmcl_ev_can0_ambient_temperature',
            'hmcl_ice_can0_engine_temperture',
            )

        df_trip_start_end_final = \
            df_trip_start_end_final.withColumn('odometer_reading_trip_end'
                ,
                F.when(df_trip_start_end_final.vehicle_id_trip_end.isNull(),
                F.expr('CASE WHEN odometer_end_tele is NULL or odometer_end_tele==0 \
                THEN odometer_reading_trip_start ELSE odometer_end_tele END'
                )).otherwise(df_trip_start_end_final.odometer_reading_trip_end)). \
                withColumn('timestamp_trip_end'
                ,
                F.when(df_trip_start_end_final.vehicle_id_trip_end.isNull(),
                F.expr('CASE WHEN collectioneventtime_ts is NULL THEN timestamp_trip_start \
                ELSE collectioneventtime_ts END'
                )).otherwise(df_trip_start_end_final.timestamp_trip_end)).withColumn('latitude_trip_end'
                ,
                F.when(df_trip_start_end_final.vehicle_id_trip_end.isNull(),
                F.col('tele_latitude'
                )).otherwise(df_trip_start_end_final.latitude_trip_end)).withColumn('longitude_trip_end'
                ,
                F.when(df_trip_start_end_final.vehicle_id_trip_end.isNull(),
                F.col('tele_longitude'
                )).otherwise(df_trip_start_end_final.longitude_trip_end)).withColumn('usable_energy_trip_end'
                ,
                F.when(df_trip_start_end_final.vehicle_id_trip_end.isNull(),
                F.col('tele_trip_end_usable_energy'
                ).cast(DoubleType())).otherwise(df_trip_start_end_final.usable_energy_trip_end))
        
        df_trip_start_end_final = \
            df_trip_start_end_final.withColumn('total_distance_covered'
                , F.col('odometer_reading_trip_end')
                - F.col('odometer_reading_trip_start'
                )).withColumn('overall_odo_reading',
                              df_trip_start_end_final['odometer_reading_trip_end'
                              ]).withColumn('total_trip_time_minutes',
                F.round((F.unix_timestamp(F.to_timestamp('timestamp_trip_end'
                ))
                - F.unix_timestamp(F.to_timestamp('timestamp_trip_start'
                ))) / 60))

        df_trip_start_end_final = \
            df_trip_start_end_final.withColumn('kwh_consumed',
                df_trip_start_end_final['usable_energy_trip_end']
                - df_trip_start_end_final['usable_energy_trip_start'])

        df_trip_start_end_final = \
            df_trip_start_end_final.withColumn('kwh_consumed_vs_dist',
                df_trip_start_end_final['kwh_consumed']
                / df_trip_start_end_final['total_distance_covered'])
        
        df_trip_start_end_final = df_trip_start_end_final.drop(
            'tele_latitude',
            'tele_longitude',
            'latitude_col',
            'longitude_col',
            'hmcl_common_vcan0_longitude',
            'hmcl_common_vcan0_latitude',
            'hmcl_ev_can0_total_usable_energy',
            'usable_energy_col',
            'tele_trip_end_usable_energy',
            'tele_trip_start_usable_energy',
            'odometer_tele',
            'tele_trip_end_odometer_tele',
            'hmcl_ev_can0_vehicle_mode_signal',
            'vehicle_mode_col',
            'last_val_fil',
            )

        hudi_options = {
            'hoodie.table.name': table_name,
            'hoodie.datasource.write.operation': 'upsert',
            'hoodie.datasource.write.precombine.field': 'collectioneventtime_ts',
            'hoodie.datasource.write.partitionpath.field': 'tenant_id_trip_start,year,month,day,hour',
            'hoodie.datasource.write.recordkey.field': 'vehicle_id_trip_start,trip_id_trip_start',
            'hoodie.datasource.hive_sync.enable': 'true',
            'hoodie.datasource.hive_sync.database': database,
            'hoodie.datasource.hive_sync.table': table_name,
            'hoodie.datasource.hive_sync.use_jdbc': 'false',
            'hoodie.datasource.hive_sync.mode': 'hms',
            'hoodie.datasource.hive_sync.support_timestamp': 'true',
            'path': s3_output_path,
            'hoodie.parquet.max.file.size': '134217728',
            'hoodie.schema.on.read.enable': 'true',
            'hoodie.datasource.write.schema.evolution.enable': 'true',
            'hoodie.datasource.write.schemaValidation': 'true',
            }

        df_trip_start_end_final = \
            df_trip_start_end_final.withColumn('id',
                F.concat(df_trip_start_end_final['vehicle_id_trip_start'
                ], df_trip_start_end_final['trip_id_trip_start']))

        df_trip_start_end_final = \
            df_trip_start_end_final.withColumn('longitude_trip_end',
                df_trip_start_end_final['longitude_trip_end'
                ].cast(DoubleType())).withColumn('latitude_trip_end',
                df_trip_start_end_final['latitude_trip_end'
                ].cast(DoubleType()))
        
        # Create a new schema with all fields set to nullable

        nullable_schema = StructType([StructField(field.name,
                field.dataType, True) for field in
                df_trip_start_end_final.schema.fields])
        df_trip_start_end_final = \
            spark.createDataFrame(df_trip_start_end_final.rdd,
                                  nullable_schema)
        
        if spark._jsparkSession.catalog().tableExists(database,
                table_name):

            # df_target_ext_tgt_1=spark.read.format("hudi").load(s3_trip_output_path)

            for field in df_target_ext_tgt_1.schema.fields:

                # print(field.dataType)

                if field.name not in df_trip_start_end_final.columns:
                    if 'StringType()' == field.dataType:
                        df_trip_start_end_final = \
                            df_trip_start_end_final.withColumn(field.name,
                                F.lit('').cast(field.dataType))
                    elif 'IntegerType()' == field.dataType \
                        or 'LongType()' == field.dataType:
                        df_trip_start_end_final = \
                            df_trip_start_end_final.withColumn(field.name,
                                F.lit(0).cast(field.dataType))
                    elif 'DoubleType()' == field.dataType \
                        or 'FloatType()' == field.dataType:
                        df_trip_start_end_final = \
                            df_trip_start_end_final.withColumn(field.name,
                                F.lit(0.0).cast(field.dataType))
                    else:
                        df_trip_start_end_final = \
                            df_trip_start_end_final.withColumn(field.name,
                                F.lit(None).cast(field.dataType))

                if field.name in df_trip_start_end_final.columns:
                    df_trip_start_end_final = \
                        df_trip_start_end_final.withColumn(field.name,
                            F.col(field.name).cast(field.dataType))
                    if 'StringType()' == field.dataType:
                        df_trip_start_end_final.fillna({field.name: ''})
                    elif 'IntegerType()' == field.dataType \
                        or 'LongType()' == field.dataType:
                        df_trip_start_end_final.fillna({field.name: 0})
                    elif 'DoubleType()' == field.dataType \
                        or 'FloatType()' == field.dataType:
                        df_trip_start_end_final.fillna({field.name: 0.0})
                        
        df_trip_start_end_final = \
            df_trip_start_end_final.drop('_hoodie_commit_seqno',
                '_hoodie_commit_time', '_hoodie_file_name',
                '_hoodie_partition_path', '_hoodie_record_key')
        
        df_trip_start_end_final = \
            df_trip_start_end_final.withColumn('mode_wise_kwh_consumed_vs_dist'
                , F.col('mode_wise_kwh_consumed_vs_dist'
                ).cast(ArrayType(MapType(StringType(), DoubleType()))))

        if len(df_trip_start_end_final.head(1)) > 0:
            df_trip_start_end_final.write.format('org.apache.hudi'
                    ).options(**hudi_options).mode('append').save()
        
        
        
        # ##write to OS

        df_trip_start_end_final_os = \
            df_trip_start_end_final.withColumn('collectioneventtime_ts'
                , df_trip_start_end_final['collectioneventtime_ts'
                ].cast(StringType())).withColumn('timestamp_trip_start'
                , df_trip_start_end_final['timestamp_trip_start'
                ].cast(StringType())).withColumn('timestamp_trip_end',
                df_trip_start_end_final['timestamp_trip_end'
                ].cast(StringType())).withColumn('break_end_timestamp_trip_break'
                ,
                df_trip_start_end_final['break_end_timestamp_trip_break'
                ].cast(StringType())).withColumn('break_start_timestamp_trip_break'
                ,
                df_trip_start_end_final['break_start_timestamp_trip_break'
                ].cast(StringType()))

        # df_trip_start_end_final_os = \
        #     df_trip_start_end_final_os.withColumn("mode_wise_kwh_consumed_vs_dist_obj",F.col("mode_wise_kwh_consumed_vs_dist"))
        # df_trip_start_end_final_os = \
        #     df_trip_start_end_final_os.drop('mode_wise_kwh_consumed_vs_dist'
        #         )
        
        df_trip_start_end_final_os = \
            df_trip_start_end_final_os.withColumn('latitude_trip_start'
                , F.coalesce(F.col('latitude_trip_start'),
                F.lit(0.0))).withColumn('longitude_trip_start',
                F.coalesce(F.col('longitude_trip_start'),
                F.lit(0.0))).withColumn('latitude_trip_break',
                F.coalesce(F.col('latitude_trip_break'),
                F.lit(0.0))).withColumn('longitude_trip_break',
                F.coalesce(F.col('longitude_trip_break'), F.lit(0.0)))

        df_trip_start_end_final_os = \
            df_trip_start_end_final_os.withColumn('latitude_trip_end',
                F.coalesce(F.col('latitude_trip_end'),
                F.col('latitude_trip_start'
                ))).withColumn('longitude_trip_end',
                               F.coalesce(F.col('longitude_trip_end'),
                               F.col('longitude_trip_start')))

        df_trip_start_end_final_os = \
            df_trip_start_end_final_os.withColumn('trip_start_location'
                , F.concat_ws(',', F.col('latitude_trip_start'),
                F.col('longitude_trip_start'
                ))).withColumn('trip_end_location', F.concat_ws(',',
                               F.col('latitude_trip_end'),
                               F.col('longitude_trip_end'
                               ))).withColumn('trip_break_location',
                F.concat_ws(',', F.col('latitude_trip_break'),
                F.col('longitude_trip_break')))

        df_trip_start_end_final_os = \
            df_trip_start_end_final_os.withColumnRenamed('odometer_reading_trip_end'
                , 'end_odo_reading'
                ).withColumnRenamed('campaign_name_trip_start',
                                    'campaingn_name'
                                    ).withColumnRenamed('campaingn_name_trip_start'
                , 'vehicle_id'
                ).withColumnRenamed('break_start_timestamp_trip_break',
                                    'timestamp_trip_break'
                                    ).withColumnRenamed('timestamp_trip_end'
                , 'trip_end_timestamp'
                ).withColumnRenamed('timestamp_trip_start',
                                    'trip_start_timestamp'
                                    ).withColumnRenamed('trip_id_trip_start'
                , 'trip_id'
                ).withColumnRenamed('odometer_reading_trip_start',
                                    'start_odo_reading')

        df_trip_start_end_final_os=df_trip_start_end_final_os.withColumn("end_odo_reading",F.col("end_odo_reading").cast(DoubleType()))

        df_trip_start_end_final_os = \
            df_trip_start_end_final_os.withColumn('trip_end_timestamp',
                F.date_format(F.col('trip_end_timestamp'),
                "yyyy-MM-dd'T'HH:mm:ss.SSS'Z'"
                )).withColumn('trip_start_timestamp',
                              F.date_format(F.col('trip_start_timestamp'
                              ), "yyyy-MM-dd'T'HH:mm:ss.SSS'Z'"
                              )).withColumn('timestamp_trip_break_start'
                , F.date_format(F.col('timestamp_trip_break'),
                "yyyy-MM-dd'T'HH:mm:ss.SSS'Z'"
                )).withColumn('break_end_timestamp_trip_break',
                              F.date_format(F.col('break_end_timestamp_trip_break'
                              ), "yyyy-MM-dd'T'HH:mm:ss.SSS'Z'"))

        os_stream_dynamic_hero = \
            DynamicFrame.fromDF(df_trip_start_end_final_os,
                                glueContext, 'convert')

        os_stream_dynamic_hero = \
            os_stream_dynamic_hero.resolveChoice(specs=[('timestamp_trip_break'
                , 'cast:timestamp')])

        glueContext.write_dynamic_frame.from_options(frame=os_stream_dynamic_hero,
                connection_type='opensearch', connection_options={
            'connectionName': os_connector_name,
            'opensearch.resource': os_trip_stat_index,
            'opensearch.write.operation': 'upsert',
            'opensearch.mapping.id': 'id',
            })

        df_trip_start_end_final_os.foreach(count_elements)
        end_time = datetime.now()
        logging.info('Calling log_audit to log the status as completed')

        log_audit(
            spark,
            args['JOB_NAME'],
            source_name,
            source_type,
            target,
            target_type,
            'Completed',
            start_time,
            end_time,
            count_accum.value,
            audit_path,
            audit_table,
            )

        logging.info('job completed')
    except Exception as exp:

        logging.error('An error occurred: %s', str(exp))
        end_time = datetime.now()
        logging.info('Calling log_audit to log the status Failed')
        log_audit(
            spark,
            args['JOB_NAME'],
            source_name,
            source_type,
            target,
            target_type,
            'Failed',
            start_time,
            end_time,
            None,
            audit_path,
            audit_table,
            )

        raise


if __name__ == '__main__':
    os_trip_start_index_ev = os_trip_start_index + '-ev-vida-stream'
    os_trip_end_index_ev = os_trip_end_index + '-ev-vida-stream'
    os_trip_break_index_ev = os_trip_break_index + '-ev-vida-stream'
    os_trip_stat_index_ev = os_trip_stat_index \
        + '-ev-vida-stream-000001'

    os_trip_start_index_hero = os_trip_start_index + '-ice-hero-stream'
    os_trip_end_index_hero = os_trip_end_index + '-ice-hero-stream'
    os_trip_break_index_hero = os_trip_break_index + '-ice-hero-stream'
    os_trip_stat_index_hero = os_trip_stat_index \
        + '-ice-hero-stream-000001'

    os_trip_start_index_harley = os_trip_start_index \
        + '-ice-harley-stream'
    os_trip_end_index_harley = os_trip_end_index + '-ice-harley-stream'
    os_trip_break_index_harley = os_trip_break_index \
        + '-ice-harley-stream'
    os_trip_stat_index_harley = os_trip_stat_index \
        + '-ice-harley-stream-000001'

    logging.info('Job started')
    start_time = datetime.now()

    logging.info('job_name=%s', args.get('JOB_NAME'))
    logging.info('Calling log audit to log the status is job started')

    source_name = os_trip_start_index + '-' + os_trip_end_index + '-' \
        + os_trip_end_index
    target = table_name + '-' + os_trip_stat_index

    log_audit(
        spark,
        args['JOB_NAME'],
        source_name,
        source_type,
        target,
        target_type,
        'Started',
        start_time,
        None,
        None,
        audit_path,
        audit_table,
        )

    extract(os_trip_start_index_ev, os_trip_end_index_ev,
            os_trip_break_index_ev, os_trip_stat_index_ev, 'EV-VIDA')
    extract(os_trip_start_index_hero, os_trip_end_index_hero,
            os_trip_break_index_hero, os_trip_stat_index_hero,
            'ICE-HERO')
    extract(os_trip_start_index_harley, os_trip_end_index_harley,
            os_trip_break_index_harley, os_trip_stat_index_harley,
            'ICE-HARLEY')

    end_time = datetime.now()
    logging.info('Calling log_audit to log the status as completed')

    log_audit(
        spark,
        args['JOB_NAME'],
        source_name,
        source_type,
        target,
        target_type,
        'Completed',
        start_time,
        end_time,
        count_accum.value,
        audit_path,
        audit_table,
        )

    logging.info('job completed')
