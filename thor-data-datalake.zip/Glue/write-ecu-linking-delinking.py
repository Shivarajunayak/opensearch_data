
# pylint: disable=import-error, invalid-name, too-many-locals, too-many-statements, broad-except
import sys
import logging
from datetime import datetime,timedelta
import boto3
import json
import traceback
import psycopg2
import snowflake.connector
import re

# import logging

from awsglue.utils import getResolvedOptions
from pyspark.sql import functions as F
from pyspark.sql.functions import lit 

from hmcl_cv_common_utilities import (
    log_audit,get_cloudwatch_url,
    send_sns_notification,
    load_yaml_config,
    fetch_postgres_credentials,
    validate_audit_table_with_s3_partition,
    get_watermark_timestamp,
    update_watermark_file,
    initialize_spark_session,
    get_postgres_jdbc_properties,
    fetch_snowflake_credentials,
    get_snowflake_connection
)
logging.basicConfig(
    level=logging.INFO, format="%(asctime)s - %(name)s - %(levelname)s - %(message)s"
)

postgresl_driver = "org.postgresql.Driver"

#Allow only alphanumeric characters and underscores in identifiers.
def sanitize_identifier(identifier):
    if not re.match(r'^[a-zA-Z_][a-zA-Z0-9_]*$', identifier):
        raise ValueError(f"Invalid identifier: {identifier}")
    return identifier
 
def get_snowflake_connection(sfUser,sfPassword,sfURL):
    """
    Establish and return a Snowflake connection.
    """
    try:
        conn = snowflake.connector.connect(
        user=sfUser,
        password=sfPassword,
        account = sfURL.split('//')[1].split('.snowflakecomputing.com')[0]
    )
        logging.info("Snowflake connection established.")
        return conn
    except Exception as e:
        logging.error(f"Error establishing Snowflake connection: {str(e)}")
        traceback.print_exc()
        raise
    
def read_postgres_table(spark, jdbc_url,source_table_name1,source_table_name2, latest_watermark, db_user, db_password, postgres_driver, updated_time_col):
    """
    Read data incrementally from PostgreSQL using a timestamp or bigint column, handling both cases dynamically.
    """
    try:
        # Get JDBC properti
        jdbc_properties = get_postgres_jdbc_properties(db_user, db_password, postgres_driver)

        # Sanitize table and column names
        schema = source_table_name1.split('.')[0]
        table_name1 = source_table_name1.split('.')[1]
        table_name2 = source_table_name2.split('.')[1]
        schema = sanitize_identifier(schema)
        table_name1 = sanitize_identifier(table_name1)
        table_name2 = sanitize_identifier(table_name2)
        updated_time_col = sanitize_identifier(updated_time_col)
        logging.info(f"Sanitized tables: {source_table_name1},{source_table_name1} and column name: {updated_time_col}")

        # Construct the SQL query
        query = f"""
        (SELECT 
            t.id,
            t.linked_on,
            v.vin, v.vid,
            v.tenant_id,
            v.model,v.year,  
            t.tcu_id, t.ecu_id, t.created_tsp, t.updated_tsp, t.is_active, t.is_deleted
        FROM 
            {source_table_name1} v
        JOIN 
            {source_table_name2} t
        ON 
            v.tcu_mapping_id = t.id
            WHERE t.{updated_time_col} >= {latest_watermark}) AS temp
            """
        logging.info(f"Constructed SQL query: {query}")

        # Execute the query and fetch data
        df = spark.read.jdbc(url=jdbc_url, table=query, properties=jdbc_properties)
        new_pg_rows = df.count()
        df_schema = df.schema
        logging.info(f"Fetched {new_pg_rows} rows from PostgreSQL")

        return df,df_schema

    except Exception as e:
        logging.exception(f"Error fetching PostgreSQL data from tables {source_table_name1} , {source_table_name2} and column {updated_time_col}: {str(e)}")
        raise

def fetch_schemas(landing_table):
    """
    Fetches schemas from PostgreSQL and compares them with landing table schema.
    """
    hudi_columns = {
        '_hoodie_record_key', '_hoodie_commit_seqno', '_hoodie_commit_time',
        '_hoodie_file_name', '_hoodie_partition_path', '_hoodie_commit_time_land_cal',
        'p_year', 'p_month', 'p_day'
    }
    
    pg_table_columns = set(['ID', 'LINKED_ON', 'VIN', 'VID', 'TENANT_ID', 'MODEL', 'YEAR', 'TCU_ID', 'ECU_ID', 'CREATED_TSP', 'UPDATED_TSP', 'IS_ACTIVE', 'IS_DELETED'])
    
    hudi_columns = set(col.upper() for col in hudi_columns)
    landing_columns = set(col.upper() for col in landing_table.columns) - hudi_columns
    
    return pg_table_columns, landing_columns

def compare_schemas(pg_table_columns, landing_columns, target_table_columns):
    """
    Compares the schemas and identifies missing and new columns.
    """
    missing_columns_pg = list(landing_columns - pg_table_columns)
    new_columns_pg = list(pg_table_columns - landing_columns)
    
    exclude_columns = {'MODEL', 'YEAR', 'UPDATED_TSP'}
    pg_table_columns_filtered = set(col for col in pg_table_columns if col not in exclude_columns)
    missing_columns_target = list(pg_table_columns_filtered - target_table_columns)
    
    exclude_columns_from_target = {'VEHICLE_MODEL'}
    target_table_columns_filtered = set(col for col in target_table_columns if col not in exclude_columns_from_target)
    new_columns_target = list(target_table_columns_filtered - pg_table_columns_filtered)
    
    return missing_columns_pg,new_columns_pg,missing_columns_target,new_columns_target



def handle_schema_mismatch(spark, job_name, source_table_name, target_table_name, start_time, audit_path, audit_table, sns_secret_name, missing_columns,region_name):
    """
    Handles schema mismatches by logging and raising a notification.
    """
    schema_status = "Aborted"
    error_message = f"Missing columns in source table: {', '.join(missing_columns)}"
    logging.error(error_message)
    
    # Log the error
    end_time = datetime.now()
    duration = (end_time - start_time).seconds
    log_audit(spark, job_name, source_table_name, "source_type", target_table_name, "target_type", schema_status, start_time, end_time, None, audit_path, audit_table)
    
    # Send SNS notification
    subject = f"Job {job_name} - Aborted for table {source_table_name} - Schema Validation Failed"
    send_sns_notification(subject[:98] + '..' if len(subject) > 100 else subject, error_message, sns_secret_name,region_name)
    
    raise ValueError(error_message)


def handle_new_columns(sns_secret_name, job_name, source_table_name, new_columns,region_name):
    """
    Handles the detection of new columns by sending a notification.
    """
    schema_status = "New columns detected"
    new_columns_message = f"New columns detected in source table: {', '.join(new_columns)}"
    logging.warning(new_columns_message)
    
    # Send SNS notification
    subject = f"Job - {job_name} Succeeded for table {source_table_name}- with new Schema "
    send_sns_notification(subject[:98] + '..' if len(subject) > 100 else subject, new_columns_message, sns_secret_name,region_name)

def add_buffer_to_hudi_commit_time(hudi_timestamp,num_of_hours):
    
    try:
        # Parse the timestamp to a datetime object
        parsed_time = datetime.strptime(hudi_timestamp[:-3], "%Y%m%d%H%M%S")
        # Subtract one hour
        time_one_hour_back = parsed_time - timedelta(hours=num_of_hours)
        # Format it back to the Hudi timestamp format
        new_hudi_timestamp = time_one_hour_back.strftime("%Y%m%d%H%M%S") + hudi_timestamp[-3:]
        return new_hudi_timestamp
    
    except Exception as e:
        logging.error(f"Error while adding buffer to hudi commit time :{str(e)}")
        raise


def get_evaluated_schema(spark,conn, landing_table, target_table_name, sns_secret_name, source_table_name, start_time, job_name, audit_path, audit_table,region_name):
    """
    Adjust schema based on target table schema and send notifications if there are discrepancies.
    """
    try:
        schema_status = "Success"
        
        # Fetch schema from PostgreSQL and validate
        pg_table_schema, landing_columns = fetch_schemas(landing_table)

        target_table_columns = get_table_schema(conn, target_table_name, exclude_columns=['TCU_MAPPING_ID','YEAR_OF_MFG','UPDATION_DATE'])
        
        # Compare schemas and detect missing/new columns
        missing_columns_pg,new_columns_pg,missing_columns_target,new_columns_target = compare_schemas(pg_table_schema, landing_columns,target_table_columns)
        
        if missing_columns_pg:
            handle_schema_mismatch(spark, job_name, source_table_name, target_table_name, start_time, audit_path, audit_table, sns_secret_name, missing_columns_pg,region_name)
        elif missing_columns_target:
            handle_schema_mismatch(spark, job_name, source_table_name, target_table_name, start_time, audit_path, audit_table, sns_secret_name, missing_columns_target,region_name)
        elif new_columns_target:
            handle_new_columns(sns_secret_name, job_name, source_table_name, new_columns_target,region_name)
        elif new_columns_pg:
            handle_new_columns(sns_secret_name, job_name, source_table_name, new_columns_pg,region_name)
        return schema_status

    except Exception as e:
        logging.error("An error occurred while fetching schema from source table: %s", str(e))
        logging.error("Traceback: %s", traceback.format_exc())
        raise

def get_table_schema(conn, table_name, exclude_columns=None):

    exclude_columns = exclude_columns or []
    schema_query = f"DESCRIBE TABLE {table_name}"
    schema_result = conn.cursor().execute(schema_query)
    schema_columns = [row[0] for row in schema_result]  # Assuming the first column in result is the column name
    # Exclude specified columns
    schema_columns = set([col for col in schema_columns if col not in exclude_columns])
    return schema_columns

def get_snowflake_options(secret_dict):
    """
    Create a dictionary of Snowflake options for Spark DataFrame writes.
    """
    return {
        "sfURL": secret_dict['url'],
        "sfDatabase": secret_dict['database'],
        "sfSchema": secret_dict['schema'],
        "sfWarehouse": secret_dict['warehouse'],
        "sfRole": secret_dict['role'],
        "sfUser": secret_dict['username'],
        "sfPassword": secret_dict['password']
    }

def check_table_exists(spark,conn, target_table_name, job_name, sns_secret_name, region_name, start_time, audit_path, audit_table,source_table_name,source_type,target_type):
    # Extract the table name (assumes target_table is in format 'database.schema.table')
    table_name = target_table_name.split('.')[2]
    
    # Create the query to check if the table exists
    check_table_query = f"SHOW TABLES LIKE '{table_name}'"
    
    # Execute the query to check if the table exists
    cursor = conn.cursor()
    cursor.execute(check_table_query)
    table_exists = cursor.fetchone()
    
    if not table_exists:
        # Log the error and notify via SNS
        logging.error(f"Target table {target_table_name} does not exist. Aborting job.")
        end_time = datetime.now()
        # Log the audit information
        log_audit(spark, job_name, source_table_name, source_type, target_table_name, target_type, "Aborted", start_time, end_time, None, audit_path, audit_table)
        
        # Send SNS notification about the failure
        subject = f"{job_name} failed - Missing Target Table"
        if len(subject)>100:
            subject = subject[:97] + '..'
        send_sns_notification("job failed", f"The target table {target_table_name} does not exist.", sns_secret_name, region_name)
        
        # Optional: Raise an exception or return early to stop the job
        raise Exception(f"Target table {target_table_name} does not exist. Job aborted.")
    
def write_to_snowflake(df, target_table, snowflake_secret_name):
    """
    Write the Spark DataFrame to a Snowflake table.

    Args:
        df (pyspark.sql.DataFrame): The Spark DataFrame to be written.
        table_name (str): The target Snowflake table name.
        snowflake_secret_name (str): The name of the secret containing Snowflake credentials.
    """
    try:
        # Fetch Snowflake credentials
        secret_dict = fetch_snowflake_credentials(snowflake_secret_name)
        logging.info("Snowflake credentials loaded successfully.")

        # Prepare Snowflake options
        options = get_snowflake_options(secret_dict)

        # Write DataFrame to Snowflake
        logging.info(f"Starting data write to Snowflake table: {target_table}")
        df.write \
            .format("snowflake") \
            .options(**options) \
            .option("dbtable", target_table) \
            .mode("overwrite") \
            .save()
        logging.info(f"Data written successfully to Snowflake table: {target_table}")
    except Exception as e:
        logging.error(f"Failed to write to Snowflake: {str(e)}")
        raise

def execute_merge_query(conn,query):
    """Execute the Snowflake MERGE query."""
    
    try:
        cursor = conn.cursor()
        cursor.execute(query)
    finally:
        cursor.close()
        conn.close()

def merge_source_to_target(conn, source_df, stage_table, target_table_name, snowflake_secret_name, primary_key_column):
    """
    Merge the source data from the specified stage table into the Snowflake target table.

    Parameters:
    - conn: Snowflake connection object.
    - vehicle_details: DataFrame containing vehicle details.
    - stage_table (str): Name of the Snowflake staging table.
    - target_table_name (str): Name of the Snowflake target table.
    - snowflake_secret_name (str): Secret name for Snowflake credentials.
    - primary_key_column (str): The primary key column used for the merge.
    """

    # Step 3: Write Data to Snowflake Staging Table
    write_to_snowflake(source_df, stage_table, snowflake_secret_name)

    # Step 4: Construct the Merge Query
    merge_query = f"""
    MERGE INTO {target_table_name} AS target
    USING (
        SELECT
			 "ID" AS "TCU_MAPPING_ID", "LINKED_ON", "VIN", "VID", "TENANT_ID", "MODEL", "YEAR", "TCU_ID", "ECU_ID", "CREATED_TSP", "UPDATED_TSP", "IS_ACTIVE", "IS_DELETED"
        FROM {stage_table}
    ) AS source
    ON target."{primary_key_column}" = source."{primary_key_column}"
    WHEN MATCHED THEN UPDATE SET
        target."TCU_MAPPING_ID" = source."TCU_MAPPING_ID",
        target."LINKED_ON" = source."LINKED_ON",
        target."VIN" = source."VIN",
        target."VID" = source."VID",
        target."TENANT_ID" = source."TENANT_ID",
        target."VEHICLE_MODEL" = source."MODEL",
        target."YEAR_OF_MFG" = source."YEAR",
		target."TCU_ID" = source."TCU_ID",
        target."ECU_ID" = source."ECU_ID",
        target."CREATED_TSP" = source."CREATED_TSP",
        target."UPDATION_DATE" = source."UPDATED_TSP",
		target."IS_ACTIVE" = source."IS_ACTIVE",
        target."IS_DELETED" = source."IS_DELETED"
    WHEN NOT MATCHED THEN INSERT (
        "TCU_MAPPING_ID", "LINKED_ON", "VIN", "VID", "TENANT_ID", "VEHICLE_MODEL", "YEAR_OF_MFG", "TCU_ID", "ECU_ID", "CREATED_TSP", "UPDATION_DATE", "IS_ACTIVE", "IS_DELETED"
    ) VALUES (
        source."TCU_MAPPING_ID", source."LINKED_ON", source."VIN", source."VID", source."TENANT_ID", source."MODEL", source."YEAR", source."TCU_ID", source."ECU_ID", source."CREATED_TSP", source."UPDATED_TSP", source."IS_ACTIVE", source."IS_DELETED"
    );
    """

    # Step 5: Execute the Merge Query
    execute_merge_query(conn, merge_query)

def read_yaml_file(s3_client,yaml_s3_bucket,yaml_file_key,source_table_name):
    try:
        # Read YAML file from S3
        yaml_dict = load_yaml_config(s3_client,yaml_s3_bucket,yaml_file_key)
        target_table_name = yaml_dict[source_table_name]['target_table_name']
        target_table_name_hudi = yaml_dict[source_table_name]['target_table_name_hudi']
        source_table_name1 = yaml_dict[source_table_name]['source_table_name1']
        source_table_name2 = yaml_dict[source_table_name]['source_table_name2']
        sns_secret_name = yaml_dict[source_table_name]['sns_secret_name']
        watermark_bucket = yaml_dict[source_table_name]['watermark_bucket']
        watermark_file_key = yaml_dict[source_table_name]['watermark_file_key']
        audit_path = yaml_dict[source_table_name]['audit_path']
        audit_table = yaml_dict[source_table_name]['audit_table']
        region_name = yaml_dict[source_table_name]['region']
        log_path = yaml_dict[source_table_name]['log_path']
        source_type = yaml_dict[source_table_name]['source_type']
        target_type = yaml_dict[source_table_name]['target_type']
        primary_key_column = yaml_dict[source_table_name]['primary_key_column']
        snowflake_secret_name = yaml_dict[source_table_name]['snowflake_secret_name']
        stage_table = yaml_dict[source_table_name]['stage_table']
        precombine_field = yaml_dict[source_table_name]['precombine_field']
        updated_time_col = yaml_dict[source_table_name]['updated_time_col']
        partition_extract_col = yaml_dict[source_table_name]['partition_extract_col']
        raw_bucket = yaml_dict[source_table_name]['raw_bucket']
        table_prefix = yaml_dict[source_table_name]['table_prefix']
        table_append = yaml_dict[source_table_name]['table_append_raw']
        recordkey = yaml_dict[source_table_name]['recordkey']
        rds_secret_name = yaml_dict[source_table_name]['rds_secret_name'] 
        target_database = yaml_dict[source_table_name]['target_database'] 
        partition_field = yaml_dict[source_table_name]['partition_field']
        logging.info("yaml parameters read successfully")
        return target_table_name,target_table_name_hudi,sns_secret_name,watermark_bucket,watermark_file_key,audit_path,audit_table,region_name,\
            log_path,source_type,target_type,primary_key_column,snowflake_secret_name,stage_table,precombine_field,\
            updated_time_col,partition_extract_col,raw_bucket,table_prefix,table_append,recordkey,rds_secret_name,target_database,partition_field,source_table_name1,source_table_name2

    except Exception as e:
        logging.error(f"Error while reading yaml parameters: {str(e)}")
        raise

def main():
    """
    Main method.
    """
    #initiating log
    log = {}
    timestamp_dtype = "timestamp without time zone"
    s3_client = boto3.client('s3')
    
    try:
        logging.info("Job started")

        start_time = datetime.now()
        

        # Initialize Spark session
        spark=initialize_spark_session()
        
        try:
                
            # Define arguments
            arguments = [
                "JOB_NAME",
                "yaml_s3_bucket",
                "yaml_file_key",
                "source_table_name",
                "audit_database"
            ]
    
            # Get the arguments
            args = getResolvedOptions(sys.argv, arguments)
            job_name = args.get("JOB_NAME")
            source_table_name = args.get("source_table_name")
            logging.info("job_name=%s", job_name+"/"+source_table_name)
            job_run_id = args.get("JOB_RUN_ID")
            logging.info(f"JOB_RUN_ID is :{job_run_id}")
            yaml_s3_bucket = args.get("yaml_s3_bucket")
            yaml_file_key = args.get("yaml_file_key")
            logging.info("Arguments resolved successfully.")
            logging.info(f"The job name is {job_name}")
        except Exception as e:
            logging.error(f"Error resolving arguments: {str(e)}")
            traceback.print_exc()
            raise
        
         # Load configurations
        try:
            yaml_dict = load_yaml_config(s3_client,yaml_s3_bucket,yaml_file_key)
            logging.info("Configurations loaded successfully.")
        except Exception as e:
            logging.error(f"Error loading configurations or credentials: {str(e)}")
            traceback.print_exc()
            raise

        # Extract and process configurations
        try:
            target_table_name,target_table_name_hudi,sns_secret_name,watermark_bucket,watermark_file_key,audit_path,audit_table,region_name,\
            log_path,source_type,target_type,primary_key_column,snowflake_secret_name,stage_table,precombine_field,\
            updated_time_col,partition_extract_col,raw_bucket,table_prefix,table_append,\
            recordkey,rds_secret_name,target_database,partition_field,source_table_name1,source_table_name2= read_yaml_file(s3_client,yaml_s3_bucket,yaml_file_key,source_table_name)
            
            if '.' in source_table_name:
                source_schema, source_table = source_table_name.split('.')
            
            year_partitioned=start_time.year
            month_partitioned=start_time.month
            #Validate the audit table to process the job based on job_status
            is_validate = validate_audit_table_with_s3_partition(spark,sns_secret_name,start_time,audit_path,audit_table,source_table_name,target_table_name,job_name,region_name,year_partitioned,month_partitioned)
            
            if is_validate == False:
                logging.error("Job is being aborted due to concurrent execution.")
                return
             # Extract PostgreSQL credentials from secret
            secret_dict = fetch_postgres_credentials(rds_secret_name,region_name)
            logging.info("rds_secret_name loaded successfully.")
            db_host = secret_dict['db.host']
            db_port = secret_dict['db.port']
            db_name = secret_dict['db.database']
            db_user = secret_dict['db.username']
            db_password = secret_dict['db.password']
            jdbc_url = f"jdbc:postgresql://{db_host}:{db_port}/{db_name}?user={db_user}&password={db_password}"
            logging.info("Configurations extracted and processed successfully.")
        except KeyError as e:
            logging.error(f"Configuration key error: {str(e)}")
            traceback.print_exc()
            raise
        except Exception as e:
            logging.error(f"Error processing configurations: {str(e)}")
            traceback.print_exc()
            raise
        
        log_audit(
            spark,
            job_name,
            source_table_name,
            source_type,
            target_table_name,
            target_type,
            "Started",
            start_time,
            None,
            None,
            audit_path,
            audit_table,
        )

        #cloudwatch url for tracking the logs in the email alert.
        cloudwatch_url = get_cloudwatch_url(region_name,job_name,job_run_id)
        

        target_path = "s3://" + raw_bucket + "/" + table_prefix + "_" + table_append + "/"
        
        #fetch snowflake credentials
        secret_dict = fetch_snowflake_credentials(snowflake_secret_name)
        logging.info("Snowflake credentials loaded successfully")
        sfURL = secret_dict['url']
        sfPassword = secret_dict['password']
        sfUser = secret_dict['username']
        
        # Initialize Snowflake connection
        conn=get_snowflake_connection(sfUser,sfPassword,sfURL)

        check_table_exists(spark,conn, target_table_name, job_name, sns_secret_name, region_name, start_time, audit_path, audit_table,source_table_name,source_type,target_type)
        # Continue job logic if table exists

         # Check if the target table exists
        if spark._jsparkSession.catalog().tableExists(target_database, target_table_name_hudi):
            try:
                # Read the existing landing table
                landing_table = spark.read.format("hudi").load(target_path).limit(0)
                logging.info(f"Landing table schema: {landing_table.schema}")
                
                
                # Perform schema evaluation and possible evolution
                schema_status = get_evaluated_schema(spark,conn, landing_table, target_table_name, sns_secret_name, source_table_name, start_time, job_name, audit_path, audit_table,region_name)
                
                logging.info(f"Schema status after evaluation: {schema_status}")
                
                if schema_status == "Aborted":
                    logging.error("Schema validation failed. Aborting the job.")
                    return False
                else:
                    logging.info("Schema validation successfull.")
            except Exception as e:
                logging.error(f"Unexpected error: {str(e)}")
        
        else:
            logging.info("Landing table does not exist. No schema validation performed.")
        
        latest_watermark = get_watermark_timestamp(s3_client,watermark_bucket,watermark_file_key)
        # read_watermark_from_s3(watermark_bucket, watermark_file_key,s3_client,source_table_name)
        logging.info(f"latest_watermark is for :{latest_watermark}")
        
        source_df,source_schema = read_postgres_table(spark, jdbc_url,source_table_name1,source_table_name2, latest_watermark, db_user, db_password, postgresl_driver, updated_time_col)
        logging.info(f"source_schema is : {source_schema}")
        
        num_records = source_df.count()
        if num_records > 0:
            try :

            # source_df,data_type=transform_source_data(db_host,db_port, db_name, db_user, db_password,source_schema,source_table, source_table_name, updated_time_col,precombine_field,source_df,timestamp_dtype)
                df_evaluated = source_df.withColumn("p_year", F.year((F.col(partition_extract_col) / 1000).cast("timestamp")))
                df_evaluated = df_evaluated.withColumn("p_month", F.month((F.col(partition_extract_col) / 1000).cast("timestamp")))
                df_evaluated = df_evaluated.withColumn("p_day", F.dayofmonth((F.col(partition_extract_col) / 1000).cast("timestamp")))
                
            except Exception as e:
                logging.error(f"An error occured while creating the columns {partition_extract_col} for partitioning.")

            # Log the schema and sample data after transformations
            logging.info(f"Schema after transformations: {df_evaluated.schema}")

            # Define Hudi options
            logging.info("Defining Hudi options")
            hudi_options = {
                "hoodie.table.name": target_table_name_hudi,
                "hoodie.datasource.write.storage.type": "COPY_ON_WRITE",
                "hoodie.datasource.write.recordkey.field": recordkey,
                "hoodie.datasource.write.operation": "upsert",
                "hoodie.datasource.write.precombine.field": precombine_field,
                "hoodie.datasource.write.partitionpath.field": partition_field,
                "hoodie.datasource.hive_sync.enable": "true",
                "hoodie.datasource.hive_sync.database": target_database,
                "hoodie.datasource.hive_sync.table": target_table_name_hudi,
                "hoodie.datasource.hive_sync.use_jdbc": "false",
                "hoodie.datasource.hive_sync.mode": "hms",
                "hoodie.datasource.hive_sync.sync_as_datasource": "false",
                "hoodie.datasource.hive_sync.support_timestamp": "true",
                "hoodie.avro.schema.allow.empty": "true",
                "hoodie.schema.on.read.enable": "true",
                "hoodie.datasource.hive_sync.partition_fields": partition_field,
                "path": target_path,
                "hoodie.parquet.max.file.size": "134217728",
            }
            
            logging.info(f"Data schema: {df_evaluated.schema}")
            
            logging.info("Proceeding with merge operation.")

            #get cloudwatch details
            cloudwatch_url = get_cloudwatch_url(region_name, job_name, job_run_id)
            end_time = datetime.now()
            duration = (end_time - start_time).seconds
            
        
            # Log audit
            log_audit(
                    spark,job_name,source_table_name,source_type,target_table_name,target_type,"Completed",start_time,end_time,\
                        num_records,audit_path,audit_table,
                    )

            # Write the DataFrame to Hudi
            try:
                logging.info(f"Writing DataFrame to Hudi table: {target_table_name_hudi}")
                df_evaluated.write.format("hudi").options(**hudi_options).mode("append").save()
                logging.info("Data successfully written to Hudi table")
            except Exception as e:
                logging.error(f"Failed to write data to Hudi table: {str(e)}")
                raise

            try:
                merge_source_to_target(conn,source_df, stage_table, target_table_name,snowflake_secret_name,primary_key_column)
                logging.info(f"Job completed successfully with processing {num_records} rows to snowflake target_table {target_table_name} in {duration} seconds")
            except Exception as e:
                logging.error(f"Failed to write data to snowflake target_table {target_table_name} table: {str(e)}")
                raise
            # Update the watermark if data was successfully written
            new_watermark = df_evaluated.agg({updated_time_col: "max"}).collect()[0][0]
            logging.info(f"new_watermark : {new_watermark}")
            update_watermark_file(s3_client,new_watermark,watermark_bucket,watermark_file_key,source_table_name)
         
        else:
            logging.info("No incremental data to write. Skipping Hudi write and snowflake merge operations.")
            
        logging.info("Job completed successfully")
       

        end_time = datetime.now()

        duration = (end_time - start_time).seconds
        
        
        log_audit(
            spark,
            job_name,
            source_table_name,
            source_type,
            target_table_name,
            target_type,
            "Completed",
            start_time,
            end_time,
            num_records,
            audit_path,
            audit_table,
        )
        

        # send_sns_notification(subject, message, sns_secret_name)
    except Exception as e:
        logging.error("Job failed with error :%s", str(e))
        end_time = datetime.now()
        duration = (end_time - start_time).seconds
        traceback.print_exc()
        
        cloudwatch_url = get_cloudwatch_url(region_name,job_name, job_run_id)
        error_code = getattr(e, 'code', 'N/A')  # Some exceptions might have a 'code' attribute
        if error_code == 'N/A':
            # Try to parse error code from the exception message if it's in a known format
            error_code = "Specific logic to parse error code from the exception message if possible"
            
        log = {
            "status": "failure",
            "job_name": job_name,
            "source_table": source_table_name,
            "target_table": target_table_name,
            "start_time": start_time.isoformat(),
            "end_time": end_time.isoformat(),
            "duration": duration,
            "error_code": error_code,
            "error": f"Error: {str(e)}\nTraceback: {traceback.format_exc()}"
        }
        
        try :
            
            log_audit(
                spark,
                job_name,
                source_table_name,
                source_type,
                target_table_name,
                target_type,
                "Failed",
                start_time,
                end_time,
                None,
                audit_path,
                audit_table,
            )
        except Exception as audit_exception:
            logging.error("An error occurred while entering logs to audit table: %s", str(audit_exception))
            logging.error("Traceback: %s", traceback.format_exc())
               
        
        log_message = "\n".join([f"{key}: {value}" for key, value in log.items()])
        
        message = f"Job {job_name} failed. Error: {str(e)}\nTraceback: {traceback.format_exc()} \n\n{log_message}.\n\nView the logs in CloudWatch:{cloudwatch_url}"
        
        subject =f'{job_name} failed for {source_table_name} table'
        if len(subject) > 100:
            subject = subject[:98] + '..'  # Truncate if needed
        
        send_sns_notification(subject, message, sns_secret_name,region_name)
        logging.error(f"Error: {str(e)}\nTraceback: {traceback.format_exc()}")
        raise
    finally:
        final_log = log.copy()  # Copy the current log
        yaml_params = {
        "job_name": job_name,
        "table_name": source_table_name,
        "log_path":log_path, 
        "audit_table": audit_table, 
        "audit_path":audit_path,
        "yaml_s3_bucket": yaml_s3_bucket,
        "yaml_file_path": yaml_file_key,
        "rds_secret_name": rds_secret_name, 
        "updated_time_col": updated_time_col,
        "partition_extract_col": partition_extract_col, 
        "target_table_name": target_table_name_hudi,
        "raw_bucket": raw_bucket, 
        "table_prefix": table_prefix,
        "table_append": table_append,
        "recordkey": recordkey, 
        "target_database": target_database,
        "partition_field": partition_field,
        "watermark_bucket":watermark_bucket,
        "watermark_folder":watermark_file_key
        }

        final_log.update(yaml_params)
        dt = datetime.now()
        epoch_time = int(dt.timestamp() * 1000)
        s3_client.put_object(Bucket=log_path, Key=f'logs/{job_name}-{source_table_name}_{epoch_time}_logs.json', Body=json.dumps(final_log))


if __name__ == "__main__":
    main()
