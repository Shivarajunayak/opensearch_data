import json
import sys
from pyspark.sql import Window
from awsglue.context import GlueContext
from functools import reduce
from datetime import datetime, timezone
from pyspark.sql import functions as F
from pyspark.sql.functions import col
from awsglue.utils import getResolvedOptions
import boto3
import snowflake.connector
import logging
from pyspark.sql.functions import col, current_timestamp, unix_timestamp, when
from pyspark.sql.types import StructType,StructField,StringType
import traceback
from hmcl_cv_common_utilities import (
    log_audit,
    load_yaml_config,
    initialize_spark_session,
    send_sns_notification,
    get_cloudwatch_url,
    fetch_postgres_credentials,
    get_watermark_timestamp,
    update_watermark_file,
    validate_audit_table_with_s3_partition
    )

logging.basicConfig(
    level=logging.INFO, format="%(asctime)s - %(name)s - %(levelname)s - %(message)s"
)


def fetch_opensearch_credentials(opensearch_secret_name, region_name):
    
    try:
        session = boto3.session.Session()
        client = session.client(service_name="secretsmanager", region_name = region_name)
        get_secret_value_response = client.get_secret_value(SecretId = opensearch_secret_name)
        secret = get_secret_value_response["SecretString"]
        logging.info("Opensearch credentials fetched successfully.")
        return json.loads(secret)
    except Exception as e:
        logging.error(
            f"Error fetching Opensearch credentials from Secrets Manager: {e}"
        )
        traceback.print_exc()
        raise
   
    
def read_job_parameters():
    try:
        # Define arguments
        arguments = [
            "JOB_NAME",
            "yaml_s3_bucket",
            "yaml_file_key",
        ]
        # Get the arguments
        args = getResolvedOptions(sys.argv, arguments)
        job_name = args.get("JOB_NAME")
        job_run_id = args.get("JOB_RUN_ID")
        yaml_s3_bucket = args.get("yaml_s3_bucket")
        yaml_file_key = args.get("yaml_file_key")
        logging.info("Job parameters read successfully")
        return job_name,job_run_id,yaml_s3_bucket,yaml_file_key
    
    except Exception as e:
        logging.error(f"Error while reading job parameters: {str(e)}")
        traceback.print_exc()
        raise
    
def read_yaml_file(s3_client,yaml_s3_bucket,yaml_file_key):
    try:
        # Read YAML file from S3
        yaml_dict = load_yaml_config(s3_client,yaml_s3_bucket,yaml_file_key)
        vehicle_snapshot_index_name = yaml_dict["vehicle_snapshot_index_name"]
        audit_table = yaml_dict["audit_table"]
        sns_secret_name = yaml_dict["sns_secret_name"]
        audit_path = yaml_dict["audit_path"]
        source_type = yaml_dict["source_type"]
        target_type = yaml_dict["target_type"]
        region_name = yaml_dict["region_name"]
        snowflake_secret_name = yaml_dict["snowflake_secret_name"]
        opensearch_connection_name = yaml_dict["opensearch_connection_name"]
        stage_table = yaml_dict["stage_table"]
        snowflake_target_table = yaml_dict["snowflake_target_table"]
        pg_secret_name = yaml_dict["pg_secret_name"]
        pg_secret_region = yaml_dict["pg_secret_region"]
        pg_vehicles_table = yaml_dict["pg_vehicles_table"]
        pg_vehicle_model_table = yaml_dict["pg_vehicle_model_table"]
        master_tele_bucket_name = yaml_dict["master_tele_bucket_name"]
        master_tele_hudi_path = yaml_dict["master_tele_hudi_path"]
        trip_stats_bucket_name = yaml_dict["trip_stats_bucket_name"]
        trip_stats_hudi_path = yaml_dict["trip_stats_hudi_path"]
        watermark_bucket = yaml_dict["watermark_bucket"]
        watermark_file_key = yaml_dict["watermark_file_key"]
        watermark_col_landing = yaml_dict["watermark_col_landing"]
        
        logging.info("yaml parameters read successfully")
        
        return opensearch_connection_name,audit_table,vehicle_snapshot_index_name,\
            sns_secret_name,audit_path,source_type,target_type,region_name,\
            snowflake_secret_name,stage_table,snowflake_target_table,watermark_bucket,watermark_file_key,watermark_col_landing, \
            pg_secret_name,pg_secret_region,pg_vehicles_table,master_tele_bucket_name,master_tele_hudi_path,trip_stats_bucket_name, \
                trip_stats_hudi_path,pg_vehicle_model_table 
    except Exception as e:
        logging.error(f"Error while reading yaml parameters: {str(e)}")
        traceback.print_exc()
        raise
    
def fetch_snowflake_credentials(secret_name):
    try:
        client = boto3.client('secretsmanager')
        response = client.get_secret_value(SecretId=secret_name)
        secret = json.loads(response['SecretString'])
        return secret
    except Exception as e:
        logging.error(f"Error while fetching snowflake credentials: {str(e)}")
        traceback.print_exc()
        raise   
     
def get_snowflake_connection(sfUser,sfPassword,sfURL):
    """
    Establish and return a Snowflake connection.
    """
    try:
        conn = snowflake.connector.connect(
        user=sfUser,
        password=sfPassword,
        account = sfURL.split('//')[1].split('.snowflakecomputing.com')[0]
    )
        logging.info("Snowflake connection established.")
        return conn
    except Exception as e:
        logging.error(f"Error establishing Snowflake connection: {str(e)}")
        traceback.print_exc()
        raise
    
def get_snowflake_options(secret_dict):
    """
    Create a dictionary of Snowflake options for Spark DataFrame writes.
    """
    return {
        "sfURL": secret_dict['url'],
        "sfDatabase": secret_dict['database'],
        "sfSchema": secret_dict['schema'],
        "sfWarehouse": secret_dict['warehouse'],
        "sfRole": secret_dict['role'],
        "sfUser": secret_dict['username'],
        "sfPassword": secret_dict['password']
    }

def load_data_into_snowflake_stage(df,snowflake_options,stage_table):
    try:
        # Write the DataFrame to a temporary Snowflake table
        df.write.format("snowflake") \
            .options(**snowflake_options) \
            .option("dbtable", stage_table) \
            .mode("overwrite") \
            .save()
    except Exception as e:
        logging.error(f"Error while loading data into snowflake stage: {str(e)}")
        traceback.print_exc()
        raise

def execute_merge_query(conn,query):
    """Execute the Snowflake MERGE query."""
    try:
        cursor = conn.cursor()
        cursor.execute(query)
    finally:
        cursor.close()
        conn.close()
        
def prepare_merge_query(columns,target_table,stage_table):
    
    coalesce_columns = {"can_data", "latest_trip_details"}
    
    update_col = [
    f"target.{col_} = COALESCE(source.{col_}, target.{col_})" if col_ in coalesce_columns else f"target.{col_} = source.{col_}" for col_ in columns]
    
    update_col_str = ','.join(update_col)
    insert_col_str = ', '.join(columns)
    values_col_str = ', '.join([f"source.{col_}" for col_ in columns])
    
    merge_query = f"""
            MERGE INTO {target_table} AS target
            USING {stage_table} AS source
            ON target.vid = source.vid
            WHEN MATCHED THEN
                UPDATE SET
                    {update_col_str}
            WHEN NOT MATCHED THEN
                INSERT ({insert_col_str})
                VALUES ({values_col_str})
            """
    logging.info(f"MERGE QUERY {merge_query}")
    return merge_query    
    

def load_df_into_snowflake_table(source_df,snowflake_secret_name,stage_table,target_table,columns):
    try: 
    
        secret_dict = fetch_snowflake_credentials(snowflake_secret_name)
        logging.info("Snowflake credentials loaded successfully.")
        snowflake_options = get_snowflake_options(secret_dict)
        
        sfURL = snowflake_options["sfURL"]
        sfUser = snowflake_options["sfUser"]
        sfPassword = snowflake_options["sfPassword"] 
        
        conn = get_snowflake_connection(sfUser,sfPassword,sfURL)
        
        source_df = source_df.dropDuplicates(["vid"])

        load_data_into_snowflake_stage(source_df,snowflake_options,stage_table)
        
        merge_query = prepare_merge_query(columns,target_table,stage_table)
        # Execute the Merge Query
        execute_merge_query(conn, merge_query)
    
    except Exception as e:
        logging.error(f"Error while loading data into target snowflake table: {str(e)}")
        traceback.print_exc()
        raise
    
    

def load_df_into_target_table(source_df,num_records,target_table_name,target_database,target_hudi_table_path,recordkey,partition_field):
    """
    This function loads  data into raw
    """
    try:
        logging.info(f"PARTITION VALUES  (partition_field) in main table load: {partition_field}")
        
        hudi_options = {
            "hoodie.table.name": target_table_name,
            "hoodie.datasource.write.operation": "insert",
            "hoodie.datasource.write.partitionpath.field": partition_field,
            "hoodie.datasource.write.recordkey.field": recordkey,
            "hoodie.datasource.hive_sync.enable": "true",
            "hoodie.datasource.hive_sync.database": target_database,
            "hoodie.datasource.hive_sync.table": target_table_name,
            "hoodie.datasource.hive_sync.use_jdbc": "false",
            "hoodie.datasource.hive_sync.mode": "hms",
            "hoodie.datasource.hive_sync.support_timestamp": "true",
            "path": target_hudi_table_path,
            "hoodie.parquet.max.file.size": "134217728",
        }
        
        source_df.write.format("org.apache.hudi").options(**hudi_options).mode(
            "append"
        ).save()
    
        logging.info(f"Data loaded successfully into {target_table_name} table,\
            no.of processed records count: {num_records}")
        return True
    except Exception as e:
        logging.error(f"Error while loading the data into table:{target_table_name}, {str(e)}")
        traceback.print_exc()
        raise


def get_vehicle_snapshot_query(watermark_timestamp):
    
    filter_query = {
    "query": {
        "range": {
            "updatedTsp": {
                "gt": watermark_timestamp
            }
        }
    }
    }

    filter_query_json = json.dumps(filter_query)
    return filter_query_json

def read_vehicle_snapshot(glue_context, resource, connection_name, filter_query_json):
    try:
        
        source_data = glue_context.create_dynamic_frame.from_options(
            connection_type="opensearch",
            connection_options={
                "connectionName": connection_name,
                "opensearch.port": 443,
                "opensearch.resource": resource,
                "opensearch.query": filter_query_json,
                "pushdown": "true",
                "opensearch.read.field.include": "vid,tenantId,updatedTsp,latitude.value,longitude.value,vehicleSpeedDisplay.value"
            },
        ).toDF()
        
        return source_data
    
    except Exception as e:
        logging.error("Error happened while reading vehicle snapshot from openasearch: %s", str(e))
        logging.error(traceback.format_exc())
        raise

def get_postgres_conn_details(secret_name,secret_region):
    try:
        # Extract PostgreSQL credentials from secret
        secret_dict = fetch_postgres_credentials(secret_name,secret_region)
        logging.info(f"SECRET INFO :{secret_dict}")
        logging.info("rds_secret_name loaded successfully.")
        db_host = secret_dict['db.host']
        db_port = secret_dict['db.port']
        db_name = secret_dict['db.database']
        db_user = secret_dict['db.username']
        db_password = secret_dict['db.password']
        
        jdbc_url = f"jdbc:postgresql://{db_host}:{db_port}/{db_name}?user={db_user}&password={db_password}"
        
        return db_host,db_port,db_name,db_user,db_password,jdbc_url
    except Exception as e:
        logging.error(f"Error While fetching Source PostgreSQL credentials from Secrets Manager: {e}")
        traceback.print_exc()
        raise
    

def read_postgres_table(spark,source_pg_secret_name,source_secret_region,pg_vehicles_table):
    """
    Read data incrementally from PostgreSQL using a id value.
    """
    try:
        _,_,_,db_user,db_password,jdbc_url \
            = get_postgres_conn_details(source_pg_secret_name,source_secret_region)
        
        logging.info("Configurations extracted and processed successfully.")
        
        jdbc_properties = {
            "user": db_user,
            "password": db_password,
            "driver": "org.postgresql.Driver"
        }
        
        # Construct the SQL query
        query = f"(SELECT * FROM {pg_vehicles_table}) AS temp"
        logging.info(f"Constructed SQL query: {query}")

        # Execute the query and fetch data
        df = spark.read.jdbc(url=jdbc_url, table=query, properties=jdbc_properties)
        new_pg_rows = df.count()
        logging.info(f"Fetched {new_pg_rows} rows from PostgreSQL")

        return df

    except Exception as e:
        logging.error(f"Error fetching PostgreSQL data: {e}")
        traceback.print_exc()
        raise
    
def s3_path_exists(bucket_name, prefix, s3_client):
    
    response = s3_client.list_objects_v2(Bucket=bucket_name, Prefix=prefix, MaxKeys=1)
    return "Contents" in response

   
def update_watermark_with_latesttime(s3,water_mark_max_time,raw_watermark_bucket,raw_watermark_file_key,source_table_name):
    
    try:
        
        update_watermark_file(s3,water_mark_max_time,raw_watermark_bucket,raw_watermark_file_key,source_table_name)
        return True
    except Exception as e:
        logging.error(f"Error while updating the watermark file:{str(e)}")
        raise

def main():
    try:
        
        start_time = datetime.now()
        logging.info(f"Job started at {start_time}")
        
        spark=initialize_spark_session()
        job_name,job_run_id,yaml_s3_bucket,yaml_file_key =  read_job_parameters()
        
        s3_client = boto3.client('s3')
        source_os_index = "vehicle-live-status-opensearch"
        target_table_name = "vehicle-live-status-snowflake"
        
        opensearch_connection_name,audit_table,vehicle_snapshot_index_name,\
            sns_secret_name,audit_path,source_type,target_type,region_name,\
            snowflake_secret_name,stage_table,snowflake_target_table,watermark_bucket,watermark_file_key,watermark_col_landing, \
            pg_secret_name,pg_secret_region,pg_vehicles_table,master_tele_bucket_name,master_tele_hudi_path,trip_stats_bucket_name, \
                trip_stats_hudi_path,pg_vehicle_model_table \
                = read_yaml_file(s3_client,yaml_s3_bucket,yaml_file_key)
        logging.info("job_name=%s", job_name)
        
    except Exception as e:
        logging.error(f"Error in initial steps: {str(e)}")
        traceback.print_exc()
        raise
    
    try:
        
        year_partitioned=start_time.year
        month_partitioned=start_time.month
        is_validate = validate_audit_table_with_s3_partition(spark,sns_secret_name,start_time,audit_path,audit_table,source_os_index,target_table_name,job_name,region_name,year_partitioned,month_partitioned)
        
        if is_validate == False:
            return
        
        log_audit(
                    spark,job_name,source_os_index,source_type,target_table_name,target_type,\
                    "Started",start_time,None,None,audit_path,audit_table)
        
        glueContext = GlueContext(spark.sparkContext)
        
        watermark_timestamp = get_watermark_timestamp(s3_client,watermark_bucket,watermark_file_key)
        vehicle_snapshot_query = get_vehicle_snapshot_query(watermark_timestamp)
        
        
        vehicle_snapshot_df  = read_vehicle_snapshot(glueContext, vehicle_snapshot_index_name, opensearch_connection_name, vehicle_snapshot_query)
        
        logging.info(f"vehicle_snapshot_df : ")
        logging.info(f" {vehicle_snapshot_df.show(truncate = False)}")
        logging.info("vehicle_snapshot_df")
        num_records = vehicle_snapshot_df.count()
        logging.info(vehicle_snapshot_df.count())
        logging.info(vehicle_snapshot_df.show(2))
        logging.info(vehicle_snapshot_df.printSchema())
        if num_records > 0:
            vehicle_snapshot_df = vehicle_snapshot_df.filter(col("updatedTsp").isNotNull())
            
            water_mark_max_time = vehicle_snapshot_df.agg({watermark_col_landing: "max"}).collect()[0][0]
            
            three_minutes_ms = 3 * 60 * 1000
            current_tsp_ms = (unix_timestamp(current_timestamp()) * 1000).cast("bigint")
            # Add new column with Connected/Offline status
            vehicle_snapshot_df = vehicle_snapshot_df.withColumn(
                "vehicle_connection_status",
                when(col("updatedTsp") >= (current_tsp_ms - three_minutes_ms), "Connected")
                .otherwise("Offline")
            )
            
            vehicle_snapshot_df = vehicle_snapshot_df.withColumn("latitude",col("latitude.value"))
            vehicle_snapshot_df = vehicle_snapshot_df.withColumn("longitude",col("longitude.value"))
            vehicle_snapshot_df = vehicle_snapshot_df.withColumn("current_speed",col("vehicleSpeedDisplay.value"))
            
            vehicle_snapshot_df = vehicle_snapshot_df.withColumn(
                "location", F.concat_ws(",", col("latitude"), col("longitude")))
            
            vehicle_snapshot_df = vehicle_snapshot_df.select(col("vid"),col("tenantId").alias("tenant"),col("location"),col("vehicle_connection_status"),\
                col("current_speed"), col("updatedTsp"))
            
            logging.info("vehicle_snapshot_df2......")
            logging.info(vehicle_snapshot_df.count())
            logging.info(vehicle_snapshot_df.show(2))
            logging.info(vehicle_snapshot_df.printSchema())
            
            vid_list_df = vehicle_snapshot_df.select(F.collect_list("vid"))
            vid_list = vid_list_df.collect()[0][0]
            
            logging.info("Vehicle_list")
            logging.info(vid_list)
        
            now_utc = datetime.now(timezone.utc)
            # Get the current hour in UTC
            current_hour = now_utc.hour
            current_year = now_utc.year
            current_month = now_utc.month
            current_day = now_utc.day
            last_4_hours = [current_hour - i for i in range(3, -1, -1)]
            
            window_spec = Window.partitionBy("vid").orderBy(col("collectioneventtime").desc())
            
            if s3_path_exists(master_tele_bucket_name, master_tele_hudi_path, s3_client):
                            
                master_tele_hudi_full_path = f"s3://{master_tele_bucket_name}/{master_tele_hudi_path}"
            
                master_tele_df = spark.read.format("hudi").load(master_tele_hudi_full_path) \
                .filter((col("year")== current_year) &
                        (col("month")== current_month) &
                        (col("day")== current_day) & 
                        (col("hour").isin(last_4_hours)))
                            
                master_tele_df = master_tele_df.filter(col("vid").isin(vid_list))
                
                master_tele_df = master_tele_df.withColumn("rownumber",F.row_number().over(window_spec))
                master_tele_df = master_tele_df.filter(col("rownumber")==1)
                
                exclude_columns = [
                    "_hoodie_commit_time", "_hoodie_commit_seqno", "_hoodie_record_key","kafka_topic",
                    "_hoodie_partition_path", "_hoodie_file_name", "key", "topic", "partition", "offset"
                    "year", "month", "day", "hour", "rownumber"
                ]

                # Select only the columns that should be included in JSON
                columns_to_include = [c for c in master_tele_df.columns if c not in exclude_columns]
                
                master_tele_df = master_tele_df.withColumn("source_", F.struct([col(x) for x in columns_to_include]))
                master_tele_df = master_tele_df.select(col("vid"),col("source_"))
                tele_result_df = master_tele_df.withColumnRenamed("source_", "can_data")
                
            else:
                schema = StructType([
                    StructField("vid", StringType(), True),
                    StructField("can_data", StringType(), True)
                    ])
                tele_result_df = spark.createDataFrame([], schema)
            
                
            logging.info(f"tele_result_df")
            logging.info(tele_result_df.count())
            logging.info(tele_result_df.show(2))
            # logging.info(tele_result_df.printSchema())
            
            
            if s3_path_exists(trip_stats_bucket_name, trip_stats_hudi_path, s3_client):
                            
                trip_stats_hudi_full_path = f"s3://{trip_stats_bucket_name}/{trip_stats_hudi_path}"
            
                trip_stats_df = spark.read.format("hudi").load(trip_stats_hudi_full_path) \
                .filter((col("year")== current_year) &
                        (col("month")== current_month) &
                        (col("day")== current_day) &
                        (col("hour").isin(last_4_hours)))
                            
                trip_stats_df = trip_stats_df.filter(col("vid").isin(vid_list))
                
                trip_stats_df = trip_stats_df.withColumn("rownumber",F.row_number().over(window_spec))
                trip_stats_df = trip_stats_df.filter(col("rownumber")==1)
                
                exclude_columns = [
                    "_hoodie_commit_time", "_hoodie_commit_seqno", "_hoodie_record_key",
                    "_hoodie_partition_path", "_hoodie_file_name", "use_case_name",
                    "year", "month", "day", "hour", "rownumber"
                ]

                # Select only the columns that should be included in JSON
                columns_to_include = [c for c in trip_stats_df.columns if c not in exclude_columns]
                
                trip_with_source = trip_stats_df.withColumn("source_", F.struct([col(x) for x in columns_to_include]))
                trip_with_source = trip_with_source.select(col("vid"),col("source_"))
                trip_result_df = trip_with_source.withColumnRenamed("source_", "latest_trip_details")
                
            else:
                schema = StructType([
                    StructField("vid", StringType(), True),
                    StructField("latest_trip_details", StringType(), True)
                    ])
                trip_result_df = spark.createDataFrame([], schema)
                
            logging.info(f"trip_result_df")
            logging.info(trip_result_df.count())
            logging.info(trip_result_df.show(2))
            # logging.info(trip_result_df.printSchema())
            
            final_df = vehicle_snapshot_df.join(tele_result_df,on="vid",how="left") \
                        .join(trip_result_df,on="vid",how="left")
                        
            logging.info(f"final_df1")
            logging.info(final_df.count())
            logging.info(final_df.show(2))
            # logging.info(trip_result_df.printSchema())

            pg_vehicle_df = read_postgres_table(spark,pg_secret_name,pg_secret_region,pg_vehicles_table)
            pg_vehicle_model_df = read_postgres_table(spark,pg_secret_name,pg_secret_region,pg_vehicle_model_table)
            
            
            pg_vehicle = pg_vehicle_df.alias("v").join(pg_vehicle_model_df.alias("vm"),
                col("v.model") == col("vm.vds_code"), how="left").select(
                col("v.vid"), col("v.make"), col("vm.vehicle_model_name"))

            pg_vehicle = pg_vehicle.dropDuplicates().dropna(subset=["vid"])
            pg_vehicle= pg_vehicle.select(col("vid"),col("make"),col("vehicle_model_name").alias("model"))
            
            
            final_df = final_df.join(pg_vehicle, on="vid", how="left")

            logging.info(f"final_df2")
            logging.info(final_df.count())
            logging.info(final_df.show(2))
            load_df_into_snowflake_table(final_df,snowflake_secret_name,stage_table,snowflake_target_table,final_df.columns)
            
            update_watermark_with_latesttime(s3_client,water_mark_max_time,watermark_bucket,watermark_file_key,"vehicle_live_status")
        #get cloudwatch details
        cloudwatch_url = get_cloudwatch_url(region_name, job_name, job_run_id)
        end_time = datetime.now()
        duration = (end_time - start_time).seconds
        
        # Log audit
        log_audit(
                spark,job_name,source_os_index,source_type,target_table_name,target_type,"Completed",start_time,end_time,\
                    num_records,audit_path,audit_table,
                )
        logging.info(f"Job completed successfully in {duration} seconds")
        
                    
    except Exception as e:
        logging.error("Job failed with error: %s", str(e))
        traceback.print_exc()
        end_time = datetime.now()
        duration = end_time - start_time
        logging.error(f"Job failed in {duration} seconds")
        #get cloudwatch details 
        cloudwatch_url = get_cloudwatch_url(region_name, job_name, job_run_id)
        log = {
                "status": "failure",
                "job_name": job_name,
                "source_table": source_os_index,
                "target_table": target_table_name,
                "start_time": start_time.isoformat(),
                "end_time": end_time.isoformat(),
                "duration": duration,
                "error": f"Error: {str(e)}\nTraceback: {traceback.format_exc()}"
            }
        
        # Log audit
        log_audit(
                spark,job_name,source_os_index,source_type,target_table_name,target_type,\
                "Failed",start_time,end_time,None,audit_path,audit_table,
                )
            
        log_message = "\n".join([f"{key}: {value}" for key, value in log.items()])
        message = f"Job -{job_name} failed. Transformation returned None.\n\n{log_message}.\n\nView the logs in CloudWatch:{cloudwatch_url}"
        subject= f"Job Failed : Job - {job_name}"
        send_sns_notification(subject, message, sns_secret_name,region_name)
        raise
    
if __name__ == "__main__":
    main()
