"""
This code loads the data from opensearch to S3layer 
and opensearch for 30min interval
"""

# pylint: disable=import-error
import sys
import logging
import re
import json
from datetime import datetime, timedelta, timezone
import traceback
import pytz
import boto3
from botocore.exceptions import ClientError
from urllib.parse import urlparse
from awsglue.context import GlueContext
from awsglue.dynamicframe import DynamicFrame
from awsglue.utils import getResolvedOptions
from pyspark.sql.functions import row_number
from pyspark.sql import functions as F
from pyspark.sql.window import Window
from pyspark.sql import SparkSession
from pyspark.sql.types import (
    DoubleType,
    FloatType,
    DecimalType,
    TimestampType,
    StringType,
    IntegerType,
    LongType,
    ArrayType,
    MapType,
    StructType,
    StructField,
    BooleanType,
    DateType,
)
from hmcl_cv_common_utilities import (
    log_audit,
    get_cloudwatch_url,
    send_sns_notification,
    validate_audit_table,
)

# Create a Spark session and Glue context

logging.basicConfig(
    level=logging.INFO, format="%(asctime)s - %(name)s - %(levelname)s - %(message)s"
)


spark = (
    SparkSession.builder.config(
        "spark.serializer", "org.apache.spark.serializer.KryoSerializer"
    )
    .config("spark.kryoserializer.buffer.max", "256m")
    .config("spark.hudi.query.metadata.enable", "true")
    .config("spark.sql.jsonGenerator.ignoreNullFields", "false")
    .config("spark.sql.adaptive.enabled", "true")
    .config("spark.sql.adaptive.skewJoin.enabled", "true")
    # .config("spark.sql.adaptive.forceOptimizeSkewedJoin", "false")
    .config("spark.sql.adaptive.coalescePartitions.enabled", "true")
    # .config("spark.sql.shuffle.partitions", 300)
    .config("spark.sql.join.preferSortMergeJoin", "true")
    # .config("spark.yarn.executor.memoryOverhead", "7g")
    # .config("spark.driver.memory", "10g")
    .getOrCreate()
)

sc = spark

# .conf.set("spark.sql.shuffle.partitions", spark.sparkContext.defaultParallelism)

glueContext = GlueContext(sc)

# Define an accumulator

count_accum = spark.sparkContext.accumulator(0)


arguments = [
    "JOB_NAME",
    "table_name",
    "landing_bucket",
    "database",
    "tele_table_name",
    "raw_bucket",
    "os_trip_start_index",
    "os_trip_end_index",
    "os_trip_break_index",
    "os_trip_stat_index",
    "os_connector_name",
    "source_type",
    "target_type",
    "audit_path",
    "audit_table",
    "os_telemetry_index",
    "read_partitions",
    "array_include_attrs",
    "tele_fields",
    "region_name",
    "sns_secret_name",
    "campaignname",
    "tenants_list",
    "batch_type",
    "source_partition",
    "kafka_broker",
    "topic",
    "partition_extract_col",
    "default_param_store_val",
]

optional_arguments = [
    "read_partitions",
    "array_include_attrs",
    "region_name",
    "sns_secret_name",
    "os_telemetry_index",
    "campaignname",
    "tele_fields",
    "tenants_list",
    "batch_type",
    "source_partition",
    "partition_extract_col",
    "default_param_store_val",
]

for argument in optional_arguments:
    if not f"--{argument}" in sys.argv:
        arguments.remove(argument)

args = getResolvedOptions(
    sys.argv,
    arguments,
)


job_name = args.get("JOB_NAME")
job_run_id = args.get("JOB_RUN_ID")
sns_secret_name = args.get("sns_secret_name", "sns_topic_arn")
table_name = args.get("table_name")
landing_bucket = args.get("landing_bucket")
table_name = args.get("table_name")
database = args.get("database")
tele_table_name = args.get("tele_table_name")
s3_tele_output_path = args.get("s3_tele_output_path")
os_trip_start_index = args.get("os_trip_start_index")
os_trip_end_index = args.get("os_trip_end_index")
os_trip_break_index = args.get("os_trip_break_index")
os_trip_stat_index = args.get("os_trip_stat_index")
os_connector_name = args.get("os_connector_name")
raw_bucket = args.get("raw_bucket")
source_type = args.get("source_type")
target_type = args.get("target_type")
audit_path = args.get("audit_path")
audit_table = args.get("audit_table")
os_telemetry_index = args.get("os_telemetry_index", "os_telemetry_index")
read_partitions = int(args.get("read_partitions", 8))
region_name = args.get("region_name", "ap-south-1")
kafka_broker = args.get("kafka_broker")
topic = args.get("topic")
tenants_list = args.get(
    "tenants_list", json.dumps(["ev-vida", "ice-hero", "ice-harley"])
)
campaignname = args.get(
    "campaignname", "hmcl-cv-fw-periodic-app-screen-telemetry-ign-rise"
)
tele_fields = args.get(
    "tele_fields",
    "vehicle_speed,odo_signal_hr, vid,campaign_name,collectioneventtime,collectioneventtimets,\
    vehicle_speed_display,  total_usable_energy,  drive_mode_signal,  soc_user,  fuel_level,\
    battery_pack_temperature,  ambient_temperature,  engine_temperature,  latitude,  longitude,\
    bms1_battery_pack_temperature,bms2_battery_pack_temperature,harsh_driving_alert,\
    remaining_range_in_km,gps_valid,gps_fix,tenant_id,hdop,vdop,pdop",
)
array_include_attrs = args.get(
    "array_include_attrs",
    "battery_slot_identity_rear ,gear_position_sensor,charger_power_line_state,fuel_level,\
    total_usable_capacity,vehicle_speed,soe,bms_bdu_status,userid,soh,sats_in_use,\
    throttle_position_sensor,ambient_temperature,sats_in_view,battery_detection,\
    fuel_level_indication, abs_front_wheel_pressure_plus,abs_telltale_status,altitude,\
    avg_energy_consumption, battery_operation_mode,battery_operation_mode_bms2,\
    battery_pack_temperature, battery_slot_identity_front,ble_connectivity,\
    bms_status,boost_mode_status, brake_input_signal,cog,distance_accumulation,\
    distance_travelled_with_mil, engine_speed,engine_temperature,fr_wss,fr_wss_plus,\
    gps_fix,gps_speed, gps_valid,hdop,int_bat_charge_percent,int_bat_charge_voltage,\
    latitude, longitude,mileage_trip,odo_signal_hr,pack_current,pack_voltage,pdop,\
    ready_status,remaining_capacity,remaining_range_in_km,rider_info_userid, rider_info_usertype,\
    rr_wss,rr_wss_plus,soc_user,soc_user_bms1,soc_user_bms2, speed_limit_signal,status_abs,\
    tcu_ignition,temp_status,thermal_run_command, thermal_run_status_aggr,throttle,\
    throttle_grip_sensor,total_usable_energy, usertype,vdop,vehicle_speed_display,\
    vehicle_speed_high_res,vehicle_speed_high_res_1,drive_mode_signal,bms1_battery_pack_temperature\
    ,bms2_battery_pack_temperature,harsh_driving_alert,bms_bdu_connection_request,\
    total_usable_energy_bms1,total_usable_energy_bms2,dtc_info,bms_bdu,user_type,user_id",
)
batch_type = args.get("batch_type", "4hour")
source_partition = args.get("source_partition", "day")
partition_extract_col = args.get("partition_extract_col", "trip_start_timestamp")
default_param_store_val = args.get("default_param_store_val", "2025-02-01T00:00:00Z")


s3_output_path = "s3://" + raw_bucket + "/" + table_name
s3_tele_output_path = "s3://" + raw_bucket + "/cvp-telemetry-hudi"
source_name = os_trip_start_index + "-" + os_trip_end_index + "-" + os_trip_end_index
target = table_name + "-" + os_trip_stat_index

logging.info("tenants list param value:%s", tenants_list)
tenants_list = json.loads(tenants_list)
logging.info("tenants list param value after converted to list:%s", tenants_list)

default_hahb = F.array(
    F.struct(
        F.lit(None).cast("double").alias("fuel_percentage"),
        F.lit(None).cast("double").alias("fuel_value"),
        F.lit(None).cast("integer").alias("gps_fix"),
        F.lit(None).cast("boolean").alias("gps_valid"),
        F.lit(None).cast("float").alias("hdop"),
        F.struct(
            F.lit(0.0).cast("double").alias("lat"),
            F.lit(0.0).cast("double").alias("lon"),
        ).alias("location"),
        F.lit(None).cast("double").alias("odometer"),
        F.lit(None).cast("float").alias("pdop"),
        F.lit(None).cast("double").alias("soc"),
        F.lit(None).cast("long").alias("timestamp"),
        F.lit(None).cast("float").alias("vdop"),
    )
)


location_default = F.struct(
    F.lit(0.0).cast("double").alias("lat"), F.lit(0.0).cast("double").alias("lon")
)


def store_parameter(name, value, param_type="String", overwrite=True):
    """
    Store a parameter in AWS Systems Manager Parameter Store.

    :param name: The name of the parameter (e.g., '/myapp/prod/db_password').
    :param value: The value to store (string).
    :param param_type: Type of the parameter ('String', 'StringList', or 'SecureString').
    :param overwrite: Whether to overwrite an existing parameter.
    :return: The response from the SSM API.
    """
    ssm = boto3.client("ssm")

    try:
        response = ssm.put_parameter(
            Name=name, Value=value, Type=param_type, Overwrite=overwrite
        )
        return response
    except Exception as exp:
        logging.error("Error in storing parameter : %s", exp)
        traceback.print_exc()
        raise


def retrieve_parameter(name, with_decryption=True):
    """
    Retrieve a parameter from AWS Systems Manager Parameter Store.

    :param name: The name of the parameter (e.g., '/myapp/prod/db_password').
    :param with_decryption: Whether to decrypt the parameter if it is of type 'SecureString'.
    :return: The parameter value, or None if not found.
    """
    ssm = boto3.client("ssm")

    try:
        response = ssm.get_parameter(Name=name, WithDecryption=with_decryption)
        return response["Parameter"]["Value"]
    except Exception as exp:
        logging.error("Error in getting parameter from paramter store  : %s", exp)
        traceback.print_exc()
        return default_param_store_val


def fill_na_with_default(df, exclude_columns=[]):
    """
    Fills missing (NaN, None) values in a DataFrame with default values based on column types.

    Args:
        df (DataFrame): The input PySpark DataFrame with missing values.

    Returns:
        DataFrame: A new DataFrame with missing values filled with default values based on column data types.

    Raises:
        ValueError: If an unsupported data type is found in the DataFrame.
    """

    fill_values = {}

    # Iterate through DataFrame columns and their data types
    for column, dtype in df.dtypes:
        try:
            if column not in exclude_columns:
                # Handle specific data types and fill with the appropriate default value
                if dtype in ["bigint", "int", "long"]:
                    fill_values[column] = 0
                elif dtype in ["float", "double"]:
                    fill_values[column] = 0.0
                elif dtype == "string":
                    fill_values[column] = ""
                elif dtype == "boolean":
                    fill_values[column] = False
                elif dtype in ["timestamp", "date"]:
                    fill_values[column] = "1970-01-01 00:00:00"  # Default timestamp
                else:
                    # If data type is unsupported, log and set to None
                    logging.warning(
                        "Unsupported data type for column '%s': %s", column, dtype
                    )
                    # fill_values[column] = None

        except Exception as exp:
            # If any error occurs during type checking or fill value assignment, log it
            logging.error("Error processing column '%s': %s", column, str(exp))
            traceback.print_exc()
            raise
    # Apply fillna to the DataFrame with the generated fill values dictionary
    try:
        filled_df = df.fillna(fill_values)
        logging.info(
            "Successfully filled missing values in the DataFrame. Columns filled: %s",
            list(fill_values.keys()),
        )
        return filled_df
    except Exception as exp:
        # Log and raise an error if fillna operation fails
        logging.error("Failed to fill missing values in the DataFrame: %s", str(exp))
        traceback.print_exc()
        raise


def cast_selected_columns(df, columns_to_cast):
    """
    Casts the specified columns in the DataFrame to the provided target data types.

    Args:
        df (DataFrame): The input PySpark DataFrame.
        columns_to_cast (dict): A dictionary where keys are column names,
        and values are target data types (as strings).

    Returns:
        DataFrame: A new DataFrame with only the specified columns cast to the given types.
    """
    try:
        # List of column expressions to select
        casted_columns = [
            (
                F.col(col).cast(columns_to_cast[col]).alias(col)
                if col in columns_to_cast
                else F.col(col)
            )
            for col in df.columns
        ]

        # Select the columns with appropriate casting
        casted_df = df.select(*casted_columns)

        return casted_df
    except Exception as exp:
        logging.error("Error casting datatypes : %s", exp)
        traceback.print_exc()
        raise


def rename_columns_efficient(df, columns_to_rename):
    """
    Renames the specified columns in the DataFrame efficiently using `selectExpr`.

    Args:
        df (DataFrame): The input PySpark DataFrame.
        columns_to_rename (dict): A dictionary where keys are old column names and values are new column names.

    Returns:
        DataFrame: A new DataFrame with the renamed columns.
    """
    try:
        # Build the select expression for renaming columns
        select_expr = [
            (
                f"`{old_name}` AS `{columns_to_rename[old_name]}`"
                if old_name in columns_to_rename
                else old_name
            )
            for old_name in df.columns
        ]

        # Apply the select expression to the DataFrame
        return df.selectExpr(select_expr)

    except Exception as exp:
        logging.error("Error renaming columns: %s", {str(exp)})
        traceback.print_exc()
        raise


def get_filter_query(ts_start, ts_end, column_name, source_type="trip"):

    try:
        if source_type == "trip":
            trip_filter_query = {
                "query": {
                    "bool": {
                        "must": [
                            {"range": {column_name: {"gte": ts_start, "lte": ts_end}}}
                        ]
                    }
                }
            }
        elif source_type == "tele":
            trip_filter_query = {
                "query": {
                    "bool": {
                        "must": [
                            {"range": {column_name: {"gte": ts_start, "lte": ts_end}}},
                            {
                                "terms": {
                                    "campaign_name.keyword": [
                                        "hmcl-cv-fw-periodic-app-screen-telemetry-ign-rise",
                                    ]
                                }
                            },
                        ]
                    }
                }
            }
        elif source_type == "target":
            trip_filter_query = {
                "query": {"bool": {"must": [{"match": {column_name: "on going"}}]}}
            }
        elif source_type == "target_lastnhour":
            trip_filter_query = {
                "query": {
                    "bool": {
                        "must": [
                            {
                                "range": {
                                    column_name: {
                                        "gte": ts_start,
                                        "lte": ts_end,
                                    }
                                }
                            },
                        ]
                    }
                }
            }

        return json.dumps(trip_filter_query)
    except Exception as exp:
        logging.error("Error in getting filter query: %s", {str(exp)})
        traceback.print_exc()
        raise


def flatten_df(df, array_attr_to_flatten):
    """
    Flattening data frame
    """

    try:

        default_value = F.array(
            F.struct(
                F.lit(None).cast("string").alias("dataType"),
                F.lit(None).cast("bigint").alias("time"),
                F.lit(None).cast("string").alias("value"),
            )
        )

        # Getting list of columns which are not exploding
        not_flattened_columns = [
            col for col in df.columns if col not in array_attr_to_flatten
        ]

        # Zipping the columns whihc are need to exploded
        zipped_df = df.select(
            *not_flattened_columns,
            F.arrays_zip(
                *[F.col(col).alias(col) for col in array_attr_to_flatten]
            ).alias("zipped_arrays"),
        )

        exploded_df = zipped_df.select(
            *not_flattened_columns,
            F.posexplode(F.col("zipped_arrays")).alias("pos", "zipped_values"),
        )

        # Dynamically extract the "value" field from each struct in the exploded array
        flattened_columns = []
        for col_name in array_attr_to_flatten:
            flattened_columns.append(
                F.when(
                    F.col("zipped_values").getItem(col_name).isNotNull(),
                    F.col("zipped_values").getItem(col_name).getItem("value"),
                )
                .otherwise(F.lit(None))
                .alias(f"{col_name}")
            )

        flattened_df = exploded_df.select(
            *not_flattened_columns,
            *flattened_columns,
            F.col("zipped_values")
            .getItem("tele_total_usable_energy")
            .getItem("time")
            .alias("polling_time"),
            F.col("pos"),
        )

        # window_spec = (
        #     Window.partitionBy(F.col("vid"), F.col("collectioneventtime_ts")).orderBy(
        #         F.col("polling_time").desc()
        #     )
        #     # .rowsBetween(Window.unboundedPreceding, Window.currentRow)
        # )

        # flattened_df_fill_na = flattened_df.select(
        #     *not_flattened_columns,
        #     *[
        #         F.coalesce(
        #             F.col(col_name),
        #             F.last(F.col(col_name), ignorenulls=True).over(window_spec),
        #         ).alias(col_name)
        #         for col_name in array_attr_to_flatten
        #     ],
        #     "polling_time",
        #     "pos",
        # )

        # flattened_df_fill_na.filter(
        #     (F.col("vid") == "7c35616b-616b-45616ba6ca-85616ba6ca0b8-0b8b87")
        #     & (F.col("collectioneventtime") >= 1734604354147)
        #     & (F.col("collectioneventtime") <= 1734604634180)
        # ).select(
        #     "vid",
        #     "collectioneventtime",
        #     "polling_time",
        #     "pos",
        #     "tele_total_usable_energy",
        #     "tele_odo_vcu",
        # ).show(
        #     truncate=False
        # )

        return flattened_df
    except Exception as exp:
        logging.error("An error occurred in flattening array attributes : %s", str(exp))
        traceback.print_exc()
        raise


def mode_wise_calculation(df):
    """
    vehicle mode based Trip metrics calculation
    """

    try:

        w_mode_calc = Window.partitionBy(
            F.col("trip_id_trip_start"), F.col("vehicle_id_trip_start")
        ).orderBy(F.col("collectioneventtime_ts"), F.col("pos").desc())

        df = df.withColumn(
            "usable_energy_diff",
            F.col("tele_total_usable_energy")
            - F.lead(F.col("tele_total_usable_energy")).over(w_mode_calc),
        ).withColumn(
            "tele_odo_vcu_diff",
            F.lead(F.col("tele_odo_vcu")).over(w_mode_calc) - F.col("tele_odo_vcu"),
        )

        df_trip_mode_agg = df.groupby(
            F.col("vehicle_id_trip_start"),
            F.col("trip_id_trip_start"),
            F.col("tele_vehicle_mode_signal"),
        ).agg(
            F.sum(F.col("usable_energy_diff")).alias("mode_wise_wh_consumed"),
            F.sum(F.col("tele_odo_vcu_diff")).alias("mode_wise_distance_covered"),
            (
                F.sum(F.col("usable_energy_diff")) / F.sum(F.col("tele_odo_vcu_diff"))
            ).alias("mode_wise_wh_consumed_vs_dist"),
        )

        expected_modes = ["eco", "ride", "sport", "custom"]

        default_modes_map = F.create_map(
            [
                kv
                for mode in expected_modes
                for kv in [F.lit(mode), F.lit(None).cast(DoubleType())]
            ]
        )

        df_trip_mode_merge = (
            df_trip_mode_agg.groupby(
                F.col("vehicle_id_trip_start"), F.col("trip_id_trip_start")
            )
            .agg(
                F.collect_list(
                    F.struct(
                        F.col("tele_vehicle_mode_signal"),
                        F.col("mode_wise_wh_consumed_vs_dist"),
                    )
                ).alias("mode_wise_wh_consumed_vs_dist"),
                F.collect_list(
                    F.struct(
                        F.col("tele_vehicle_mode_signal"),
                        F.col("mode_wise_wh_consumed"),
                    )
                ).alias("mode_wise_wh_consumed"),
                F.collect_list(
                    F.struct(
                        F.col("tele_vehicle_mode_signal"),
                        F.col("mode_wise_distance_covered"),
                    )
                ).alias("mode_wise_distance_covered"),
            )
            .withColumn(
                "mode_wise_wh_consumed",
                F.coalesce(
                    F.map_from_entries(F.col("mode_wise_wh_consumed")),
                    default_modes_map,
                ),
            )
            .withColumn(
                "mode_wise_distance_covered",
                F.coalesce(
                    F.map_from_entries(F.col("mode_wise_distance_covered")),
                    default_modes_map,
                ),
            )
            .withColumn(
                "mode_wise_wh_consumed_vs_dist",
                F.coalesce(
                    F.map_from_entries(F.col("mode_wise_wh_consumed_vs_dist")),
                    default_modes_map,
                ),
            )
        )

        return df_trip_mode_merge
    except Exception as exp:
        logging.error("An error occurred in modewise calculations : %s", str(exp))
        traceback.print_exc()
        raise


##UDF to extract specific data based on latest time.
def get_latest_value(col):
    """
    This is user defined method to get the latets value from array of signal samples
    """

    try:

        if not col:
            return None  # Handle empty case
        latest_entry = max(col, key=lambda x: x["time"])
        return latest_entry["value"]
    except Exception as exp:
        logging.error("An error occurred in getting latest value : %s", str(exp))
        traceback.print_exc()
        raise


# Function to generate a list of day or hour-based partition paths between start and end timestamps
def generate_partitions(
    start_timestamp: str,
    end_timestamp: str,
    partition_type: str = "day",
    time_format: str = "%Y/%m/%d",
    zone="IST",
):
    # Convert input timestamps to datetime objects
    if zone == "UTC":
        start_dt = datetime.strptime(start_timestamp, "%Y-%m-%d %H:%M:%S") - timedelta(
            hours=5, minutes=30
        )
        end_dt = datetime.strptime(end_timestamp, "%Y-%m-%d %H:%M:%S") - timedelta(
            hours=5, minutes=30
        )
    else:
        start_dt = datetime.strptime(start_timestamp, "%Y-%m-%d %H:%M:%S")
        end_dt = datetime.strptime(end_timestamp, "%Y-%m-%d %H:%M:%S")

    # List to hold the partition paths
    partitions = []

    current_dt = start_dt
    while current_dt <= end_dt:
        if partition_type == "day":
            # Format the day partition path (e.g., "2023/12/26")
            partition_path = current_dt.strftime(
                "%Y/%-m/%-d"
            )  # Format the date as "YYYY/MM/DD"
        elif partition_type == "hour":
            # Format the hour partition path (e.g., "2023/12/26/18")
            partition_path = current_dt.strftime(
                "%Y/%-m/%-d/%-H"
            )  # Format the date as "YYYY/MM/DD/HH"
        else:
            partition_path = current_dt.strftime("%Y/%-m/%-d")

        partitions.append(partition_path)

        # Move to the next day or hour depending on partition_type
        if partition_type == "day":
            current_dt += timedelta(days=1)
        elif partition_type == "hour":
            current_dt += timedelta(hours=1)

        # Ensure the last partition is included if the loop finishes with an unprocessed partition
        if current_dt.date() > end_dt.date() or (
            current_dt.date() == end_dt.date() and current_dt.hour > end_dt.hour
        ):
            break

    # Add the last partition (end_dt) if not already added
    if current_dt.date() == end_dt.date() and (
        current_dt.hour == end_dt.hour or partition_type == "day"
    ):

        partitions.append(
            end_dt.strftime("%Y/%-m/%-d")
            if partition_type == "day"
            else end_dt.strftime("%Y/%-m/%-d/%-H")
        )

    return partitions


def get_s3_latest_partition(
    part_timestamp: str,
    partition_type: str = "day",
    time_format: str = "%Y/%m/%d",
    zone="IST",
):
    # Convert input timestamps to datetime objects
    if zone == "UTC":
        latest_dt = datetime.strptime(part_timestamp, "%Y-%m-%d %H:%M:%S") - timedelta(
            hours=5, minutes=30
        )

    else:
        latest_dt = datetime.strptime(part_timestamp, "%Y-%m-%d %H:%M:%S")

    if partition_type == "day":
        # Format the day partition path (e.g., "2023/12/26")
        partition_path = latest_dt.strftime(
            "%Y/%-m/%-d"
        )  # Format the date as "YYYY/MM/DD"
    elif partition_type == "hour":
        # Format the hour partition path (e.g., "2023/12/26/18")
        partition_path = latest_dt.strftime(
            "%Y/%-m/%-d/%-H"
        )  # Format the date as "YYYY/MM/DD/HH"
    else:
        partition_path = latest_dt.strftime("%Y/%-m/%-d")

    return partition_path


def s3_path_exists(s3_path: str) -> bool:
    """
    Check if a file or directory exists in S3.

    :param bucket_name: The S3 bucket name.
    :param s3_key: The S3 key (file path) to check.
    :return: True if the path exists, False otherwise.
    """
    s3_client = boto3.client("s3")
    parsed_url = urlparse(s3_path)
    bucket_name = parsed_url.netloc
    s3_key = parsed_url.path.lstrip("/")

    try:
        # Attempt to retrieve metadata for the object (file)
        response = s3_client.list_objects_v2(
            Bucket=bucket_name, Prefix=s3_key, MaxKeys=1
        )
        if "Contents" in response:
            return True  # Prefix exists and has objects under it
        else:
            logging.info("path does not exist %s", s3_path)
            return False  # Prefix exists but is empty (no objects under it)

    except ClientError as e:
        # If a ClientError is thrown, it means the object doesn't exist or another error occurred
        if e.response["Error"]["Code"] == "404":
            logging.info("path does not exist %s", s3_path)
            return False
        else:
            raise  # Re-raise the exception if it's not a 404 (File not found)


def read_telemetry(ts_start, ts_end, tenantid, s3_output_partition_path, trip_vids):
    """
    Reading telemetry data
    """

    try:

        ts_start = datetime.strptime(ts_start, "%Y-%m-%dT%H:%M:%SZ").strftime(
            "%Y-%m-%d %H:%M:%S"
        )

        ts_end = datetime.strptime(ts_end, "%Y-%m-%dT%H:%M:%SZ").strftime(
            "%Y-%m-%d %H:%M:%S"
        )

        try:

            if ts_start == "1970-01-01T00:00:00Z":
                opensearch_read_telemetry = spark.read.format("hudi").load(
                    s3_output_partition_path
                )
            else:

                source_partitions = generate_partitions(
                    ts_start, ts_end, partition_type=source_partition, zone="UTC"
                )

                partition_paths = [
                    f"{s3_output_partition_path}/{partition}"
                    for partition in source_partitions
                ]
                valid_partition_paths = [
                    path for path in partition_paths if s3_path_exists(path)
                ]

                valid_partition_paths = [f"{path}/*" for path in valid_partition_paths]
                paths_string = ",".join(valid_partition_paths)

                logging.info("telemetry partions to read %s", valid_partition_paths)

                hudi_opts = {
                    "hoodie.datasource.query.type": "snapshot",
                    "hoodie.file.index.enable": False,
                    "hoodie.datasource.read.paths": paths_string,
                }

                opensearch_read_telemetry = (
                    spark.read.format("hudi").options(**hudi_opts).load()
                )

        except Exception as exp:
            logging.error(
                "There is no telemetry data for given partion path : %s",
                paths_string,
            )
            traceback.print_exc()
            return

        opensearch_read_telemetry.repartition(
            read_partitions, opensearch_read_telemetry["vid"]
        )

        opensearch_read_telemetry = opensearch_read_telemetry.join(
            trip_vids,
            (opensearch_read_telemetry["vid"] == trip_vids["vehicle_id_trip_start"]),
            "inner",
        )

        logging.info(
            "Reading telemetry data between ts_start %s and ts_end %s from path %s ended",
            ts_start,
            ts_end,
            partition_paths,
        )
        opensearch_read_telemetry_df = opensearch_read_telemetry.withColumn(
            "collectioneventtime_ts",
            F.from_utc_timestamp(F.col("collectioneventtime_ts"), "Asia/Calcutta").cast(
                TimestampType()
            ),
        ).filter(
            (F.col("collectioneventtime_ts") >= ts_start)
            & (F.col("collectioneventtime_ts") < ts_end)
            & (F.col("campaignname") == campaignname)
        )

        # #testing

        opensearch_read_telemetry_df = opensearch_read_telemetry_df.withColumn(
            "vid", F.trim(F.col("vid"))
        )

        columns_to_select = {
            "hmcl_ev_can0_vehicle_speed_vcu": ArrayType(
                StructType(
                    [  # Complex type example
                        StructField("value", DoubleType(), True),
                        StructField("time", LongType(), True),
                        StructField("dataType", StringType(), True),
                    ]
                )
            ),
            "hmcl_ev_can0_odo_reading": ArrayType(
                StructType(
                    [  # Complex type example
                        StructField("value", DoubleType(), True),
                        StructField("time", LongType(), True),
                        StructField("dataType", StringType(), True),
                    ]
                )
            ),
            "hmcl_ev_can0_cluster_speed": ArrayType(
                StructType(
                    [  # Complex type example
                        StructField("value", DoubleType(), True),
                        StructField("time", LongType(), True),
                        StructField("dataType", StringType(), True),
                    ]
                )
            ),
            "hmcl_ev_can0_total_usable_energy": ArrayType(
                StructType(
                    [  # Complex type example
                        StructField("value", DoubleType(), True),
                        StructField("time", LongType(), True),
                        StructField("dataType", StringType(), True),
                    ]
                )
            ),
            "hmcl_ev_can0_vehicle_mode_signal": ArrayType(
                StructType(
                    [  # Complex type example
                        StructField("value", IntegerType(), True),
                        StructField("time", LongType(), True),
                        StructField("dataType", StringType(), True),
                    ]
                )
            ),
            "hmcl_ev_can0_soc_user_percentage": ArrayType(
                StructType(
                    [  # Complex type example
                        StructField("value", DoubleType(), True),
                        StructField("time", LongType(), True),
                        StructField("dataType", StringType(), True),
                    ]
                )
            ),
            "hmcl_common_vcan0_fuel_level_volts": ArrayType(
                StructType(
                    [  # Complex type example
                        StructField("value", DoubleType(), True),
                        StructField("time", LongType(), True),
                        StructField("dataType", StringType(), True),
                    ]
                )
            ),
            "hmcl_ice_can0_fuel_percentage": ArrayType(
                StructType(
                    [  # Complex type example
                        StructField("value", DoubleType(), True),
                        StructField("time", LongType(), True),
                        StructField("dataType", StringType(), True),
                    ]
                )
            ),
            "hmcl_ev_can0_battery_pack_temperature": ArrayType(
                StructType(
                    [  # Complex type example
                        StructField("value", DoubleType(), True),
                        StructField("time", LongType(), True),
                        StructField("dataType", StringType(), True),
                    ]
                )
            ),
            "hmcl_ev_can0_ambient_temperature": ArrayType(
                StructType(
                    [  # Complex type example
                        StructField("value", DoubleType(), True),
                        StructField("time", LongType(), True),
                        StructField("dataType", StringType(), True),
                    ]
                )
            ),
            "hmcl_ev_can0_bms1_battery_pack_temperature": ArrayType(
                StructType(
                    [  # Complex type example
                        StructField("value", DoubleType(), True),
                        StructField("time", LongType(), True),
                        StructField("dataType", StringType(), True),
                    ]
                )
            ),
            "hmcl_ev_can0_bms2_battery_pack_temperature": ArrayType(
                StructType(
                    [  # Complex type example
                        StructField("value", DoubleType(), True),
                        StructField("time", LongType(), True),
                        StructField("dataType", StringType(), True),
                    ]
                )
            ),
            "hmcl_ice_can0_engine_temperture": ArrayType(
                StructType(
                    [  # Complex type example
                        StructField("value", DoubleType(), True),
                        StructField("time", LongType(), True),
                        StructField("dataType", StringType(), True),
                    ]
                )
            ),
            "hmcl_common_vcan0_latitude": ArrayType(
                StructType(
                    [  # Complex type example
                        StructField("value", DoubleType(), True),
                        StructField("time", LongType(), True),
                        StructField("dataType", StringType(), True),
                    ]
                )
            ),
            "hmcl_common_vcan0_longitude": ArrayType(
                StructType(
                    [  # Complex type example
                        StructField("value", DoubleType(), True),
                        StructField("time", LongType(), True),
                        StructField("dataType", StringType(), True),
                    ]
                )
            ),
            "hmcl_common_vcan0_harsh_driving_alert": ArrayType(
                StructType(
                    [  # Complex type example
                        StructField("value", LongType(), True),
                        StructField("time", LongType(), True),
                        StructField("dataType", StringType(), True),
                    ]
                )
            ),
            "hmcl_ev_can0_remaining_range": ArrayType(
                StructType(
                    [  # Complex type example
                        StructField("value", DoubleType(), True),
                        StructField("time", LongType(), True),
                        StructField("dataType", StringType(), True),
                    ]
                )
            ),
            "hmcl_common_vcan0_gps_valid": ArrayType(
                StructType(
                    [  # Complex type example
                        StructField("value", BooleanType(), True),
                        StructField("time", LongType(), True),
                        StructField("dataType", StringType(), True),
                    ]
                )
            ),
            "hmcl_common_vcan0_gps_fix": ArrayType(
                StructType(
                    [  # Complex type example
                        StructField("value", IntegerType(), True),
                        StructField("time", LongType(), True),
                        StructField("dataType", StringType(), True),
                    ]
                )
            ),
            "hmcl_common_vcan0_hdop": ArrayType(
                StructType(
                    [  # Complex type example
                        StructField("value", FloatType(), True),
                        StructField("time", LongType(), True),
                        StructField("dataType", StringType(), True),
                    ]
                )
            ),
            "hmcl_common_vcan0_vdop": ArrayType(
                StructType(
                    [  # Complex type example
                        StructField("value", FloatType(), True),
                        StructField("time", LongType(), True),
                        StructField("dataType", StringType(), True),
                    ]
                )
            ),
            "hmcl_common_vcan0_pdop": ArrayType(
                StructType(
                    [  # Complex type example
                        StructField("value", FloatType(), True),
                        StructField("time", LongType(), True),
                        StructField("dataType", StringType(), True),
                    ]
                )
            ),
            "b2bclientid": StringType(),
        }

        opensearch_read_telemetry_df = select_missing_columns_with_nulls(
            opensearch_read_telemetry_df, columns_to_select
        )

        opensearch_read_telemetry_df_renamed = opensearch_read_telemetry_df.selectExpr(
            "hmcl_ev_can0_vehicle_speed_vcu as vehicle_speed",  # hmcl.ev.can0.vehicle_speed_vcu
            "hmcl_ev_can0_odo_reading as tele_odo_vcu",  # hmcl_ev_can0_odo_vcu
            "vid",
            "campaignname as campaign_name",
            "collectioneventtime",
            "collectioneventtime_ts as collectioneventtime_ts",
            "hmcl_ev_can0_cluster_speed as tele_cluster_speed",
            "hmcl_ev_can0_total_usable_energy as tele_total_usable_energy",
            "hmcl_ev_can0_vehicle_mode_signal as tele_vehicle_mode_signal",
            "hmcl_ev_can0_soc_user_percentage as tele_soc_user_percentage",
            "hmcl_common_vcan0_fuel_level_volts as tele_fuel_level_volts",
            "hmcl_ice_can0_fuel_percentage as tele_fuel_percentage",
            "hmcl_ev_can0_battery_pack_temperature as tele_battery_pack_temperature",
            "hmcl_ev_can0_ambient_temperature as tele_ambient_temperature",
            "hmcl_ice_can0_engine_temperture as tele_engine_temperture",
            "hmcl_common_vcan0_latitude as tele_latitude",
            "hmcl_common_vcan0_longitude as tele_longitude",
            "hmcl_ev_can0_bms1_battery_pack_temperature as tele_bms1_battery_pack_temperature",
            "hmcl_ev_can0_bms2_battery_pack_temperature as tele_bms2_battery_pack_temperature",
            "hmcl_common_vcan0_harsh_driving_alert as tele_harsh_driving_alert",
            "hmcl_ev_can0_remaining_range as tele_remaining_range_in_km",
            "hmcl_common_vcan0_gps_valid as tele_gps_valid",
            "hmcl_common_vcan0_gps_fix as tele_gps_fix",
            "hmcl_tenantid as tenant_id",
            "hmcl_common_vcan0_hdop as tele_hdop",
            "hmcl_common_vcan0_vdop as tele_vdop",
            "hmcl_common_vcan0_pdop as tele_pdop",
            "b2bclientid",
        )

        opensearch_read_telemetry_df_renamed = (
            opensearch_read_telemetry_df_renamed.withColumn(
                "collectioneventtimets",
                F.date_format(
                    F.col("collectioneventtime_ts"),
                    "yyyy-MM-dd'T'HH:mm:ss.SSS",
                ),
            )
        )

        opensearch_read_telemetry_df_renamed = (
            opensearch_read_telemetry_df_renamed.drop(
                "vehicle_speed_display", "vehicle_speed", "tenant_id"
            )
        )
        df_target_tele = func_rename_col(opensearch_read_telemetry_df_renamed)

        # array_attr_for_latest = []

        array_attr_to_flatten = [
            "tele_odo_vcu",
            "tele_total_usable_energy",
            "tele_vehicle_mode_signal",
            "tele_cluster_speed",
            "tele_battery_pack_temperature",
            "tele_bms1_battery_pack_temperature",
            "tele_bms2_battery_pack_temperature",
            "tele_harsh_driving_alert",
            "tele_remaining_range_in_km",
            "tele_gps_valid",
            "tele_gps_fix",
            "tele_latitude",
            "tele_longitude",
            "tele_soc_user_percentage",
            "tele_fuel_level_volts",
            "tele_fuel_percentage",
            "tele_ambient_temperature",
            "tele_engine_temperture",
            "tele_hdop",
            "tele_vdop",
            "tele_pdop",
        ]

        # latest_value_udf = F.udf(get_latest_value, StringType())
        # for col in array_attr_for_latest:
        #    df_target_tele = df_target_tele.withColumn(col, latest_value_udf(F.col(col)))

        df_flatten = flatten_df(df_target_tele, array_attr_to_flatten)

        # need fill null with lead or lag vlaues, yet to implemnet

        columns_to_cast = {
            "tele_soc_user_percentage": "double",
            "tele_fuel_level_volts": "double",
            "tele_fuel_percentage": "double",
            "tele_battery_pack_temperature": "double",
            "tele_bms1_battery_pack_temperature": "double",
            "tele_bms2_battery_pack_temperature": "double",
            "tele_ambient_temperature": "double",
            "tele_engine_temperture": "double",
            "tele_cluster_speed": "double",
            "tele_vehicle_mode_signal": "integer",
            "tele_latitude": "double",
            "tele_longitude": "double",
            "tele_odo_vcu": "double",
            "tele_remaining_range_in_km": "double",
            "tele_total_usable_energy": "double",
            "tele_harsh_driving_alert": "long",
            "tele_gps_valid": "boolean",
            "tele_gps_fix": "integer",
            "tele_pdop": "float",
            "tele_hdop": "float",
            "tele_vdop": "float",
            "b2bclientid": "string",
        }

        df_target_tele = cast_selected_columns(df_flatten, columns_to_cast)

        return df_target_tele
    except Exception as exp:
        logging.error("An error occurred in reading telemetry data : %s", str(exp))
        traceback.print_exc()
        raise


def count_elements(row):
    global count_accum
    count_accum.add(1)


def func_case_col(dataframe_ip, value):
    try:

        new_columns = [col + value for col in dataframe_ip.columns]
        df_renamed = dataframe_ip
        for old_col, new_col in zip(dataframe_ip.columns, new_columns):
            df_renamed = df_renamed.withColumnRenamed(old_col.lower(), new_col.lower())
        return df_renamed
    except Exception as exp:
        logging.error("An error occurred in converting case in columns : %s", str(exp))
        traceback.print_exc()
        raise


def func_rename_col(dataframe_ip):
    """
    replace . with _
    """

    # new_columns = [col.replace(".", "_") for col in dataframe_ip.columns]

    try:
        new_columns = [re.sub(r"[.-]", "_", col) for col in dataframe_ip.columns]
        df_renamed_val = dataframe_ip
        for old_col, new_col in zip(dataframe_ip.columns, new_columns):
            df_renamed_val = df_renamed_val.withColumnRenamed(
                old_col.lower(), new_col.lower()
            )
        return df_renamed_val
    except Exception as exp:
        logging.error("An error occurred in renaming columns : %s", str(exp))
        traceback.print_exc()
        raise


def select_missing_columns_with_nulls(df, columns_to_select):
    """
    Selects columns from the DataFrame, if a column doesn't exist,
    it creates a column with null values (with complex types where applicable).
    Also retains extra columns in the dataframe that are not specified in `columns_to_select`.
    """
    selected_columns = []

    try:

        # Loop through the columns to select
        # (as dictionary: key is column name, value is target type)
        for col_name, col_type in columns_to_select.items():
            if col_name in df.columns:
                if isinstance(col_type, ArrayType):
                    # Handle the case where the array is empty (size = 0)
                    field_obj = df.schema[col_name]
                    if len(field_obj.dataType.elementType.fields) == 0:

                        selected_columns.append(
                            F.array(
                                F.struct(
                                    *[
                                        F.lit(None)
                                        .cast(field.dataType)
                                        .alias(field.name)
                                        for field in col_type.elementType.fields
                                    ]
                                )
                            ).alias(col_name)
                        )

                    else:
                        selected_columns.append(
                            F.when(
                                F.size(F.col(col_name)) == 0,
                                F.array(
                                    F.struct(
                                        *[
                                            F.lit(None)
                                            .cast(field.dataType)
                                            .alias(field.name)
                                            for field in col_type.elementType.fields
                                        ]
                                    )
                                ),
                            )
                            .when(
                                F.col(col_name).isNull(),
                                F.array(
                                    F.struct(
                                        *[
                                            F.lit(None)
                                            .cast(field.dataType)
                                            .alias(field.name)
                                            for field in col_type.elementType.fields
                                        ]
                                    )
                                ),
                            )
                            .otherwise(F.col(col_name).cast(col_type))
                            .alias(col_name)
                        )
                else:
                    # If it's not an array, simply select and cast it to the target type
                    selected_columns.append(
                        F.col(col_name).cast(col_type).alias(col_name)
                    )

            else:
                # If the column is expected to be a complex type (Array of Struct),
                # create it with nulls
                if isinstance(col_type, ArrayType) and isinstance(
                    col_type.elementType, StructType
                ):
                    # Dynamically create structs with null values for each field in the struct based on schema
                    struct_fields = []
                    for field in col_type.elementType.fields:
                        # Get the name and type of each field and create a null value with the correct type
                        struct_fields.append(
                            F.lit(None).cast(field.dataType).alias(field.name)
                        )
                    # Create an array of structs
                    selected_columns.append(
                        F.array(F.struct(*struct_fields)).alias(col_name)
                    )
                else:
                    # For simple types, create it with nulls and cast
                    selected_columns.append(F.lit(None).cast(col_type).alias(col_name))

        # Add any extra columns that are present in the DataFrame but not in `columns_to_select`
        for col in df.columns:

            if col not in columns_to_select:
                selected_columns.append(F.col(col))

        # Select the columns
        return df.select(*selected_columns)
    except Exception as exp:
        logging.error("An error occurred in imputing null values : %s", str(exp))
        traceback.print_exc()
        raise


def write_to_s3(
    df,
    table_name,
    database,
    s3_output_path,
    s3_output_partition_path,
    partition_col_variable,
):
    try:
        hudi_options = {
            "hoodie.table.name": table_name,
            "hoodie.datasource.write.operation": "insert",
            # "hoodie.datasource.write.precombine.field": "collectioneventtime_ts",
            "hoodie.datasource.write.partitionpath.field": "tenant_id,use_case_name,year,month,day,hour",
            "hoodie.datasource.write.recordkey.field": "vid,trip_id",
            "hoodie.datasource.hive_sync.enable": "true",
            "hoodie.datasource.hive_sync.database": database,
            "hoodie.datasource.hive_sync.table": table_name,
            "hoodie.datasource.hive_sync.use_jdbc": "false",
            "hoodie.datasource.hive_sync.mode": "hms",
            "hoodie.datasource.hive_sync.support_timestamp": "true",
            "hoodie.datasource.meta.sync.enable": "true",
            "path": s3_output_path,
            "hoodie.parquet.max.file.size": "134217728",
            "hoodie.datasource.write.reconcile.schema": "true",
        }

        # #"hoodie.schema.on.read.enable":"true",
        # "hoodie.datasource.write.schema.evolution.enable":"true"
        # "hoodie.datasource.write.schemaValidation":"true"
        # Load to Hudi table
        # df_trip_start_end_final

        if len(df.head(1)) > 0:

            partition_extract_col = "trip_start_timestamp"
            use_case_name = "trip_analytics"

            partition_extract_col_ts = partition_extract_col + "_part"
            df = (
                df.withColumn(
                    partition_extract_col_ts,
                    F.col(partition_extract_col).cast(TimestampType()),
                )
                .withColumn("year", F.year(F.col(partition_extract_col_ts)))
                .withColumn("month", F.month(F.col(partition_extract_col_ts)))
                .withColumn("day", F.dayofmonth(F.col(partition_extract_col_ts)))
                .withColumn("hour", F.hour(F.col(partition_extract_col_ts)))
                .withColumn("use_case_name", F.lit(use_case_name))
            ).drop(partition_extract_col_ts)

            nullable_schema = StructType(
                [
                    StructField(field.name, field.dataType, True)
                    for field in df.schema.fields
                ]
            )

            # Apply the new schema to create a new DataFrame

            df = spark.createDataFrame(df.rdd, nullable_schema)

            if spark._jsparkSession.catalog().tableExists(database, table_name):

                latest_partition_date = retrieve_parameter(partition_col_variable)

                if latest_partition_date == default_param_store_val:
                    partition_path = f"{s3_output_partition_path}/{use_case_name}"
                else:

                    source_partition = get_s3_latest_partition(
                        latest_partition_date, partition_type="hour", zone="IST"
                    )

                    partition_path = (
                        f"{s3_output_partition_path}/{use_case_name}/{source_partition}"
                    )
                logging.info("partion path to read:%s", partition_path)

                df_target_ext_tgt = (
                    spark.read.format("hudi").load(partition_path).limit(1)
                )

                for field in df_target_ext_tgt.schema.fields:
                    if field.name not in df.columns:
                        if "StringType()" == field.dataType:
                            df = df.withColumn(
                                field.name, F.lit("").cast(field.dataType)
                            )
                        elif (
                            "IntegerType()" == field.dataType
                            or "LongType()" == field.dataType
                        ):
                            df = df.withColumn(
                                field.name, F.lit(0).cast(field.dataType)
                            )
                        elif (
                            "DoubleType()" == field.dataType
                            or "FloatType()" == field.dataType
                        ):
                            df = df.withColumn(
                                field.name, F.lit(0.0).cast(field.dataType)
                            )
                        else:
                            df = df.withColumn(
                                field.name, F.lit(None).cast(field.dataType)
                            )

            df.write.format("org.apache.hudi").options(**hudi_options).mode(
                "append"
            ).save()

            max_part_date = df.agg(
                F.max(F.col(partition_extract_col).cast(TimestampType()))
            ).collect()[0][0]

            store_parameter(partition_col_variable, str(max_part_date))

    except Exception as exp:
        logging.error("An error occurred while writing to S3 : %s", str(exp))
        traceback.print_exc()


def write_to_kafka(df, kafka_broker, topic):
    try:
        df.selectExpr("to_json(struct(*)) AS value").write.format("kafka").option(
            "kafka.bootstrap.servers", kafka_broker
        ).option("topic", topic).option("kafka.security.protocol", "SASL_SSL").option(
            "kafka.sasl.mechanism", "AWS_MSK_IAM"
        ).option(
            "kafka.sasl.jaas.config",
            "software.amazon.msk.auth.iam.IAMLoginModule required;",
        ).option(
            "kafka.sasl.client.callback.handler.class",
            "software.amazon.msk.auth.iam.IAMClientCallbackHandler",
        ).save()

    except Exception as exp:
        logging.error("An error occurred while writing to kafka topic : %s", str(exp))
        traceback.print_exc()

def update_telemetry_with_trip_data(df, column_mappings):
    """
    Updates telemetry columns using trip start/end values with fallback to polling_time
    when collectioneventtime is identical across trip packets.

    Parameters:
    - df: trip_tele DataFrame
    - column_mappings: List of tuples in format (target_col, start_col, end_col)
    """
    try:
        trip_partition = ["vehicle_id_trip_start", "trip_id_trip_start"]
        event_time = 'collectioneventtime'
        polling_time = 'polling_time'

        # Create time boundaries for both time columns
        window = Window.partitionBy(trip_partition)
        df = (df
              .withColumn("min_event", F.min(event_time).over(window))
              .withColumn("max_event", F.max(event_time).over(window))
              .withColumn("min_poll", F.min(polling_time).over(window))
              .withColumn("max_poll", F.max(polling_time).over(window))
              )

        # Process each column mapping
        for target_col, start_col, end_col in column_mappings:
            df = df.withColumn(
                target_col,
                # End values first (handles single-packet trips)
                F.when(
                    ((F.col("min_event") != F.col("max_event")) & (F.col(event_time) == F.col("max_event"))) |
                    ((F.col("min_event") == F.col("max_event")) & (F.col(polling_time) == F.col("max_poll"))),
                    F.coalesce(F.col(end_col), F.col(target_col))
                )
                # Then start values
                .when(
                    ((F.col("min_event") != F.col("max_event")) & (F.col(event_time) == F.col("min_event"))) |
                    ((F.col("min_event") == F.col("max_event")) & (F.col(polling_time) == F.col("min_poll"))),
                    F.coalesce(F.col(start_col), F.col(target_col))
                )
                .otherwise(F.col(target_col))
            )

        return df.drop("min_event", "max_event", "min_poll", "max_poll")

    except Exception as e:
        logging.error("An error occurred while updating telemetry with trip: %s", str(e))
        return df

def extract(
    os_trip_start_index,
    os_trip_end_index,
    os_trip_break_index,
    os_trip_stat_index,
    tenantid_in,
    os_telemetry_index,
):
    """
    This function extracts the data from OS loads to hudi and OS
    """

    try:
        logging.info("extract method  started for tenant id %s", tenantid_in)
        start_time = datetime.now()

        logging.info("job_name=%s", args.get("JOB_NAME"))
        logging.info("Calling log audit to log the status is job started")

        log_audit(
            spark,
            args["JOB_NAME"],
            source_name,
            source_type,
            target,
            target_type,
            "Started",
            start_time,
            None,
            None,
            audit_path,
            audit_table,
        )

        param_store_variable = "trip_stats_ts_start_" + batch_type + "_" + tenantid_in
        partition_col_variable = (
            "trip_stats_partition_" + batch_type + "_" + tenantid_in
        )
        logging.info("Getting start timestamp from paramter store")
        ts_start = retrieve_parameter(param_store_variable)

        # ts_start = "2024-12-18T05:00:00Z"

        # Define the IST timezone
        ist = pytz.timezone("Asia/Kolkata")
        utc_time = datetime.now(pytz.utc)

        # Convert UTC time to IST
        ist_time = utc_time.astimezone(ist)

        # Truncate the time to the nearest hour
        truncated_time = ist_time.replace(minute=0, second=0, microsecond=0)
        final_time = truncated_time - timedelta(hours=1)

        ts_end = final_time.strftime("%Y-%m-%dT%H:%M:%SZ")

        # ts_end = "2024-12-18T23:00:00Z"

        logging.info(f"ts_start:{ts_start} ts_end: {ts_end}")
        ts_end_format = "yyyy-MM-dd'T'HH:mm:ss'Z'"

        tenantid = "%" + tenantid_in + "%"

        s3_output_partition_path = (
            "s3://" + raw_bucket + "/" + table_name + "/" + tenantid_in
        )

        s3_tele_extract_output_path = (
            "s3://"
            + raw_bucket
            + "/cvp-telemetry-hudi/"
            + tenantid_in
            + "/"
            + "hmcl-thor-rfw-telemetry-per-mstr-v1-k2"
        )

        trip_filter_query = get_filter_query(ts_start, ts_end, "timestamp", "trip")
        trip_end_filter_query = get_filter_query(
            ts_start, ts_end, "timestamp", "trip"
        )
        break_filter_query = get_filter_query(
            ts_start, ts_end, "break_start_timestamp", "trip"
        )

        trip_columns_select = {
            "vehicle_id": StringType(),
            "tenant_id": StringType(),
            "campaign_name": StringType(),
            "trip_id": StringType(),
            "timestamp": TimestampType(),
            "source_timestamp": LongType(),
            "vdop": FloatType(),
            "hdop": FloatType(),
            "pdop": FloatType(),
            "soc": DoubleType(),
            "odometer_reading": DoubleType(),
            "fuel_percentage": DoubleType(),
            "latitude": DoubleType(),
            "longitude": DoubleType(),
            "ambient_temperature": DoubleType(),
            "fuel_value": DoubleType(),
            "usable_energy": DoubleType(),
            "vehicle_mode": StringType(),
            "user_id": StringType(),
            "user_profile": StringType(),
            "user_name": StringType(),
            "gps_fix": IntegerType(),
            "gps_valid": BooleanType(),
            "remaining_range": DoubleType(),
            "processingtime": LongType(),
        }

        trip_columns = list(trip_columns_select.keys())

        trip_break_columns_select = {
            "vdop": FloatType(),
            "hdop": FloatType(),
            "pdop": FloatType(),
            "soc": DoubleType(),
            "odometer_reading": DoubleType(),
            "fuel_percentage": DoubleType(),
            "fuel_value": DoubleType(),
            "gps_fix": IntegerType(),
            "gps_valid": BooleanType(),
            "latitude": DoubleType(),
            "longitude": DoubleType(),
            "user_id": StringType(),
            "user_profile": StringType(),
            "user_name": StringType(),
        }

        opensearch_read_trip_start = glueContext.create_dynamic_frame.from_options(
            connection_type="opensearch",
            connection_options={
                "connectionName": os_connector_name,
                "opensearch.port": 443,
                "es.partitioning.field": "vehicle_id",
                "es.partitioning.total": read_partitions,
                "opensearch.resource": os_trip_start_index,
                "opensearch.query": trip_filter_query,
                "pushdown": "true",
                # "opensearch.read.field.include": trip_columns,
            },
        ).toDF()

        opensearch_read_trip_start = select_missing_columns_with_nulls(
            opensearch_read_trip_start, trip_columns_select
        )

        opensearch_read_trip_end = glueContext.create_dynamic_frame.from_options(
            connection_type="opensearch",
            connection_options={
                "connectionName": os_connector_name,
                "opensearch.port": 443,
                "es.partitioning.field": "vehicle_id",
                "es.partitioning.total": read_partitions,
                "opensearch.resource": os_trip_end_index,
                "opensearch.query": trip_end_filter_query,
                "pushdown": "true",
                # "opensearch.read.field.include": trip_columns,
            },
        ).toDF()

        opensearch_read_trip_end = select_missing_columns_with_nulls(
            opensearch_read_trip_end, trip_columns_select
        )

        opensearch_read_trip_break = glueContext.create_dynamic_frame.from_options(
            connection_type="opensearch",
            connection_options={
                "connectionName": os_connector_name,
                "opensearch.port": 443,
                "es.partitioning.field": "vehicle_id",
                "es.partitioning.total": read_partitions,
                "opensearch.resource": os_trip_break_index,
                "opensearch.query": break_filter_query,
                "pushdown": "true",
            },
        ).toDF()

        opensearch_read_trip_break = select_missing_columns_with_nulls(
            opensearch_read_trip_break, trip_break_columns_select
        )

        opensearch_read_trip_break = fill_na_with_default(opensearch_read_trip_break)

        # df_target_tele = read_telemetry(
        #     ts_start, ts_end, tenantid_in, s3_tele_extract_output_path
        # )

        not_needed_from_trip_start_end = [
            "battery_temperature1",
            "battery_temperature2",
            "harsh_acceleration",
            "harsh_braking",
            "driving_score",
            "trip_accuracy",
            "usable_capacity",
            "trip_end_flag",
            "collectioneventtime",
            "collectioneventtimets",
            "processingtimets",
            "trip_source",
            "user_details_source",
            "trip_start_odometer_value",
        ]

        opensearch_read_trip_start = opensearch_read_trip_start.drop(
            *not_needed_from_trip_start_end
        )
        opensearch_read_trip_end = opensearch_read_trip_end.drop(
            *not_needed_from_trip_start_end
        )

        opensearch_read_trip_start = func_case_col(
            opensearch_read_trip_start, "_trip_start"
        )

        # removing duplicate trip start

        window_spec_trip = Window.partitionBy("trip_id_trip_start").orderBy(
            "processingtime_trip_start"
        )
        opensearch_read_trip_start = opensearch_read_trip_start.withColumn(
            "rownum",
            F.row_number().over(window_spec_trip),
        ).filter(F.col("rownum") == 1)
        opensearch_read_trip_start = opensearch_read_trip_start.drop("rownum")
        # removing duplicate trip start logic ended

        if (opensearch_read_trip_start.count() == 0) and (
            opensearch_read_trip_end.count() == 0
        ):
            logging.info(
                "There is no trip data so not proceeding further for tenant %s",
                tenantid_in,
            )
            store_parameter(param_store_variable, ts_end)

            return 1

        opensearch_read_trip_end = func_case_col(opensearch_read_trip_end, "_trip_end")

        df_trip_start_end = opensearch_read_trip_start.join(
            opensearch_read_trip_end,
            (
                opensearch_read_trip_start["vehicle_id_trip_start"]
                == opensearch_read_trip_end["vehicle_id_trip_end"]
            )
            & (
                opensearch_read_trip_start["trip_id_trip_start"]
                == opensearch_read_trip_end["trip_id_trip_end"]
            ),
            "inner",
        )

        trip_start_end_cols_to_cast = {
            "timestamp_trip_start": "timestamp",
            "timestamp_trip_end": "timestamp",
            "source_timestamp_trip_start": "long",
            "source_timestamp_trip_end": "long",
            "latitude_trip_start": "double",
            "latitude_trip_end": "double",
            "longitude_trip_start": "double",
            "longitude_trip_end": "double",
        }
        df_trip_start_end = cast_selected_columns(
            df_trip_start_end, trip_start_end_cols_to_cast
        )

        df_trip_start_end = df_trip_start_end.drop(
            "source_trip_start_timestamp_trip_end", "trip_start_timestamp_trip_end"
        )

        df_trip_start_end = fill_na_with_default(
            df_trip_start_end, opensearch_read_trip_end.columns
        )

        trip_break_cols_to_cast = {
            "break_start_timestamp": "timestamp",
            "break_end_timestamp": "timestamp",
            "latitude": "double",
            "longitude": "double",
        }

        opensearch_read_trip_break = cast_selected_columns(
            opensearch_read_trip_break, trip_break_cols_to_cast
        )

        # # Merging logic started here
        logging.info("merging logic started here")

        windowspec_1 = Window.partitionBy("vehicle_id_trip_start").orderBy(
            "timestamp_trip_start"
        )

        df_trip_start_end_inter1 = df_trip_start_end.withColumn(
            "unix_timestamp_trip_end",
            F.unix_timestamp(F.to_timestamp(F.col("timestamp_trip_end"))),
        ).withColumn(
            "unix_timestamp_trip_start",
            F.unix_timestamp(F.to_timestamp(F.col("timestamp_trip_start"))),
        )

        df_trip_start_end_inter1 = df_trip_start_end_inter1.withColumn(
            "trips_break_time_ref1",
            (
                F.lead(F.col("unix_timestamp_trip_start")).over(windowspec_1)
                - F.col("unix_timestamp_trip_end")
            )
            / 60,
        ).withColumn(
            "trips_break_time_ref2",
            (
                F.col("unix_timestamp_trip_start")
                - F.lag(F.col("unix_timestamp_trip_end")).over(windowspec_1)
            )
            / 60,
        )

        df_trip_start_end_inter1.select(
            "trips_break_time_ref1", "trips_break_time_ref2"
        )

        df_trip_start_end_inter1 = df_trip_start_end_inter1.drop(
            "unix_timestamp_trip_end", "unix_timestamp_trip_start"
        )

        df_trip_start_end_inter1 = df_trip_start_end_inter1.withColumn(
            "is_trips_break_ref1",
            F.when(
                F.col("trips_break_time_ref1").cast(IntegerType()) < 3, True
            ).otherwise(False),
        ).withColumn(
            "is_trips_break_ref2",
            F.when(
                F.col("trips_break_time_ref2").cast(IntegerType()) < 3, True
            ).otherwise(False),
        )

        df_trip_start_end_inter2 = df_trip_start_end_inter1.withColumn(
            "trip_break_session_change",
            F.when(
                (F.lag(F.col("is_trips_break_ref2")).over(windowspec_1) == True)
                & (F.col("is_trips_break_ref2") == False),
                1,
            ).otherwise(0),
        )

        df_trip_start_end_inter3 = df_trip_start_end_inter2.withColumn(
            "trip_session", F.sum("trip_break_session_change").over(windowspec_1)
        )

        df_trip_no_ign_breaks = df_trip_start_end_inter3.filter(
            (F.col("is_trips_break_ref1") == False)
            & (F.col("is_trips_break_ref2") == False)
        )

        df_trip_with_ign_breaks = df_trip_start_end_inter3.filter(
            (F.col("is_trips_break_ref1") == True)
            | (F.col("is_trips_break_ref2") == True)
        )

        trip_merge_columns = [
            (
                F.first(col).alias(col)
                if "_trip_start" in col and col != "vehicle_id_trip_start"
                else (F.last(col).alias(col) if "_trip_end" in col else "")
            )
            for col in df_trip_with_ign_breaks.columns
        ]
        trip_merge_columns = [col for col in trip_merge_columns if col is not ""]

        derived_cols_for_merge = [
            "trips_break_time_ref1",
            "trips_break_time_ref2",
            "is_trips_break_ref1",
            "is_trips_break_ref2",
            "trip_break_session_change",
            "trip_session",
        ]

        df_trip_no_ign_breaks = df_trip_no_ign_breaks.drop(*derived_cols_for_merge)

        df_trip_start_end_merge = df_trip_with_ign_breaks.groupBy(
            "vehicle_id_trip_start", "trip_session"
        ).agg(
            *trip_merge_columns,
            F.collect_list("trip_id_trip_start").alias("merged_trips"),
        )

        # creating data frame with merged trips logic started

        merged_trips = df_trip_start_end_merge.select(
            F.col("vehicle_id_trip_start").alias("vid"),
            F.col("tenant_id_trip_start").alias("tenantId"),
            F.col("trip_id_trip_start").alias("tripId"),
            F.col("source_timestamp_trip_start").alias("startTime"),
            F.col("timestamp_trip_start").alias("startTimeTS"),
            F.col("source_timestamp_trip_end").alias("endTime"),
            F.col("timestamp_trip_end").alias("endTimeTS"),
            "merged_trips",
        )

        merged_trip_flattened = merged_trips.select(
            "*", F.explode(F.col("merged_trips")).alias("merged_trip_id")
        )

        merged_trip_flattened = merged_trip_flattened.filter(
            F.col("tripId") != F.col("merged_trip_id")
        ).select(
            "vid",
            "tripId",
            "merged_trip_id",
            F.concat(
                F.col("vid"),
                F.col("merged_trip_id"),
            ).alias("id"),
            F.lit(True).alias("is_deleted"),
        )

        # merged_trip_mapping_flat=merged_trip_mapping.withColumn()

        # creating data frame with merged trips logic ended

        df_trip_start_end_merge = df_trip_start_end_merge.drop("trip_session")

        df_trip_start_end_merge = df_trip_start_end_merge.withColumn(
            "trip_id_trip_end", F.col("trip_id_trip_start")
        ).select(*df_trip_start_end.columns)

        df_trip_start_end = df_trip_start_end_merge.union(df_trip_no_ign_breaks)

        windowspec_2 = Window.partitionBy(
            "vehicle_id_trip_start", "trip_session"
        ).orderBy("timestamp_trip_start")

        df_trip_ign_breaks = df_trip_with_ign_breaks.withColumn(
            "trip_break_id", F.first(F.col("trip_id_trip_start")).over(windowspec_2)
        )

        df_trip_ign_breaks = df_trip_ign_breaks.select(
            F.col("vehicle_id_trip_start").alias("vehicle_id"),
            F.col("tenant_id_trip_start").alias("tenant_id"),
            F.col("campaign_name_trip_start").alias("campaign_name"),
            F.col("trip_break_id").alias("trip_id"),
            F.lead(F.col("trip_id_trip_start")).over(windowspec_2).alias("trip_sub_id"),
            F.col("timestamp_trip_end").alias("break_start_timestamp"),
            F.lead(F.col("timestamp_trip_start"))
            .over(windowspec_2)
            .alias("break_end_timestamp"),
            F.col("longitude_trip_end").alias("longitude"),
            F.col("latitude_trip_end").alias("latitude"),
            F.col("gps_fix_trip_end").alias("gps_fix"),
            F.col("gps_valid_trip_end").alias("gps_valid"),
            F.col("hdop_trip_end").alias("hdop"),
            F.col("vdop_trip_end").alias("vdop"),
            F.col("pdop_trip_end").alias("pdop"),
            F.col("odometer_reading_trip_end").alias("odometer_reading"),
            F.col("soc_trip_end").alias("soc"),
            F.col("fuel_percentage_trip_end").alias("fuel_percentage"),
            F.col("fuel_value_trip_end").alias("fuel_value"),
        )

        df_trip_ign_breaks = df_trip_ign_breaks.filter(
            F.col("break_end_timestamp").isNotNull()
        )

        df_trip_non_ign_breaks = (
            opensearch_read_trip_break.alias("source_breaks")
            .join(
                df_trip_ign_breaks.alias("ign_breaks"),
                F.col("source_breaks.trip_id") == F.col("ign_breaks.trip_sub_id"),
                how="left",
            )
            .select(
                "source_breaks.vehicle_id",
                "source_breaks.tenant_id",
                "source_breaks.campaign_name",
                F.coalesce(
                    F.col("ign_breaks.trip_id"), F.col("source_breaks.trip_id")
                ).alias("trip_id"),
                F.lit("").alias("trip_sub_id"),
                "source_breaks.break_start_timestamp",
                "source_breaks.break_end_timestamp",
                "source_breaks.longitude",
                "source_breaks.latitude",
                "source_breaks.gps_fix",
                "source_breaks.gps_valid",
                "source_breaks.hdop",
                "source_breaks.vdop",
                "source_breaks.pdop",
                "source_breaks.odometer_reading",
                "source_breaks.soc",
                "source_breaks.fuel_percentage",
                "source_breaks.fuel_value",
            )
        )

        df_trip_breaks = df_trip_non_ign_breaks.union(df_trip_ign_breaks)
        df_trip_breaks = df_trip_breaks.drop("trip_sub_id")

        # this is checking lat long validity and if not valid imputing 0
        df_trip_breaks = df_trip_breaks.withColumn(
            "longitude",
            F.when(
                (F.col("longitude").isNull()) | (F.col("longitude") > 180), 0.0
            ).otherwise(F.col("longitude")),
        ).withColumn(
            "latitude",
            F.when(
                (F.col("latitude").isNull()) | (F.col("latitude") > 90), 0.0
            ).otherwise(F.col("latitude")),
        )

        df_trip_breaks = df_trip_breaks.groupBy(
            "vehicle_id", "tenant_id", "trip_id"
        ).agg(
            F.sum(
                F.unix_timestamp(F.col("break_end_timestamp"))
                - F.unix_timestamp(F.col("break_start_timestamp"))
            ).alias("break_duration"),
            F.collect_list(F.col("longitude")).alias("longitude"),
            F.collect_list(F.col("latitude")).alias("latitude"),
            F.collect_list(
                F.struct(
                    F.coalesce(F.col("fuel_percentage"), F.lit(0.0)).alias(
                        "fuel_percentage"
                    ),
                    F.coalesce(F.col("fuel_value"), F.lit(0.0)).alias("fuel_value"),
                    F.coalesce(F.col("gps_fix"), F.lit(0)).alias("gps_fix"),
                    F.coalesce(F.col("gps_valid"), F.lit(False)).alias("gps_valid"),
                    F.coalesce(F.col("hdop"), F.lit(0.0)).alias("hdop"),
                    F.struct(
                        F.col("latitude").alias("lat"),
                        F.col("longitude").alias("lon"),
                    ).alias("location"),
                    F.coalesce(F.col("odometer_reading"), F.lit(0.0)).alias("odometer"),
                    F.coalesce(F.col("pdop"), F.lit(0.0)).alias("pdop"),
                    F.coalesce(F.col("soc"), F.lit(0.0)).alias("soc"),
                    F.coalesce(
                        (
                            (
                                (F.unix_timestamp(F.col("break_start_timestamp")))
                                - (5.5 * 60 * 60)
                            )
                            * 1000
                        ),
                        F.lit(0),
                    ).alias("timestamp"),
                    F.coalesce(F.col("vdop"), F.lit(0.0)).alias("vdop"),
                )
            ).alias("location"),
        )

        df_trip_breaks = func_case_col(df_trip_breaks, "_trip_break")

        logging.info("merging logic ended ")

        # # Merging logic ended here

        logging.info("trips Joining with breaks")

        df_trip_start_end = df_trip_start_end.join(
            df_trip_breaks,
            (
                df_trip_breaks["vehicle_id_trip_break"]
                == df_trip_start_end["vehicle_id_trip_start"]
            )
            & (
                df_trip_breaks["trip_id_trip_break"]
                == df_trip_start_end["trip_id_trip_start"]
            ),
            "left",
        ).select(  # Since we do not have break information for all trips , filling default value for missing breaks
            *df_trip_start_end,
            F.coalesce(F.col("break_duration_trip_break"), F.lit(0)).alias(
                "break_duration_trip_break"
            ),
            F.coalesce(F.col("latitude_trip_break"), F.array()).alias(
                "latitude_trip_break"
            ),
            F.coalesce(F.col("longitude_trip_break"), F.array()).alias(
                "longitude_trip_break"
            ),
            F.coalesce(F.col("location_trip_break"), F.array()).alias(
                "location_trip_break"
            ),
        )

        # deriving trip_flag and deriving trip end time stamp for on going sessions to fetch telemetry data

        logging.info("Deriving end timestamp and trip falg")

        df_trip_start_end = (
            df_trip_start_end.withColumn(
                "next_trip_id", F.lead(F.col("trip_id_trip_start")).over(windowspec_1)
            )
            .withColumn(
                "next_trip_start_timestamp",
                F.lead(F.col("timestamp_trip_start")).over(windowspec_1),
            )
            .withColumn(
                "next_trip_start_source_timestamp",
                F.lead(F.col("source_timestamp_trip_start")).over(windowspec_1),
            )
            .withColumn(
                "trip_flag",
                F.when(
                    (F.col("trip_id_trip_end").isNull())
                    & (F.col("next_trip_id").isNull()),
                    "on going",
                )
                .when(
                    (F.col("trip_id_trip_end").isNull())
                    & (F.col("next_trip_id").isNotNull()),
                    "provisional",
                )
                .otherwise("completed"),
            )
            .withColumn(
                "timestamp_trip_end",  # imputing trip end time stamp if trip end is not there
                F.when(
                    (F.col("trip_id_trip_end").isNull())
                    & (F.col("trip_flag") == "on going"),
                    F.when(
                        (
                            F.unix_timestamp(F.lit(ts_end), ts_end_format)
                            - F.unix_timestamp(F.col("timestamp_trip_start"))
                        )
                        > (15 * 60 * 60),  # hours*mins*secs  (15 hours)
                        F.expr(
                            "timestamp_trip_start + INTERVAL 15 HOURS"
                        ),  # if we are running full run or first run giving start time +15 hr as end since need to get 15 hrs tele data for this trip
                    ).otherwise(F.lit(ts_end).cast(TimestampType())),
                )
                .when(
                    (F.col("trip_flag") == "provisional"),
                    F.col("next_trip_start_timestamp"),
                )
                .otherwise(F.col("timestamp_trip_end")),
            )
            .withColumn(
                "source_timestamp_trip_end",  # imputing trip end time stamp if trip end is not there
                F.when(
                    (F.col("trip_id_trip_end").isNull())
                    & (F.col("trip_flag") == "on going"),
                    F.when(
                        (
                            F.unix_timestamp(F.lit(ts_end), ts_end_format)
                            - F.unix_timestamp(F.col("timestamp_trip_start"))
                        )
                        > (15 * 60 * 60),  # hours*mins*secs  (15 hours)
                        F.expr(
                            "source_timestamp_trip_start + (15 * 60 * 60*1000)"
                        ),  # if we are running full run or first run giving start time +15 hr as end since need to get 15 hrs tele data for this trip
                    ).otherwise(
                        (
                            F.unix_timestamp(F.lit(ts_end), ts_end_format)
                            - (5.5 * 60 * 60)
                        )
                        * 1000
                    ),
                )
                .when(
                    (F.col("trip_flag") == "provisional"),
                    F.col("next_trip_start_source_timestamp"),
                )
                .otherwise(F.col("source_timestamp_trip_end")),
            )
        )

        df_trip_start_end = df_trip_start_end.drop(
            "next_trip_id",
            "next_trip_start_timestamp",
            "next_trip_start_source_timestamp",
        )

        logging.info("reading telemetry data started")

        trip_vids = df_trip_start_end.select("vehicle_id_trip_start")

        df_target_tele = read_telemetry(
            ts_start, ts_end, tenantid_in, s3_tele_extract_output_path, trip_vids
        )

        logging.info("reading telemetry data ended")

        w_rownum_desc = Window.partitionBy(
            F.col("vehicle_id_trip_start"), F.col("trip_id_trip_start")
        ).orderBy(F.col("collectioneventtime_ts").desc(), F.col("pos"))

        logging.info("joining telemtry with trips")

        df_trip_tele = df_trip_start_end.join(
            df_target_tele,
            (df_target_tele["vid"] == df_trip_start_end["vehicle_id_trip_start"])
            & (
                df_target_tele["collectioneventtime_ts"]
                >= df_trip_start_end["timestamp_trip_start"]
            )
            & (
                df_target_tele["collectioneventtime_ts"]
                <= df_trip_start_end["timestamp_trip_end"]
            ),
            "inner",
        ).withColumn("row_num", row_number().over(w_rownum_desc))

        logging.info("joining telemtry with trips ended")

        logging.info("df_trip_tele cache started")

        df_trip_tele.cache()

        logging.info("df_trip_tele cache ended")

        # starting to fill null values with last not null across packets of the particular trip

        window_spec_last_not_null = Window.partitionBy(
            F.col("trip_id_trip_start"), F.col("vehicle_id_trip_start")
        ).orderBy(F.col("collectioneventtime"), F.col("pos").desc())

        window_spec_last_not_null_reverse = Window.partitionBy(
            F.col("trip_id_trip_start"), F.col("vehicle_id_trip_start")
        ).orderBy(F.col("collectioneventtime"), F.col("pos").asc())

        telemetry_columns = df_target_tele.columns
        non_telemetry_columns = [
            col for col in df_trip_tele.columns if col not in telemetry_columns
        ]

        # List of elements to move from tele data
        columns_to_move = ["tele_harsh_driving_alert"]
        # Remove from telemetry_columns and add to non_telemetry_columns
        for col in columns_to_move:
            if col in telemetry_columns:
                telemetry_columns.remove(col)
                non_telemetry_columns.append(col)

        logging.info("filling last not null value started")

        df_trip_tele = df_trip_tele.select(
            *non_telemetry_columns,
            *[
                F.coalesce(
                    F.col(col_name),
                    F.last(F.col(col_name), ignorenulls=True).over(window_spec_last_not_null),
                    F.last(F.col(col_name), ignorenulls=True).over(window_spec_last_not_null_reverse)
                ).alias(col_name)
                for col_name in telemetry_columns
            ],
        )
        logging.info("filling last not null value ended")

        # updating telemetry data with trip index data
        column_mappings = [
            ("tele_total_usable_energy", "usable_energy_trip_start", "usable_energy_trip_end"),
            ("tele_odo_vcu", "odometer_reading_trip_start", "odometer_reading_trip_end")
        ]
        df_trip_tele = update_telemetry_with_trip_data(df_trip_tele, column_mappings)

        df_trip_tele = (
            df_trip_tele.withColumn(
                "tele_vehicle_mode_signal",
                F.expr(
                    "CASE WHEN tele_vehicle_mode_signal='0' or tele_vehicle_mode_signal=0 THEN 'eco' \
            WHEN tele_vehicle_mode_signal='1' or tele_vehicle_mode_signal=1 THEN 'ride' \
            WHEN tele_vehicle_mode_signal='2' or tele_vehicle_mode_signal=2 THEN 'sport' \
            WHEN tele_vehicle_mode_signal='3' or tele_vehicle_mode_signal=3 THEN 'park' \
            WHEN tele_vehicle_mode_signal='4' or tele_vehicle_mode_signal=4 THEN '4' \
            WHEN tele_vehicle_mode_signal='5' or tele_vehicle_mode_signal=5 THEN '5' \
            WHEN tele_vehicle_mode_signal='6' or tele_vehicle_mode_signal=6 THEN '6' \
            WHEN tele_vehicle_mode_signal='7' or tele_vehicle_mode_signal=7 THEN '7' \
            WHEN tele_vehicle_mode_signal='8' or tele_vehicle_mode_signal=8 THEN 'segment on' \
            WHEN tele_vehicle_mode_signal='9' or tele_vehicle_mode_signal=9 THEN 'segment off' \
            WHEN tele_vehicle_mode_signal='10' or tele_vehicle_mode_signal=10 THEN 'all blink' \
            WHEN tele_vehicle_mode_signal='11' or tele_vehicle_mode_signal=11 THEN 'custom' \
            WHEN tele_vehicle_mode_signal='12' or tele_vehicle_mode_signal=12 THEN 'safe' \
            WHEN tele_vehicle_mode_signal='13' or tele_vehicle_mode_signal=13 THEN 'boost' \
            WHEN tele_vehicle_mode_signal='14' or tele_vehicle_mode_signal=14 THEN 'speed limit' \
            else 'None' END as tele_vehicle_mode_signal"
                ),
            )
            .withColumn("tele_latitude", F.coalesce(F.col("tele_latitude"), F.lit(0.0)))
            .withColumn(
                "tele_longitude", F.coalesce(F.col("tele_longitude"), F.lit(0.0))
            )
            .withColumn(
                "tele_location",
                F.struct(
                    F.col("tele_latitude").alias("lat"),
                    F.col("tele_longitude").alias("lon"),
                ),
            )
        )

        # endof logic  to fill null values with last not null across packets of the particular trip

        w_agg = Window.partitionBy(
            F.col("trip_id_trip_start"), F.col("vehicle_id_trip_start")
        )

        # Calculating aggregations based on telemetry data
        logging.info("deriving metircs based telemtry data")

        df_trip_tele_agg = (
            df_trip_tele.withColumn(
                "signal_samples", F.count(F.col("tele_cluster_speed")).over(w_agg)
            )
            .withColumn("average_speed", F.avg(F.col("tele_cluster_speed")).over(w_agg))
            .withColumn("max_speed", F.max(F.col("tele_cluster_speed")).over(w_agg))
            .withColumn(
                "average_engine_temperature",
                F.avg("tele_engine_temperture").over(w_agg),
            )
            .withColumn(
                "average_battery_pack_temperature",
                F.avg("tele_battery_pack_temperature").over(w_agg),
            )
            .withColumn(
                "average_bms1_battery_pack_temperature",
                F.avg("tele_bms1_battery_pack_temperature").over(w_agg),
            )
            .withColumn(
                "average_bms2_battery_pack_temperature",
                F.avg("tele_bms2_battery_pack_temperature").over(w_agg),
            )
            .withColumn(
                "harsh_acceleration_points",
                F.collect_list(
                    F.when(
                        F.col("tele_harsh_driving_alert") == 2,
                        F.struct(
                            F.coalesce(F.col("tele_fuel_percentage"), F.lit(0.0)).alias(
                                "fuel_percentage"
                            ),
                            F.coalesce(
                                F.col("tele_fuel_level_volts"), F.lit(0.0)
                            ).alias("fuel_value"),
                            F.coalesce(F.col("tele_gps_fix"), F.lit(0)).alias(
                                "gps_fix"
                            ),
                            F.coalesce(F.col("tele_gps_valid"), F.lit(False)).alias(
                                "gps_valid"
                            ),
                            F.coalesce(F.col("tele_hdop"), F.lit(0.0)).alias("hdop"),
                            F.col("tele_location").alias("location"),
                            F.coalesce(F.col("tele_odo_vcu"), F.lit(0.0)).alias(
                                "odometer"
                            ),
                            F.coalesce(F.col("tele_pdop"), F.lit(0.0)).alias("pdop"),
                            F.coalesce(
                                F.col("tele_soc_user_percentage"), F.lit(0.0)
                            ).alias("soc"),
                            F.coalesce(F.col("collectioneventtime"), F.lit(0)).alias(
                                "timestamp"
                            ),
                            F.coalesce(F.col("tele_vdop"), F.lit(0.0)).alias("vdop"),
                        ),
                    ),
                ).over(w_agg),
            )
            .withColumn(
                "harsh_break_points",
                F.collect_list(
                    F.when(
                        F.col("tele_harsh_driving_alert") == 1,
                        F.struct(
                            F.coalesce(F.col("tele_fuel_percentage"), F.lit(0.0)).alias(
                                "fuel_percentage"
                            ),
                            F.coalesce(
                                F.col("tele_fuel_level_volts"), F.lit(0.0)
                            ).alias("fuel_value"),
                            F.coalesce(F.col("tele_gps_fix"), F.lit(0)).alias(
                                "gps_fix"
                            ),
                            F.coalesce(F.col("tele_gps_valid"), F.lit(False)).alias(
                                "gps_valid"
                            ),
                            F.coalesce(F.col("tele_hdop"), F.lit(0.0)).alias("hdop"),
                            F.col("tele_location").alias("location"),
                            F.coalesce(F.col("tele_odo_vcu"), F.lit(0.0)).alias(
                                "odometer"
                            ),
                            F.coalesce(F.col("tele_pdop"), F.lit(0.0)).alias("pdop"),
                            F.coalesce(
                                F.col("tele_soc_user_percentage"), F.lit(0.0)
                            ).alias("soc"),
                            F.coalesce(F.col("collectioneventtime"), F.lit(0)).alias(
                                "timestamp"
                            ),
                            F.coalesce(F.col("tele_vdop"), F.lit(0.0)).alias("vdop"),
                        ),
                    )
                ).over(w_agg),
            )
        )

        # This is to calculate packet sample count
        df_trip_packets_count = df_trip_tele.groupBy(
            F.col("vehicle_id_trip_start"), F.col("trip_id_trip_start")
        ).agg(F.countDistinct("collectioneventtime").alias("packet_samples"))

        logging.info(
            "calling mode wise calclulation method to calculate mettrics at vehicle mode level"
        )
        mode_wise_df = mode_wise_calculation(df_trip_tele)

        # Filtering the data with latest telemetry data
        df_trip_tele_single_rec = df_trip_tele_agg.filter(F.col("row_num") == 1)

        df_trip_tele_alias = df_trip_tele_single_rec.alias("df_trip_tele_single_rec")
        df_mode_alias = mode_wise_df.alias("mode_wise_df")
        df_trip_packets_count_alias = df_trip_packets_count.alias("packet_samples_df")

        # Joining the trip start_end_lastrowtel data with modewise calculations dataframe to have them in signle dataframe
        df_trip_start_end_final = (
            df_trip_tele_alias.join(
                df_mode_alias,
                on=["vehicle_id_trip_start", "trip_id_trip_start"],
                how="left",
            )
            .join(
                df_trip_packets_count_alias,
                on=["vehicle_id_trip_start", "trip_id_trip_start"],
                how="left",
            )
            .select(
                *df_trip_tele_alias,
                df_mode_alias.mode_wise_wh_consumed,
                df_mode_alias.mode_wise_distance_covered,
                df_mode_alias.mode_wise_wh_consumed_vs_dist,
                df_trip_packets_count_alias.packet_samples,
            )
        )

        # Fill the trip end attributes with telemetry data for ongoing sessions with coalesce

        trip_end_tele_col_map = {
            "vehicle_id_trip_end": "vid",
            "campaign_name_trip_end": "campaign_name",
            "latitude_trip_end": "tele_latitude",
            "longitude_trip_end": "tele_longitude",
            # "timestamp_trip_end": "collectioneventtime_ts",
            "ambient_temperature_trip_end": "tele_ambient_temperature",
            "fuel_value_trip_end": "tele_fuel_level_volts",
            "fuel_percentage_trip_end": "tele_fuel_percentage",
            "odometer_reading_trip_end": "tele_odo_vcu",
            "soc_trip_end": "tele_soc_user_percentage",
            "usable_energy_trip_end": "tele_total_usable_energy",
            "battery_pack_temp_trip_end": "tele_battery_pack_temperature",
            # "bms1_battery_pack_temperature_trip_end": "tele_bms1_battery_pack_temperature",
            "vehicle_mode_trip_end": "tele_vehicle_mode_signal",
            "gps_fix_trip_end": "tele_gps_fix",
            "gps_valid_trip_end": "tele_gps_valid",
            "remaining_range_trip_end": "tele_remaining_range_in_km",
            "hdop_trip_end": "tele_hdop",
            "vdop_trip_end": "tele_vdop",
            "pdop_trip_end": "tele_pdop",
        }

        zero_or_minusone = [
            "fuel_value_trip_end",
            "ambient_temperature_trip_end",
            "fuel_percentage_trip_end",
            "odometer_reading_trip_end",
            "soc_trip_end",
            "usable_energy_trip_end",
            "battery_pack_temp_trip_end",
            "remaining_range_trip_end",
        ]

        # Select columns while handling nulls, zeros, and -1
        df_trip_end_fill_from_tele = df_trip_start_end_final.select(
            *[
                (
                    F.when(
                        (F.col(col).isNull()) | (F.col(col) == 0) | (F.col(col) == -1),
                        F.col(
                            trip_end_tele_col_map.get(col, col)
                        ),  # Take from the mapped column if null, 0, or -1
                    )
                    .otherwise(F.col(col))  # Otherwise, keep the original value
                    .alias(col)
                    if col in zero_or_minusone
                    else F.coalesce(
                        F.col(col), F.col(trip_end_tele_col_map.get(col, col))
                    ).alias(col)
                )
                for col in df_trip_start_end_final.columns
                if col
                not in trip_end_tele_col_map.values()  # Exclude fallback columns from select
            ]
        )

        # df_trip_end_fill_from_tele = fill_na_with_default(df_trip_end_fill_from_tele)

        # Calculate the trips stats metrics based on trips start and end values only

        df_trip_end_fill_from_tele = (
            df_trip_end_fill_from_tele.withColumn(
                "latitude_trip_start",
                F.expr(
                    "CASE WHEN abs(latitude_trip_start) > 90 THEN 0.0 \
        else latitude_trip_start END as latitude_trip_start"
                ),
            )
            .withColumn(
                "longitude_trip_start",
                F.expr(
                    "CASE WHEN abs(longitude_trip_start) > 180 THEN 0.0 \
        else longitude_trip_start END as longitude_trip_start"
                ),
            )
            .withColumn(
                "latitude_trip_end",
                F.expr(
                    "CASE WHEN abs(latitude_trip_end) > 90 THEN 0.0 \
        else latitude_trip_end END as latitude_trip_end"
                ),
            )
            .withColumn(
                "longitude_trip_end",
                F.expr(
                    "CASE WHEN abs(longitude_trip_end) > 90 THEN 0.0 \
        else longitude_trip_end END as longitude_trip_end"
                ),
            )
            .withColumn(
                "timestamp_trip_end",
                F.when(
                    (F.col("trip_flag") == "on going")
                    | (F.col("timestamp_trip_end").isNull())
                    | (F.col("trip_flag") == "provisional"),
                    F.col("collectioneventtime_ts"),
                ).otherwise(F.col("timestamp_trip_end")),
            )
            .withColumn(
                "source_timestamp_trip_end",
                F.when(
                    (F.col("trip_flag") == "on going")
                    | (F.col("source_timestamp_trip_end").isNull())
                    | (F.col("trip_flag") == "provisional"),
                    F.col("collectioneventtime"),
                ).otherwise(F.col("source_timestamp_trip_end")),
            )
        )

        # List of expected modes
        expected_modes = ["eco", "ride", "sport", "custom"]

        default_modes_map = F.create_map(
            [
                kv
                for mode in expected_modes
                for kv in [F.lit(mode), F.lit(None).cast(DoubleType())]
            ]
        )

        # Seriving metric based on trip start and end values

        df_trip_stats_final = df_trip_end_fill_from_tele.select(
            F.coalesce(
                (
                    F.col("odometer_reading_trip_end")
                    - F.col("odometer_reading_trip_start")
                ),
                F.lit(0.0),
            ).alias("total_distance_covered"),
            F.coalesce(
                (
                    F.unix_timestamp("timestamp_trip_end")
                    - F.unix_timestamp("timestamp_trip_start")
                ),
                F.lit(0),
            ).alias("total_trip_time_seconds"),
            F.coalesce(
                (F.col("usable_energy_trip_start") - F.col("usable_energy_trip_end")),
                F.lit(0.0),
            ).alias("wh_consumed"),
            F.coalesce(
                (
                    (
                        F.col("usable_energy_trip_start")
                        - F.col("usable_energy_trip_end")
                    )
                    / (
                        F.col("odometer_reading_trip_end")
                        - F.col("odometer_reading_trip_start")
                    )
                ),
                F.lit(0.0),
            ).alias("wh_consumed_vs_dist"),
            F.coalesce(
                (F.col("soc_trip_start") - F.col("soc_trip_end")), F.lit(0.0)
            ).alias("soc_consumed"),
            F.coalesce(
                (F.col("fuel_value_trip_start") - F.col("fuel_value_trip_end")),
                F.lit(0.0),
            ).alias("fuel_consumed"),
            F.coalesce(
                (
                    F.col("fuel_percentage_trip_start")
                    - F.col("fuel_percentage_trip_end")
                ),
                F.lit(0.0),
            ).alias("fuel_percentage"),
            F.coalesce(
                F.struct(
                    F.col("latitude_trip_start").alias("lat"),
                    F.col("longitude_trip_start").alias("lon"),
                ),
                location_default,
            ).alias("trip_start_location"),
            F.coalesce(
                F.struct(
                    F.col("latitude_trip_end").alias("lat"),
                    F.col("longitude_trip_end").alias("lon"),
                ),
                location_default,
            ).alias("trip_end_location"),
            F.concat(
                F.col("vehicle_id_trip_start"),
                F.col("trip_id_trip_start"),
            ).alias("id"),
            *df_trip_end_fill_from_tele.columns,
        )

        df_trip_stats_final = (
            df_trip_stats_final.withColumnRenamed(
                "timestamp_trip_end", "trip_end_timestamp"
            )
            .withColumnRenamed("timestamp_trip_start", "trip_start_timestamp")
            .withColumnRenamed("trip_id_trip_start", "trip_id")
            .withColumnRenamed("vehicle_id_trip_start", "vid")
            .withColumnRenamed("tenant_id_trip_start", "tenant_id")
            .withColumnRenamed("campaign_name_trip_start", "campaign_name")
            .withColumn(
                "trip_flag",
                F.when(
                    (F.col("trip_flag") == "on going")
                    & (
                        (
                            F.unix_timestamp(F.lit(ts_end), ts_end_format)
                            - F.unix_timestamp(F.col("trip_start_timestamp"))
                        )
                        >= (15 * 60 * 60)
                    ),  # hours*mins*secs  (15 hours)
                    F.lit("provisional"),
                ).otherwise(F.col("trip_flag")),
            )
            .withColumn(
                "trip_accuracy",
                (
                    (F.col("packet_samples"))
                    / (
                        (
                            (
                                (
                                    (F.unix_timestamp("trip_end_timestamp") + 10) / 10
                                ).cast("long")
                            )
                            * 10
                            - (
                                (F.unix_timestamp("trip_start_timestamp") / 10).cast(
                                    "long"
                                )
                            )
                            * 10
                        )
                        / 10
                    )  # here 10 sec is polling frequency
                )
                * 100,
            )
            .withColumn(
                "trip_accuracy",
                F.when(F.col("trip_accuracy") > 100, F.lit(100)).otherwise(
                    F.col("trip_accuracy")
                ),
            )
            .withColumn(
                "mode_wise_wh_consumed",
                F.map_zip_with(
                    F.col("mode_wise_wh_consumed"),
                    default_modes_map,
                    lambda k, x, y: F.coalesce(
                        x, y
                    ),  # Use coalesce to handle missing values
                ),
            )
            .withColumn(
                "mode_wise_distance_covered",
                F.map_zip_with(
                    F.col("mode_wise_distance_covered"),
                    default_modes_map,
                    lambda k, x, y: F.coalesce(
                        x, y
                    ),  # Use coalesce to handle missing values
                ),
            )
            .withColumn(
                "mode_wise_wh_consumed_vs_dist",
                F.map_zip_with(
                    F.col("mode_wise_wh_consumed_vs_dist"),
                    default_modes_map,
                    lambda k, x, y: F.coalesce(
                        x, y
                    ),  # Use coalesce to handle missing values
                ),
            )
        )

        # These are not needed since these are same column froms trip end and trip break transformation

        dropping_not_needed_cols = [
            "vehicle_id_trip_end",
            "vehicle_id_trip_break",
            "tenant_id_trip_break",
            "trip_id_trip_break",
            "row_num",
            "tenant_id_trip_end",
            "trip_id_trip_end",
            "trip_id_trip_break",
            "collectioneventtime_ts",
            "tele_harsh_driving_alert",
            "tele_gps_valid",
            "tele_gps_fix",
            "tele_engine_temperture",
            "tele_location",
            "user_profile_trip_end",
            "user_id_trip_end",
            "user_name_trip_end",
            "tele_bms1_battery_pack_temperature",
            "tele_bms2_battery_pack_temperature",
            "tele_remaining_range_in_km",
            "tele_cluster_speed",
            "campaign_name_trip_end",
            "pos",
            "polling_time",
        ]

        df_trip_stats_final = df_trip_stats_final.drop(*dropping_not_needed_cols)

        # Converting timestamp to stting backs since need to retain the human readable foramt

        df_trip_stats_final = df_trip_stats_final.withColumn(
            "trip_end_timestamp",
            F.date_format(F.col("trip_end_timestamp"), "yyyy-MM-dd'T'HH:mm:ss.SSS"),
        ).withColumn(
            "trip_start_timestamp",
            F.date_format(F.col("trip_start_timestamp"), "yyyy-MM-dd'T'HH:mm:ss.SSS"),
        )

        # Incremental logic

        df_trip_stats_final_fill_na = fill_na_with_default(df_trip_stats_final)

        df_trip_stats_final = (
            df_trip_stats_final_fill_na.withColumn(
                "harsh_acceleration_points",
                F.coalesce(F.col("harsh_acceleration_points"), default_hahb),
            )
            .withColumn(
                "harsh_break_points",
                F.coalesce(F.col("harsh_break_points"), default_hahb),
            )
            .withColumn(
                "location_trip_break",
                F.coalesce(F.col("location_trip_break"), default_hahb),
            )
            .withColumn(
                "mode_wise_wh_consumed",
                F.coalesce(F.col("mode_wise_wh_consumed"), default_modes_map),
            )
            .withColumn(
                "mode_wise_distance_covered",
                F.coalesce(F.col("mode_wise_distance_covered"), default_modes_map),
            )
            .withColumn(
                "mode_wise_wh_consumed_vs_dist",
                F.coalesce(F.col("mode_wise_wh_consumed_vs_dist"), default_modes_map),
            )
            .withColumn(
                "b2bclientid",
                F.coalesce(F.col("b2bclientid"), F.lit(None)),
            )
        )

        df_trip_stats_final = (
            df_trip_stats_final
            .withColumn("b2bclientid", F.col("b2b_client_id_trip_start"))
            .drop("b2b_client_id_trip_start", "b2b_client_id_trip_end")
        )

        df_trip_stats_final.printSchema()

        # ##write to OS

        logging.info("caching started")

        df_trip_stats_final.cache()

        logging.info("caching ended")

        logging.info("converting to dynamicframe started")

        df_trip_stats_final_dynamic = DynamicFrame.fromDF(
            df_trip_stats_final, glueContext, "convert"
        )

        logging.info("converting to dynamicframe ended")

        logging.info("loading to opensearch started")

        glueContext.write_dynamic_frame.from_options(
            frame=df_trip_stats_final_dynamic,
            connection_type="opensearch",
            connection_options={
                "connectionName": os_connector_name,
                "opensearch.resource": os_trip_stat_index,
                "opensearch.write.operation": "upsert",
                "opensearch.mapping.id": "id",
            },
        )

        # updating is_deleted fag to true for trips there trips stats but merged late

        df_merged_deleted_update_dynamic = DynamicFrame.fromDF(
            merged_trip_flattened, glueContext, "convert"
        )

        try:
            glueContext.write_dynamic_frame.from_options(
                frame=df_merged_deleted_update_dynamic,
                connection_type="opensearch",
                connection_options={
                    "connectionName": os_connector_name,
                    "opensearch.resource": os_trip_stat_index,
                    "opensearch.write.operation": "update",
                    "opensearch.mapping.id": "id",
                },
            )
        except Exception as e:
            logging.error("erros happened since updating not exist documents")

        logging.info("loading to opensearch ended")

        # writing merged trips to gif generatror topic

        write_to_kafka(merged_trips, kafka_broker, topic)

        # Writing to s3

        logging.info("loading to s3 started")

        write_to_s3(
            df_trip_stats_final,
            table_name,
            database,
            s3_output_path,
            s3_output_partition_path,
            partition_col_variable,
        )

        logging.info("loading to s3 ended")

        df_trip_tele.unpersist()
        df_trip_stats_final.unpersist()

        store_parameter(param_store_variable, ts_end)

    except Exception as exp:

        logging.error("An error occurred in extract for tenant: %s", str(exp))
        traceback.print_exc()

        raise


# # Merging logic ended here

if __name__ == "__main__":

    try:

        logging.info("Job started")
        start_time = datetime.now()

        logging.info("job_name=%s", args.get("JOB_NAME"))
        logging.info("Calling log audit to log the status is job started")

        source_name = (
            os_trip_start_index + "-" + os_trip_end_index + "-" + os_trip_end_index
        )
        target = table_name + "-" + os_trip_stat_index

        log_audit(
            spark,
            args["JOB_NAME"],
            source_name,
            source_type,
            target,
            target_type,
            "Started",
            start_time,
            None,
            None,
            audit_path,
            audit_table,
        )

        for tenant in tenants_list:
            TENANT_LOWER = tenant.lower()
            TENANT_UPPER = tenant.upper()

            os_trip_start_index_tenant = (
                os_trip_start_index + "-" + TENANT_LOWER + "-stream"
            )
            os_trip_end_index_tenant = (
                os_trip_end_index + "-" + TENANT_LOWER + "-stream"
            )
            os_trip_break_index_tenant = (
                os_trip_break_index + "-" + TENANT_LOWER + "-stream"
            )
            os_trip_stat_index_tenant = (
                os_trip_stat_index + "-" + TENANT_LOWER + "-stream-000001"
            )
            os_telemetry_index_tenant = (
                os_telemetry_index + "-" + TENANT_LOWER + "-stream"
            )

            logging.info("Processing started  for tenant:%s", TENANT_UPPER)

            extract(
                os_trip_start_index_tenant,
                os_trip_end_index_tenant,
                os_trip_break_index_tenant,
                os_trip_stat_index_tenant,
                TENANT_UPPER,
                os_telemetry_index_tenant,
            )

            logging.info("Processing ended for tenant:%s", TENANT_UPPER)

        end_time = datetime.now()
        duration = (end_time - start_time).seconds
        logging.info("Calling log_audit to log the status as completed")

        log_audit(
            spark,
            args["JOB_NAME"],
            source_name,
            source_type,
            target,
            target_type,
            "Completed",
            start_time,
            end_time,
            count_accum.value,
            audit_path,
            audit_table,
        )

        logging.info("job completed")
    except Exception as e:

        logging.error("An error occurred: %s", str(e))
        traceback.print_exc()
        end_time = datetime.now()
        duration = (end_time - start_time).seconds

        cloudwatch_url = get_cloudwatch_url(region_name, job_name, job_run_id)
        ERROR_CODE = getattr(
            e, "code", "N/A"
        )  # Some exceptions might have a 'code' attribute
        if ERROR_CODE == "N/A":
            # Try to parse error code from the exception message if it's in a known format
            ERROR_CODE = "Specific logic to parse error code from the exception message if possible"

        log = {
            "status": "failure",
            "job_name": job_name,
            "source_table": source_name,
            "target_table": target,
            "start_time": start_time.isoformat(),
            "end_time": end_time.isoformat(),
            "duration": duration,
            "error_code": ERROR_CODE,
            "error": f"Error: {str(e)}\nTraceback: {traceback.format_exc()}",
        }

        logging.info("Calling log_audit to log the status Failed")
        log_audit(
            spark,
            args["JOB_NAME"],
            source_name,
            source_type,
            target,
            target_type,
            "Failed",
            start_time,
            end_time,
            None,
            audit_path,
            audit_table,
        )

        log_message = "\n".join([f"{key}: {value}" for key, value in log.items()])

        message = f"Job {job_name} failed. Error: {str(e)}\nTraceback: {traceback.format_exc()}\
              \n\n{log_message}.\n\nView the logs in CloudWatch:{cloudwatch_url}"

        sns_message_size = len(message.encode("utf-8"))
        logging.info("message body size in KB:%s", sns_message_size / 1024)
        if sns_message_size >= 256 * 1024:
            logging.info("messages size is greater than 256KB so truncating it")
            message = message[
                :250000
            ]  # 250 KB to ensure we stay within the 256 KB limit

        subject = f"{job_name} failed for {target} table"
        if len(subject) > 100:
            subject = subject[:98] + ".."  # Truncate if needed

        # send_sns_notification(subject, message, sns_secret_name, region_name)

        raise
