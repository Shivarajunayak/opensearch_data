"""
AWS Glue Job: landing layer to raw layer Data Pipeline

This AWS Glue job reads data from an landing glue table and 
writes the data to an raw layer Hudi table in Amazon S3 bucket.
The job leverages AWS Glue's ETL capabilities to transform 
and store the data in a specified S3 location.

Usage:
    - Ensure the IAM role for the Glue job has necessary permissions 
    to read from landing hudi table and write to raw layer hudi table.
"""

# pylint: disable=import-error
import sys
import logging
import json
from datetime import datetime
from string import Template
import traceback
import yaml
import boto3

# from awsglue.transforms import *
from awsglue.utils import getResolvedOptions
from awsglue.context import GlueContext
from awsglue.job import Job
from pyspark.sql import SparkSession
from pyspark.sql import functions as F
from pyspark.sql.types import MapType
from hmcl_cv_common_utilities import (
    log_audit,
    get_cloudwatch_url,
    send_sns_notification,
    validate_audit_table_with_s3_partition,
)

logging.basicConfig(
    level=logging.INFO, format="%(asctime)s - %(name)s - %(levelname)s - %(message)s"
)


def store_parameter(name, value, param_type="String", overwrite=True):
    """
    Store a parameter in AWS Systems Manager Parameter Store.

    :param name: The name of the parameter (e.g., '/myapp/prod/db_password').
    :param value: The value to store (string).
    :param param_type: Type of the parameter ('String', 'StringList', or 'SecureString').
    :param overwrite: Whether to overwrite an existing parameter.
    :return: The response from the SSM API.
    """
    ssm = boto3.client("ssm")

    try:
        response = ssm.put_parameter(
            Name=name, Value=value, Type=param_type, Overwrite=overwrite
        )
        return response
    except Exception as e:
        logging.error("Error in storing parameter : %s", e)
        traceback.print_exc()
        raise


def retrieve_parameter(name, with_decryption=True):
    """
    Retrieve a parameter from AWS Systems Manager Parameter Store.

    :param name: The name of the parameter (e.g., '/myapp/prod/db_password').
    :param with_decryption: Whether to decrypt the parameter if it is of type 'SecureString'.
    :return: The parameter value, or None if not found.
    """
    ssm = boto3.client("ssm")

    try:
        response = ssm.get_parameter(Name=name, WithDecryption=with_decryption)
        return response["Parameter"]["Value"]
    except Exception as e:
        logging.error("Error in getting parameter from paramter store  : %s", e)
        traceback.print_exc()
        return 19700101


def substitute_variables(config, args):
    """
    This method to substtute env specific variables where ever referenced
    """
    try:
        config_str = yaml.dump(config)  # Convert config back to a string
        template = Template(config_str)
        return yaml.safe_load(template.substitute(args))
    except Exception as e:
        logging.error("Error in substituting variables : %s", e)
        traceback.print_exc()
        raise


def load_yaml_config(yaml_s3_bucket, yaml_file_key, source_table_name):
    """
    Load and parse YAML configuration from S3.
    """
    try:
        s3_client = boto3.client("s3", region_name="ap-south-1")
        s3_object = s3_client.get_object(Bucket=yaml_s3_bucket, Key=yaml_file_key)
        yaml_content = s3_object["Body"].read().decode("utf-8")
        yaml_dict = yaml.safe_load(yaml_content)
        logging.info("YAML configuration loaded successfully.")
        return yaml_dict["tables"][source_table_name]
    except Exception as e:
        logging.error("Error loading YAML configuration from S3: %s", e)
        traceback.print_exc()
        raise


def read_single_table(spark, source_path, latest_commit_time):
    """
    This method to read the data from source table incrementally
    """
    try:
        source_df = (
            spark.read.format("hudi")
            .option("hoodie.datasource.query.type", "incremental")
            .option("hoodie.datasource.read.begin.instanttime", latest_commit_time)
            .load(source_path)
        )
        return source_df
    except Exception as e:
        logging.error("Error in sourcing single table: %s", e)
        traceback.print_exc()
        raise


def read_two_tables(spark, source_path, reference_source_path):
    """
    This method to jojn the source table with referecne table
    for missing columns in the source table
    """
    try:
        source_df = (
            spark.read.format("hudi")
            # .option("hoodie.datasource.query.type", "incremental")
            # .option("hoodie.datasource.read.begin.instanttime", latest_commit_time)
            .load(source_path)
        )

        reference_df = (
            spark.read.format("hudi")
            # .option("hoodie.datasource.query.type", "incremental")
            # .option("hoodie.datasource.read.begin.instanttime", latest_commit_time)
            .load(reference_source_path)
        )

        reference_df = reference_df.select("tcu_id", "tenant_id")

        joined_df = source_df.join(
            reference_df,
            source_df["tcu_id"] == reference_df["tcu_id"],
            "left_outer",
        ).select(source_df["*"], reference_df["tenant_id"])

        return joined_df
    except Exception as e:
        logging.error("Error in reading from two source tables: %s", e)
        traceback.print_exc()
        raise


def flatten_dataframe(df_to_flatten):
    """
    This method is to identify the struct type columns
    and flatten nested level data to least level
    """
    try:
        types = [
            item
            for item in df_to_flatten.dtypes
            if item[1].startswith("struct") or item[1].startswith("map")
        ]
        # while types:
        me_cols = []
        se_cols = []
        drop_cols = []
        for s_col, typ in types:

            if typ.startswith("struct"):
                s_col_keys = df_to_flatten.select(s_col + ".*").columns
                se_cols += [
                    F.col(s_col + "." + c).alias(s_col + "_" + c) for c in s_col_keys
                ]

            elif typ.startswith("map"):
                sample_map = df_to_flatten.select(s_col).head()[0]
                # me_cols +=[F.col(f"{s_col}.{key}").\
                # alias(f"{s_col}_{key}") for key in sample_map.keys()]
                me_cols += [
                    F.col(s_col + "." + key).alias(s_col + "_" + key)
                    for key in sample_map.keys()
                ]

            drop_cols.append(s_col)

        all_cols = df_to_flatten.select("*").columns
        all_cols_exploded = all_cols + se_cols + me_cols
        df_to_flatten = df_to_flatten.select(*all_cols_exploded)
        df_to_flatten = df_to_flatten.drop(*drop_cols)

        # types = [item for item in df_to_flatten.dtypes if item[1].startswith("struct")]
        return df_to_flatten
    except Exception as e:
        logging.error("Error in flattening dataframe: %s", e)
        traceback.print_exc()
        raise


def get_evaluated_schema(
    spark, flattened_df, target_path, target_database, target_table_name
):
    """
    If columns deleted in source then imputing None to target
    If columns added in source then appending columns to end of the schema
    """
    try:
        if spark._jsparkSession.catalog().tableExists(
            target_database, target_table_name
        ):
            ## load the target hudi table to fetch the schema
            df_target = spark.read.format("hudi").load(target_path).limit(1)
            ## fetch the target column name and datatype. Mainly
            # to default the column as None if not present in source and
            # use the same data type as target.
            for field in df_target.schema.fields:
                if field.name not in flattened_df.columns:
                    flattened_df = flattened_df.withColumn(
                        field.name, F.lit(None).cast(field.dataType)
                    )
            ## export the column names of the target as list
            column_list_target = df_target.columns
            ##Validate if the column in source exists in target,
            # if not add it to target list of column names.
            for col_name in flattened_df.columns:
                if col_name not in column_list_target:
                    column_list_target.append(col_name)
            ## enforce schema order by using the previously selected column list
            # from the modified source dataframe. Where the columns not present in
            # source will be defaulted as None
            flattened_df = flattened_df.select(column_list_target)
        return flattened_df
    except Exception as e:
        logging.error("Error in evaulating the schema: %s", e)
        traceback.print_exc()
        raise


def main():
    """
    Main method
    """
    try:
        logging.info("Job started")

        start_time = datetime.now()

        spark = (
            SparkSession.builder.config(
                "spark.serializer", "org.apache.spark.serializer.KryoSerializer"
            )
            .config("spark.hudi.query.metadata.enable", "true")
            .getOrCreate()
        )

        arguments = ["JOB_NAME", "yaml_s3_bucket", "yaml_file_key", "source_table_name"]

        optional_arguments = []
        for argument in optional_arguments:
            if not f"--{argument}" in sys.argv:
                arguments.remove(argument)

        ## @params: [JOB_NAME]
        args = getResolvedOptions(sys.argv, arguments)
        logging.info("job_name=%s", args.get("JOB_NAME"))

        job_name = args.get("JOB_NAME")
        job_run_id = args.get("JOB_RUN_ID")

        yaml_s3_bucket = args.get("yaml_s3_bucket")
        yaml_file_key = args.get("yaml_file_key")
        source_table_name = args.get("source_table_name")

        # Load configurations
        try:
            job_args = load_yaml_config(
                yaml_s3_bucket, yaml_file_key, source_table_name
            )

            global_args = load_yaml_config(yaml_s3_bucket, yaml_file_key, "global")

            all_args = {**job_args, **global_args}

            env_specific_args = load_yaml_config(
                yaml_s3_bucket, yaml_file_key, "env_specific"
            )

            all_args = substitute_variables(all_args, env_specific_args)

            # secret_dict = fetch_postgres_credentials(rds_secret_name)
            logging.info("Configurations loaded successfully.")
        except Exception as e:
            logging.error("Error loading configurations or credentials: %s", e)
            traceback.print_exc()
            raise

        target_bucket_name = all_args.get("target_bucket_name")
        target_table_name = all_args.get("target_table_name")
        target_database = all_args.get("target_database")
        recordkey = all_args.get("recordkey")
        precombine_field = all_args.get("precombine_field")
        partition_field = all_args.get("partition_field")
        source_bucket_name = all_args.get("source_bucket_name")
        folder_prefix = all_args.get("folder_prefix")
        # source_db_name = args.get("source_db_name")
        source_table_name = all_args.get("source_table_name")
        date_interval = all_args.get("date_interval", 0)
        use_case_name = all_args.get("use_case_name")
        source_type = all_args.get("source_type")
        target_type = all_args.get("target_type")
        audit_path = all_args.get("audit_path")
        audit_table = all_args.get("audit_table")
        reference_use_case_name = all_args.get("reference_use_case_name")
        table_type = all_args.get("table_type", "independend")
        audit_database = all_args.get("audit_database")
        sns_secret_name = all_args.get("sns_secret_name")
        region_name = all_args.get("region_name")

        year_partitioned=start_time.year
        month_partitioned=start_time.month
        
        # Validate the audit table to process the job based on job_status
        is_validate = validate_audit_table_with_s3_partition(spark,sns_secret_name,start_time,audit_path,audit_table,source_table_name,target_table_name,job_name,region_name,year_partitioned,month_partitioned)

        if is_validate == False:
            return

        logging.info("Calling the log_audit to log the status as job started")

        log_audit(
            spark,
            args["JOB_NAME"],
            source_table_name,
            source_type,
            target_table_name,
            target_type,
            "Started",
            start_time,
            None,
            None,
            audit_path,
            audit_table,
        )

        cloudwatch_url = get_cloudwatch_url(region_name, job_name, job_run_id)

        source_path = (
            "s3://"
            + source_bucket_name
            + "/"
            + folder_prefix
            + "_"
            + use_case_name
            + "/"
        )

        if table_type == "join":
            reference_source_path = (
                "s3://"
                + source_bucket_name
                + "/"
                + folder_prefix
                + "_"
                + reference_use_case_name
                + "/"
            )

        target_path = (
            "s3://"
            + target_bucket_name
            + "/"
            + folder_prefix
            + "_"
            + use_case_name
            + "/"
        )

        if table_type == "join":
            logging.info(
                "Reading data from landing table path:%s and reference path %s",
                source_path,
                reference_source_path,
            )
            source_df = read_two_tables(spark, source_path, reference_source_path)
        else:
            logging.info("Reading data from landing table path: %s", source_path)
            latest_commit_time = int(
                retrieve_parameter(target_table_name + "_srctime", with_decryption=True)
            ) - int(date_interval)
            logging.info(
                "latest commit time to read the delta data: %s", latest_commit_time
            )

            source_df = read_single_table(spark, source_path, latest_commit_time)

        source_df = source_df.filter(F.col(precombine_field).isNotNull())

        # Adding landing table commit time to raw table
        source_df = source_df.withColumn(
            "_hoodie_commit_time_land_cal", F.substring("_hoodie_commit_time", 1, 10)
        )

        if len(source_df.select(F.lit(1)).head(1)) == 0:
            logging.info("No new data in source so exiting the process")
            return

        flattened_df = flatten_dataframe(source_df)

        df_evaulated = get_evaluated_schema(
            spark, flattened_df, target_path, target_database, target_table_name
        )

        hudi_options = {
            "hoodie.table.name": target_table_name,
            "hoodie.datasource.write.storage.type": "COPY_ON_WRITE",
            "hoodie.datasource.write.recordkey.field": recordkey,
            "hoodie.datasource.write.operation": "upsert",
            "hoodie.datasource.write.precombine.field": precombine_field,
            "hoodie.datasource.write.partitionpath.field": partition_field,
            "hoodie.datasource.hive_sync.enable": "true",
            "hoodie.datasource.hive_sync.database": target_database,
            "hoodie.datasource.hive_sync.table": target_table_name,
            "hoodie.datasource.hive_sync.use_jdbc": "false",
            "hoodie.datasource.hive_sync.mode": "hms",
            "hoodie.datasource.hive_sync.sync_as_datasource": "false",
            "hoodie.datasource.hive_sync.support_timestamp": "true",
            "hoodie.datasource.hive_sync.partition_fields": partition_field,
            "path": target_path,
            "hoodie.parquet.max.file.size": "134217728",
        }

        # Write the audit log to Hudi
        logging.info(
            "Loading data to table : %s to this path : %s",
            target_table_name,
            target_path,
        )
        df_evaulated.write.format("org.apache.hudi").options(**hudi_options).mode(
            "append"
        ).save()

        latest_commit_time_val = df_evaulated.agg(
            {"_hoodie_commit_time_land_cal": "max"}
        ).collect()[0][0]
        latest_commit_time_put = str(latest_commit_time_val)

        logging.info(
            "Storing param value: %s to this paramter: %s",
            latest_commit_time_put,
            target_table_name + "_srctime",
        )

        store_parameter(
            target_table_name + "_srctime",
            latest_commit_time_put,
            param_type="String",
            overwrite=True,
        )

        end_time = datetime.now()
        duration = (end_time - start_time).seconds
        records_processed = df_evaulated.count()

        logging.info("records processed : %s", records_processed)

        logging.info("Calling log_audit to log the status as completed")

        log_audit(
            spark,
            args["JOB_NAME"],
            source_table_name,
            source_type,
            target_table_name,
            target_type,
            "Completed",
            start_time,
            end_time,
            records_processed,
            audit_path,
            audit_table,
        )

        logging.info("Job Completed successfully")

    except Exception as e:
        logging.error("An error occurred: %s", str(e))

        end_time = datetime.now()
        duration = (end_time - start_time).seconds
        traceback.print_exc()

        cloudwatch_url = get_cloudwatch_url(region_name, job_name, job_run_id)
        error_code = getattr(
            e, "code", "N/A"
        )  # Some exceptions might have a 'code' attribute
        if error_code == "N/A":
            # Try to parse error code from the exception message if it's in a known format
            error_code = "Specific logic to parse error code from the exception message if possible"

        log = {
            "status": "failure",
            "job_name": job_name,
            "source_table": source_table_name,
            "target_table": target_table_name,
            "start_time": start_time.isoformat(),
            "end_time": end_time.isoformat(),
            "duration": duration,
            "error_code": error_code,
            "error": f"Error: {str(e)}\nTraceback: {traceback.format_exc()}",
        }
        logging.info("Calling log_audit to log the status Failed")

        log_audit(
            spark,
            args["JOB_NAME"],
            source_table_name,
            source_type,
            target_table_name,
            target_type,
            "Failed",
            start_time,
            end_time,
            None,
            audit_path,
            audit_table,
        )

        log_message = "\n".join([f"{key}: {value}" for key, value in log.items()])

        message = f"Job {job_name} failed. Error: {str(e)}\nTraceback: {traceback.format_exc()}\
              \n\n{log_message}.\n\nView the logs in CloudWatch:{cloudwatch_url}"

        subject = f"{job_name} failed for {target_table_name} table"
        if len(subject) > 100:
            subject = subject[:98] + ".."  # Truncate if needed

        send_sns_notification(subject, message, sns_secret_name, region_name)
        logging.error(f"Error: {str(e)}\nTraceback: {traceback.format_exc()}")

        raise


if __name__ == "__main__":
    main()
