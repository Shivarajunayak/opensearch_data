"""
This code loads the data from landing to Raw S3 layer
"""

# pylint: disable=import-error
import sys
import logging
import traceback
import boto3
from pyspark.sql import SparkSession, functions as F
from awsglue.utils import getResolvedOptions
from datetime import datetime
from hmcl_cv_common_utilities import (
    log_audit,
    get_cloudwatch_url,
    send_sns_notification,
    validate_audit_table,
)

# Create a Spark session and Glue context
spark = (
    SparkSession.builder.config(
        "spark.serializer", "org.apache.spark.serializer.KryoSerializer"
    )
    .config("spark.hudi.query.metadata.enable", "true")
    .getOrCreate()
)

# Define an accumulator
count_accum = spark.sparkContext.accumulator(0)

## select the job parameters
args = getResolvedOptions(
    sys.argv,
    [
        "JOB_NAME",
        "kafka_topic",
        "brokers",
        "offset",
        "landing_bucket",
        "table_prefix",
        "table_append",
        "database",
        "timestamp_column",
        "VID_col",
        "tenantID_col",
        "raw_bucket",
        "date_interval",
        "use_case_name",
        "source_type",
        "target_type",
        "audit_path",
        "audit_table",
        "latest_commit_time_var",
        "sns_secret_name",
    ],
)

job_name = args.get("JOB_NAME")
job_run_id = args.get("JOB_RUN_ID")
kafka_topic = args.get("kafka_topic")
brokers = args.get("brokers")
offset = args.get("offset")
landing_bucket = args.get("landing_bucket")
table_prefix = args.get("table_prefix")
table_append = args.get("table_append")
database = args.get("database")
timestamp_column = args.get("timestamp_column")
VID_col = args.get("VID_col")
tenantID_col = args.get("tenantID_col")
raw_bucket = args.get("raw_bucket")
date_interval = args.get("date_interval")
use_case_name = args.get("use_case_name")
source_type = args.get("source_type")
target_type = args.get("target_type")
audit_path = args.get("audit_path")
audit_table = args.get("audit_table")
latest_commit_time_var = args.get(
    "latest_commit_time_var", "tele_land_latest_commit_time"
)
sns_secret_name = args.get("sns_secret_name")

logging.basicConfig(
    level=logging.INFO, format="%(asctime)s - %(name)s - %(levelname)s - %(message)s"
)

## landing hudi table path
table_append = "-" + use_case_name + "-" + table_append
hudi_table_path = "s3://" + landing_bucket + "/" + table_prefix + table_append + "/"
source_table_name_cal = table_prefix + "_landing" + "_" + kafka_topic + table_append
source_table_name = source_table_name_cal.lower().replace("-", "_")

##remove value after append post testing
table_name_cal = table_prefix + "_" + "raw_" + kafka_topic + table_append
table_name = table_name_cal.lower().replace("-", "_")
s3_output_path = "s3://" + raw_bucket + "/" + table_prefix + table_append + "/"

logging.info("job started")
start_time = datetime.now()
logging.info("job_name=%s", args.get("JOB_NAME"))

""" 
Function to count elements and update accumulator
"""


def count_elements(row):
    global count_accum
    count_accum.add(1)


def func_rename_col(dataframe_ip):
    """
    This function replaces the . with _
    """
    try:
        new_columns = [col.replace(".", "_") for col in dataframe_ip.columns]
        df_renamed = dataframe_ip
        for old_col, new_col in zip(dataframe_ip.columns, new_columns):
            df_renamed = df_renamed.withColumnRenamed(old_col.lower(), new_col.lower())
        return df_renamed
    except Exception as exp:
        logging.error("Error in renaming  function : %s", exp)
        traceback.print_exc()
        raise


def exp_pivot(explode_val, exp_df):
    """
    This function explodes and pivots the columns
    """
    try:
        updated_df_exp = exp_df.select(F.explode(explode_val), "_hoodie_record_key")
        df_pivot = (
            updated_df_exp.groupBy("_hoodie_record_key")
            .pivot("key")
            .agg(F.first("value"))
        )
        df_pivot = df_pivot.withColumn(
            "hoodie_record_key_pivot_" + explode_val, df_pivot["_hoodie_record_key"]
        )
        df_pivot = df_pivot.drop("_hoodie_record_key")
        df_pivot = df_pivot.drop(explode_val)
        return df_pivot
    except Exception as exp:
        logging.error("Error in exp pivot function : %s", exp)
        traceback.print_exc()
        raise


def store_parameter(name, value, param_type="String", overwrite=True):
    """
    Store a parameter in AWS Systems Manager Parameter Store.

    :param name: The name of the parameter (e.g., '/myapp/prod/db_password').
    :param value: The value to store (string).
    :param param_type: Type of the parameter ('String', 'StringList', or 'SecureString').
    :param overwrite: Whether to overwrite an existing parameter.
    :return: The response from the SSM API.
    """
    ssm = boto3.client("ssm")

    try:
        response = ssm.put_parameter(
            Name=name, Value=value, Type=param_type, Overwrite=overwrite
        )
        return response
    except Exception as exp:
        logging.error("Error in storing parameter : %s", exp)
        traceback.print_exc()
        raise


def retrieve_parameter(name, with_decryption=True):
    """
    Retrieve a parameter from AWS Systems Manager Parameter Store.

    :param name: The name of the parameter (e.g., '/myapp/prod/db_password').
    :param with_decryption: Whether to decrypt the parameter if it is of type 'SecureString'.
    :return: The parameter value, or None if not found.
    """
    ssm = boto3.client("ssm")

    try:
        response = ssm.get_parameter(Name=name, WithDecryption=with_decryption)
        return response["Parameter"]["Value"]
    except Exception as exp:
        logging.error("Error in getting parameter from paramter store  : %s", exp)
        traceback.print_exc()
        return 19700101


def transform():
    """
    This function transforms the data from landing to raw
    """
    try:

        logging.info("Calling the log_audit to log the status as job started")

        log_audit(
            spark,
            args["JOB_NAME"],
            source_table_name,
            source_type,
            table_name,
            target_type,
            "Started",
            start_time,
            None,
            None,
            audit_path,
            audit_table,
        )

        logging.info("Getting latest_commit_time from paramter store")
        latest_commit_time = int(retrieve_parameter(latest_commit_time_var))
        logging.info(
            "latest_commit_time from paramter store is :%s", latest_commit_time
        )

        ##Hudi loads LATEST_COMMIT_TIME as yyyymmdd
        ## load the incremental data from hudi
        updated_df = (
            spark.read.format("hudi")
            .option("hoodie.datasource.query.type", "incremental")
            .option("hoodie.datasource.read.begin.instanttime", latest_commit_time)
            .load(hudi_table_path)
        )
        ## select the hudi commit time for given hour
        updated_df = updated_df.withColumn(
            "_hoodie_commit_time_land_cal", F.substring("_hoodie_commit_time", 1, 10)
        )

        ##explode signals and dimensions
        df_pivot_signals = exp_pivot("signals", updated_df)
        df_pivot_dimensions = exp_pivot("dimensions", updated_df)
        ##drop signals and dimensions
        updated_sig_df = updated_df.drop("signals", "dimensions")
        ## the signals pivot and raw data
        updated_sig_join_df = updated_sig_df.join(
            df_pivot_signals,
            updated_sig_df["_hoodie_record_key"]
            == df_pivot_signals["hoodie_record_key_pivot_signals"],
            "left",
        )
        ## the dimensions pivot and raw data
        updated_sig_join_df_final = updated_sig_join_df.join(
            df_pivot_dimensions,
            updated_sig_df["_hoodie_record_key"]
            == df_pivot_dimensions["hoodie_record_key_pivot_dimensions"],
            "left",
        )
        ##drop the join columns
        updated_sig_join_df_final = updated_sig_join_df_final.drop(
            "hoodie_record_key_pivot_signals", "hoodie_record_key_pivot_dimensions"
        )
        ##replace . with _ and convert column to lower case
        df_renamed_ret = func_rename_col(updated_sig_join_df_final)
        ##check if table exists in the catalog. To identify
        # if this is the first run to load the table or subsequent run
    except Exception as exp:
        logging.error("An error occurred: %s", str(exp))
        traceback.print_exc()
        end_time = datetime.now()
        logging.info("Calling log_audit to log the status Failed")

        log_audit(
            spark,
            args["JOB_NAME"],
            source_table_name,
            source_type,
            table_name,
            target_type,
            "Failed",
            start_time,
            end_time,
            None,
            audit_path,
            audit_table,
        )

        raise
    return df_renamed_ret


def load(df_renamed_op):
    """
    This function loads transformed the data to raw
    """
    try:
        if spark._jsparkSession.catalog().tableExists(database, table_name):
            ## load the target hudi table to fetch the schema
            df_target = spark.read.format("hudi").option("hoodie.datasource.query.type", "snapshot").load(s3_output_path).limit(1)
            ## fetch the target column name and datatype. Mainly
            # to default the column as None if not present in source and
            # use the same data type as target.
            for field in df_target.schema.fields:
                if field.name not in df_renamed_op.columns:
                    df_renamed_op = df_renamed_op.withColumn(
                        field.name, F.lit(None).cast(field.dataType)
                    )
            ## export the column names of the target as list
            column_list_target = df_target.columns
            ##Validate if the column in source exists in target,
            # if not add it to target list of column names.
            for col_name in df_renamed_op.columns:
                if col_name not in column_list_target:
                    column_list_target.append(col_name)
            ## enforce schema order by using the previously selected column list
            # from the modified source dataframe. Where the columns not present in
            # source will be defaulted as None
            df_renamed_op = df_renamed_op.select(column_list_target)
        ## Hudi table options
        hudi_options = {
            "hoodie.table.name": table_name,
            "hoodie.datasource.write.operation": "insert",
            "hoodie.datasource.write.partitionpath.field": "tenantid,kafka_topic,year,month,day,hour",
            "hoodie.datasource.write.recordkey.field": "vid,eventid,offset",
            "hoodie.datasource.hive_sync.enable": "true",
            "hoodie.datasource.hive_sync.database": database,
            "hoodie.datasource.hive_sync.table": table_name,
            "hoodie.datasource.hive_sync.use_jdbc": "false",
            "hoodie.datasource.hive_sync.mode": "hms",
            "hoodie.datasource.hive_sync.support_timestamp": "true",
            "path": s3_output_path,
            "hoodie.parquet.max.file.size": "134217728",
        }
        ## Load to Hudi table
        if len(df_renamed_op.head(1)) > 0:
            df_renamed_op.write.format("org.apache.hudi").options(**hudi_options).mode(
                "append"
            ).save()

        end_time = datetime.now()
        # Apply the counting function to each row
        df_renamed_op.foreach(count_elements)

        logging.info("Calling log_audit to log the status as completed")

        log_audit(
            spark,
            args["JOB_NAME"],
            source_table_name,
            source_type,
            table_name,
            target_type,
            "Completed",
            start_time,
            end_time,
            count_accum.value,
            audit_path,
            audit_table,
        )

        latest_commit_time_val = df_renamed_op.agg(
            {"_hoodie_commit_time_land_cal": "max"}
        ).collect()[0][0]
        latest_commit_time_val_str = str(latest_commit_time_val)
        store_parameter(latest_commit_time_var, latest_commit_time_val_str)
        logging.info(
            "this is latest commit time we are storing for to use as start time for next run :%s",
            latest_commit_time_val_str,
        )

        logging.info("job completed")

    except Exception as exp:
        logging.error("An error occurred: %s", str(exp))
        traceback.print_exc()
        end_time = datetime.now()
        logging.info("Calling log_audit to log the status Failed")

        log_audit(
            spark,
            args["JOB_NAME"],
            source_table_name,
            source_type,
            table_name,
            target_type,
            "Failed",
            start_time,
            end_time,
            None,
            audit_path,
            audit_table,
        )

        raise


if __name__ == "__main__":
    try:
        df_renamed_op = transform()
        load(df_renamed_op)
    except Exception as e:
        logging.error("An error occurred in main method: %s", str(e))
        traceback.print_exc()

        end_time = datetime.now()
        duration = (end_time - start_time).seconds

        cloudwatch_url = get_cloudwatch_url("ap-south-1", job_name, job_run_id)
        ERROR_CODE = getattr(
            e, "code", "N/A"
        )  # Some exceptions might have a 'code' attribute
        if ERROR_CODE == "N/A":
            # Try to parse error code from the exception message if it's in a known format
            ERROR_CODE = "Specific logic to parse error code from the exception message if possible"

        log = {
            "status": "failure",
            "job_name": job_name,
            "source_table": source_table_name,
            "target_table": table_name,
            "start_time": start_time.isoformat(),
            "end_time": end_time.isoformat(),
            "duration": duration,
            "error_code": ERROR_CODE,
            "error": f"Error: {str(e)}\nTraceback: {traceback.format_exc()}",
        }

        log_message = "\n".join([f"{key}: {value}" for key, value in log.items()])

        message = f"Job {job_name} failed. Error: {str(e)}\nTraceback: {traceback.format_exc()}\
              \n\n{log_message}.\n\nView the logs in CloudWatch:{cloudwatch_url}"

        sns_message_size = len(message.encode("utf-8"))
        logging.info("message body size in KB:%s", sns_message_size / 1024)
        if sns_message_size >= 256 * 1024:
            logging.info("messages size is greater than 256KB so truncating it")
            message = message[
                :250000
            ]  # 250 KB to ensure we stay within the 256 KB limit

        subject = f"{job_name} failed for {table_name} table"
        if len(subject) > 100:
            subject = subject[:98] + ".."  # Truncate if needed

        send_sns_notification(subject, message, sns_secret_name, "ap-south-1")

        raise
