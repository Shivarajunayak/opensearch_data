   
# pylint: disable=import-error, invalid-name, too-many-locals, too-many-statements, broad-except
import sys
import logging
from datetime import datetime
import boto3
import json
import psycopg2
import traceback
from awsglue.utils import getResolvedOptions
from pyspark.sql import functions as F
from pyspark.sql.functions import lit
from hmcl_cv_common_utilities import (
    log_audit,
    load_yaml_config,
    validate_audit_table_with_s3_partition,
    send_sns_notification,
    get_watermark_timestamp,
    get_cloudwatch_url,
    update_watermark_file,
    initialize_spark_session,
    fetch_postgres_credentials,
    )


logging.basicConfig(
    level=logging.INFO, format="%(asctime)s - %(name)s - %(levelname)s - %(message)s"
)

def read_job_param():
    try:
    
        # Define arguments
        arguments = [
            "JOB_NAME",
            "yaml_s3_bucket",
            "yaml_file_key",
        ]
        # Get the arguments
        args = getResolvedOptions(sys.argv, arguments)
        job_name = args.get("JOB_NAME")
        yaml_s3_bucket = args.get("yaml_s3_bucket")
        yaml_file_key = args.get("yaml_file_key")
        job_run_id = args.get("JOB_RUN_ID")
        logging.info("Job parameters read successfully")
        return yaml_s3_bucket,yaml_file_key,job_name,job_run_id
        
    except Exception as e:
        logging.error(f"Error while reading job parameters: {str(e)}")
        raise
        
def read_yaml_file(s3_client,yaml_s3_bucket,yaml_file_key):
    try:
        yaml_dict = load_yaml_config(s3_client,yaml_s3_bucket,yaml_file_key)
        source_table_name = yaml_dict['postgres_source_table_name']
        source_type = yaml_dict['postgres_source_type']
        target_table_name = yaml_dict['table_name_landing']
        target_type = yaml_dict['type_landing']
        target_database = yaml_dict['database_landing']
        target_bucket_name = yaml_dict['bucket_name_landing']
        target_hudi_table_path = yaml_dict['table_path_landing']
        partition_field = yaml_dict['partition_field']
        recordkey = yaml_dict['recordkey']
        sns_secret_name = yaml_dict['sns_secret_name']
        watermark_bucket = yaml_dict['watermark_bucket_landing']
        watermark_file_key = yaml_dict['watermark_file_key_landing']
        audit_path = yaml_dict['audit_path']
        audit_table = yaml_dict['audit_table']
        watermark_col_landing = yaml_dict['watermark_col_landing']
        source_pg_secret_name = yaml_dict['source_pg_secret_name']
        source_secret_region = yaml_dict['source_secret_region']
        flag_col = yaml_dict['flag_col']
    
        logging.info("yaml parameters read successfully")
        return source_table_name,source_type,target_table_name,target_database,target_type,target_bucket_name,\
        target_hudi_table_path,recordkey,partition_field,sns_secret_name,watermark_bucket,\
        watermark_file_key,audit_path,audit_table,watermark_col_landing,source_pg_secret_name,source_secret_region,flag_col
    except Exception as e:
        logging.error(f"Error while reading yaml parameters: {str(e)}")
        raise
    
def load_df_into_target_table(source_df,target_table_name,target_database,target_bucket_name,target_hudi_table_path,recordkey,partition_field,watermark_col_landing):
    """
    This function loads  data into raw
    """
    try:
        source_df = source_df.withColumn("year", F.year((F.col(watermark_col_landing) / 1000).cast("timestamp"))) \
                     .withColumn("month", F.month((F.col(watermark_col_landing) / 1000).cast("timestamp"))) \
                     .withColumn("day", F.dayofmonth((F.col(watermark_col_landing) / 1000).cast("timestamp"))) \
                     .withColumn('tenant_id', lit('Master'))
        
        target_path = "s3://" + target_bucket_name + "/" + target_hudi_table_path + "/"
        # Define Hudi options
        source_df.write.format("hudi") \
        .option("hoodie.table.name", target_table_name) \
        .option("hoodie.datasource.write.storage.type", "COPY_ON_WRITE") \
        .option("hoodie.datasource.write.recordkey.field", recordkey) \
        .option("hoodie.datasource.write.partitionpath.field", partition_field) \
        .option("hoodie.datasource.write.operation", "insert") \
        .option("hoodie.datasource.hive_sync.enable", "true") \
        .option("hoodie.datasource.hive_sync.database", target_database) \
        .option("hoodie.datasource.hive_sync.table", target_table_name) \
        .option("hoodie.datasource.hive_sync.use_jdbc", "false") \
        .option("hoodie.datasource.hive_sync.mode", "hms") \
        .option("hoodie.datasource.hive_sync.sync_as_datasource", "false") \
        .option("hoodie.datasource.hive_sync.support_timestamp", "true") \
        .option("hoodie.avro.schema.allow.empty", "true") \
        .option("hoodie.schema.on.read.enable", "true") \
        .option("hoodie.datasource.write.schema.evolution.enable", "true") \
        .option("hoodie.parquet.max.file.size", "134217728") \
        .option("hoodie.insert.shuffle.parallelism", 200) \
        .mode("append") \
        .save(target_path)
        ## .option("hoodie.datasource.hive_sync.partition_fields": partition_field) \
        logging.info(f"Data loaded successfully into {target_table_name} table,\
            no.of processed records count: {source_df.count()}")
        return True
    except Exception as e:
        logging.error(f"Error while loading the data into table:{target_table_name}, {str(e)}")
        raise

    
def get_postgres_conn_details(secret_name,secret_region):
    try:
        # Extract PostgreSQL credentials from secret
        secret_dict = fetch_postgres_credentials(secret_name,secret_region)
        logging.info(f"SECRET INFO :{secret_dict}")
        logging.info("rds_secret_name loaded successfully.")
        db_host = secret_dict['RDS_DB_URL']
        db_port = secret_dict['RDS_PORT']
        db_name = secret_dict['RDS_NAME']
        db_user = secret_dict['RDS_USERNAME']
        db_password = secret_dict['RDS_PASSWORD']
        
        jdbc_url = f"jdbc:postgresql://{db_host}:{db_port}/{db_name}?user={db_user}&password={db_password}"
        
        return db_host,db_port,db_name,db_user,db_password,jdbc_url
    except Exception as e:
        logging.error(f"Error While fetching Source PostgreSQL credentials from Secrets Manager: {e}")
        traceback.print_exc()
        raise
    
def get_postgres_conn(source_pg_secret_name,source_secret_region):
    try:
        db_host,db_port,db_name,db_user,db_password,_ \
                = get_postgres_conn_details(source_pg_secret_name,source_secret_region)
        # Connect to PostgreSQL
        
        
        conn = psycopg2.connect(
            database=db_name,
            user= db_user,
            password= db_password,
            host= db_host,
            port= db_port
        )
        return conn
    
    except Exception as e:
        logging.error(f"Error While getting Source PostgreSQL conn: {e}")
        traceback.print_exc()
        raise
    
def delete_processed_records_from_pg(source_table_name,source_pg_secret_name,watermark_col_landing,source_secret_region):
    #delete the records from postgres where flag = true and older than 7 days
    try:
    
        conn = get_postgres_conn(source_pg_secret_name,source_secret_region)
        # Create a cursor
        cursor = conn.cursor()
        query = f"DELETE FROM {source_table_name} WHERE {watermark_col_landing} < ((EXTRACT(EPOCH FROM NOW()) - 7 * 24 * 60 * 60) * 1000)  AND  flag = true"
        logging.info(f"Constructed SQL delete query: {query}")
        cursor.execute(query)
        deleted_count = cursor.rowcount
        conn.commit()
        logging.info(f"Number of records deleted: {deleted_count}")
        cursor.close()
        conn.close()
        return True
    except Exception as e:
        logging.error(f"Error While updating PostgreSQL Flag: {e}")
        traceback.print_exc()
        raise


def update_flag(source_df,source_table_name,source_pg_secret_name,source_secret_region,flag_col):
    try:
        conn = get_postgres_conn(source_pg_secret_name,source_secret_region)
            
        #get all processed ids
        processed_ids_list = source_df.select("id").rdd.flatMap(lambda x: x).collect()

        cur = conn.cursor()
        
        # Construct the SQL query
        update_query = f"""
        UPDATE {source_table_name}
        SET {flag_col} = TRUE 
        WHERE id in ({', '.join(map(str, processed_ids_list))});
        """
        logging.info(f"Constructed SQL Update query: {update_query}")
        cur.execute(update_query)
        
        # Commit the changes and close the connection
        conn.commit()
        cur.close()
        conn.close()

        logging.info(f"Source Table Falg Updated Successfully")
        return True
        
    except Exception as e:
        logging.error(f"Error While updating PostgreSQL Flag: {e}")
        traceback.print_exc()
        raise
    
def read_postgres_table(spark,source_table,watermark_timestamp,source_pg_secret_name,watermark_col_landing,source_secret_region):
    """
    Read data incrementally from PostgreSQL using a id value.
    """
    try:
        _,_,_,db_user,db_password,jdbc_url \
            = get_postgres_conn_details(source_pg_secret_name,source_secret_region)
        
        logging.info("Configurations extracted and processed successfully.")
        
        jdbc_properties = {
            "user": db_user,
            "password": db_password,
            "driver": "org.postgresql.Driver"
        }
        
        # Construct the SQL query
        query = f"(SELECT * FROM {source_table} WHERE {watermark_col_landing} >= {watermark_timestamp}) AS temp"
        logging.info(f"Constructed SQL query: {query}")

        # Execute the query and fetch data
        df = spark.read.jdbc(url=jdbc_url, table=query, properties=jdbc_properties)
        new_pg_rows = df.count()
        logging.info(f"Fetched {new_pg_rows} rows from PostgreSQL")

        return df

    except Exception as e:
        logging.error(f"Error fetching PostgreSQL data: {e}")
        traceback.print_exc()
        raise
    
def update_watermark_with_latesttime(s3,source_df,raw_watermark_bucket,raw_watermark_file_key,watermark_col_landing,source_table_name):
    
    try:
        # Update the watermark for the specific table
        max_commit_time = source_df.agg({watermark_col_landing: "max"}).collect()[0][0]
        update_watermark_file(s3,max_commit_time,raw_watermark_bucket,raw_watermark_file_key,source_table_name)
        return True
    except Exception as e:
        logging.error(f"Error while updating the watermark file:{str(e)}")
        raise


def main():
    
    
    try:
        #initialization of job parameters
        start_time = datetime.now()
        logging.info(f"Job started at {start_time}")
        
        #initialize spark job
        spark = initialize_spark_session()
        
        #read job parameters
        yaml_s3_bucket,yaml_file_key,job_name,job_run_id = read_job_param()
        logging.info("job_name=%s", job_name+"/")
        
        #create an S3 client
        s3 = boto3.client('s3')

        #read necessary  parameters from yaml file
        source_table_name,source_type,target_table_name,target_database,target_type,target_bucket_name,\
        target_hudi_table_path,recordkey,partition_field,sns_secret_name,watermark_bucket,\
        watermark_file_key,audit_path,audit_table,watermark_col_landing,source_pg_secret_name,source_secret_region,\
            flag_col= read_yaml_file(s3,yaml_s3_bucket,yaml_file_key)
    except Exception as e:
        logging.error(f"Error in initial steps: {str(e)}")
        traceback.print_exc()
        raise
         
    try:
        year_partitioned=start_time.year
        month_partitioned=start_time.month
        #validate audit table
        is_validate = validate_audit_table_with_s3_partition(spark,sns_secret_name,start_time,audit_path,audit_table,source_table_name,target_table_name,job_name,source_secret_region,year_partitioned,month_partitioned)
        
        if is_validate == False:
            return
        
        # Log audit
        log_audit(
                    spark,job_name,source_table_name,source_type,target_table_name,target_type,\
                    "Started",start_time,None,None,audit_path,audit_table,
                )
        # delete_processed_records_from_pg(source_table_name,source_pg_secret_name,watermark_col_landing,source_secret_region)
        #read watermark value
        watermark_timestamp = get_watermark_timestamp(s3,watermark_bucket,watermark_file_key)
        
        # read data from landing table incrementally
        source_df = read_postgres_table(spark,source_table_name,watermark_timestamp,source_pg_secret_name,watermark_col_landing,source_secret_region)
        num_records = source_df.count()
        
        if num_records > 0:
            #load landing data into raw
            load_df_into_target_table(source_df,target_table_name,target_database,target_bucket_name,target_hudi_table_path,recordkey,partition_field,watermark_col_landing)
            #update the flag in postgres
            update_flag(source_df,source_table_name,source_pg_secret_name,source_secret_region,flag_col)
            #update watermark file
            update_watermark_with_latesttime(s3,source_df,watermark_bucket,watermark_file_key,watermark_col_landing,source_table_name)
            
        cloudwatch_url = get_cloudwatch_url(source_secret_region, job_name, job_run_id)
        
        end_time = datetime.now()
        duration = (end_time - start_time).seconds
        
        log = {
            "status": "success",
            "job_name": job_name,
            "source_table": source_table_name,
            "target_table": target_table_name,
            "start_time": start_time.isoformat(),
            "end_time": end_time.isoformat(),
            "duration": duration,
            "num_records": num_records
        }
        # Log audit
        log_audit(
                spark,job_name,source_table_name,source_type,target_table_name,target_type,"Completed",start_time,end_time,\
                    num_records,audit_path,audit_table,
                )
        logging.info(f"Job completed successfully in {duration} seconds")
        
        
                    
    except Exception as e:
        logging.error("Job failed with error: %s", str(e))
        traceback.print_exc()
        end_time = datetime.now()
        duration = end_time - start_time
        logging.error(f"Job failed in {duration} seconds")
        
        #get cloudwatch details 
        cloudwatch_url = get_cloudwatch_url(source_secret_region, job_name, job_run_id)
            
        log = {
                "status": "failure",
                "job_name": job_name,
                "source_table": source_table_name,
                "target_table": target_table_name,
                "start_time": start_time.isoformat(),
                "end_time": end_time.isoformat(),
                "duration": duration,
                "error": f"Error: {str(e)}\nTraceback: {traceback.format_exc()}"
            }
        
        # Log audit
        log_audit(
                spark,job_name,source_table_name,source_type,target_table_name,target_type,\
                "Failed",start_time,end_time,None,audit_path,audit_table,
                )
            
        log_message = "\n".join([f"{key}: {value}" for key, value in log.items()])
        message = f"Job -{job_name} failed. Transformation returned None.\n\n{log_message}.\n\nView the logs in CloudWatch:{cloudwatch_url}"

        send_sns_notification(
            subject=f"Job Failed : Job - {job_name}",
            message=message,
            sns_secret_name=sns_secret_name,
            region_name=source_secret_region
                )
        raise

    finally:
        final_log = log.copy() 
        yaml_params = {
        "table_name": source_table_name,
        "target_bucket_name":target_bucket_name, 
        "audit_table": audit_table, 
        "audit_path":audit_path,
        "yaml_s3_bucket": yaml_s3_bucket,
        "yaml_file_path": yaml_file_key,
        "target_table_name": target_table_name,
        "recordkey": recordkey, 
        "target_database": target_database,
        "partition_field": partition_field}

        final_log.update(yaml_params)
        dt = datetime.now()
        epoch_time = int(dt.timestamp() * 1000)
        s3 = boto3.client('s3', region_name='ap-south-1')
        s3.put_object(Bucket=target_bucket_name, Key=f'logs/{job_name}-{source_table_name}_{epoch_time}_logs.json', Body=json.dumps(final_log))
      
if __name__ == "__main__":
    main()
