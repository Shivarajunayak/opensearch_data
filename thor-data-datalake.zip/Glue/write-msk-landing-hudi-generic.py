"""
AWS Glue Job: MSK to S3 Data Pipeline

This AWS Glue job reads data from an msk TOPIC and 
writes the data to an Hudi table in Amazon S3 bucket. If any nested json fileds in the input 
we use this job to load to landing and if no nested josn fileds 
we use same job to load directly to raw layer
The job leverages AWS Glue's ETL capabilities to transform 
and store the data in a specified S3 location.

Usage:
    - Ensure the IAM role for the Glue job has necessary permissions 
    to read from MSK and write to S3.
"""

# pylint: disable=import-error
import sys
import logging
import json
import traceback
import yaml
from datetime import datetime
from string import Template
import boto3
from awsglue.utils import getResolvedOptions
from pyspark.sql import functions as F
from pyspark.sql import SparkSession
from pyspark.sql.types import (
    StructType,
    StructField,
    StringType,
    DecimalType,
    DoubleType,
    TimestampType,
)
from hmcl_cv_common_utilities import (
    log_audit,
    get_cloudwatch_url,
    send_sns_notification,
    validate_audit_table_with_s3_partition
)

ssm = boto3.client("ssm")
logging.basicConfig(
    level=logging.INFO, format="%(asctime)s - %(name)s - %(levelname)s - %(message)s"
)
FORMAT_STR = "%Y-%m-%d %H:%M:%S"

# logger = logging.getLogger('my_custom_logger')


# This method is not currently being used
def process_nested_fields(df, fields):
    """
    This method to create nested fileds as seperate columns in the data frame
    as main columns to be used in hoodi options
    """
    try:
        new_columns = []
        for key in fields:
            if "." in key:
                nested_field, new_column_name = key, key.split(".")[-1] + "_pkey"
                df = df.withColumn(new_column_name, F.col(nested_field))
                new_columns.append(new_column_name)
            else:
                new_columns.append(key)

        return df, new_columns
    except Exception as e:
        logging.error("Error in processing nested fields : %s", e)
        traceback.print_exc()
        raise


def substitute_variables(config, args):
    """
    This method to substtute env specific variables where ever referenced
    """
    try:
        config_str = yaml.dump(config)  # Convert config back to a string
        template = Template(config_str)
        return yaml.safe_load(template.substitute(args))
    except Exception as e:
        logging.error("Error in substituting variables : %s", e)
        traceback.print_exc()
        raise


def load_yaml_config(yaml_s3_bucket, yaml_file_key, source_table_name):
    """
    Load and parse YAML configuration from S3.
    """
    try:
        s3_client = boto3.client("s3", region_name="ap-south-1")
        s3_object = s3_client.get_object(Bucket=yaml_s3_bucket, Key=yaml_file_key)
        yaml_content = s3_object["Body"].read().decode("utf-8")
        yaml_dict = yaml.safe_load(yaml_content)
        logging.info("YAML configuration loaded successfully.")
        return yaml_dict["tables"][source_table_name]
    except Exception as e:
        logging.error(f"Error loading YAML configuration from S3: {e}")
        traceback.print_exc()
        raise


# This methid is not currently being used
def cast_data_type(df, from_type, to_type):
    """
    Generic method to convert data type of columns dynamically
    """
    try:
        columns_to_convert = [
            field.name
            for field in df.schema.fields
            if isinstance(field.dataType, from_type)
        ]
        if not columns_to_convert:
            return df

        for column in columns_to_convert:
            df = df.withColumn(column, F.col(column).cast(to_type))

        return df
    except Exception as e:
        logging.error("Error in casting data types: %s", e)
        traceback.print_exc()
        raise


def func_rename_col(dataframe_ip, special_char):
    """
    replace special_char (. or #) with _
    """
    try:
        old_new_columns = [
            (col, col.replace(special_char, "_"))
            for col in dataframe_ip.columns
            if special_char in col
        ]
        df_renamed_val = dataframe_ip
        for old_col, new_col in old_new_columns:
            df_renamed_val = df_renamed_val.withColumnRenamed(
                old_col.lower(), new_col.lower()
            )
        return df_renamed_val
    except Exception as e:
        logging.error(f"Error in replacing column names: {e}")
        traceback.print_exc()
        raise


def func_drop_col(dataframe_ip, special_char):
    """
    replace special_char (. or #) with _
    """
    try:
        impact_cols = [col for col in dataframe_ip.columns if special_char in col]
        df_renamed_val = dataframe_ip.drop(*impact_cols)

        return df_renamed_val
    except Exception as e:
        logging.error("Error in dropping column names: %s", e)
        traceback.print_exc()
        raise


def process_timestamps(df, primary_col, secondary_col=None):
    """
    This method to extract year,month,day and hour partition columns
    for given time stamp column in epoch.epochmillies/UTS timestamp
    """
    try:
        if secondary_col:
            df = (
                df.withColumn(
                    primary_col + "_ts",
                    F.when(
                        F.length(primary_col) == 13,
                        F.from_unixtime(
                            (
                                F.coalesce(F.col(primary_col), F.col(secondary_col))
                                / 1000
                            ).cast(DoubleType()),
                            "yyyy-MM-dd hh:mm:ss.SSS",
                        ),
                    )
                    .when(
                        F.length(primary_col) == 10,
                        F.from_unixtime(
                            (F.coalesce(F.col(primary_col), F.col(secondary_col))).cast(
                                DoubleType()
                            ),
                            "yyyy-MM-dd hh:mm:ss.SSS",
                        ),
                    )
                    .otherwise(F.coalesce(F.col(primary_col), F.col(secondary_col))),
                )
                .withColumn(
                    primary_col + "_ts",
                    (F.col(primary_col + "_ts")).cast(TimestampType()),
                )
                .withColumn("year", F.year(F.col(primary_col + "_ts")))
                .withColumn("month", F.month(F.col(primary_col + "_ts")))
                .withColumn("day", F.dayofmonth(F.col(primary_col + "_ts")))
                .withColumn("hour", F.hour(F.col(primary_col + "_ts")))
            )
        else:
            df = (
                df.withColumn(
                    primary_col + "_ts",
                    F.when(
                        F.length(primary_col) == 13,
                        F.from_unixtime(
                            (F.col(primary_col) / 1000).cast(DoubleType()),
                            "yyyy-MM-dd hh:mm:ss.SSS",
                        ),
                    )
                    .when(
                        F.length(primary_col) == 10,
                        F.from_unixtime(
                            (F.col(primary_col)).cast(DoubleType()),
                            "yyyy-MM-dd hh:mm:ss.SSS",
                        ),
                    )
                    .otherwise(F.col(primary_col)),
                )
                .withColumn(
                    primary_col + "_ts",
                    (F.col(primary_col + "_ts")).cast(TimestampType()),
                )
                .withColumn("year", F.year(F.col(primary_col + "_ts")))
                .withColumn("month", F.month(F.col(primary_col + "_ts")))
                .withColumn("day", F.dayofmonth(F.col(primary_col + "_ts")))
                .withColumn("hour", F.hour(F.col(primary_col + "_ts")))
            )

        return df
    except Exception as e:
        logging.error("Error in processing timestamp for partion columns : %s", e)
        traceback.print_exc()
        raise


def main():
    """
    Main method
    """
    try:
        logging.info("Job started")
        start_time = datetime.now()
        year_partitioned=start_time.year
        month_partitioned=start_time.month
        arguments = [
            "JOB_NAME",
            "yaml_s3_bucket",
            "yaml_file_key",
            "source_table_name",
        ]
        optional_arguments = []

        for argument in optional_arguments:
            if not f"--{argument}" in sys.argv:
                arguments.remove(argument)

        ## @params: [JOB_NAME]
        args = getResolvedOptions(sys.argv, arguments)
        logging.info("job_name=%s", args.get("JOB_NAME"))
        logging.info("intialising spark session")
        spark = (
            SparkSession.builder.config(
                "spark.serializer", "org.apache.spark.serializer.KryoSerializer"
            )
            .config("spark.hudi.query.metadata.enable", "true")
            .getOrCreate()
        )

        logging.info("accessing job parameters and storing variables")

        job_name = args.get("JOB_NAME")
        job_run_id = args.get("JOB_RUN_ID")
        yaml_s3_bucket = args.get("yaml_s3_bucket")
        yaml_file_key = args.get("yaml_file_key")
        source_table_name = args.get("source_table_name")

        # Load configurations
        try:
            job_args = load_yaml_config(
                yaml_s3_bucket, yaml_file_key, source_table_name
            )

            global_args = load_yaml_config(yaml_s3_bucket, yaml_file_key, "global")

            all_args = {**job_args, **global_args}

            env_specific_args = load_yaml_config(
                yaml_s3_bucket, yaml_file_key, "env_specific"
            )

            all_args = substitute_variables(all_args, env_specific_args)

            # secret_dict = fetch_postgres_credentials(rds_secret_name)
            logging.info("Configurations loaded successfully.")
        except Exception as e:
            logging.error(f"Error loading configurations or credentials: {e}")
            traceback.print_exc()
            raise

        source_kafka_topic = all_args.get("source_kafka_topic")
        target_bucket_name = all_args.get("target_bucket_name")
        target_table_name = all_args.get("target_table_name")
        target_database = all_args.get("target_database")
        recordkey = all_args.get("recordkey")
        precombine_field = all_args.get("precombine_field")
        partition_field = all_args.get("partition_field")
        folder_prefix = all_args.get("folder_prefix")
        use_case_name = all_args.get("use_case_name")
        write_operation = all_args.get("write_operation")
        source_type = all_args.get("source_type")
        target_type = all_args.get("target_type")
        audit_path = all_args.get("audit_path")
        audit_table = all_args.get("audit_table")
        partion_extract_col = all_args.get("partion_extract_col")
        partion_extract_col_sec = all_args.get("partion_extract_col_sec", None)
        # updated_time_col = args.get("updated_time_col")
        brokers = all_args.get("brokers")
        offset = all_args.get("offset")
        schema_json = all_args["schema"]
        audit_database = all_args.get("audit_database")
        sns_secret_name = all_args.get("sns_secret_name")
        region_name = all_args.get("region_name")

        # Validate the audit table to process the job based on job_status
        is_validate = validate_audit_table_with_s3_partition(spark,sns_secret_name,start_time,audit_path,audit_table,source_kafka_topic,target_table_name,job_name,region_name,year_partitioned,month_partitioned)

        if is_validate == False:
            return
        
        logging.info("Calling log audit to log the status is job started")

        log_audit(
            spark,
            args["JOB_NAME"],
            source_kafka_topic,
            source_type,
            target_table_name,
            target_type,
            "Started",
            start_time,
            None,
            None,
            audit_path,
            audit_table,
        )

        cloudwatch_url = get_cloudwatch_url(region_name, job_name, job_run_id)

        logging.info("Reading data from MSK topic :%s", source_kafka_topic)

        df_kafka = (
            spark.readStream.format("kafka")
            .option("kafka.bootstrap.servers", brokers)
            .option("subscribe", source_kafka_topic)
            .option("kafka.security.protocol", "SASL_SSL")
            .option("kafka.sasl.mechanism", "AWS_MSK_IAM")
            .option(
                "kafka.sasl.jaas.config",
                "software.amazon.msk.auth.iam.IAMLoginModule required;",
            )
            .option(
                "kafka.sasl.client.callback.handler.class",
                "software.amazon.msk.auth.iam.IAMClientCallbackHandler",
            )
            .option("startingOffsets", offset)
            # .option(
            #    "failOnDataLoss", "false"
            # )  # This is added temorarly , need to be removed for live
            .load()
        )

        logging.info("Reading data from MSK topic - %s completed", source_kafka_topic)
        ## convert the value from byte to string
        df_kafka = df_kafka.selectExpr(
            "key",
            "cast(value as string) as value",
            "topic",
            "partition",
            "offset",
            "timestamp",
        )

        schema = StructType.fromJson(json.loads(schema_json))
        # schema = eval(schema_json)

        df_kafka = df_kafka.withColumn(
            "value", F.from_json(df_kafka["value"], schema)
        ).select(
            "value.*",
            F.col("timestamp").alias("kafka_timestamp"),
            "key",
            "topic",
            "partition",
            "offset",
        )

        df_kafka = df_kafka.filter(F.col(precombine_field).isNotNull())

        # df_kafka=cast_data_type(df_kafka, DoubleType, DecimalType())

        if any("#" in column for column in df_kafka.columns):
            df_kafka = func_drop_col(df_kafka, "#")

        if any("." in key for key in recordkey):
            df_kafka, processed_record_key = process_nested_fields(df_kafka, recordkey)
        else:
            processed_record_key = recordkey

        if any("." in key for key in precombine_field):
            df_kafka, processed_precombine_field = process_nested_fields(
                df_kafka, precombine_field
            )
        else:
            processed_precombine_field = precombine_field

        df_timestamp_proc = process_timestamps(
            df_kafka, partion_extract_col, partion_extract_col_sec
        )

        target_path = (
            "s3://"
            + target_bucket_name
            + "/"
            + folder_prefix
            + "_"
            + use_case_name
            + "/"
        )

        check_point_path = (
            "s3://"
            + target_bucket_name
            + "/checkpoint/"
            + folder_prefix
            + "_"
            + use_case_name
            + "/"
        )

        hudi_options = {
            "hoodie.table.name": target_table_name,
            "hoodie.datasource.write.storage.type": "COPY_ON_WRITE",
            "hoodie.datasource.write.recordkey.field": processed_record_key,
            "hoodie.datasource.write.operation": write_operation,
            "hoodie.datasource.write.precombine.field": processed_precombine_field,
            "hoodie.datasource.write.partitionpath.field": partition_field,
            "hoodie.datasource.hive_sync.enable": "true",
            "hoodie.datasource.hive_sync.database": target_database,
            "hoodie.datasource.hive_sync.table": target_table_name,
            "hoodie.datasource.hive_sync.use_jdbc": "false",
            "hoodie.datasource.hive_sync.mode": "hms",
            "hoodie.datasource.hive_sync.sync_as_datasource": "false",
            "hoodie.datasource.hive_sync.support_timestamp": "true",
            "path": target_path,
            # "hoodie.datasource.hive_sync.partition_extractor_class": "org.apache.hudi.hive.\
            #    MultiPartKeysValueExtractor",
            "hoodie.parquet.max.file.size": "134217728",
            "hoodie.datasource.write.reconcile.schema": "true",
            "hoodie.datasource.write.schema.evolution.enable": "true"
        }

        logging.info(
            "writing data to hoodi table %s to this path %s started",
            target_table_name,
            target_path,
        )

        # df_kafka.writeStream.trigger(once=True).outputMode("append").format(
        #   "console"
        # ).option("truncate", False).start().awaitTermination()

        df_timestamp_proc.writeStream.trigger(once=True).format(
            "org.apache.hudi"
        ).option("checkpointLocation", check_point_path).options(
            **hudi_options
        ).outputMode(
            "append"
        ).start().awaitTermination()

        logging.info(
            "writing data to hoodi table %s to this path %s completed",
            target_table_name,
            target_path,
        )

        logging.info("Getting count of processed records from target")

        end_time = datetime.now()
        duration = (end_time - start_time).seconds
        processed_df = spark.read.format("hudi").load(target_path)
        records_processed = processed_df.filter(
            F.to_timestamp(
                F.expr(
                    """
        substring(_hoodie_commit_time, 1, 4) || '-' ||
        substring(_hoodie_commit_time, 5, 2) || '-' ||
        substring(_hoodie_commit_time, 7, 2) || ' ' ||
        substring(_hoodie_commit_time, 9, 2) || ':' ||
        substring(_hoodie_commit_time, 11, 2) || ':' ||
        substring(_hoodie_commit_time, 13, 2) || '.' ||
        substring(_hoodie_commit_time, 15, 3)
            """
                ),
                "yyyy-MM-dd HH:mm:ss.SSS",
            )
            > start_time
        ).count()

        logging.info("records_processed :%s", records_processed)

        logging.info("Calling log audit to log the status as job Completed")

        log_audit(
            spark,
            args["JOB_NAME"],
            source_kafka_topic,
            source_type,
            target_table_name,
            target_type,
            "Completed",
            start_time,
            end_time,
            records_processed,
            audit_path,
            audit_table,
        )

        logging.info("job completed sucessfully")

        # job.commit()
    except Exception as e:
        logging.error("An error occurred: %s", str(e))
        end_time = datetime.now()
        duration = (end_time - start_time).seconds
        traceback.print_exc()

        cloudwatch_url = get_cloudwatch_url(region_name, job_name, job_run_id)
        error_code = getattr(
            e, "code", "N/A"
        )  # Some exceptions might have a 'code' attribute
        if error_code == "N/A":
            # Try to parse error code from the exception message if it's in a known format
            error_code = "Specific logic to parse error code from the exception message if possible"

        log = {
            "status": "failure",
            "job_name": job_name,
            "source_table": source_table_name,
            "target_table": target_table_name,
            "start_time": start_time.isoformat(),
            "end_time": end_time.isoformat(),
            "duration": duration,
            "error_code": error_code,
            "error": f"Error: {str(e)}\nTraceback: {traceback.format_exc()}",
        }

        logging.info("Calling log audit to log the status as job Failed")

        log_audit(
            spark,
            args["JOB_NAME"],
            source_kafka_topic,
            source_type,
            target_table_name,
            target_type,
            "Failed",
            start_time,
            end_time,
            None,
            audit_path,
            audit_table,
        )

        log_message = "\n".join([f"{key}: {value}" for key, value in log.items()])

        message = f"Job {job_name} failed. Error: {str(e)}\nTraceback: {traceback.format_exc()}\
              \n\n{log_message}.\n\nView the logs in CloudWatch:{cloudwatch_url}"

        subject = f"{job_name} failed for {target_table_name} table"
        if len(subject) > 100:
            subject = subject[:98] + ".."  # Truncate if needed

        send_sns_notification(subject, message, sns_secret_name, region_name)
        logging.error(f"Error: {str(e)}\nTraceback: {traceback.format_exc()}")
        raise


if __name__ == "__main__":
    main()
