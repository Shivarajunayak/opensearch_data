   
# pylint: disable=import-error, invalid-name, too-many-locals, too-many-statements, broad-except
import sys
import logging
from datetime import datetime,timedelta
import boto3
import json
import traceback
import snowflake.connector
from awsglue.utils import getResolvedOptions
from pyspark.sql.types import StructType, StructField, DoubleType, IntegerType, StringType
from pyspark.sql import functions as F
from pyspark.sql.functions import col,from_unixtime
from hmcl_cv_common_utilities import (
    log_audit,
    load_yaml_config,
    validate_audit_table_with_s3_partition,
    send_sns_notification,
    get_watermark_timestamp,
    get_cloudwatch_url,
    update_watermark_file,
    initialize_spark_session,
    fetch_snowflake_credentials,
    get_snowflake_connection
    )


logging.basicConfig(
    level=logging.INFO, format="%(asctime)s - %(name)s - %(levelname)s - %(message)s"
)


def read_job_param():
    try:
    
        # Define arguments
        arguments = [
            "JOB_NAME",
            "yaml_s3_bucket",
            "yaml_file_key",
            "source_table_name",
            "audit_database"
        ]
        # Get the arguments
        args = getResolvedOptions(sys.argv, arguments)
        job_name = args.get("JOB_NAME")
        job_run_id = args.get("JOB_RUN_ID")
        yaml_s3_bucket = args.get("yaml_s3_bucket")
        yaml_file_key = args.get("yaml_file_key")
        source_table_name = args.get("source_table_name")
        audit_database = args.get("audit_database")
        logging.info("Job parameters read successfully")
        return yaml_s3_bucket,yaml_file_key,job_name,job_run_id,source_table_name,audit_database
        
    except Exception as e:
        logging.error(f"Error while reading job parameters: {str(e)}")
        raise

def get_snowflake_connection(sfUser,sfPassword,sfURL):
    """
    Establish and return a Snowflake connection.
    """
    try:
        conn = snowflake.connector.connect(
        user=sfUser,
        password=sfPassword,
        account = sfURL.split('//')[1].split('.snowflakecomputing.com')[0]
    )
        logging.info("Snowflake connection established.")
        return conn
    except Exception as e:
        logging.error(f"Error establishing Snowflake connection: {str(e)}")
        traceback.print_exc()
        raise
    
def read_yaml_file(s3_client,yaml_s3_bucket,yaml_file_key,source_table_name):
    try:
        # Read YAML file from S3
        yaml_dict = load_yaml_config(s3_client,yaml_s3_bucket,yaml_file_key)
        target_table_name = yaml_dict[source_table_name]['target_table_name']
        sns_secret_name = yaml_dict[source_table_name]['sns_secret_name']
        watermark_bucket = yaml_dict[source_table_name]['watermark_bucket']
        watermark_file_key = yaml_dict[source_table_name]['watermark_file_key']
        audit_path = yaml_dict[source_table_name]['audit_path']
        audit_table = yaml_dict[source_table_name]['audit_table']
        region_name = yaml_dict[source_table_name]['region']
        log_path = yaml_dict[source_table_name]['log_path']
        source_type = yaml_dict[source_table_name]['source_type']
        target_type = yaml_dict[source_table_name]['target_type']
        notification_path = yaml_dict[source_table_name]['notification_path']
        primary_key_column = yaml_dict[source_table_name]['primary_key_column']
        snowflake_secret_name = yaml_dict[source_table_name]['snowflake_secret_name']
        stage_table = yaml_dict[source_table_name]['stage_table']
        stored_procedure = yaml_dict[source_table_name]['stored_procedure']

        logging.info("yaml parameters read successfully")
        return target_table_name,sns_secret_name,watermark_bucket,watermark_file_key,audit_path,audit_table,region_name,log_path,source_type,target_type,notification_path,notification_path,primary_key_column,snowflake_secret_name,stage_table,stored_procedure
    except Exception as e:
        logging.error(f"Error while reading yaml parameters: {str(e)}")
        raise

def read_and_exclude(spark, path, watermark_timestamp, select_columns):
    """
    Read a Hudi table incrementally and exclude specific columns.
    
    :param spark: SparkSession
    :param path: Source path of the Hudi table
    :param watermark_timestamp: Incremental read timestamp
    :param exclude_columns: List of columns to exclude
    :return: Filtered DataFrame or None if table is empty
    """
    try:
        logging.info(f"Reading Hudi table from path: {path} with watermark: {watermark_timestamp}")
        
        source_df = spark.read.format("hudi") \
            .option("hoodie.datasource.query.type", "incremental") \
            .option("hoodie.datasource.read.begin.instanttime", watermark_timestamp) \
            .load(path)

        if source_df.head(1) is None:  # Handle empty table
            logging.warning(f"No data found in Hudi table at path: {path}")
            return None
        num_records = source_df.count()
        req_columns = [col for col in source_df.columns if col in select_columns]
        return source_df.select(*req_columns) , num_records

    except FileNotFoundError:
        logging.error(f"The specified path does not exist: {path}")
        raise

    except Exception as e:
        logging.error(f"Error reading notification incrementally: {str(e)}")
        traceback.print_exc()
        raise

    
def add_buffer_to_hudi_commit_time(hudi_timestamp,num_of_hours):
    
    try:
        # Parse the timestamp to a datetime object
        parsed_time = datetime.strptime(hudi_timestamp[:-3], "%Y%m%d%H%M%S")
        # Subtract one hour
        time_one_hour_back = parsed_time - timedelta(hours=num_of_hours)
        # Format it back to the Hudi timestamp format
        new_hudi_timestamp = time_one_hour_back.strftime("%Y%m%d%H%M%S") + hudi_timestamp[-3:]
        return new_hudi_timestamp
    
    except Exception as e:
        logging.error(f"Error while adding buffer to hudi commit time :{str(e)}")
        raise

def get_max_commit_time(source_df,hoodie_commit_time_col):
    max_commit_time= source_df.agg(F.max(hoodie_commit_time_col)).collect()[0][0]
    return max_commit_time
def update_watermark_with_latesttime(s3,raw_watermark_bucket,raw_watermark_file_key,source_table_name,max_commit_time):
    
    try:
        # Update the watermark for the specific table
        new_hudi_timestamp = add_buffer_to_hudi_commit_time(max_commit_time,1)
        update_watermark_file(s3,new_hudi_timestamp,raw_watermark_bucket,raw_watermark_file_key,source_table_name)
        return True
    except Exception as e:
        logging.error(f"Error while updating the watermark file:{str(e)}")
        raise

def check_table_exists(spark,conn, target_table_name, job_name, sns_secret_name, region_name, start_time, audit_path, audit_table,source_table_name,source_type,target_type):
    # Extract the table name (assumes target_table is in format 'database.schema.table')
    table_name = target_table_name.split('.')[2]
    
    # Create the query to check if the table exists
    check_table_query = f"SHOW TABLES LIKE '{table_name}'"
    
    # Execute the query to check if the table exists
    cursor = conn.cursor()
    cursor.execute(check_table_query)
    table_exists = cursor.fetchone()
    
    if not table_exists:
        # Log the error and notify via SNS
        logging.error(f"Target table {target_table_name} does not exist. Aborting job.")
        end_time = datetime.now()
        # Log the audit information
        log_audit(spark, job_name, source_table_name, source_type, target_table_name, target_type, "Aborted", start_time, end_time, None, audit_path, audit_table)
        
        # Send SNS notification about the failure
        subject = f"{job_name} failed - Missing Target Table"
        if len(subject)>100:
            subject = subject[:97] + '..'
        send_sns_notification("job failed", f"The target table {target_table_name} does not exist.", sns_secret_name, region_name)
        
        # Optional: Raise an exception or return early to stop the job
        raise Exception(f"Target table {target_table_name} does not exist. Job aborted.")
    
def fetch_schemas(source_df):
    """
    Fetches schemas of source dataframe.
    """
    source_columns = set([col_schema.name for col_schema in source_df.schema])
    return source_columns



def compare_schemas(source_columns, target_table_columns):
    """
    Compares the schemas and identifies missing and new columns,
    while ignoring specified columns for the new column comparison.
    """
    # List of columns to exclude when computing new columns
    excluded_columns = {
        "TCU_METADATA_PART_NUMBER", "HOUR_TCU", "VEHICLEPROPERTIES_VEHICLETYPE", "TCU_METADATA_BLE_PIN", 
        "TOPIC_TCU", "TENANT_ID", "TCU_ID_tcu", "_HOODIE_PARTITION_PATH_TCU", "_HOODIE_FILE_NAME_TCU", 
        "KEY_TCU", "YEAR_TCU", "TCU_METADATA_BLE_PROTOCOL_VERSION", "TCU_METADATA_TCU_HW_VERSION", 
        "VEHICLEPROPERTIES_MAKE", "VEHICLESTATUS", "KAFKA_TIMESTAMP_TCU", "OFFSET_TCU", "PARTITION_TCU", 
        "TCU_METADATA_SSID_PASSWORD", "VEHICLEPROPERTIES_YEAR", "TCU_METADATA_SSID", "_HOODIE_COMMIT_TIME_LAND_CAL_TCU", 
        "TIMESTAMP", "CREATEDTSP", "VEHICLEPROPERTIES_BATTERYCAPACITY", "OPERATION_tcu", 
        "VEHICLEPROPERTIES_COLOR", "TENANT_ID_tcu", "DAY_TCU", "VEHICLEPROPERTIES_FUELTYPE", 
        "TIMESTAMP_TS", "TCU_METADATA_MANUFACTURER_LOCATION", "TCU_METADATA_MANUFACTURER", 
        "_HOODIE_COMMIT_SEQNO_TCU", "_HOODIE_RECORD_KEY_TCU", "TCU_METADATA_TCU_SW_VERSION", 
        "CREATEDTSP_TS", "MONTH_TCU", "VEHICLEPROPERTIES_ELECTRICRANGE", "IMEI_tcu", 
        "VEHICLEPROPERTIES_BLE_PIN", "VEHICLEPROPERTIES_VDS"
    }

    # Filter source columns to exclude the specified columns
    filtered_source_columns = source_columns - excluded_columns

    # Compute missing and new columns
    missing_columns = list(target_table_columns - source_columns)
    new_columns = list(filtered_source_columns - target_table_columns)

    return missing_columns, new_columns


def handle_schema_mismatch(spark, job_name, source_table_name, target_table_name, start_time, audit_path, audit_table, sns_secret_name, missing_columns,region_name):
    """
    Handles schema mismatches by logging and raising a notification.
    """
    schema_status = "Aborted"
    error_message = f"Missing columns in source table: {', '.join(missing_columns)}"
    logging.error(error_message)
    
    # Log the error
    end_time = datetime.now()
    log_audit(spark, job_name, source_table_name, "source_type", target_table_name, "target_type", schema_status, start_time, end_time, None, audit_path, audit_table)
    
    # Send SNS notification
    subject = f"Job {job_name} - Aborted for table {source_table_name} - Schema Validation Failed"
    send_sns_notification(subject[:98] + '..' if len(subject) > 100 else subject, error_message, sns_secret_name,region_name)
    raise ValueError(error_message)

def handle_new_columns(sns_secret_name, job_name, source_table_name, new_columns,region_name):
    """
    Handles the detection of new columns by sending a notification.
    """
    schema_status = "New columns detected"
    new_columns_message = f"New columns detected in source table: {', '.join(new_columns)}"
    logging.warning(new_columns_message)
    
    # Send SNS notification
    subject = f"Job - {job_name} Succeeded for table {source_table_name}- with new Schema "
    send_sns_notification(subject[:98] + '..' if len(subject) > 100 else subject, new_columns_message, sns_secret_name,region_name) 
    return schema_status 

def get_evaluated_schema(spark,conn,source_df, target_table_name, sns_secret_name, source_table_name, start_time, job_name, audit_path, audit_table,region_name):
    """
    Adjust schema based on target table schema and send notifications if there are discrepancies.
    """
    try:
        schema_status = "Success"
        
        # Fetch schema from PostgreSQL and validate
        source_columns = fetch_schemas(source_df)
        # required_cols = ['_hoodie_commit_time','id','event_name','payload','notification_logged_tsp'] 
        # source_columns = fetch_schemas(source_df, required_cols)
        logging.info(f"source_schema : {source_columns}")
        

        target_table_columns = get_table_schema(conn, target_table_name, exclude_columns=['ALERT_NAME', 'ALERT_RECEIVED_AT_TIMESTAMP', 'SNO'])
        logging.info(f"target_table_columns : {target_table_columns}")
        # Compare schemas and detect missing/new columns
        missing_columns, new_columns =compare_schemas(source_columns, target_table_columns)
        
        if missing_columns:
            handle_schema_mismatch(spark, job_name, source_table_name, target_table_name, start_time, audit_path, audit_table, sns_secret_name, missing_columns,region_name)
        elif new_columns:
            handle_new_columns(sns_secret_name, job_name, source_table_name, new_columns,region_name)
        return schema_status,target_table_columns

    except Exception as e:
        logging.error("An error occurred while fetching schema from source table: %s", str(e))
        logging.error("Traceback: %s", traceback.format_exc())
        raise

def standardize_columns(notification, vehicles):
    """
    Handles duplicate column names by renaming columns in the vehicles DataFrame.
    """
    try:
        duplicate_columns = set(notification.columns).intersection(set(vehicles.columns)) - {"tcu_id"}
        for col_name in duplicate_columns:
            vehicles = vehicles.withColumnRenamed(col_name, f"{col_name}_tcu")
        return vehicles
    except Exception as e:
        logging.error(f"Error normalizing column names: {str(e)}")
        traceback.print_exc()
        raise

def normalize_column_names(df):
            return df.toDF(*[col_name.upper() for col_name in df.columns])
        
def join_notification_with_vehicles(notification, vehicles):
    """
    Joins notification with vehicles on tcu_id.
    """
    try:
        vehicle_details = notification.join(vehicles, notification["tcu_id"]==vehicles["TCU_ID_tcu"], "inner")
        num_records = vehicle_details.count()
        logging.info(f"Joined notification with vehicles. Final row count: {num_records}")
        return vehicle_details,num_records
    except Exception as e:
        logging.error(f"Error joining notification with vehicles: {str(e)}")
        traceback.print_exc()
        raise

def get_table_schema(conn, table_name, exclude_columns=None):
    """
    Retrieve the schema of the specified table as a list of column names.
    Optionally exclude specific columns from the schema.
    
    :param conn: Snowflake connection object
    :param table_name: Name of the table
    :param exclude_columns: List of column names to exclude (case-sensitive)
    :return: List of column names in the schema (excluding specified columns)
    """
    exclude_columns = exclude_columns or []
    schema_query = f"DESCRIBE TABLE {table_name}"
    schema_result = conn.cursor().execute(schema_query)
    schema_columns = [row[0] for row in schema_result]  # Assuming the first column in result is the column name
    # Exclude specified columns
    schema_columns = set([col for col in schema_columns if col not in exclude_columns])
    return schema_columns

def get_snowflake_options(secret_dict):
    """
    Create a dictionary of Snowflake options for Spark DataFrame writes.
    """
    return {
        "sfURL": secret_dict['url'],
        "sfDatabase": secret_dict['database'],
        "sfSchema": secret_dict['schema'],
        "sfWarehouse": secret_dict['warehouse'],
        "sfRole": secret_dict['role'],
        "sfUser": secret_dict['username'],
        "sfPassword": secret_dict['password']
    }

def write_to_snowflake(df, table_name, snowflake_secret_name):
    """
    Write the Spark DataFrame to a Snowflake table.

    Args:
        df (pyspark.sql.DataFrame): The Spark DataFrame to be written.
        table_name (str): The target Snowflake table name.
        snowflake_secret_name (str): The name of the secret containing Snowflake credentials.
    """
    try:
        # Fetch Snowflake credentials
        secret_dict = fetch_snowflake_credentials(snowflake_secret_name)
        logging.info("Snowflake credentials loaded successfully.")

        # Prepare Snowflake options
        options = get_snowflake_options(secret_dict)

        # Write DataFrame to Snowflake
        logging.info(f"Starting data write to Snowflake table: {table_name}")
        df.write \
            .format("snowflake") \
            .options(**options) \
            .option("dbtable", table_name) \
            .mode("overwrite") \
            .save()
        logging.info(f"Data written successfully to Snowflake stage table: {table_name}")
    except Exception as e:
        logging.error(f"Failed to write to Snowflake: {str(e)}")
        raise

def execute_merge_query(conn,query):
    """Execute the Snowflake MERGE query."""
    
    try:
        cursor = conn.cursor()
        cursor.execute(query)
    except Exception as e:
        logging.error(f"An error occured while merging to target: {str(e)}")
    
def execute_stored_procedure(conn,stored_procedure,watermark_timestamp):
    try:
        cursor = conn.cursor()
        sp_call =  f"CALL {stored_procedure}({watermark_timestamp});"
        cursor.execute(sp_call)
        result = cursor.fetchone()
        logging.info(f"Stored Procedure executed successfully. Output: {result[0]}")
        return True
    except Exception as e:
        logging.error(f"An error occured while calling SP- {sp_call} : {str(e)}")
        return False
    finally:
        cursor.close()
        conn.close()

def merge_source_to_target(conn, notification, stage_table, target_table_name, snowflake_secret_name, primary_key_column):
    """
    Merge the source data from the specified stage table into the Snowflake target table.

    Parameters:
    - conn: Snowflake connection object.
    - vehicle_details: DataFrame containing vehicle details.
    - stage_table (str): Name of the Snowflake staging table.
    - target_table_name (str): Name of the Snowflake target table.
    - snowflake_secret_name (str): Secret name for Snowflake credentials.
    - primary_key_column (str): The primary key column used for the merge.
    """

    # Step 3: Write Data to Snowflake Staging Table
    write_to_snowflake(notification, stage_table, snowflake_secret_name)

    # Step 4: Construct the Merge Query
    merge_query = f"""
    MERGE INTO {target_table_name} AS target
    USING (
        SELECT DISTINCT
            "ID", "VID","EVENT_NAME", "LATITUDE",  "LONGITUDE", "NO_OF_SATELLITE", "NOTIFICATION_LOGGED_TSP", "ALERT_RECEIVED_AT_TIMESTAMP", "VEHICLE_MODE", "_HOODIE_COMMIT_TIME"
        FROM {stage_table}
    ) AS source
    ON target."{primary_key_column}" = source."{primary_key_column}"
    WHEN MATCHED THEN UPDATE SET
        target."ID" = source."ID",
        target."VID" = source."VID",
        target."ALERT_NAME" = source."EVENT_NAME",
        target."LATITUDE" = source."LATITUDE",
        target."LONGITUDE" = source."LONGITUDE",
        target."NO_OF_SATELLITE" = source."NO_OF_SATELLITE",
        target."NOTIFICATION_LOGGED_TSP" = source."NOTIFICATION_LOGGED_TSP",
        target."ALERT_RECEIVED_AT_TIMESTAMP" = source."ALERT_RECEIVED_AT_TIMESTAMP",
        target."VEHICLE_MODE" = source."VEHICLE_MODE",
        target."_HOODIE_COMMIT_TIME" = source."_HOODIE_COMMIT_TIME"
    WHEN NOT MATCHED THEN INSERT (
        "ID", "VID","ALERT_NAME", "LATITUDE", "LONGITUDE", "NO_OF_SATELLITE", "NOTIFICATION_LOGGED_TSP", "ALERT_RECEIVED_AT_TIMESTAMP", "VEHICLE_MODE",_HOODIE_COMMIT_TIME
    ) VALUES (
        source."ID", source."VID", source."EVENT_NAME", source."LATITUDE", source."LONGITUDE", source."NO_OF_SATELLITE", source."NOTIFICATION_LOGGED_TSP", source."ALERT_RECEIVED_AT_TIMESTAMP", source."VEHICLE_MODE",source."_HOODIE_COMMIT_TIME"
    );
    """

    # Step 5: Execute the Merge Query
    execute_merge_query(conn, merge_query)
    logging.info(f"Data written successfully to Snowflake target table: {target_table_name}")

def main():
    
    try:
        start_time = datetime.now()
        logging.info(f"Job started at {start_time}")
        
        #read job parameters
        yaml_s3_bucket,yaml_file_key,job_name,job_run_id,source_table_name,audit_database = read_job_param()
        
        logging.info(f"job name : {job_name}")
        logging.info(f"source table name : {source_table_name}.{audit_database}.{yaml_file_key}")
        
        logging.info("job_name=%s", job_name+"/"+source_table_name)
        #initialize spark job
        spark = initialize_spark_session()
        
        #create an S3 client
        s3 = boto3.client('s3')

        # read necessary  parameters from yaml file

        target_table_name,sns_secret_name,watermark_bucket,watermark_file_key,audit_path,audit_table,\
        region_name,log_path,source_type,target_type,\
        notification_path,notification_path,primary_key_column,snowflake_secret_name,stage_table,stored_procedure = read_yaml_file(s3,yaml_s3_bucket,yaml_file_key,source_table_name)
    except Exception as e:
        logging.error(f"Error in initial steps: {str(e)}")
        traceback.print_exc()
        raise

    try:
        year_partitioned=start_time.year
        month_partitioned=start_time.month
        #validate audit table
        is_validate = validate_audit_table_with_s3_partition(spark,sns_secret_name,start_time,audit_path,audit_path,source_table_name,target_table_name,job_name,region_name,year_partitioned,month_partitioned )

        if is_validate == False:
            logging.error("Job is being aborted due to concurrent execution.")
            return
        # Log audit
        log_audit(
                    spark,job_name,source_table_name,source_type,target_table_name,target_type,\
                    "Started",start_time,None,None,audit_path,audit_table,
                )
        #read watermark timestamp
        watermark_timestamp = get_watermark_timestamp(s3,watermark_bucket,watermark_file_key)
        
        
        
        # schema_status,target_table_columns = get_evaluated_schema(spark,conn,notification, target_table_name, sns_secret_name, source_table_name, start_time, job_name, audit_path, audit_table,region_name)
        # logging.info(f"Schema status after evaluation: {schema_status}")
        
        exclude_columns = ['_hoodie_record_key', '_hoodie_commit_seqno','_hoodie_file_name', '_hoodie_partition_path', 
        '_hoodie_commit_time_land_cal','kafka_timestamp','key','partition','offset','_hoodie_commit_time_land_cal','topic', 'year', 'month', 'day', 'hour']
        # read data from landing table incrementally
        select_columns = ['_hoodie_commit_time','id','vid','event_name','payload_lat','payload','notification_logged_tsp']
        notification , num_records = read_and_exclude(spark, notification_path, watermark_timestamp, select_columns)
        logging.info(f"Read {notification.count()} rows from notification incrementally.")
            
        json_schema = StructType([
        StructField("lat", DoubleType(), True),
        StructField("long", DoubleType(), True)
        ])

        # Parse the JSON column 'c' into a struct with 'lat' and 'long' fields
        notification_parsed = notification.withColumn("json_data", F.from_json(F.col("payload"), json_schema))

        # Extract 'lat' and 'long' from the parsed JSON column
        notification_parsed = notification_parsed.withColumn("Latitude", F.col("json_data.lat")) \
                                    .withColumn("Longitude", F.col("json_data.long")) \
                                    .drop("json_data") 
        # Drop the intermediate JSON struct column      
        # Step 3: Read filtered vehicles data
        notification = (
                notification_parsed
                .withColumn('NO_OF_SATELLITE', F.lit(None).cast(IntegerType()))  # Cast to Integer
                .withColumn('VEHICLE_MODE', F.lit(None).cast(StringType()))  # Cast to String
            )

        notification = notification.withColumn("ALERT_RECEIVED_AT_TIMESTAMP", from_unixtime(col("NOTIFICATION_LOGGED_TSP") / 1000).cast("timestamp"))


        # Normalize column names in both DataFrames
        notification = normalize_column_names(notification)

        max_commit_time=get_max_commit_time(notification,'_HOODIE_COMMIT_TIME')

        # notification = notification.drop('_HOODIE_COMMIT_TIME')
        logging.info(f"notification schema is : {notification.schema}")
        logging.info(f"max_commit_time : {max_commit_time}")
        
        if num_records > 0:
            # Initialize Snowflake connection
            secret_dict = fetch_snowflake_credentials(snowflake_secret_name)
            logging.info("Snowflake credentials loaded successfully")
            sfURL = secret_dict['url']
            sfPassword = secret_dict['password']
            sfUser = secret_dict['username']
            
            conn=get_snowflake_connection(sfUser,sfPassword,sfURL)
            try:
                check_table_exists(spark,conn, target_table_name, job_name, sns_secret_name, region_name, start_time, audit_path, audit_table,source_table_name,source_type,target_type)
                # Continue job logic if table exists
            except Exception as e:
                logging.error(str(e))

            # schema_status,target_table_columns = get_evaluated_schema(spark,conn,notification, target_table_name, sns_secret_name, source_table_name, start_time, job_name, audit_path, audit_table,region_name)
            # logging.info(f"Schema status after evaluation: {schema_status}")

            # if schema_status == "Aborted":
            #     logging.error("Schema validation failed. Aborting the job.")
            #     return False
            
            logging.info("Schema validation successful. Proceeding with merge operation.")

            merge_source_to_target(conn,notification, stage_table, target_table_name,snowflake_secret_name,primary_key_column)

            sp_success = execute_stored_procedure(conn,stored_procedure, watermark_timestamp)

            if not sp_success:
                logging.error("Stored procedure execution failed. Stopping job without updating watermark.")
                raise Exception("Stored procedure execution failed.")  # Stop job immediately
                
                #update watermark file
            update_watermark_with_latesttime(s3,watermark_bucket,watermark_file_key,source_table_name,max_commit_time)
            
        #get cloudwatch details
        cloudwatch_url = get_cloudwatch_url(region_name, job_name, job_run_id)
        end_time = datetime.now()
        duration = (end_time - start_time).seconds
        
    
        # Log audit
        log_audit(
                spark,job_name,source_table_name,source_type,target_table_name,target_type,"Completed",start_time,end_time,\
                    num_records,audit_path,audit_table,
                )
        logging.info(f"Job completed successfully with processing {num_records} rows in {duration} seconds")
        
        log = {
            "status": "success",
            "job_name": job_name,
            "source_table": source_table_name,
            "target_table": target_table_name,
            "start_time": start_time.isoformat(),
            "end_time": end_time.isoformat(),
            "duration": duration,
            "num_records": num_records
        }
                    
    except Exception as e:
        logging.error("Job failed with error: %s", str(e))
        traceback.print_exc()
        end_time = datetime.now()
        duration = end_time - start_time
        logging.error(f"Job failed in {duration} seconds")
        #get cloudwatch details 
        cloudwatch_url = get_cloudwatch_url(region_name, job_name, job_run_id)
        log = {
                "status": "failure",
                "job_name": job_name,
                "source_table": source_table_name,
                "target_table": target_table_name,
                "start_time": start_time.isoformat(),
                "end_time": end_time.isoformat(),
                "duration": duration,
                "error": f"Error: {str(e)}\nTraceback: {traceback.format_exc()}"
            }
        
        # Log audit
        log_audit(
                spark,job_name,source_table_name,source_type,target_table_name,target_type,\
                "Failed",start_time,end_time,None,audit_path,audit_table,
                )
            
        log_message = "\n".join([f"{key}: {value}" for key, value in log.items()])
        message = f"Job -{job_name} failed. Transformation returned None.\n\n{log_message}.\n\nView the logs in CloudWatch:{cloudwatch_url}"
        subject=f"Job Failed : Job - {job_name}"
        send_sns_notification(subject, message, sns_secret_name,region_name)
        raise

    finally:
        final_log = log.copy() 
        yaml_params = {
        "table_name": source_table_name,
        "audit_table": audit_table, 
        "audit_path":audit_path,
        "yaml_s3_bucket": yaml_s3_bucket,
        "yaml_file_path": yaml_file_key,
        "target_table_name": target_table_name}

        final_log.update(yaml_params)
        dt = datetime.now()
        epoch_time = int(dt.timestamp() * 1000)
        s3 = boto3.client('s3', region_name='ap-south-1')
        s3.put_object(Bucket=watermark_bucket, Key=f'logs/{job_name}-{target_table_name}_{epoch_time}_logs.json', Body=json.dumps(final_log))
      
if __name__ == "__main__":
    main()
