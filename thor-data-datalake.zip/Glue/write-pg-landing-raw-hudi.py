   
# pylint: disable=import-error, invalid-name, too-many-locals, too-many-statements, broad-except
import sys
import logging
from datetime import datetime,timedelta
import boto3
import json
import traceback
from awsglue.utils import getResolvedOptions
from awsglue.context import GlueContext
from awsglue.job import Job
from pyspark.sql import functions as F
from hmcl_cv_common_utilities import (
    log_audit,
    normalize_json_udf,
    load_yaml_config,
    send_sns_notification,
    get_watermark_timestamp,
    get_cloudwatch_url,
    update_watermark_file,
    initialize_spark_session,
    validate_audit_table_with_s3_partition
    )
from pyspark.sql.functions import max
from pyspark.sql.functions import  explode, map_keys
from pyspark.sql.functions import concat_ws
from pyspark.sql.functions import explode, from_json, schema_of_json


logging.basicConfig(
    level=logging.INFO, format="%(asctime)s - %(name)s - %(levelname)s - %(message)s"
)


def read_job_param():
    try:
    
        # Define arguments
        arguments = [
            "JOB_NAME",
            "yaml_s3_bucket",
            "yaml_file_key",
            "source_table_name",
            "audit_database",
        ]
        # Get the arguments
        args = getResolvedOptions(sys.argv, arguments)
        job_name = args.get("JOB_NAME")
        job_run_id = args.get("JOB_RUN_ID")
        yaml_s3_bucket = args.get("yaml_s3_bucket")
        yaml_file_key = args.get("yaml_file_key")
        source_table_name = args.get("source_table_name")
        audit_database = args.get("audit_database")
        logging.info("Job parameters read successfully")
        return yaml_s3_bucket,yaml_file_key,job_name,job_run_id,source_table_name,audit_database
        
    except Exception as e:
        logging.error(f"Error while reading job parameters: {str(e)}")
        raise


def read_yaml_file(s3_client,yaml_s3_bucket,yaml_file_key,source_table_name):
    try:
        # Read YAML file from S3
        yaml_dict = load_yaml_config(s3_client,yaml_s3_bucket,yaml_file_key)
        schema = yaml_dict['tables'][source_table_name]['columns']
        use_case_name = yaml_dict['tables'][source_table_name]['use_case_name']
        partition_extract_col = yaml_dict['tables'][source_table_name]['partition_extract_col']
        target_table_name = yaml_dict['tables'][source_table_name]['target_table_name_raw']
        landing_bucket = yaml_dict['tables'][source_table_name]['landing_bucket']
        raw_bucket = yaml_dict['tables'][source_table_name]['raw_bucket']
        table_prefix = yaml_dict['tables'][source_table_name]['table_prefix']
        table_append_land = yaml_dict['tables'][source_table_name]['table_append_land']
        table_append_raw = yaml_dict['tables'][source_table_name]['table_append_raw']
        target_database = yaml_dict['tables'][source_table_name]['target_database']
        partition_field = yaml_dict['tables'][source_table_name]['partition_field']
        recordkey = yaml_dict['tables'][source_table_name]['recordkey']
        sns_secret_name = yaml_dict['tables'][source_table_name]['sns_secret_name']
        raw_watermark_bucket = yaml_dict['tables'][source_table_name]['watermark_bucket']
        raw_watermark_file_key = yaml_dict['tables'][source_table_name]['watermark_file_key_raw']
        json_columns = yaml_dict['tables'][source_table_name]['json_columns']
        precombine_field = yaml_dict['tables'][source_table_name]['precombine_field']
        audit_path = yaml_dict['tables'][source_table_name]['audit_path']
        audit_table = yaml_dict['tables'][source_table_name]['audit_table']
        region_name = yaml_dict['tables'][source_table_name]['region']
    
        logging.info(f"Schema: {schema}")
        
        # landing hudi table path
        source_hudi_table_path = "s3://" + landing_bucket + "/" + table_prefix + "_" + table_append_land + "/"
        
        table_append_raw =  use_case_name + '_' + table_append_raw
        target_hudi_table_path = "s3://" + raw_bucket + "/" + table_prefix + "_" + table_append_raw 
        logging.info("yaml parameters read successfully")
        return target_table_name,target_database,source_hudi_table_path,\
            target_hudi_table_path,recordkey,partition_field,sns_secret_name,raw_watermark_bucket,\
            raw_watermark_file_key,partition_extract_col,landing_bucket,raw_bucket,table_prefix,table_prefix,\
                table_append_land,table_append_raw,json_columns,precombine_field,audit_path,audit_table,region_name
    except Exception as e:
        logging.error(f"Error while reading yaml parameters: {str(e)}")
        raise

def load_df_into_target_table(source_df,target_table_name,target_database,target_hudi_table_path,recordkey,partition_field,precombine_field):
    """
    This function loads  data into raw
    """
    try:
        logging.info(f"PARTITION VALUES  (partition_field) in main table load: {partition_field}")
        # Define Hudi options
        source_df.write.format("hudi") \
            .option("hoodie.table.name", target_table_name) \
            .option("hoodie.datasource.write.storage.type", "COPY_ON_WRITE") \
            .option("hoodie.datasource.write.recordkey.field", recordkey) \
            .option("hoodie.datasource.write.partitionpath.field", partition_field) \
            .option("hoodie.datasource.write.precombine.field", precombine_field) \
            .option("hoodie.datasource.write.operation", "upsert") \
            .option("hoodie.datasource.hive_sync.enable", "true") \
            .option("hoodie.datasource.hive_sync.database", target_database) \
            .option("hoodie.datasource.hive_sync.table", target_table_name) \
            .option("hoodie.datasource.hive_sync.use_jdbc", "false") \
            .option("hoodie.datasource.hive_sync.mode", "hms") \
            .option("hoodie.datasource.hive_sync.sync_as_datasource", "false") \
            .option("hoodie.datasource.hive_sync.support_timestamp", "true") \
            .option("hoodie.avro.schema.allow.empty", "true") \
            .option("hoodie.schema.on.read.enable", "true") \
            .option("hoodie.datasource.write.schema.evolution.enable", "true") \
            .option("hoodie.parquet.max.file.size", "134217728") \
            .option("hoodie.upsert.shuffle.parallelism", 200) \
            .mode("append") \
            .save(target_hudi_table_path)
        ## .option("hoodie.datasource.hive_sync.partition_fields": partition_field) \
        logging.info(f"Data loaded successfully into {target_table_name} table,\
            no.of processed records count: {source_df.count()}")
        return True
    except Exception as e:
        logging.error(f"Error while loading the data into table:{target_table_name}, {str(e)}")
        raise

def read_source_table(spark,watermark_timestamp,source_hudi_table_path):
    try:
        # Read the Hudi table incrementally
        source_df = spark.read.format("hudi")\
            .option("hoodie.datasource.query.type", "incremental")\
            .option("hoodie.datasource.read.begin.instanttime", watermark_timestamp)\
            .load(source_hudi_table_path)
        
            
        logging.info(f"data read successfully from landing, no.of new records in landing :{source_df.count()}")
        return source_df,source_df.count()
    except Exception as e:
        logging.error(f"Error while reading the data from landing:{str(e)}")
        raise
    
def add_buffer_to_hudi_commit_time(hudi_timestamp,num_of_hours):
    
    try:
        # Parse the timestamp to a datetime object
        parsed_time = datetime.strptime(hudi_timestamp[:-3], "%Y%m%d%H%M%S")
        # Subtract one hour
        time_one_hour_back = parsed_time - timedelta(hours=num_of_hours)
        # Format it back to the Hudi timestamp format
        new_hudi_timestamp = time_one_hour_back.strftime("%Y%m%d%H%M%S") + hudi_timestamp[-3:]
        return new_hudi_timestamp
    
    except Exception as e:
        logging.error(f"Error while adding buffer to hudi commit time :{str(e)}")
        raise
    
def update_watermark_with_latesttime(s3,source_df,raw_watermark_bucket,raw_watermark_file_key,source_table_name):
    
    try:
        # Update the watermark for the specific table
        max_commit_time = source_df.agg(max("_hoodie_commit_time")).collect()[0][0]
        new_hudi_timestamp = add_buffer_to_hudi_commit_time(max_commit_time,1)
        update_watermark_file(s3,new_hudi_timestamp,raw_watermark_bucket,raw_watermark_file_key,source_table_name)
        return True
    except Exception as e:
        logging.error(f"Error while updating the watermark file:{str(e)}")
        raise
    
def load_data_into_hudi_raw(spark_df,json_table_name,recordkey,partition_field,precombine_field,target_database,json_target_hudi_table_path):
    try:
        # logging.info("Defining Hudi options")
        spark_df.write.format("hudi") \
            .option("hoodie.table.name", json_table_name) \
            .option("hoodie.datasource.write.storage.type", "MERGE_ON_READ") \
            .option("hoodie.datasource.write.recordkey.field", recordkey) \
            .option("hoodie.datasource.write.partitionpath.field", partition_field) \
            .option("hoodie.datasource.write.precombine.field", precombine_field) \
            .option("hoodie.datasource.write.operation", "upsert") \
            .option("hoodie.datasource.hive_sync.enable", "true") \
            .option("hoodie.datasource.hive_sync.database", target_database) \
            .option("hoodie.datasource.hive_sync.table", json_table_name) \
            .option("hoodie.datasource.hive_sync.use_jdbc", "false") \
            .option("hoodie.datasource.hive_sync.mode", "hms") \
            .option("hoodie.datasource.hive_sync.sync_as_datasource", "false") \
            .option("hoodie.datasource.hive_sync.support_timestamp", "true") \
            .option("hoodie.avro.schema.allow.empty", "true") \
            .option("hoodie.schema.on.read.enable", "true") \
            .option("hoodie.datasource.write.schema.evolution.enable", "true") \
            .option("hoodie.parquet.max.file.size", "134217728") \
            .option("hoodie.upsert.shuffle.parallelism", 200) \
            .mode("append") \
            .save(json_target_hudi_table_path)
        return True
    except Exception as e:
        logging.error(f"Error while loading the data into hudi table {json_table_name} :{str(e)}")
        raise
    
def add_missing_columns_into_sourcedf(spark,source_df,json_table_name,json_target_hudi_table_path):
    
    try:
        existing_column_names = spark.read.format("hudi").load(json_target_hudi_table_path).schema.fieldNames()
        target_schema_columns = [col for col in existing_column_names if not col.startswith('_hoodie_')]
        
        target_schema_columns = set(target_schema_columns)
        source_schema_columns = set(source_df.columns)
        logging.info(f"Target_Schema_columns: {target_schema_columns}")
        logging.info(f"Source_Schema_columns: {source_schema_columns}")
        logging.info(f"Difference between target - source coulums : {target_schema_columns - source_schema_columns}")
        # Add missing columns with null values
        for column_name in target_schema_columns - source_schema_columns:
                source_df = source_df.withColumn(column_name, F.lit("na"))
        logging.info("flattenning data frame after adding into missing columns")
        logging.info(f"flattening df  columns names: {source_df.columns}")
        logging.info(f"Existing column names in {json_table_name} Table :{existing_column_names}")

    except Exception as e:
        existing_column_names = []
        logging.info(f"not able to read the table {json_table_name}, error: %s", str(e))
        
    return source_df,existing_column_names

def process_json_columns(spark,source_df,json_column,target_table_name,target_database,\
    target_hudi_table_path,recordkey,partition_field,sns_secret_name,precombine_field,region_name):
    
    try:
        
        json_column_name = json_column["json_column_name"]
        json_column_type = json_column["json_type"]
        json_unique_key = json_column["unique_column"]
        json_table_name = target_table_name+"_"+json_column_name
        json_target_hudi_table_path = target_hudi_table_path+"_"+json_column_name
        
        
        columns_to_select = recordkey.split(",")
        columns_to_select.extend(partition_field.split(","))
        columns_to_select.extend(precombine_field.split(","))
        columns_to_select.append(json_column_name)
        logging.info(f"Columns to select from original table :{columns_to_select}")
        
        df = source_df.select(*columns_to_select)
        
        if json_column_type == "list_of_json":
            
            json_sample="[]"
            inferred_schema = schema_of_json(json_sample)
            logging.info(f"inferred_schema : {inferred_schema}")
            df_with_array = df.withColumn(json_column_name, from_json(F.col(json_column_name), inferred_schema))
            df_explod = df_with_array.withColumn(json_column_name, explode(F.col(json_column_name)))
            df = df_explod
        
        normalized_df = df.withColumn("json_normalized", normalize_json_udf(F.col(json_column_name)))
        
        
        null_recordkey_df = normalized_df.filter(F.col("json_normalized").isNull()).select(recordkey.split(","))
        logging.info(f"number of null records after json_normalized :{null_recordkey_df.count()}")
        if null_recordkey_df.count() > 0:
            record_key_columns = null_recordkey_df.columns
            recordkey_merged_df = null_recordkey_df.select(concat_ws("_", *record_key_columns).alias("recordkey_merged_column"))
        
            # Collect the values of the merged column into a list
            recordkey_merged_list = recordkey_merged_df.rdd.map(lambda row: row["recordkey_merged_column"]).collect()
            logging.info(f"not able to load the following records into {json_table_name} table,\
            {recordkey} : {set(recordkey_merged_list)} ")
            
        normalized_df = normalized_df.filter(F.col("json_normalized").isNotNull())
        
        if normalized_df.count() > 0:
            # Get all the keys present in the json_normalized map column
            keys = normalized_df.select(explode(map_keys(F.col("json_normalized")))).distinct().rdd.flatMap(lambda x: x).collect()
            logging.info(f"Json column fields : {keys}")
            
            # Dynamically create columns from map keys
            for key in keys:
                normalized_df = normalized_df.withColumn(f"{json_column_name}_{key}", F.col("json_normalized").getItem(key))
            #Drop the json_normalized column (if you don't need it anymore)
            flattened_df = normalized_df.drop("json_normalized",json_column_name)
            
            if json_column_type == "list_of_json":
                flattened_df = flattened_df.filter(F.col(f"{json_column_name}_{json_unique_key.lower()}").isNotNull())
                if flattened_df.count() > 0:
                    unique_columns = recordkey.split(',')
                    unique_columns.append(f"{json_column_name}_{json_unique_key.lower()}")
                    json_table_unique_key = '_'.join(unique_columns)
                    flattened_df = flattened_df.withColumn(json_table_unique_key, concat_ws("_", *unique_columns))
                    recordkey = json_table_unique_key
                else:
                    logging.info(f" zero records loaded into {json_table_name} table")
                    return
            flattened_df,existing_column_names = add_missing_columns_into_sourcedf(spark,flattened_df,json_table_name,json_target_hudi_table_path)
            # Define Hudi options
            # logging.info("Defining Hudi options")
            load_data_into_hudi_raw(flattened_df,json_table_name,recordkey,partition_field,precombine_field,target_database,json_target_hudi_table_path)
                
            new_fields = [f"{json_column_name}_{x}" for x in  keys if f"{json_column_name}_{x}" not in existing_column_names]
            if len(new_fields) > 0:
                subject = f"New columns added into the {json_table_name} table"
                message = f"New columns detected in {json_table_name} table, new columns are : {', '.join(new_fields)}"
                send_sns_notification(subject, message, sns_secret_name,region_name)
                logging.info(message)
            logging.info(f"Data loaded successfully into {json_table_name} table,\
                    No.of records processed : {flattened_df.count()}")
            return
        logging.info(f" zero records loaded into {json_table_name} table")
        return 
    
    except Exception as e:
        logging.error(f"Error while processing the json fields:{str(e)}")
        raise

def main():
    
    try:
        start_time = datetime.now()
        logging.info(f"Job started at {start_time}")
        
        #read job parameters
        yaml_s3_bucket,yaml_file_key,job_name,job_run_id,source_table_name,audit_database = read_job_param()
        logging.info("job_name=%s", job_name+"/"+source_table_name)
        
        #initialize spark job
        spark = initialize_spark_session()
        
        #create an S3 client
        s3 = boto3.client('s3')

        #read necessary  parameters from yaml file
        target_table_name,target_database,source_hudi_table_path,target_hudi_table_path,\
        recordkey,partition_field,sns_secret_name,raw_watermark_bucket,raw_watermark_file_key,partition_extract_col,\
        landing_bucket,raw_bucket,table_prefix,table_prefix,table_append_land,table_append_raw,\
        json_columns,precombine_field,audit_path,audit_table,region_name = read_yaml_file(s3,yaml_s3_bucket,yaml_file_key,source_table_name)
    except Exception as e:
        logging.error(f"Error in initial steps: {str(e)}")
        traceback.print_exc()
        raise
        
    
    try:
        source_type = "S3-LANDING"
        target_type = "S3-RAW"
        #validate audit table
        
        year_partitioned=start_time.year
        month_partitioned=start_time.month
        is_validate = validate_audit_table_with_s3_partition(spark,sns_secret_name,start_time,audit_path,audit_table,source_table_name,target_table_name,job_name,region_name,year_partitioned,month_partitioned)
        
        if is_validate == False:
            return
        
        # Log audit
        log_audit(
                    spark,job_name,source_table_name,source_type,target_table_name,target_type,\
                    "Started",start_time,None,None,audit_path,audit_table,
                )
        #read watermark timestamp
        watermark_timestamp = get_watermark_timestamp(s3,raw_watermark_bucket,raw_watermark_file_key)
        
        # read data from landing table incrementally
        source_df,num_records = read_source_table(spark,watermark_timestamp,source_hudi_table_path)
        
        source_df.printSchema()
        if num_records > 0:
            # if json_columns:
            #     json_list = json.loads(json_columns)
            #     for json_column in json_list:
            #         # process json columns
            #         process_json_columns(spark,source_df,json_column,target_table_name,target_database,target_hudi_table_path,\
            #             recordkey,partition_field,sns_secret_name,precombine_field,region_name)
            
            #load landing data into raw
            load_df_into_target_table(source_df,target_table_name,target_database,target_hudi_table_path,recordkey,partition_field,precombine_field)
            #update watermark file
            update_watermark_with_latesttime(s3,source_df,raw_watermark_bucket,raw_watermark_file_key,source_table_name)
            
        #get cloudwatch details
        cloudwatch_url = get_cloudwatch_url(region_name, job_name, job_run_id)
        end_time = datetime.now()
        duration = (end_time - start_time).seconds
        
    
        # Log audit
        log_audit(
                spark,job_name,source_table_name,source_type,target_table_name,target_type,"Completed",start_time,end_time,\
                    num_records,audit_path,audit_table,
                )
        logging.info(f"Job completed successfully in {duration} seconds")
        
        log = {
            "status": "success",
            "job_name": job_name,
            "source_table": source_table_name,
            "target_table": target_table_name,
            "start_time": start_time.isoformat(),
            "end_time": end_time.isoformat(),
            "duration": duration,
            "num_records": num_records
        }
                    
    except Exception as e:
        logging.error("Job failed with error: %s", str(e))
        traceback.print_exc()
        end_time = datetime.now()
        duration = end_time - start_time
        logging.error(f"Job failed in {duration} seconds")
        #get cloudwatch details 
        cloudwatch_url = get_cloudwatch_url(region_name, job_name, job_run_id)
        log = {
                "status": "failure",
                "job_name": job_name,
                "source_table": source_table_name,
                "target_table": target_table_name,
                "start_time": start_time.isoformat(),
                "end_time": end_time.isoformat(),
                "duration": duration,
                "error": f"Error: {str(e)}\nTraceback: {traceback.format_exc()}"
            }
        
        # Log audit
        log_audit(
                spark,job_name,source_table_name,source_type,target_table_name,target_type,\
                "Failed",start_time,end_time,None,audit_path,audit_table,
                )
            
        log_message = "\n".join([f"{key}: {value}" for key, value in log.items()])
        message = f"Job -{job_name} failed. Transformation returned None.\n\n{log_message}.\n\nView the logs in CloudWatch:{cloudwatch_url}"
        subject=f"Job Failed : Job - {job_name}",
        send_sns_notification(subject, message, sns_secret_name,region_name)
        raise

    finally:
        final_log = log.copy() 
        yaml_params = {
        "table_name": source_table_name,
        "target_bucket_name":raw_bucket, 
        "audit_table": audit_table, 
        "audit_path":audit_path,
        "yaml_s3_bucket": yaml_s3_bucket,
        "yaml_file_path": yaml_file_key,
        "partition_extract_col": partition_extract_col, 
        "target_table_name": target_table_name,
        "landing_bucket": landing_bucket,
        "raw_bucket": raw_bucket,
        "table_prefix": table_prefix,
        "table_append_landing": table_append_land,
        "table_append_raw":table_append_raw,
        "recordkey": recordkey, 
        "target_database": target_database,
        "partition_field": partition_field}

        final_log.update(yaml_params)
        dt = datetime.now()
        epoch_time = int(dt.timestamp() * 1000)
        s3 = boto3.client('s3', region_name='ap-south-1')
        s3.put_object(Bucket=raw_bucket, Key=f'logs/{job_name}-{source_table_name}_{epoch_time}_logs.json', Body=json.dumps(final_log))
      
if __name__ == "__main__":
    main()
