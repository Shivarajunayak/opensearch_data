import sys
import logging
from datetime import datetime,timedelta
import boto3
import traceback
import psycopg2
from awsglue.utils import getResolvedOptions
from functools import reduce
from pyspark.sql import functions as F
    
from hmcl_cv_common_utilities import (
    log_audit,
    load_yaml_config,
    validate_audit_table_with_s3_partition,
    send_sns_notification,
    get_watermark_timestamp,
    get_cloudwatch_url,
    update_watermark_file,
    initialize_spark_session,
    fetch_postgres_credentials,
    )
logging.basicConfig(
    level=logging.INFO, format="%(asctime)s - %(name)s - %(levelname)s - %(message)s"
)

def read_job_param():
    try:
    
        # Define arguments
        arguments = [
            "JOB_NAME",
            "yaml_s3_bucket",
            "yaml_file_key"
        ]
        # Get the arguments
        args = getResolvedOptions(sys.argv, arguments)
        job_name = args.get("JOB_NAME")
        yaml_s3_bucket = args.get("yaml_s3_bucket")
        yaml_file_key = args.get("yaml_file_key")
        job_run_id = args.get("JOB_RUN_ID")
        logging.info("Job parameters read successfully")
        return yaml_s3_bucket,yaml_file_key,job_name,job_run_id
        
    except Exception as e:
        logging.error(f"Error while reading job parameters: {str(e)}")
        traceback.print_exc()
        raise
    
def read_yaml_file(s3_client,yaml_s3_bucket,yaml_file_key):
    try:
        yaml_dict = load_yaml_config(s3_client,yaml_s3_bucket,yaml_file_key)
        
        raw_watermark_file_keys_with_source = yaml_dict['raw_watermark_file_keys_with_source']
        source_type = yaml_dict['source_type']
        sns_secret_name = yaml_dict['sns_secret_name']
        audit_path = yaml_dict['audit_path']
        audit_table = yaml_dict['audit_table']        
        target_type = yaml_dict['target_type']
        target_table = yaml_dict['target_table']
        raw_watermark_bucket = yaml_dict['raw_watermark_bucket']
        target_pg_schema = yaml_dict['target_pg_schema']
        region_name = yaml_dict['region_name']
        pg_secret_name = yaml_dict['pg_secret_name']
        pg_secret_region =yaml_dict['pg_secret_region']
        required_metrics = yaml_dict['required_metrics']
        
        logging.info("yaml parameters read successfully")
        
        return raw_watermark_file_keys_with_source,source_type,target_table,target_type,sns_secret_name,raw_watermark_bucket,\
        audit_path,audit_table,region_name,target_pg_schema,pg_secret_name,pg_secret_region,required_metrics
        
    except Exception as e:
        logging.error(f"Error while reading yaml parameters: {str(e)}")
        traceback.print_exc()
        raise


def get_postgres_conn_details(secret_name,secret_region):
    try:
        # Extract PostgreSQL credentials from secret
        secret_dict = fetch_postgres_credentials(secret_name,secret_region)
        logging.info("rds_secret_name loaded successfully.")
        db_host = secret_dict['db.host']
        db_port = secret_dict['db.port']
        db_name = secret_dict['db.database']
        db_user = secret_dict['db.username']
        db_password = secret_dict['db.password']
        jdbc_url = f"jdbc:postgresql://{db_host}:{db_port}/{db_name}?user={db_user}&password={db_password}"
        
        return db_host,db_port,db_name,db_user,db_password,jdbc_url
    except Exception as e:
        logging.error(f"Error While fetching Source PostgreSQL credentials from Secrets Manager: {e}")
        traceback.print_exc()
        raise

def read_source_tables(spark,watermark_timestamp,source_hudi_table_path):
    try:
        source_hudi_table_path = "s3://"+source_hudi_table_path
        # Read the Hudi table incrementally
        source_df = spark.read.format("hudi")\
            .option("hoodie.datasource.query.type", "incremental")\
            .option("hoodie.datasource.read.begin.instanttime", watermark_timestamp)\
            .load(source_hudi_table_path)
        
            
        logging.info(f"data read successfully from landing, no.of new records in landing :{source_df.count()}")
        return source_df
    except Exception as e:
        logging.error(f"Error while reading the data from RAW:{str(e)}")
        traceback.print_exc()
        raise
    
def write_data_into_pg_stage(df,target_table,user_name,password,host,port,db,target_pg_schema):
    try:
    
        df.write \
            .format("jdbc") \
            .option("url", f"jdbc:postgresql://{host}:{port}/{db}") \
            .option("dbtable", f"{target_pg_schema}.{target_table}_stage") \
            .option("user", user_name) \
            .option("password", password) \
            .option("batchsize", "1000") \
            .mode("overwrite") \
            .save()
        logging.info(f"data successfully loaded into  {target_pg_schema}.{target_table}_stage Table")
        return True
    except Exception as e:
        logging.error(f"Error while upserting data into postgres Stage table :{str(e)}")
        traceback.print_exc()
        raise
    
def upsert_into_pg(db,user_name,password,host,port,target_pg_schema,target_table):
    try:

        # Database connection parameters
        db_params = {
            'dbname': db,
            'user': user_name,
            'password': password,
            'host': host,
            'port': port
        }

        # Establish connection
        with psycopg2.connect(**db_params) as conn:
            with conn.cursor() as cursor:
            
                cursor.execute(f"""
                    SELECT column_name 
                    FROM information_schema.columns 
                    WHERE table_schema = '{target_pg_schema}' AND table_name = '{target_table}_stage';
                """)
            
                columns = [row[0] for row in cursor.fetchall()]

            # Prepare the column lists for the UPSERT query
            primary_key_columns = ['vid']  
            id_column = ', '.join(primary_key_columns)  
            set_clause = ', '.join([f"{col} = EXCLUDED.{col}" for col in columns if col not in primary_key_columns])
            column_list = ', '.join(columns)
            # Construct the dynamic UPSERT query
            upsert_query = f"""
            INSERT INTO {target_pg_schema}.{target_table} ({column_list})
            SELECT {column_list} FROM {target_pg_schema}.{target_table}_stage
            ON CONFLICT ({id_column}) 
            DO UPDATE SET
                {set_clause};
            """
            # Execute the UPSERT query
            with conn.cursor() as cursor:
                cursor.execute(upsert_query)
        logging.info(f"data successfully loaded into  {target_pg_schema}.{target_table} Table")
        return True
    except Exception as e:
        logging.error(f"Error while upserting data into postgres table :{str(e)}")
        traceback.print_exc()
        raise
    
    
def add_buffer_to_hudi_commit_time(hudi_timestamp,num_of_hours):
    
    try:
        # Parse the timestamp to a datetime object
        parsed_time = datetime.strptime(hudi_timestamp[:-3], "%Y%m%d%H%M%S")
        # Subtract one hour
        time_one_hour_back = parsed_time - timedelta(hours=num_of_hours)
        # Format it back to the Hudi timestamp format
        new_hudi_timestamp = time_one_hour_back.strftime("%Y%m%d%H%M%S") + hudi_timestamp[-3:]
        return new_hudi_timestamp
    
    except Exception as e:
        logging.error(f"Error while adding buffer to hudi commit time :{str(e)}")
        traceback.print_exc()
        raise

def load_data_into_targets(source_df,target_table,target_pg_schema,secret_name,secret_region):
    try:
        
        host,port,db,user_name,password,_ = get_postgres_conn_details(secret_name,secret_region)
        write_data_into_pg_stage(source_df,target_table,user_name,password,host,port,db,target_pg_schema)
        upsert_into_pg(db,user_name,password,host,port,target_pg_schema,target_table)        
    except Exception as e:
        logging.error(f"Error while loading the data into targets :{str(e)}")
        traceback.print_exc()
        raise

    
def update_watermark_with_latesttime(s3_client,initial_df,raw_watermark_bucket,raw_watermark_file_key,source_table_name):
    
    try:
        # Update the watermark for the specific table
        max_commit_time = initial_df.agg({"_hoodie_commit_time": "max"}).collect()[0][0]
        new_hudi_timestamp = add_buffer_to_hudi_commit_time(max_commit_time,48)
        update_watermark_file(s3_client,new_hudi_timestamp,raw_watermark_bucket,raw_watermark_file_key,source_table_name)
        return True
    except Exception as e:
        logging.error(f"Error while updating the watermark file:{str(e)}")
        traceback.print_exc()
        raise
    
def full_outer_join(df1, df2):
    return df1.join(df2, on="vid", how="outer")
    
def join_dataframes(source_data):
    try:
        unused_columns = ["_hoodie_commit_time","_hoodie_commit_seqno","_hoodie_record_key","_hoodie_partition_path", \
                            "_hoodie_file_name"]
        source_dataframes = []
        for data in source_data:
            data = data.drop(*unused_columns)
            source_dataframes.append(data)
        # Reduce the list of DataFrames with full outer join
        result_df = reduce(full_outer_join, source_dataframes)
        return result_df , result_df.count()
    except Exception as e:
        logging.error(f"Error while joining dataframes:{str(e)}")
        traceback.print_exc()
        raise

def s3_path_exists(bucket_name, prefix, s3_client):
    
    response = s3_client.list_objects_v2(Bucket=bucket_name, Prefix=prefix, MaxKeys=1)
    return "Contents" in response
 
def main():
    
    try:
        start_time = datetime.now()
        logging.info(f"Job started at {start_time}")
        spark = initialize_spark_session()
        
        yaml_s3_bucket,yaml_file_key,job_name,job_run_id = read_job_param()
        logging.info("job_name=%s", job_name)

        s3_client = boto3.client('s3')
        source_table_name = "vehicle_metrics_raw"
        raw_watermark_file_keys_with_source,source_type,target_table,target_type,sns_secret_name,raw_watermark_bucket,\
        audit_path,audit_table,region_name,target_pg_schema,pg_secret_name,pg_secret_region,required_metrics \
            = read_yaml_file(s3_client,yaml_s3_bucket,yaml_file_key)
    except Exception as e:
        logging.error(f"Error in initial steps: {str(e)}")
        traceback.print_exc()
        raise
    
    try:
        year_partitioned=start_time.year
        month_partitioned=start_time.month
        #validate audit table
        is_validate = validate_audit_table_with_s3_partition(spark,sns_secret_name,start_time,audit_path,audit_table,source_table_name,target_table,\
            job_name,region_name,year_partitioned,month_partitioned)
        
        if is_validate == False:
            return
        
        # Log audit
        log_audit(
                    spark,job_name,source_table_name,source_type,target_table,target_type,\
                    "Started",start_time,None,None,audit_path,audit_table,
                )
        #read watermark timestamp
        source_data = []
        watermark_file_keys = []
        for table_path,watermark_key  in raw_watermark_file_keys_with_source.items():
            
            watermark_timestamp = get_watermark_timestamp(s3_client,raw_watermark_bucket,watermark_key)
            metrics_bucket_name = table_path.split('/',1)[0]
            metrics_path = table_path.split('/',1)[1]
            if s3_path_exists(metrics_bucket_name, metrics_path, s3_client):
                df = read_source_tables(spark,watermark_timestamp,table_path)
            
                df = df.toDF(*[col.lower() for col in df.columns])
                
                source_data.append(df)
                watermark_file_keys.append(watermark_key)
        
        if len(source_data) > 0:
            source_df,num_records = join_dataframes(source_data)
            for req_metric in required_metrics:
                if req_metric not in source_df.columns:
                    source_df = source_df.withColumn(req_metric, F.lit(0))
                else:
                    source_df = source_df.withColumn(req_metric,
                    F.when(F.col(req_metric).isNotNull(), F.floor(F.col(req_metric))).otherwise(None))
                    
            load_data_into_targets(source_df,target_table,target_pg_schema,pg_secret_name,pg_secret_region)
            for indx,initial_df in enumerate(source_data):
                update_watermark_with_latesttime(s3_client,initial_df,raw_watermark_bucket,watermark_file_keys[indx],source_table_name)
            
        cloudwatch_url = get_cloudwatch_url(region_name, job_name, job_run_id)
        end_time = datetime.now()
        duration = (end_time - start_time).seconds
        
        log = {
            "status": "success",
            "job_name": job_name,
            "source_table": source_table_name,
            "target_table": target_table,
            "start_time": start_time.isoformat(),
            "end_time": end_time.isoformat(),
            "duration": duration,
            "num_records": num_records
        }
        
        log_audit(
                spark,job_name,source_table_name,source_type,target_table,target_type,"Completed",start_time,end_time,num_records,audit_path,audit_table,
                )
        logging.info(f"Job completed successfully in {duration} seconds")
        
    except Exception as e:
        logging.error("Job failed with error: %s", str(e))
        traceback.print_exc()
        end_time = datetime.now()
        duration = end_time - start_time
        logging.error(f"Job failed in {duration} seconds")
        
        #get cloudwatch details 
        cloudwatch_url = get_cloudwatch_url(region_name, job_name, job_run_id)
        
        log = {
                "status": "failure",
                "job_name": job_name,
                "source_table": source_table_name,
                "target_table": target_table,
                "start_time": start_time.isoformat(),
                "end_time": end_time.isoformat(),
                "duration": duration,
                "error": f"Error: {str(e)}\nTraceback: {traceback.format_exc()}"
            }
        
        # Log audit
        log_audit(
                spark,job_name,source_table_name,source_type,region_name,target_type,\
                "Failed",start_time,end_time,None,audit_path,audit_table,
                )
            
        log_message = "\n".join([f"{key}: {value}" for key, value in log.items()])
        message = f"Job -{job_name} failed. Transformation returned None.\n\n{log_message}.\n\nView the logs in CloudWatch:{cloudwatch_url}"

        send_sns_notification(
            subject=f"Job Failed : Job - {job_name}",
            message=message,
            sns_secret_name=sns_secret_name,
            region_name=region_name)
        raise

if __name__ == "__main__":
    main()

