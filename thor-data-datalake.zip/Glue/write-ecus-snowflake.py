import sys
import logging
from datetime import datetime, timedelta
import boto3
import traceback
import snowflake.connector
from awsglue.utils import getResolvedOptions
from pyspark.sql import functions as F
from pyspark.sql.types import IntegerType

from hmcl_cv_common_utilities import (
    log_audit,
    load_yaml_config,
    validate_audit_table_with_s3_partition,
    send_sns_notification,
    get_watermark_timestamp,
    get_cloudwatch_url,
    update_watermark_file,
    initialize_spark_session,
    fetch_snowflake_credentials
)

logging.basicConfig(
    level=logging.INFO, format="%(asctime)s - %(name)s - %(levelname)s - %(message)s"
)


def read_job_param():
    try:
        # Define arguments
        arguments = [
            "JOB_NAME",
            "yaml_s3_bucket",
            "yaml_file_key",
            "source_table_name"
        ]
        # Get the arguments
        args = getResolvedOptions(sys.argv, arguments)

        job_params = {
            "job_name": args.get("JOB_NAME"),
            "job_run_id": args.get("JOB_RUN_ID"),
            "yaml_s3_bucket": args.get("yaml_s3_bucket"),
            "yaml_file_key": args.get("yaml_file_key"),
            "source_table_name": args.get("source_table_name"),
            # "audit_database": args.get("audit_database"),
        }

        logging.info("Job parameters read successfully")
        return job_params
    except Exception as e:
        logging.error(f"Error while reading job parameters: {str(e)}")
        raise


def read_yaml_file(s3_client, job_params):
    try:
        # Read YAML file from S3
        yaml_dict = load_yaml_config(s3_client, job_params['yaml_s3_bucket'], job_params['yaml_file_key'])
        table_config = yaml_dict.get(job_params['source_table_name'], {})

        # Extract parameters safely using `.get()`
        job_config = {
            "source_table_name": job_params['source_table_name'],
            "target_table_name": table_config.get("target_table_name"),
            "audit_path": table_config.get("audit_path"),
            "audit_table": table_config.get("audit_table"),
            "source_type": table_config.get("source_type"),
            "target_type": table_config.get("target_type"),
            "log_path": table_config.get("log_path"),
            "ecus_path": table_config.get("ecus_path"),
            "vehicle_model_path": table_config.get("vehicle_model_path"),
            "watermark_bucket": table_config.get("watermark_bucket"),
            "watermark_file_key": table_config.get("watermark_file_key"),
            "watermark_column": table_config.get("watermark_column"),
            "region_name": table_config.get("region"),
            "sns_secret_name": table_config.get("sns_secret_name"),
            "snowflake_secret_name": table_config.get("snowflake_secret_name"),
            "stage_table_name": table_config.get("stage_table_name"),
        }
        job_config.update(job_params)
        logging.info("YAML parameters read successfully")
        return job_config

    except Exception as e:
        logging.error(f"Error while reading YAML parameters: {str(e)}")
        raise


def read_and_include(spark, path, watermark_timestamp, required_columns):
    """
    Read a Hudi table incrementally and exclude specific columns.

    :param spark: SparkSession
    :param path: Source path of the Hudi table
    :param watermark_timestamp: Incremental read timestamp
    :param required_columns: List of columns to exclude
    :return: Filtered DataFrame or None if table is empty
    """
    logging.info(f"Reading Hudi table from path: {path} with watermark: {watermark_timestamp}")
    try:
        source_df = spark.read.format("hudi") \
            .option("hoodie.datasource.query.type", "incremental") \
            .option("hoodie.datasource.read.begin.instanttime", watermark_timestamp) \
            .load(path)

        if source_df.head(1) is None:  # Handle empty table
            logging.warning(f"No data found in Hudi table at path: {path}")
            return None

        select_columns = [col for col in source_df.columns if col in required_columns]
        return source_df.select(*select_columns)

    except FileNotFoundError:
        logging.error(f"The specified path does not exist: {path}")
        raise

    except Exception as e:
        logging.error(f"Error reading Hudi table: {str(e)}")
        traceback.print_exc()
        raise


def check_table_exists(spark, conn, target_table_name, job_name, sns_secret_name, region_name, start_time, audit_path,
                       audit_table, source_table_name, source_type, target_type):
    # Extract the table name (assumes target_table is in format 'database.schema.table')
    table_name = target_table_name.split('.')[2]

    # Create the query to check if the table exists
    check_table_query = f"SHOW TABLES LIKE '{table_name}'"

    # Execute the query to check if the table exists
    cursor = conn.cursor()
    cursor.execute(check_table_query)
    table_exists = cursor.fetchone()

    if not table_exists:
        # Log the error and notify via SNS
        logging.error(f"Target table {target_table_name} does not exist. Aborting job.")
        end_time = datetime.now()
        # Log the audit information
        log_audit(spark, job_name, source_table_name, source_type, target_table_name, target_type, "Aborted",
                  start_time, end_time, None, audit_path, audit_table)

        # Send SNS notification about the failure
        subject = f"{job_name} failed - Missing Target Table"
        if len(subject) > 100:
            subject = subject[:97] + '..'
        send_sns_notification("job failed", f"The target table {target_table_name} does not exist.", sns_secret_name,
                              region_name)

        # Optional: Raise an exception or return early to stop the job
        raise Exception(f"Target table {target_table_name} does not exist. Job aborted.")


def get_max_commit_time(df, hoodie_commit_time_col):
    max_commit_time = df.agg(F.max(F.col(hoodie_commit_time_col))).collect()[0][0]
    return max_commit_time


def get_snowflake_options(secret_dict):
    """
    Create a dictionary of Snowflake options for Spark DataFrame writes.
    """
    return {
        "sfURL": secret_dict['url'],
        "sfDatabase": secret_dict['database'],
        "sfSchema": secret_dict['schema'],
        "sfWarehouse": secret_dict['warehouse'],
        "sfRole": secret_dict['role'],
        "sfUser": secret_dict['username'],
        "sfPassword": secret_dict['password']
    }


def get_snowflake_connection(sfUser, sfPassword, sfURL):
    """
    Establish and return a Snowflake connection.
    """
    try:
        conn = snowflake.connector.connect(
            user=sfUser,
            password=sfPassword,
            account=sfURL.split('//')[1].split('.snowflakecomputing.com')[0]
        )
        logging.info("Snowflake connection established.")
        return conn
    except Exception as e:
        logging.error(f"Error establishing Snowflake connection: {e}")
        raise


def write_to_snowflake(df, table_name, snowflake_secret_name, write_mode='overwrite'):
    try:
        # Fetch Snowflake credentials
        secret_dict = fetch_snowflake_credentials(snowflake_secret_name)
        logging.info("Snowflake credentials loaded successfully.")

        # Prepare Snowflake options
        options = get_snowflake_options(secret_dict)

        # Write DataFrame to Snowflake
        logging.info(f"Starting data write to Snowflake table: {table_name}")
        df.write \
            .format("snowflake") \
            .options(**options) \
            .option("dbtable", table_name) \
            .mode("overwrite") \
            .save()
        logging.info(f"Data written successfully to Snowflake table: {table_name}")
    except Exception as e:
        logging.error(f"Failed to write to Snowflake: {str(e)}")
        raise


def execute_sf_query(conn, query):
    try:
        cursor = conn.cursor()
        cursor.execute(query)
    finally:
        cursor.close()
        conn.close()


def join_ecus_vehicle_model(spark, job_config, ecus_df, vehicle_model_req_col):
    try:
        # get vehicle_model_id's from ecus data
        vehicle_model_ids_list = [row['vehicle_model_id'] for row in ecus_df.collect()]

        # Read vehicle mode data
        vehicle_model_df = read_and_include(spark, job_config['vehicle_model_path'], 0, vehicle_model_req_col)
        vehicle_model_df = vehicle_model_df.filter(F.col("id").isin(vehicle_model_ids_list))
        logging.info(f"From ecus table, vehicle_model_ids_list : {vehicle_model_ids_list}")

        df = ecus_df.join(vehicle_model_df, ecus_df['vehicle_model_id'] == vehicle_model_df['id'], how='left')
        logging.info("Join Done between ecus and vehicle_model tables")
        return df
    except Exception as e:
        logging.error(f"Error in join ecus, vehicle model tables: {str(e)}")
        raise


def write_to_snowflake_tables(spark, df, start_time, job_config, job_params):
    try:
        # Fetch Snowflake credentials
        sf_dict = fetch_snowflake_credentials(job_config['snowflake_secret_name'])
        logging.info("Snowflake credentials loaded successfully")
        logging.info(f"sf_dict: {sf_dict}")

        # Initialize Snowflake connection
        conn = get_snowflake_connection(sf_dict['username'], sf_dict['password'], sf_dict['url'])

        # Check If table exists
        check_table_exists(spark, conn, job_config['target_table_name'], job_params['job_name'],
                           job_config['sns_secret_name']
                           , job_config['region_name'], start_time, job_config['audit_path'],
                           job_config['audit_table']
                           , job_config['source_table_name'], job_config['source_type'],
                           job_config['target_type'])
        # Continue job logic if table exists

        # Overwrite to Stage table
        write_to_snowflake(df, job_config['stage_table_name'], job_config['snowflake_secret_name'],
                           'overwrite')

        # Write into target table from stage table
        columns_str = ", ".join(df.columns)
        target_query = f"""
            INSERT INTO {job_config['target_table_name']} ({columns_str})
            SELECT {columns_str} FROM {job_config['stage_table_name']};
        """
        execute_sf_query(conn, target_query)
        logging.info(f"Data written successfully to Snowflake table: {job_config['target_table_name']}")

    except Exception as e:
        logging.error(f"Error in Snowflake steps: {str(e)}")


def read_ecus(spark, job_config, current_watermark, required_col):
    try:
        df = read_and_include(spark, job_config['ecus_path'], current_watermark, required_col)

        # Filtering vehicle_model_id for NULL or other than Integer
        filter_df = df.withColumn("vehicle_model_id", F.col("vehicle_model_id").cast(IntegerType())) \
            .filter(F.col("vehicle_model_id").isNotNull())

        count = filter_df.count()
        logging.info(f"Read {count} rows from ecus incrementally.")
        return filter_df, count
    except Exception as e:
        logging.error(f"Error in reading ecus from path: {job_config['ecus_path']}")
        raise


def main():
    start_time = datetime.now()

    # 1. Read job_params and job_config
    try:
        logging.info(f"Job started at {start_time}")

        # create an S3 client
        s3 = boto3.client('s3')

        # initialize spark job
        spark = initialize_spark_session()

        # Read Job Parameters
        job_params = read_job_param()

        # Read .yml file
        job_config = read_yaml_file(s3, job_params)

    except Exception as e:
        logging.error(f"Error in initial steps: {str(e)}")
        traceback.print_exc()
        raise

    try:
        year_partitioned = start_time.year
        month_partitioned = start_time.month
        # 2. validate audit table for job status
        is_validate = validate_audit_table_with_s3_partition(spark, job_config['sns_secret_name'], start_time,
                                                             job_config['audit_path'],
                                                             job_config['audit_table'], job_config['source_table_name'],
                                                             job_config['target_table_name'], job_params['job_name'],
                                                             job_config['region_name'],
                                                             year_partitioned, month_partitioned)

        if is_validate == False:
            return

        # Log audit
        log_audit(
            spark, job_config['job_name'], job_config['source_table_name'], job_config['source_type'],
            job_config['target_table_name'],
            job_config['target_type'], "Started", start_time, None, None, job_config['audit_path'],
            job_config['audit_table'],
        )

        # 3. Read watermark timestamp
        current_watermark = get_watermark_timestamp(s3, job_config['watermark_bucket'],
                                                    job_config['watermark_file_key'])
        logging.info(f"Current watermark: {current_watermark}")

        # Columns needed for Pyspark Job & Snowflake
        ecus_required_col = ['vehicle_model_id', 'component_id', 'ecu_abbreviation', 'hardware_version',
                             'calibration_version', 'software_version', 'updatable', 'is_deleted', 'created_tsp',
                             'updated_tsp', '_hoodie_commit_time'
                             ]
        vehicle_model_req_col = ['id', 'tenant_id', 'vds_code', 'vehicle_model_name']
        ecus_drop_col = ['_hoodie_commit_time']
        vehicle_model_drop_col = ['id']
        drop_col = ecus_drop_col + vehicle_model_drop_col
        final_col = [col for col in (ecus_required_col + vehicle_model_req_col) if col not in drop_col]

        # 4. Read ecus data
        ecus_df, ecus_count = read_ecus(spark, job_config, current_watermark, ecus_required_col)

        final_count = 0
        # 5. Get details from vehicle model table w.r.t ecus
        if ecus_count > 0:
            joined_df = join_ecus_vehicle_model(spark, job_config, ecus_df, vehicle_model_req_col)

            # 6. Get max hoodie_commit_time from ecus_df
            max_commit_time = get_max_commit_time(ecus_df, job_config['watermark_column'])
            logging.info(f"max_commit_time : {max_commit_time}")

            final_df = joined_df.select(final_col)
            joined_df.show(5, False)

            # 7. Snowflake
            final_count = final_df.count()
            if final_count > 0:
                write_to_snowflake_tables(spark, final_df, start_time, job_config, job_params)

            # 8. Update watermark timestamp
            update_watermark_file(s3, max_commit_time, job_config['watermark_bucket'], job_config['watermark_file_key']
                                  , job_config['source_table_name'])
        else:
            logging.info(f"ecus has no data. Job Completed")

        # Log audit
        end_time = datetime.now()
        log_audit(
            spark, job_params['job_name'], job_config['source_table_name'], job_config['source_type'],
            job_config['target_table_name'], job_config['target_type'], "Completed", start_time, end_time,
            final_count, job_config['audit_path'], job_config['audit_table'],
        )
    except Exception as e:
        logging.error("Job failed with error: %s", str(e))
        traceback.print_exc()
        end_time = datetime.now()
        duration = end_time - start_time
        logging.error(f"Job failed in {duration} seconds")
        # get cloudwatch details
        cloudwatch_url = get_cloudwatch_url(job_config['region_name'], job_params['job_name'], job_params['job_run_id'])
        log = {
            "status": "failure",
            "job_name": job_params['job_name'],
            "source_table": job_config['source_table_name'],
            "target_table": job_config['target_table_name'],
            "start_time": start_time.isoformat(),
            "end_time": end_time.isoformat(),
            "duration": duration,
            "error": f"Error: {str(e)}\nTraceback: {traceback.format_exc()}"
        }

        # Log audit
        log_audit(
            spark, job_params['job_name'], job_config['source_table_name'], job_config['source_type'],
            job_config['target_table_name'], job_config['target_type'], "Failed", start_time, end_time,
            None, job_config['audit_path'], job_config['audit_table'],
        )

        log_message = "\n".join([f"{key}: {value}" for key, value in log.items()])
        message = f"Job -{job_params['job_name']} failed. Transformation returned None.\n\n{log_message}.\n\nView the logs in CloudWatch:{cloudwatch_url}"
        subject = f"Job Failed : Job - {job_params['job_name']}"
        send_sns_notification(subject, message, job_config['sns_secret_name'], job_config['region_name'])
        raise

    finally:
        end_time = datetime.now()
        duration = (end_time - start_time).seconds
        logging.info(f"Job completed in {duration} seconds")


if __name__ == "__main__":
    main()
