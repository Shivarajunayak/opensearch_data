import json
import sys
from pyspark.sql import SparkSession
from awsglue.dynamicframe import DynamicFrame
from awsglue.context import GlueContext
from pyspark.sql import functions as F
from awsglue.utils import getResolvedOptions
import boto3
import logging
from pyspark.sql.types import StructType,StructField,StringType,LongType,DoubleType
from datetime import datetime, timedelta
import traceback
from hmcl_cv_common_utilities import (
    log_audit,
    load_yaml_config,
    validate_audit_table,
    send_sns_notification,
    get_cloudwatch_url,
    validate_audit_table_with_s3_partition
    )

logging.basicConfig(
    level=logging.INFO, format="%(asctime)s - %(name)s - %(levelname)s - %(message)s"
)


def initialize_spark_session():
    try:
        spark = (
                SparkSession.builder.config(
                    "spark.serializer", "org.apache.spark.serializer.KryoSerializer"
                )
                .config("spark.kryoserializer.buffer.max", "256m")
                .config("spark.hudi.query.metadata.enable", "true")
                .config("spark.sql.jsonGenerator.ignoreNullFields", "false")
                .config("spark.sql.adaptive.enabled", "true")
                .config("spark.sql.adaptive.skewJoin.enabled", "true")
                .config("spark.sql.adaptive.coalescePartitions.enabled", "true")
                .config("spark.sql.join.preferSortMergeJoin", "true")
                .getOrCreate()
            )
            
        logging.info("Session created")
        
        return spark
    except Exception as e:
        logging.error(f"Error while initializing the spark Session: {str(e)}")
        traceback.print_exc()
        raise
    

def fetch_opensearch_credentials(opensearch_secret_name, region_name):
    
    try:
        session = boto3.session.Session()
        client = session.client(service_name="secretsmanager", region_name = region_name)
        get_secret_value_response = client.get_secret_value(SecretId = opensearch_secret_name)
        secret = get_secret_value_response["SecretString"]
        logging.info("Opensearch credentials fetched successfully.")
        return json.loads(secret)
    except Exception as e:
        logging.error(
            f"Error fetching Opensearch credentials from Secrets Manager: {e}"
        )
        traceback.print_exc()
        raise
   
    
def read_job_parameters():
    try:
        # Define arguments
        arguments = [
            "JOB_NAME",
            "yaml_s3_bucket",
            "yaml_file_key",
        ]
        # Get the arguments
        args = getResolvedOptions(sys.argv, arguments)
        job_name = args.get("JOB_NAME")
        job_run_id = args.get("JOB_RUN_ID")
        yaml_s3_bucket = args.get("yaml_s3_bucket")
        yaml_file_key = args.get("yaml_file_key")
        logging.info("Job parameters read successfully")
        return job_name,job_run_id,yaml_s3_bucket,yaml_file_key
    
    except Exception as e:
        logging.error(f"Error while reading job parameters: {str(e)}")
        traceback.print_exc()
        raise
    
def read_yaml_file(s3_client,yaml_s3_bucket,yaml_file_key):
    try:
        # Read YAML file from S3
        yaml_dict = load_yaml_config(s3_client,yaml_s3_bucket,yaml_file_key)
        source_os_index = yaml_dict["source_os_index"]
        target_hudi_table_path = yaml_dict["hudi_table_path"]
        target_database = yaml_dict["hudi_table_database"]
        target_table_name = yaml_dict["hudi_table_name"]
        number_of_days_to_consider = yaml_dict["number_of_days_to_consider"]
        recordkey = yaml_dict["recordkey"]
        partition_field = yaml_dict["partition_field"]
        precombine_field = yaml_dict["precombine_field"]
        audit_table = yaml_dict["audit_table"]
        sns_secret_name = yaml_dict["sns_secret_name"]
        audit_path = yaml_dict["audit_path"]
        source_type = yaml_dict["source_type"]
        target_type = yaml_dict["target_type"]
        region_name = yaml_dict["region_name"]
        metrics_bucket_name = yaml_dict["metrics_bucket_name"]
        metrics_cumulative_path = yaml_dict["metrics_cumulative_path"]
        target_table_name_cum = yaml_dict["target_table_name_cum"]
        metrics_path = yaml_dict["metrics_path"]
        os_connector_name = yaml_dict["os_connector_name"]
        read_partitions = yaml_dict["read_partitions"]
        logging.info("yaml parameters read successfully")
        
        return source_os_index,target_table_name,target_database,target_hudi_table_path,number_of_days_to_consider,\
            recordkey,partition_field,precombine_field,os_connector_name,read_partitions,audit_table,\
            sns_secret_name,audit_path,source_type,target_type,region_name,metrics_bucket_name, \
            metrics_cumulative_path,target_table_name_cum,metrics_path
    except Exception as e:
        logging.error(f"Error while reading yaml parameters: {str(e)}")
        traceback.print_exc()
        raise
    

def load_df_into_target_table(source_df,target_table_name,target_database,target_hudi_table_path,recordkey,partition_field,precombine_field):
    """
    This function loads  data into raw
    """
    try:
        logging.info(f"PARTITION VALUES  (partition_field) in main table load: {partition_field}")
        # Define Hudi options
        source_df.write.format("hudi") \
            .option("hoodie.table.name", target_table_name) \
            .option("hoodie.datasource.write.storage.type", "COPY_ON_WRITE") \
            .option("hoodie.datasource.write.recordkey.field", recordkey) \
            .option("hoodie.datasource.write.partitionpath.field", partition_field) \
            .option("hoodie.datasource.write.precombine.field", precombine_field) \
            .option("hoodie.datasource.write.operation", "upsert") \
            .option("hoodie.datasource.hive_sync.enable", "true") \
            .option("hoodie.datasource.hive_sync.database", target_database) \
            .option("hoodie.datasource.hive_sync.table", target_table_name) \
            .option("hoodie.datasource.hive_sync.use_jdbc", "false") \
            .option("hoodie.datasource.hive_sync.mode", "hms") \
            .option("hoodie.datasource.hive_sync.sync_as_datasource", "false") \
            .option("hoodie.datasource.hive_sync.support_timestamp", "true") \
            .option("hoodie.avro.schema.allow.empty", "true") \
            .option("hoodie.schema.on.read.enable", "true") \
            .option("hoodie.datasource.write.schema.evolution.enable", "true") \
            .option("hoodie.parquet.max.file.size", "134217728") \
            .option("hoodie.upsert.shuffle.parallelism", 200) \
            .mode("append") \
            .save(target_hudi_table_path)
        ## .option("hoodie.datasource.hive_sync.partition_fields": partition_field) \
        logging.info(f"Data loaded successfully into {target_table_name} table,\
            no.of processed records count: {source_df.count()}")
        return True
    except Exception as e:
        logging.error(f"Error while loading the data into table:{target_table_name}, {str(e)}")
        traceback.print_exc()
        raise


def get_previous_time(number_of_days_to_consider):
    try:
        target_date = datetime.now() - timedelta(days=number_of_days_to_consider)
        target_date_midnight = target_date.replace(hour=0, minute=0, second=0, microsecond=0)
        epoch_time = int(target_date_midnight.timestamp() * 1000)
        epoch_time = epoch_time-19800000
        print(epoch_time)
        return epoch_time
    except Exception as e:
        logging.error(f"Error getting previous date value {str(e)}")
        traceback.print_exc()
        raise

def get_schema():
    
    # Define the schema
    schema = {
        "vid": StringType(),
        "max_speed": DoubleType(),
        "tenant_id": StringType(),
        "source_timestamp_trip_start": LongType(),
        "total_distance_covered": DoubleType(),
        "total_trip_time_seconds": LongType()
        }
    return schema

def get_query(epochtime_for_previous_date):
    
    query = f"""
    {{
        "query": {{
            "range": {{
                "source_timestamp_trip_start": {{
                    "gte": "{epochtime_for_previous_date}"
                }}
            }}
        }}
    }}
    """
    return query

def read_opensearch_index(glueContext,os_connector_name,read_partitions,query,source_os_index):
    try:
        
        
        trip_statistics_index = glueContext.create_dynamic_frame.from_options(
            connection_type="opensearch",
            connection_options={
                "connectionName": os_connector_name,
                "opensearch.port": 443,
                "es.partitioning.field": "vid",
                "es.partitioning.total": read_partitions,
                "opensearch.resource": source_os_index,
                "opensearch.query": query,
                "pushdown": "true",
                "opensearch.read.field.include": "vid,max_speed,tenant_id,source_timestamp_trip_start,total_distance_covered,total_trip_time_seconds"
                # "opensearch.read.field.as.array.include": "latitude_trip_break,longitude_trip_break,location_trip_break,harsh_acceleration_points,harsh_break_points,merged_trips",
            },
        ).toDF()
        logging.info("reading trip statistics completed")
        trip_statistics_index.printSchema()
        logging.info(trip_statistics_index.show())
        return trip_statistics_index
    
    except Exception as e:
       logging.error(f"Error while reading source opensearch {str(e)}")
       traceback.print_exc()
       raise

def s3_path_exists(bucket_name, prefix, s3_client):
    
    response = s3_client.list_objects_v2(Bucket=bucket_name, Prefix=prefix, MaxKeys=1)
    return "Contents" in response

def fill_missing_columns_with_null(trip_statistics_index,schema):
    casted_columns = []
    for col_name,col_type in schema.items():
        if col_name in trip_statistics_index.columns:
            casted_columns.append(F.col(col_name).cast(col_type).alias(col_name))
        else:
            casted_columns.append(F.lit(None).cast(col_type).alias(col_name))
    return trip_statistics_index.select(*casted_columns)


def load_metrics_into_stage_cum_counts(spark,metrics_df,metrics_bucket_name,metrics_cumulative_path,s3_client,target_table_name_cum,metrics_path,target_database,
                            precombine_field):
    try: 
        metrics_base_path = "s3://"+metrics_bucket_name+"/"+metrics_path
                
        if s3_path_exists(metrics_bucket_name, metrics_path, s3_client):
        
            # Extract unique partition values as integers
            unique_years = metrics_df.select("year").distinct().rdd.flatMap(lambda x: x).collect()
            unique_months = metrics_df.select("month").distinct().rdd.flatMap(lambda x: x).collect()
            unique_days = metrics_df.select("day").distinct().rdd.flatMap(lambda x: x).collect()
            
            logging.info("UNIQUE VALUES")
            logging.info(unique_years)
            logging.info(unique_months)
            logging.info(unique_days)

            # Construct dynamic filter condition
            filter_condition = f"(year IN ({', '.join(map(str, unique_years))}) " \
                            f"AND month IN ({', '.join(map(str, unique_months))}) " \
                            f"AND day IN ({', '.join(map(str, unique_days))}))"
                            
            logging.info("filter_condition")
            logging.info(filter_condition)

            partition_df = spark.read.format("hudi").load(metrics_base_path) \
                .filter(filter_condition)
            logging.info("partition df")
            partition_df.show()
                

            metrics_df = (
                metrics_df.alias("m")
                .join(partition_df.alias("p"), on=["vid", "date"], how="left")
                .select(F.col("m.vid").alias("vid"),F.col("m.date").alias("date"),
                    (F.col("m.trips_count") - F.coalesce(F.col("p.trips_count"), F.lit(0))).alias("trips_count"),
                    (F.col("m.total_distance_covered") - F.coalesce(F.col("p.total_distance_covered"), F.lit(0))).alias("total_distance_covered"),
                    (F.col("m.moving_time") - F.coalesce(F.col("p.moving_time"), F.lit(0))).alias("moving_time"),                    
                    F.greatest(F.col("m.max_speed"), F.coalesce(F.col("p.max_speed"), F.lit(0))).alias("max_speed")))
        logging.info("after join metrics df :")
        logging.info(metrics_df.show())
        logging.info("after group by vid :")
        metrics_df = metrics_df.groupBy("vid").agg(F.sum("trips_count").alias("trips_count"),
                                                   F.sum("total_distance_covered").alias("total_distance_covered"),
                                                   F.sum("moving_time").alias("moving_time"),
                                                F.max("max_speed").alias("max_speed"))
        
        logging.info(metrics_df.show())
        
        metrics_base_path_cum = "s3://"+metrics_bucket_name+"/"+metrics_cumulative_path
        
        if s3_path_exists(metrics_bucket_name, metrics_cumulative_path, s3_client):
            existing_df = spark.read.format("hudi").load(metrics_base_path_cum)
            existing_df  = existing_df.select(F.col('vid'),F.col("trips_count"),F.col("total_distance_covered"),F.col("moving_time"),F.col("max_speed"))
            logging.info("existing df :")
            logging.info(existing_df.show())
            metrics_df = (
                        metrics_df.alias("m")
                        .join(existing_df.alias("e"), on="vid", how="left")
                        .select(
                            F.col("m.vid").alias("vid"),
                            (F.col("m.trips_count") + F.coalesce(F.col("e.trips_count"), F.lit(0))).alias("trips_count"),
                            (F.col("m.total_distance_covered") + F.coalesce(F.col("e.total_distance_covered"), F.lit(0))).alias("total_distance_covered"),
                            (F.col("m.moving_time") + F.coalesce(F.col("e.moving_time"), F.lit(0))).alias("moving_time"),
                            F.greatest(F.col("m.max_speed"), F.coalesce(F.col("e.max_speed"), F.lit(0))).alias("max_speed") ))
        
        metrics_df = metrics_df.withColumn("total_distance_covered", F.round(F.col("total_distance_covered"), 3))
        
        logging.info("after join metrics df :")
        logging.info(metrics_df.show())
        
        load_df_into_target_table(metrics_df,target_table_name_cum,target_database,metrics_base_path_cum,"vid","",precombine_field)
        logging.info("cumulative metrics stored successfully:")
        
        
    except Exception as e:
        logging.error(f"Error while loading the cumulative data into stage, {str(e)}")
        traceback.print_exc()
        raise   
    
def transform_and_load_into_datalake(spark,trip_statistics_index,recordkey,partition_field,precombine_field,target_table_name,\
            target_database,target_hudi_table_path,metrics_bucket_name,metrics_cumulative_path,s3_client,target_table_name_cum,metrics_path):
    try:
        df_with_date = trip_statistics_index.withColumn("date",F.to_date(F.from_unixtime(trip_statistics_index["source_timestamp_trip_start"] / 1000)))
        df_grouped = df_with_date.groupBy("vid", "tenant_id", "date").agg(
            F.count("vid").alias("trips_count"),
            F.sum("total_distance_covered").alias("total_distance_covered"),
            F.sum("total_trip_time_seconds").alias("moving_time"),
            F.max("max_speed").alias("max_speed")
            
        )
        df_grouped = df_grouped.filter(df_grouped["vid"].isNotNull() & df_grouped["date"].isNotNull())

        df_grouped = df_grouped \
            .withColumn("year", F.year("date")) \
            .withColumn("month", F.month("date")) \
            .withColumn("day",F.dayofmonth("date"))
        
        
        if df_grouped.count() > 0:
            load_metrics_into_stage_cum_counts(spark,df_grouped,metrics_bucket_name,metrics_cumulative_path,s3_client,target_table_name_cum,metrics_path,target_database,
                            precombine_field)
            
            df_grouped = df_grouped.withColumn("total_distance_covered", F.round(F.col("total_distance_covered"), 3))
            load_df_into_target_table(df_grouped,target_table_name,target_database,target_hudi_table_path,recordkey,partition_field,precombine_field)
           
        else:
            logging.info("no new data found")
        logging.info("data loaded in hudi table")

    except Exception as e:
       logging.error(f"Error while transform data {str(e)}")
       traceback.print_exc()
       raise

def main():
    try:
        start_time = datetime.now()
        logging.info(f"Job started at {start_time}")
        spark=initialize_spark_session()
        glueContext = GlueContext(spark) 
        job_name,job_run_id,yaml_s3_bucket,yaml_file_key =  read_job_parameters()
        s3_client = boto3.client('s3')
        source_os_index,target_table_name,target_database,target_hudi_table_path,number_of_days_to_consider,\
        recordkey,partition_field,precombine_field,os_connector_name,read_partitions,audit_table,\
        sns_secret_name,audit_path,source_type,target_type,region_name,metrics_bucket_name, \
        metrics_cumulative_path,target_table_name_cum,metrics_path= read_yaml_file(s3_client,yaml_s3_bucket,yaml_file_key)
        logging.info("job_name=%s", job_name)
    except Exception as e:
        logging.error(f"Error in initial steps: {str(e)}")
        traceback.print_exc()
        raise
    
    try:
        
        year_partitioned=start_time.year
        month_partitioned=start_time.month
        is_validate = validate_audit_table_with_s3_partition(spark,sns_secret_name,start_time,audit_path,audit_table,source_os_index,target_table_name,job_name,region_name,year_partitioned,month_partitioned)        # Log audit
        
        if is_validate == False:
            return
        
        log_audit(
                    spark,job_name,source_os_index,source_type,target_table_name,target_type,\
                    "Started",start_time,None,None,audit_path,audit_table)
        
        epochtime_for_previous_date  = get_previous_time(number_of_days_to_consider)
        query = get_query(epochtime_for_previous_date) 
        schema = get_schema()
        trip_statistics_index  = read_opensearch_index(glueContext,os_connector_name,read_partitions,query,source_os_index)
        trip_statistics_index = fill_missing_columns_with_null(trip_statistics_index,schema)
        
        transform_and_load_into_datalake(spark,trip_statistics_index,recordkey,partition_field,precombine_field,target_table_name,\
            target_database,target_hudi_table_path,metrics_bucket_name,metrics_cumulative_path,s3_client,target_table_name_cum,metrics_path)
            
        #get cloudwatch details
        cloudwatch_url = get_cloudwatch_url(region_name, job_name, job_run_id)
        end_time = datetime.now()
        duration = (end_time - start_time).seconds
        
        num_records = trip_statistics_index.count()
        # Log audit
        log_audit(
                spark,job_name,source_os_index,source_type,target_table_name,target_type,"Completed",start_time,end_time,\
                    num_records,audit_path,audit_table,
                )
        logging.info(f"Job completed successfully in {duration} seconds")
        
        log = {
            "status": "success",
            "job_name": job_name,
            "source_table": source_os_index,
            "target_table": target_table_name,
            "start_time": start_time.isoformat(),
            "end_time": end_time.isoformat(),
            "duration": duration,
            "num_records": num_records
        }
                    
    except Exception as e:
        logging.error("Job failed with error: %s", str(e))
        traceback.print_exc()
        end_time = datetime.now()
        duration = end_time - start_time
        logging.error(f"Job failed in {duration} seconds")
        #get cloudwatch details 
        cloudwatch_url = get_cloudwatch_url(region_name, job_name, job_run_id)
        log = {
                "status": "failure",
                "job_name": job_name,
                "source_table": source_os_index,
                "target_table": target_table_name,
                "start_time": start_time.isoformat(),
                "end_time": end_time.isoformat(),
                "duration": duration,
                "error": f"Error: {str(e)}\nTraceback: {traceback.format_exc()}"
            }
        
        # Log audit
        log_audit(
                spark,job_name,source_os_index,source_type,target_table_name,target_type,\
                "Failed",start_time,end_time,None,audit_path,audit_table,
                )
            
        log_message = "\n".join([f"{key}: {value}" for key, value in log.items()])
        message = f"Job -{job_name} failed. Transformation returned None.\n\n{log_message}.\n\nView the logs in CloudWatch:{cloudwatch_url}"
        subject= f"Job Failed : Job - {job_name}"
        send_sns_notification(subject, message, sns_secret_name,region_name)
        raise
    
if __name__ == "__main__":
    main()
