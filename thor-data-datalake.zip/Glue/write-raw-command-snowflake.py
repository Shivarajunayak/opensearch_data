import boto3
import logging
import sys
import traceback
from datetime import datetime
import snowflake.connector
import pandas as pd
import yaml
import json
from awsglue.utils import getResolvedOptions

from hmcl_cv_common_utilities import  update_watermark_file, get_watermark_timestamp,send_sns_notification,get_cloudwatch_url,load_yaml_config,log_audit,initialize_spark_session,validate_audit_table_with_s3_partition

logging.basicConfig(level=logging.INFO, format="%(asctime)s - %(name)s - %(levelname)s -%(message)s")
logger = logging.getLogger()


def fetch_snowflake_credentials(secret_name):
    client = boto3.client('secretsmanager')
    response = client.get_secret_value(SecretId=secret_name)
    secret = json.loads(response['SecretString'])
    return secret
    
def get_snowflake_connection(sfUser,sfPassword,sfURL):
    """
    Establish and return a Snowflake connection.
    """
    try:
        conn = snowflake.connector.connect(
        user=sfUser,
        password=sfPassword,
        account = sfURL.split('//')[1].split('.snowflakecomputing.com')[0]
    )
        logging.info("Snowflake connection established.")
        return conn
    except Exception as e:
        logging.error(f"Error establishing Snowflake connection: {e}")
        raise
    
def get_table_schema(conn, table_name, exclude_columns=None):
    """
    Retrieve the schema of the specified table as a list of column names.
    Optionally exclude specific columns from the schema.
    
    :param conn: Snowflake connection object
    :param table_name: Name of the table
    :param exclude_columns: List of column names to exclude (case-sensitive)
    :return: List of column names in the schema (excluding specified columns)
    """
    exclude_columns = exclude_columns or []
    schema_query = f"DESCRIBE TABLE {table_name}"
    schema_result = conn.cursor().execute(schema_query)
    schema_columns = [row[0] for row in schema_result]  # Assuming the first column in result is the column name
    # Exclude specified columns
    schema_columns = [col for col in schema_columns if col not in exclude_columns]
    return schema_columns

def merge_into_target_table(conn, ext_table, target_table, primary_key_column, current_watermark, ext_table_schema):
    """
    Performs a MERGE INTO operation to upsert data from the external table to the target table.
    """
    
    # Refresh table
    refresh_query = f"ALTER EXTERNAL TABLE {ext_table} REFRESH"
    conn.cursor().execute(refresh_query)
    logging.info(f"External table {ext_table} refreshed.")
    
    # Exclude 'VALUE' column from the schema
    filtered_schema = [col for col in ext_table_schema if col.upper() != "VALUE"]
    
     # Debug: Count rows to be merged
    debug_query = f"""
        SELECT COUNT(1)
        FROM {ext_table}
        WHERE _hoodie_commit_time > '{current_watermark}'
    """
    with conn.cursor() as cursor:
        cursor.execute(debug_query)
        num_records = cursor.fetchone()[0]
        logging.info(f"Records to be merged: {num_records}")

    merge_query = f"""
        MERGE INTO {target_table} AS tgt
		USING (
			SELECT *
			FROM (
				SELECT *,
					   ROW_NUMBER() OVER (
						   PARTITION BY {primary_key_column}
						   ORDER BY SPLIT_PART(SPLIT_PART(_hoodie_file_name, '.', 1), '_', 3) DESC
					   ) AS rn
				FROM {ext_table}
				WHERE _hoodie_commit_time >= '{current_watermark}'
			)
			WHERE rn = 1
		) AS src
		ON tgt.{primary_key_column} = src.{primary_key_column}
		WHEN MATCHED THEN
			UPDATE SET {', '.join([f'tgt.{col} = src.{col}' for col in filtered_schema if col != primary_key_column])}
		WHEN NOT MATCHED THEN
			INSERT ({', '.join(filtered_schema)})
			VALUES ({', '.join([f'src.{col}' for col in filtered_schema])});
    """
    logging.info("Executing MERGE INTO command for upsert")
    
    try:
        with conn.cursor() as cursor:
            cursor.execute(merge_query)
            logging.info(f"Merge completed successfully for target table: {target_table}")
    except Exception as e:
        logging.error(f"Error during MERGE INTO operation: {e}")
        logging.error(f"Failed MERGE Query:\n{merge_query}")
        raise
    
    return num_records


def check_table_exists(spark,conn, target_table, job_name, sns_secret_name, region_name, start_time, audit_path, audit_table,ext_table,source_type,target_type):
    # Extract the table name (assumes target_table is in format 'database.schema.table')
    table_name = target_table.split('.')[2]
    
    # Create the query to check if the table exists
    check_table_query = f"SHOW TABLES LIKE '{table_name}'"
    
    # Execute the query to check if the table exists
    cursor = conn.cursor()
    cursor.execute(check_table_query)
    table_exists = cursor.fetchone()
    
    if not table_exists:
        # Log the error and notify via SNS
        logging.error(f"Target table {target_table} does not exist. Aborting job.")
        end_time = datetime.now()
        # Log the audit information
        log_audit(spark, job_name, ext_table, source_type, target_table, target_type, "Aborted", start_time, end_time, None, audit_path, audit_table)
        
        # Send SNS notification about the failure
        subject = f"{job_name} failed - Missing Target Table"
        if len(subject)>100:
            subject = subject[:97] + '..'
        send_sns_notification("job failed", f"The target table {target_table} does not exist.", sns_secret_name, region_name)
        
        # Optional: Raise an exception or return early to stop the job
        raise Exception(f"Target table {target_table} does not exist. Job aborted.")
        
def compare_schemas(ext_table_schema, tgt_table_schema):

    ext_table_schema = set(ext_table_schema)  # Convert to set
    tgt_table_schema = set(tgt_table_schema)   # Convert to set

    missing_columns = list(tgt_table_schema - ext_table_schema)
    new_columns = list(ext_table_schema - tgt_table_schema)

    return missing_columns, new_columns


def handle_schema_mismatch(spark,sns_secret_name,job_name, missing_columns,region_name,ext_table,target_table,ext_table_schema,tgt_table_schema,source_type,target_type,audit_path,audit_table,start_time):
    """
    Handles schema mismatches by logging and raising a notification.
    """
    schema_status = "Aborted"
    error_message = f"Missing columns in exteranl table {ext_table}: {', '.join(missing_columns)}.\n\n ext table schema is : \n\n{ext_table_schema} and target schema is :\n\n{tgt_table_schema}"
    logging.error(error_message)
    
    # Log the error
    end_time = datetime.now()
    duration = (end_time - start_time).seconds
    log_audit(spark, job_name, ext_table, source_type, target_table, target_type, schema_status, start_time, end_time, None, audit_path, audit_table)
    
    # Send SNS notification
    subject = f"Job {job_name} - Aborted for table {target_table} - Schema Validation Failed"
    send_sns_notification(subject[:98] + '..' if len(subject) > 100 else subject, error_message, sns_secret_name,region_name)
    raise ValueError(error_message)


			
def handle_new_columns(spark,sns_secret_name, job_name,ext_table, target_table, new_columns,region_name,source_type,target_type, audit_path, audit_table,start_time,source_table_name):
    """
    Handles the detection of new columns by sending a notification.
    """
    schema_status = "Aborted"
    new_columns_message = f"New columns detected in source table: {', '.join(new_columns)}"
    logging.error(new_columns_message)
    
     # Log the error
    end_time = datetime.now()
    duration = (end_time - start_time).seconds
    log_audit(spark, job_name, ext_table, source_type, target_table, target_type, schema_status, start_time, end_time, None, audit_path, audit_table)
    
    # Send SNS notification
    subject = f"Job - {job_name} Succeeded for table {source_table_name}- with new Schema "
    send_sns_notification(subject[:98] + '..' if len(subject) > 100 else subject, new_columns_message, sns_secret_name,region_name)
    raise ValueError(new_columns_message)
    

 
def get_evaluated_schema(spark,job_name,ext_table,target_table,sns_secret_name,region_name,conn,source_type,target_type,audit_path,audit_table,start_time,source_table_name):
    """
    Adjust schema based on target table schema and send notifications if there are discrepancies.
    """
    try:
        schema_status = "Success"
        
        # Fetch schema from PostgreSQL and validate
        ext_table_schema = get_table_schema(conn, ext_table, exclude_columns=["VALUE"])
        tgt_table_schema = get_table_schema(conn, target_table)
        # pg_table_schema, landing_columns = fetch_schemas()
        
        # Compare schemas and detect missing/new columns
        missing_columns, new_columns = compare_schemas(ext_table_schema, tgt_table_schema)
        
        if missing_columns:
            handle_schema_mismatch(spark,sns_secret_name,job_name, missing_columns,region_name,ext_table,target_table,ext_table_schema,tgt_table_schema,source_type,target_type,audit_path,audit_table,start_time)
        elif new_columns:
            handle_new_columns(spark,sns_secret_name, job_name,ext_table, target_table, new_columns,region_name,source_type,target_type, audit_path, audit_table,start_time,source_table_name)
        return schema_status,ext_table_schema

    except Exception as e:
        logging.error(f"An error occured while Validating the schema : {str(e)}")
        raise

def main():
    
    # Initiate logging
    log = {}
    s3_client = boto3.client('s3')
    
    try:
        logging.info("Job started")
        start_time = datetime.now()

        # Initialize Spark session
        spark=initialize_spark_session()
        
        # Define and resolve arguments
        arguments = [
            "JOB_NAME",
            "yaml_file_key",
            "yaml_s3_bucket",
            "source_table_name"
        ]
        args = getResolvedOptions(sys.argv, arguments)
        
        job_name = args.get("JOB_NAME")
        yaml_s3_bucket = args.get("yaml_s3_bucket")
        yaml_file_key = args.get("yaml_file_key")
        source_table_name = args.get("source_table_name")
        JOB_RUN_ID = args.get("JOB_RUN_ID")
        logging.info(f"job run id is : {JOB_RUN_ID}")
        
        logging.info(f"Job name: {job_name}")

        # Load YAML configurations
        try:
            yaml_dict = load_yaml_config(s3_client, yaml_s3_bucket, yaml_file_key)
            logging.info("Configurations loaded successfully.")
        except Exception as e:
            logging.error(f"Error loading configurations or credentials: {e}")
            traceback.print_exc()
            raise

        # Extract and process configurations
        try:
            snowflake_secret_name = yaml_dict['paths'][source_table_name]['snowflake_secret_name']
            sns_secret_name = yaml_dict['paths'][source_table_name]['sns_secret_name']
            ext_table = yaml_dict['paths'][source_table_name]['ext_table']
            watermark_bucket = yaml_dict['paths'][source_table_name]['watermark_bucket']
            watermark_file_key = yaml_dict['paths'][source_table_name]['watermark_file_key']
            region_name = yaml_dict['paths'][source_table_name]['region']
            primary_key_column = yaml_dict['paths'][source_table_name]['primary_key_column']
            target_table = yaml_dict['paths'][source_table_name]['target_table']
            audit_path = yaml_dict['paths'][source_table_name]['audit_path']
            audit_table = yaml_dict['paths'][source_table_name]['audit_table']
            source_type = yaml_dict['paths'][source_table_name]['source_type']
            target_type = yaml_dict['paths'][source_table_name]['target_type']
            
            year_partitioned=start_time.year
            month_partitioned=start_time.month
             #Validate the audit table to process the job based on job_status
            is_validate = validate_audit_table_with_s3_partition(spark,sns_secret_name,start_time,audit_path,audit_path,ext_table,target_table,job_name,region_name,year_partitioned,month_partitioned )
            if is_validate == False:
                logging.error("Job is being aborted due to concurrent execution.")
                return

            # Extract Snowflake credentials
            secret_dict = fetch_snowflake_credentials(snowflake_secret_name)
            logging.info("Snowflake credentials loaded successfully")
            sfURL = secret_dict['url']
            sfPassword = secret_dict['password']
            sfUser = secret_dict['username']
        except KeyError as e:
            logging.error(f"Configuration key error: {e}")
            traceback.print_exc()
            raise
        try:
            
            log_audit(
                spark,
                job_name,
                ext_table,
                source_type,
                target_table,
                target_type,
                "Started",
                start_time,
                None,
                None,
                audit_path,
                audit_table,
            )
            logging.info("logs written to audit table")
        except Exception as audit_exception:
            logging.error("An error occurred while entering logs to audit table: %s", str(audit_exception))
            logging.error("Traceback: %s", traceback.format_exc())
                

        # Get current watermark
        current_watermark = get_watermark_timestamp(s3_client, watermark_bucket, watermark_file_key)
        logging.info(f"Current watermark: {current_watermark}")
        
        # Initialize Snowflake connection
        conn=get_snowflake_connection(sfUser,sfPassword,sfURL)

        # Step 1: Check if Target Table Exists
        
        check_table_exists(spark,conn, target_table, job_name, sns_secret_name, region_name, start_time, audit_path, audit_table,ext_table,source_type,target_type)
        # Continue job logic if table exists

        schema_status,ext_table_schema=get_evaluated_schema(spark,job_name,ext_table,target_table,sns_secret_name,region_name,conn,source_type,target_type,audit_path,audit_table,start_time,source_table_name)
        logging.info(f"Schema status after evaluation: {schema_status}")
                
        if schema_status == "Aborted":
            logging.error("Schema validation failed. Aborting the job.")
            return False
            
        logging.info("Schema validation successful. Proceeding with merge operation.")

        # Step 3: Fetch the Current Watermark
        current_watermark = get_watermark_timestamp(s3_client, watermark_bucket, watermark_file_key)
        logging.info(f"Current watermark: {current_watermark}")

        # Step 4: Perform Incremental Query and Merge Operation
        num_records=merge_into_target_table(conn,ext_table, target_table, primary_key_column,current_watermark,ext_table_schema)

        # Step 5: Update the Watermark After Merge
        new_watermark_query = f"""
            SELECT MAX(_hoodie_commit_time) FROM {ext_table}
        """
        new_watermark = conn.cursor().execute(new_watermark_query).fetchone()[0]
        logging.info(f"New watermark calculated: {new_watermark}")

        update_watermark_file(s3_client, new_watermark, watermark_bucket, watermark_file_key, target_table)
        
        end_time = datetime.now()
        
        log_audit(
            spark,
            job_name,
            ext_table,
            source_type,
            target_table,
            target_type,
            "Completed",
            start_time,
            end_time,
            num_records,
            audit_path,
            audit_table,
        )

    except Exception as e:
        logging.error(f"Job failed with error: {str(e)}")
        traceback.print_exc()
        
        end_time = datetime.now()
        duration = (end_time - start_time).seconds
        
        cloudwatch_url = get_cloudwatch_url(region_name,job_name, JOB_RUN_ID)
        
        try :
            
            log_audit(
                spark,
                job_name,
                ext_table,
                source_type,
                target_table,
                target_type,
                "Failed",
                start_time,
                end_time,
                None,
                audit_path,
                audit_table,
            )
        except Exception as audit_exception:
            logging.error("An error occurred while entering logs to audit table: %s", str(audit_exception))
            logging.error("Traceback: %s", traceback.format_exc())
        
        log = {
            "status": "failure",
            "job_name": job_name,
            "source_table": ext_table,
            "target_table": target_table,
            "start_time": start_time.isoformat(),
            "end_time": end_time.isoformat(),
            "duration": duration,
            "error": f"Error: {str(e)}\nTraceback: {traceback.format_exc()}"
        }
     
        log_message = "\n".join([f"{key}: {value}" for key, value in log.items()])
        message = f"Job {job_name} failed. Error: {str(e)}\nTraceback: {traceback.format_exc()} \n\n{log_message}.\n\nView the logs in CloudWatch:{cloudwatch_url}"
        
        subject =f'{job_name} failed for {ext_table} table'
        if len(subject) > 100:
            subject = subject[:98] + '..'  # Truncate if needed
        
        send_sns_notification(subject, message, sns_secret_name, region_name)

    finally:
        end_time = datetime.now()
        duration = (end_time - start_time).seconds
        logging.info(f"Job completed in {duration} seconds")

if __name__ == "__main__":
    main()