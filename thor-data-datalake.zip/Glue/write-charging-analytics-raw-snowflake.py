import boto3
import logging
import sys
import traceback
from datetime import datetime
import snowflake.connector
import json
from awsglue.utils import getResolvedOptions
from concurrent.futures import ThreadPoolExecutor

from hmcl_cv_common_utilities import  update_watermark_file, get_watermark_timestamp,send_sns_notification,\
    get_cloudwatch_url,load_yaml_config,log_audit,initialize_spark_session,validate_audit_table_with_s3_partition

logging.basicConfig(level=logging.INFO, format="%(asctime)s - %(name)s - %(levelname)s -%(message)s")
logger = logging.getLogger()

def read_job_param():
    try:
    
        # Define arguments
        arguments = [
            "JOB_NAME",
            "yaml_s3_bucket",
            "yaml_file_key",
            "source_table_name",
        ]
        # Get the arguments
        args = getResolvedOptions(sys.argv, arguments)
        job_name = args.get("JOB_NAME")
        job_run_id = args.get("JOB_RUN_ID")
        yaml_s3_bucket = args.get("yaml_s3_bucket")
        yaml_file_key = args.get("yaml_file_key")
        source_table_name = args.get("source_table_name")
        logging.info("Job parameters read successfully")
        return yaml_s3_bucket,yaml_file_key,job_name,job_run_id,source_table_name
        
    except Exception as e:
        logging.error(f"Error while reading job parameters: {str(e)}")
        traceback.print_exc()
        raise

def read_yaml_file(s3_client,yaml_s3_bucket,yaml_file_key,source_table_name):
    try:
        yaml_dict = load_yaml_config(s3_client,yaml_s3_bucket,yaml_file_key)
        snowflake_secret_name = yaml_dict['paths'][source_table_name]['snowflake_secret_name']
        sns_secret_name = yaml_dict['paths'][source_table_name]['sns_secret_name']
        ext_table = yaml_dict['paths'][source_table_name]['ext_table']
        watermark_bucket = yaml_dict['paths'][source_table_name]['watermark_bucket']
        watermark_file_key = yaml_dict['paths'][source_table_name]['watermark_file_key']
        region_name = yaml_dict['paths'][source_table_name]['region']
        target_table = yaml_dict['paths'][source_table_name]['target_table']
        audit_path = yaml_dict['paths'][source_table_name]['audit_path']
        audit_table = yaml_dict['paths'][source_table_name]['audit_table']
        source_type = yaml_dict['paths'][source_table_name]['source_type']
        target_type = yaml_dict['paths'][source_table_name]['target_type']
        watermark_column = yaml_dict['paths'][source_table_name]['watermark_column']        
        logging.info("yaml parameters read successfully")
        return snowflake_secret_name,sns_secret_name,ext_table,watermark_bucket,watermark_file_key,\
            region_name,target_table,audit_path,audit_table,source_type,target_type,watermark_column
    except Exception as e:
        logging.error(f"Error while reading yaml parameters: {str(e)}")
        traceback.print_exc()
        raise


def fetch_snowflake_credentials(secret_name):
    try:
        client = boto3.client('secretsmanager')
        response = client.get_secret_value(SecretId=secret_name)
        secret = json.loads(response['SecretString'])
        return secret
    except Exception as e:
        logging.error(f"Error while fetching snowflake credentials: {str(e)}")
        traceback.print_exc()
        raise
    
def get_snowflake_connection(sfUser,sfPassword,sfURL):
    """
    Establish and return a Snowflake connection.
    """
    try:
        conn = snowflake.connector.connect(
        user=sfUser,
        password=sfPassword,
        account = sfURL.split('//')[1].split('.snowflakecomputing.com')[0]
    )
        logging.info("Snowflake connection established.")
        return conn
    except Exception as e:
        logging.error(f"Error establishing Snowflake connection: {str(e)}")
        traceback.print_exc()
        raise

def refresh_external_table(conn, ext_table):
    """
    Refreshes the external table to ensure the latest data is available.
    """
    refresh_query = f"ALTER EXTERNAL TABLE {ext_table} REFRESH"
    try:
        conn.cursor().execute(refresh_query)
        logging.info(f"External table {ext_table} refreshed.")
    except Exception as e:
        logging.error(f"Failed to refresh external table {ext_table}: {e}")
        raise


def count_incremental_records(conn, ext_table, watermark_column, current_watermark):
    """
    Counts the number of incremental records based on the watermark.
    """
    debug_query = f"""
        SELECT COUNT(*)
        FROM {ext_table}
        WHERE {watermark_column} > '{current_watermark}'
    """
    try:
        with conn.cursor() as cursor:
            cursor.execute(debug_query)
            num_records = cursor.fetchone()[0]
            logging.info(f"Records to be processed: {num_records}")
            return num_records
    except Exception as e:
        logging.error(f"Error during row count validation: {e}")
        traceback.print_exc()
        raise
    
def merge_data(conn, target_table, merge_query):
    """
    Executes the MERGE query to either update or insert data into the target table.
    """
    
    logging.info("Executing MERGE query.")
    try:
        with conn.cursor() as cursor:
            cursor.execute(merge_query)
            conn.commit()
            logging.info(f"data inserted successfully into target table: {target_table}")
    except Exception as e:
        logging.error(f"Error during MERGE operation: {e}")
        logging.error(f"Failed MERGE Query:\n{merge_query}")
        traceback.print_exc()
        raise
    
def get_target_table_columns(conn, target_table_name):
    """
    Fetches the column names of the target table in order.
    """
    try:
        query = f"DESCRIBE TABLE {target_table_name}"
        with conn.cursor() as cursor:
            cursor.execute(query)
            result = cursor.fetchall()
            # Extract column names
            return [row[0] for row in result]
    except Exception as e:
        logging.error(f"Error while fetching target table columns: {str(e)}")
        traceback.print_exc()
        raise
    
def generate_insert_query(conn,sf_target_table_name,sf_ext_table,watermark_column,current_watermark):
    
    try:
        target_columns = get_target_table_columns(conn, sf_target_table_name)
        
        modified_columns = ", ".join([f"{col}" for col in target_columns if not col.startswith('_HOODIE')])
        insert_query = f"""INSERT INTO {sf_target_table_name}
        SELECT {modified_columns}
        FROM {sf_ext_table}
        WHERE {watermark_column} > '{current_watermark}';
        """
        logging.info("INSERT Query :")
        logging.info(insert_query)
        return insert_query

    except Exception as e:
        logging.error(f"Error while generating pivot query: {str(e)}")
        traceback.print_exc()
        raise
    
def load_data_into_snowflake_table(conn, sf_target_table_name,sf_ext_table_name,current_watermark, watermark_column):
    """
    Main function to flatten and merge incremental data from the external table into the target table.
    """
    try:
        # Refresh the external table
        refresh_external_table(conn, sf_ext_table_name)

        num_records = count_incremental_records(conn, sf_ext_table_name, watermark_column, current_watermark)
        if num_records == 0:
            logging.info("No new records to process.")
            return num_records
        
        insert_query = generate_insert_query(conn,sf_target_table_name,sf_ext_table_name,watermark_column,current_watermark)

        merge_data(conn, sf_target_table_name, insert_query)
        logging.info(f"number of records processed : {num_records}")
        return num_records
    except Exception as e:
        logging.error(f"Error while loading data into snowflake: {str(e)}")
        traceback.print_exc()
        raise

def main():
    
    try:
        logging.info("Job started")
        start_time = datetime.now()

        yaml_s3_bucket,yaml_file_key,job_name,job_run_id,source_table_name = read_job_param()
        logging.info("job_name=%s", job_name+"/"+source_table_name)

        #initialize spark job
        spark = initialize_spark_session()
        
        #create an S3 client
        s3_client = boto3.client('s3')


        #read necessary  parameters from yaml file
        snowflake_secret_name,sns_secret_name,ext_table,watermark_bucket,watermark_file_key,\
        region_name,target_table,audit_path,audit_table,source_type,target_type,watermark_column \
             = read_yaml_file(s3_client,yaml_s3_bucket,yaml_file_key,source_table_name)
    except Exception as e:
        logging.error(f"Error in initial steps: {str(e)}")
        traceback.print_exc()
        raise

    try:
        year_partitioned=start_time.year
        month_partitioned=start_time.month            
        is_validate = validate_audit_table_with_s3_partition(spark,sns_secret_name,start_time,audit_path,audit_path,ext_table,target_table,job_name,region_name,year_partitioned,month_partitioned)

        if is_validate == False:
            return 
        
        secret_dict = fetch_snowflake_credentials(snowflake_secret_name)
        logging.info("Snowflake credentials loaded successfully")
        sfURL = secret_dict['url']
        sfPassword = secret_dict['password']
        sfUser = secret_dict['username']
        
        log_audit(spark,job_name,ext_table,source_type,target_table,target_type,"Started",start_time,None,None,audit_path,audit_table)
        logging.info("logs written to audit table")
                    
        # Initialize Snowflake connection
        conn=get_snowflake_connection(sfUser,sfPassword,sfURL)
        
        current_watermark = get_watermark_timestamp(s3_client, watermark_bucket, watermark_file_key)
        logging.info("checking current_watermark dtype")
        if current_watermark == 0:
            current_watermark = '19700000000000000'
        logging.info(f"Current watermark: {current_watermark}")

        # Check if Target Table Exists        
        check_table_query = f"SHOW TABLES LIKE '{target_table.split('.')[2]}'"
        table_exists = conn.cursor().execute(check_table_query).fetchone()
        
        if not table_exists:
            logging.error(f"Target table {target_table} does not exist. Aborting job.")
            send_sns_notification(f"{job_name} failed - Missing Target Table", f"The target table {target_table} does not exist.", sns_secret_name, region_name)
            return False  # Exit the function early

        num_records = load_data_into_snowflake_table(conn, target_table,ext_table,current_watermark, watermark_column)
        
        if num_records > 0:
            new_watermark_query = f"""
            SELECT MAX(_hoodie_commit_time) FROM {ext_table}"""
            new_watermark = conn.cursor().execute(new_watermark_query).fetchone()[0]
            logging.info(f"New watermark calculated: {new_watermark}")

            update_watermark_file(s3_client, new_watermark, watermark_bucket, watermark_file_key, target_table)
            
        end_time = datetime.now()
        
        log_audit(spark,job_name,ext_table,source_type,target_table,target_type,"Completed",start_time,end_time,num_records,audit_path,audit_table)

    except Exception as e:
        logging.error(f"Job failed with error: {str(e)}")
        traceback.print_exc()
        
        end_time = datetime.now()
        duration = (end_time - start_time).seconds
        cloudwatch_url = get_cloudwatch_url(region_name,job_name, job_run_id)
        logging.info("writing to Exception audit logs")
        log_audit(spark,job_name,ext_table,source_type,target_table,target_type,"Failed",start_time,end_time,None,audit_path,audit_table)
        
        log = {
            "status": "failure",
            "job_name": job_name,
            "source_table": ext_table,
            "target_table": target_table,
            "start_time": start_time.isoformat(),
            "end_time": end_time.isoformat(),
            "duration": duration,
            "error": f"Error: {str(e)}\nTraceback: {traceback.format_exc()}"
        }
        log_message = "\n".join([f"{key}: {value}" for key, value in log.items()])
        message = f"Job {job_name} failed. Error: {str(e)}\nTraceback: {traceback.format_exc()} \n\n{log_message}.\n\nView the logs in CloudWatch:{cloudwatch_url}"
        subject =f'{job_name} failed for {ext_table} table'
        if len(subject) > 100:
            subject = subject[:98] + '..'
        send_sns_notification(subject, message, sns_secret_name, region_name)
        raise
    finally:
        end_time = datetime.now()
        duration = (end_time - start_time).seconds
        logging.info(f"Job completed in {duration} seconds")

if __name__ == "__main__":
    main()