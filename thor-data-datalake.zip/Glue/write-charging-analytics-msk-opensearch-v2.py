"""
AWS Glue Job: Charging Analytics Pipeline
Purpose: Read Data from MSK and Write to Open Search

"""
# pylint: disable=import-error
import sys
import logging
import json
import re
import traceback
from botocore.exceptions import ClientError
from datetime import datetime
import boto3
from boto3.dynamodb.conditions import Key, Attr
from awsglue.utils import getResolvedOptions
from awsglue.context import GlueContext
from awsglue.dynamicframe import DynamicFrame
from pyspark.sql import functions as F
from pyspark.sql.window import Window
from pyspark.sql import SparkSession
from pyspark.sql.types import (
    StructType,
    StructField,
    StringType,
    DecimalType,
    DoubleType,
    TimestampType,
    LongType,
    BooleanType,
    ArrayType,
)
from pyspark.sql.functions import(
    array_max,
    transform,
    col
)
from hmcl_cv_common_utilities import (
    log_audit,
    get_cloudwatch_url,
    send_sns_notification,
    validate_audit_table,
)

ssm = boto3.client("ssm")
logging.basicConfig(
    level=logging.INFO, format="%(asctime)s - %(name)s - %(levelname)s - %(message)s"
)
FORMAT_STR = "%Y-%m-%d %H:%M:%S"

# Method to get latest values from array of signal samples
def get_latest_value(col):
    try:
        if not col:
            return None  # Handle empty case
        latest_entry = max(col, key=lambda x: x["time"])
        return latest_entry["value"]
    except Exception as e:
        logging.error(
            "Error occured while getting the latest value from array of siganls: %s", e
        )
        logging.error(traceback.format_exc())
        raise

# Flattens array columns in a DataFrame containing structs with value, time, and dataType fields.
def flatten_array_df(df, array_attr_to_flatten, time_needed_cols):
    try:
        # Create default empty struct for handling null/empty arrays
        default_value = F.array(
            F.struct(
                F.lit(None).cast("string").alias("value"),
                F.lit(None).cast("bigint").alias("time"),
                F.lit(None).cast("string").alias("dataType"),
            )
        )
        
        # Identify columns that don't need flattening
        not_flattened_columns = [
            col for col in df.columns if col not in array_attr_to_flatten
        ]
        
        # Zip all array columns together, replacing empty/null arrays with default value
        zipped_df = df.select(
            *not_flattened_columns,
            F.arrays_zip(
                *[
                    F.when(
                        (F.size(F.col(col)) == 0) | (F.col(col).isNull()), 
                        default_value
                    )
                    .otherwise(F.col(col))
                    .alias(col)
                    for col in array_attr_to_flatten
                ]
            ).alias("zipped_arrays"),
        )
        
        # Explode the zipped arrays to create a row for each array element
        # pos = position index, zipped_values = struct containing all array values
        exploded_df = zipped_df.select(
            *not_flattened_columns,
            F.posexplode(F.col("zipped_arrays")).alias("pos", "zipped_values"),
        )
        
        # Extract values from each struct in the exploded array
        flattened_columns = []
        for col_name in array_attr_to_flatten:
            # Extract the "value" field for each column
            flattened_columns.append(
                F.when(
                    F.col("zipped_values").getField(col_name).isNotNull(),
                    F.col("zipped_values").getField(col_name).getField("value"),
                )
                .otherwise(F.lit(None))
                .alias(f"{col_name}")
            )
            
            # For specified columns, also extract the "time" field
            if col_name in time_needed_cols:
                flattened_columns.append(
                    F.when(
                        F.col("zipped_values").getField(col_name).isNotNull(),
                        F.col("zipped_values").getField(col_name).getField("time"),
                    )
                    .otherwise(F.lit(None))
                    .alias(f"{col_name}_time")
                )

        # Create flattened DataFrame with extracted values
        # Special handling for total_usable_energy.time as polling_time
        flattened_df = exploded_df.select(
            *not_flattened_columns,
            *flattened_columns,
            F.col("zipped_values")
            .getField("total_usable_energy")
            .getField("time")
            .alias("polling_time"),
            F.col("pos"),
        )

        # Define window for forward-filling null values (ascending by position)
        window_spec1 = (
            Window.partitionBy(F.col("virtualId"), F.col("collectionEventTime"))
            .orderBy(F.col("pos"))
            .rowsBetween(Window.unboundedPreceding, Window.currentRow)
        )

        # Define window for backward-filling null values (descending by position)
        window_spec2 = (
            Window.partitionBy(F.col("virtualId"), F.col("collectionEventTime"))
            .orderBy(F.col("pos").desc())
            .rowsBetween(Window.unboundedPreceding, Window.currentRow)
        )

        # Get list of time columns that were created
        flattened_time_column = [col + "_time" for col in time_needed_cols]

        # Fill forward missing values using window function
        flattened_df_fill_na = flattened_df.select(
            *not_flattened_columns,
            *[
                F.coalesce(
                    F.col(col_name),
                    F.last(F.col(col_name), ignorenulls=True).over(window_spec1),
                ).alias(col_name)
                for col_name in (array_attr_to_flatten + flattened_time_column)
            ],
            "pos",
        )

        # Fill backward any remaining missing values
        flattened_df_fill_na = flattened_df_fill_na.select(
            *not_flattened_columns,
            *[
                F.coalesce(
                    F.col(col_name),
                    F.last(F.col(col_name), ignorenulls=True).over(window_spec2),
                ).alias(col_name)
                for col_name in (array_attr_to_flatten + flattened_time_column)
            ],
        )
        return flattened_df_fill_na
    except Exception as e:
        logging.error("Error happened while flattening array attributes: %s", e)
        logging.error(traceback.format_exc())
        raise

# Casts specified columns in a DataFrame to the desired data types.
def cast_selected_columns(df, columns_to_cast):
    try:
        # Create expressions for each column, applying casting only to specified columns
        casted_columns = [
            F.col(col).cast(columns_to_cast[col]).alias(col) if col in columns_to_cast
            else F.col(col)
            for col in df.columns
        ]

        # Apply all column expressions to create the new DataFrame
        casted_df = df.select(*casted_columns)
        
        return casted_df
    except Exception as exp:
        logging.error("Error casting datatypes: %s", exp)
        logging.error(traceback.format_exc())
        raise

# Flattens complex nested structures (structs and maps) in a Spark DataFrame. This function transforms nested columns into a flat structure.
def flatten_dataframe(df_to_flatten):
    try:
        types = [
            item
            for item in df_to_flatten.dtypes
            if item[1].startswith("struct") or item[1].startswith("map")
        ]
        # while types:
        me_cols = []
        se_cols = []
        drop_cols = []
        for s_col, typ in types:

            if typ.startswith("struct"):
                s_col_keys_temp = df_to_flatten.select(s_col + ".*").columns
                s_col_keys = [re.sub(r"[.-]", "_", col) for col in s_col_keys_temp]

                se_cols += [
                    F.col(s_col + "." + c).alias(s_col + "_" + c) for c in s_col_keys
                ]

            elif typ.startswith("map"):
                if s_col == "signals":
                    # here we have given column since getting column names dynamically  if data not there causing job failure
                    sample_map = [
                        "hmcl.ev.can0.soc_user_percentage",
                        "hmcl.ev.can0.bms1_soc_user_percentage",
                        "hmcl.ev.can0.bms2_soc_user_percentage",
                        "hmcl.ev.can0.battery_charging_status",
                        "hmcl.ev.can0.charger_identity",
                        "hmcl.ev.can0.charger_status",
                        "hmcl.ev.can0.charger_state",
                        "hmcl.ev.can0.soh_percentage",
                        "hmcl.ev.can0.bms1_soh_percentage",
                        "hmcl.ev.can0.bms2_soh_percentage",
                        "hmcl.ev.can0.total_usable_energy",
                        "hmcl.ev.can0.total_usable_energy_bms1",
                        "hmcl.ev.can0.total_usable_energy_bms2",
                        "hmcl.common.custom.charging_session_start",
                        "hmcl.common.custom.charging_session_end",
                        "hmcl.common.vcan0.latitude",
                        "hmcl.common.vcan0.longitude",
                        "hmcl.common.vcan0.gps_valid",
                        "hmcl.ev.can0.battery_pack_temperature",
                        "hmcl.ev.can0.bms1_battery_pack_temperature",
                        "hmcl.ev.can0.bms2_battery_pack_temperature",
                        "hmcl.common.vcan0.vdop",
                        "hmcl.common.vcan0.hdop",
                        "hmcl.common.vcan0.pdop",
                        "hmcl.common.vcan0.gps_fix",
                        "hmcl.ev.can0.bms_bdu_connection_request",
                        "hmcl.common.custom.charging_session_id",
                    ]
                    me_cols += [
                        F.col(s_col)[F.lit(key)].alias(
                            key.split(".")[-1].replace(".", "_")
                        )
                        for key in sample_map
                    ]

                else:
                    sample_map = df_to_flatten.select(s_col).head()[0]
                    me_cols += [
                        F.col(s_col)[F.lit(key)].alias(
                            key.split(".")[-1].replace(".", "_")
                        )
                        for key in sample_map.keys()
                    ]

            drop_cols.append(s_col)

        all_cols = df_to_flatten.select("*").columns
        all_cols_exploded = all_cols + se_cols + me_cols
        df_to_flatten = df_to_flatten.select(*all_cols_exploded)
        df_to_flatten = df_to_flatten.drop(*drop_cols)

        return df_to_flatten

    except Exception as e:
        logging.error("Error occurred while flattening complex data structures: %s", e)
        logging.error(traceback.format_exc())
        raise

# Method to Read Opensearch
def read_opensearch(glue_context, resource, connection_name, filter_query_json=None):
    try:
        source_data = glue_context.create_dynamic_frame.from_options(
            connection_type="opensearch",
            connection_options={
                "connectionName": connection_name,
                "opensearch.port": 443,
                "opensearch.resource": resource,
                "opensearch.query": filter_query_json,
                "pushdown": "true",
            },
        ).toDF()

        return source_data
    except Exception as e:
        logging.error("Error happened while reading data from openasearch: %s", e)
        logging.error(traceback.format_exc())
        raise

# Method to Write to Opensearch
def write_opensearch(glue_context, dynamic_frame, resource, connection_name):
    try:

        glue_context.write_dynamic_frame.from_options(
            frame=dynamic_frame,
            connection_type="opensearch",
            connection_options={
                "connectionName": connection_name,
                "opensearch.port": 443,
                "opensearch.resource": resource,
                "opensearch.batch.write.retry.wait": "60s",
                "opensearch.batch.write.retry.count": 6,
                "opensearch.write.operation": "index",
                "opensearch.mapping.id": "doc_id",
            },
        )
    except Exception as e:
        logging.error("Error happened while writing to opensearch index: %s", e)
        logging.error(traceback.format_exc())
        raise

# Method to Write to S3 Loaction
def write_s3(
    target_df,
    target_table_name,
    target_path,
    recordkey,
    precombine_field,
    partition_field,
    target_database,
    write_operation,
):
    
    try:

        hudi_options = {
            "hoodie.table.name": target_table_name,
            "hoodie.datasource.write.storage.type": "COPY_ON_WRITE",
            "hoodie.datasource.write.recordkey.field": recordkey,
            "hoodie.datasource.write.operation": write_operation,
            "hoodie.datasource.write.partitionpath.field": partition_field,
            "hoodie.datasource.hive_sync.enable": "true",
            "hoodie.datasource.hive_sync.database": target_database,
            "hoodie.datasource.hive_sync.table": target_table_name,
            "hoodie.datasource.hive_sync.use_jdbc": "false",
            "hoodie.datasource.hive_sync.mode": "hms",
            "hoodie.datasource.hive_sync.sync_as_datasource": "false",
            "hoodie.datasource.hive_sync.support_timestamp": "true",
            "path": target_path,
            "hoodie.parquet.max.file.size": "134217728",
            "hoodie.datasource.write.reconcile.schema": "true",
            "hoodie.datasource.write.precombine.field": precombine_field
        }

        logging.info(
            "Writing data to hoodi table %s to this path %s started",
            target_table_name,
            target_path,
        )

        target_df.write.format("org.apache.hudi").options(**hudi_options).mode(
            "append"
        ).save()

        logging.info(
            "Writing data to hoodi table %s to this path %s completed",
            target_table_name,
            target_path,
        )
    except Exception as e:
        logging.error("Error occured while loading data to S3: %s", e)
        logging.error(traceback.format_exc())

def main():
    """
    Main method
    """
    logging.info("Job started")
    start_time = datetime.now()
    arguments = [
        "JOB_NAME",
        "source_kafka_topic",
        "brokers",
        "offset",
        "schema",
        "target_bucket_name",
        "use_case_name",
        "opensearch_resource",
        "env",
        "source_type",
        "target_type",
        "audit_path",
        "audit_table",
        "campaign_name",
        "charging_off_campaign_name",
        "tenant_name",
        "folder_prefix",
        "target_table_name",
        "recordkey",
        "precombine_field",
        "partition_field",
        "target_database",
        "write_operation",
        "partition_extract_col",
        "region_name",
        "sns_secret_name",
    ]
    optional_arguments = [
        "campaign_name",
        "charging_off_campaign_name",
        "tenant_name",
        "folder_prefix",
        "target_table_name",
        "recordkey",
        "precombine_field",
        "partition_field",
        "target_database",
        "write_operation",
        "partition_extract_col",
        "region_name",
        "sns_secret_name",
    ]

    for argument in optional_arguments:
        if not f"--{argument}" in sys.argv:
            arguments.remove(argument)

    ## @params: [JOB_NAME]
    args = getResolvedOptions(sys.argv, arguments)
    logging.info("job_name=%s", args.get("JOB_NAME"))
    logging.info("intialising spark session")
    spark = (
        SparkSession.builder.config(
            "spark.serializer", "org.apache.spark.serializer.KryoSerializer"
        )
        .config("spark.hudi.query.metadata.enable", "true")
        .config("spark.sql.debug.maxToStringFields", 100)
        .getOrCreate()
    )

    glueContext = GlueContext(spark.sparkContext)

    logging.info("accessing job parameters and storing variables")

    region_name = args.get("region_name", "ap-south-1")
    job_name = args.get("JOB_NAME")
    job_run_id = args.get("JOB_RUN_ID")
    sns_secret_name = args.get("sns_secret_name", "sns_topic_arn")
    source_kafka_topic = args.get("source_kafka_topic")
    brokers = args.get("brokers")
    offset = args.get("offset")
    schema_json = args["schema"]
    target_bucket_name = args.get("target_bucket_name")
    use_case_name = args.get("use_case_name")
    opensearch_resource = args.get("opensearch_resource")
    env = args.get("env")
    source_type = args.get("source_type")
    target_type = args.get("target_type")
    audit_path = args.get("audit_path")
    audit_table = args.get("audit_table")
    campaign_name = args.get(
        "campaign_name", "hmcl-cv-fw-periodic-app-screen-telemetry-charge"
    )
    charging_off_campaign_name = args.get(
        "charging_off_campaign_name", "hmcl-cv-fw-charging-off-snapshot"
    )
    tenant_name = args.get("tenant_name", "EV-VIDA")
    folder_prefix = args.get("folder_prefix", "cvp_hudi")
    target_table_name = args.get(
        "target_table_name", f"hmcl_cv_{env}_charging_analytics"
    )
    recordkey = args.get("recordkey", "vid,chargingSessionId")
    precombine_field = args.get("precombine_field", "collectionEventTime_start")
    partition_field = args.get(
        "partition_field", "tenantId,use_case_name,year,month,day,hour"
    )
    target_database = args.get("target_database", f"hmcl_cv_{env}_glue_database")
    write_operation = args.get("write_operation", "upsert")
    partition_extract_col = args.get(
        "partition_extract_col", "session_startTimestamp_ts"
    )

    connectionName = f"hmcl-cv-{env}-opensearch-connector"

    try:

        logging.info("Calling log audit to log the status is job started")

        log_audit(
            spark,
            args["JOB_NAME"],
            source_kafka_topic,
            source_type,
            opensearch_resource,
            target_type,
            "Started",
            start_time,
            None,
            None,
            audit_path,
            audit_table,
        )

        logging.info("Reading data from MSK topic :%s", source_kafka_topic)

        df_kafka = (
            spark.readStream.format("kafka")
            .option("kafka.bootstrap.servers", brokers)
            .option("subscribe", source_kafka_topic)
            .option("kafka.security.protocol", "SASL_SSL")
            .option("kafka.sasl.mechanism", "AWS_MSK_IAM")
            .option(
                "kafka.sasl.jaas.config",
                "software.amazon.msk.auth.iam.IAMLoginModule required;",
            )
            .option(
                "kafka.sasl.client.callback.handler.class",
                "software.amazon.msk.auth.iam.IAMClientCallbackHandler",
            )
            .option("startingOffsets", offset)
            # .option(
            #    "startingOffsets", """{"topic1":{"0":23,"1":-2},"topic2":{"0":-2}}"""
            # )
            # .option("endingOffsets", """{"topic1":{"0":50,"1":-1},"topic2":{"0":-1}}""")
            # .option(
            #    "failOnDataLoss", "false"
            # )
            .load()
        )

        logging.info("Reading data from MSK topic - %s completed", source_kafka_topic)
        ## convert the value from byte to string
        df_kafka = df_kafka.selectExpr(
            "key",
            "cast(value as string) as value",
            "topic",
            "partition",
            "offset",
            "timestamp",
        )

        schema = StructType.fromJson(json.loads(schema_json))

        df_kafka = df_kafka.withColumn(
            "value", F.from_json(df_kafka["value"], schema)
        ).select(
            "value.*",
            F.col("timestamp").alias("kafka_timestamp"),
            "key",
            "topic",
            "partition",
            "offset",
        )

        filtered_df = df_kafka.filter(
            (F.col("campaignName").isin([campaign_name, charging_off_campaign_name]))
            & (F.col("dimensions")["hmcl.tenantId"] == tenant_name)
        )

        req_source_cols = [
            "soc_user_percentage",
            "bms1_soc_user_percentage",
            "bms2_soc_user_percentage",
            "bms_bdu_connection_request",            
            "charger_identity",
            "charger_status",
            "charger_state",
            "soh_percentage",
            "bms1_soh_percentage",
            "bms2_soh_percentage",
            "total_usable_energy",
            "total_usable_energy_bms1",
            "total_usable_energy_bms2",
            "virtualId",
            "tenantId",
            "campaignName",
            "eventId",
            "collectionEventTime",
            "charging_session_start",
            "charging_session_end",
            "longitude",
            "latitude",
            "gps_valid",
            "battery_pack_temperature",           
            "vdop",
            "hdop",
            "pdop",
            "gps_fix",
            "charging_session_id",
            "b2bClientId",
            # "bms1_battery_pack_temperature",
            # "bms2_battery_pack_temperature",
            # "battery_charging_status",
        ]

        array_attr = [
            "total_usable_energy",
            "total_usable_energy_bms1",
            "total_usable_energy_bms2",
            "soc_user_percentage",
            "bms1_soc_user_percentage",
            "bms2_soc_user_percentage",
            "bms_bdu_connection_request",            
            "charger_identity",
            "charger_status",
            "charger_state",
            "soh_percentage",
            "bms1_soh_percentage",
            "bms2_soh_percentage",
            "latitude",
            "longitude",
            "gps_valid",
            "gps_fix",
            "battery_pack_temperature",            
            "vdop",
            "hdop",
            "pdop",
            "charging_session_id",
            # "bms1_battery_pack_temperature",
            # "bms2_battery_pack_temperature",
            # "battery_charging_status",
        ]

        def process_batch(batch_df, batch_id):

            try:

                logging.info("batch count %s", batch_df.count())
                if batch_df.count() == 0:
                    logging.info("No new data present in the source. Stopping the process")
                    return

                logging.info("Calling flatten data frame to flatten the map items")

                flatten_df = flatten_dataframe(batch_df)

                # Block which checks for b2bclientid and adds it if not present
                
                if "b2bClientId" not in flatten_df.columns:
                    flatten_df = flatten_df.withColumn("b2bClientId", F.lit(None).cast(StringType()))

                flatten_df = flatten_df.select(*req_source_cols)

                logging.info("Flattening the array items to get latest values")

                time_needed_cols = ["charger_state", "charger_status", "bms_bdu_connection_request", "charging_session_id"]

                flatten_df = flatten_array_df(flatten_df, array_attr, time_needed_cols)

                # Getting charging session id and timestamps from the session start and end signals

                charging_session_start_schema = StructType(
                    [
                        StructField("chargingSessionId", StringType(), True),
                        StructField("startTimestamp", LongType(), True),
                    ]
                )

                charging_session_end_schema = StructType(
                    [
                        StructField("chargingSessionId", StringType(), True),
                        StructField("startTimestamp", LongType(), True),
                        StructField("endTimestamp", LongType(), True),
                    ]
                )

                window = Window.partitionBy(
                    F.col("virtualId"), F.col("chargingSessionId")
                )

                flatten_df = (
                    flatten_df.withColumn(
                        "charging_session_start",
                        F.from_json(
                            F.col("charging_session_start")[0].value,
                            charging_session_start_schema,
                        ),
                    )
                    .withColumn(
                        "charging_session_end",
                        F.from_json(
                            F.col("charging_session_end")[0].value,
                            charging_session_end_schema,
                        ),
                    )
                    .withColumn(
                        "chargingSessionId",
                        F.coalesce(
                            F.col("charging_session_start.chargingSessionId"),
                            F.col("charging_session_end.chargingSessionId"),
                            F.col("charging_session_id"),
                        ),
                    )
                    .withColumn(
                        "session_startTimestamp",
                        F.col("charging_session_start.startTimestamp"),
                    )
                    .withColumn(
                        "session_endTimestamp",
                        F.coalesce(
                            F.max(F.col("charging_session_end.endTimestamp")).over(window),
                            F.max(F.col("charging_session_id_time")).over(window),                            
                        ),
                    )
                )
                                             
                columns_to_cast = {
                    "total_usable_energy": "double",
                    "total_usable_energy_bms1": "double",
                    "total_usable_energy_bms2": "double",
                    "soc_user_percentage": "double",
                    "bms1_soc_user_percentage": "double",
                    "bms2_soc_user_percentage": "double",
                    "soh_percentage": "double",
                    "bms1_soh_percentage": "double",
                    "bms2_soh_percentage": "double",
                    "latitude": "double",
                    "longitude": "double",
                    "gps_valid": "boolean",
                    "gps_fix": "integer",
                    "battery_pack_temperature": "double",                    
                    "vdop": "float",
                    "hdop": "float",
                    "pdop": "float",
                    "charger_state": "integer",
                    "charger_status": "boolean",
                    "bms_bdu_connection_request": "integer",
                    # "bms1_battery_pack_temperature": "double",
                    # "bms2_battery_pack_temperature": "double",
                }

                flatten_df = cast_selected_columns(flatten_df, columns_to_cast)                              

                logging.info("Deriving charger type and charging location")
                df1 = (
                    flatten_df.withColumn(
                        "charging_type",
                        F.when(flatten_df["charger_identity"] == "1", "DC")
                        .when(flatten_df["charger_identity"] == "2", "AC")
                        .when(flatten_df["charger_identity"] == "3", "DC")
                        .otherwise("None"),
                    )
                    .withColumn(
                        "charging_location",
                        F.when(
                            F.col("gps_valid") == True,
                            F.concat_ws(",", F.col("latitude"), F.col("longitude")),
                        ).otherwise(F.concat_ws(",", F.lit("0.0"), F.lit("0.0"))),
                    )
                    .withColumnRenamed("virtualId", "vid")
                )

                df1.cache()

                # Creating seperate data frames for charging start session and end sessions

                window_first_signal_spec = Window.partitionBy(
                    F.col("vid"), F.col("chargingSessionId")
                ).orderBy(F.col("charger_state_time").desc())

                window_last_signal_spec = Window.partitionBy(
                    F.col("vid"), F.col("chargingSessionId")
                ).orderBy(F.col("charger_state_time"))

                df_charge_start = df1.filter(
                    F.col("charging_session_start").isNotNull()
                )

                df_charge_start = df_charge_start.withColumn(
                    "row_num", F.row_number().over(window_first_signal_spec)
                ).filter(F.col("row_num") == 1)

                df_charge_start = df_charge_start.drop("row_num")

                df_charge_end = df1.filter(
                    F.col("charging_session_end").isNotNull()
                ).withColumn("is_ongoing_session", F.lit(False))

                df_charge_end = df_charge_end.withColumn(
                    "row_num", F.row_number().over(window_last_signal_spec)
                ).filter(F.col("row_num") == 1)

                df_charge_end = df_charge_end.drop("row_num")

                logging.info("Identifying Ongoing Sessions")

                filter_query = {
                    "query": {
                        "bool": {"must": [{"match": {"is_ongoing_session": True}}]}
                    }
                }

                filter_query_json = json.dumps(filter_query)

                target = read_opensearch(
                    glueContext, opensearch_resource, connectionName, filter_query_json
                )

                logging.info("Carrying forward ongoing session from previous batch as first event in current batch")
                
                if target.count() > 0:

                    provisional_end_target = target.filter(F.col("is_ongoing_session"))

                    provisional_end_target = provisional_end_target.select(
                        "vid",
                        "tenantId",
                        F.col("chargingSessionId"),
                        "charging_type",
                        F.col("total_usable_energy_start").alias("total_usable_energy"),
                        F.col("total_usable_energy_bms1_start").alias(
                            "total_usable_energy_bms1"
                        ),
                        F.col("total_usable_energy_bms2_start").alias(
                            "total_usable_energy_bms2"
                        ),
                        F.col("collectionEventTime_start").alias("collectionEventTime"),
                        F.col("soh_percentage_start").alias("soh_percentage"),
                        F.col("bms1_soh_percentage_start").alias("bms1_soh_percentage"),
                        F.col("bms2_soh_percentage_start").alias("bms2_soh_percentage"),
                        F.col("soc_user_percentage_start").alias("soc_user_percentage"),
                        F.col("bms1_soc_user_percentage_start").alias(
                            "bms1_soc_user_percentage"
                        ),
                        F.col("bms2_soc_user_percentage_start").alias(
                            "bms2_soc_user_percentage"
                        ),
                        F.col("charging_location_start").alias("charging_location"),
                        F.col("session_startTimestamp"),
                        F.col("gps_valid_start").alias("gps_valid"),
                        F.col("gps_fix_start").alias("gps_fix"),
                        F.col("hdop_start").alias("hdop"),
                        F.col("vdop_start").alias("vdop"),
                        F.col("pdop_start").alias("pdop"),
                    )

                    for field in df1.schema.fields:
                        col_name = field.name
                        if col_name not in provisional_end_target.columns:
                            provisional_end_target = provisional_end_target.withColumn(
                                col_name,
                                (F.lit(None).cast(field.dataType)),
                            )
                    provisional_end_target = provisional_end_target.select(df1.columns)

                    df_charge_start = df_charge_start.unionByName(
                        provisional_end_target
                    )

                logging.info("Charging sessions that do not have a confirmed end status are treated as 'provisional' and reflected as 'ongoing' within the target system")
                logging.info("Provisional end logic started")

                # finding the sessions which are started and not ended

                df_charge_start_alias = df_charge_start.alias("df_charge_start")
                df_charge_end_alias = df_charge_end.alias("df_charge_end")

                # getting ongoing sessions
                windowspec_next_sess = Window.partitionBy(
                    F.col("df_charge_start.vid"), F.col("df_charge_start.tenantid")
                ).orderBy(F.col("df_charge_start.collectionEventTime"))

                # *************************************DEBUG HERE*************************************
                df_ongoing_sessions = (
                    df_charge_start_alias.join(
                        df_charge_end_alias, on="chargingSessionId", how="left"
                    )
                    .filter(F.col("df_charge_end.chargingSessionId").isNull())
                    .select(
                        F.col("df_charge_start.vid").alias("ongoing_vid"),
                        F.col("df_charge_start.tenantId").alias("ongoing_tenantId"),
                        F.col("df_charge_start.session_startTimestamp").alias(
                            "ongoing_session_startTimestamp"
                        ),
                        F.col("df_charge_start.chargingSessionId").alias(
                            "ongoing_chargingSessionId"
                        ),
                        F.max(F.col("df_charge_start.session_endTimestamp")
                            ).over(windowspec_next_sess).alias("ongoing_session_endTimestamp"),
                    )
                )

                df1_alias = df1.alias("df1")
                df_ongoing_sessions_alias = df_ongoing_sessions.alias(
                    "df_ongoing_sessions"
                )
                
                df_onging_sess_all_data = df1_alias.join(
                    df_ongoing_sessions_alias,
                    (df1.vid == df_ongoing_sessions.ongoing_vid)
                    & (
                        df1.collectionEventTime
                        >= df_ongoing_sessions.ongoing_session_startTimestamp
                    )
                    & (
                        df1.collectionEventTime
                        <= df_ongoing_sessions.ongoing_session_endTimestamp
                    ),
                    "inner",
                ).select(*df1, df_ongoing_sessions.ongoing_chargingSessionId)

                windowspec = Window.partitionBy(
                    "vid", "tenantid", "ongoing_chargingSessionId"
                ).orderBy(F.col("collectionEventTime").desc())

                # getting last signal for ongoing session

                df_ongoing_last_signal = (
                    df_onging_sess_all_data.withColumn(
                        "row_num", F.row_number().over(windowspec)
                    )
                    .filter(F.col("row_num") == 1)
                    .withColumn("is_ongoing_session", F.lit(True))
                    # .withColumn("session_endTimestamp", F.col("collectionEventTime"))
                    .withColumn(
                        "chargingSessionId",
                        F.col("ongoing_chargingSessionId"),
                    )  # Since it is ongoing seesion giving collection event time as endtime
                )

                # making is_ongoing false for previous charging session if new charging session id received
                windowspec_ending_sess = Window.partitionBy(
                    "vid",
                    "tenantid",
                ).orderBy(F.col("collectionEventTime").asc())

                df_ongoing_last_signal = df_ongoing_last_signal.withColumn(
                    "is_ongoing_session",
                    F.when(
                        (
                            F.lead(F.col("chargingSessionId"))
                            .over(windowspec_ending_sess)
                            .isNotNull()
                        ),
                        F.lit(False),
                    ).otherwise(F.lit(True)),
                )

                # logic ended--making is_ongoing false for previous charging session if new charging session id received

                df_ongoing_last_signal = df_ongoing_last_signal.drop(
                    "row_num", "ongoing_chargingSessionId"
                )

                # Provisional end logic end

                # union of  end session records and  last signal of ongoing as end
                df_charge_end = df_charge_end.unionByName(df_ongoing_last_signal)

                logging.info("Provisional end logic has concluded")                

                charge_start_new_cols = [
                    F.col(col).alias(col + "_start") for col in df_charge_start.columns
                ]
                charge_end_new_cols = [
                    F.col(col).alias(col + "_end") for col in df_charge_end.columns
                ]

                df_charge_start = df_charge_start.select(*charge_start_new_cols)
                df_charge_end = df_charge_end.select(*charge_end_new_cols)

                

                logging.info(
                    "Calculating all the metrics by joining the charging start and charging end dataframes"
                )

                

                # merging start and end session data to single dataframe

                df_charge_session_start_end = df_charge_start.join(
                    df_charge_end,
                    (df_charge_start["vid_start"] == df_charge_end["vid_end"])
                    & (
                        df_charge_start["tenantId_start"]
                        == df_charge_end["tenantId_end"]
                    )
                    & (
                        df_charge_start["chargingSessionId_start"]
                        == df_charge_end["chargingSessionId_end"]
                    ),
                    how="inner",
                )

                # calculating metrics based on entire charging session data like avaerge and max values

                df_charge_start_end = df_charge_session_start_end.alias("start_end")
                df_all_data = df1.alias("all_data")

                df_charge_agg = (
                    df_charge_start_end.join(
                        df_all_data,
                        (df_all_data["vid"] == df_charge_start_end["vid_start"])
                        & (
                            df_all_data["collectioneventtime"]
                            >= df_charge_start_end["session_startTimestamp_start"]
                        )
                        & (
                            df_all_data["collectioneventtime"]
                            <= df_charge_start_end["session_endTimestamp_end"]
                        ),
                        "inner",
                    )
                    .select(
                        df_charge_start_end.vid_start,
                        df_charge_start_end.tenantId_start,
                        df_charge_start_end.chargingSessionId_start,
                        df_all_data.battery_pack_temperature,
                        df_all_data.b2bClientId,
                        df_all_data.charger_status,
                        df_all_data.charger_status_time,
                        df_all_data.bms_bdu_connection_request,
                        df_all_data.bms_bdu_connection_request_time,
                        df_all_data.charger_state,
                        df_all_data.charger_state_time,
                        # df_all_data.bms1_battery_pack_temperature,
                        # df_all_data.bms2_battery_pack_temperature,
                    )
                    .groupBy("vid_start", "chargingSessionId_start")
                    .agg(
                        F.count("battery_pack_temperature").alias("signal_samples"),
                        F.avg("battery_pack_temperature").alias(
                            "avg_battery_pack_temperature"
                        ),
                        F.max("battery_pack_temperature").alias(
                            "max_battery_pack_temperature"
                        ),
                        F.min("battery_pack_temperature").alias(
                            "min_battery_pack_temperature"
                        ),
                        F.min(
                            F.when(
                                F.col("bms_bdu_connection_request") == 2,
                                F.col("bms_bdu_connection_request_time"),
                            )
                        ).alias("charger_plugin_time"),
                        F.min(
                            F.when(
                                F.col("bms_bdu_connection_request") != 2,
                                F.col("bms_bdu_connection_request_time"),
                            )
                        ).alias("charger_unplug_time"),
                        F.min(
                            F.when(
                                F.col("charger_state").isin(
                                    [14, 13, 12, 11, 10, 9, 8, 7]
                                ),
                                F.col("charger_state_time"),
                            )
                        ).alias("error_state_time"),
                        F.min(
                            F.when(
                                F.col("charger_state") == 5,
                                F.col("charger_state_time"),
                            )
                        ).alias("user_or_system_stop_time"),
                        F.min(
                            F.when(
                                F.col("charger_state") == 2,
                                F.col("charger_state_time"),
                            )
                        ).alias("charging_start_time"),
                    )
                )

                df_charge_agg = df_charge_agg.alias("src_agg")
                target = target.alias("tgt")

                df_charge_session = (
                    df_charge_start_end.join(
                        df_charge_agg, on="chargingSessionId_start", how="inner"
                    )
                    .join(
                        target,
                        df_charge_agg["chargingSessionId_start"]
                        == target["chargingSessionId"],
                        "left",
                    )
                    .select(
                        F.col("start_end.vid_start").alias("vid"),
                        F.col("start_end.tenantId_start").alias("tenantId"),
                        F.col("start_end.chargingSessionId_start").alias(
                            "chargingSessionId"
                        ),
                        F.col("start_end.b2bClientId_start").alias("b2bclientid"),
                        F.col("start_end.charging_type_start").alias("charging_type"),
                        F.col("start_end.collectionEventTime_start"),
                        F.col("start_end.collectionEventTime_end"),
                        F.col("start_end.total_usable_energy_start"),
                        F.col("start_end.total_usable_energy_end"),
                        (
                            F.coalesce(
                                F.col("start_end.total_usable_energy_end"), F.lit(0)
                            )
                            - F.coalesce(
                                F.col("start_end.total_usable_energy_start"), F.lit(0)
                            )
                        ).alias("wh_consumed"),
                        F.col("start_end.total_usable_energy_bms1_start"),
                        F.col("start_end.total_usable_energy_bms1_end"),
                        F.col("start_end.total_usable_energy_bms2_start"),
                        F.col("start_end.total_usable_energy_bms2_end"),
                        F.col("start_end.soh_percentage_start"),
                        F.col("start_end.soh_percentage_end"),
                        F.col("start_end.bms1_soh_percentage_start"),
                        F.col("start_end.bms1_soh_percentage_end"),
                        F.col("start_end.bms2_soh_percentage_start"),
                        F.col("start_end.bms2_soh_percentage_end"),
                        F.col("start_end.soc_user_percentage_start"),
                        F.col("start_end.soc_user_percentage_end"),
                        F.col("start_end.bms1_soc_user_percentage_start"),
                        F.col("start_end.bms1_soc_user_percentage_end"),
                        F.col("start_end.bms2_soc_user_percentage_start"),
                        F.col("start_end.bms2_soc_user_percentage_end"),
                        F.col("start_end.session_startTimestamp_start").alias(
                            "session_startTimestamp"
                        ),
                        F.col("start_end.session_endTimestamp_end").alias(
                            "session_endTimestamp"
                        ),
                        F.from_unixtime(
                            (
                                F.col("start_end.session_startTimestamp_start") / 1000
                            ).cast(DoubleType()),
                            "yyyy-MM-dd'T'HH:mm:ss.SSS",
                        ).alias("session_startTimestamp_ts"),
                        F.from_unixtime(
                            (F.col("start_end.session_endTimestamp_end") / 1000).cast(
                                DoubleType()
                            ),
                            "yyyy-MM-dd'T'HH:mm:ss.SSS",
                        ).alias("session_endTimestamp_ts"),
                        F.col("start_end.charging_location_start"),
                        F.col("start_end.charging_location_end"),
                        F.col("start_end.gps_valid_start"),
                        F.col("start_end.gps_valid_end"),
                        F.col("start_end.gps_fix_start"),
                        F.col("start_end.gps_fix_end"),
                        F.col("start_end.hdop_start"),
                        F.col("start_end.hdop_end"),
                        F.col("start_end.vdop_start"),
                        F.col("start_end.vdop_end"),
                        F.col("start_end.pdop_start"),
                        F.col("start_end.pdop_end"),
                        F.col("start_end.is_ongoing_session_end").alias(
                            "is_ongoing_session"
                        ),
                        F.concat_ws(
                            "-",
                            F.col("start_end.vid_start"),
                            F.col("start_end.chargingSessionId_start"),
                        ).alias("doc_id"),
                        (
                            F.col("src_agg.signal_samples")
                            + F.coalesce(F.col("tgt.signal_samples"), F.lit(0))
                        ).alias("signal_samples"),
                        F.when(
                            F.col("tgt.chargingSessionId").isNotNull(),
                            (
                                (
                                    (
                                        F.col("src_agg.avg_battery_pack_temperature")
                                        * F.col("src_agg.signal_samples")
                                    )
                                    + (
                                        F.col("tgt.avg_battery_pack_temperature")
                                        * F.col("tgt.signal_samples")
                                    )
                                )
                                / (
                                    F.col("src_agg.signal_samples")
                                    + F.col("tgt.signal_samples")
                                )
                            ),
                        )
                        .otherwise(F.col("src_agg.avg_battery_pack_temperature"))
                        .alias("avg_battery_pack_temperature"),
                        F.greatest(
                            F.col("src_agg.max_battery_pack_temperature"),
                            F.col("tgt.max_battery_pack_temperature"),
                        ).alias("max_battery_pack_temperature"),
                        F.least(
                            F.col("src_agg.min_battery_pack_temperature"),
                            F.col("tgt.min_battery_pack_temperature"),
                        ).alias("min_battery_pack_temperature"),
                        F.least(
                            F.col("src_agg.charger_plugin_time"),
                            F.col("tgt.charger_plugin_time"),
                        ).alias("charger_plugin_time"),
                        F.least(
                            F.col("src_agg.charger_unplug_time"),
                            F.col("tgt.charger_unplug_time"),
                        ).alias("charger_unplug_time"),
                        F.least(
                            F.col("src_agg.error_state_time"),
                            F.col("tgt.error_state_time"),
                        ).alias("error_state_time"),
                        F.least(
                            F.col("src_agg.user_or_system_stop_time"),
                            F.col("tgt.user_or_system_stop_time"),
                        ).alias("user_or_system_stop_time"),
                        F.least(
                            F.col("src_agg.charging_start_time"),
                            F.col("tgt.charging_start_time"),
                        ).alias("charging_start_time"),
                    )
                )

                for column in df_charge_session.columns:
                    column_type = dict(df_charge_session.dtypes)[column]

                    if column_type == "string":  # Check if the column type is string
                        df_charge_session = df_charge_session.withColumn(
                            column,
                            F.when(F.col(column).isNull(), "null").otherwise(
                                F.col(column)
                            ),
                        )
                    elif column_type in ["bigint", "int", "long"]:  # For integer types
                        df_charge_session = df_charge_session.withColumn(
                            column,
                            F.when(F.col(column).isNull(), 0).otherwise(F.col(column)),
                        )
                    elif column_type in ["float", "double"]:  # For float types
                        df_charge_session = df_charge_session.withColumn(
                            column,
                            F.when(F.col(column).isNull(), 0.0).otherwise(
                                F.col(column)
                            ),
                        )
                    elif column_type == "boolean":  # For boolean types
                        df_charge_session = df_charge_session.withColumn(
                            column,
                            F.when(F.col(column).isNull(), False).otherwise(
                                F.col(column)
                            ),
                        )
                    else:
                        # Handle any other types if necessary
                        logging.info(
                            "Unsupported type for column %s: %s", column, column_type
                        )

                df_charge_session.cache()

                dynamic_frame = DynamicFrame.fromDF(
                    df_charge_session, glueContext, "dynamic_frame"
                )

                write_opensearch(
                    glueContext, dynamic_frame, opensearch_resource, connectionName
                )

                target_path = (
                    "s3://"
                    + target_bucket_name
                    + "/"
                    + folder_prefix
                    + "_"
                    + use_case_name
                    + "/"
                )

                partition_extract_col_ts = partition_extract_col + "_part"
                df_charge_session = (
                    df_charge_session.withColumn(
                        partition_extract_col_ts,
                        F.col(partition_extract_col).cast(TimestampType()),
                    )
                    .withColumn("year", F.year(F.col(partition_extract_col_ts)))
                    .withColumn("month", F.month(F.col(partition_extract_col_ts)))
                    .withColumn("day", F.dayofmonth(F.col(partition_extract_col_ts)))
                    .withColumn("hour", F.hour(F.col(partition_extract_col_ts)))
                    .withColumn("use_case_name", F.lit(use_case_name))
                ).drop(partition_extract_col_ts)

                write_s3(
                    df_charge_session,
                    target_table_name,
                    target_path,
                    recordkey,
                    precombine_field,
                    partition_field,
                    target_database,
                    write_operation,
                )

                logging.info("Calling log audit to log the status as job Completed")
                records_processed = df_charge_session.count()
                logging.info("Records processed:%s", records_processed)
                end_time = datetime.now()

                log_audit(
                    spark,
                    args["JOB_NAME"],
                    source_kafka_topic,
                    source_type,
                    opensearch_resource,
                    target_type,
                    "Completed",
                    start_time,
                    end_time,
                    records_processed,
                    audit_path,
                    audit_table,
                )
            
            except Exception as e:
                logging.error("Error happened while processing batch data: %s", e)
                logging.error(traceback.format_exc())
                raise
        check_point_path = (
            "s3://" + target_bucket_name + "/checkpoint/" + use_case_name + "/"
        )
        filtered_df.writeStream.foreachBatch(process_batch).trigger(once=True).option(
            "checkpointLocation", check_point_path
        ).outputMode("append").start().awaitTermination()

        logging.info("job completed sucessfully")

    except Exception as e:
        logging.error("An error occurred in main method : %s", str(e))
        logging.error(traceback.format_exc())

        end_time = datetime.now()
        duration = (end_time - start_time).seconds

        cloudwatch_url = get_cloudwatch_url(region_name, job_name, job_run_id)
        ERROR_CODE = getattr(
            e, "code", "N/A"
        )  # Some exceptions might have a 'code' attribute
        if ERROR_CODE == "N/A":
            # Try to parse error code from the exception message if it's in a known format
            ERROR_CODE = "Specific logic to parse error code from the exception message if possible"

        log = {
            "status": "failure",
            "job_name": job_name,
            "source_table": source_kafka_topic,
            "target_table": opensearch_resource,
            "start_time": start_time.isoformat(),
            "end_time": end_time.isoformat(),
            "duration": duration,
            "error_code": ERROR_CODE,
            "error": f"Error: {str(e)}\nTraceback: {traceback.format_exc()}",
        }

        logging.info("Calling log audit to log the status as job Failed")

        log_audit(
            spark,
            args["JOB_NAME"],
            source_kafka_topic,
            source_type,
            opensearch_resource,
            target_type,
            "Failed",
            start_time,
            end_time,
            None,
            audit_path,
            audit_table,
        )

        log_message = "\n".join([f"{key}: {value}" for key, value in log.items()])

        message = f"Job {job_name} failed. Error: {str(e)}\nTraceback: {traceback.format_exc()}\
              \n\n{log_message}.\n\nView the logs in CloudWatch:{cloudwatch_url}"

        sns_message_size = len(message.encode("utf-8"))
        logging.info("message body size in KB:%s", sns_message_size / 1024)
        if sns_message_size >= 256 * 1024:
            logging.info("messages size is greater than 256KB so truncating it")
            message = message[
                :250000
            ]  # 250 KB to ensure we stay within the 256 KB limit

        subject = f"{job_name} failed for {opensearch_resource} table"
        if len(subject) > 100:
            subject = subject[:98] + ".."  # Truncate if needed

        # send_sns_notification(subject, message, sns_secret_name, region_name)

        raise

if __name__ == "__main__":
    main()

