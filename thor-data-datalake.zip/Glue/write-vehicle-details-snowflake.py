   
# pylint: disable=import-error, invalid-name, too-many-locals, too-many-statements, broad-except
import sys
import logging
from datetime import datetime,timedelta
import boto3
import json
import traceback
import snowflake.connector
from awsglue.utils import getResolvedOptions
from pyspark.sql import functions as F
from pyspark.sql.functions import col
from hmcl_cv_common_utilities import (
    log_audit,
    load_yaml_config,
    validate_audit_table_with_s3_partition,
    send_sns_notification,
    get_watermark_timestamp,
    get_cloudwatch_url,
    update_watermark_file,
    initialize_spark_session
    )


logging.basicConfig(
    level=logging.INFO, format="%(asctime)s - %(name)s - %(levelname)s - %(message)s"
)


def read_job_param():
    try:
    
        # Define arguments
        arguments = [
            "JOB_NAME",
            "yaml_s3_bucket",
            "yaml_file_key",
            "source_table_name",
            "audit_database"
        ]
        # Get the arguments
        args = getResolvedOptions(sys.argv, arguments)
        job_name = args.get("JOB_NAME")
        job_run_id = args.get("JOB_RUN_ID")
        yaml_s3_bucket = args.get("yaml_s3_bucket")
        yaml_file_key = args.get("yaml_file_key")
        source_table_name = args.get("source_table_name")
        audit_database = args.get("audit_database")
        logging.info("Job parameters read successfully")
        return yaml_s3_bucket,yaml_file_key,job_name,job_run_id,source_table_name,audit_database
        
    except Exception as e:
        logging.error(f"Error while reading job parameters: {str(e)}")
        raise

def fetch_snowflake_credentials(secret_name):
    try:
        client = boto3.client('secretsmanager')
        response = client.get_secret_value(SecretId=secret_name)
        secret = json.loads(response['SecretString'])
        return secret
    except Exception as e:
        logging.error(f"Error while fetching snowflake credentials: {str(e)}")
        traceback.print_exc()
        raise

def get_snowflake_connection(sfUser,sfPassword,sfURL):
    """
    Establish and return a Snowflake connection.
    """
    try:
        conn = snowflake.connector.connect(
        user=sfUser,
        password=sfPassword,
        account = sfURL.split('//')[1].split('.snowflakecomputing.com')[0]
    )
        logging.info("Snowflake connection established.")
        return conn
    except Exception as e:
        logging.error(f"Error establishing Snowflake connection: {str(e)}")
        traceback.print_exc()
        raise
    
def read_yaml_file(s3_client,yaml_s3_bucket,yaml_file_key,source_table_name):
    try:
        # Read YAML file from S3
        yaml_dict = load_yaml_config(s3_client,yaml_s3_bucket,yaml_file_key)
        target_table_name = yaml_dict[source_table_name]['target_table_name']
        sns_secret_name = yaml_dict[source_table_name]['sns_secret_name']
        watermark_bucket = yaml_dict[source_table_name]['watermark_bucket']
        watermark_file_key = yaml_dict[source_table_name]['watermark_file_key']
        audit_path = yaml_dict[source_table_name]['audit_path']
        audit_table = yaml_dict[source_table_name]['audit_table']
        region_name = yaml_dict[source_table_name]['region']
        log_path = yaml_dict[source_table_name]['log_path']
        source_type = yaml_dict[source_table_name]['source_type']
        target_type = yaml_dict[source_table_name]['target_type']
        device_ledger_path = yaml_dict[source_table_name]['device_ledger_path']
        tcu_path = yaml_dict[source_table_name]['tcu_path']
        primary_key_column = yaml_dict[source_table_name]['primary_key_column']
        snowflake_secret_name = yaml_dict[source_table_name]['snowflake_secret_name']
        stage_table = yaml_dict[source_table_name]['stage_table']

        logging.info("yaml parameters read successfully")
        return target_table_name,sns_secret_name,watermark_bucket,watermark_file_key,audit_path,audit_table,region_name,log_path,source_type,target_type,device_ledger_path,tcu_path,primary_key_column,snowflake_secret_name,stage_table
    except Exception as e:
        logging.error(f"Error while reading yaml parameters: {str(e)}")
        raise

def read_and_exclude(spark, path, watermark_timestamp, exclude_columns):
    """
    Read a Hudi table incrementally and exclude specific columns.
    
    :param spark: SparkSession
    :param path: Source path of the Hudi table
    :param watermark_timestamp: Incremental read timestamp
    :param exclude_columns: List of columns to exclude
    :return: Filtered DataFrame or None if table is empty
    """
    try:
        logging.info(f"Reading Hudi table from path: {path} with watermark: {watermark_timestamp}")
        
        source_df = spark.read.format("hudi") \
            .option("hoodie.datasource.query.type", "incremental") \
            .option("hoodie.datasource.read.begin.instanttime", watermark_timestamp) \
            .load(path)

        if source_df.head(1) is None:  # Handle empty table
            logging.warning(f"No data found in Hudi table at path: {path}")
            return None

        remaining_columns = [col for col in source_df.columns if col not in exclude_columns]
        return source_df.select(*remaining_columns)

    except FileNotFoundError:
        logging.error(f"The specified path does not exist: {path}")
        raise

    except Exception as e:
        logging.error(f"Error reading device_ledger incrementally: {str(e)}")
        traceback.print_exc()
        raise

# def read_and_exclude(spark, path, watermark_timestamp, exclude_columns):
#     """
#     Read a Hudi table incrementally and exclude specific columns.
    
#     :param spark: SparkSession
#     :param path: Source path of the Hudi table
#     :param watermark_timestamp: Incremental read timestamp
#     :param exclude_columns: List of columns to exclude
#     :return: Filtered DataFrame
#     """
#     try :
#         source_df = spark.read.format("hudi") \
#             .option("hoodie.datasource.query.type", "incremental")\
#             .option("hoodie.datasource.read.begin.instanttime", watermark_timestamp) \
#             .load(path)
        
#         remaining_columns = [col for col in source_df.columns if col not in exclude_columns]
#         return source_df.select(*remaining_columns)
#     except Exception as e:
#         logging.error(f"Error reading device_ledger incrementally: {str(e)}")
#         traceback.print_exc()
#         raise

# Example usage

def extract_distinct_tcu_ids(device_ledger):
    """
    Extracts distinct tcu_id values from the device_ledger DataFrame.
    """
    try:
        tcu_ids = device_ledger.select("tcu_id").distinct()
        logging.info(f"Extracted {tcu_ids.count()} distinct tcu_id values.")
        return tcu_ids
    except Exception as e:
        logging.error(f"Error extracting tcu_id values: {str(e)}")
        traceback.print_exc()
        raise

def read_filtered_tcu_data(spark, tcu_path, tcu_ids, exclude_columns):
    """
    Reads the tcu table and filters it based on the tcu_ids, then normalizes the column names.
    """
    try:
        if tcu_ids.count() == 0:
            logging.info("No tcu_id values found in device_ledger. Skipping tcu table read.")
            return None
        
        # Step 1: Extract tcu_id values from tcu_ids DataFrame into a list
        tcu_ids_list = [row['tcu_id'] for row in tcu_ids.collect()]  # Collecting tcu_ids into a list
        
        # Step 2: Read and filter the tcu table at read time based on tcu_ids
        tcu = spark.read.format("hudi").load(tcu_path) \
            .filter(col("TCU_ID").isin(tcu_ids_list))  # Filter based on the list of tcu_ids
        
        logging.info(f"Read {tcu.count()} rows from tcu table for matching tcu_id values.")

        # Step 3: Normalize column names (renaming conflicting columns)
        duplicate_columns = set(tcu.columns).intersection(set(exclude_columns))  # List of overlapping columns
        
        # Rename conflicting columns by appending a suffix to differentiate them
        for col_name in duplicate_columns:
            tcu = tcu.withColumnRenamed(col_name, f"{col_name}_tcu")

        # Step 4: Remove excluded columns from the tcu DataFrame
        remaining_columns = [col for col in tcu.columns if col not in exclude_columns]
        tcu = tcu.select(*remaining_columns)

        return tcu
        
    except Exception as e:
        logging.error(f"Error reading filtered tcu data: {str(e)}")
        traceback.print_exc()
        raise
    
def add_buffer_to_hudi_commit_time(hudi_timestamp,num_of_hours):
    
    try:
        # Parse the timestamp to a datetime object
        parsed_time = datetime.strptime(hudi_timestamp[:-3], "%Y%m%d%H%M%S")
        # Subtract one hour
        time_one_hour_back = parsed_time - timedelta(hours=num_of_hours)
        # Format it back to the Hudi timestamp format
        new_hudi_timestamp = time_one_hour_back.strftime("%Y%m%d%H%M%S") + hudi_timestamp[-3:]
        return new_hudi_timestamp
    
    except Exception as e:
        logging.error(f"Error while adding buffer to hudi commit time :{str(e)}")
        raise

def get_max_commit_time(source_df,hoodie_commit_time_col):
    max_commit_time= source_df.agg(F.max(hoodie_commit_time_col)).collect()[0][0]
    return max_commit_time
def update_watermark_with_latesttime(s3,raw_watermark_bucket,raw_watermark_file_key,source_table_name,max_commit_time):
    
    try:
        # Update the watermark for the specific table
        new_hudi_timestamp = add_buffer_to_hudi_commit_time(max_commit_time,1)
        update_watermark_file(s3,new_hudi_timestamp,raw_watermark_bucket,raw_watermark_file_key,source_table_name)
        return True
    except Exception as e:
        logging.error(f"Error while updating the watermark file:{str(e)}")
        raise

def check_table_exists(spark,conn, target_table_name, job_name, sns_secret_name, region_name, start_time, audit_path, audit_table,source_table_name,source_type,target_type):
    # Extract the table name (assumes target_table is in format 'database.schema.table')
    table_name = target_table_name.split('.')[2]
    
    # Create the query to check if the table exists
    check_table_query = f"SHOW TABLES LIKE '{table_name}'"
    
    # Execute the query to check if the table exists
    cursor = conn.cursor()
    cursor.execute(check_table_query)
    table_exists = cursor.fetchone()
    
    if not table_exists:
        # Log the error and notify via SNS
        logging.error(f"Target table {target_table_name} does not exist. Aborting job.")
        end_time = datetime.now()
        # Log the audit information
        log_audit(spark, job_name, source_table_name, source_type, target_table_name, target_type, "Aborted", start_time, end_time, None, audit_path, audit_table)
        
        # Send SNS notification about the failure
        subject = f"{job_name} failed - Missing Target Table"
        if len(subject)>100:
            subject = subject[:97] + '..'
        send_sns_notification("job failed", f"The target table {target_table_name} does not exist.", sns_secret_name, region_name)
        
        # Optional: Raise an exception or return early to stop the job
        raise Exception(f"Target table {target_table_name} does not exist. Job aborted.")
    
def fetch_schemas(source_df):
    """
    Fetches schemas of source dataframe.
    """
    source_columns = set([col_schema.name for col_schema in source_df.schema])
    return source_columns

def compare_schemas(source_columns, target_table_columns):
    """
    Compares the schemas and identifies missing and new columns,
    while ignoring specified columns for the new column comparison.
    """
    # List of columns to exclude when computing new columns
    excluded_columns = {
        "TCU_METADATA_PART_NUMBER", "HOUR_TCU", "VEHICLEPROPERTIES_VEHICLETYPE", "TCU_METADATA_BLE_PIN", 
        "TOPIC_TCU", "TENANT_ID", "TCU_ID_tcu", "_HOODIE_PARTITION_PATH_TCU", "_HOODIE_FILE_NAME_TCU", 
        "KEY_TCU", "YEAR_TCU", "TCU_METADATA_BLE_PROTOCOL_VERSION", "TCU_METADATA_TCU_HW_VERSION", 
        "VEHICLEPROPERTIES_MAKE", "VEHICLESTATUS", "KAFKA_TIMESTAMP_TCU", "OFFSET_TCU", "PARTITION_TCU", 
        "TCU_METADATA_SSID_PASSWORD", "VEHICLEPROPERTIES_YEAR", "TCU_METADATA_SSID", "_HOODIE_COMMIT_TIME_LAND_CAL_TCU", 
        "TIMESTAMP", "CREATEDTSP", "VEHICLEPROPERTIES_BATTERYCAPACITY", "OPERATION_tcu", 
        "VEHICLEPROPERTIES_COLOR", "TENANT_ID_tcu", "DAY_TCU", "VEHICLEPROPERTIES_FUELTYPE", 
        "TIMESTAMP_TS", "TCU_METADATA_MANUFACTURER_LOCATION", "TCU_METADATA_MANUFACTURER", 
        "_HOODIE_COMMIT_SEQNO_TCU", "_HOODIE_RECORD_KEY_TCU", "TCU_METADATA_TCU_SW_VERSION", 
        "CREATEDTSP_TS", "MONTH_TCU", "VEHICLEPROPERTIES_ELECTRICRANGE", "IMEI_tcu", 
        "VEHICLEPROPERTIES_BLE_PIN", "VEHICLEPROPERTIES_VDS"
    }

    # Filter source columns to exclude the specified columns
    filtered_source_columns = source_columns - excluded_columns

    # Compute missing and new columns
    missing_columns = list(target_table_columns - source_columns)
    new_columns = list(filtered_source_columns - target_table_columns)

    return missing_columns, new_columns


def handle_schema_mismatch(spark, job_name, source_table_name, target_table_name, start_time, audit_path, audit_table, sns_secret_name, missing_columns,region_name):
    """
    Handles schema mismatches by logging and raising a notification.
    """
    schema_status = "Aborted"
    error_message = f"Missing columns in source table: {', '.join(missing_columns)}"
    logging.error(error_message)
    
    # Log the error
    end_time = datetime.now()
    log_audit(spark, job_name, source_table_name, "source_type", target_table_name, "target_type", schema_status, start_time, end_time, None, audit_path, audit_table)
    
    # Send SNS notification
    subject = f"Job {job_name} - Aborted for table {source_table_name} - Schema Validation Failed"
    send_sns_notification(subject[:98] + '..' if len(subject) > 100 else subject, error_message, sns_secret_name,region_name)
    raise ValueError(error_message)

def handle_new_columns(sns_secret_name, job_name, source_table_name, new_columns,region_name):
    """
    Handles the detection of new columns by sending a notification.
    """
    schema_status = "New columns detected"
    new_columns_message = f"New columns detected in source table: {', '.join(new_columns)}"
    logging.warning(new_columns_message)
    
    # Send SNS notification
    subject = f"Job - {job_name} Succeeded for table {source_table_name}- with new Schema "
    send_sns_notification(subject[:98] + '..' if len(subject) > 100 else subject, new_columns_message, sns_secret_name,region_name) 
    return schema_status 

def get_evaluated_schema(spark,conn,source_df, target_table_name, sns_secret_name, source_table_name, start_time, job_name, audit_path, audit_table,region_name):
    """
    Adjust schema based on target table schema and send notifications if there are discrepancies.
    """
    try:
        schema_status = "Success"
        
        # Fetch schema from PostgreSQL and validate
        source_columns = fetch_schemas(source_df)
        

        target_table_columns = get_table_schema(conn, target_table_name, exclude_columns='ID')
        
        # Compare schemas and detect missing/new columns
        missing_columns, new_columns =compare_schemas(source_columns, target_table_columns)
        
        if missing_columns:
            handle_schema_mismatch(spark, job_name, source_table_name, target_table_name, start_time, audit_path, audit_table, sns_secret_name, missing_columns,region_name)
        elif new_columns:
            handle_new_columns(sns_secret_name, job_name, source_table_name, new_columns,region_name)
        return schema_status,target_table_columns

    except Exception as e:
        logging.error("An error occurred while fetching schema from source table: %s", str(e))
        logging.error("Traceback: %s", traceback.format_exc())
        raise

def standardize_columns(device_ledger, tcu):
    """
    Handles duplicate column names by renaming columns in the tcu DataFrame.
    """
    try:
        duplicate_columns = set(device_ledger.columns).intersection(set(tcu.columns)) - {"tcu_id"}
        for col_name in duplicate_columns:
            tcu = tcu.withColumnRenamed(col_name, f"{col_name}_tcu")
        return tcu
    except Exception as e:
        logging.error(f"Error normalizing column names: {str(e)}")
        traceback.print_exc()
        raise

def normalize_column_names(df):
            return df.toDF(*[col_name.upper() for col_name in df.columns])
        
def join_device_ledger_with_tcu(device_ledger, tcu):
    """
    Joins device_ledger with tcu on tcu_id.
    """
    try:
        vehicle_details = device_ledger.join(tcu, device_ledger["tcu_id"]==tcu["TCU_ID_tcu"], "inner")
        num_records = vehicle_details.count()
        logging.info(f"Joined device_ledger with tcu. Final row count: {num_records}")
        return vehicle_details,num_records
    except Exception as e:
        logging.error(f"Error joining device_ledger with tcu: {str(e)}")
        traceback.print_exc()
        raise

def get_table_schema(conn, table_name, exclude_columns=None):
    """
    Retrieve the schema of the specified table as a list of column names.
    Optionally exclude specific columns from the schema.
    
    :param conn: Snowflake connection object
    :param table_name: Name of the table
    :param exclude_columns: List of column names to exclude (case-sensitive)
    :return: List of column names in the schema (excluding specified columns)
    """
    exclude_columns = exclude_columns or []
    schema_query = f"DESCRIBE TABLE {table_name}"
    schema_result = conn.cursor().execute(schema_query)
    schema_columns = [row[0] for row in schema_result]  # Assuming the first column in result is the column name
    # Exclude specified columns
    schema_columns = set([col for col in schema_columns if col not in exclude_columns])
    return schema_columns

def get_snowflake_options(secret_dict):
    """
    Create a dictionary of Snowflake options for Spark DataFrame writes.
    """
    return {
        "sfURL": secret_dict['url'],
        "sfDatabase": secret_dict['database'],
        "sfSchema": secret_dict['schema'],
        "sfWarehouse": secret_dict['warehouse'],
        "sfRole": secret_dict['role'],
        "sfUser": secret_dict['username'],
        "sfPassword": secret_dict['password']
    }

def write_to_snowflake(df, table_name, snowflake_secret_name):
    """
    Write the Spark DataFrame to a Snowflake table.

    Args:
        df (pyspark.sql.DataFrame): The Spark DataFrame to be written.
        table_name (str): The target Snowflake table name.
        snowflake_secret_name (str): The name of the secret containing Snowflake credentials.
    """
    try:
        # Fetch Snowflake credentials
        secret_dict = fetch_snowflake_credentials(snowflake_secret_name)
        logging.info("Snowflake credentials loaded successfully.")

        # Prepare Snowflake options
        options = get_snowflake_options(secret_dict)

        # Write DataFrame to Snowflake
        logging.info(f"Starting data write to Snowflake table: {table_name}")
        df.write \
            .format("snowflake") \
            .options(**options) \
            .option("dbtable", table_name) \
            .mode("overwrite") \
            .save()
        logging.info(f"Data written successfully to Snowflake table: {table_name}")
    except Exception as e:
        logging.error(f"Failed to write to Snowflake: {str(e)}")
        raise

def execute_merge_query(conn,query):
    """Execute the Snowflake MERGE query."""
    
    try:
        cursor = conn.cursor()
        cursor.execute(query)
    finally:
        cursor.close()
        conn.close()

def merge_source_to_target(conn, vehicle_details, stage_table, target_table_name, snowflake_secret_name, primary_key_column):
    """
    Merge the source data from the specified stage table into the Snowflake target table.

    Parameters:
    - conn: Snowflake connection object.
    - vehicle_details: DataFrame containing vehicle details.
    - stage_table (str): Name of the Snowflake staging table.
    - target_table_name (str): Name of the Snowflake target table.
    - snowflake_secret_name (str): Secret name for Snowflake credentials.
    - primary_key_column (str): The primary key column used for the merge.
    """

    # Step 3: Write Data to Snowflake Staging Table
    write_to_snowflake(vehicle_details, stage_table, snowflake_secret_name)

    # Step 4: Construct the Merge Query
    merge_query = f"""
    MERGE INTO {target_table_name} AS target
    USING (
        SELECT DISTINCT
            "VIRTUAL_ID", "VIN", "TCU_ID", "IMEI", "TCU_METADATA_ICCID", "TCU_METADATA_MAC", "VEHICLEPROPERTIES_MODEL"
        FROM {stage_table}
    ) AS source
    ON target."{primary_key_column}" = source."{primary_key_column}"
    WHEN MATCHED THEN UPDATE SET
        target."VIRTUAL_ID" = source."VIRTUAL_ID",
        target."VIN" = source."VIN",
        target."TCU_ID" = source."TCU_ID",
        target."IMEI" = source."IMEI",
        target."TCU_METADATA_ICCID" = source."TCU_METADATA_ICCID",
        target."TCU_METADATA_MAC" = source."TCU_METADATA_MAC",
        target."VEHICLEPROPERTIES_MODEL" = source."VEHICLEPROPERTIES_MODEL"
    WHEN NOT MATCHED THEN INSERT (
        "VIRTUAL_ID", "VIN", "TCU_ID", "IMEI", "TCU_METADATA_ICCID", "TCU_METADATA_MAC", "VEHICLEPROPERTIES_MODEL"
    ) VALUES (
        source."VIRTUAL_ID", source."VIN", source."TCU_ID", source."IMEI", source."TCU_METADATA_ICCID", source."TCU_METADATA_MAC", source."VEHICLEPROPERTIES_MODEL"
    );
    """

    # Step 5: Execute the Merge Query
    execute_merge_query(conn, merge_query)

def main():
    
    try:
        start_time = datetime.now()
        logging.info(f"Job started at {start_time}")
        
        #read job parameters
        yaml_s3_bucket,yaml_file_key,job_name,job_run_id,source_table_name,audit_database = read_job_param()
        
        logging.info(f"job name : {job_name}")
        logging.info(f"source table name : {source_table_name}.{audit_database}.{yaml_file_key}")
        
        logging.info("job_name=%s", job_name+"/"+source_table_name)
        #initialize spark job
        spark = initialize_spark_session()
        
        #create an S3 client
        s3 = boto3.client('s3')

        # read necessary  parameters from yaml file

        target_table_name,sns_secret_name,watermark_bucket,watermark_file_key,audit_path,audit_table,\
        region_name,log_path,source_type,target_type,\
        device_ledger_path,tcu_path,primary_key_column,snowflake_secret_name,stage_table = read_yaml_file(s3,yaml_s3_bucket,yaml_file_key,source_table_name)
    except Exception as e:
        logging.error(f"Error in initial steps: {str(e)}")
        traceback.print_exc()
        raise

    try:
        year_partitioned=start_time.year
        month_partitioned=start_time.month
        #validate audit table
        validate_audit_table_with_s3_partition(spark,sns_secret_name,start_time,audit_path,audit_path,source_table_name,target_table_name,job_name,region_name,year_partitioned,month_partitioned )

        # validate_audit_table(spark, audit_database, audit_table, source_table_name,target_table_name,job_name,sns_secret_name,start_time,audit_path,source_type,target_type,region_name)
        # Log audit
        log_audit(
                    spark,job_name,source_table_name,source_type,target_table_name,target_type,\
                    "Started",start_time,None,None,audit_path,audit_table,
                )
        #read watermark timestamp
        watermark_timestamp = get_watermark_timestamp(s3,watermark_bucket,watermark_file_key)
        
        exclude_columns = ['_hoodie_record_key', '_hoodie_commit_seqno','_hoodie_file_name', '_hoodie_partition_path', 
        '_hoodie_commit_time_land_cal','kafka_timestamp','key','partition','offset','_hoodie_commit_time_land_cal','topic', 'year', 'month', 'day', 'hour']
        # read data from landing table incrementally

        device_ledger = read_and_exclude(spark, device_ledger_path, watermark_timestamp, exclude_columns)
        logging.info(f"Read {device_ledger.count()} rows from device_ledger incrementally.")
            
        
        # Step 2: Extract distinct tcu_id values
        tcu_ids = extract_distinct_tcu_ids(device_ledger)
        
        # Step 3: Read filtered tcu data
        tcu = read_filtered_tcu_data(spark, tcu_path, tcu_ids,exclude_columns)
        logging.info(f"tcu schema is : {tcu.schema}")
        if tcu is None:
            return device_ledger

        # Normalize column names in both DataFrames
        device_ledger = normalize_column_names(device_ledger)
        tcu = normalize_column_names(tcu)
        
        # Step 4: standardize column names to handle duplicates
        tcu = standardize_columns(device_ledger, tcu)
        # tcu  = read_and_exclude(spark, tcu_path, watermark_timestamp, exclude_columns)
        # source_df,num_records = read_source_table(spark,watermark_timestamp,source_hudi_table_path)
        
        # Step 5: Join device_ledger with tcu
        vehicle_details,num_records = join_device_ledger_with_tcu(device_ledger, tcu)

        
        # duplicate_columns = set(device_ledger.columns).intersection(set(tcu.columns))

        # # Rename duplicates in one DataFrame
        # for col_name in duplicate_columns:
        #     tcu = tcu.withColumnRenamed(col_name, f"{col_name}_tcu")
        # vehicle_details = device_ledger.join(tcu, device_ledger['tcu_id']==tcu['tcu_id_tcu'], how='inner')
        # num_records=vehicle_details.count()
        # logging.info(f"num records loading: {num_records}")

        max_commit_time=get_max_commit_time(device_ledger,'_HOODIE_COMMIT_TIME')
        
        logging.info(f"max_commit_time : {max_commit_time}")
        
        vehicle_details=vehicle_details.drop('_HOODIE_COMMIT_TIME','_HOODIE_COMMIT_TIME_tcu','CREATED_TSP','ENCODEDENCRYPTEDVIN','OPERATION','UPDATEDTSP')
        
        secret_dict = fetch_snowflake_credentials(snowflake_secret_name)
        logging.info("Snowflake credentials loaded successfully")
        sfURL = secret_dict['url']
        sfPassword = secret_dict['password']
        sfUser = secret_dict['username']

        logging.info(f"vehicle details schema : {vehicle_details.schema}")

        if num_records > 0:
            # Initialize Snowflake connection
            conn=get_snowflake_connection(sfUser,sfPassword,sfURL)
            try:
                check_table_exists(spark,conn, target_table_name, job_name, sns_secret_name, region_name, start_time, audit_path, audit_table,source_table_name,source_type,target_type)
                # Continue job logic if table exists
            except Exception as e:
                logging.error(str(e))

            schema_status,target_table_columns = get_evaluated_schema(spark,conn,vehicle_details, target_table_name, sns_secret_name, source_table_name, start_time, job_name, audit_path, audit_table,region_name)
            logging.info(f"Schema status after evaluation: {schema_status}")

            if schema_status == "Aborted":
                logging.error("Schema validation failed. Aborting the job.")
                return False
            
            logging.info("Schema validation successful. Proceeding with merge operation.")

            merge_source_to_target(conn,vehicle_details, stage_table, target_table_name,snowflake_secret_name,primary_key_column)
                
                #update watermark file
            update_watermark_with_latesttime(s3,watermark_bucket,watermark_file_key,source_table_name,max_commit_time)
            
        #get cloudwatch details
        cloudwatch_url = get_cloudwatch_url(region_name, job_name, job_run_id)
        end_time = datetime.now()
        duration = (end_time - start_time).seconds
        
    
        # Log audit
        log_audit(
                spark,job_name,source_table_name,source_type,target_table_name,target_type,"Completed",start_time,end_time,\
                    num_records,audit_path,audit_table,
                )
        logging.info(f"Job completed successfully with processing {num_records} rows in {duration} seconds")
        
        log = {
            "status": "success",
            "job_name": job_name,
            "source_table": source_table_name,
            "target_table": target_table_name,
            "start_time": start_time.isoformat(),
            "end_time": end_time.isoformat(),
            "duration": duration,
            "num_records": num_records
        }
                    
    except Exception as e:
        logging.error("Job failed with error: %s", str(e))
        traceback.print_exc()
        end_time = datetime.now()
        duration = end_time - start_time
        logging.error(f"Job failed in {duration} seconds")
        #get cloudwatch details 
        cloudwatch_url = get_cloudwatch_url(region_name, job_name, job_run_id)
        log = {
                "status": "failure",
                "job_name": job_name,
                "source_table": source_table_name,
                "target_table": target_table_name,
                "start_time": start_time.isoformat(),
                "end_time": end_time.isoformat(),
                "duration": duration,
                "error": f"Error: {str(e)}\nTraceback: {traceback.format_exc()}"
            }
        
        # Log audit
        log_audit(
                spark,job_name,source_table_name,source_type,target_table_name,target_type,\
                "Failed",start_time,end_time,None,audit_path,audit_table,
                )
            
        log_message = "\n".join([f"{key}: {value}" for key, value in log.items()])
        message = f"Job -{job_name} failed. Transformation returned None.\n\n{log_message}.\n\nView the logs in CloudWatch:{cloudwatch_url}"
        subject=f"Job Failed : Job - {job_name}"
        send_sns_notification(subject, message, sns_secret_name,region_name)
        raise

    finally:
        final_log = log.copy() 
        yaml_params = {
        "table_name": source_table_name,
        "audit_table": audit_table, 
        "audit_path":audit_path,
        "yaml_s3_bucket": yaml_s3_bucket,
        "yaml_file_path": yaml_file_key,
        "target_table_name": target_table_name}

        final_log.update(yaml_params)
        dt = datetime.now()
        epoch_time = int(dt.timestamp() * 1000)
        s3 = boto3.client('s3', region_name='ap-south-1')
        s3.put_object(Bucket=watermark_bucket, Key=f'logs/{job_name}-{target_table_name}_{epoch_time}_logs.json', Body=json.dumps(final_log))
      
if __name__ == "__main__":
    main()
