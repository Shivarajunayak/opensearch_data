import sys
import time
import logging
import traceback
import boto3
from awsglue.utils import getResolvedOptions

logging.basicConfig(
    level=logging.INFO, format="%(asctime)s - %(levelname)s - %(message)s"
)

args = getResolvedOptions(sys.argv, ["JOB_NAME", "table_name", "index_name"])

logging.info("job_name=%s", args.get("JOB_NAME"))

# Define the DynamoDB table name and index name
DYNAMODB_TABLE_NAME = args.get("table_name")

PROFILE_TYPE_INDEX_NAME = args.get("index_name")

# Initialize DynamoDB resource and client
dynamodb = boto3.resource("dynamodb")
client = boto3.client("dynamodb")
table = dynamodb.Table(DYNAMODB_TABLE_NAME)


def update_dynamodb_record(vid, profile_id):
    """
    This method updates the updatedTsp timestamp for a given partion and sort key.
    """
    try:
        # Get the current time in seconds
        current_time_seconds = time.time()

        # Convert seconds to milliseconds
        current_time_millis = int(current_time_seconds * 1000)

        table.update_item(
            Key={
                "vid": vid,
                "profileId": profile_id,
            },  # Use both partition key and sort key
            UpdateExpression="SET updatedTsp = :t",
            ExpressionAttributeValues={":t": current_time_millis},
        )
        logging.info("Updated record with vid:%s  and profile_id: %s", vid, profile_id)
    except client.exceptions.ProvisionedThroughputExceededException as e:
        logging.error(
            "Provisioned throughput exceeded for vid %s and profileId %s: %s",
            vid,
            profile_id,
            e,
        )
        raise
    except client.exceptions.ClientError as e:
        logging.error(
            "Client error occurred for vid %s and profileId %s: %s", vid, profile_id, e
        )
        logging.error(traceback.format_exc())
        raise
    except Exception as e:
        logging.error(
            "An unexpected error occurred for vid %s and profileId %s: %s",
            vid,
            profile_id,
            e,
        )
        logging.error(traceback.format_exc())
        raise


def scan_dynamodb(filter_expression, expression_values):
    """
    This method scans the table or index for items matching the filter expression.
    """
    last_evaluated_key = None

    while True:
        try:
            # Initialize scan parameters
            scan_params = {
                "TableName": DYNAMODB_TABLE_NAME,
                "ProjectionExpression": "vid,profileId, profileType, isRider",  # Adjust as needed
                "FilterExpression": filter_expression,
                "ExpressionAttributeValues": expression_values,
            }

            if last_evaluated_key:
                scan_params["ExclusiveStartKey"] = last_evaluated_key

            # Perform the scan operation
            logging.info("performing the scan operation")
            response = client.scan(**scan_params)

            # Process each record

            for item in response.get("Items", []):
                vid = item.get("vid", {}).get("S", "")
                profile_type = item.get("profileType", {}).get("S", "")
                is_rider = item.get("isRider", {}).get("BOOL", False)
                profile_id = item.get("profileId", {}).get(
                    "S", ""
                )  # Adjust primary key name and type

                # Update records based on conditions
                if profile_type == "Primary" or (
                    profile_type != "Primary" and is_rider
                ):
                    # update_dynamodb_record(profile_id)
                    update_dynamodb_record(vid, profile_id)

            # Check if there are more items to retrieve
            last_evaluated_key = response.get("LastEvaluatedKey")
            if not last_evaluated_key:
                break  # Exit the loop if no more items
        except client.exceptions.ClientError as e:
            logging.error("Client error occurred during scan: %s", e)
            logging.error(traceback.format_exc())
            raise
        except Exception as e:
            logging.error("An unexpected error occurred during scan: %s", e)
            logging.error(traceback.format_exc())
            raise


def main():
    """
    Main method to perform DynamoDB operations.
    """
    try:
        # Scan for profileType = primary and profileType <> primary and isRider=True

        scan_dynamodb(
            "(profileType = :pt) OR (profileType <> :pt AND isRider = :ir)",
            {":pt": {"S": "Primary"}, ":ir": {"BOOL": True}},
        )

    except Exception as e:
        logging.error("An unexpected error occurred in the main function: %s", e)
        logging.error(traceback.format_exc())
        raise


if __name__ == "__main__":
    main()
