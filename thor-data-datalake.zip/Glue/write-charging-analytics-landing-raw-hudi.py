   
# pylint: disable=import-error, invalid-name, too-many-locals, too-many-statements, broad-except
import sys
import logging
from datetime import datetime,timedelta
import boto3
import json
import traceback
from awsglue.utils import getResolvedOptions
from pyspark.sql import functions as F
from pyspark.sql.functions import max
from pyspark.sql.types import StructType,StructField,ArrayType,StringType,LongType,MapType
from hmcl_cv_common_utilities import (
    log_audit,
    load_yaml_config,
    validate_audit_table,
    send_sns_notification,
    get_watermark_timestamp,
    get_cloudwatch_url,
    update_watermark_file,
    initialize_spark_session,
    validate_audit_table_with_s3_partition
    )


logging.basicConfig(
    level=logging.INFO, format="%(asctime)s - %(name)s - %(levelname)s - %(message)s"
)

def read_job_param():
    try:
    
        # Define arguments
        arguments = [
            "JOB_NAME",
            "yaml_s3_bucket",
            "yaml_file_key"
        ]
        # Get the arguments
        args = getResolvedOptions(sys.argv, arguments)
        job_name = args.get("JOB_NAME")
        job_run_id = args.get("JOB_RUN_ID")
        yaml_s3_bucket = args.get("yaml_s3_bucket")
        yaml_file_key = args.get("yaml_file_key")
        logging.info("Job parameters read successfully")
        return yaml_s3_bucket,yaml_file_key,job_name,job_run_id
        
    except Exception as e:
        logging.error(f"Error while reading job parameters: {str(e)}")
        raise


def read_yaml_file(s3_client,yaml_s3_bucket,yaml_file_key):
    try:
        # Read YAML file from S3
        yaml_dict = load_yaml_config(s3_client,yaml_s3_bucket,yaml_file_key)
        
        audit_database = yaml_dict['audit_database']
        source_table_name = yaml_dict['hudi_table_name']
        target_table_name = yaml_dict['hudi_table_name_raw']
        target_database = yaml_dict['hudi_database_raw']
        source_hudi_table_path = yaml_dict['hudi_table_path']
        target_hudi_table_path = yaml_dict['hudi_table_path_raw']
        partition_field = yaml_dict['partition_field']
        recordkey = yaml_dict['recordkey']
        sns_secret_name = yaml_dict['sns_secret_name']
        raw_watermark_bucket = yaml_dict['raw_watermark_bucket']
        raw_watermark_file_key = yaml_dict['raw_watermark_file_key']
        audit_path = yaml_dict['audit_path']
        audit_table = yaml_dict['audit_table']
        region_name = yaml_dict['region']
    
        logging.info("yaml parameters read successfully")
        return audit_database,source_table_name,target_table_name,target_database,source_hudi_table_path,target_hudi_table_path,\
            recordkey,partition_field,sns_secret_name,raw_watermark_bucket,raw_watermark_file_key,\
            audit_path,audit_table,region_name
    except Exception as e:
        logging.error(f"Error while reading yaml parameters: {str(e)}")
        raise

def load_df_into_target_table(source_df,target_table_name,target_database,target_hudi_table_path,recordkey,partition_field,precombine_field):
    """
    This function loads  data into raw
    """
    try:
        logging.info(f"PARTITION VALUES  (partition_field) in main table load: {partition_field}")
        # Define Hudi options
        source_df.write.format("hudi") \
            .option("hoodie.table.name", target_table_name) \
            .option("hoodie.datasource.write.storage.type", "COPY_ON_WRITE") \
            .option("hoodie.datasource.write.recordkey.field", recordkey) \
            .option("hoodie.datasource.write.partitionpath.field", partition_field) \
            .option("hoodie.datasource.write.precombine.field", precombine_field) \
            .option("hoodie.datasource.write.operation", "upsert") \
            .option("hoodie.datasource.hive_sync.enable", "true") \
            .option("hoodie.datasource.hive_sync.database", target_database) \
            .option("hoodie.datasource.hive_sync.table", target_table_name) \
            .option("hoodie.datasource.hive_sync.use_jdbc", "false") \
            .option("hoodie.datasource.hive_sync.mode", "hms") \
            .option("hoodie.datasource.hive_sync.sync_as_datasource", "false") \
            .option("hoodie.datasource.hive_sync.support_timestamp", "true") \
            .option("hoodie.avro.schema.allow.empty", "true") \
            .option("hoodie.schema.on.read.enable", "true") \
            .option("hoodie.datasource.write.schema.evolution.enable", "true") \
            .option("hoodie.parquet.max.file.size", "134217728") \
            .option("hoodie.upsert.shuffle.parallelism", 200) \
            .mode("append") \
            .save(target_hudi_table_path)
        ## .option("hoodie.datasource.hive_sync.partition_fields": partition_field) \
        logging.info(f"Data loaded successfully into {target_table_name} table,\
            no.of processed records count: {source_df.count()}")
        return True
    except Exception as e:
        logging.error(f"Error while loading the data into table:{target_table_name}, {str(e)}")
        raise

def read_source_table(spark,watermark_timestamp,source_hudi_table_path):
    try:
        # Read the Hudi table incrementally
        source_df = spark.read.format("hudi")\
            .option("hoodie.datasource.query.type", "incremental")\
            .option("hoodie.datasource.read.begin.instanttime", watermark_timestamp)\
            .load(source_hudi_table_path)
        
            
        logging.info(f"data read successfully from landing, no.of new records in landing :{source_df.count()}")
        return source_df,source_df.count()
    except Exception as e:
        logging.error(f"Error while reading the data from landing:{str(e)}")
        raise
    
def update_watermark_with_latesttime(s3,source_df,raw_watermark_bucket,raw_watermark_file_key,source_table_name):
    
    try:
        # Update the watermark for the specific table
        max_commit_time = source_df.agg(max("_hoodie_commit_time")).collect()[0][0]
        update_watermark_file(s3,max_commit_time,raw_watermark_bucket,raw_watermark_file_key,source_table_name)
        return True
    except Exception as e:
        logging.error(f"Error while updating the watermark file:{str(e)}")
        traceback.print_exc()
        raise
    
def add_missing_columns_into_sourcedf(spark,source_df,target_hudi_table_path):
    
    try:
        target_schema_columns = spark.read.format("hudi").load(target_hudi_table_path).schema.fieldNames()
        
        target_schema_columns = set(target_schema_columns)
        source_schema_columns = set(source_df.columns)
        logging.info(f"Target_Schema_columns: {target_schema_columns}")
        logging.info(f"Source_Schema_columns: {source_schema_columns}")
        logging.info(f"Difference between target - source coulums : {target_schema_columns - source_schema_columns}")
        # Add missing columns with null values
        for column_name in target_schema_columns - source_schema_columns:
                source_df = source_df.withColumn(column_name, "")
        logging.info("flattenning data frame after adding into missing columns")
        logging.info(f"flattening df  columns names: {source_df.columns}")

    except Exception as e:
        logging.error(f"Error while adding missing columns into target table:{str(e)}")
    return source_df
    
def load_data_into_hudi_raw(spark_df,table_name,target_database,target_hudi_table_path,recordkey,partition_field):
    
    try:
        hudi_options = {
            "hoodie.table.name": table_name,
            "hoodie.datasource.write.operation": "insert",
            "hoodie.datasource.write.partitionpath.field": partition_field,
            "hoodie.datasource.write.recordkey.field": recordkey,
            "hoodie.datasource.hive_sync.enable": "true",
            "hoodie.datasource.hive_sync.database": target_database,
            "hoodie.datasource.hive_sync.table": table_name,
            "hoodie.datasource.hive_sync.use_jdbc": "false",
            "hoodie.datasource.hive_sync.mode": "hms",
            "hoodie.datasource.hive_sync.support_timestamp": "true",
            "hoodie.datasource.write.schema.evolution.enable": "true",
            "path": target_hudi_table_path,
            "hoodie.parquet.max.file.size": "134217728",
        }
        if len(spark_df.head(1)) > 0:
            spark_df.write.format("org.apache.hudi").options(**hudi_options).mode(
                "append"
            ).save()
        return True
    except Exception as e:
        logging.error(f"Error while loading the data into hudi table {table_name} :{str(e)}")
        traceback.print_exc()
        raise



def flat_signal_column_data(source_df):
    try:
    
        keys = source_df.select(F.explode(F.map_keys(F.col("signals")))).distinct().rdd.flatMap(lambda x: x).collect()
        logging.info(f"signals column fields : {keys}")    
        for key in keys:
            source_df = source_df.withColumn(key.replace(".","_"), F.col("signals").getItem(key))
        normalized_df = source_df.drop("flat_signals","signals")
        return normalized_df
    except Exception as e:
        logging.error(f"Error while flattening signal columns:{str(e)}")
        traceback.print_exc()
        raise


def main():
    
    try:
        start_time = datetime.now()
        logging.info(f"Job started at {start_time}")
        #read job parameters
        yaml_s3_bucket,yaml_file_key,job_name,job_run_id = read_job_param()
        logging.info("job_name=%s", job_name)
        
        #initialize spark job
        spark = initialize_spark_session()
        s3 = boto3.client('s3')
        audit_database,source_table_name,target_table_name,target_database,source_hudi_table_path,target_hudi_table_path,\
            recordkey,partition_field,sns_secret_name,raw_watermark_bucket,raw_watermark_file_key,\
            audit_path,audit_table,region_name = read_yaml_file(s3,yaml_s3_bucket,yaml_file_key)
    except Exception as e:
        logging.error(f"Error in initial steps: {str(e)}")
        traceback.print_exc()
        raise
        
    
    try:
        source_type = "S3-LANDING"
        target_type = "S3-RAW"
        year_partitioned=start_time.year
        month_partitioned=start_time.month
        #Validate the audit table to process the job based on job_status
        validate_audit_table_with_s3_partition(spark,sns_secret_name,start_time,audit_path,audit_table,source_table_name,target_table_name,job_name,region_name,year_partitioned,month_partitioned)
        # Log audit
        log_audit(
                    spark,job_name,source_table_name,source_type,target_table_name,target_type,\
                    "Started",start_time,None,None,audit_path,audit_table,
                )
        #read watermark timestamp
        watermark_timestamp = get_watermark_timestamp(s3,raw_watermark_bucket,raw_watermark_file_key)
        
        # read data from landing table incrementally
        source_df,num_records = read_source_table(spark,watermark_timestamp,source_hudi_table_path)
        
        logging.info("source schema")
        logging.info(source_df.printSchema())
        logging.info(f"number of records :{num_records}")
        if num_records > 0:
            
            flatten_data =  flat_signal_column_data(source_df)
            #load landing data into raw
            flatten_data = add_missing_columns_into_sourcedf(spark,flatten_data,target_hudi_table_path)
            load_data_into_hudi_raw(flatten_data,target_table_name,target_database,target_hudi_table_path,recordkey,partition_field)
            #update watermark file
            update_watermark_with_latesttime(s3,source_df,raw_watermark_bucket,raw_watermark_file_key,source_table_name)
            
        #get cloudwatch details
        cloudwatch_url = get_cloudwatch_url(region_name, job_name, job_run_id)
        end_time = datetime.now()
        duration = (end_time - start_time).seconds
        
    
        # Log audit
        log_audit(
                spark,job_name,source_table_name,source_type,target_table_name,target_type,"Completed",start_time,end_time,\
                    num_records,audit_path,audit_table,
                )
        logging.info(f"Job completed successfully in {duration} seconds")
        
        log = {
            "status": "success",
            "job_name": job_name,
            "source_table": source_table_name,
            "target_table": target_table_name,
            "start_time": start_time.isoformat(),
            "end_time": end_time.isoformat(),
            "duration": duration,
            "num_records": num_records
        }
                    
    except Exception as e:
        logging.error("Job failed with error: %s", str(e))
        traceback.print_exc()
        end_time = datetime.now()
        duration = end_time - start_time
        logging.error(f"Job failed in {duration} seconds")
        #get cloudwatch details 
        cloudwatch_url = get_cloudwatch_url(region_name, job_name, job_run_id)
        log = {
                "status": "failure",
                "job_name": job_name,
                "source_table": source_table_name,
                "target_table": target_table_name,
                "start_time": start_time.isoformat(),
                "end_time": end_time.isoformat(),
                "duration": duration,
                "error": f"Error: {str(e)}\nTraceback: {traceback.format_exc()}"
            }
        
        # Log audit
        log_audit(
                spark,job_name,source_table_name,source_type,target_table_name,target_type,\
                "Failed",start_time,end_time,None,audit_path,audit_table,
                )
            
        log_message = "\n".join([f"{key}: {value}" for key, value in log.items()])
        message = f"Job -{job_name} failed. Transformation returned None.\n\n{log_message}.\n\nView the logs in CloudWatch:{cloudwatch_url}"
        subject=f"Job Failed : Job - {job_name}"
        send_sns_notification(subject, message, sns_secret_name,region_name)
        raise
      
if __name__ == "__main__":
    main()
