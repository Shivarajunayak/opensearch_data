import sys
import logging
from datetime import datetime,timedelta
import boto3
import traceback
import psycopg2
import json
from awsglue.utils import getResolvedOptions
from pyspark.sql.types import  StringType, DoubleType, BooleanType,LongType,MapType
from concurrent.futures import ThreadPoolExecutor, as_completed
from pyspark.sql.functions import  lit
from pyspark.sql.functions import explode, from_json,col
from pyspark.sql.functions import when
from pyspark.sql.window import Window
import pyspark.sql.functions as F 
from pyspark.sql.types import IntegerType, StringType, LongType, FloatType,\
    DoubleType, BooleanType, DateType, TimestampType, DecimalType, ArrayType
import snowflake.connector
    
from hmcl_cv_common_utilities import (
    log_audit,
    load_yaml_config,
    validate_audit_table_with_s3_partition,
    send_sns_notification,
    get_watermark_timestamp,
    get_cloudwatch_url,
    update_watermark_file,
    initialize_spark_session,
    fetch_postgres_credentials,
    )
logging.basicConfig(
    level=logging.INFO, format="%(asctime)s - %(name)s - %(levelname)s - %(message)s"
)



def read_job_param():
    try:
    
        # Define arguments
        arguments = [
            "JOB_NAME",
            "yaml_s3_bucket",
            "yaml_file_key"
        ]
        # Get the arguments
        args = getResolvedOptions(sys.argv, arguments)
        job_name = args.get("JOB_NAME")
        yaml_s3_bucket = args.get("yaml_s3_bucket")
        yaml_file_key = args.get("yaml_file_key")
        job_run_id = args.get("JOB_RUN_ID")
        logging.info("Job parameters read successfully")
        return yaml_s3_bucket,yaml_file_key,job_name,job_run_id
        
    except Exception as e:
        logging.error(f"Error while reading job parameters: {str(e)}")
        raise
    

def read_yaml_file(s3_client,yaml_s3_bucket,yaml_file_key):
    try:
        yaml_dict = load_yaml_config(s3_client,yaml_s3_bucket,yaml_file_key)
        
        source_table_name = yaml_dict['table_name_landing']
        source_type = yaml_dict['type_landing']
        table_path_landing = yaml_dict["table_path_landing"]
        landing_bucket = yaml_dict["bucket_name_landing"]
        recordkey = yaml_dict['recordkey']
        partition_field = yaml_dict['partition_field']
        sns_secret_name = yaml_dict['sns_secret_name']
        audit_path = yaml_dict['audit_path']
        audit_table = yaml_dict['audit_table']
        target_type = yaml_dict['type_raw']
        target_database = yaml_dict['database_raw']
        target_table_prefix = yaml_dict['table_prefix_raw']
        target_bucket_name = yaml_dict["bucket_name_raw"]
        target_hudi_table_path = yaml_dict["table_path_prefix_raw"]
        raw_watermark_bucket = yaml_dict['watermark_bucket_raw']
        raw_watermark_file_key = yaml_dict['watermark_file_key_raw']
        region_name = yaml_dict['region_name']
        snowflake_stage_table = yaml_dict['snowflake_stage_table']#
        snowflake_secret_name = yaml_dict['snowflake_secret_name']#
        snowflake_target_table = yaml_dict['snowflake_target_table']#
        ota_tables = yaml_dict['ota_tables']
        target_pg_schema = yaml_dict['target_pg_schema']
        target_pg_secret_name = yaml_dict['target_pg_secret_name']
        pg_secret_region = yaml_dict['pg_secret_region']
        campaign_table_name = yaml_dict['campaign_table_name']
        campaign_source_pg_secret_name = yaml_dict['campaign_source_pg_secret_name']
        campaign_source_secret_region = yaml_dict['campaign_source_secret_region']
        pg_vehicle_model_table = yaml_dict['pg_vehicle_model_table']
        
        source_hudi_table_path = "s3://" + landing_bucket + "/" + table_path_landing + "/"
        
        logging.info("yaml parameters read successfully")
        
        return source_table_name,source_hudi_table_path,source_type,target_table_prefix,target_database,\
        target_type,target_bucket_name,target_hudi_table_path,\
        recordkey,partition_field,sns_secret_name,raw_watermark_bucket,raw_watermark_file_key,\
        audit_path,audit_table,region_name,\
        ota_tables,snowflake_secret_name,snowflake_stage_table,snowflake_target_table,\
            target_pg_schema,target_pg_secret_name,pg_secret_region,campaign_table_name,\
                            campaign_source_pg_secret_name,campaign_source_secret_region,pg_vehicle_model_table
        
    except Exception as e:
        logging.error(f"Error while reading yaml parameters: {str(e)}")
        raise

def read_source_table(spark,watermark_timestamp,source_hudi_table_path):
    try:
        # Read the Hudi table incrementally
        source_df = spark.read.format("hudi")\
            .option("hoodie.datasource.query.type", "incremental")\
            .option("hoodie.datasource.read.begin.instanttime", watermark_timestamp)\
            .load(source_hudi_table_path)
        
            
        logging.info(f"data read successfully from landing, no.of new records in landing :{source_df.count()}")
        return source_df,source_df.count()
    except Exception as e:
        logging.error(f"Error while reading the data from landing:{str(e)}")
        raise
    
def get_postgres_conn_details(secret_name,secret_region):
    try:
        # Extract PostgreSQL credentials from secret
        secret_dict = fetch_postgres_credentials(secret_name,secret_region)
        logging.info("rds_secret_name loaded successfully.")
        db_host = secret_dict['db.host']
        db_port = secret_dict['db.port']
        db_name = secret_dict['db.database']
        db_user = secret_dict['db.username']
        db_password = secret_dict['db.password']
        jdbc_url = f"jdbc:postgresql://{db_host}:{db_port}/{db_name}?user={db_user}&password={db_password}"
        
        return db_host,db_port,db_name,db_user,db_password,jdbc_url
    except Exception as e:
        logging.error(f"Error While fetching Source PostgreSQL credentials from Secrets Manager: {str(e)}")
        traceback.print_exc()
        raise
    
def write_data_into_pg_stage(df,feature,user_name,password,host,port,db,target_pg_schema):
    
    df.write \
        .format("jdbc") \
        .option("url", f"jdbc:postgresql://{host}:{port}/{db}") \
        .option("dbtable", f"{target_pg_schema}.{feature}_stage") \
        .option("user", user_name) \
        .option("password", password) \
        .option("batchsize", "1000") \
        .mode("overwrite") \
        .save()
    logging.info(f"data successfully loaded into  {target_pg_schema}.{feature}_stage Table")
    return True

def upsert_into_pg(db,user_name,password,host,port,target_pg_schema,target_table,feature,columns,upsert_keys):

    # Database connection parameters
    db_params = {
        'dbname': db,
        'user': user_name,
        'password': password,
        'host': host,
        'port': port
    }

    # Establish connection
    with psycopg2.connect(**db_params) as conn:

        # Prepare the column lists for the UPSERT query
        set_clause = ', '.join([f"{col} = EXCLUDED.{col}" for col in columns if col not in upsert_keys.split(",")])
        column_list = ', '.join(columns)

        # Step 2: Construct the dynamic UPSERT query
        upsert_query = f"""
        INSERT INTO {target_pg_schema}.{target_table} ({column_list})
        SELECT {column_list} FROM {target_pg_schema}.{feature}_stage
        ON CONFLICT ({upsert_keys}) 
        DO UPDATE SET
            {set_clause};
        """
        # Step 3: Execute the UPSERT query
        with conn.cursor() as cursor:
            cursor.execute(upsert_query)
    logging.info(f"data successfully loaded into  {target_pg_schema}.{target_table} Table")
    return True

def load_data_into_postgres(final_df,feature,target_pg_schema,target_pg_secret_name,target_secret_region,columns,upsert_keys):
    
    target_pg_table_name = feature
    db_host,db_port,db_name,db_user,db_password,_ \
            = get_postgres_conn_details(target_pg_secret_name,target_secret_region)
    final_df = final_df.drop("year","month","day","tenant_id")
    #remove the null records and store it into error records.
    write_data_into_pg_stage(final_df,feature,db_user,db_password,db_host,db_port,db_name,target_pg_schema)
    upsert_into_pg(db_name,db_user,db_password,db_host,db_port,target_pg_schema,target_pg_table_name,feature,columns,upsert_keys)
    logging.info(f"Data loaded into postgres table : {target_pg_table_name}") 

    
def get_snowflake_connection(sfUser,sfPassword,sfURL):
    """
    Establish and return a Snowflake connection.
    """
    try:
        conn = snowflake.connector.connect(
        user=sfUser,
        password=sfPassword,
        account = sfURL.split('//')[1].split('.snowflakecomputing.com')[0]
    )
        logging.info("Snowflake connection established.")
        return conn
    except Exception as e:
        logging.error(f"Error establishing Snowflake connection: {str(e)}")
        traceback.print_exc()
        raise
    
def get_snowflake_options(secret_dict):
    """
    Create a dictionary of Snowflake options for Spark DataFrame writes.
    """
    return {
        "sfURL": secret_dict['url'],
        "sfDatabase": secret_dict['database'],
        "sfSchema": secret_dict['schema'],
        "sfWarehouse": secret_dict['warehouse'],
        "sfRole": secret_dict['role'],
        "sfUser": secret_dict['username'],
        "sfPassword": secret_dict['password']
    }
    
# Function to cast columns dynamically based on schema from YAML
def cast_columns(df, schema):
    existing_columns = df.columns
    casted_columns = []
    for column, col_type in schema.items():
        if column not in existing_columns:
            logging.warning(f"Column '{column}' not found in DataFrame. Filling with NULL.")
            # Fill missing columns with NULL and cast them to the expected type
            if col_type == "int":
                casted_columns.append(lit(None).cast(IntegerType()).alias(column))
            elif col_type == "bigint":
                casted_columns.append(lit(None).cast(LongType()).alias(column))
            elif col_type == "string":
                casted_columns.append(lit(None).cast(StringType()).alias(column))
            elif col_type == "float":
                casted_columns.append(lit(None).cast(FloatType()).alias(column))
            elif col_type == "double":
                casted_columns.append(lit(None).cast(DoubleType()).alias(column))
            elif col_type == "boolean":
                casted_columns.append(lit(None).cast(BooleanType()).alias(column))
            elif col_type == "date":
                casted_columns.append(lit(None).cast(DateType()).alias(column))
            elif col_type == "timestamp":
                casted_columns.append(lit(None).cast(TimestampType()).alias(column))
            elif col_type == "array_of_integer":
                array_of_integer_schema = ArrayType(IntegerType())
                casted_columns.append(lit(None).cast(ArrayType(IntegerType())).alias(column))
            elif col_type == "array_of_string":
                array_of_string_schema = ArrayType(StringType())
                casted_columns.append(lit(None).cast(ArrayType(StringType())).alias(column))
            elif col_type == "decimal":
                casted_columns.append(lit(None).cast(DecimalType(10, 2)).alias(column))
            else:
                casted_columns.append(lit(None).alias(column))  # Default to NULL if type not recognized
        
        else:
        
            if col_type == "int":
                casted_columns.append(col(column).cast(IntegerType()).alias(column))
            elif col_type == "bigint":
                casted_columns.append(col(column).cast(LongType()).alias(column))
            elif col_type == "string":
                casted_columns.append(col(column).cast(StringType()).alias(column))
            elif col_type == "float":
                casted_columns.append(col(column).cast(FloatType()).alias(column))
            elif col_type == "double":
                casted_columns.append(col(column).cast(DoubleType()).alias(column))
            elif col_type == "boolean":
                casted_columns.append(col(column).cast(BooleanType()).alias(column))
            elif col_type == "date":
                casted_columns.append(col(column).cast(DateType()).alias(column))
            elif col_type == "timestamp":
                casted_columns.append(col(column).cast(TimestampType()).alias(column))
            elif col_type == "array_of_integer":
                array_of_integer_schema = ArrayType(IntegerType())
                casted_columns.append(from_json(col(column),array_of_integer_schema).cast(ArrayType(IntegerType())).alias(column))
            elif col_type == "array_of_string":
                array_of_string_schema = ArrayType(StringType())
                casted_columns.append(from_json(col(column),array_of_string_schema).cast(ArrayType(StringType())).alias(column))
            elif col_type == "decimal":
                # Assuming default precision and scale, you can adjust as needed
                casted_columns.append(col(column).cast(DecimalType(10, 2)).alias(column))
            else:
                casted_columns.append(col(column).alias(column))  # Default to no casting if type not recognized
                
    # added below columns for partition purpose
    casted_columns.append(col("year"))
    casted_columns.append(col("month"))
    casted_columns.append(col("day"))
    casted_columns.append(col("tenant_id"))
    new_df = df.select(casted_columns)
    
    return new_df

 
def fetch_snowflake_credentials(secret_name):
    try:
        client = boto3.client('secretsmanager')
        response = client.get_secret_value(SecretId=secret_name)
        secret = json.loads(response['SecretString'])
        return secret
    except Exception as e:
        logging.error(f"Error while fetching snowflake credentials: {str(e)}")
        traceback.print_exc()
        raise

def load_data_into_snowflake_stage(df,snowflake_options,stage_table):
    try:
        # Write the DataFrame to a temporary Snowflake table
        df.write.format("snowflake") \
            .options(**snowflake_options) \
            .option("dbtable", stage_table) \
            .mode("overwrite") \
            .save()
    except Exception as e:
        logging.error(f"Error while loading data into snowflake stage: {str(e)}")
        traceback.print_exc()
        raise  
    
def execute_merge_query(conn,query):
    """Execute the Snowflake MERGE query."""
    try:
        cursor = conn.cursor()
        cursor.execute(query)
    finally:
        cursor.close()
        conn.close()
        
def prepare_merge_query(columns,target_table,stage_table,upsert_keys_list):
    
    update_col = []
    insert_col = []
    values_col = []
    on_condition = " AND ".join([f"target.{col_} = source.{col_}" for col_ in upsert_keys_list])
    for col_ in columns:
        update_col.append(f"target.{col_} = source.{col_}")
        insert_col.append(col_)
        values_col.append(f"source.{col_}")
        
    update_col_str = ','.join(update_col)
    insert_col_str = ','.join(insert_col)
    values_col_str = ','.join(values_col)
    
    merge_query = f"""
            MERGE INTO {target_table} AS target
            USING {stage_table} AS source
            ON {on_condition}
            WHEN MATCHED THEN
                UPDATE SET
                    {update_col_str}
            WHEN NOT MATCHED THEN
                INSERT ({insert_col_str})
                VALUES ({values_col_str})
            """
    logging.info(f"MERGE QUERY {merge_query}")
    return merge_query    
     
   
def load_df_into_snowflake_table(source_df,snowflake_secret_name,stage_table,target_table,columns,upsert_keys):
    try: 
        
        upsert_keys_list = upsert_keys.split(",")
        
        secret_dict = fetch_snowflake_credentials(snowflake_secret_name)
        logging.info("Snowflake credentials loaded successfully.")
        snowflake_options = get_snowflake_options(secret_dict)
        
        sfURL = snowflake_options["sfURL"]
        sfUser = snowflake_options["sfUser"]
        sfPassword = snowflake_options["sfPassword"] 
        
        conn = get_snowflake_connection(sfUser,sfPassword,sfURL)
        

        load_data_into_snowflake_stage(source_df,snowflake_options,stage_table)
        
        merge_query = prepare_merge_query(columns,target_table,stage_table,upsert_keys_list)
        # Execute the Merge Query
        execute_merge_query(conn, merge_query)
    
    except Exception as e:
        logging.error(f"Error while loading data into target snowflake table: {str(e)}")
        traceback.print_exc()
        raise
    
     
def load_data_into_raw(split_df,hudi_target_table_name,recordkey,partition_field,target_database,hudi_target_path):
    try:
        split_df.write.format("hudi") \
            .option("hoodie.table.name", hudi_target_table_name) \
            .option("hoodie.datasource.write.storage.type", "COPY_ON_WRITE") \
            .option("hoodie.datasource.write.recordkey.field", recordkey) \
            .option("hoodie.datasource.write.partitionpath.field", partition_field) \
            .option("hoodie.datasource.write.operation", "insert") \
            .option("hoodie.datasource.hive_sync.enable", "true") \
            .option("hoodie.datasource.hive_sync.database", target_database) \
            .option("hoodie.datasource.hive_sync.table", hudi_target_table_name) \
            .option("hoodie.datasource.hive_sync.use_jdbc", "false") \
            .option("hoodie.datasource.hive_sync.mode", "hms") \
            .option("hoodie.datasource.hive_sync.sync_as_datasource", "false") \
            .option("hoodie.datasource.hive_sync.support_timestamp", "true") \
            .option("hoodie.avro.schema.allow.empty", "true") \
            .option("hoodie.schema.on.read.enable", "true") \
            .option("hoodie.datasource.write.schema.evolution.enable", "true") \
            .option("hoodie.parquet.max.file.size", "134217728") \
            .option("hoodie.insert.shuffle.parallelism", 200) \
            .mode("append") \
            .save(hudi_target_path)
        logging.info(f"Data loaded successfully into {hudi_target_table_name} table,\
            No.of records processed : {split_df.count()}")
        return
    except Exception as e:
        logging.error(f"Error while upserting the data into table{hudi_target_table_name}:{str(e)}")
        raise
    
# Function to get the schema for a given table name
def get_schema(ota_tables, table_name):
    for table in ota_tables:
        if table['table_name'] == table_name:
            return table['schema']
    return None  # Return None if the table name is not found      
    
def split_into_feature_dfs(source_df,ota_tables,partition_field,target_bucket_name,target_hudi_table_path,job_name,sns_secret_name,sns_region_name):
    try :
        partition_columns = partition_field.split(",")
        error_output_path = "s3://" + target_bucket_name +"/"+ target_hudi_table_path+"/errors/"
        df = source_df.select(col("payload"),col("year"),col("month"),col("day"),col("tenant_id"))
        json_schema = MapType(StringType(), StringType())
        df_parsed = df.withColumn("parsed_payload", from_json(col("payload"), json_schema))
       
        
        keys_df = df_parsed.select(explode(df_parsed.parsed_payload).alias("key", "value"))
        
        # Get Unique Keys
        unique_keys = keys_df.select("key").distinct()
        
        # Convert unique keys to a list
        unique_keys_list = [row.key for row in unique_keys.collect()]

        # Need to remove later added just to see logs
        print(unique_keys_list)
        for key in unique_keys_list:
            df_parsed = df_parsed.withColumn(key, col("parsed_payload").getItem(key))
        if "vin" in df_parsed.columns:
            df_parsed = df_parsed.withColumnRenamed("vin", "vid")
            
        df_parsed = df_parsed.select([df_parsed[col_].alias(col_.replace("-", "_")) for col_ in df_parsed.columns])
        
        df_parsed = df_parsed.select([col(column).alias(column.lower()) for column in df_parsed.columns])

            
        # Drop the json_normalized column (if you don't need it anymore)
        full_flattened_df = df_parsed.drop("parsed_payload","payload")
        
        flattened_df = full_flattened_df.filter(col("feature_name").isNotNull())
        flattened_df = flattened_df.filter(col("created_on").isNotNull())
        
        error_df = full_flattened_df.subtract(flattened_df)
        error_rec_count = error_df.count()
        
        
        if error_rec_count > 0:
            error_df.write.partitionBy(*partition_columns).mode("append").json(error_output_path)
            send_sns_notification(
                subject=f" Job - {job_name} found error records",
                message=f"feature_name/created_on  column has {error_rec_count} null values, records are moving into : {error_output_path} Folder",
                sns_secret_name=sns_secret_name,
                region_name=sns_region_name)
        # notification should send when null values present in created_on
        # error records will store it into erro folder.
        
        feature_dfs = {}
        if flattened_df.count() > 0:
            flattened_df = flattened_df.withColumn('updated_on', when(col('updated_on').isNull(), col('created_on')).otherwise(col('updated_on')))
            # Get unique values in the feature_name column
            unique_feature_names = flattened_df.select("feature_name").distinct().rdd.flatMap(lambda x: x).collect()

            # Create a dictionary to hold DataFrames
            dfs = {}
            # Split the DataFrame based on unique values in the feature_name column
            for feature in unique_feature_names:
                dfs[feature] = flattened_df.filter(flattened_df.feature_name == feature)
                
            for feature, split_df in dfs.items():
                
                if feature == "fota_campaign":
                    ota_table_name = "ota_campaign"
                elif feature == "campaign_package":
                    ota_table_name = "ota_campaign_package"
                elif feature == 'rollback':
                    ota_table_name = "ota_rollback"
                else:
                    ota_table_name = feature

                schema = get_schema(ota_tables, ota_table_name)
                if schema:
                    casted_split_df = cast_columns(split_df, schema)
                    logging.info(f"FEATURE DF :{ota_table_name}")
                    
                else:
                    
                    # if columns not found move records into error folder
                    split_df.write.partitionBy(*partition_columns).mode("append").json(error_output_path)
                    send_sns_notification(
                        subject=f" Job - {job_name} found error records",
                        message=f"feature_name not found, {error_rec_count} records are moving into : {error_output_path} Folder",
                        sns_secret_name=sns_secret_name,
                        region_name=sns_region_name)
                    continue
                feature_dfs[ota_table_name] = casted_split_df  
        return feature_dfs
    
    except Exception as e:
        logging.error(f"Error while split the  payload data:{str(e)}")
        raise
    
def add_buffer_to_hudi_commit_time(hudi_timestamp,num_of_hours):
    
    try:
        # Parse the timestamp to a datetime object
        parsed_time = datetime.strptime(hudi_timestamp[:-3], "%Y%m%d%H%M%S")
        # Subtract one hour
        time_one_hour_back = parsed_time - timedelta(hours=num_of_hours)
        # Format it back to the Hudi timestamp format
        new_hudi_timestamp = time_one_hour_back.strftime("%Y%m%d%H%M%S") + hudi_timestamp[-3:]
        return new_hudi_timestamp
    
    except Exception as e:
        logging.error(f"Error while adding buffer to hudi commit time :{str(e)}")
        raise
    
def read_postgres_table(spark,source_table,source_pg_secret_name,source_secret_region):
    """
    Read data incrementally from PostgreSQL using a id value.
    """
    try:
        _,_,_,db_user,db_password,jdbc_url \
            = get_postgres_conn_details(source_pg_secret_name,source_secret_region)
        
        logging.info("Configurations extracted and processed successfully.")
        
        jdbc_properties = {
            "user": db_user,
            "password": db_password,
            "driver": "org.postgresql.Driver"
        }
        
        # Construct the SQL query
        query = f"(SELECT * FROM {source_table}) AS temp"
        logging.info(f"Constructed SQL query: {query}")

        # Execute the query and fetch data
        df = spark.read.jdbc(url=jdbc_url, table=query, properties=jdbc_properties)
        new_pg_rows = df.count()
        logging.info(f"Fetched {new_pg_rows} rows from PostgreSQL")

        return df

    except Exception as e:
        logging.error(f"Error fetching PostgreSQL data: {str(e)}")
        traceback.print_exc()
        raise
    
def add_campaign_type(finaldf,spark,campaign_table_name,campaign_source_pg_secret_name,campaign_source_secret_region):
    
    try:
        campaign_df = read_postgres_table(spark,campaign_table_name,campaign_source_pg_secret_name,campaign_source_secret_region)
        campaign_df = campaign_df.select(col("name").alias("campaign_name"),col("campaign_type"))
        finaldf = finaldf.join(campaign_df,on="campaign_name",how = "left")
        return finaldf
    
    except Exception as e:
        logging.error(f"Error fetching PostgreSQL Campaign data: {str(e)}")
        traceback.print_exc()
        raise

def read_postgres_full_table(spark,source_pg_secret_name,source_secret_region,pg_vehicles_table):
    """
    Read data incrementally from PostgreSQL using a id value.
    """
    try:
        _,_,_,db_user,db_password,jdbc_url \
            = get_postgres_conn_details(source_pg_secret_name,source_secret_region)
        
        logging.info("Configurations extracted and processed successfully.")
        
        jdbc_properties = {
            "user": db_user,
            "password": db_password,
            "driver": "org.postgresql.Driver"
        }
        
        # Construct the SQL query
        query = f"(SELECT * FROM {pg_vehicles_table}) AS temp"
        logging.info(f"Constructed SQL query: {query}")

        # Execute the query and fetch data
        df = spark.read.jdbc(url=jdbc_url, table=query, properties=jdbc_properties)
        new_pg_rows = df.count()
        logging.info(f"Fetched {new_pg_rows} rows from PostgreSQL")

        return df

    except Exception as e:
        logging.error(f"Error fetching PostgreSQL data: {e}")
        traceback.print_exc()
        raise
    
def load_data_into_targets(feature, split_df,ota_tables,target_bucket_name,pg_vehicle_model_table, target_hudi_table_path,target_table_prefix,\
                    target_database,recordkey,snowflake_secret_name,stage_table,target_table,\
                    partition_field,target_pg_schema,target_pg_secret_name,pg_secret_region,\
                    spark,campaign_table_name,campaign_source_pg_secret_name,campaign_source_secret_region):
    try:
        rec_count = split_df.count()
        logging.info(recordkey)
        logging.info(partition_field)
        logging.info(split_df.show())
        
        schema = get_schema(ota_tables, feature)
        columns = schema.keys()
        stage_table = stage_table+"_"+feature.upper()
        target_table = target_table+"_"+feature.upper()
        
        if rec_count > 0:
            hudi_target_path = "s3://" + target_bucket_name +"/"+ target_hudi_table_path+"/"+feature+"/"
            hudi_target_table_name = target_table_prefix+'_'+feature.replace("ota_","")
            load_data_into_raw(split_df,hudi_target_table_name,recordkey,partition_field,target_database,hudi_target_path)
            logging.info(f"{feature} data  loaded into {hudi_target_table_name} Hudi table, {rec_count} records loaded")
            if feature == "ota_campaign":
                logging.info("campaign detected")
                upsert_keys = "id"
                window_spec = Window.partitionBy(col("id")).orderBy(col("source_timestamp").desc())
            elif feature == "ota_campaign_package":
                upsert_keys = "vid,campaign_name"
                logging.info("campaign package detected")
                window_spec = Window.partitionBy(col("vid"),col("campaign_name")).orderBy(col("source_timestamp").desc())
            else:
                upsert_keys = "vid,created_on"
                logging.info(f"{feature} detected")
                window_spec = Window.partitionBy(col("vid"),col("created_on")).orderBy(col("source_timestamp").desc())
                
            split_df_with_row_number = split_df.withColumn("row_number",F.row_number().over(window_spec))
            # get only the latest record per campaign
            finaldf = split_df_with_row_number.filter(col("row_number")==1)
            not_required_columns = ["feature_name","object_sequence"]
            columns = list(set(columns) - set(not_required_columns))
            rec_count1 = finaldf.count()
            
            if feature == "ota_campaign":
                vehicles_df = read_postgres_full_table(spark,target_pg_secret_name,pg_secret_region,pg_vehicle_model_table)
                
                finaldf = finaldf.withColumn("vehicle_model_exploded", explode(col("vehicle_models")))
                
                finaldf = finaldf.alias("c").join(
                    vehicles_df.alias("v"),
                    col("c.vehicle_model_exploded") == col("v.vds_code"),
                    how="left"
                )
                
                finaldf = finaldf.select("c.*", col("v.vehicle_model_name").alias("vehicle_model_name"))
                finaldf = finaldf.drop("vehicle_model_exploded")
                finaldf = finaldf.dropDuplicates(["id"])
                columns.append("vehicle_model_name")

            
            if feature == "ota_campaign_package":
                finaldf = add_campaign_type(finaldf,spark,campaign_table_name,campaign_source_pg_secret_name,campaign_source_secret_region)
                columns.append("campaign_type")
            load_df_into_snowflake_table(finaldf,snowflake_secret_name,stage_table,target_table,columns,upsert_keys)
            logging.info(f"{feature} data  loaded into ota_{feature} snoeflake table successfully, record count : {rec_count1}")
            load_data_into_postgres(finaldf,feature,target_pg_schema,target_pg_secret_name,pg_secret_region,columns,upsert_keys)
            logging.info(f"{feature} data  loaded into ota_{feature} pg table successfully, record count : {rec_count1}")
        
        return rec_count
    except Exception as e:
        logging.error(f"Error while loading the data into targets :{str(e)}")
        raise

def process_payload_data(source_df,target_table_prefix,target_database,target_bucket_name,pg_vehicle_model_table,\
    target_hudi_table_path,recordkey,partition_field,sns_region_name,\
        snowflake_secret_name,stage_table,target_table,ota_tables,job_name,sns_secret_name,\
        target_pg_schema,target_pg_secret_name,pg_secret_region,spark,campaign_table_name,\
            campaign_source_pg_secret_name,campaign_source_secret_region):
    try:    
        feature_dicts = split_into_feature_dfs(source_df,ota_tables,partition_field,target_bucket_name,target_hudi_table_path,job_name,sns_secret_name,sns_region_name)
        # Create a ThreadPoolExecutor to manage threads
        total_processed_records_count = 0
        
        with ThreadPoolExecutor(max_workers=4) as executor:
            # Submit tasks with additional arguments (config and metadata)
            feature_dfs = {
                executor.submit(load_data_into_targets, feature, split_df, ota_tables,\
                    target_bucket_name,pg_vehicle_model_table, target_hudi_table_path,target_table_prefix,target_database,recordkey,\
                    snowflake_secret_name,stage_table,target_table,partition_field,target_pg_schema,\
                        target_pg_secret_name,pg_secret_region,spark,campaign_table_name,\
                            campaign_source_pg_secret_name,campaign_source_secret_region ):feature
                for feature, split_df in feature_dicts.items()
            }
            
        # Iterate over the futures as they complete
        for res in as_completed(feature_dfs):
            try:
                feature_name = feature_dfs[res]
                record_count = res.result()  # Get the result of the future (i.e., the S3 path)
                total_processed_records_count += record_count 
                print(f"Successfully {feature_name} data loaded into thier target tables")
            except Exception as e:
                print(f"Error occurred: {str(e)}")
                raise
                
        logging.info(f"payload data processed successfully, Total {total_processed_records_count} records loaded into their respective feature tables")
        return
    except Exception as e:
        logging.error(f"Error while processing payload data:{str(e)}")
        raise
    
def update_watermark_with_latesttime(s3,source_df,raw_watermark_bucket,raw_watermark_file_key,source_table_name):
    
    try:
        # Update the watermark for the specific table
        max_commit_time = source_df.agg({"_hoodie_commit_time": "max"}).collect()[0][0]
        # new_hudi_timestamp = add_buffer_to_hudi_commit_time(max_commit_time,1)
        update_watermark_file(s3,max_commit_time,raw_watermark_bucket,raw_watermark_file_key,source_table_name)
        return True
    except Exception as e:
        logging.error(f"Error while updating the watermark file:{str(e)}")
        raise

def main():
    
    try:
        
        start_time = datetime.now()
        logging.info(f"Job started at {start_time}")
        
        #initialize spark job
        spark = initialize_spark_session()
        
        #read job parameters
        yaml_s3_bucket,yaml_file_key,job_name,job_run_id = read_job_param()
        logging.info("job_name=%s", job_name)
        
        
        
        #create an S3 client
        s3 = boto3.client('s3')

        #read necessary  parameters from yaml file
        source_table_name,source_hudi_table_path,source_type,target_table_prefix,target_database,\
        target_type,target_bucket_name,target_hudi_table_path,\
        recordkey,partition_field,sns_secret_name,raw_watermark_bucket,raw_watermark_file_key,\
        audit_path,audit_table,region_name,\
        ota_tables,snowflake_secret_name,stage_table,target_table,\
        target_pg_schema,target_pg_secret_name,pg_secret_region,campaign_table_name,\
        campaign_source_pg_secret_name,campaign_source_secret_region,pg_vehicle_model_table = read_yaml_file(s3,yaml_s3_bucket,yaml_file_key)
    except Exception as e:
        logging.error(f"Error in initial steps: {str(e)}")
        traceback.print_exc()
        raise
    
    
    try:
        year_partitioned=start_time.year
        month_partitioned=start_time.month
        #validate audit table
        is_validate = validate_audit_table_with_s3_partition(spark,sns_secret_name,start_time,audit_path,audit_table,source_table_name,target_table_prefix,job_name,region_name,year_partitioned,month_partitioned)
       
        if is_validate == False:
            return 
              
        # Log audit
        log_audit(
                    spark,job_name,source_table_name,source_type,target_table_prefix,target_type,\
                    "Started",start_time,None,None,audit_path,audit_table,
                )
        #read watermark timestamp
        watermark_timestamp = get_watermark_timestamp(s3,raw_watermark_bucket,raw_watermark_file_key)
        
        # read data from landing table incrementally
        source_df,num_records = read_source_table(spark,watermark_timestamp,source_hudi_table_path)
        
        
        source_df.printSchema()
        if num_records > 0:
            
            # process payload data
            process_payload_data(source_df,target_table_prefix,target_database,target_bucket_name,pg_vehicle_model_table,\
                target_hudi_table_path,recordkey,partition_field,region_name,\
                    snowflake_secret_name,stage_table,target_table,ota_tables,job_name,sns_secret_name,\
                        target_pg_schema,target_pg_secret_name,pg_secret_region,spark,campaign_table_name,\
                            campaign_source_pg_secret_name,campaign_source_secret_region)
            
            update_watermark_with_latesttime(s3,source_df,raw_watermark_bucket,raw_watermark_file_key,source_table_name)
            
        #get cloudwatch details
        cloudwatch_url = get_cloudwatch_url(region_name, job_name, job_run_id)
        
        end_time = datetime.now()
        duration = (end_time - start_time).seconds
        
        log = {
            "status": "success",
            "job_name": job_name,
            "source_table": source_table_name,
            "target_table": target_table_prefix,
            "start_time": start_time.isoformat(),
            "end_time": end_time.isoformat(),
            "duration": duration,
            "num_records": num_records
        }
        
        # Log audit
        log_audit(
                spark,job_name,source_table_name,source_type,target_table_prefix,target_type,"Completed",start_time,end_time,num_records,audit_path,audit_table,
                )
        logging.info(f"Job completed successfully in {duration} seconds")
        
        
                    
    except Exception as e:
        logging.error("Job failed with error: %s", str(e))
        traceback.print_exc()
        end_time = datetime.now()
        duration = end_time - start_time
        logging.error(f"Job failed in {duration} seconds")
        
        #get cloudwatch details 
        cloudwatch_url = get_cloudwatch_url(region_name, job_name, job_run_id)
        
        log = {
                "status": "failure",
                "job_name": job_name,
                "source_table": source_table_name,
                "target_table": target_table_prefix,
                "start_time": start_time.isoformat(),
                "end_time": end_time.isoformat(),
                "duration": duration,
                "error": f"Error: {str(e)}\nTraceback: {traceback.format_exc()}"
            }
        
        # Log audit
        log_audit(
                spark,job_name,source_table_name,source_type,target_table_prefix,target_type,\
                "Failed",start_time,end_time,None,audit_path,audit_table,
                )
            
        log_message = "\n".join([f"{key}: {value}" for key, value in log.items()])
        message = f"Job -{job_name} failed. Transformation returned None.\n\n{log_message}.\n\nView the logs in CloudWatch:{cloudwatch_url}"

        send_sns_notification(
            subject=f"Job Failed : Job - {job_name}",
            message=message,
            sns_secret_name=sns_secret_name,
            region_name=region_name)
        raise

if __name__ == "__main__":
    main()

