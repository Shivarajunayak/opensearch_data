import boto3
import logging
import sys
import traceback
from datetime import datetime
import snowflake.connector
import json
from awsglue.utils import getResolvedOptions
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime, timezone, timedelta
from pyspark.sql.functions import col
from pyspark.sql import SparkSession
from pyspark.sql.types import ArrayType

from hmcl_cv_common_utilities import  update_watermark_file, get_watermark_timestamp,send_sns_notification,\
    get_cloudwatch_url,load_yaml_config,log_audit,validate_audit_table_with_s3_partition

logging.basicConfig(level=logging.INFO, format="%(asctime)s - %(name)s - %(levelname)s -%(message)s")
logger = logging.getLogger()

def read_job_param():
    try:
    
        # Define arguments
        arguments = [
            "JOB_NAME",
            "yaml_s3_bucket",
            "yaml_file_key",
            "source_table_name",
        ]
        # Get the arguments
        args = getResolvedOptions(sys.argv, arguments)
        job_name = args.get("JOB_NAME")
        job_run_id = args.get("JOB_RUN_ID")
        yaml_s3_bucket = args.get("yaml_s3_bucket")
        yaml_file_key = args.get("yaml_file_key")
        source_table_name = args.get("source_table_name")
        logging.info("Job parameters read successfully")
        return yaml_s3_bucket,yaml_file_key,job_name,job_run_id,source_table_name
        
    except Exception as e:
        logging.error(f"Error while reading job parameters: {str(e)}")
        traceback.print_exc()
        raise

def read_yaml_file(s3_client,yaml_s3_bucket,yaml_file_key,source_table_name):
    try:
        yaml_dict = load_yaml_config(s3_client,yaml_s3_bucket,yaml_file_key)
        first_stage_table = yaml_dict['paths'][source_table_name]['first_stage_table']
        second_stage_table = yaml_dict['paths'][source_table_name]['second_stage_table']
        snowflake_secret_name = yaml_dict['paths'][source_table_name]['snowflake_secret_name']
        sns_secret_name = yaml_dict['paths'][source_table_name]['sns_secret_name']
        ext_table = yaml_dict['paths'][source_table_name]['ext_table']
        watermark_bucket = yaml_dict['paths'][source_table_name]['watermark_bucket']
        watermark_file_key = yaml_dict['paths'][source_table_name]['watermark_file_key']
        region_name = yaml_dict['paths'][source_table_name]['region']
        target_table = yaml_dict['paths'][source_table_name]['target_table']
        audit_path = yaml_dict['paths'][source_table_name]['audit_path']
        audit_table = yaml_dict['paths'][source_table_name]['audit_table']
        source_type = yaml_dict['paths'][source_table_name]['source_type']
        target_type = yaml_dict['paths'][source_table_name]['target_type']
        watermark_column = yaml_dict['paths'][source_table_name]['watermark_column']
        stored_procedure  = yaml_dict['paths'][source_table_name]['stored_procedure']
        exclude_vids_config_file = yaml_dict['paths'][source_table_name]['exclude_vids_config_file']
        hct_latest_timestamp_key = yaml_dict['paths'][source_table_name]['hct_latest_timestamp_key']
        pre_target_table = yaml_dict['paths'][source_table_name]['pre_target_table']
        charging_telemetry_raw_path = yaml_dict['paths'][source_table_name]['charging_telemetry_raw_path']
        sf_warehouse =  yaml_dict['paths'][source_table_name]['sf_warehouse']
        sf_role = yaml_dict['paths'][source_table_name]['sf_role']
        signals = yaml_dict['paths'][source_table_name]['signals']
       
       
        vids_exclude_yaml_dict= load_yaml_config(s3_client,yaml_s3_bucket,exclude_vids_config_file)
        exclude_vids_list = vids_exclude_yaml_dict['vid_filter_list']
        
        logging.info("yaml parameters read successfully")
        logging.info(f"signal list : {signals}")
        
        return first_stage_table,second_stage_table,pre_target_table,snowflake_secret_name,sns_secret_name,ext_table,watermark_bucket,watermark_file_key,\
            region_name,target_table,audit_path,audit_table,source_type,target_type,watermark_column,\
                stored_procedure,hct_latest_timestamp_key,exclude_vids_list,charging_telemetry_raw_path,sf_warehouse,sf_role,signals
    except Exception as e:
        logging.error(f"Error while reading yaml parameters: {str(e)}")
        traceback.print_exc()
        raise

def initialize_spark_session():    
    try:
        spark = SparkSession.builder \
            .config('spark.serializer', 'org.apache.spark.serializer.KryoSerializer') \
            .config('spark.hudi.query.metadata.enable', 'true') \
            .config("spark.sql.analyzer.failAmbiguousSelfJoin", "false") \
            .config('spark.hadoop.hadoop.security.credential.provider.path', '') \
            .getOrCreate()
        return spark
    except Exception as e:
        logging.error(f"Error while initializing the spark Session: {str(e)}")
        traceback.print_exc()
        raise

def fetch_snowflake_credentials(secret_name):
    try:
        client = boto3.client('secretsmanager')
        response = client.get_secret_value(SecretId=secret_name)
        secret = json.loads(response['SecretString'])
        return secret
    except Exception as e:
        logging.error(f"Error while fetching snowflake credentials: {str(e)}")
        traceback.print_exc()
        raise
    
def get_snowflake_connection(sfUser,sfPassword,sfURL):
    """
    Establish and return a Snowflake connection.
    """
    try:
        conn = snowflake.connector.connect(
        user=sfUser,
        password=sfPassword,
        account = sfURL.split('//')[1].split('.snowflakecomputing.com')[0]
    )
        logging.info("Snowflake connection established.")
        return conn
    except Exception as e:
        logging.error(f"Error establishing Snowflake connection: {str(e)}")
        traceback.print_exc()
        raise

def get_sf_options(table_full_path,SF_URL,SF_WAREHOUSE,SF_ROLE,SF_USER,SF_PASSWORD):
    
    SF_DB = table_full_path.split('.')[0]
    SF_SCHEMA = table_full_path.split('.')[1]
        
    sf_options = {
        "sfURL": SF_URL,
        "sfDatabase": SF_DB,
        "sfSchema": SF_SCHEMA,
        "sfWarehouse": SF_WAREHOUSE,
        "sfRole": SF_ROLE,
        "sfUser": SF_USER,
        "sfPassword": SF_PASSWORD
    }
    return sf_options
        

def load_external_table_data_into_stage( spark,telemetry_raw_path,exclude_vids,SF_URL,SF_WAREHOUSE,SF_ROLE,SF_USER,SF_PASSWORD,\
                        watermark_column,current_watermark,year,month,day,hour,first_stage_table,hct_latest_timestamp):
     
    try:

        telemetry  = (
            spark.read.format("hudi").load(telemetry_raw_path) \
            .filter(
                (col("year") > year) |
                ((col("year") == year) & (col("month") > month)) |
                ((col("year") == year) & (col("month") == month) & (col("day") > day)) |
                ((col("year") == year) & (col("month") == month) & (col("day") == day) & (col("hour") >= hour))
            )
            .filter(~col("vid").isin(exclude_vids))  # Exclude vids
            .filter(col(watermark_column) > current_watermark)  # Apply watermark filter
            .filter(col("_hoodie_commit_time") > hct_latest_timestamp)  # Filter on Hudi commit time
        )

        columns_to_drop = [
                "_hoodie_commit_seqno",
                "_hoodie_record_key",
                "_hoodie_partition_path",
                "_hoodie_file_name",
                "campaignname",
                "vehiclename",
                "eventid",
                "msgid",
                "vds",
                "date",
                "timestamp",
                "key",
                "topic",
                "offset",
                "partition",
                "collectioneventtime_ts",
                "_hoodie_commit_time_land_cal",
                "kafka_topic"
            ]

        telemetry = telemetry.drop(*columns_to_drop)
         
        sf_options = get_sf_options(first_stage_table,SF_URL,SF_WAREHOUSE,SF_ROLE,SF_USER,SF_PASSWORD)
        SF_TABLE = first_stage_table.split('.')[2]
        # Write DataFrame to Snowflake table
        telemetry.write \
            .format("snowflake") \
            .options(**sf_options) \
            .option("dbtable", SF_TABLE) \
            .mode("overwrite") \
            .save()
        
        num_records = telemetry.count()
        logging.info(f"Data Loaded into {first_stage_table} snowflake table , number of records processed are :{num_records}")
        return num_records
    except Exception as e:
        logging.error(f"Error during loading data into stage: {str(e)}")
        traceback.print_exc()
        raise
    
def get_year_month_day_hour(epoch_time_ms):
    
    epoch_time_sec = epoch_time_ms / 1000 
    utc_dt = datetime.fromtimestamp(epoch_time_sec, tz=timezone.utc)
    # keep buffer of 4 hours from now
    ist_offset = timedelta(hours=4)
    buffer_dt = utc_dt - ist_offset
    
    year = buffer_dt.year
    month = buffer_dt.month
    day = buffer_dt.day
    hour = buffer_dt.hour
    
    return year,month,day,hour
    

def execute_stored_procedure(conn,stored_procedure,signals,raw_table,stage2_table,pre_target_table,target_table):
    try:
        cursor = conn.cursor()
        sp_call =  f"CALL {stored_procedure}('{signals}','{raw_table}','{stage2_table}','{pre_target_table}','{target_table}');"
        cursor.execute(sp_call)
        result = cursor.fetchone()
        logging.info(f"Stored Procedure executed successfully. Output: {result[0]}")
        return True
    except Exception as e:
        logging.error(f"An error occured while calling SP- {sp_call} : {str(e)}")
        return False
    
    
def load_data_into_snowflake_table(first_stage_table,\
            spark,telemetry_raw_path,SF_URL,SF_WAREHOUSE,SF_ROLE,SF_USER,SF_PASSWORD,\
                current_watermark, watermark_column,hct_latest_timestamp,exclude_vids_list):
    """
    Main function to flatten and merge incremental data from the external table into the target table.
    """
    try:
        
        year,month,day,hour = get_year_month_day_hour(current_watermark)
        
        # load external table data into stage1
        num_records = load_external_table_data_into_stage( spark,telemetry_raw_path,exclude_vids_list,SF_URL,SF_WAREHOUSE,SF_ROLE,SF_USER,SF_PASSWORD,\
                        watermark_column,current_watermark,year,month,day,hour,first_stage_table,hct_latest_timestamp)
        if num_records == 0:
            logging.info("No new records to process.")
            return num_records
        
        logging.info(f"number of records processed : {num_records}")
        return num_records
    except Exception as e:
        logging.error(f"Error while loading data into snowflake: {str(e)}")
        traceback.print_exc()
        raise
    
def process_data(conn, s3_client, num_records, stored_procedure, signal_list, first_stage_table, second_stage_table, pre_target_table, target_table, watermark_column, watermark_bucket,
                 watermark_file_key, hct_latest_timestamp_key):
    try:
        if num_records > 0:
            sp_success = execute_stored_procedure(conn, stored_procedure, signal_list, first_stage_table, second_stage_table, pre_target_table, target_table)

            if not sp_success:
                logging.error("Stored procedure execution failed. Stopping job without updating watermark.")
                raise Exception("Stored procedure execution failed.")  # Stop job immediately

            current_epoch_time_ms = int(datetime.now(timezone.utc).timestamp() * 1000)

            # Use context manager for cursor to calculate new watermark
            with conn.cursor() as cursor:
                new_watermark_query = f"""
                SELECT MAX({watermark_column}) FROM {first_stage_table} WHERE {watermark_column} <= {current_epoch_time_ms} """
                cursor.execute(new_watermark_query)
                new_watermark = cursor.fetchone()[0]
                logging.info(f"New watermark calculated: {new_watermark}")
            
            update_watermark_file(s3_client, new_watermark, watermark_bucket, watermark_file_key, target_table)

            # Use context manager for cursor to calculate hudi commit watermark
            with conn.cursor() as cursor:
                htc_watermark_query = f"""
                SELECT MAX(_hoodie_commit_time) FROM {first_stage_table}"""
                cursor.execute(htc_watermark_query)
                hct_watermark = cursor.fetchone()[0]
                logging.info(f"New hudi commit time: {hct_watermark}")
            
            update_watermark_file(s3_client, hct_watermark, watermark_bucket, hct_latest_timestamp_key, target_table)

    finally:
        # Close the connection after all operations
        if 'conn' in locals() and conn is not None:
            conn.close()
            logging.info("Snowflake connection closed.")


def main():
    
    try:
        logging.info("Job started")
        start_time = datetime.now()

        yaml_s3_bucket,yaml_file_key,job_name,job_run_id,source_table_name = read_job_param()
        logging.info("job_name=%s", job_name+"/"+source_table_name)

        #initialize spark job
        spark = initialize_spark_session()
        
        #create an S3 client
        s3_client = boto3.client('s3')


        #read necessary  parameters from yaml file
        first_stage_table,second_stage_table,pre_target_table,snowflake_secret_name,sns_secret_name,ext_table,watermark_bucket,watermark_file_key,\
        region_name,target_table,audit_path,audit_table,source_type,target_type,watermark_column,\
            stored_procedure,hct_latest_timestamp_key,exclude_vids_list,charging_telemetry_raw_path,sf_warehouse,sf_role,signals \
                = read_yaml_file(s3_client,yaml_s3_bucket,yaml_file_key,source_table_name)
    except Exception as e:
        logging.error(f"Error in initial steps: {str(e)}")
        traceback.print_exc()
        raise

    try:
        year_partitioned=start_time.year
        month_partitioned=start_time.month            
        is_validate = validate_audit_table_with_s3_partition(spark,sns_secret_name,start_time,audit_path,audit_path,ext_table,target_table,job_name,region_name,year_partitioned,month_partitioned )

        if is_validate == False:
            return
        
        secret_dict = fetch_snowflake_credentials(snowflake_secret_name)
        logging.info("Snowflake credentials loaded successfully")
        sfURL = secret_dict['url']
        sfPassword = secret_dict['password']
        sfUser = secret_dict['username']
        
        log_audit(spark,job_name,ext_table,source_type,target_table,target_type,"Started",start_time,None,None,audit_path,audit_table)
        logging.info("logs written to audit table")
                    
        # Initialize Snowflake connection
        conn = get_snowflake_connection(sfUser,sfPassword,sfURL)
        
        #read collectionevent time as a watermark file1
        current_watermark = get_watermark_timestamp(s3_client, watermark_bucket, watermark_file_key)
        logging.info("checking current_watermark dtype")
        if current_watermark == 0:
            current_watermark = 1730332800000
        logging.info(f"Current watermark: {current_watermark}")
                
        #read hct time as a watermark file2
        hct_latest_timestamp = get_watermark_timestamp(s3_client, watermark_bucket, hct_latest_timestamp_key)
        if hct_latest_timestamp == 0:
            hct_latest_timestamp = '20241031000000000'
        logging.info(f"Current watermark: {hct_latest_timestamp}")     

        # Check if Target Table Exists        
        check_table_query = f"SHOW TABLES LIKE '{target_table.split('.')[2]}'"
        table_exists = conn.cursor().execute(check_table_query).fetchone()
        
        if not table_exists:
            logging.error(f"Target table {target_table} does not exist. Aborting job.")
            send_sns_notification(f"{job_name} failed - Missing Target Table", f"The target table {target_table} does not exist.", sns_secret_name, region_name)
            return False  # Exit the function early


        num_records = load_data_into_snowflake_table(first_stage_table,\
            spark,charging_telemetry_raw_path,sfURL,sf_warehouse,sf_role,sfUser,sfPassword,\
                current_watermark, watermark_column,hct_latest_timestamp,exclude_vids_list)
        
        signal_list = ','.join(signals)
        process_data(conn, s3_client, num_records, stored_procedure, signal_list, first_stage_table, second_stage_table, pre_target_table, target_table, watermark_column, watermark_bucket, watermark_file_key, hct_latest_timestamp_key)
            
        end_time = datetime.now()
        
        log_audit(spark,job_name,ext_table,source_type,target_table,target_type,"Completed",start_time,end_time,num_records,audit_path,audit_table)

    except Exception as e:
        logging.error(f"Job failed with error: {str(e)}")
        traceback.print_exc()
        
        end_time = datetime.now()
        duration = (end_time - start_time).seconds
        cloudwatch_url = get_cloudwatch_url(region_name,job_name, job_run_id)
        logging.info("writing to Exception audit logs")
        log_audit(spark,job_name,ext_table,source_type,target_table,target_type,"Failed",start_time,end_time,None,audit_path,audit_table)
        
        log = {
            "status": "failure",
            "job_name": job_name,
            "source_table": ext_table,
            "target_table": target_table,
            "start_time": start_time.isoformat(),
            "end_time": end_time.isoformat(),
            "duration": duration,
            "error": f"Error: {str(e)}\nTraceback: {traceback.format_exc()}"
        }
        log_message = "\n".join([f"{key}: {value}" for key, value in log.items()])
        message = f"Job {job_name} failed. Error: {str(e)}\nTraceback: {traceback.format_exc()} \n\n{log_message}.\n\nView the logs in CloudWatch:{cloudwatch_url}"
        subject =f'{job_name} failed for {ext_table} table'
        if len(subject) > 100:
            subject = subject[:98] + '..'
        send_sns_notification(subject, message, sns_secret_name, region_name)
        raise
    finally:
        end_time = datetime.now()
        duration = (end_time - start_time).seconds
        logging.info(f"Job completed in {duration} seconds")

if __name__ == "__main__":
    main()