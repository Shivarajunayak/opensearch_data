   
# pylint: disable=import-error, invalid-name, too-many-locals, too-many-statements, broad-except
import sys
import logging
from datetime import datetime,timedelta
import boto3
import json
import traceback
from awsglue.utils import getResolvedOptions
from pyspark.sql import functions as F
from pyspark.sql.functions import col
import psycopg2
from hmcl_cv_common_utilities import (
    log_audit,
    load_yaml_config,
    validate_audit_table_with_s3_partition,
    send_sns_notification,
    get_watermark_timestamp,
    get_cloudwatch_url,
    update_watermark_file,
    initialize_spark_session,
    fetch_postgres_credentials
    )


logging.basicConfig(
    level=logging.INFO, format="%(asctime)s - %(name)s - %(levelname)s - %(message)s"
)


def read_job_param():
    try:
    
        # Define arguments
        arguments = [
            "JOB_NAME",
            "yaml_s3_bucket",
            "yaml_file_key",
            "source_table_name",
            "audit_database"
        ]
        # Get the arguments
        args = getResolvedOptions(sys.argv, arguments)
        job_name = args.get("JOB_NAME")
        job_run_id = args.get("JOB_RUN_ID")
        yaml_s3_bucket = args.get("yaml_s3_bucket")
        yaml_file_key = args.get("yaml_file_key")
        source_table_name = args.get("source_table_name")
        audit_database = args.get("audit_database")
        logging.info("Job parameters read successfully")
        return yaml_s3_bucket,yaml_file_key,job_name,job_run_id,source_table_name,audit_database
        
    except Exception as e:
        logging.error(f"Error while reading job parameters: {str(e)}")
        raise


def read_yaml_file(s3_client,yaml_s3_bucket,yaml_file_key,source_table_name):
    try:
        # Read YAML file from S3
        yaml_dict = load_yaml_config(s3_client,yaml_s3_bucket,yaml_file_key)
        target_table_name = yaml_dict[source_table_name]['pg_target_table_name']
        sns_secret_name = yaml_dict[source_table_name]['sns_secret_name']
        watermark_bucket = yaml_dict[source_table_name]['watermark_bucket']
        watermark_file_key = yaml_dict[source_table_name]['watermark_file_key']
        audit_path = yaml_dict[source_table_name]['audit_path']
        audit_table = yaml_dict[source_table_name]['audit_table']
        region_name = yaml_dict[source_table_name]['region']
        rds_secret_name = yaml_dict[source_table_name]['rds_secret_name']
        log_path = yaml_dict[source_table_name]['log_path']
        source_type = yaml_dict[source_table_name]['source_type']
        target_type = yaml_dict[source_table_name]['target_type']
        device_ledger_path = yaml_dict[source_table_name]['device_ledger_path']
        tcu_path = yaml_dict[source_table_name]['tcu_path']
        target_pg_schema = yaml_dict[source_table_name]['target_pg_schema']
        temp_table_name = yaml_dict[source_table_name]['PG_temp_table_name']
        primary_key_column = yaml_dict[source_table_name]['primary_key_column']

        logging.info("yaml parameters read successfully")
        return target_table_name,sns_secret_name,watermark_bucket,watermark_file_key,audit_path,audit_table,region_name,rds_secret_name,log_path,source_type,target_type,device_ledger_path,tcu_path,target_pg_schema,temp_table_name,primary_key_column
    except Exception as e:
        logging.error(f"Error while reading yaml parameters: {str(e)}")
        raise

def read_and_exclude(spark, path, watermark_timestamp, exclude_columns):
    """
    Read a Hudi table incrementally and exclude specific columns.
    
    :param spark: SparkSession
    :param path: Source path of the Hudi table
    :param watermark_timestamp: Incremental read timestamp
    :param exclude_columns: List of columns to exclude
    :return: Filtered DataFrame
    """
    try :
        source_df = spark.read.format("hudi") \
            .option("hoodie.datasource.query.type", "incremental")\
            .option("hoodie.datasource.read.begin.instanttime", watermark_timestamp) \
            .load(path)
        
        remaining_columns = [col for col in source_df.columns if col not in exclude_columns]
        return source_df.select(*remaining_columns)
    except Exception as e:
        logging.error(f"Error reading device_ledger incrementally: {str(e)}")
        traceback.print_exc()
        raise

# Example usage

def extract_distinct_tcu_ids(device_ledger):
    """
    Extracts distinct tcu_id values from the device_ledger DataFrame.
    """
    try:
        tcu_ids = device_ledger.select("tcu_id").distinct()
        logging.info(f"Extracted {tcu_ids.count()} distinct tcu_id values.")
        return tcu_ids
    except Exception as e:
        logging.error(f"Error extracting tcu_id values: {str(e)}")
        traceback.print_exc()
        raise

def read_filtered_tcu_data(spark, tcu_path, tcu_ids, exclude_columns):
    """
    Reads the tcu table and filters it based on the tcu_ids, then normalizes the column names.
    """
    try:
        if tcu_ids.count() == 0:
            logging.info("No tcu_id values found in device_ledger. Skipping tcu table read.")
            return None
        
        # Step 1: Extract tcu_id values from tcu_ids DataFrame into a list
        tcu_ids_list = [row['tcu_id'] for row in tcu_ids.collect()]  # Collecting tcu_ids into a list
        
        # Step 2: Read and filter the tcu table at read time based on tcu_ids
        tcu = spark.read.format("hudi").load(tcu_path) \
            .filter(col("TCU_ID").isin(tcu_ids_list))  # Filter based on the list of tcu_ids
        
        logging.info(f"Read {tcu.count()} rows from tcu table for matching tcu_id values.")

        # Step 3: Normalize column names (renaming conflicting columns)
        duplicate_columns = set(tcu.columns).intersection(set(exclude_columns))  # List of overlapping columns
        
        # Rename conflicting columns by appending a suffix to differentiate them
        for col_name in duplicate_columns:
            tcu = tcu.withColumnRenamed(col_name, f"{col_name}_tcu")

        # Step 4: Remove excluded columns from the tcu DataFrame
        remaining_columns = [col for col in tcu.columns if col not in exclude_columns]
        tcu = tcu.select(*remaining_columns)

        return tcu
        
    except Exception as e:
        logging.error(f"Error reading filtered tcu data: {str(e)}")
        traceback.print_exc()
        raise
    
def add_buffer_to_hudi_commit_time(hudi_timestamp,num_of_hours):
    
    try:
        # Parse the timestamp to a datetime object
        parsed_time = datetime.strptime(hudi_timestamp[:-3], "%Y%m%d%H%M%S")
        # Subtract one hour
        time_one_hour_back = parsed_time - timedelta(hours=num_of_hours)
        # Format it back to the Hudi timestamp format
        new_hudi_timestamp = time_one_hour_back.strftime("%Y%m%d%H%M%S") + hudi_timestamp[-3:]
        return new_hudi_timestamp
    
    except Exception as e:
        logging.error(f"Error while adding buffer to hudi commit time :{str(e)}")
        raise

def get_max_commit_time(source_df,hoodie_commit_time_col):
    max_commit_time= source_df.agg(F.max(hoodie_commit_time_col)).collect()[0][0]
    return max_commit_time
def update_watermark_with_latesttime(s3,raw_watermark_bucket,raw_watermark_file_key,source_table_name,max_commit_time):
    
    try:
        # Update the watermark for the specific table
        new_hudi_timestamp = add_buffer_to_hudi_commit_time(max_commit_time,1)
        update_watermark_file(s3,new_hudi_timestamp,raw_watermark_bucket,raw_watermark_file_key,source_table_name)
        return True
    except Exception as e:
        logging.error(f"Error while updating the watermark file:{str(e)}")
        raise
    
def get_postgres_connection(db_host, db_port, db_name, db_user, db_password):
    """
    Establish a connection to the PostgreSQL database using psycopg2.
    """
    try:
        connection = psycopg2.connect(
            host=db_host,
            database=db_name,
            user=db_user,
            password=db_password,
            port=db_port
        )
        logging.info("PostgreSQL connection established successfully")
        return connection
    except Exception as e:
        logging.error(f"Error connecting to PostgreSQL: {str(e)}")
        raise

    
def write_data_into_pg_stage(df,user_name,password,host,port,db,target_pg_schema,temp_table_name):
    
    try:
        df.write \
            .format("jdbc") \
            .option("url", f"jdbc:postgresql://{host}:{port}/{db}") \
            .option("dbtable",f"{target_pg_schema}.{temp_table_name}") \
            .option("user", user_name) \
            .option("password", password) \
            .mode("overwrite") \
            .save()
        logging.info(f"data successfully loaded into temperory table {target_pg_schema}.{temp_table_name}")
        return True
    except Exception as e:
        logging.error(f"An error occurred while loading data to temperory table {target_pg_schema}.{target_table_name} table : {str(e)} ")

def execute_upsert_query_into_target(connection, target_pg_schema, target_table_name, temp_table_name, primary_key_column):
    """
    Perform the upsert operation using a PostgreSQL query.
    """
    try:
        cursor = connection.cursor()
        upsert_query = f"""
            INSERT INTO {target_pg_schema}.{target_table_name} AS target
            SELECT DISTINCT "VIRTUAL_ID","VIN","TCU_ID","IMEI","TCU_METADATA_ICCID","TCU_METADATA_MAC","VEHICLEPROPERTIES_MODEL" FROM {temp_table_name}
            ON CONFLICT ("{primary_key_column}") DO UPDATE SET
                "VIN" = EXCLUDED."VIN",
                "TCU_ID" = EXCLUDED."TCU_ID",
                "VIRTUAL_ID" = EXCLUDED."VIRTUAL_ID",
                "IMEI" = EXCLUDED."IMEI",
                "TCU_METADATA_ICCID" = EXCLUDED."TCU_METADATA_ICCID",
                "TCU_METADATA_MAC" = EXCLUDED."TCU_METADATA_MAC",
                "VEHICLEPROPERTIES_MODEL" = EXCLUDED."VEHICLEPROPERTIES_MODEL"

        """
        cursor.execute(upsert_query)
        connection.commit()
        logging.info(f"Upsert operation completed for table {target_pg_schema}.{target_table_name}")
    except Exception as e:
        logging.error(f"Error executing upsert query: {str(e)}")
        raise
    finally:
        if cursor:
            cursor.close()

def standardize_columns(device_ledger, tcu):
    """
    Handles duplicate column names by renaming columns in the tcu DataFrame.
    """
    try:
        duplicate_columns = set(device_ledger.columns).intersection(set(tcu.columns)) - {"tcu_id"}
        for col_name in duplicate_columns:
            tcu = tcu.withColumnRenamed(col_name, f"{col_name}_tcu")
        return tcu
    except Exception as e:
        logging.error(f"Error normalizing column names: {str(e)}")
        traceback.print_exc()
        raise

def normalize_column_names(df):
            return df.toDF(*[col_name.upper() for col_name in df.columns])
        
def join_device_ledger_with_tcu(device_ledger, tcu):
    """
    Joins device_ledger with tcu on tcu_id.
    """
    try:
        vehicle_details = device_ledger.join(tcu, device_ledger["tcu_id"]==tcu["TCU_ID_tcu"], "inner")
        num_records = vehicle_details.count()
        logging.info(f"Joined device_ledger with tcu. Final row count: {num_records}")
        return vehicle_details,num_records
    except Exception as e:
        logging.error(f"Error joining device_ledger with tcu: {str(e)}")
        traceback.print_exc()
        raise
    
def main():
    
    try:
        start_time = datetime.now()
        logging.info(f"Job started at {start_time}")
        
        #read job parameters
        yaml_s3_bucket,yaml_file_key,job_name,job_run_id,source_table_name,audit_database = read_job_param()
        
        logging.info(f"job name : {job_name}")
        logging.info(f"source table name : {source_table_name}.{audit_database}.{yaml_file_key}")
        
        logging.info("job_name=%s", job_name+"/"+source_table_name)
        #initialize spark job
        spark = initialize_spark_session()
        
        #create an S3 client
        s3 = boto3.client('s3')

        # read necessary  parameters from yaml file
        target_table_name,sns_secret_name,watermark_bucket,watermark_file_key,audit_path,audit_table,\
        region_name,rds_secret_name,log_path,source_type,target_type,\
        device_ledger_path,tcu_path,target_pg_schema,temp_table_name,primary_key_column = read_yaml_file(s3,yaml_s3_bucket,yaml_file_key,source_table_name)
       
        secret_dict = fetch_postgres_credentials(rds_secret_name,region_name)
        logging.info("rds_secret_name loaded successfully.")
        db_host = secret_dict['host']
        db_port = secret_dict['port']
        db_name = secret_dict['database']
        db_user = secret_dict['user']
        db_password = secret_dict['password']
        logging.info("PostgresSQL credentials extracted and processed successfully.")
       
    except Exception as e:
        logging.error(f"Error in initial steps: {str(e)}")
        traceback.print_exc()
        raise
        
    
    try:
        year_partitioned=start_time.year
        month_partitioned=start_time.month
        #validate audit table
        is_validate = validate_audit_table_with_s3_partition(spark,sns_secret_name,start_time,audit_path,audit_path,source_table_name,target_table_name,job_name,region_name,year_partitioned,month_partitioned )

        if is_validate == False:
            logging.error("Job is being aborted due to concurrent execution.")
            return
       
        # Log audit
        log_audit(
                    spark,job_name,source_table_name,source_type,target_table_name,target_type,\
                    "Started",start_time,None,None,audit_path,audit_table,
                )
        #read watermark timestamp
        watermark_timestamp = get_watermark_timestamp(s3,watermark_bucket,watermark_file_key)
        
        exclude_columns = ['_hoodie_record_key', '_hoodie_commit_seqno','_hoodie_file_name', '_hoodie_partition_path', 
        '_hoodie_commit_time_land_cal','kafka_timestamp','key','partition','offset','_hoodie_commit_time_land_cal','topic', 'year', 'month', 'day', 'hour']
        # read data from landing table incrementally

        device_ledger = read_and_exclude(spark, device_ledger_path, watermark_timestamp, exclude_columns)
        logging.info(f"Read {device_ledger.count()} rows from device_ledger incrementally.")
            
        
        # Step 2: Extract distinct tcu_id values
        tcu_ids = extract_distinct_tcu_ids(device_ledger)
        
        # Step 3: Read filtered tcu data
        tcu = read_filtered_tcu_data(spark, tcu_path, tcu_ids,exclude_columns)
        if tcu is None:
            return device_ledger

        # Normalize column names in both DataFrames
        device_ledger = normalize_column_names(device_ledger)
        tcu = normalize_column_names(tcu)
        
        # Step 4: standardize column names to handle duplicates
        tcu = standardize_columns(device_ledger, tcu)
        # tcu  = read_and_exclude(spark, tcu_path, watermark_timestamp, exclude_columns)
        # source_df,num_records = read_source_table(spark,watermark_timestamp,source_hudi_table_path)
        
        # Step 5: Join device_ledger with tcu
        vehicle_details,num_records = join_device_ledger_with_tcu(device_ledger, tcu)

        
        # duplicate_columns = set(device_ledger.columns).intersection(set(tcu.columns))

        # # Rename duplicates in one DataFrame
        # for col_name in duplicate_columns:
        #     tcu = tcu.withColumnRenamed(col_name, f"{col_name}_tcu")
        # vehicle_details = device_ledger.join(tcu, device_ledger['tcu_id']==tcu['tcu_id_tcu'], how='inner')
        # num_records=vehicle_details.count()
        # logging.info(f"num records loading: {num_records}")

        max_commit_time=get_max_commit_time(device_ledger,'_HOODIE_COMMIT_TIME')
        
        logging.info(f"max_commit_time : {max_commit_time}")
        
        vehicle_details=vehicle_details.drop('_HOODIE_COMMIT_TIME','_HOODIE_COMMIT_TIME_tcu')
        
        vehicle_details.printSchema()
        if num_records > 0:
            write_data_into_pg_stage(vehicle_details,db_user,db_password,db_host,db_port,db_name,target_pg_schema,temp_table_name)
            logging.info(f"Data loaded successfully to {target_pg_schema}.{temp_table_name} table")
            
            # Connect to PostgreSQL
            connection = None
            try:
                connection = get_postgres_connection(db_host, db_port, db_name, db_user, db_password)
                
                execute_upsert_query_into_target(connection, target_pg_schema, target_table_name, temp_table_name, primary_key_column)
                
            finally:
                if connection:
                    connection.close()
                    logging.info("PostgreSQL connection closed")
                
                #update watermark file
            update_watermark_with_latesttime(s3,watermark_bucket,watermark_file_key,source_table_name,max_commit_time)
            
        #get cloudwatch details
        cloudwatch_url = get_cloudwatch_url(region_name, job_name, job_run_id)
        end_time = datetime.now()
        duration = (end_time - start_time).seconds
        
    
        # Log audit
        log_audit(
                spark,job_name,source_table_name,source_type,target_table_name,target_type,"Completed",start_time,end_time,\
                    num_records,audit_path,audit_table,
                )
        logging.info(f"Job completed successfully in {duration} seconds")
        
        log = {
            "status": "success",
            "job_name": job_name,
            "source_table": source_table_name,
            "target_table": target_table_name,
            "start_time": start_time.isoformat(),
            "end_time": end_time.isoformat(),
            "duration": duration,
            "num_records": num_records
        }
                    
    except Exception as e:
        logging.error("Job failed with error: %s", str(e))
        traceback.print_exc()
        end_time = datetime.now()
        duration = end_time - start_time
        logging.error(f"Job failed in {duration} seconds")
        #get cloudwatch details 
        cloudwatch_url = get_cloudwatch_url(region_name, job_name, job_run_id)
        log = {
                "status": "failure",
                "job_name": job_name,
                "source_table": source_table_name,
                "target_table": target_table_name,
                "start_time": start_time.isoformat(),
                "end_time": end_time.isoformat(),
                "duration": duration,
                "error": f"Error: {str(e)}\nTraceback: {traceback.format_exc()}"
            }
        
        # Log audit
        log_audit(
                spark,job_name,source_table_name,source_type,target_table_name,target_type,\
                "Failed",start_time,end_time,None,audit_path,audit_table,
                )
            
        log_message = "\n".join([f"{key}: {value}" for key, value in log.items()])
        message = f"Job -{job_name} failed. Transformation returned None.\n\n{log_message}.\n\nView the logs in CloudWatch:{cloudwatch_url}"
        subject=f"Job Failed : Job - {job_name}"
        send_sns_notification(subject, message, sns_secret_name,region_name)
        raise

    finally:
        final_log = log.copy() 
        yaml_params = {
        "table_name": source_table_name,
        "audit_table": audit_table, 
        "audit_path":audit_path,
        "yaml_s3_bucket": yaml_s3_bucket,
        "yaml_file_path": yaml_file_key,
        "target_table_name": target_table_name}

        final_log.update(yaml_params)
        dt = datetime.now()
        epoch_time = int(dt.timestamp() * 1000)
        s3 = boto3.client('s3', region_name='ap-south-1')
        s3.put_object(Bucket=watermark_bucket, Key=f'logs/{job_name}-{target_table_name}_{epoch_time}_logs.json', Body=json.dumps(final_log))
      
if __name__ == "__main__":
    main()
