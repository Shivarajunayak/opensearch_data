import sys
import logging
import boto3
import traceback
from datetime import datetime
from pyspark.sql import SparkSession, functions as F
from pyspark.sql.types import StructType,StructField,ArrayType,StringType,LongType,MapType
from awsglue.utils import getResolvedOptions
from pyspark.sql.functions import col

from hmcl_cv_common_utilities import (
    log_audit,
    load_yaml_config,
    validate_audit_table,
    send_sns_notification,
    get_cloudwatch_url,
    validate_audit_table_with_s3_partition)

logging.basicConfig(
    level=logging.INFO, format="%(asctime)s - %(name)s - %(levelname)s - %(message)s")

def initialize_spark_session():    
    try:
        spark = SparkSession.builder \
            .config('spark.serializer', 'org.apache.spark.serializer.KryoSerializer') \
            .config('spark.hudi.query.metadata.enable', 'true') \
            .config('spark.hadoop.hadoop.security.credential.provider.path', '') \
            .getOrCreate()
        return spark
    except Exception as e:
        logging.error(f"Error while initializing the spark Session: {str(e)}")
        traceback.print_exc()
        raise

def read_job_parameters():
    try:
        # Define arguments
        arguments = [
            "JOB_NAME",
            "yaml_s3_bucket",
            "yaml_file_key",
        ]
        # Get the arguments
        args = getResolvedOptions(sys.argv, arguments)
        job_name = args.get("JOB_NAME")
        job_run_id = args.get("JOB_RUN_ID")
        yaml_s3_bucket = args.get("yaml_s3_bucket")
        yaml_file_key = args.get("yaml_file_key")
        logging.info("Job parameters read successfully")
        return job_name,job_run_id,yaml_s3_bucket,yaml_file_key
    
    except Exception as e:
        logging.error(f"Error while reading job parameters: {str(e)}")
        traceback.print_exc()
        raise
  
def read_yaml_file(s3_client,yaml_s3_bucket,yaml_file_key):
    try:
        # Read YAML file from S3
        yaml_dict = load_yaml_config(s3_client,yaml_s3_bucket,yaml_file_key)
        brokers = yaml_dict["brokers"]
        kafka_topic = yaml_dict["kafka_topic"]
        offset = yaml_dict["offset"] 
        sns_secret_name = yaml_dict["sns_secret_name"]
        region = yaml_dict["region"]
        hudi_table_name = yaml_dict["hudi_table_name"]
        hudi_table_path = yaml_dict["hudi_table_path"]
        hudi_database = yaml_dict["hudi_database"]
        audit_table = yaml_dict["audit_table"]
        audit_path = yaml_dict["audit_path"]
        audit_database = yaml_dict["audit_database"]
        source_type = yaml_dict["source_type"]
        target_type = yaml_dict["target_type"]
        check_point_bucket = yaml_dict["check_point_bucket"]
        check_point_path = yaml_dict["check_point_path"]
        check_point_full_path = "s3://"+ check_point_bucket + "/" +check_point_path
        
        logging.info("yaml parameters read successfully")
        return brokers, kafka_topic,offset,sns_secret_name,region,\
        hudi_table_name,hudi_table_path,hudi_database,audit_table,audit_path,audit_database,\
        source_type,target_type,check_point_full_path
    except Exception as e:    
        logging.error(f"Error while reading yaml parameters: {str(e)}")
        traceback.print_exc()
        raise
    
def get_schema():
    
    ## define the json schema
    schema = StructType(
        [
            StructField("campaignName", StringType(), True),
            StructField("vehicleName", StringType(), True),
            StructField("eventId", StringType(), True),
            StructField("msgId", StringType(), True),
            StructField("collectionEventTime", LongType(), True),
            StructField("dimensions", MapType(StringType(), StringType()), True),
            StructField("signals",MapType(StringType(),ArrayType(StructType(
                        [
                            StructField("value", StringType(), True),
                            StructField("time", LongType(), True),
                            StructField("dataType", StringType(), True),
                        ]),True,),True,),True,),])
    return schema

def read_kafka_topic(spark,brokers,kafka_topic,offset):
    try :
        df_kafka = (
            spark.readStream.format("kafka")
            .option("kafka.bootstrap.servers", brokers)
            .option("subscribe", kafka_topic)
            .option("failOnDataLoss", "false")
            .option("kafka.security.protocol", "SASL_SSL")
            .option("kafka.sasl.mechanism", "AWS_MSK_IAM")
            .option(
                "kafka.sasl.jaas.config",
                "software.amazon.msk.auth.iam.IAMLoginModule required;",
            )
            .option(
                "kafka.sasl.client.callback.handler.class",
                "software.amazon.msk.auth.iam.IAMClientCallbackHandler",
            )
            .option("startingOffsets", offset)
            .load()
        )
        
        return df_kafka
    except Exception as e:    
        logging.error(f"Error while reading kafka topic: {str(e)}")
        traceback.print_exc()
        raise
    
def load_batch_into_hudi_table(df,table_name,database,s3_output_path):
    
    try:
        hudi_options = {
                "hoodie.table.name": table_name,
                "hoodie.datasource.write.operation": "upsert",
                "hoodie.datasource.write.partitionpath.field": "tenantId,year,month,day,hour",
                "hoodie.datasource.write.recordkey.field": "vid,eventId",
                "hoodie.datasource.write.precombine.field": "collectionEventTime",
                "hoodie.datasource.hive_sync.enable": "true",
                "hoodie.datasource.hive_sync.database": database,
                "hoodie.datasource.hive_sync.table": table_name,
                "hoodie.datasource.hive_sync.use_jdbc": "false",
                "hoodie.datasource.hive_sync.mode": "hms",
                "hoodie.datasource.hive_sync.support_timestamp": "true",
                "path": s3_output_path,
                "hoodie.parquet.max.file.size": "134217728",
            }
        df.write.format("hudi").options(**hudi_options).mode("append").save()
        logging.info("Data successfully written to Hudi table")
        
    except Exception as e:
        logging.error(f"Error while loading data into Hudi Table: {str(e)}")
        traceback.print_exc()
        raise
    
def process_batch(df_kafka,spark,job_name,kafka_topic,table_name,database,s3_output_path,source_type,target_type,start_time,audit_path,audit_table):
    try:
        num_records = df_kafka.count()
        logging.info(f"dataframe count:{num_records}")
        if num_records > 0:
            df_kafka = df_kafka.select("value")
            json_schema = get_schema()
            df_kafka=df_kafka.withColumn("value", F.from_json(df_kafka["value"],json_schema))
            flattened_columns = [F.col("value." + key).alias(key) for key in df_kafka.select("value.*").columns]
            
            df_kafka = df_kafka.select(*flattened_columns)

            dim_flattened_df = df_kafka.select(
                "campaignName",
                "vehicleName",
                "eventId",
                "msgId",
                "collectionEventTime",
                col("dimensions.`hmcl.tenantId`").alias("tenantId"),
                col("dimensions.`hmcl.virtualId`").alias("vid"),
                col("dimensions.`hmcl.vds`").alias("vds"),
                col("dimensions.`hmcl.b2bClientId`").alias("b2bClientId"),
                "signals"
            )

            dim_flattened_df = dim_flattened_df.withColumn("date", F.from_unixtime((col("collectionEventTime") / 1000).cast("long"))) \
                    .withColumn("day", F.expr("day(date)")) \
                    .withColumn("month", F.expr("month(date)")) \
                    .withColumn("year", F.expr("year(date)")) \
                    .withColumn("hour", F.hour(col("date")))
            
            # dim_flattened_df.show(n=10)
            hudi_required_cols = ["vid", "eventId", "collectionEventTime", "tenantId", "year", "month", "day", "hour"]
            final_df_to_write = dim_flattened_df.dropna(subset=hudi_required_cols)

            if final_df_to_write.count() < dim_flattened_df.count():
                 logging.warning(f"Dropped {dim_flattened_df.count() - final_df_to_write.count()} records due to NULLs in Hudi key fields.")

            if final_df_to_write.count() > 0:
                logging.info(f"Writing {final_df_to_write.count()} cleaned records to Hudi.")
                load_batch_into_hudi_table(final_df_to_write, table_name, database, s3_output_path)
            else:
                logging.warning("No valid records to write in this batch after cleaning.")
               
        end_time = datetime.now()
        log_audit(
                spark,job_name,kafka_topic,source_type,table_name,target_type,"Completed",start_time,end_time,\
                    num_records,audit_path,audit_table)
        
        logging.info(f"load completed")
    except Exception as e:
        logging.error(f"Error batch load : {str(e)}")
        traceback.print_exc()
        raise

def load_metrics_into_hudi_table(df_kafka,spark,job_name,kafka_topic,table_name,database,s3_output_path,source_type,\
                                target_type,start_time,audit_path,audit_table,check_point_path):
    try:
        query = df_kafka.writeStream \
            .foreachBatch(lambda df, _: process_batch(df,spark,job_name,kafka_topic,table_name,database,\
                            s3_output_path,source_type,target_type,start_time,audit_path,audit_table))  \
            .option("checkpointLocation", check_point_path) \
            .outputMode("update") \
            .trigger(once=True) \
            .start()
        query.awaitTermination()
    except Exception as e:
        logging.error(f"Error while kafka write operation: {str(e)}")
        traceback.print_exc()
        raise

def find_and_show_duplicates(df, key_cols):
    logging.info(f"Checking for duplicates based on key columns: {key_cols}")

    # Group by the key columns and count occurrences
    duplicate_keys_df = df.groupBy(key_cols).count().where(F.col("count") > 1)
    
    num_duplicate_keys = duplicate_keys_df.count()

    if num_duplicate_keys > 0:
        logging.warning(f"Found {num_duplicate_keys} key combinations with duplicate records.")
        
        # Join back to the original DataFrame to show the full duplicate rows
        all_duplicate_rows_df = df.join(
            F.broadcast(duplicate_keys_df),  # Use broadcast for efficiency if duplicate_keys_df is small
            on=key_cols,
            how="inner"
        ).orderBy(key_cols)

        logging.warning("Showing the full rows that contain duplicate data:")
        all_duplicate_rows_df.show(n=50, truncate=False)
        
    else:
        logging.info("No duplicate records found based on the provided key columns.")

def main():
    """
    This function extracts the data from MSK loads to hudi
    """
    try:
        start_time = datetime.now()
        logging.info(f"Job started at {start_time}")
        spark = initialize_spark_session()
        job_name,job_run_id,yaml_s3_bucket,yaml_file_key = read_job_parameters()
        s3_client = boto3.client('s3')
        brokers, kafka_topic,offset,sns_secret_name,region_name,\
        hudi_table_name,hudi_table_path,database,audit_table,audit_path,audit_database,\
        source_type,target_type,check_point_path = read_yaml_file(s3_client,yaml_s3_bucket,yaml_file_key)
        logging.info("job_name=%s", job_name)
    except Exception as e:
        logging.error(f"Error in initial steps: {str(e)}")
        traceback.print_exc()
        raise
    
    
    try:
        year_partitioned=start_time.year
        month_partitioned=start_time.month
        #Validate the audit table to process the job based on job_status
        is_validate = validate_audit_table_with_s3_partition(spark,sns_secret_name,start_time,audit_path,audit_table,kafka_topic,hudi_table_name,job_name,region_name,year_partitioned,month_partitioned)

        if is_validate == False:
            return
        
        log_audit(spark,job_name,kafka_topic,source_type,hudi_table_name,target_type,\
                    "Started",start_time,None,None,audit_path,audit_table)
        df_kafka = read_kafka_topic(spark,brokers,kafka_topic,offset)        
        df_kafka = df_kafka.selectExpr("CAST(value AS STRING)")
        load_metrics_into_hudi_table(df_kafka,spark,job_name,kafka_topic,hudi_table_name,database,hudi_table_path,source_type,target_type,\
            start_time,audit_path,audit_table,check_point_path)        
        
        #get cloudwatch details
        cloudwatch_url = get_cloudwatch_url(region_name, job_name, job_run_id)
        end_time = datetime.now()
        duration = (end_time - start_time).seconds
        
        logging.info(f"Job completed successfully in {duration} seconds")
        
        log = {
            "status": "success",
            "job_name": job_name,
            "source_table": kafka_topic,
            "target_table": hudi_table_name,
            "start_time": start_time.isoformat(),
            "end_time": end_time.isoformat(),
            "duration": duration,
        }
    except Exception as e:
        logging.error("Job failed with error: %s", str(e))
        traceback.print_exc()
        end_time = datetime.now()
        duration = end_time - start_time
        logging.error(f"Job failed in {duration} seconds")
        #get cloudwatch details 
        
        cloudwatch_url = get_cloudwatch_url(region_name, job_name, job_run_id)
        log = {
                "status": "failure",
                "job_name": job_name,
                "source_table": kafka_topic,
                "target_table": hudi_table_name,
                "start_time": start_time.isoformat(),
                "end_time": end_time.isoformat(),
                "duration": duration,
                "error": f"Error: {str(e)}\nTraceback: {traceback.format_exc()}"
            }
        
        # Log audit
        log_audit(
                spark,job_name,kafka_topic,source_type,hudi_table_name,target_type,\
                "Failed",start_time,end_time,None,audit_path,audit_table,
                )
            
        log_message = "\n".join([f"{key}: {value}" for key, value in log.items()])
        message = f"Job -{job_name} failed. Transformation returned None.\n\n{log_message}.\n\nView the logs in CloudWatch:{cloudwatch_url}"
        subject=f"Job Failed : Job - {job_name}"
        send_sns_notification(subject, message, sns_secret_name,region_name)
        raise

if __name__ == "__main__":
    main()
