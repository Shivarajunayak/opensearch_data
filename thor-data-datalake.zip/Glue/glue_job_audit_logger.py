"""
This module performs audit logging for glue job

It has the reusable function called log_audit which can be called from glue job for which
stats need be logged in to hudi table by passign required attributes to log in the table

Usage:
    log_audit(spark, job_name,source,source_type,target,target_type,job_status, start_time, \
                end_time, records_processed, audit_path,audit_table)
"""

# pylint: disable=import-error

from pyspark.sql.types import (
    IntegerType,
    StringType,
    StructField,
    StructType,
    TimestampType,
)
import boto3
import time

from pyspark.sql import functions as F

athena_client = boto3.client("athena")


def execute_athena_query(query, database, s3_output):
    """
    This method to execute athen query
    """
    # Start the query execution
    response = athena_client.start_query_execution(
        QueryString=query,
        QueryExecutionContext={"Database": database},
        ResultConfiguration={"OutputLocation": s3_output},
    )

    # Get the execution ID
    query_execution_id = response["QueryExecutionId"]

    # Wait for the query to finish
    while True:
        query_status = athena_client.get_query_execution(
            QueryExecutionId=query_execution_id
        )
        status = query_status["QueryExecution"]["Status"]["State"]

        if status in ["SUCCEEDED", "FAILED", "CANCELLED"]:
            break

        print("Query is still running...")
        time.sleep(5)

    # Check the final status
    if status == "SUCCEEDED":
        print("Query succeeded!")
    else:
        print(f"Query failed with status: {status}")


def log_audit(
    spark,
    job_name,
    source,
    source_type,
    target,
    target_type,
    job_status,
    start_time,
    end_time,
    records_processed,
    audit_path,
    audit_table,
):
    """
    Records an audit log entry for a data processing operation by glue job.

    This method appends an entry to the audit log containing information about
    the job, source ,source_type,target,target type of job, job start time,
    job end time , records processed by job
    """
    job_id = job_name + "_" + target + "_" + str(start_time) + "_" + job_status
    schema = StructType(
        [
            StructField("job_id", StringType(), True),
            StructField("job_name", StringType(), True),
            StructField("source", StringType(), True),
            StructField("source_type", StringType(), True),
            StructField("target", StringType(), True),
            StructField("target_type", StringType(), True),
            StructField("job_status", StringType(), True),
            StructField("start_time", TimestampType(), True),
            StructField("end_time", TimestampType(), True),
            StructField("records_processed", IntegerType(), True),
        ]
    )
    audit_log = spark.createDataFrame(
        [
            (
                job_id,
                job_name,
                source,
                source_type,
                target,
                target_type,
                job_status,
                start_time,
                end_time,
                records_processed,
            )
        ],
        schema,
    )

    audit_log = audit_log.fillna("NULL")

    audit_log = audit_log.withColumn("year", F.year(F.col("start_time"))).withColumn(
        "month", F.month(F.col("start_time"))
    )

    database = "control"
    bucket_name = audit_path.split("/")[2]
    s3_output = "s3://" + bucket_name + "/athenaresults/"

    print(f"Table {audit_table} does not exist. Creating table...")
    create_table_sql = f"""CREATE EXTERNAL TABLE IF NOT EXISTS {database}.{audit_table} (
                    job_id string,
                    job_name string,
                    source string,
                    source_type string,
                    target_type string,
                    job_status string,
                    start_time timestamp,
                    end_time timestamp,
                    records_processed int
                    )
                    PARTITIONED BY (
                        target STRING,
                        year STRING,
                        month string
                    )
                    STORED AS PARQUET
                    LOCATION '{audit_path}'
                    TBLPROPERTIES (
                        'parquet.compress'='SNAPPY' 
                    )
                    """

    execute_athena_query(create_table_sql, database, s3_output)

    audit_log.write.partitionBy("target", "year", "month").parquet(
        audit_path, mode="append"
    )

    create_table_sql = f""" MSCK REPAIR TABLE {database}.{audit_table}; """
    execute_athena_query(create_table_sql, database, s3_output)
