import json
import sys
from pyspark.sql import Window
from pyspark.sql import SparkSession
from awsglue.dynamicframe import DynamicFrame
from awsglue.context import GlueContext
from functools import reduce
from pyspark.sql import functions as F
from pyspark.sql.functions import col
from awsglue.utils import getResolvedOptions
import boto3
import snowflake.connector
import logging
from pyspark.sql.types import StructType,StructField,StringType,LongType,DoubleType
from datetime import datetime, timedelta
import traceback
from hmcl_cv_common_utilities import (
    log_audit,
    load_yaml_config,
    initialize_spark_session,
    send_sns_notification,
    get_cloudwatch_url,
    get_watermark_timestamp,
    update_watermark_file,
    validate_audit_table_with_s3_partition
    )

logging.basicConfig(
    level=logging.INFO, format="%(asctime)s - %(name)s - %(levelname)s - %(message)s"
)


def fetch_opensearch_credentials(opensearch_secret_name, region_name):
    
    try:
        session = boto3.session.Session()
        client = session.client(service_name="secretsmanager", region_name = region_name)
        get_secret_value_response = client.get_secret_value(SecretId = opensearch_secret_name)
        secret = get_secret_value_response["SecretString"]
        logging.info("Opensearch credentials fetched successfully.")
        return json.loads(secret)
    except Exception as e:
        logging.error(
            f"Error fetching Opensearch credentials from Secrets Manager: {e}"
        )
        traceback.print_exc()
        raise
   
    
def read_job_parameters():
    try:
        # Define arguments
        arguments = [
            "JOB_NAME",
            "yaml_s3_bucket",
            "yaml_file_key",
        ]
        # Get the arguments
        args = getResolvedOptions(sys.argv, arguments)
        job_name = args.get("JOB_NAME")
        job_run_id = args.get("JOB_RUN_ID")
        yaml_s3_bucket = args.get("yaml_s3_bucket")
        yaml_file_key = args.get("yaml_file_key")
        logging.info("Job parameters read successfully")
        return job_name,job_run_id,yaml_s3_bucket,yaml_file_key
    
    except Exception as e:
        logging.error(f"Error while reading job parameters: {str(e)}")
        traceback.print_exc()
        raise
    
def read_yaml_file(s3_client,yaml_s3_bucket,yaml_file_key):
    try:
        # Read YAML file from S3
        yaml_dict = load_yaml_config(s3_client,yaml_s3_bucket,yaml_file_key)
        device_ledger_hudi_path = yaml_dict["device_ledger_hudi_path"]
        indexs_info = yaml_dict["indexs_info"]
        target_database = yaml_dict["hudi_table_database"]
        watermark_bucket = yaml_dict["watermark_bucket"]
        recordkey = yaml_dict["recordkey"]
        partition_field = yaml_dict["partition_field"]
        audit_table = yaml_dict["audit_table"]
        sns_secret_name = yaml_dict["sns_secret_name"]
        audit_path = yaml_dict["audit_path"]
        source_type = yaml_dict["source_type"]
        target_type = yaml_dict["target_type"]
        region_name = yaml_dict["region_name"]
        snowflake_secret_name = yaml_dict["snowflake_secret_name"]
        opensearch_connection_name = yaml_dict["opensearch_connection_name"]
        stage_table = yaml_dict["stage_table"]
        snowflake_target_table = yaml_dict["snowflake_target_table"]
        
        logging.info("yaml parameters read successfully")
        
        return device_ledger_hudi_path,indexs_info,watermark_bucket,\
            target_database,opensearch_connection_name,\
            recordkey,partition_field,audit_table,\
            sns_secret_name,audit_path,source_type,target_type,region_name,\
            snowflake_secret_name,stage_table,snowflake_target_table
    except Exception as e:
        logging.error(f"Error while reading yaml parameters: {str(e)}")
        traceback.print_exc()
        raise
    
def fetch_snowflake_credentials(secret_name):
    try:
        client = boto3.client('secretsmanager')
        response = client.get_secret_value(SecretId=secret_name)
        secret = json.loads(response['SecretString'])
        return secret
    except Exception as e:
        logging.error(f"Error while fetching snowflake credentials: {str(e)}")
        traceback.print_exc()
        raise   
     
def get_snowflake_connection(sfUser,sfPassword,sfURL):
    """
    Establish and return a Snowflake connection.
    """
    try:
        conn = snowflake.connector.connect(
        user=sfUser,
        password=sfPassword,
        account = sfURL.split('//')[1].split('.snowflakecomputing.com')[0]
    )
        logging.info("Snowflake connection established.")
        return conn
    except Exception as e:
        logging.error(f"Error establishing Snowflake connection: {str(e)}")
        traceback.print_exc()
        raise
    
def get_snowflake_options(secret_dict):
    """
    Create a dictionary of Snowflake options for Spark DataFrame writes.
    """
    return {
        "sfURL": secret_dict['url'],
        "sfDatabase": secret_dict['database'],
        "sfSchema": secret_dict['schema'],
        "sfWarehouse": secret_dict['warehouse'],
        "sfRole": secret_dict['role'],
        "sfUser": secret_dict['username'],
        "sfPassword": secret_dict['password']
    }

def load_data_into_snowflake_stage(df,snowflake_options,stage_table):
    try:
        # Write the DataFrame to a temporary Snowflake table
        df.write.format("snowflake") \
            .options(**snowflake_options) \
            .option("dbtable", stage_table) \
            .mode("overwrite") \
            .save()
    except Exception as e:
        logging.error(f"Error while loading data into snowflake stage: {str(e)}")
        traceback.print_exc()
        raise

def execute_merge_query(conn,query):
    """Execute the Snowflake MERGE query."""
    try:
        cursor = conn.cursor()
        cursor.execute(query)
    finally:
        cursor.close()
        conn.close()
def prepare_merge_query(columns,target_table,stage_table):
    
    
    update_col = []
    insert_col = []
    values_col = []
    for col_ in columns:
        update_col.append(f"target.{col_} = source.{col_}")
        insert_col.append(col_)
        values_col.append(f"source.{col_}")
        
    update_col_str = ','.join(update_col)
    insert_col_str = ','.join(insert_col)
    values_col_str = ','.join(values_col)
    
    merge_query = f"""
            MERGE INTO {target_table} AS target
            USING {stage_table} AS source
            ON target.vid = source.vid
            WHEN MATCHED THEN
                UPDATE SET
                    {update_col_str}
            WHEN NOT MATCHED THEN
                INSERT ({insert_col_str})
                VALUES ({values_col_str})
            """
    logging.info(f"MERGE QUERY {merge_query}")
    return merge_query    
    

def load_df_into_snoflake_table(source_df,snowflake_secret_name,stage_table,target_table,columns):
    try: 
    
        secret_dict = fetch_snowflake_credentials(snowflake_secret_name)
        logging.info("Snowflake credentials loaded successfully.")
        snowflake_options = get_snowflake_options(secret_dict)
        
        sfURL = snowflake_options["sfURL"]
        sfUser = snowflake_options["sfUser"]
        sfPassword = snowflake_options["sfPassword"] 
        
        conn = get_snowflake_connection(sfUser,sfPassword,sfURL)
        

        load_data_into_snowflake_stage(source_df,snowflake_options,stage_table)
        
        merge_query = prepare_merge_query(columns,target_table,stage_table)
        # Execute the Merge Query
        execute_merge_query(conn, merge_query)
    
    except Exception as e:
        logging.error(f"Error while loading data into target snowflake table: {str(e)}")
        traceback.print_exc()
        raise
    
    

def load_df_into_target_table(source_df,num_records,target_table_name,target_database,target_hudi_table_path,recordkey,partition_field):
    """
    This function loads  data into raw
    """
    try:
        logging.info(f"PARTITION VALUES  (partition_field) in main table load: {partition_field}")
        
        hudi_options = {
            "hoodie.table.name": target_table_name,
            "hoodie.datasource.write.operation": "insert",
            "hoodie.datasource.write.partitionpath.field": partition_field,
            "hoodie.datasource.write.recordkey.field": recordkey,
            "hoodie.datasource.hive_sync.enable": "true",
            "hoodie.datasource.hive_sync.database": target_database,
            "hoodie.datasource.hive_sync.table": target_table_name,
            "hoodie.datasource.hive_sync.use_jdbc": "false",
            "hoodie.datasource.hive_sync.mode": "hms",
            "hoodie.datasource.hive_sync.support_timestamp": "true",
            "path": target_hudi_table_path,
            "hoodie.parquet.max.file.size": "134217728",
        }
        
        source_df.write.format("org.apache.hudi").options(**hudi_options).mode(
            "append"
        ).save()
    
        logging.info(f"Data loaded successfully into {target_table_name} table,\
            no.of processed records count: {num_records}")
        return True
    except Exception as e:
        logging.error(f"Error while loading the data into table:{target_table_name}, {str(e)}")
        traceback.print_exc()
        raise


def get_query(watermark_timestamp):
    
    filter_query = {
            "query": {
                "range": {
                "timestamp": {
                    "gt": watermark_timestamp
                }
                }
            }
            }

    filter_query_json = json.dumps(filter_query)
    return filter_query_json



def read_opensearch(glue_context, resource, connection_name, filter_query_json=None):
    """
    Method to read opensearch source
    """
    try:
        source_data = glue_context.create_dynamic_frame.from_options(
            connection_type="opensearch",
            connection_options={
                "connectionName": connection_name,
                "opensearch.port": 443,
                "opensearch.resource": resource,
                "opensearch.query": filter_query_json,
                "pushdown": "true",
            },
        ).toDF()

        return source_data
    except Exception as e:
        logging.error("Error happened while reading data from openasearch: %s", str(e))
        logging.error(traceback.format_exc())
        raise

def read_source_tables(spark,source_hudi_table_path):
    try:
        # Read the Hudi table incrementally
        devie_ledger_df = spark.read.format("hudi").load(source_hudi_table_path)
    
        logging.info(f"data read successfully from landing, records in raw :{devie_ledger_df.count()}")
        return devie_ledger_df
    except Exception as e:
        logging.error(f"Error while reading the data from RAW:{str(e)}")
        traceback.print_exc()
        raise   
     
def union_dfs(df1, df2):
    return df1.union(df2)
    
    
def main():
    try:
        
        start_time = datetime.now()
        logging.info(f"Job started at {start_time}")
        
        spark=initialize_spark_session()
        job_name,job_run_id,yaml_s3_bucket,yaml_file_key =  read_job_parameters()
        
        s3_client = boto3.client('s3')
        source_os_index = "vehicle-status-opensearch"
        target_table_name = "vehicle-status-hudi"
        
        device_ledger_hudi_path,indexs_info,watermark_bucket,\
            target_database,opensearch_connection_name,\
            recordkey,partition_field,audit_table,\
            sns_secret_name,audit_path,source_type,target_type,region_name,\
            snowflake_secret_name,stage_table,snowflake_target_table = read_yaml_file(s3_client,yaml_s3_bucket,yaml_file_key)
        logging.info("job_name=%s", job_name)
        
    except Exception as e:
        logging.error(f"Error in initial steps: {str(e)}")
        traceback.print_exc()
        raise
    
    try:
        
        year_partitioned=start_time.year
        month_partitioned=start_time.month
        is_validate = validate_audit_table_with_s3_partition(spark,sns_secret_name,start_time,audit_path,audit_table,source_os_index,target_table_name,job_name,region_name,year_partitioned,month_partitioned)
        
        if is_validate == False:
            return
        
        log_audit(
                    spark,job_name,source_os_index,source_type,target_table_name,target_type,\
                    "Started",start_time,None,None,audit_path,audit_table)
        
        glueContext = GlueContext(spark.sparkContext)
        device_ledger_df = read_source_tables(spark,device_ledger_hudi_path)
        device_ledger_df = device_ledger_df.select(col("virtual_id").alias("vid"),col("tcu_id").alias("clientId"),col("tenant_id"))
        total_processed_record_count = 0
        
        df_list =[]
        
        for index_name,details  in indexs_info.items():
            logging.info(f"item details :{indexs_info.items()}")
            logging.info(f"Index name :{index_name}")
            logging.info(f"details  :{details}")
            snowflake_columns = details['columns']
            watermark_key = details['watermark_file']
            target_table = details['target_table_name']
            target_hudi_table_path = details['target_table_path']
            
            
            watermark_timestamp = get_watermark_timestamp(s3_client,watermark_bucket,watermark_key)
            filter_query_json = get_query(watermark_timestamp) 
            source_df  = read_opensearch(glueContext, index_name, opensearch_connection_name, filter_query_json)
            
            record_count = source_df.count()
            if record_count > 0:
                
                joined_df = source_df.join(device_ledger_df, on ="clientId",how = "left")
                joined_df = joined_df.withColumn("date",  F.to_date(F.from_unixtime((col("timestamp") / 1000).cast("long"))))
                
                joined_df = joined_df.withColumn("year", F.year("date")) \
                .withColumn("month", F.month("date")) \
                .withColumn("day",F.dayofmonth("date"))
                
                joined_df = joined_df.withColumn("timestampIST",F.expr("from_unixtime((timestamp / 1000) + 19800, 'yyyy-MM-dd HH:mm:ss')"))
                
                joined_df = joined_df.filter(col("vid").isNotNull())
                
                num_records = joined_df.count()
                ## Load to Hudi table
                if num_records > 0:
                    load_df_into_target_table(joined_df,num_records,target_table,target_database,target_hudi_table_path,recordkey,partition_field)
                    max_commit_time = source_df.agg(F.max(col("timestamp"))).collect()[0][0]
                    logging.info(f"MAX TIMESTAMP FROM SOURCE : {max_commit_time}")
                    update_watermark_file(s3_client,max_commit_time,watermark_bucket,watermark_key,index_name)
                    if "connectionfail" not in index_name:
                        report_df = joined_df.select(col("vid"),col("clientId").alias("tcu_id"),col("timestamp"),col("timestampIST"),col("eventType"))
                        df_list.append(report_df)
                        
                total_processed_record_count += record_count
                
        if df_list:
            result_df = reduce(union_dfs, df_list)
            window_spec = Window.partitionBy("vid").orderBy(col("timestamp").desc())
            ranked_df = result_df.withColumn("row_num", F.row_number().over(window_spec))
            
            # Filter to only keep the row with the max timestamp for each vid
            result_df = ranked_df.filter(col("row_num") == 1).select(
                col("vid"),
                col("tcu_id"),
                col("timestampIST"),
                col("eventType")
            )
            transformed_df = result_df.withColumn(
                "eventType",
                F.when(col("eventType") == "connected", "active")
                .when(col("eventType") == "disconnected", "inactive")
                .otherwise(col("eventType")) 
                )
            
            transformed_df = transformed_df.select(col("vid"),col("tcu_id"),col("timestampIST").alias("last_connect"),col("eventType").alias("active_inactive"))
            load_df_into_snoflake_table(transformed_df,snowflake_secret_name,stage_table,snowflake_target_table,["vid","tcu_id","last_connect","active_inactive"])
        #get cloudwatch details
        cloudwatch_url = get_cloudwatch_url(region_name, job_name, job_run_id)
        end_time = datetime.now()
        duration = (end_time - start_time).seconds
        
        num_records = total_processed_record_count
        # Log audit
        log_audit(
                spark,job_name,source_os_index,source_type,target_table_name,target_type,"Completed",start_time,end_time,\
                    num_records,audit_path,audit_table,
                )
        logging.info(f"Job completed successfully in {duration} seconds")
        
        log = {
            "status": "success",
            "job_name": job_name,
            "source_table": source_os_index,
            "target_table": target_table_name,
            "start_time": start_time.isoformat(),
            "end_time": end_time.isoformat(),
            "duration": duration,
            "num_records": num_records
        }
                    
    except Exception as e:
        logging.error("Job failed with error: %s", str(e))
        traceback.print_exc()
        end_time = datetime.now()
        duration = end_time - start_time
        logging.error(f"Job failed in {duration} seconds")
        #get cloudwatch details 
        cloudwatch_url = get_cloudwatch_url(region_name, job_name, job_run_id)
        log = {
                "status": "failure",
                "job_name": job_name,
                "source_table": source_os_index,
                "target_table": target_table_name,
                "start_time": start_time.isoformat(),
                "end_time": end_time.isoformat(),
                "duration": duration,
                "error": f"Error: {str(e)}\nTraceback: {traceback.format_exc()}"
            }
        
        # Log audit
        log_audit(
                spark,job_name,source_os_index,source_type,target_table_name,target_type,\
                "Failed",start_time,end_time,None,audit_path,audit_table,
                )
            
        log_message = "\n".join([f"{key}: {value}" for key, value in log.items()])
        message = f"Job -{job_name} failed. Transformation returned None.\n\n{log_message}.\n\nView the logs in CloudWatch:{cloudwatch_url}"
        subject= f"Job Failed : Job - {job_name}"
        send_sns_notification(subject, message, sns_secret_name,region_name)
        raise
    
if __name__ == "__main__":
    main()
