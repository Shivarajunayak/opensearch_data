import sys
import logging
import json
import traceback
from awsglue.utils import getResolvedOptions
from hmcl_cv_common_utilities import execute_athena_query

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


def main():

    try:
        # Define arguments
        arguments = [
            "JOB_NAME",
            "database_name",
            "table_name",
            "year",
            "target_tables",
            "audit_path",
        ]
        # Get the arguments
        args = getResolvedOptions(sys.argv, arguments)
        job_name = args.get("JOB_NAME")
        database_name = args.get("database_name")
        table_name = args.get("table_name")
        year = args.get("year")
        target_tables = args.get("target_tables")
        audit_path = args.get("audit_path")
        month_range_start = args.get("month_range_start", 1)
        month_range_end = args.get("month_range_end", 12)
        bucket_name = audit_path.split("/")[2]
        s3_output = "s3://" + bucket_name + "/athenaresults/"

        target_tables = json.loads(target_tables)

        for target in target_tables:
            for month in range(month_range_start, month_range_end + 1):
                query = f"""
                ALTER TABLE {database_name}.{table_name}
                ADD PARTITION (target='{target}', year='{year}', month='{month}')
                LOCATION '{audit_path}/target={target}/year={year}/month={month}/'
                """

                status = execute_athena_query(query, database_name, s3_output)
                if status == "SUCCEEDED":

                    logger.info(
                        f"Partion added for the table {table_name} with partion values {target},{year},{month}"
                    )
                else:
                    logger.info(
                        f"Partion creation failed for the table {table_name} with partion values {target},{year},{month}. check if the partitions already exists"
                    )

    except Exception as e:
        logger.error(
            "An error occurred in main method of addong partions to catalog table : %s",
            str(e),
        )
        logger.error("Stack trace: %s", traceback.format_exc())
        raise


if __name__ == "__main__":
    main()
