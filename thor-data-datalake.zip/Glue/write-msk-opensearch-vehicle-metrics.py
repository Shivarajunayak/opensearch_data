import sys
import boto3
from pyspark.sql import functions as F
from pyspark.sql.window import Window
from awsglue.utils import getResolvedOptions
from pyspark.sql.types import StructType,StructField,StringType,LongType
import logging
from pyspark.sql.functions import col
import traceback
from datetime import datetime, timezone, timedelta

from hmcl_cv_common_utilities import (
    log_audit,
    load_yaml_config,
    send_sns_notification,
    get_cloudwatch_url,
    get_watermark_timestamp,
    initialize_spark_session,
    update_watermark_file,
    validate_audit_table_with_s3_partition
    )

logging.basicConfig(
    level=logging.INFO, format="%(asctime)s - %(name)s - %(levelname)s - %(message)s"
)

def read_job_parameters():
    try:
        # Define arguments
        arguments = [
            "JOB_NAME",
            "yaml_s3_bucket",
            "yaml_file_key",
        ]
        # Get the arguments
        args = getResolvedOptions(sys.argv, arguments)
        job_name = args.get("JOB_NAME")
        job_run_id = args.get("JOB_RUN_ID")
        yaml_s3_bucket = args.get("yaml_s3_bucket")
        yaml_file_key = args.get("yaml_file_key")
        logging.info("Job parameters read successfully")
        return job_name,job_run_id,yaml_s3_bucket,yaml_file_key
    
    except Exception as e:
        logging.error(f"Error while reading job parameters: {str(e)}")
        traceback.print_exc()
        raise
    
def read_yaml_file(s3_client,yaml_s3_bucket,yaml_file_key):
    try:
        # Read YAML file from S3
        yaml_dict = load_yaml_config(s3_client,yaml_s3_bucket,yaml_file_key)
        audit_table = yaml_dict["audit_table"]
        audit_path = yaml_dict["audit_path"]
        region_name = yaml_dict["region"]
        source_type = yaml_dict["source_type"]
        target_type = yaml_dict["target_type"]
        sns_secret_name = yaml_dict["sns_secret_name"]
        target_table_name = yaml_dict["target_table_name"]
        target_database = yaml_dict["target_database"]
        recordkey = yaml_dict["recordkey"]
        partition_field = yaml_dict["partition_field"]
        precombine_field = yaml_dict["precombine_field"]
        metrics_bucket_name = yaml_dict["metrics_bucket_name"]
        metrics_path = yaml_dict["metrics_path"]
        metrics_cumulative_path = yaml_dict["metrics_cumulative_path"]
        cumulative_target_table_name = yaml_dict["cumulative_target_table_name"]
        watermark_bucket = yaml_dict["watermark_bucket"]
        watermark_file_key = yaml_dict["watermark_file_key"]
        latest_updatedTsp_key = yaml_dict["latest_updatedTsp_key"]
        watermark_column = yaml_dict["watermark_column"]
        vehicle_state_hudi_path = yaml_dict["vehicle_state_hudi_path"]
        vehicle_state_table_name = yaml_dict["vehicle_state_table_name"]
        exclude_vids_config_file = yaml_dict["exclude_vids_config_file"]
        
        vids_exclude_yaml_dict= load_yaml_config(s3_client,yaml_s3_bucket,exclude_vids_config_file)
        exclude_vids = vids_exclude_yaml_dict['vid_filter_list']
        
        
        logging.info("yaml parameters read successfully")
        return audit_table, audit_path,region_name,source_type,target_type,sns_secret_name,target_table_name,\
                target_database,metrics_bucket_name,metrics_path,recordkey,partition_field,precombine_field,\
                metrics_cumulative_path,cumulative_target_table_name,watermark_bucket,watermark_file_key,\
                latest_updatedTsp_key,watermark_column,vehicle_state_hudi_path,exclude_vids,vehicle_state_table_name
        
    except Exception as e:
        logging.error(f"Error while reading yaml parameters: {str(e)}")
        traceback.print_exc()
        raise
    
def calculate_count_duration(df1):
    try:
        #get duration  from data frame
        window_spec1 = Window.partitionBy("vid","tenantId").orderBy(col("updatedTsp").asc())
        df_with_lead = df1.withColumn('next_updated_time', F.lead('updatedTsp').over(window_spec1))
        df_with_duration = df_with_lead.withColumn(
            'time_diff_secs',
            F.floor(F.coalesce((col('next_updated_time') - col('updatedTsp'))/1000, F.lit(0)))
        ).drop('next_updated_time')
        
        #the difference between packets should be less than 1 hour
        df_with_duration = df_with_duration.filter(col('time_diff_secs') < 3600)
        
        df_with_dur = df_with_duration.withColumn("date", F.to_date(F.from_unixtime((col("updatedTsp") / 1000).cast("long"))))
        
        
        df_with_dur = df_with_dur.groupBy("vid","tenantId","driveStatus_value","group_id","date").agg(F.sum('time_diff_secs').alias('duration_status_wise'))
        dur_result = df_with_dur.groupBy("vid","tenantId","date").agg(
            F.sum(F.when(col("driveStatus_value") == "Stopped", col("duration_status_wise")).otherwise(0)).alias("stopped_duration"),
            F.sum(F.when(col("driveStatus_value") == "Moving", col("duration_status_wise")).otherwise(0)).alias("moving_duration"),
            F.sum(F.when(col("driveStatus_value") == "Idle", col("duration_status_wise")).otherwise(0)).alias("idle_duration")
        )
        
        # get the count
        count_result = df_with_dur.groupBy("vid","tenantId","date").agg(
            F.count(F.when(col("driveStatus_value") == "Stopped", 1)).alias("stopped_count"),
            F.count(F.when(col("driveStatus_value") == "Moving", 1)).alias("moving_count"),
            F.count(F.when(col("driveStatus_value") == "Idle", 1)).alias("idle_count")
        )
        
        metrics_df = dur_result.join(count_result, on=["vid","tenantId","date"], how="inner")
        
        
        return metrics_df
    except Exception as e:
        logging.error(f"Error while calculating counts and duration: {str(e)}")
        traceback.print_exc()
        raise
    
    
def add_rownum_for_sequential_state(df1):
    
    try :

        window_spec1 = Window.partitionBy("vid","tenantId").orderBy(col("updatedTsp").asc())
        
        # create a column change_flag , assign 1 when flag change happen else 0
        df_with_ranks_flag = df1.withColumn(
            "change_flag", 
            F.when(col("driveStatus_value") != F.lag("driveStatus_value").over(window_spec1), 1).otherwise(0)
        )
        # Use a cumulative sum to assign a group ID to consecutive drivestates
        df_with_ranks_flag_group = df_with_ranks_flag.withColumn(
            "group_id", 
            F.sum("change_flag").over(window_spec1)
        )

        return df_with_ranks_flag_group
    except Exception as e:
        logging.error(f"Error while adding rown numbers columns : {str(e)}")
        traceback.print_exc()
        raise

def load_df_into_target_table(source_df,target_table_name,target_database,target_hudi_table_path,recordkey,partition_field,precombine_field):
    """
    This function loads  data into raw
    """
    try:
        logging.info(f"PARTITION VALUES  (partition_field) in main table load: {partition_field}")
        # Define Hudi options
        source_df.write.format("hudi") \
            .option("hoodie.table.name", target_table_name) \
            .option("hoodie.datasource.write.storage.type", "COPY_ON_WRITE") \
            .option("hoodie.datasource.write.recordkey.field", recordkey) \
            .option("hoodie.datasource.write.partitionpath.field", partition_field) \
            .option("hoodie.datasource.write.precombine.field", precombine_field) \
            .option("hoodie.datasource.write.operation", "upsert") \
            .option("hoodie.datasource.hive_sync.enable", "true") \
            .option("hoodie.datasource.hive_sync.database", target_database) \
            .option("hoodie.datasource.hive_sync.table", target_table_name) \
            .option("hoodie.datasource.hive_sync.use_jdbc", "false") \
            .option("hoodie.datasource.hive_sync.mode", "hms") \
            .option("hoodie.datasource.hive_sync.sync_as_datasource", "false") \
            .option("hoodie.datasource.hive_sync.support_timestamp", "true") \
            .option("hoodie.avro.schema.allow.empty", "true") \
            .option("hoodie.schema.on.read.enable", "true") \
            .option("hoodie.datasource.write.schema.evolution.enable", "true") \
            .option("hoodie.parquet.max.file.size", "134217728") \
            .option("hoodie.upsert.shuffle.parallelism", 200) \
            .mode("append") \
            .save(target_hudi_table_path)
        ## .option("hoodie.datasource.hive_sync.partition_fields": partition_field) \
        logging.info(f"Data loaded successfully into {target_table_name} table,\
            no.of processed records count: {source_df.count()}")
        return True
    except Exception as e:
        logging.error(f"Error while loading the data into table:{target_table_name}, {str(e)}")
        traceback.print_exc()
        raise

def s3_path_exists(bucket_name, prefix, s3_client):
    
    response = s3_client.list_objects_v2(Bucket=bucket_name, Prefix=prefix, MaxKeys=1)
    return "Contents" in response

def load_metrics_into_stage_cum_counts(spark,metrics_df,metrics_bucket_name,metrics_cumulative_path,s3_client,target_table_name,target_database,
                            precombine_field):
    try: 
    
        metrics_df = metrics_df.groupBy("vid").agg(F.sum("stopped_count").alias("stopped_count"),
                                                F.sum("idle_count").alias("idle_count"),
                                                F.sum("moving_count").alias("moving_count"),
                                                F.sum("stopped_duration").alias("stopped_duration"),
                                                F.sum("idle_duration").alias("idle_duration"),
                                                F.sum("moving_duration").alias("moving_duration")
                                                )
        
        metrics_base_path = "s3://"+metrics_bucket_name+"/"+metrics_cumulative_path
        
        if s3_path_exists(metrics_bucket_name, metrics_cumulative_path, s3_client):
        
            existing_df = spark.read.format("hudi").load(metrics_base_path)
            existing_df  = existing_df.select(col('vid'),col("stopped_count"),col("idle_count"),col('moving_count'), \
                                        col("stopped_duration"),col("idle_duration"),col("moving_duration"))
            metrics_df = (
                        metrics_df.alias("m")
                        .join(existing_df.alias("e"), on="vid", how="left")
                        .select(
                            col("m.vid").alias("vid"),
                            # Handle addition for counts
                            (col("m.moving_count") + F.coalesce(col("e.moving_count"), F.lit(0))).alias("moving_count"),
                            (col("m.idle_count") + F.coalesce(col("e.idle_count"), F.lit(0))).alias("idle_count"),
                            (col("m.stopped_count") + F.coalesce(col("e.stopped_count"), F.lit(0))).alias("stopped_count"),
                            
                            (col("m.moving_duration") + F.coalesce(col("e.moving_duration"), F.lit(0))).alias("moving_duration"),
                            (col("m.idle_duration") + F.coalesce(col("e.idle_duration"), F.lit(0))).alias("idle_duration"),
                            (col("m.stopped_duration") + F.coalesce(col("e.stopped_duration"), F.lit(0))).alias("stopped_duration")))
    
        load_df_into_target_table(metrics_df,target_table_name,target_database,metrics_base_path,"vid","",precombine_field)
        logging.info("cumulative metrics stored successfully:")
        
    except Exception as e:
        logging.error(f"Error while loading the cumulative data into stage, {str(e)}")
        traceback.print_exc()
        raise   
    
def load_metrics_into_stage(spark,metrics_df,metrics_bucket_name,metrics_path,s3_client,target_table_name,target_database,
                            recordkey,partition_field,precombine_field):
    try:
    
        metrics_base_path = "s3://"+metrics_bucket_name+"/"+metrics_path
        
        metrics_df = metrics_df.withColumn("year", F.year("date")) \
                .withColumn("month", F.month("date")) \
                .withColumn("day",F.dayofmonth("date"))
                
                
        if s3_path_exists(metrics_bucket_name, metrics_path, s3_client):
        
            # Extract unique partition values as integers
            unique_years = metrics_df.select("year").distinct().rdd.flatMap(lambda x: x).collect()
            unique_months = metrics_df.select("month").distinct().rdd.flatMap(lambda x: x).collect()
            unique_days = metrics_df.select("day").distinct().rdd.flatMap(lambda x: x).collect()
            
            logging.info("UNIQUE VALUES")
            logging.info(unique_years)
            logging.info(unique_months)
            logging.info(unique_days)

            # Construct dynamic filter condition
            filter_condition = f"(year IN ({', '.join(map(str, unique_years))}) " \
                            f"AND month IN ({', '.join(map(str, unique_months))}) " \
                            f"AND day IN ({', '.join(map(str, unique_days))}))"
                            
            logging.info("filter_condition")
            logging.info(filter_condition)

            partition_df = spark.read.format("hudi").load(metrics_base_path) \
                .filter(filter_condition)

            # Perform left join based on multiple columns
            metrics_df = (
                metrics_df.alias("m")
                .join(partition_df.alias("p"), on=["vid", "tenantId", "date"], how="left")
                .select(
                    col("m.vid").alias("vid"),
                    col("m.tenantId").alias("tenantId"),
                    col("m.date").alias("date"),
                    col("m.year").alias("year"),
                    col("m.month").alias("month"),
                    col("m.day").alias("day"),
                    # Handle addition for counts
                    (col("m.moving_count") + F.coalesce(col("p.moving_count"), F.lit(0))).alias("moving_count"),
                    (col("m.idle_count") + F.coalesce(col("p.idle_count"), F.lit(0))).alias("idle_count"),
                    (col("m.stopped_count") + F.coalesce(col("p.stopped_count"), F.lit(0))).alias("stopped_count"),
                    
                    (col("m.moving_duration") + F.coalesce(col("p.moving_duration"), F.lit(0))).alias("moving_duration"),
                    (col("m.idle_duration") + F.coalesce(col("p.idle_duration"), F.lit(0))).alias("idle_duration"),
                    (col("m.stopped_duration") + F.coalesce(col("p.stopped_duration"), F.lit(0))).alias("stopped_duration")))

        load_df_into_target_table(metrics_df,target_table_name,target_database,metrics_base_path,recordkey,partition_field,precombine_field)
        logging.info("Data loaded  successfully into S3")
    except Exception as e:
        logging.error(f"Error while loading the data into stage, {str(e)}")
        traceback.print_exc()
        raise

def get_drive_state_schema():
    
    drive_state_Schema = StructType([
        StructField("createdTsp", LongType(), True),
        StructField("incomingTsp", LongType(), True),
        StructField("updatedTsp", LongType(), True),
        StructField("value", StringType(), True)
    ])
    
    return drive_state_Schema
    
def read_source_data(spark,vehicle_state_hudi_path,year,month,day,exclude_vids,watermark_column,current_watermark):
    try: 
        
        vehicle_state_df  = (
                spark.read.format("hudi").load(vehicle_state_hudi_path) \
                .filter(
                    (col("year") > year) |
                    ((col("year") == year) & (col("month") > month)) |
                    ((col("year") == year) & (col("month") == month) & (col("day") >= day))
                )
                .filter(~col("vid").isin(exclude_vids))  # Exclude vids
                .filter(col(watermark_column) > current_watermark)  # Apply watermark filter
            )
        return vehicle_state_df
        
    except Exception as e:
        logging.error(f"Error while reading the source data: {str(e)}")
        traceback.print_exc()
        raise
    
def get_year_month_day_hour(epoch_time_ms):
    
    epoch_time_sec = epoch_time_ms / 1000 
    utc_dt = datetime.fromtimestamp(epoch_time_sec, tz=timezone.utc)
    # keep buffer of 4 hours from now
    ist_offset = timedelta(hours=24)
    buffer_dt = utc_dt - ist_offset
    
    year = buffer_dt.year
    month = buffer_dt.month
    day = buffer_dt.day
    
    return year,month,day
    
def main():
    try:
        start_time = datetime.now()
        logging.info(f"Job started at {start_time}")
        spark = initialize_spark_session()
        job_name,job_run_id,yaml_s3_bucket,yaml_file_key = read_job_parameters()
        s3_client = boto3.client('s3')
        audit_table, audit_path,region_name,source_type,target_type,\
        sns_secret_name,target_table_name,target_database,metrics_bucket_name,metrics_path,recordkey,\
            partition_field,precombine_field,metrics_cumulative_path,cumulative_target_table_name,\
            watermark_bucket,watermark_file_key,latest_updatedTsp_key,watermark_column,vehicle_state_hudi_path, \
                exclude_vids,vehicle_state_table_name \
                = read_yaml_file(s3_client,yaml_s3_bucket,yaml_file_key)
        logging.info("job_name=%s", job_name)
    except Exception as e:
        logging.error(f"Error in initial steps: {str(e)}")
        traceback.print_exc()
        raise
    
    
    try:
        year_partitioned=start_time.year
        month_partitioned=start_time.month
        is_validate = validate_audit_table_with_s3_partition(spark,sns_secret_name,start_time,audit_path,audit_table,\
            vehicle_state_table_name,target_table_name,job_name,region_name,year_partitioned,month_partitioned)        # Log audit
        
        if is_validate == False:
            return
        
        log_audit(spark,job_name,vehicle_state_table_name,source_type,target_table_name,target_type,\
                    "Started",start_time,None,None,audit_path,audit_table)
        
        #read collectionevent time as a watermark file1
        current_watermark = get_watermark_timestamp(s3_client, watermark_bucket, watermark_file_key)
        logging.info("checking current_watermark dtype")
        if current_watermark == 0:
            current_watermark = '20241031000000000'
        logging.info(f"Current watermark: {current_watermark}")
        
        #read hct time as a watermark file2
        latest_updatedTsp = get_watermark_timestamp(s3_client, watermark_bucket, latest_updatedTsp_key)
        if latest_updatedTsp == 0:
            latest_updatedTsp = 1730332800000
        logging.info(f"Current watermark: {latest_updatedTsp}")  
        
        year,month,day = get_year_month_day_hour(latest_updatedTsp)
        vehicle_state_df = read_source_data(spark,vehicle_state_hudi_path,year,month,day,exclude_vids,watermark_column,current_watermark)
        
        record_count = vehicle_state_df.count()
        
        if record_count > 0:
            latest_hct = vehicle_state_df.agg({"_hoodie_commit_time": "max"}).collect()[0][0]
            max_updated_tsp = vehicle_state_df.agg({"updatedTsp": "max"}).collect()[0][0]
            
            vehicle_state_df = vehicle_state_df.select(col("vid"),col("tenantId"),col("driveStatus"))
            drive_state_schema = get_drive_state_schema()
            
            vehicle_state_df = vehicle_state_df.withColumn("driveStatus",F.from_json(col("driveStatus"),drive_state_schema))
            
            vehicle_state_df = vehicle_state_df.where(col("driveStatus").isNotNull())
            vehicle_state_df = vehicle_state_df.where(col("tenantId").isNotNull())
            vehicle_state_df = vehicle_state_df.withColumn("updatedTsp",col("driveStatus.updatedTsp").cast("long"))\
                .withColumn("driveStatus_value",col("driveStatus.value"))
            vehicle_state_df = vehicle_state_df.select("vid","tenantId","updatedTsp","driveStatus_value")
                    
            df_with_ranks_flag_group = add_rownum_for_sequential_state(vehicle_state_df)
            metrics_df = calculate_count_duration(df_with_ranks_flag_group)
            
            metrics_df = metrics_df.cache()
            if metrics_df.count() > 0:
            
                load_metrics_into_stage(spark,metrics_df,metrics_bucket_name,metrics_path,s3_client,
                                        target_table_name,target_database,recordkey,partition_field,precombine_field)
                load_metrics_into_stage_cum_counts(spark,metrics_df,metrics_bucket_name,metrics_cumulative_path,
                                        s3_client,cumulative_target_table_name,target_database,precombine_field)
            update_watermark_file(s3_client, latest_hct, watermark_bucket, watermark_file_key, cumulative_target_table_name)
            update_watermark_file(s3_client, max_updated_tsp, watermark_bucket, latest_updatedTsp_key, cumulative_target_table_name)
            metrics_df.unpersist()
            
        logging.info(f"load completed ")
        end_time = datetime.now()
        log_audit(
                spark,job_name,vehicle_state_table_name,source_type,target_table_name,target_type,"Completed",start_time,\
                    end_time,record_count,audit_path,audit_table)
        
    except Exception as e:
        logging.error("Job failed with error: %s", str(e))
        traceback.print_exc()
        end_time = datetime.now()
        duration = end_time - start_time
        logging.error(f"Job failed in {duration} seconds")
        #get cloudwatch details 
        
        cloudwatch_url = get_cloudwatch_url(region_name, job_name, job_run_id)
        log = {
                "status": "failure",
                "job_name": job_name,
                "source_table": vehicle_state_table_name,
                "target_table": target_table_name,
                "start_time": start_time.isoformat(),
                "end_time": end_time.isoformat(),
                "duration": duration,
                "error": f"Error: {str(e)}\nTraceback: {traceback.format_exc()}"
            }
        
        log_audit(
                spark,job_name,vehicle_state_table_name,source_type,target_table_name,target_type,\
                "Failed",start_time,end_time,None,audit_path,audit_table,
                )
            
        log_message = "\n".join([f"{key}: {value}" for key, value in log.items()])
        message = f"Job -{job_name} failed. Transformation returned None.\n\n{log_message}.\n\nView the logs in CloudWatch:{cloudwatch_url}"
        subject=f"Job Failed : Job - {job_name}"
        send_sns_notification(subject[:95], message, sns_secret_name,region_name)
        raise


if __name__ == "__main__":
    main()