# pylint: disable=import-error, invalid-name, too-many-locals, too-many-statements, broad-except
import sys
import logging
from datetime import datetime
import boto3
import json
import yaml
import traceback
from botocore.exceptions import ClientError
from pyspark.sql import SparkSession
from pyspark.sql.functions import udf
from pyspark.sql.utils import AnalysisException

from pyspark.sql.types import (
    IntegerType,
    StringType,
    StructField,
    StructType,
    TimestampType,
    MapType,
)
import time
from pyspark.sql import functions as F


athena_client = boto3.client("athena")
"""
This module performs audit logging for glue job
"""


def execute_athena_query(query, database, s3_output):
    """
    This method to execute athen query
    """
    # Start the query execution
    response = athena_client.start_query_execution(
        QueryString=query,
        QueryExecutionContext={"Database": database},
        ResultConfiguration={"OutputLocation": s3_output},
    )

    # Get the execution ID
    query_execution_id = response["QueryExecutionId"]

    # Wait for the query to finish
    while True:
        query_status = athena_client.get_query_execution(
            QueryExecutionId=query_execution_id
        )
        status = query_status["QueryExecution"]["Status"]["State"]

        if status in ["SUCCEEDED", "FAILED", "CANCELLED"]:
            break

        logging.info(f"Query is still running...")
        time.sleep(5)

    # Check the final status
    if status == "SUCCEEDED":
        logging.info("Query succeeded!")
    else:
        logging.info(f"Query failed with status: {status}")
    return status


def log_audit(
    spark,
    job_name,
    source,
    source_type,
    target,
    target_type,
    job_status,
    start_time,
    end_time,
    records_processed,
    audit_path,
    audit_table,
):
    """
    Records an audit log entry for a data processing operation by glue job.

    This method appends an entry to the audit log containing information about
    the job, source ,source_type,target,target type of job, job start time,
    job end time , records processed by job
    """
    job_id = job_name + "_" + target + "_" + str(start_time) + "_" + job_status
    schema = StructType(
        [
            StructField("job_id", StringType(), True),
            StructField("job_name", StringType(), True),
            StructField("source", StringType(), True),
            StructField("source_type", StringType(), True),
            StructField("target", StringType(), True),
            StructField("target_type", StringType(), True),
            StructField("job_status", StringType(), True),
            StructField("start_time", TimestampType(), True),
            StructField("end_time", TimestampType(), True),
            StructField("records_processed", IntegerType(), True),
        ]
    )
    audit_log = spark.createDataFrame(
        [
            (
                job_id,
                job_name,
                source,
                source_type,
                target,
                target_type,
                job_status,
                start_time,
                end_time,
                records_processed,
            )
        ],
        schema,
    )

    audit_log = audit_log.fillna("NULL")

    audit_log = audit_log.withColumn("year", F.year(F.col("start_time"))).withColumn(
        "month", F.month(F.col("start_time"))
    )

    database = "control"
    bucket_name = audit_path.split("/")[2]
    s3_output = "s3://" + bucket_name + "/athenaresults/"

    audit_log.write.partitionBy("target", "year", "month").parquet(
        audit_path, mode="append"
    )


def get_cloudwatch_url(region_name, job_name, job_run_id):
    """
    Generate a Glue Studio URL for the given job and run.
    """
    try:
        base_url = f"https://{region_name}.console.aws.amazon.com/gluestudio/home"
        glue_job_url = (
            f"{base_url}?region={region_name}#/job/{job_name}/run/{job_run_id}"
        )
        logging.info(f"Glue Job URL generated: {glue_job_url}")
        return glue_job_url
    except Exception as e:
        logging.error(f"Error generating Glue Job URL: {e}")
        traceback.print_exc()
        raise


def send_sns_notification(subject, message, sns_secret_name, region_name):
    try:
        session = boto3.session.Session()
        client = session.client(service_name="secretsmanager", region_name=region_name)
        get_secret_value_response = client.get_secret_value(SecretId=sns_secret_name)
        secret = get_secret_value_response["SecretString"]
        secret_dict = json.loads(secret)
        sns_topic_arn = secret_dict["sns_topic_arn"]
        sns_client = boto3.client("sns", region_name=region_name)
        sns_client.publish(TopicArn=sns_topic_arn, Subject=subject, Message=message)
        logging.info(f"SNS publish response succeeded")
    except Exception as e:
        logging.error(f"Error sending notification using SNS service: {e}")
        traceback.print_exc()
        raise


def load_yaml_config(s3_client, yaml_s3_bucket, yaml_file_key):
    """
    Load and parse YAML configuration from S3.
    """
    try:
        s3_object = s3_client.get_object(Bucket=yaml_s3_bucket, Key=yaml_file_key)
        yaml_content = s3_object["Body"].read().decode("utf-8")
        yaml_dict = yaml.safe_load(yaml_content)
        logging.info("YAML configuration loaded successfully.")
        return yaml_dict
    except Exception as e:
        logging.error(f"Error loading YAML configuration from S3: {e}")
        traceback.print_exc()
        raise


def fetch_postgres_credentials(rds_secret_name, region_name):
    """
    Fetch PostgreSQL credentials from AWS Secrets Manager.
    """
    try:
        session = boto3.session.Session()
        client = session.client(service_name="secretsmanager", region_name=region_name)
        get_secret_value_response = client.get_secret_value(SecretId=rds_secret_name)
        secret = get_secret_value_response["SecretString"]
        logging.info("PostgreSQL credentials fetched successfully.")
        return json.loads(secret)
    except Exception as e:
        logging.error(
            f"Error fetching PostgreSQL credentials from Secrets Manager: {e}"
        )
        traceback.print_exc()
        raise

def validate_audit_table_with_s3_partition(
    spark: SparkSession,
    sns_secret_name: str,
    start_time: datetime,
    audit_path: str,
    audit_table: str,
    source_table_name: str,
    target_table_name: str,
    job_name: str,
    region_name: str,
    year: int,    # Year partition value
    month: int,   # Month partition value
):
    """
    Validate if a concurrent job is running based on the partitioned S3 path.

    Returns:
        bool: True if the job can proceed, False if an active job is running.
    """
    try:
        logging.info(f"Validating using S3 path for table: {source_table_name}")

        # Construct the partition path based on the partition columns
        partition_path = f"target={target_table_name}/year={year}/month={month}/"

        try:
            partition_df = spark.read.parquet(f"{audit_path}{partition_path}")
            logging.info(f"Data exists in partition {audit_path}{partition_path}, checking for job status.")

            job_status_df = (
                partition_df.filter(partition_df["source"] == source_table_name)
                .filter(partition_df["job_status"] != "Aborted")
                .orderBy(partition_df["start_time"].desc(), partition_df["end_time"].desc())
            )

            # Timeout threshold ( 25 minutes = 1500 seconds)
            TIMEOUT_THRESHOLD_SECONDS = 1500

            latest_job_status = job_status_df.first()
            logging.info(f"latest_job_status is {latest_job_status['job_status']}")
            if latest_job_status and latest_job_status["job_status"] == "Started":
                job_start_time = latest_job_status["start_time"]
                # job_start_time = datetime.strptime(job_start_time_str, "%Y-%m-%d %H:%M:%S.%f")
                job_runtime_seconds = (datetime.now() - job_start_time).total_seconds()

                if job_runtime_seconds < TIMEOUT_THRESHOLD_SECONDS:
                    logging.error(
                        f"An incomplete job is already running for table {source_table_name} "
                        f"in partition {target_table_name}/{year}/{month}. Exiting job."
                    )

                    end_time = datetime.now()
                    duration = (end_time - start_time).seconds

                    log_audit(
                        spark,
                        job_name,
                        source_table_name,
                        "SourceType",
                        target_table_name,
                        "TargetType",
                        "Aborted",
                        start_time,
                        end_time,
                        None,
                        audit_path,
                        audit_table,
                    )

                    log = {
                        "status": "Aborted",
                        "job_name": job_name,
                        "source_table": source_table_name,
                        "target_table": target_table_name,
                        "start_time": start_time.isoformat(),
                        "end_time": end_time.isoformat(),
                        "duration": duration,
                        "error": (
                            f"An incomplete job is already running for table {source_table_name} "
                            f"in partition {target_table_name}/{year}/{month}."
                        ),
                    }

                    message = (
                        f"Job aborting due to {job_name} for {source_table_name} in partition "
                        f"{target_table_name}/{year}/{month} is still running. Hence validation failed.\n\n"
                        + "\n".join([f"{k}: {v}" for k, v in log.items()])
                    )
                    logging.error(message)

                    send_sns_notification(
                        f"Job Aborted for table {source_table_name}",
                        message,
                        sns_secret_name,
                        region_name,
                    )
                    return False
                else:
                    logging.warning(
                        f"Previous job was stuck in 'Started' state but has exceeded the timeout threshold "
                        f"({job_runtime_seconds:.2f} seconds > {TIMEOUT_THRESHOLD_SECONDS} seconds). "
                        f"Treating it as stale and proceeding with the current job."
                    )

        except AnalysisException:
            logging.warning(
                f"Partition path {partition_path} does not exist. Assuming first-time job execution."
            )
            return True

        logging.info(
            f"No incomplete jobs found for table {source_table_name} "
            f"in partition {target_table_name}/{year}/{month}. Proceeding with the job."
        )
        return True

    except Exception as e:
        logging.error(f"Error validating the audit table with S3 path: {e}")
        raise
    
def validate_audit_table(
    spark,
    audit_database,
    audit_table,
    source_table_name,
    target_table_name,
    job_name,
    sns_secret_name,
    start_time,
    audit_path,
    source_type,
    target_type,
    region_name,
):
    """
    Validate the audit table to check if there is an incomplete job.

    Args:
        spark (SparkSession): The Spark session to use for querying.
        audit_database (str): The name of the audit database.
        audit_table (str): The name of the audit table.
        source_table_name (str): The source table name to check.

    Raises:
        SystemExit: Exits the job if an incomplete job is found.
    """
    try:
        logging.info(f"audit table is : {audit_database}.{audit_table}")
        logging.info(f"audit path is : {audit_path}")
        # Query to check the latest status for the given source_table_name
        query = f"""
        SELECT job_status 
        FROM {audit_database}.{audit_table}
        WHERE source = '{source_table_name}'
        ORDER BY start_time DESC, end_time DESC
        LIMIT 1
        """

        # Execute the query using Spark SQL
        audit_df = spark.sql(query)
        logging.info("query successfully executed")
        logging.info(f"Query: {query}")

        # Check if there is an incomplete job
        if not audit_df.rdd.isEmpty():
            latest_job_status = audit_df.collect()[0]["job_status"]
            logging.info(
                f"Latest job status for table {source_table_name} is: {latest_job_status}"
            )
            if latest_job_status == "Started":
                logging.error(
                    f"An incomplete job is already running for table {source_table_name}. Exiting job."
                )

                end_time = datetime.now()
                duration = (end_time - start_time).seconds

                logging.info("writing to audit table for validation")
                logging.info(f"target_table_name is : {target_table_name}")

                log_audit(
                    spark,
                    job_name,
                    source_table_name,
                    source_type,
                    target_table_name,
                    target_type,
                    "Aborted",
                    start_time,
                    end_time,
                    None,
                    audit_path,
                    audit_table,
                )

                log = {
                    "status": "Aborted",
                    "job_name": job_name,
                    "source_table": source_table_name,
                    "target_table": target_table_name,
                    "start_time": start_time.isoformat(),
                    "end_time": end_time.isoformat(),
                    "duration": duration,
                    "error": f"An incomplete job is already running for table {source_table_name}.",
                }

                log_message = "\n".join(
                    [f"{key}: {value}" for key, value in log.items()]
                )
                message = f"Job aborting due to {job_name} for {source_table_name} is still running. Hence validation of audit table Failed \n\n{log_message}"
                logging.error(message)
                send_sns_notification(
                    f"Job - {job_name} Aborted for table {source_table_name}",
                    message,
                    sns_secret_name,
                    region_name,
                )
                sys.exit(1)  # Exit the job if an incomplete job is found
        else:
            logging.info("No previous job status found. Proceeding with the job.")

    except Exception as e:
        logging.error(f"Error validating the audit table: {e}")
        traceback.print_exc()
        raise


def check_file_exist(s3_client, bucket_name, file_key):
    try:
        s3_client.head_object(Bucket=bucket_name, Key=file_key)
        return True
    except ClientError as e:
        # If the error is a 404 error, the file does not exist
        if e.response["Error"]["Code"] == "404":
            return False
        # Handle other potential errors
        else:
            raise e


def read_watermark_from_s3(s3_client, watermark_bucket, watermark_file_key):
    """
    Read the watermark from S3 for a specific table.
    """
    try:
        response = s3_client.get_object(Bucket=watermark_bucket, Key=watermark_file_key)
        watermark_data = json.loads(response["Body"].read().decode("utf-8"))

        latest_watermark = watermark_data.get("watermark_timestamp")
        return latest_watermark
    except Exception as e:
        logging.error(
            f"Error While reading watermarkfile from the file {watermark_file_key}:{str(e)}"
        )
        raise


def get_watermark_timestamp(s3_client, watermark_bucket, watermark_file_key):
    try:
        # check whether the file exist or not
        watermark_file_exist = check_file_exist(
            s3_client, watermark_bucket, watermark_file_key
        )
        if watermark_file_exist:
            watermark_timestamp = read_watermark_from_s3(
                s3_client, watermark_bucket, watermark_file_key
            )
        else:
            # read old timestamp as a watermark timestamp
            watermark_timestamp = 0
        logging.info(
            f"watermark timestamp read successfully, watermark_timestamp: {watermark_timestamp}"
        )
        return watermark_timestamp
    except Exception as e:
        logging.error(f"Error while reading watermark timestamp: {str(e)}")
        raise


def update_watermark_file(
    s3_client, max_commit_time, watermark_bucket, watermark_file_key, source_table_name
):
    try:
        # Convert max_commit_time to string (ISO 8601 format) or UNIX timestamp
        if isinstance(max_commit_time, datetime):
            max_commit_time_str = (
                max_commit_time.isoformat()
            )  # Convert to ISO 8601 string
        else:
            max_commit_time_str = max_commit_time  # If it's already a string or integer

        # Update the watermark for the specific table
        data = {}
        data["watermark_timestamp"] = max_commit_time_str

        # Convert updated data to JSON
        json_data = json.dumps(data)

        # Write updated data back to S3
        s3_client.put_object(
            Body=json_data, Bucket=watermark_bucket, Key=watermark_file_key
        )

        logging.info(
            f"Successfully updated watermark file for table {source_table_name}, latest_commit_time: {max_commit_time_str}"
        )
        return True

    except Exception as e:
        logging.error(f"Error while updating the watermark file: {str(e)}")
        raise


def initialize_spark_session():
    try:
        spark = (
            SparkSession.builder.config(
                "spark.serializer", "org.apache.spark.serializer.KryoSerializer"
            )
            .config("spark.hudi.query.metadata.enable", "true")
            .config("spark.sql.analyzer.failAmbiguousSelfJoin", "false")
            .getOrCreate()
        )
        logging.info("Spark session initialized successfully.")
        return spark
    except Exception as e:
        logging.error(f"Error initializing Spark session: {str(e)}")
        raise


# normalie the json at any level
def normalize_json(json_str):
    try:
        # Parse the JSON string into a Python dict
        json_obj = json.loads(json_str)

        # Flatten the JSON (recursive for nested JSON)
        def flatten_json(json_obj, prefix=""):
            items = {}
            for key, value in json_obj.items():
                new_key = f"{prefix}{key}" if prefix == "" else f"{prefix}_{key}"
                if isinstance(value, dict):
                    items.update(flatten_json(value, new_key))
                else:
                    items[str(new_key).lower().strip()] = value
            return items

        # Call the flattening function
        return flatten_json(json_obj)

    except:
        return None


normalize_json_udf = udf(normalize_json, MapType(StringType(), StringType()))


def get_postgres_jdbc_properties(db_user, db_password, postgres_driver):
    """
    Return the JDBC properties for PostgreSQL connection.
    """
    jdbc_properties = {
        "user": db_user,
        "password": db_password,
        "driver": postgres_driver,
    }
    return jdbc_properties


def format_watermark(latest_watermark, data_type, timestamp_dtype):
    """
    Format the watermark based on the column data type.
    """
    formats = ["%Y-%m-%dT%H:%M:%S", "%Y-%m-%d %H:%M:%S.%f", "%Y-%m-%d %H:%M:%S"]

    if data_type in ["bigint", "integer"]:
        # Use the epoch time (already in milliseconds)
        return f"{latest_watermark}"

    elif data_type == timestamp_dtype:
        # Check if latest_watermark is already a timestamp string
        if isinstance(latest_watermark, str):
            timestamp = None
            for fmt in formats:
                try:
                    timestamp = datetime.strptime(latest_watermark, fmt)
                    break
                except ValueError:
                    continue

            if timestamp is None:
                logging.error(f"Error parsing timestamp: {latest_watermark}")
                raise ValueError(f"Unsupported timestamp format: {latest_watermark}")

            # Convert timestamp to epoch time in milliseconds
            latest_watermark = int(timestamp.timestamp() * 1000)

        # Convert epoch to timestamp in seconds for SQL query
        return f"to_timestamp({latest_watermark} / 1000)"

    else:
        raise ValueError(f"Unsupported data type: {data_type}")

def fetch_snowflake_credentials(secret_name):
    client = boto3.client('secretsmanager')
    response = client.get_secret_value(SecretId=secret_name)
    secret = json.loads(response['SecretString'])
    return secret

def get_snowflake_connection(sfUser,sfPassword,sfURL):
    """
    Establish and return a Snowflake connection.
    """
    try:
        conn = snowflake.connector.connect(
        user=sfUser,
        password=sfPassword,
        account = sfURL.split('//')[1].split('.snowflakecomputing.com')[0]
    )
        logging.info("Snowflake connection established.")
        return conn
    except Exception as e:
        logging.error(f"Error establishing Snowflake connection: {e}")
        raise