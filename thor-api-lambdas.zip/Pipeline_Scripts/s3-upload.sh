#!/bin/bash
# set -xe  #Uncomment this line to enable detailed logs for troubleshooting
set -e

if [ ${LOWERCASE_BRANCH_NAME} == 'dev' ]; then
    ROLE_ARN="arn:aws:iam::${dev_account_id}:role/${ROLE_NAME}"
    ROLE_SESSION_NAME="DEVCrossAccountS3UploadADOSession"
elif [ ${LOWERCASE_BRANCH_NAME} == 'qa' ]; then
    ROLE_ARN="arn:aws:iam::${qa_account_id}:role/${ROLE_NAME}"
    ROLE_SESSION_NAME="QACrossAccountS3UploadADOSession"
elif [ ${LOWERCASE_BRANCH_NAME} == 'uat' ]; then
    ROLE_ARN="arn:aws:iam::${uat_account_id}:role/${ROLE_NAME}"
    ROLE_SESSION_NAME="UATCrossAccountS3UploadADOSession"
elif [ ${LOWERCASE_BRANCH_NAME} == 'prod' ]; then
    ROLE_ARN="arn:aws:iam::${prod_account_id}:role/${ROLE_NAME}"
    ROLE_SESSION_NAME="PRODCrossAccountS3UploadADOSession"
fi

DURATION_SECONDS=900
LAMBDA_LOCAL_FILE_PATH="${Build_ArtifactStagingDirectory}/Lambda/"

# Assume role and export credentials
assume_role() {
    CREDENTIALS=$(aws sts assume-role --role-arn "${ROLE_ARN}" --role-session-name "${ROLE_SESSION_NAME}" --query "[Credentials.AccessKeyId,Credentials.SecretAccessKey,Credentials.SessionToken]" --output text --duration-seconds "${DURATION_SECONDS}")
    
    export AWS_ACCESS_KEY_ID="$(echo $CREDENTIALS | awk '{print $1}')"
    export AWS_SECRET_ACCESS_KEY="$(echo $CREDENTIALS | awk '{print $2}')"
    export AWS_SESSION_TOKEN="$(echo $CREDENTIALS | awk '{print $3}')"

    if [ -z "${AWS_ACCESS_KEY_ID}" ] || [ -z "${AWS_SECRET_ACCESS_KEY}" ] || [ -z "${AWS_SESSION_TOKEN}" ]; then
        echo "Error assuming the role or retrieving credentials. Exiting..."
        exit 1
    fi

    aws sts get-caller-identity
}

# Get list of .zip files in a directory
get_zip_files() {
    local directory="$1"
    mapfile -t zip_files < <(ls -X "$directory" | grep '\.zip$')
    echo "${zip_files[@]}"
}

# Get Lambda function names from zip files
get_function_names() {
    local zip_files=("$@")
    for i in "${!zip_files[@]}"; do
        func_names[$i]="${zip_files[$i]%.zip}"
    done
    echo "${func_names[@]}"
}

# Get revision ID of a Lambda function
get_revision_id() {
    local func_name="$1"
    aws lambda get-function --function-name "$func_name" --query "[Configuration.RevisionId]" --region "$REGION" --output text
}

# Sync files to S3 and check result
sync_to_s3() {
    local src="$1"
    local dest="$2"
    aws s3 sync "$src" "$dest"
    if [ $? -eq 0 ]; then
        echo "Files uploaded successfully to S3 bucket"
    else 
        echo "Something went wrong in uploading files to S3 bucket"
        exit 1
    fi
}

# Main script starts here
echo "Starting cross-account role assumption for temporary credentials in AWS Account $dev_account_id..."
assume_role

echo "Retrieving list of .zip files for Lambda function..."
zip_files=($(get_zip_files "$LAMBDA_LOCAL_FILE_PATH"))
echo "Printing the zip_files array: ${zip_files[@]}"

echo "Extracting function names from zip files..."
func_names=($(get_function_names "${zip_files[@]}"))
echo "Printing the func_names array: ${func_names[@]}"

declare -A PreSyncRevId
declare -A PostSyncRevId

for func_name in "${func_names[@]}"; do
    if [ ${LOWERCASE_BRANCH_NAME} == 'dev' ]; then
        lambda_name="${ENTITY_NAME}-dev-${func_name}"
        echo "Lambda function name is $lambda_name"
    elif [ ${LOWERCASE_BRANCH_NAME} == 'qa' ]; then
        lambda_name="${ENTITY_NAME}-qa-${func_name}"
        echo "Lambda function name is $lambda_name"
    elif [ ${LOWERCASE_BRANCH_NAME} == 'uat' ]; then
        lambda_name="${ENTITY_NAME}-uat-${func_name}"
        echo "Lambda function name is $lambda_name"
    elif [ ${LOWERCASE_BRANCH_NAME} == 'prod' ]; then
        lambda_name="${ENTITY_NAME}-prod-${func_name}"
        echo "Lambda function name is $lambda_name" 
    fi
    echo "Processing Lambda function: $lambda_name"
    PreSyncRevId[$func_name]=$(get_revision_id "$lambda_name")
    echo "Revision ID of Lambda function $lambda_name before S3 sync: ${PreSyncRevId[$func_name]}"
done

echo "Printing the PreSyncRevId array: ${PreSyncRevId[@]}"

echo "Syncing all the Lambda function code files from ADO repository to S3 buckets..."
if [ ${LOWERCASE_BRANCH_NAME} == 'dev' ]; then
    sync_to_s3 "${LAMBDA_LOCAL_FILE_PATH}" "s3://${DEV_LAMBDA_S3_BUCKET}/"
elif [ ${LOWERCASE_BRANCH_NAME} == 'qa' ]; then
    sync_to_s3 "${LAMBDA_LOCAL_FILE_PATH}" "s3://${QA_LAMBDA_S3_BUCKET}/"
elif [ ${LOWERCASE_BRANCH_NAME} == 'uat' ]; then
    sync_to_s3 "${LAMBDA_LOCAL_FILE_PATH}" "s3://${UAT_LAMBDA_S3_BUCKET}/"
elif [ ${LOWERCASE_BRANCH_NAME} == 'prod' ]; then
    sync_to_s3 "${LAMBDA_LOCAL_FILE_PATH}" "s3://${PROD_LAMBDA_S3_BUCKET}/"
fi

sleep_duration=$(( ${#func_names[@]} * 15 ))
echo "Sleeping for $sleep_duration seconds to allow Lambda code update..."
sleep $sleep_duration

for func_name in "${func_names[@]}"; do
    if [ ${LOWERCASE_BRANCH_NAME} == 'dev' ]; then
        lambda_name="${ENTITY_NAME}-dev-${func_name}"
        echo "Lambda function name is $lambda_name"
    elif [ ${LOWERCASE_BRANCH_NAME} == 'qa' ]; then
        lambda_name="${ENTITY_NAME}-qa-${func_name}"
        echo "Lambda function name is $lambda_name"
    elif [ ${LOWERCASE_BRANCH_NAME} == 'uat' ]; then
        lambda_name="${ENTITY_NAME}-uat-${func_name}"
        echo "Lambda function name is $lambda_name"
    elif [ ${LOWERCASE_BRANCH_NAME} == 'prod' ]; then
        lambda_name="${ENTITY_NAME}-prod-${func_name}"
        echo "Lambda function name is $lambda_name" 
    fi
    echo "Processing Lambda function: $lambda_name"
    PostSyncRevId[$func_name]=$(get_revision_id "$lambda_name")
    echo "Revision ID of Lambda function $lambda_name after S3 sync: ${PostSyncRevId[$func_name]}"

    if [ ${PreSyncRevId[$func_name]} != ${PostSyncRevId[$func_name]} ]; then
        echo "Revision IDs before and after S3 sync are different. Hence the Lambda code update is successful for $lambda_name"
    else
        echo "Revision IDs before and after S3 sync are same. Hence the Lambda code update is failed for $lambda_name. Please update its code manually from the console or retrigger the pipeline."
        echo "Exiting the pipeline with failure..."
        exit 1
    fi
done

echo "Printing the PostSyncRevId array: ${PostSyncRevId[@]}"

echo "Data Pipeline completed successfully. Unsetting temporary AWS credentials..."
# echo "Dummy"

unset AWS_ACCESS_KEY_ID
unset AWS_SECRET_ACCESS_KEY
unset AWS_SESSION_TOKEN

echo "Data Pipeline script execution finished."