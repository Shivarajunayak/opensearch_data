import { unmarshall } from '@aws-sdk/util-dynamodb';
import { Kafka } from "kafkajs"
import {
    SecretsManagerClient,
    GetSecretValueCommand,
} from "@aws-sdk/client-secrets-manager";
import { generateAuthToken, generateAuthTokenFromRole } from 'aws-msk-iam-sasl-signer-js';
import { KMSClient, DecryptCommand } from "@aws-sdk/client-kms";
// JOI Schema validator imported from lambda layer
import Joi from 'joi';
import { TextDecoder } from 'util';
import { createClient,createCluster  } from "redis";

/*-------------Declare all constants START---------*/

const SECRET_NAME = process.env.SECRET_NAME;
const REGION = process.env.AWS_REGION;
const MSK_TOPIC_NAME = "hmcl-thor-user-management-topic";
const TOPIC_NAME_PINPOINT_UPDATE = "hmcl-thor-user-management-pinpoint-registration-topic";
const TOPIC_NAME_DATALAKE = "hmcl-thor-user-management-all-fields";
const HMCL_THOR_CMD_CONTROL_REQ_TOPIC = 'hmcl-thor-rfw-cmdrequest-cond-mstr-v1-k2';
const BROKERS_IAM = process.env.BROKERS_IAM.split(',').map(e=>e.trim());
const RDS_SECRET_NAME = process.env.RDS_SECRET_NAME;
const REDIS_SLL_KEY_PREFIX = "share_live_location"
// const BROKERS_SASL= process.env.BROKERS_SASL.split(',').map(e=>e.trim());
const MSK_SASL_MECHANISM = 'SCRAM-SHA-512';
const MSK_IAM_MECHANISM = 'oauthbearer';
const NOTIFICATION_CHANNEL_ACTION = {
    DELETE: "Delete",
    UPDATE: "Update",
    CREATE: "Create",
}

const USER_TYPE = {
    PRIMARY: "Primary",
    SECONDARY: "Secondary"
}

const NOTIFICATION_CHANNEL = {
    SMS: "SMS",
    EMAIL: "Email",
    PUSH: "Push",
    NONE: "None",
    ALL: "All",

}
const GEO_FENCE_ACTIVATE_CMD_ISSUED = "Activate-Cmd-Issued";
const GEO_FENCE_DEACTIVATE_CMD_ISSUED = "DeActivate-Cmd-Issued";
const LOG_LEVELS_ENUM = {
    INFO: 2,
    ERROR: 0,
    WARN: 1,
}
const LOG_LEVELS = {
    INFO: "INFO",
    ERROR: "ERROR",
    WARN: "WARN",
}
const LOG_LEVEL = process.env.LOG_LEVEL || "INFO";

const OVERSPEED_CMD_CODE_SECRET_NAME = process.env.OVERSPEED_CMD_CODE_SECRET_NAME;
const GEOFENCE_FTR_CODE_SECRET_NAME = process.env.GEOFENCE_FTR_CODE_SECRET_NAME;
const secretClient = new SecretsManagerClient({
    region: REGION,
});
let speedUpdatedViaBLE = false;
const KMS_KEY = "arn:aws:kms:ap-south-1:211125359537:key/mrk-4a7e1d457a7e4f9f87534de0c631cb11";

/*-------------Declare all constants END---------*/


const shouldLog = (level) => {
    return LOG_LEVELS_ENUM[level] <= LOG_LEVELS_ENUM[LOG_LEVEL];
}

// Custom logger function
const log = (level, message, meta = {}) => {
    switch (level) {
        case LOG_LEVEL.INFO:
            if(shouldLog(level)) {
                console.log(JSON.stringify({ level, message, ...meta }));
            }
            break;
        case LOG_LEVEL.ERROR:
            if(shouldLog(level)) {
                console.error(JSON.stringify({ level, message, ...meta }));
            }
            break;
        case LOG_LEVEL.WARN:
            if(shouldLog(level)) {
                console.warn(JSON.stringify({ level, message, ...meta }));
            }
            break;
        default:
            if(shouldLog(level)) {
                console.log(JSON.stringify({ level, message, ...meta }));
            }
            break;
    }
};

// this method will be used only if the authentication mechanism of MSK is IAM
async function oauthBearerTokenProvider(region) {
    // Uses AWS Default Credentials Provider Chain to fetch credentials
    const authTokenResponse = await generateAuthToken({ region });
    // const authTokenResponse = await generateAuthTokenFromRole({
    //     region: region,
    //     awsRoleArn: "arn:aws:iam::493491284121:role/hmcl-msk-add-update-user-lambda-assume-role",
    //     awsRoleSessionName: "AssumeRole"
    // })
    return {
        value: authTokenResponse.token
    }
}

async function getOverSpeedSecretManagerValue() {
    let resp;
    try {
      resp = await secretClient.send(
        new GetSecretValueCommand({
          SecretId: OVERSPEED_CMD_CODE_SECRET_NAME,
          VersionStage: "AWSCURRENT",
        })
      );
    } catch (error) {
      return {
        errorMessage:error
      }
    }

    const secret = JSON.parse(resp.SecretString);
    console.log("secret1:", secret);
    return secret.SecretString;
  }

  async function getOverGeofenceManagerValue() {
    let resp;
    try {
      resp = await secretClient.send(
        new GetSecretValueCommand({
          SecretId: GEOFENCE_FTR_CODE_SECRET_NAME,
          VersionStage: "AWSCURRENT",
        })
      );
    } catch (error) {
      return {
        errorMessage:error
      }
    }

    const secret = JSON.parse(resp.SecretString);
    console.log("secret2:", secret);
    return secret.SecretString;
  }

export const handler = async (event) => {
    try {
        //NOTE - When a new record is inserted, only NewImage will be present
        //NOTE - When a new record is updated, OldImage and NewImage, both, will not present
        //NOTE - when a record is deleted, only OldImage will be present.

        // Use cases
        // A single record is updated
        // A single record is creaated
        // A single record is deleted
        // Multiple records are created
        // Multiple records are updated
        // Multiple records are deleted

        if (!Array.isArray(event.Records)) {
            throw new Error(`Records should be of type array`);
        }

        //validate each new/updated record
        for (let record of event.Records) {
            const newImageFromDynamoDb = record.dynamodb.NewImage;
            const newImageObject = (unmarshall(newImageFromDynamoDb));
            if (newImageFromDynamoDb) {
                // if any issue in schema then method will terminate from here raising exception
                validateRecordWithSchema(newImageObject);
            }
        }

        /*-------------Connect to Kafka topic START---------*/
        // const client = new SecretsManagerClient({
        //     region: REGION,
        // });
        // const secretResponse = await client.send(
        //     new GetSecretValueCommand({
        //         SecretId: SECRET_NAME,
        //         VersionStage: "AWSCURRENT",
        //     })
        // );
        // const secret = JSON.parse(secretResponse.SecretString);
        const kafka = new Kafka({
            clientId: 'add-update-customer-preference-lambda',
            brokers: BROKERS_IAM,
            ssl: true, // Set to true if your cluster uses SSL
            // sasl: {
            //     mechanism: MSK_SASL_MECHANISM,
            //     username: secret.username,
            //     password: secret.password,
            // }
              sasl: {
                mechanism: MSK_IAM_MECHANISM,
                oauthBearerProvider: () => oauthBearerTokenProvider(REGION)
            }
        });
        const producer = kafka.producer();
        try {
            await producer.connect();

            // Once the producer is connected, all the stream data will be processed one by one for each use case
            for (let record of event.Records) {

                log(LOG_LEVELS.INFO, "Processing record", { record });

                // MSK payload object
                let message = {};
                const newImageFromDynamoDb = record.dynamodb.NewImage;
                const oldImageFromDynamoDb = record.dynamodb.OldImage;

                //check if the record is inserted or updated
                const isRecordAdded = record.eventName === "INSERT";
                const isRecordUpdated = record.eventName === "MODIFY";
                const isRecordDeleted = record.eventName === "REMOVE";

                log(LOG_LEVELS.INFO, "Record status", { isRecordAdded, isRecordUpdated, isRecordDeleted });

                const newImageObject = (unmarshall(newImageFromDynamoDb));
                const oldImageObject = isRecordUpdated ? (unmarshall(oldImageFromDynamoDb)) : null;


                /*-------------Data preparation for sending to Data Lake START---------*/
                // The new image needs to be sent as is to Data Lake
                try {
                    if(isRecordAdded || isRecordUpdated) {
                        message = {
                            value: JSON.stringify(newImageObject)
                        };
                        log(LOG_LEVELS.INFO, "New Image record", { newImageObject });
                        await sendToKafkaTopic(producer, message, TOPIC_NAME_DATALAKE);
                    }
                } catch (error) {
                    log(LOG_LEVELS.ERROR, "Error while processing data for DataLake", error);
                }
                /*-------------Data preparation for sending to Data Lake END---------*/
                
                /*-------------Data preparation for sending to User management API service to update the pinpointIDs START---------*/
                //if it as new record then send directly to user management service for pinpoint update
                try {
                    let pinPointPayload = null;
                    const isContactDetailsUpdated = isRecordAdded ? false : getIsContactDetailsUpdated(newImageObject, oldImageObject);
                    if (isRecordAdded) {
                        // the list of all the channels enabled by the user in new image ex. ['SMS', 'EMAIL']
                        const newPreferredNotificationList = await getAllUserPreferredChannels(newImageObject);                        // the list of all the channels enabled by the user in old image ex. ['SMS', 'EMAIL']
                        const oldPreferredNotificationList = [];
                        const newOldPreferredNotificationList = Array.from(new Set([...newPreferredNotificationList, ...oldPreferredNotificationList]));
                        const notificationListFWithPinPointIdUpdated = getAvailablePreferredNotificationChannelsUniqueList(newImageObject);
                        pinPointPayload = await convertToPinpointRequestDTO(newImageObject,null, newPreferredNotificationList, newOldPreferredNotificationList,oldPreferredNotificationList, isContactDetailsUpdated);

                        if(pinPointPayload.channels.length || pinPointPayload.emergencyContacts.length) {
                            message = {
                                value: JSON.stringify(pinPointPayload)
                            };
                            log(LOG_LEVELS.INFO, "Pinpoint Payload for added record", pinPointPayload);
                            await sendToKafkaTopic(producer, message, TOPIC_NAME_PINPOINT_UPDATE);
                        }
                    } else {
                     
                        if (isRecordUpdated) {
                            const isEmergencyContactDetailsUpdated = getIsEmergencyContactDetailsUpdated(newImageObject, oldImageObject);
                            // the list of all the channels enabled by the user in new image ex. ['SMS', 'EMAIL']
                            const newPreferredNotificationList = await getAllUserPreferredChannels(newImageObject);
                            // the list of all the channels enabled by the user in old image ex. ['SMS', 'EMAIL']
                            const oldPreferredNotificationList = await getAllUserPreferredChannels(oldImageObject);
                          
                            const newOldPreferredNotificationList = Array.from(new Set([...newPreferredNotificationList, ...oldPreferredNotificationList]));
                            const notificationListFWithPinPointIdUpdated = getAvailablePreferredNotificationChannelsUniqueList(newImageObject);
                            // if the record is updated and preferred notification requires an update due to a difference then send it to customer service for pinpoint update
                            if (!areArraysEqual(newPreferredNotificationList, oldPreferredNotificationList) || isContactDetailsUpdated || isEmergencyContactDetailsUpdated) {
                                pinPointPayload = await convertToPinpointRequestDTO(newImageObject,oldImageObject, newPreferredNotificationList, newOldPreferredNotificationList,oldPreferredNotificationList, isContactDetailsUpdated);

                                if(pinPointPayload.channels.length || pinPointPayload.emergencyContacts.length) {
                                    message = {
                                        value: JSON.stringify(pinPointPayload)
                                    };
                                    log(LOG_LEVELS.INFO, "Pinpoint Payload for updated record", pinPointPayload);
                                    await sendToKafkaTopic(producer, message, TOPIC_NAME_PINPOINT_UPDATE);
                                    //send the pinpoint payload to User Profile service via MSK
                                }
                            }

                            try {
                                if(newImageObject.assignedFeatures?.optionalFeatures) {
                                    let isShareLiveLocationAccessRemoved = true;
                                    for(let feature of newImageObject.assignedFeatures.optionalFeatures) {
                                        if(feature.featureCode === 'ALC48FD8') {
                                            isShareLiveLocationAccessRemoved = false;
                                            break;
                                        }
                                    }
                                    if(isShareLiveLocationAccessRemoved) {
                                        try {
                                            const redisConfigs = await secretClient.send(
                                                new GetSecretValueCommand({
                                                  SecretId: RDS_SECRET_NAME,
                                                  VersionStage: "AWSCURRENT", 
                                                })
                                            );
                                            let secretString = JSON.parse(redisConfigs.SecretString);
                                            let redisClient;
                                            if(secretString["redis.mode"] == 'cluster') {
                                                let startupNodes = []
                                                let nodes = secretString["redis.nodes"].split(',')
                                                for(let node of nodes) {
                                                    startupNodes.push({
                                                      url: `rediss://${secretString["redis.user"]}:${secretString["redis.auth.token"]}@${node.trim()}`
                                                    })
                                                }
                                                redisClient = createCluster({
                                                    rootNodes: startupNodes,
                                                    defaults: {
                                                      username: secretString["redis.user"],
                                                      password: secretString["redis.auth.token"],
                                                      socket: {
                                                        tls: true
                                                        }
                                                    }
                                                });
                                            }else {
                                                redisClient = createClient({
                                                    url: `rediss://${secretString["redis.user"]}:${secretString["redis.auth.token"]}@${secretString["redis.host"]}:${secretString["redis.port"]}`,
                                                    socket: {
                                                        connectTimeout: parseInt(process.env.CONN_TIME_OUT)
                                                    }
                                                });   
                                            }
                                            await redisClient.connect();
                                            await redisClient.del(`${REDIS_SLL_KEY_PREFIX + newImageObject.vid + newImageObject.profileId}`);
                                            await redisClient.disconnect();
                                        } catch(error) {
                                            console.log('Connecting and Updating Redis Failed',error)
                                            log(LOG_LEVELS.ERROR, "Error while removing token from REDIS", error);
                                        }
                                    }
                                }
                            } catch(error) {
                                console.log('Share Live Location Revoke for Secondary User Error',error)
                                log(LOG_LEVELS.ERROR, "Error while removing token from REDIS", error);
                            }
                        }
                    }
                } catch (error) {
                    console.log('---PinPoint Error',error);
                    log(LOG_LEVELS.ERROR, "Error while processing data for PinPoint", error.errorMessage);
                }
                /*-------------Data preparation for sending to User management API service to update the pinpointIDs END---------*/

                /*-------------Data preparation for sending to Data service to send to MSK START---------*/
                // check if record is eligible for sending to MSK topic or not.
                if(isRecordAdded || isRecordUpdated) { 
                    //removed condition for speedUpdatedViaBLE - why is it needed? recheck.
                    const mskPaylod = await transformCustomerProfileToMSKPayload(newImageObject);
                    message = {
                        value: JSON.stringify(mskPaylod)
                    };
                    log(LOG_LEVELS.INFO, "MSK Payload17:", {mskPaylod});
                    await sendToKafkaTopic(producer, message, MSK_TOPIC_NAME, producer);
                }
                /*-------------Data preparation for sending to Data service to send to MSK END---------*/

                /*-------------Data preparation for sending to User management (Command and control) API service to send to MSK START---------*/
                //check if overlimitspeed is not equal then send to msk topic
                try {
                    if ((isRecordAdded && isDataAddedForSpeedLimitForMSK(newImageObject)) || (isRecordUpdated && isDataUpdatedForSpeedLimitForMSK(oldImageObject, newImageObject))) {
                        const mskOverSpeedCnCPayload = await transformCustomerProfileSpeedLimitToMSKPayload(newImageObject,isRecordAdded);
                        message = {
                            value: JSON.stringify(mskOverSpeedCnCPayload)
                        }
                        log(LOG_LEVELS.INFO, "Overspeed CnC Payload:", {mskOverSpeedCnCPayload});
                        console.log('-----HMCL_THOR_CMD_CONTROL_REQ_TOPIC---',mskOverSpeedCnCPayload);
                        await sendToKafkaTopic(producer, message, HMCL_THOR_CMD_CONTROL_REQ_TOPIC);
                    }
                } catch (error) {
                    log(LOG_LEVELS.ERROR, "Error while sending data to MSK for overspeed", {error : error.message});
                }
                //check there is change in geoFenceCommandStatus then send to msk topic
                try {
                    if((isRecordAdded && isDataAddedForGeoFence(newImageObject)) || (isRecordUpdated && isDataUpdatedForGeoFence(oldImageObject, newImageObject))){
                        const geoFenceCnCPayload = await transformCustomerGeofenceToMSKPayload(newImageObject);
                        message={
                            value: JSON.stringify(geoFenceCnCPayload)
                        }
                        log(LOG_LEVELS.INFO, "GeoFence CnC Payload:", {geoFenceCnCPayload});
                        console.log("-----HMCL_THOR_CMD_CONTROL_REQ_TOPIC:",HMCL_THOR_CMD_CONTROL_REQ_TOPIC);
                        await sendToKafkaTopic(producer, message, HMCL_THOR_CMD_CONTROL_REQ_TOPIC);
                    }
                } catch (error) {
                    log(LOG_LEVELS.ERROR, "Error while sending data to MSK for Geofence", {error : error.message});
                }
                /*-------------Data preparation for sending to User management (Command and control) API service to send to MSK END---------*/
            }
        } catch (error) {
            log(LOG_LEVELS.ERROR, "Error publishing message:", {error : error.message});
        } finally {
            // Disconnect producer
            log(LOG_LEVELS.INFO, "Disconnecting producer");
            await producer.disconnect();
        }
        /*-------------Connect to Kafka topic END---------*/
    } catch (err) {
        log(LOG_LEVELS.ERROR, "Error: ", {error : err.message});
    }
}

function getIsContactDetailsUpdated(newImageObject, oldImageObject) {
    return newImageObject.phone !== oldImageObject.phone || newImageObject.email !== oldImageObject.email;
}

function getIsEmergencyContactDetailsUpdated(newImageObject, oldImageObject) {
    return JSON.stringify(newImageObject.emergencyContacts) !== JSON.stringify(oldImageObject.emergencyContacts);
}

 function getCombinedFeatures(customerProfile,commandCodeSecret) {
    const combinedFeatures =  [
        ...mapStandardFeatures(
          customerProfile.assignedFeatures.defaultFeatures.filter(
            (feature) => (feature.enabled ||  feature.alertEnabled)
          ),
          customerProfile.assignedFeatures?.overSpeedLimit,
          commandCodeSecret
        ),
        ...mapStandardFeatures(
          customerProfile.assignedFeatures.optionalFeatures.filter(
            (feature) => (feature.enabled ||  feature.alertEnabled)
          ),
          customerProfile.assignedFeatures?.overSpeedLimit,
          commandCodeSecret
        ),
        ...mapStandardFeatures(
          customerProfile.assignedFeatures.subscriptionFeatures.filter(
            (feature) => (feature.enabled ||  feature.alertEnabled)
          ),
          customerProfile.assignedFeatures?.overSpeedLimit,
          commandCodeSecret
        ),
      ];
      return combinedFeatures;
}

async function transformCustomerProfileToMSKPayload(customerProfile) {
  const commandCodeSecret = await getOverSpeedSecretManagerValue();
  const combinedFeatures =  getCombinedFeatures(customerProfile,commandCodeSecret);
  const profileName = `${customerProfile.name?await getDecryptedHashedKMS(customerProfile.name):NULL}`;
  return {
    vid: customerProfile.vid,
    tenantId: customerProfile.tenantId,
    profileId: customerProfile.profileId,
    isRider: customerProfile.isRider,
    profileType: customerProfile.profileType,
    profileStatus: customerProfile.profileStatus,
    profileName,
    assignedFeatures: {
      standardFeatures: combinedFeatures,
      geofenceFeatures: mapGeofenceFeatures(
        customerProfile.assignedFeatures.geofenceFeatures.filter(
          (feature) => (feature.enabled ||  feature.alertEnabled)
        )
      ),
      timefenceFeatures: mapTimefenceFeatures(
        customerProfile.assignedFeatures.timefenceFeatures.filter(
          (feature) => (feature.enabled ||  feature.alertEnabled)
        )
      ),
    },
    profileValidTsp: customerProfile.profileValidTsp,
    createdTsp: customerProfile.createdTsp,
    updatedTsp: customerProfile.updatedTsp ?? customerProfile.createdTsp,
    accessValidFromTsp: customerProfile.accessValidFromTsp,
    accessValidTillTsp: customerProfile.accessValidTillTsp,
  };
}

function getNotificationEnabled(preferredNotification) {
    return preferredNotification && preferredNotification.length > 0 && !preferredNotification.some(notification => notification.channel === "None");
}

function mapStandardFeatures(features, overSpeedLimit, commandCodeSecret) {
  let finalFeaturesList = [];
  features.forEach((feature) => {
    if (overSpeedLimit?.commandSource === "BLE") {
      speedUpdatedViaBLE = true;
    }

    if (feature.featureCode === commandCodeSecret) {
      finalFeaturesList.push({
        code: feature.featureCode,
        name: feature.featureName,
        notificationEnabled: getNotificationEnabled(
          feature.preferredNotification
        ),
        preferredNotification:feature?.preferredNotification,
        limit: overSpeedLimit?.limit,
      });
    } else {
      finalFeaturesList.push({
        code: feature.featureCode,
        name: feature.featureName,
        preferredNotification:feature?.preferredNotification,
        notificationEnabled: getNotificationEnabled(
          feature.preferredNotification
        ),
      });
    }
  });
  return finalFeaturesList;
}

function mapGeofenceFeatures(features) {
    return features.map(feature => ({
        code: feature.code,
        name: feature.name,
        id: feature.id,
        notificationEnabled: getNotificationEnabled(feature.preferredNotification),
        isFenceTypeCircle: feature.fenceType.toLowerCase() === 'circle',
        // coordinates: feature.coordinates,
        // radius: feature.radius.toString(),
        // unit: feature.unit,
        circle: feature.circle,
        polygon: feature.polygon,
        geofenceSetBy: feature.geofenceSetBy,
        createdTsp: feature.createdTsp.toString(),
        updatedTsp: feature.updatedTsp ? feature.updatedTsp.toString() : feature.createdTsp.toString(),
        status: feature.status,
        autoImmobilisationEnabled: feature.autoImmobilisationEnabled,
        notificationSetBy: feature.notificationSetBy,
        tagProfiles: feature.tagProfiles.map(tag => ({
            taggedProfileId: tag.taggedProfileId || tag.taggedProfile,
            OptInForNotification: tag.OptInForNotification
        }))
    }));
}
function mapTimefenceFeatures(features) {
    return features.map(feature => ({
        code: feature.code,
        name: feature.name,
        notificationEnabled: getNotificationEnabled(feature.preferredNotification),
        days: feature.days,
        fromTsp: feature.fromTsp,
        toTsp: feature.toTsp
    }));
}

function validateRecordWithSchema(record) {
    // returning true since the schema is not finalized yet
    return true;
    // JOI Schema
    const schema = Joi.object({
        overSpeedAlert: Joi.object({
            enabled: Joi.boolean().required(),
            limit: Joi.number().required(),
            unit: Joi.string().required()
        }).unknown().required(),
        geoFenceAlert: Joi.object({
            enabled: Joi.boolean().required(),
            fenceType: Joi.string().required(),
            coordinates: Joi.array().items(
                Joi.object({
                    latitude: Joi.number().required(),
                    longitude: Joi.number().required()
                }).unknown().required()
            ).required(),
            radius: Joi.number().required(),
            unit: Joi.string().required(),
            geoFenceShutdown: Joi.boolean().required()
        }).unknown().required(),
        timeFenceAlert: Joi.object({
            enabled: Joi.boolean().required(),
            fromTsp: Joi.number().required(),
            toTsp: Joi.number().required(),
            timeFenceShutdown: Joi.boolean().required()
        }).unknown().required(),
    }).unknown().required();
    const customerPreferenceSchema = Joi.object({
        vid: Joi.string().required(),
        profileId: Joi.string().required(),
        alertPreference: alertPreferencesSchema,
        profileValidTsp: Joi.number().required(),
        createdTsp: Joi.number().required(),
        updatedTsp: Joi.number(),
    }).unknown();
    const { error } = schema.validate(record);
    if (error) {
        throw new Error(error);
    }

}

// This function will check if the updated data is eligible to be sent to MSK or not. Example if customer name is updated then we will not send.
function isDataUpdatedForMSK(oldRecord, newRecord) {
    // return JSON.stringify(oldRecord.assignedFeatures) !== JSON.stringify(newRecord.assignedFeatures) ||
    //     JSON.stringify(oldRecord.chargingPreference) !== JSON.stringify(newRecord.chargingPreference) ||
    //     JSON.stringify(oldRecord.trackingLocationPreference) !== JSON.stringify(newRecord.trackingLocationPreference) ||
    //     JSON.stringify(oldRecord.bluetoothConnectivityPreference) !== JSON.stringify(newRecord.bluetoothConnectivityPreference) ||
    //     JSON.stringify(oldRecord.remoteconnectivityPreference) !== JSON.stringify(newRecord.remoteconnectivityPreference)

    // if(newRecord.isRider && JSON.stringify(oldRecord.assignedFeatures) !== JSON.stringify(newRecord.assignedFeatures)) {
    //     //TODO - further check standard, geo and timefence

    // }
    return JSON.stringify(oldRecord.assignedFeatures) !== JSON.stringify(newRecord.assignedFeatures);
}

//comparision for speed limit 
function isDataUpdatedForSpeedLimitForMSK(oldRecord, newRecord) {
    console.log('-----oldRecord:',oldRecord,' -----newRecord:',newRecord);
    const oldSpeedLimit = oldRecord.assignedFeatures.overSpeedLimit.newLimit; 
    const newSpeedLimit = newRecord.assignedFeatures.overSpeedLimit.newLimit;
    const currentSpeedLimit = newRecord.assignedFeatures.overSpeedLimit.limit;
    const status = newRecord.assignedFeatures.overSpeedLimit.status;
    const commandSource = newRecord.assignedFeatures.overSpeedLimit.commandSource;
    return currentSpeedLimit!==newSpeedLimit && status === 'Pending' && commandSource === 'CLOUD';
}

function isDataAddedForSpeedLimitForMSK(newRecord){
        console.log('newRecord:',newRecord);
        let value = newRecord.assignedFeatures.overSpeedLimit?.limit; 
        
        const status = newRecord.assignedFeatures.overSpeedLimit.status;
        const commandSource = newRecord.assignedFeatures.overSpeedLimit.commandSource;
        return(value && value>0 && status === 'Pending' && commandSource === 'CLOUD');
    }
//checking change in geoFenceCommandStatus value
function isDataUpdatedForGeoFence(oldRecord, newRecord){
    if(newRecord.geoFenceCommandStatus ==='Activate-Cmd-Issued' || newRecord.geoFenceCommandStatus === 'DeActivate-Cmd-Issued'){
        return oldRecord.geoFenceCommandStatus!==newRecord.geoFenceCommandStatus;
    }
    return false;
}

function isDataAddedForGeoFence(newRecord){
    //geoFenceCommandStatus  values :  Activate-Cmd-Issued or DeActivate-Cmd-Issued
    return newRecord.geoFenceCommandStatus === GEO_FENCE_ACTIVATE_CMD_ISSUED || newRecord.geoFenceCommandStatus === GEO_FENCE_DEACTIVATE_CMD_ISSUED;
}

function getAvailablePreferredNotificationChannelsUniqueList(newRecord) {
    // check if preferredNotificationChannels object is already available or not
    const channelSet = new Set();
    if (newRecord.hasOwnProperty("preferredNotificationChannel") && Array.isArray(newRecord.preferredNotificationChannels)) {
        newRecord.preferredNotificationChannels.forEach((notification) => {
            if (notification.name) {
                channelSet.add(notification.name);
            }
        });
    }
    return Array.from(channelSet);
}

async function getAllUserPreferredChannels(newRecord) {
   const commandCodeSecret = await getOverSpeedSecretManagerValue();
    const channels = new Set();
    // TODO - confirm with Karthik and create an enum
    const allAvailableChannels = [NOTIFICATION_CHANNEL.EMAIL, NOTIFICATION_CHANNEL.SMS, NOTIFICATION_CHANNEL.PUSH];
    const channelsArr = [];
    const combinedFeatures =  getCombinedFeatures(newRecord,commandCodeSecret);
    extractChannels(combinedFeatures, channels);
    extractChannels(newRecord?.assignedFeatures?.geofenceFeatures, channels);
    extractChannels(newRecord?.assignedFeatures?.timefenceFeatures, channels);
    if (channels.has(NOTIFICATION_CHANNEL.ALL)) {
        return allAvailableChannels;
    }
    if (channels.has(NOTIFICATION_CHANNEL.EMAIL)) {
        channelsArr.push(NOTIFICATION_CHANNEL.EMAIL);
    }
    if (channels.has(NOTIFICATION_CHANNEL.SMS)) {
        channelsArr.push(NOTIFICATION_CHANNEL.SMS);
    }
    if (channels.has(NOTIFICATION_CHANNEL.PUSH)) {
        channelsArr.push(NOTIFICATION_CHANNEL.PUSH);
    }
    return channelsArr;

}

function extractChannels(featuresArr, channelsSet) {
    for (const features of featuresArr) {
        for (const key in features) {
            if (key === "preferredNotification" && features.hasOwnProperty(key)) {
                //TODO - validate preferredNotification schema
                for (const channelObj of features[key]) {
                    channelsSet.add(channelObj.channel);
                }
            }
        }
    }
    return channelsSet;
}

function areArraysEqual(existingPreferredNotificationChannel, updatedPreferredNotificationChannel) {
    if (existingPreferredNotificationChannel.length !== updatedPreferredNotificationChannel.length) {
        return false;
    } let existingPreferredNotificationChannelSet = new Set(existingPreferredNotificationChannel);
    let updatedPreferredNotificationChannelSet = new Set(updatedPreferredNotificationChannel);
    if (existingPreferredNotificationChannelSet.size !== updatedPreferredNotificationChannelSet.size) {
        return false;
    }
    for (let item of existingPreferredNotificationChannelSet) {
        if (!updatedPreferredNotificationChannelSet.has(item)) {
            return false;
        }
    }
    for (let item of updatedPreferredNotificationChannelSet) {
        if (!existingPreferredNotificationChannelSet.has(item)) {
            return false;
        }
    }
    return true;
}

async function getDecryptedHashedKMS(valueToDecrypt) {
    console.log('valueToDecrypt:',valueToDecrypt);
    const config = { region: REGION };
    const client = new KMSClient(config);
    const input = {
      CiphertextBlob: Buffer.from(valueToDecrypt, 'base64'), 
      KeyId: KMS_KEY,
    };
    const command = new DecryptCommand(input);
    const response = await client.send(command);
    console.log('response12:',response);
    return new TextDecoder('utf-8').decode(response.Plaintext);
  }


async function convertToPinpointRequestDTO(newImageObject, oldImageObject, newPreferredNotificationList, newOldPreferredNotificationList, oldPreferredNotificationList, isContactDetailsUpdated) {
    const channelsArr = [];
    const emergencyContactsArr =  await generateEmergencyContactsPayload(oldImageObject, newImageObject);
    console.log('emergencyContactsArr:',emergencyContactsArr);
    newOldPreferredNotificationList.filter((channel)=>{
        if(isContactDetailsUpdated) {
            return true;
        } else {
            if((oldPreferredNotificationList.indexOf(channel) === -1 && newPreferredNotificationList.indexOf(channel) > -1)
            || newPreferredNotificationList.indexOf(channel) === -1 && oldPreferredNotificationList.indexOf(channel) > -1) {
                return true;
            } else {
                return false;
            }
        }
    }).forEach((channel) => {
        channelsArr.push({
            name: channel,
            action: getNotificationChannelAction(channel, newPreferredNotificationList, oldPreferredNotificationList, isContactDetailsUpdated)
        })
    })

    console.log('---name after the decryption6: ', newImageObject.phone?await getDecryptedHashedKMS(newImageObject.phone):NULL);
    console.log('---name after the decryption5: ', newImageObject.email?await getDecryptedHashedKMS(newImageObject.email):NULL);

    return {
        vid: newImageObject.vid,
        tenantId: newImageObject.tenantId,
        profileId: newImageObject.profileId,
       // name: await getDecryptedHashedKMS(newImageObject.name),
        phone: `${newImageObject?.countryCode}${newImageObject.phone?await getDecryptedHashedKMS(newImageObject.phone):NULL}`,
        email: newImageObject.email?await getDecryptedHashedKMS(newImageObject.email):NULL,
        channels: [...channelsArr],
        emergencyContacts: [...emergencyContactsArr],
    }
}

function getNotificationChannelAction(channel, newPreferredNotificationList, oldPreferredNotificationList, isContactDetailsUpdated) {
    if (newPreferredNotificationList.indexOf(channel) === -1 && oldPreferredNotificationList.indexOf(channel) > -1) {
        return NOTIFICATION_CHANNEL_ACTION.DELETE;
    } else {
        // record is added
        if(oldPreferredNotificationList.indexOf(channel) === -1 && newPreferredNotificationList.indexOf(channel) > -1 ) {
            return NOTIFICATION_CHANNEL_ACTION.CREATE;
        } else {
            // record contact details are updated
            if(isContactDetailsUpdated) {
                return NOTIFICATION_CHANNEL_ACTION.UPDATE;
            }
        }
    }
}

 async function generateEmergencyContactsPayload(oldImage, newImage) {
    const oldContacts = oldImage?.emergencyContacts || [];
    const newContacts = newImage?.emergencyContacts || [];
    const payload = [];
    // Iterate through new contacts to find creates and updates
    await Promise.all(newContacts.map(async newContact => {
        const oldContact = oldContacts.find(contact => contact.id === newContact.id);
        if (oldContact) {
            const oldContactNumber = await getDecryptedHashedKMS(oldContact.phoneNumber);
            const newContactNumber = await getDecryptedHashedKMS(newContact.phoneNumber);
            // If the contact exists in old image, check if it was updated
            if (oldContactNumber !== newContactNumber ) {
                payload.push({
                    id: newContact.id,
                    //name: newContact.name,
                    phone: `${newContact?.countryCode}${newContact.phoneNumber?await getDecryptedHashedKMS(newContact.phoneNumber):NULL}`,
                    action: NOTIFICATION_CHANNEL_ACTION.UPDATE
                });
            } 
        } else {
            // If the contact does not exist in old image, it's a new contact
            payload.push({
                id: newContact.id,
                //name: newContact.name,
                phone: `${newContact?.countryCode}${newContact.phoneNumber?await getDecryptedHashedKMS(newContact.phoneNumber):NULL}`,
                action: NOTIFICATION_CHANNEL_ACTION.CREATE
            });
        }
    }));
    // Iterate through old contacts to find deletions
    await Promise.all(oldContacts.map(async oldContact => {
        const newContact = newContacts.find(contact => contact.id === oldContact.id);
        if (!newContact) {
            payload.push({
                id: oldContact.id,
                //name: oldContact.name,
                phone: `${oldContact?.countryCode}${oldContact.phoneNumber?await getDecryptedHashedKMS(oldContact.phoneNumber):NULL}`,
                action: NOTIFICATION_CHANNEL_ACTION.DELETE
            });
        }
    }));
    return payload;
}

async function transformCustomerProfileSpeedLimitToMSKPayload(customerProfile,isRecordAdded) {
    let speedLimitValue = customerProfile.assignedFeatures.overSpeedLimit.limit;
    if(!isRecordAdded) {
        speedLimitValue = customerProfile.assignedFeatures.overSpeedLimit.newLimit;
    } 
    const commandCodeSecret = await getOverSpeedSecretManagerValue();
   
    return {
        vehicleIdentifier: customerProfile.vid,
        profileId: customerProfile.profileId,
        userType: "CUSTOMER",
        commandCode: commandCodeSecret,
        value: speedLimitValue,
        commandType: `NON_UDS`,
        commandSource: "CLOUD",
    };
}

async function transformCustomerGeofenceToMSKPayload(customerProfile) {
    const commandCodeSecret = await getOverGeofenceManagerValue();
    return {
        vehicleIdentifier: customerProfile.vid,
        profileId: customerProfile.profileId,
        userType: "CUSTOMER",
        commandCode: commandCodeSecret,
        value: customerProfile.geoFenceCommandStatus === GEO_FENCE_ACTIVATE_CMD_ISSUED ? true : false,
        commandType: 'NON_UDS',
        commandSource: "CLOUD",
    };
}

async function sendToKafkaTopic(producer, message, topicName) {
    try {
        log(LOG_LEVELS.INFO, "Sending message to topic", {topicName});
        let messageToBeProducedToKafka = {
            topic: topicName,
            messages: [message]
        };
        await producer.send(messageToBeProducedToKafka);
        log(LOG_LEVELS.INFO, "Message sent to kafka topic", {topicName});
    } catch (error) {
        log(LOG_LEVELS.ERROR, "Error while sending message to topic", {error : error.message, topicName: topicName});
    }
}