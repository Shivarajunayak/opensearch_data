import {
    CognitoIdentityProviderClient,
    AdminUpdateUserAttributesCommand
} from "@aws-sdk/client-cognito-identity-provider";
import { SecretsManagerClient, GetSecretValueCommand } from "@aws-sdk/client-secrets-manager";

const cognitoClient = new CognitoIdentityProviderClient({});
const secretsManagerClient = new SecretsManagerClient({});

export const handler = async function(event, context) {
    context.callbackWaitsForEmptyEventLoop = false;

    const defaultVendorRole = process.env.DEFAULT_VENDOR_USER_ROLE_NAME
    const defaultInternalRole = process.env.DEFAULT_INTERNAL_USER_ROLE_NAME
    const externalUser = process.env.EXTERNAL_USER
    const internalUser = process.env.INTERNAL_USER

    console.log("Event data:", event);

    const userPoolId = event.userPoolId;
    const username = event.userName;
    const userAttributes = event.request.userAttributes;
    const useremail = userAttributes['email'];

    let role = userAttributes['custom:role'] || '';
    let usertype = userAttributes['custom:usertype'] || '';

    const isExternal = useremail && useremail.includes('.ext');

    // Get admin email list from Secrets Manager
    const adminEmailList = await getAdminEmailList();

    if (!role && adminEmailList.includes(useremail)) {
        console.log("Setting master admin role for useremail", useremail);
        role = 'ThorDefaultMasterAdminInternal';
        usertype = internalUser;
    } else if (!role && !usertype) {
        role = isExternal ? defaultVendorRole : defaultInternalRole;
        usertype = isExternal ? externalUser : internalUser;
    }

    console.log("role name:", role);

    const attributes = [];

    if (!userAttributes['custom:role']) {
        attributes.push({ Name: "custom:role", Value: role });
    }

    if (!userAttributes['custom:usertype']) {
        attributes.push({ Name: "custom:usertype", Value: usertype });
    }

    if (attributes.length === 0) {
        console.log("No attributes need to be updated.");
        event.response = {
            "claimsAndScopeOverrideDetails": {
                "accessTokenGeneration": {
                    "claimsToAddOrOverride": {
                        "CustomRole": role
                    }
                },
                "idTokenGeneration": {
                    "claimsToAddOrOverride": {
                        "User": username,
                        "CustomRole": role,
                        "CustomUserType": usertype
                    }
                }
            }
        };
        console.log("event.response", event.response);
        context.done(null, event);
        return;
    }

    const params = {
        UserPoolId: userPoolId,
        Username: username,
        UserAttributes: attributes
    };

    try {
        const data = await cognitoClient.send(new AdminUpdateUserAttributesCommand(params));
        console.log("User attributes updated successfully:", data);
        event.response = {
            "claimsAndScopeOverrideDetails": {
                "accessTokenGeneration": {
                    "claimsToAddOrOverride": {
                        "CustomRole": role
                    }
                },
                "idTokenGeneration": {
                    "claimsToAddOrOverride": {
                        "User": username,
                        "CustomRole": role,
                        "CustomUserType": usertype
                    }
                }
            }
        };
    } catch (error) {
        console.error("Error updating user attributes:", error);
        context.done(error, event);
        return;
    }
    console.log("End Event data:", event);
    // Return to Amazon Cognito
    context.done(null, event);
};

async function getAdminEmailList() {
    let secretArn = process.env.ADMIN_EMAIL_LIST_SECRET_ARN;
    if (!secretArn) {
        console.error("ADMIN_EMAIL_LIST_SECRET_ARN environment variable is not set.");
        return [];
    }

    try {
        const data = await secretsManagerClient.send(new GetSecretValueCommand({ SecretId: secretArn }));
        const secretValue = data.SecretString;
        console.log("secretValue", secretValue);
        // Parse the JSON string
        const parsedValue = JSON.parse(secretValue);

        // Extract the admin email IDs from the admin_mailids property
        const adminEmailList = parsedValue.admin_mailids.split(',');

        console.log("adminEmailList", adminEmailList);
        return adminEmailList;
    } catch (error) {
        console.error("Error retrieving admin email list from Secrets Manager:", error);
        return [];
    }
}