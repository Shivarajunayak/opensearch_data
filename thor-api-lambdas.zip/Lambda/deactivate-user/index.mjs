import { CognitoIdentityProviderClient, ListUsersCommand, AdminDeleteUserCommand } from "@aws-sdk/client-cognito-identity-provider";

const USER_POOL_ID = process.env.USER_POOL_ID;
const INACTIVITY_DAYS = parseInt(process.env.INACTIVITY_DAYS);
const REGION = process.env.REGION;
const client = new CognitoIdentityProviderClient({ region: REGION });


const LOG_LEVELS_ENUM = {
    INFO: 2,
    ERROR: 0,
    WARN: 1,
}
const LOG_LEVELS = {
    INFO: "INFO",
    ERROR: "ERROR",
    WARN: "WARN",
}
const LOG_LEVEL = process.env.LOG_LEVEL || "INFO";

const shouldLog = (level) => {
    return LOG_LEVELS_ENUM[level] <= LOG_LEVELS_ENUM[LOG_LEVEL];
}

// Custom logger function
const log = (level, message, meta = {}) => {
    switch (level) {
        case LOG_LEVEL.INFO:
            if(shouldLog(level)) {
                console.log(JSON.stringify({ level, message, ...meta }));
            }
            break;
        case LOG_LEVEL.ERROR:
            if(shouldLog(level)) {
                console.error(JSON.stringify({ level, message, ...meta }));
            }
            break;
        case LOG_LEVEL.WARN:
            if(shouldLog(level)) {
                console.warn(JSON.stringify({ level, message, ...meta }));
            }
            break;
        default:
            if(shouldLog(level)) {
                console.log(JSON.stringify({ level, message, ...meta }));
            }
            break;
    }
};

export const handler = async (event) => {
    try {
        let users = await listAllDeactiveUsers(USER_POOL_ID);
        let cutoffDate = new Date();
        cutoffDate.setDate(cutoffDate.getDate() - INACTIVITY_DAYS);

        for (let user of users) {
            // let lastModifiedDateAttr = user.Attributes.find(attr => attr.Name === 'userLastModifiedDate');
            let userLastModifiedDate = user.UserLastModifiedDate;
            if (userLastModifiedDate) {
                let lastModifiedDate = new Date(userLastModifiedDate);
                if (lastModifiedDate < cutoffDate) {
                    await deleteUser(USER_POOL_ID, user.Username);
                    log(LOG_LEVELS.INFO, `Deleted user ${user.Username} due to inactivity.`, {user});
                }
            }
        }

        return {
            statusCode: 200,
            body: 'Inactive users deletion process completed.'
        };
    } catch (error) {
        log(LOG_LEVELS.ERROR, "Error occurred while deleting inactive users.", error);
        return {
            statusCode: 500,
            body: 'Error occurred while deleting inactive users.'
        };
    }
};

const listAllDeactiveUsers = async (userPoolId) => {
    let users = [];
    let paginationToken;
    let params = {
        UserPoolId: userPoolId,
        // AttributesToGet: ['name'],
        // UserLastModifiedDate
        // Filter: "\"UserLastModifiedDate\"^=\"2024-07-04T05:21:25.428Z\"",

    };

    do {
        const command = new ListUsersCommand({ ...params, PaginationToken: paginationToken });
        const response = await client.send(command);
        users = users.concat(response.Users);
        paginationToken = response.PaginationToken;
    } while (paginationToken);

    // const command = new ListUsersCommand(input);
    // const response = await client.send(command);

    return users;
};

const deleteUser = async (userPoolId, username) => {
    log(LOG_LEVELS.INFO, `Deleting user ${username} due to inactivity.`, {username});
    const params = {
        UserPoolId: userPoolId,
        Username: username
    };
    const command = new AdminDeleteUserCommand(params);
    await client.send(command);
};
