import { handler } from "../index.mjs";
describe("testHandler", () => {

  it("Should check that TCU exist", async () => {
    const event = {
      DevicePayload: {
        Item: {
          VehicleStatus: {
            S: "Active",
          },
          TCU_ID: {
            S: "TCU-uk-test-1",
          },
        },
      },
      TCU_ID: "TCU-uk-test-1",
    };
    try {
      const response = await handler(event);
      expect(response.statusCode).toBe(400);
    } catch (error) {
      console.log(error)
      expect(error.statusCode).toBe(400);
    }
  });

  it("Should check that Vehicle is DECOMMISSIONED", async () => {
    const event = {
      DevicePayload: {
        Item: {
          VehicleStatus: {
            S: "DECOMMISSIONED",
          },
          TCU_ID: {
            S: "TCU-uk-test1-1",
          },
        },
      },
      TCU_ID: "TCU-uk-test1-1",
    };
    try {
      const response = await handler(event);
      expect(response.statusCode).toBe(400);
    } catch (error) {
      console.log(error)
      expect(error.statusCode).toBe(400);
    }
  });

  it("should check for TCUID_NOT_FOUND", async () => {
    const event = {
      "VALIDATE_TCU_FOR_DELINKED_VIN" : {},
      "TCUPayload": {}
    };
    try {
      const response = await handler(event);
      expect(response.statusCode).toBe(400);
    } catch (error) {
      console.log(error)
      expect(error.statusCode).toBe(400);
    }
  })

  it("should check for TCUID_IS_ALREADY_LINKED_TO_ANOTHER_VIN", async () => {
    const event = {
      VALIDATE_TCU_FOR_DELINKED_VIN : {
        Items: [{
          TCU_ID: {
            S: "TCU-uk-test1-1",
          },
        }]
      },
      TCUPayload: {
        Item: {}
      }
      
    };
    console.log("TCUID_IS_ALREADY_LINKED_TO_ANOTHER_VIN",event.VALIDATE_TCU_FOR_DELINKED_VIN.Items[0].TCU_ID.S)
    try {
      const response = await handler(event);
      expect(response.statusCode).toBe(400);
    } catch (error) {
      console.log(error)
      expect(error.statusCode).toBe(400);
    }
  })

  it("Should check that TCU_ID_MISMATCH", async () => {
    const event = {
      DevicePayload: {
        Item: {
          TCU_ID: {
            S: "TCU-uk-test1-1",
          },
          VehicleStatus: {
            S: "Active",
          }
        },
      },
      TCU_ID: "TCU-uk-test1-2",
    };
    try {
      const response = await handler(event);
      expect(response.statusCode).toBe(400);
    } catch (error) {
      console.log(error)
      expect(error.statusCode).toBe(400);
    }
  });
});
