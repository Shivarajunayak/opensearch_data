export const handler = async (event) => {
    console.log(event);
    let errorMessage = "INTERNAL_SERVER_ERROR";
    if (event.hasOwnProperty("VALIDATE_TCU_FOR_DELINKED_VIN") || event.hasOwnProperty("VALIDATE_TCU_FOR_NEW_VIN")) {
      if (Object.keys(event.MaskedPayload.Payload.tcuData).length == 0) {
        errorMessage = "TCUID_NOT_FOUND";
      } else if (event.VALIDATE_TCU_FOR_DELINKED_VIN?.Items[0]?.TCU_ID.S || event.VALIDATE_TCU_FOR_NEW_VIN?.Items[0]?.TCU_ID.S) {
        errorMessage = "TCUID_IS_ALREADY_LINKED_TO_ANOTHER_VIN";
      }
    } else if (event.MaskedPayload.Payload?.data) {
      errorMessage = `IoT Resource Not Found,\n${event.MaskedPayload.Payload.data}`;
    } else if (event.DevicePayload.Item) {
      if (
        event.DevicePayload.Item.VehicleStatus.S === "DECOMMISSIONED" &&
        event.DevicePayload.Item.TCU_ID.S === event.TCU_ID
      ) {
        errorMessage = "VEHICLE_DECOMISSIONED";
      } else if (event.DevicePayload.Item.TCU_ID.S !== "NULL" && event.TCU_ID !== event.DevicePayload.Item.TCU_ID.S) {
        errorMessage = "TCUID_MISMATCH";
      }
    } else if(!event.TCUPayload?.Item) {
      errorMessage = "TCU_NOT_FOUND";
    }
    const error = new Error(errorMessage);
    error.status = "FAILED";
    error.statusCode = 400;
    error.stack = "";
    throw error;
  };
  