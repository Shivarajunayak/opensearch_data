import { handler } from '../index.mjs';
import { mockClient } from 'aws-sdk-client-mock';
import { ACMPCAClient, CreateCertificateAuthorityCommand,GetCertificateAuthorityCsrCommand,IssueCertificateCommand,GetCertificateCommand,ImportCertificateAuthorityCertificateCommand,DeleteCertificateAuthorityCommand,ListCertificateAuthoritiesCommand,GetCertificateAuthorityCertificateCommand,UpdateCertificateAuthorityCommand } from "@aws-sdk/client-acm-pca"; 
import { SSMClient, GetParameterCommand, PutParameterCommand } from '@aws-sdk/client-ssm';
import { STSClient, AssumeRoleCommand } from '@aws-sdk/client-sts';
import { IoTClient,RegisterCACertificateCommand,ListCACertificatesCommand } from "@aws-sdk/client-iot"; 
import fs from 'fs';
import {
  SecretsManagerClient,
  GetSecretValueCommand,
} from "@aws-sdk/client-secrets-manager";

describe("testHandler", () => {
    it("If parameter name were not passed then it should return statusCode 500", async () => {

        const event = {
          "secretPassword": "password@1234"
        };
       
        const sTSClientMock = mockClient(STSClient); 
        sTSClientMock.on(AssumeRoleCommand).resolves({Credentials:{ AccessKeyId:'XXXXXX', SecretAccessKey:'XXXXXX', SessionToken:'XXXXXX'}}); 

        const sSMClientMock = mockClient(SSMClient);                
        sSMClientMock.on(GetParameterCommand).resolves({Parameter:{Value:'XXXXXXXXXXX'}}); 
        sSMClientMock.on(PutParameterCommand).resolves({}); 

        const aCMPCAClientMock = mockClient(ACMPCAClient);                
        aCMPCAClientMock.on(IssueCertificateCommand).resolves({CertificateArn:'XXXXXXXXXXX'}); 
        aCMPCAClientMock.on(GetCertificateCommand).resolves({Certificate:'XXXXXXXX',CertificateChain:'XXXXXXX'}); 
        aCMPCAClientMock.on(CreateCertificateAuthorityCommand).resolves({CertificateAuthorityArn:'XXXXXXXXX'}); 
        aCMPCAClientMock.on(ImportCertificateAuthorityCertificateCommand).resolves({}); 
        aCMPCAClientMock.on(DeleteCertificateAuthorityCommand).resolves({
            CertificateAuthorities : [{
              Status : "ACTIVE",
              Type:'SUBORDINATE',
              Arn:'XXXXXXXXX'
            }]
          });
        aCMPCAClientMock.on(ListCertificateAuthoritiesCommand).resolves({
            CertificateAuthorities : [{
              Status : "ACTIVE",
              Type:'SUBORDINATE',
              Arn:'XXXXXXXXX'
            }]
          });
        aCMPCAClientMock.on(GetCertificateAuthorityCertificateCommand).resolves({CertificateAuthorityArn:'XXXXXXXX'});
        aCMPCAClientMock.on(UpdateCertificateAuthorityCommand).resolves({});
         
        aCMPCAClientMock.on(GetCertificateAuthorityCsrCommand).resolves({Csr:'XXXXXXXX'});
        
        const ioTClientMock = mockClient(IoTClient);                
        ioTClientMock.on(RegisterCACertificateCommand).resolves({certificateId:'XXXXXXXX'}); 
        ioTClientMock.on(ListCACertificatesCommand).resolves({certificateId:'XXXXXXXX'}); 
        
        const secretsManagerMock = mockClient(SecretsManagerClient);
        secretsManagerMock.on(GetSecretValueCommand).resolves({
          SecretString: JSON.stringify({
              "validationPassword":"password@1234"
          })
        });
        //handler.on()  
        const response = await handler(event);
        console.log('test response:',response);
        expect(response.statusCode).toBe(500);

    },30000);

    it("DELETED and ROOT certificate check should return statusCode 200", async () => {

        const event = {
          "secretPassword": "password@1234"
        };
       
        const sTSClientMock = mockClient(STSClient); 
        sTSClientMock.on(AssumeRoleCommand).resolves({Credentials:{ AccessKeyId:'XXXXXX', SecretAccessKey:'XXXXXX', SessionToken:'XXXXXX'}}); 

        const sSMClientMock = mockClient(SSMClient);                
        sSMClientMock.on(GetParameterCommand).resolves({Parameter:{Value:'XXXXXXXXXXX'}}); 
        sSMClientMock.on(PutParameterCommand).resolves({}); 

        const aCMPCAClientMock = mockClient(ACMPCAClient);                
        aCMPCAClientMock.on(IssueCertificateCommand).resolves({CertificateArn:'XXXXXXXXXXX'}); 
        aCMPCAClientMock.on(GetCertificateCommand).resolves({Certificate:'XXXXXXXX',CertificateChain:'XXXXXXX'}); 
        aCMPCAClientMock.on(CreateCertificateAuthorityCommand).resolves({CertificateAuthorityArn:'XXXXXXXXX'}); 
        aCMPCAClientMock.on(ImportCertificateAuthorityCertificateCommand).resolves({}); 
        aCMPCAClientMock.on(DeleteCertificateAuthorityCommand).resolves({
            CertificateAuthorities : [{
              Status : "DELETED",
              Type:'ROOT',
              Arn:'XXXXXXXXX'
            }]
          });
        aCMPCAClientMock.on(ListCertificateAuthoritiesCommand).resolves({
            CertificateAuthorities : [{
              Status : "DELETED",
              Type:'ROOT',
              Arn:'XXXXXXXXX'
            }]
          });
        aCMPCAClientMock.on(GetCertificateAuthorityCertificateCommand).resolves({CertificateAuthorityArn:'XXXXXXXX'});
        aCMPCAClientMock.on(UpdateCertificateAuthorityCommand).resolves({});
         
        aCMPCAClientMock.on(GetCertificateAuthorityCsrCommand).resolves({Csr:'XXXXXXXX'});
        
        const ioTClientMock = mockClient(IoTClient);                
        ioTClientMock.on(RegisterCACertificateCommand).resolves({certificateId:'XXXXXXXX'}); 
        ioTClientMock.on(ListCACertificatesCommand).resolves({certificateId:'XXXXXXXX'}); 
        
        const secretsManagerMock = mockClient(SecretsManagerClient);
        secretsManagerMock.on(GetSecretValueCommand).resolves({
          SecretString: JSON.stringify({
              "validationPassword":"password@1234"
          })
        });

        const response = await handler(event);
        console.log('test response:',response);
        expect(response.statusCode).toBe(500);

    },30000);

    it("Excelfore API status should return statusCode 200", async () => {
        
        process.env.COMMON_NAME='Rohit Prasad';
        process.env.INTERMEDIATE_ACP_PCA_NAME='Rohit Prasad';
        process.env.PARAMETER_STORE_NAME='XXXXXXXXXXXXX';
        process.env.SHARED_PARAMETER_STORE_NAME='XXXXXXXXXXXXX';
        process.env.SHARED_ROLE_ARN='arn:aws:iam::211125359537:role/hmcl-cv-audit-acmpca-role';
        process.env.VALIDITY=5;
        process.env.VALIDITY_TYPE='YEARS';

        const event = {
          "secretPassword": "password@1234"
        };
       
        const sTSClientMock = mockClient(STSClient); 
        sTSClientMock.on(AssumeRoleCommand).resolves({Credentials:{ AccessKeyId:'XXXXXX', SecretAccessKey:'XXXXXX', SessionToken:'XXXXXX'}}); 

        const sSMClientMock = mockClient(SSMClient);                
        sSMClientMock.on(GetParameterCommand).resolves({Parameter:{Value:'XXXXXXXXXXX'}}); 
        sSMClientMock.on(PutParameterCommand).resolves({}); 

        const aCMPCAClientMock = mockClient(ACMPCAClient);                
        aCMPCAClientMock.on(IssueCertificateCommand).resolves({CertificateArn:'XXXXXXXXXXX'}); 
        aCMPCAClientMock.on(GetCertificateCommand).resolves({Certificate:'XXXXXXXX',CertificateChain:'XXXXXXX'}); 
        aCMPCAClientMock.on(CreateCertificateAuthorityCommand).resolves({CertificateAuthorityArn:'XXXXXXXXX'}); 
        aCMPCAClientMock.on(ImportCertificateAuthorityCertificateCommand).resolves({}); 
        aCMPCAClientMock.on(DeleteCertificateAuthorityCommand).resolves({
            CertificateAuthorities : [{
              Status : "ACTIVE",
              Type:'SUBORDINATE',
              Arn:'XXXXXXXXX'
            }]
          });
        aCMPCAClientMock.on(ListCertificateAuthoritiesCommand).resolves({
            CertificateAuthorities : [{
              Status : "ACTIVE",
              Type:'SUBORDINATE',
              Arn:'XXXXXXXXX'
            }]
          });
        aCMPCAClientMock.on(GetCertificateAuthorityCertificateCommand).resolves({CertificateAuthorityArn:'XXXXXXXX',Certificate:fs.readFileSync('public-cert.pem')});

        aCMPCAClientMock.on(UpdateCertificateAuthorityCommand).resolves({});
         
        aCMPCAClientMock.on(GetCertificateAuthorityCsrCommand).resolves({Csr:'XXXXXXXX'});
        
        const ioTClientMock = mockClient(IoTClient);                
        ioTClientMock.on(RegisterCACertificateCommand).resolves({certificateId:'XXXXXXXX'}); 
        ioTClientMock.on(ListCACertificatesCommand).resolves({certificateId:'XXXXXXXX'}); 

        const secretsManagerMock = mockClient(SecretsManagerClient);
        secretsManagerMock.on(GetSecretValueCommand).resolves({
          SecretString: JSON.stringify({
              "validationPassword":"password@1234"
          })
        });
        const response = await handler(event);
        expect(response.statusCode).toBe(200);

    },30000);

});