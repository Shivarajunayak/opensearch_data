import { ACMPCAClient, CreateCertificateAuthorityCommand,GetCertificateAuthorityCsrCommand,IssueCertificateCommand,GetCertificateCommand,ImportCertificateAuthorityCertificateCommand,DeleteCertificateAuthorityCommand,ListCertificateAuthoritiesCommand,GetCertificateAuthorityCertificateCommand,UpdateCertificateAuthorityCommand } from "@aws-sdk/client-acm-pca"; 
import { SSMClient, GetParameterCommand, PutParameterCommand } from '@aws-sdk/client-ssm';
import { STSClient, AssumeRoleCommand } from '@aws-sdk/client-sts';
import { IoTClient,RegisterCACertificateCommand,ListCACertificatesCommand } from "@aws-sdk/client-iot"; 
import { X509Certificate } from 'crypto';
import {
  SecretsManagerClient,
  GetSecretValueCommand,
} from "@aws-sdk/client-secrets-manager";

// Create an ACM PCA client
const config = { region: process.env.AWS_REGION };
const acmPcaClient = new ACMPCAClient(config);
const stsClient = new STSClient({ config });
const ssmClient = new SSMClient(config);
const iotClient = new IoTClient(config);

const secretKeyName = process.env.SECRET_KEY_NAME

//initialize secretmanager client
const client = new SecretsManagerClient({
  region: process.env.REGION
});


let acmPcaClientForSharedAccount;

//Add delay in the response
const delay = ms => new Promise(resolve => setTimeout(resolve, ms));

async function getSharedAccountClient() {
  // settings for the Assume the role from the shared account
  const assumeRoleCommand = new AssumeRoleCommand({
    RoleArn: process.env.SHARED_ROLE_ARN,
    RoleSessionName: 'LambdaSession',
  });

  const assumeRoleResponse = await stsClient.send(assumeRoleCommand);
  console.log('assumeRoleResponse:',assumeRoleResponse);
  const { AccessKeyId, SecretAccessKey, SessionToken } = assumeRoleResponse.Credentials;
  // Create an SSM client with the assumed role credentials
  return new ACMPCAClient({
  region: process.env.AWS_REGION,
  credentials: {
    accessKeyId: AccessKeyId,
    secretAccessKey: SecretAccessKey,
    sessionToken: SessionToken,
  },
  });
}

//Create new ACM PCA certificate
async function createNewAcmPca() {
    const params = {
      CertificateAuthorityConfiguration: {
        KeyAlgorithm: "RSA_2048",
        SigningAlgorithm: "SHA256WITHRSA",
        Subject: {
          CommonName: process.env.COMMON_NAME,
        }
      },
      CertificateAuthorityType: "SUBORDINATE",
    };

    const command = new CreateCertificateAuthorityCommand(params);
    const response = await acmPcaClient.send(command);
    await delay(5000);
    return {
       CertificateAuthorityArn: response.CertificateAuthorityArn
    };
}

//Get the Intermediate Certificate CSR file
async function GetIntermediateCertificateCSR(CertificateAuthorityArn) {
    const caArn = CertificateAuthorityArn;
    // Create the GetCertificateAuthorityCsrCommand with the CA ARN
    const command = new GetCertificateAuthorityCsrCommand({
      CertificateAuthorityArn: caArn,
    });

    // Send the command to ACM PCA to get the CSR
    const response = await acmPcaClient.send(command);
    
    return {
      CSR: response.Csr
    };
}

//Capture Root CA ARN from the shared account Parameter Store
async function GetCaArnFromSharedParameterStore() {
  
  const parameterName = process.env.SHARED_PARAMETER_STORE_NAME;
    if (!parameterName) {
      throw new Error('Parameter name is required');
    }

    // Set up the GetParameterCommand to retrieve the Root CA ARN
    const getParameterCommand = new GetParameterCommand({
      Name: parameterName,
      WithDecryption: true,
    });

    // Send the command to the SSM client
    const response = await ssmClient.send(getParameterCommand);
    console.log("response:",response);
    const rootCaArn = response.Parameter.Value;
    return {
      rootCaArn
    };
}

//Get the Certificate CSR Signed by RootCA
async function GetCertificateCsrSignedByRootCA(caArn, csrUint8Array, validity, validity_type) {
    let input = {
        CertificateAuthorityArn: caArn,
        Csr: csrUint8Array,
        SigningAlgorithm: "SHA256WITHRSA",
        TemplateArn: "arn:aws:acm-pca:::template/SubordinateCACertificate_PathLen0_APIPassthrough/V1",
        Validity: {
            Value: validity,
            Type: validity_type,
        },
        Subject: {
            CommonName: process.env.COMMON_NAME
         },
         BasicConstraints : "CA:TRUE, pathlen: 0"
    };
    
    console.log("IssueCertificateCommand payload. \n", input);
    let command = new IssueCertificateCommand(input);
    const issueCertResponse = await acmPcaClientForSharedAccount.send(command);
    await delay(5000);
    return { CertificateArn : issueCertResponse.CertificateArn };
}

//Convert CSR for to be used as encoded
function GenerateEncodedCSR(CSR) {
    const encodedCSR = new TextEncoder().encode(CSR);
    return { encodedCSR };
}

//Store the ACM PCA ARN in the parameter store

async function StoreAcmPcaArnInParameterStore(CertificateAuthorityArn) {
  const putParameterCommand = new PutParameterCommand({
    Name: process.env.PARAMETER_STORE_NAME,
    Value: CertificateAuthorityArn,
    Type: "SecureString", 
    Overwrite: true, 
  });
  
  const storeParameterARN = await ssmClient.send(putParameterCommand);
  return storeParameterARN;
}

//Get certificate and chain certificate from ACM PCA
async function getCertificateAndCertificateChainFromAcmPca(CertificateArn,rootCaArn) {
  
    const params = {
      CertificateArn: CertificateArn,
      CertificateAuthorityArn : rootCaArn
    }; 
    const command = new GetCertificateCommand(params);
    const response = await acmPcaClientForSharedAccount.send(command);
    
    //Return the certificate details
    return {
        Certificate: response.Certificate,
        CertificateChain: response.CertificateChain
    };
    
}

//Install Certificate over the ACM PCA
async function installCertificateOnAcmPca(CertificateAuthorityArn,Certificate,CertificateChain) {
    //Certificate Installation
     const params = { 
      CertificateAuthorityArn: CertificateAuthorityArn, // required
      Certificate: Certificate,// TextEncoder().encode(Certificate), // e.g. Buffer.from("") or new TextEncoder().encode("")   // required
      CertificateChain: CertificateChain,//new TextEncoder().encode(CertificateChain), // e.g. Buffer.from("") or new TextEncoder().encode("")
    };
    
    const command = new ImportCertificateAuthorityCertificateCommand(params);
    const response = await acmPcaClient.send(command);
    return {
        response: response,
    };
}

// Register Intermediate Certificate with AWS IoT as Certificate Authority
async function registerIntermediateCaCertificateWithAwsIoT(Certificate,CertificateChain) {
  try {
     const params = { // RegisterCACertificateRequest
      caCertificate: Certificate, // required
      setAsActive: true,
      certificateMode: "SNI_ONLY",
      allowAutoRegistration: true
    };
    
    const command = new RegisterCACertificateCommand(params);
    const response = await iotClient.send(command);
    console.log('Registered CA Certificates:', response);
    return {
      certificateId : response.certificateId
    };
  } catch (error) {
    console.log("error.message11:",error.message);
    if (error.message.includes('CA certificate already registered')) {
      console.log('CA certificate is already registered, using the existing registration.');
      const listCommand = new ListCACertificatesCommand({});
      const listResponse = await iotClient.send(listCommand);
      console.log("listResponse:",listResponse);
      const getTargetCaId = error.message.split(":");
      const targetCertificateId = getTargetCaId[1];
      const caCertificate = listResponse.certificates.find(ca => ca.certificateId === targetCertificateId);
      console.log("caCertificate:",caCertificate);
      if (caCertificate) {
        const existingCertificateId = caCertificate.certificateId;
        console.log("existingCertificateId:",existingCertificateId);
        return {
          certificateId : existingCertificateId
        };
      } else {
        console.log('No matching CA found');
        return {
          statusCode: 500,
          message: JSON.stringify({ error: "No matching Certificate Id found!" })
        };
      } 
      // Proceed with using the already registered CA certificate
    } else {
       console.error('Error listing CA certificates:', error);
       return {
          statusCode: 500,
          message: JSON.stringify({ error: error.message })
        };
    }
  }
   
}



//Delete the old Intermediate Certificate from the ACM PCA
async function deleteOldIntermediateCertificateFromAcmPca(CertificateAuthorityArn,PermanentDeletionTimeInDays) {
  
 const disablePcaCommand = new UpdateCertificateAuthorityCommand({
          CertificateAuthorityArn: CertificateAuthorityArn,
          Status: 'DISABLED'
      });

  await acmPcaClient.send(disablePcaCommand);
  console.log('PCA disabled successfully.');
  
  const params = {
      CertificateAuthorityArn: CertificateAuthorityArn,
      PermanentDeletionTimeInDays:PermanentDeletionTimeInDays,
    };
    const command = new DeleteCertificateAuthorityCommand(params);
    const response = await acmPcaClient.send(command);
    return {
      response : response
    }
} 



// List all Certificate Authorities to get the certificate ARN of ACM PCA
async function getCertificateAuthorityArnByName(commonName) {

    try {
        // Step 1: List all Certificate Authorities
        const listCAsCommand = new ListCertificateAuthoritiesCommand({});
        const response = await acmPcaClient.send(listCAsCommand);
        console.log("pcaNameResponse:",response);
        // Step 2: Iterate over each CA
        for (const pca of response.CertificateAuthorities) {
            if (pca.Status === 'DELETED' || pca.Type==='ROOT') {
                console.log(`Skipping deleted CA: ${pca.Arn}`);
                continue;
            }

            // Step 3: Retrieve the certificate associated with this CA
            const getCertCommand = new GetCertificateAuthorityCertificateCommand({ CertificateAuthorityArn: pca.Arn });
            const certResponse = await acmPcaClient.send(getCertCommand);
            console.log("certResponse:",certResponse);

            if (certResponse.Certificate) {
                // Step 4: Parse the certificate and get the subject/common name
                const certificate = new X509Certificate(certResponse.Certificate);
                const subjectName = certificate.subject; // Subject name (including common name)
                console.log("subjectName:",subjectName);
                // Check if the subject name matches the common name
                if (subjectName.includes(`CN=${commonName}`)) {
                    console.log('Found PCA with matching common name:', pca.Arn);
                    return {oldAcmPcaArn:pca.Arn};
                }
            }
        }
        console.log('PCA with the specified common name not found.');
        return {
          statusCode: 500,
          message: JSON.stringify({ error: 'PCA with the specified common name not found' })
        };

    } catch (error) {
        console.error('Error retrieving PCA:', error);
         return {
          statusCode: 500,
          message: JSON.stringify({ error: error.message })
        };
    }
}

export const handler = async (event) => {
  try {
    //validate incoming request
    if(!event.secretPassword) {
      return {
        statusCode: 400,
        message: "Secret token is missing"
      }
    }

    try {
      const lambdaSecretPassConfig = await client.send(
        new GetSecretValueCommand({
          SecretId: secretKeyName,
          VersionStage: "AWSCURRENT", 
        })
      );
      const secretString = JSON.parse(lambdaSecretPassConfig.SecretString);
    
      if(event.secretPassword !== secretString.validationPassword) {
        return {
          statusCode: 400,
          message: "Invalid secret token passed"
        }
      }
    } catch(error) {
      return {
        statusCode: 400,
        message: JSON.stringify({ error: "Invalid secret token passed"})
      };
    }

    acmPcaClientForSharedAccount = await getSharedAccountClient();
    const { oldAcmPcaArn } = await getCertificateAuthorityArnByName(process.env.INTERMEDIATE_ACP_PCA_NAME);
    if(oldAcmPcaArn) {
      const deleteOldAcmPcaCertificate = await deleteOldIntermediateCertificateFromAcmPca(oldAcmPcaArn,7);
      console.log("deleteOldAcmPcaCertificate:",deleteOldAcmPcaCertificate);
    }
    console.log('Step-1 : deleteOldAcmPcaCertificate:');
    
    const { CertificateAuthorityArn } = await createNewAcmPca();
    console.log('Step-2 : createNewAcmPca',CertificateAuthorityArn);

    const { rootCaArn } = await GetCaArnFromSharedParameterStore();
    console.log('Step-3 : GetCaArnFromSharedParameterStore',rootCaArn);
    
    const { CSR } = await GetIntermediateCertificateCSR(CertificateAuthorityArn);
    console.log('Step-4 : GetIntermediateCertificateCSR',CSR);
    
    const { encodedCSR } = GenerateEncodedCSR(CSR);
    
    const { CertificateArn } = await GetCertificateCsrSignedByRootCA(rootCaArn, encodedCSR, parseInt(process.env.VALIDITY), process.env.VALIDITY_TYPE);
    console.log('Step-5 : GetCertificateCsrSignedByRootCA',CertificateArn);
   
    const storeParameterARN = await StoreAcmPcaArnInParameterStore(CertificateAuthorityArn);
    console.log('Step-6 : storeParameterARN',storeParameterARN);

    const {Certificate,CertificateChain} = await getCertificateAndCertificateChainFromAcmPca(CertificateArn,rootCaArn);
    console.log('Step-7 : getCertificateAndCertificateChainFromAcmPca',Certificate);
    
    const { response } = await installCertificateOnAcmPca(CertificateAuthorityArn,Certificate,CertificateChain);
    console.log('Step-8 : installCertificateOnAcmPca',response);
    
    const {certificateArn,certificateId} = await registerIntermediateCaCertificateWithAwsIoT(Certificate,CertificateChain);
    console.log('Step-9 : registerIntermediateCaCertificateWithAwsIoT',certificateArn,certificateId);

    return {
      statusCode: 200,
      message: "Intermediate rotation has been completed successfully!",
      certificateId : certificateId
    }; 
    
  } catch (error) {
    // Handle any errors
    return {
      statusCode: 500,
      message: JSON.stringify({ error: error.message })
    };
  }
};