module.exports = {
    transform: { "^.+\\.mjs$": "babel-jest" },
    moduleFileExtensions: ["js", "mjs","ts"],
    testEnvironment: 'node',
    moduleDirectories:["node_modules"],
    testMatch: ["**/test/*.test.mjs"],
    roots: ["<rootDir>"],
    transformIgnorePatterns: ["node_modules/*"],
    collectCoverage: true,
    collectCoverageFrom: ['<rootDir>/**/*.mjs'],
    coverageReporters: [['lcov', {"projectRoot":"../"}],'text-summary', 'text', 'html'],
coverageDirectory: "./coverage",
  };