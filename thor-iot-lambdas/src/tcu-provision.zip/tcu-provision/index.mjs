import { IoTDataPlaneClient, PublishCommand } from "@aws-sdk/client-iot-data-plane";
const iotDataClient = new IoTDataPlaneClient({ region: process.env.REGION });
import {
    SecretsManagerClient,
    GetSecretValueCommand,
} from "@aws-sdk/client-secrets-manager";
import pg from 'pg'
const { Client } = pg

const MandatoryKeys = [
    "TCU_ID",
    "IMEI",
    "BLE_Advertising_Name",
    "BLE_KEY",
    "BLE_MAC",
    "BLE_PIN",
    "BLE_PROTOCOL_VERSION",
    "ECU_ID",
    "ICCID",
    "MANUFACTURER",
    "MANUFACTURER_LOCATION",
    "PART_NUMBER",
    "TCU_HW_VERSION",
    "TCU_SW_VERSION",
    "TCU_METADATA"
];
const nonMandatoryKeys = ["MAC", "SSID", "SSID_PASSWORD", "WIFI_MAC"];
const imeiRegex = "^\\d{15}$"
const tcuIdRegex = (imei) => new RegExp(`^[0-9]{2}[A-L]{1}[0-9]{2}${imei}[0-9]{4}[0-9A-Z]{4}$`);
const tcuMappingTable = process.env.TCU_MAPPING_TABLE
const tcuDetailTable = process.env.TCU_DETAILS_TABLE
const secret_name = process.env.RDS_SECRET_NAME; 

const client = new SecretsManagerClient({
  region: process.env.REGION
});

const getKeysFromObject = (current, keys) => {
    for (const key in current) {
        if (Object.hasOwn(current, key)) {
            keys.push(key);
            if (typeof current[key] === 'object' && current[key] !== null) {
                getKeysFromObject(current[key], keys);
            }
        }
    }
};

const getKeys = (obj) => {
    const keys = [];
    if (obj && typeof obj === 'object') {
        getKeysFromObject(obj, keys);
    }
    return keys;
};

const publishToIoTClient = async (payloadData, topicName, TCU_ID) => {
    try {
        topicName = topicName.replace('<tcu_id>', TCU_ID)
        await iotDataClient.send(new PublishCommand({
            topic: `${topicName}`,
            payload: JSON.stringify(payloadData),
            qos: 1
        }));
    } catch (error) {
        console.log(error)
    }
}

const validateMandatoryKeys = (payloadKeys, mandatoryKeys) => {
    const missingKeys = [];
    for (const key of mandatoryKeys) {
        if (!payloadKeys.includes(key)) {
            missingKeys.push(key);
        }
    }
    return missingKeys;
};

const validateKeyValues = (payload, key, imei, hasTcuMetadata, invalidKeys) => {
    let value;
    if (key === 'TCU_ID' || key === 'IMEI') {
        value = payload[key];
    } else {
        value = payload?.[key] ?? (hasTcuMetadata ? payload.TCU_METADATA?.[key] : null);
    }

    if (value == null || value === "" || value === undefined) {
        return true; // Indicates missing value
    }

    // Validate specific keys
    if (key === "TCU_ID" && imei) {
        const tcuRegex = tcuIdRegex(imei);
        if (!value.match(tcuRegex)) {
            invalidKeys.push('Invalid TCU_ID Format');
        }
    }
    if (key === "IMEI" && !value.match(imeiRegex)) {
        invalidKeys.push('Invalid IMEI Format');
    }
    return false; // Indicates valid value
};

const validateExtraKeys = (payloadKeys, allKeys, invalidKeys) => {
    for (const key of payloadKeys) {
        if (!allKeys.includes(key)) {
            invalidKeys.push(key);
        }
    }
};

const queryPostgres = async(query,rdsClient) => {
    try{
        const res = await rdsClient.query(query)
        return {status: true,data: res.rows}
    } catch(error){ 
        console.log(error)
        console.log('error while querying rds', JSON.stringify(error))
        return {status:false,data:[]}
    }
}
const validateInput = async (payload) => {
    const missingKeys = [];
    const invalidKeys = [];

    try {
        const payloadKeys = getKeys(payload);
        const hasTcuMetadata = payloadKeys.includes('TCU_METADATA');
        const imei = payload?.IMEI;

        // Validate mandatory keys
        missingKeys.push(...validateMandatoryKeys(payloadKeys, MandatoryKeys));

        // Validate each mandatory key's value
        for (const key of MandatoryKeys) {
            if (missingKeys.includes(key)) continue; // Skip if already missing
            if (validateKeyValues(payload, key, imei, hasTcuMetadata, invalidKeys)) {
                missingKeys.push(key);
            }
        }

        // Validate extra unexpected keys
        const allKeys = [...MandatoryKeys, ...nonMandatoryKeys];
        validateExtraKeys(payloadKeys, allKeys, invalidKeys);

        return {
            valid: missingKeys.length === 0 && invalidKeys.length === 0,
            ...(missingKeys.length > 0 && { missingKeys }),
            ...(invalidKeys.length > 0 && { invalidKeys }),
        };

    } catch (error) {
        payload.error = error.message;
        await publishToIoTClient({ message: error }, process.env.REJECT_TOPIC, payload.TCU_ID)
        return formatErrorResponse("Error Validation issue", { message: error.message }, 500);
    }
};

const formatErrorResponse = (errorMessage, errPayload, statusCode) => {
    console.log({
        statusCode: statusCode,
        body: JSON.stringify({
            message: errorMessage,
            errPayload: errPayload,
        }),
    })
    return { "status": false }
};

const generateUpdatePayload = async(payload,tableName,id) => {
    try {
        let updateQuery = `update ${tableName} set `
        for(let key of Object.keys(payload)) {
            let value = typeof payload[key] == 'string' ? `'${payload[key]}'` : payload[key]
            updateQuery += `${key} = ${value},`
        }
        return `${updateQuery.substr(0,updateQuery.length-1)} where id = ${id}`
        
    } catch(error) {
        console.log(error)
    }
}

const generateInsertPayload = async(payload,tableName) => {
    try{
        let colums = ""
        let values = ""
        for(let key of Object.keys(payload)) {
            if(![null,undefined].includes(payload[key])) {
                colums += `${key},`
                values += typeof payload[key] == 'string' ? `'${payload[key]}',` : `${payload[key]},`
            }
        }
        colums = `(${colums.substr(0,colums.length-1)})`
        values = `(${values.substr(0,values.length-1)})`

        return `insert into ${tableName} ${colums} values ${values}`
    } catch(error) {
        console.log(error)
    }
}


const validateInputType = async(payload) => {
    try {
        let invalidInput = []
        for(let key of Object.keys(payload)) {
            if(typeof payload[key] != 'string' && !nonMandatoryKeys.includes(key)) {
                invalidInput.push(`${key} should be of type string`)
            }
        }
        return invalidInput.length > 0 ? {valid:false, "invalidInput": invalidInput } : {valid:true}
    } catch(error) {
        payload.error = error.message;
        await publishToIoTClient({ message: error }, process.env.REJECT_TOPIC, payload.TCU_ID)
        return formatErrorResponse("Error Validation issue", { message: error.message }, 500);
    }
}
export const handler = async (event) => {
    let tcuData = event.payload;
    tcuData.TCU_ID = event?.TCU_ID
    console.log('--TCU ID---',tcuData?.TCU_ID)
    tcuData.IMEI = tcuData?.IMEI == undefined ? "" : tcuData.IMEI.toString()
    try {
        const outPut = await validateInput(tcuData);
        
        if (!outPut.valid) {
            tcuData.error = outPut;
            await publishToIoTClient({ message: "Invalid Input", errData: tcuData }, process.env.REJECT_TOPIC, tcuData.TCU_ID)
            return formatErrorResponse("Invalid Input", outPut, 400);
        } else {
            const inputValRes = await validateInputType(tcuData.TCU_METADATA)
            if(!inputValRes.valid) {
                tcuData.error = inputValRes;
                await publishToIoTClient({ message: "Invalid Input Type", errData: tcuData }, process.env.REJECT_TOPIC, tcuData.TCU_ID)
                return formatErrorResponse("Invalid Input", inputValRes, 400);
            }
            try {
                //fetch RDS secret
                const rdsConfigs = await client.send(
                    new GetSecretValueCommand({
                      SecretId: secret_name,
                      VersionStage: "AWSCURRENT", 
                    })
                );
                let secretString = JSON.parse(rdsConfigs.SecretString);
                //connect to RDS 
                const rdsClient = new Client({
                    user: secretString['db.username'],
                    password: secretString['db.password'],
                    host: secretString['db.host'],
                    port: secretString['db.port'],
                    database: secretString['db.database'],
                    ssl: {
                        rejectUnauthorized: false // Accept self-signed certificates (adjust as needed)
                    }
                })
                await rdsClient.connect()
                const getTcuQuery =  `select id,tcu_id,is_active from ${tcuDetailTable} where tcu_id = '${tcuData.TCU_ID}'`;
                const tcuAlreadyMapped = await queryPostgres(getTcuQuery,rdsClient)
                
                if(tcuAlreadyMapped.status == false) {
                    await rdsClient.end()
                    await publishToIoTClient({ message: "RDS fetch error" }, process.env.REJECT_TOPIC, tcuData.TCU_ID)
                    return formatErrorResponse("RDS fetch error", { message: "RDS fetch error" }, 500);
                }

                if(tcuAlreadyMapped.data.length > 0) {
                    if(tcuAlreadyMapped.data[0].is_active) {
                        const errMessage = "TCU is already provisioned and mapped to a Vehicle"
                        await rdsClient.end()
                        await publishToIoTClient({ message: errMessage }, process.env.REJECT_TOPIC, tcuData.TCU_ID)
                        return formatErrorResponse(errMessage, { message: errMessage }, 500);
                    }
                }

                // //add query to insert/update record to tcu_details and tcu_mapping
                try {
                    ["MAC", "SSID", "SSID_PASSWORD", "WIFI_MAC"]
                    //to avoide optional keys which are not present in tcu payload
                    let tcuPostgreInfo = {
                        "ble_mac_id": tcuData.TCU_METADATA?.BLE_MAC,
                        "iccid":tcuData.TCU_METADATA?.ICCID,
                        "imei":tcuData?.IMEI,
                        "ssid":tcuData.TCU_METADATA?.SSID || null,
                        "wifi_mac_id":tcuData.TCU_METADATA?.WIFI_MAC || null,
                        "hardware_detail":tcuData.TCU_METADATA?.TCU_HW_VERSION,
                        "software_detail":tcuData.TCU_METADATA?.TCU_SW_VERSION,
                        "tcu_id":tcuData?.TCU_ID,
                        "is_active": false,
                        "ecu_ref_id":tcuData.TCU_METADATA?.ECU_ID,
                        "created_by": "System",
                        "ble_pin":tcuData.TCU_METADATA?.BLE_PIN,
                        "ble_protocol_version":tcuData.TCU_METADATA?.BLE_PROTOCOL_VERSION,
                        "manufacturer":tcuData.TCU_METADATA?.MANUFACTURER,
                        "manufacturer_location":tcuData.TCU_METADATA?.MANUFACTURER_LOCATION,
                        "part_number":tcuData.TCU_METADATA?.PART_NUMBER,
                        "ssid_password":tcuData.TCU_METADATA?.SSID_PASSWORD || null,
                        "mac":tcuData.TCU_METADATA?.MAC || null,
                        "updated_by":"System",
                        "ble_advertising_name":tcuData.TCU_METADATA?.BLE_Advertising_Name,
                        'ble_key': tcuData.TCU_METADATA?.BLE_KEY
                    }
                    
                    let queryInsOrUpd;
                    if(tcuAlreadyMapped.data.length > 0) {
                        queryInsOrUpd = await generateUpdatePayload(tcuPostgreInfo,tcuDetailTable,tcuAlreadyMapped.data[0].id) 
                    } else {
                        queryInsOrUpd = await generateInsertPayload(tcuPostgreInfo,tcuDetailTable)
                    }
                    await queryPostgres(queryInsOrUpd,rdsClient)
                    await rdsClient.end()
                } catch(error) {
                    await rdsClient.end()
                    console.log(error)
                    await publishToIoTClient({ message: error.message }, process.env.REJECT_TOPIC, tcuData.TCU_ID)
                    return formatErrorResponse("Internal Server Error", { message: error.message }, 500);
                }  
                return { "status": true }
            } catch(err) {
                console.log(err)
                await publishToIoTClient({ message: err.message }, process.env.REJECT_TOPIC, tcuData.TCU_ID)
                return formatErrorResponse("Internal Server Error", { message: err.message }, 500);
            }
        }
    } catch (err) {
        console.log(err)
        await publishToIoTClient({ message: err.message }, process.env.REJECT_TOPIC, tcuData.TCU_ID)
        return formatErrorResponse("Internal Server Error", { message: err.message }, 500);
    }
};