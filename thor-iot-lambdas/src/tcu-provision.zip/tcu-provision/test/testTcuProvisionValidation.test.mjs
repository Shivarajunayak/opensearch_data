import { handler } from '../index.mjs';

describe("testHandler", () => {
    it("should retrun true when the payload is a valid payload", async () => {
        const event = {payload: {IMEI: '350435031402674',
        TCU_METADATA: {
          BLE_Advertising_Name: 'BEL',
          BLE_KEY: '9781483628325057',
          BLE_MAC: '00:80:E1:2A:D7:9C',
          BLE_PIN: '978148',
          BLE_PROTOCOL_VERSION: '0.0.3.0',
          ECU_ID: '7M14',
          ICCID: 'BLE',
          MANUFACTURER: 'BNBS',
          MANUFACTURER_LOCATION: 'GURUGRAM',
          PART_NUMBER: 'ACPDA7M001000',
          TCU_HW_VERSION: 'A',
          TCU_SW_VERSION: '0.1.76'
        },
       },
       TCU_ID: '17L3535043503140267434583320'
     }

     const response = await handler(event);
     console.log(response);
     expect(response.status).toBe(true);
    });
    it("should return false when the payload is a invalid payload", async () => {
        const event = {payload: {IMEI: '35043503140267',
        TCU_METADATA: {
          BLE_Advertising_Name: 'BEL',
          BLE_KEY: '9781483628325057',
          BLE_MAC: '00:80:E1:2A:D7:9C',
          BLE_PIN: '978148',
          BLE_PROTOCOL_VERSION: '0.0.3.0',
          ECU_ID: '7M14',
          ICCID: 'BLE',
          MANUFACTURER: 'BNBS',
          MANUFACTURER_LOCATION: 'GURUGRAM',
          PART_NUMBER: 'ACPDA7M001000',
          TCU_HW_VERSION: 'A',
          TCU_SW_VERSION: '0.1.76'
        },
       },
       TCU_ID: '17L3535043503140267434583320'
     }

     const response = await handler(event);
     console.log(response);
     expect(response.status).toBe(false);
    });
    it("should return false when the if any of the mandatory key is missing", async () => {
        const event = {payload: {IMEI: '35043503140267',
            TCU_METADATA: {
              BLE_Advertising_Name: 'BEL',
              BLE_KEY: '9781483628325057',
              BLE_MAC: '00:80:E1:2A:D7:9C',
              BLE_PIN: '978148',
              BLE_PROTOCOL_VERSION: '0.0.3.0',
              ECU_ID: '7M14',
              ICCID: 'BLE',
              MANUFACTURER: 'BNBS',
              MANUFACTURER_LOCATION: 'GURUGRAM',
              PART_NUMBER: 'ACPDA7M001000',
              TCU_HW_VERSION: 'A',
              TCU_SW_VERSION: '0.1.76',
              TEST_KEY: "TEST_VALUE"
            },
           },
           TCU_ID: '17L3535043503140267434583320'
        }

     const response = await handler(event);
     console.log(response);
     expect(response.status).toBe(false);
    });
    it("should return false when the if unwanted key value is passed", async () => {
        const event = {payload: {IMEI: '35043503140267',
        TCU_METADATA: {
          BLE_KEY: '9781483628325057',
          BLE_MAC: '00:80:E1:2A:D7:9C',
          BLE_PIN: '978148',
          BLE_PROTOCOL_VERSION: '0.0.3.0',
          ECU_ID: '7M14',
          ICCID: 'BLE',
          MANUFACTURER: 'BNBS',
          MANUFACTURER_LOCATION: 'GURUGRAM',
          PART_NUMBER: 'ACPDA7M001000',
          TCU_HW_VERSION: 'A',
          TCU_SW_VERSION: '0.1.76'
        },
       },
       TCU_ID: '17L3535043503140267434583320'
     }

     const response = await handler(event);
     console.log(response);
     expect(response.status).toBe(false);
    });
    it("should return false when the payload contains null as a value for any key", async () => {
        const event = {payload: {IMEI: '35043503140267',
        TCU_METADATA: {
          BLE_Advertising_Name: null,
          BLE_KEY: '9781483628325057',
          BLE_MAC: '00:80:E1:2A:D7:9C',
          BLE_PIN: '978148',
          BLE_PROTOCOL_VERSION: '0.0.3.0',
          ECU_ID: '7M14',
          ICCID: 'BLE',
          MANUFACTURER: 'BNBS',
          MANUFACTURER_LOCATION: 'GURUGRAM',
          PART_NUMBER: 'ACPDA7M001000',
          TCU_HW_VERSION: 'A',
          TCU_SW_VERSION: '0.1.76'
        },
       },
       TCU_ID: '17L3535043503140267434583320'
     }

     const response = await handler(event);
     console.log(response);
     expect(response.status).toBe(false);
    });
});