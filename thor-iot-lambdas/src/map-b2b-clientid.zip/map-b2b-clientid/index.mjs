import { IoTFleetWiseClient,UpdateVehicleCommand,GetVehicleCommand   }  from "@aws-sdk/client-iotfleetwise";
const client = new IoTFleetWiseClient({region: process.env.AWS_REGION});

const getVehicle = async(vehicleName) => {
    try {
        let vehicleInput = {
            vehicleName: vehicleName,
            region: process.env['REGION']
        }

        const vehicleCommand = new GetVehicleCommand(vehicleInput);
        const vehicleResponse = await client.send(vehicleCommand);
        return {
            status: true,
            vehicleResponse: vehicleResponse
        }
    } catch(error) {
        console.log(`---getVehicle function error-- ${vehicleName}`)
        console.log(error)
        return {
            status: false,
            error: error
        }
    }
}

const updateVehicle = async(vehicleData) => {
    try {
        const updateVehicleCmd = new UpdateVehicleCommand(vehicleData);
        const lksResponse = await client.send(updateVehicleCmd);
        return {
            status: true,
        }
    } catch(error) {
        console.log(`Error updateVehicle function ${vehicleData.vehicleName}`)
        console.log(error)
        return {
            status: false,
            error: error
        }
    }
}

const updateVehicleClientId = async(vehicle, clientId) => {
    try {
        let vehicleData = await getVehicle(vehicle)
        if(vehicleData.status == true) {
            const vehicleRes = vehicleData.vehicleResponse
            let attributes = vehicleRes.attributes
            attributes["hmcl.b2bClientId"] = clientId == null || clientId == "" ? "null" : clientId
            let b2bData = {
                    "vehicleName": vehicleRes.vehicleName,
                    "modelManifestArn": vehicleRes.modelManifestArn,
                    "decoderManifestArn": vehicleRes.decoderManifestArn,
                    "attributeUpdateMode": "Merge",
                    "attributes": attributes
                }
            await updateVehicle(b2bData)
            console.log(`clientId for the vehicle ${vehicle} update successfully`)
        }
        return true
    } catch(error) {
        console.log(`updateVehicleClientId function failed ${vehicle}`)
        console.log(error)
    }
}

export const handler = async (event) => {
    try {
        let {b2bClientId,mappingVehicles} = event
        if(mappingVehicles.length == 0) {
           return {
            statusCode: 400,
            body: JSON.stringify({
                message: "mappingVehicles cannot be empty"
            })
          }
        };

        for(let vehicle of mappingVehicles) {
            await updateVehicleClientId(vehicle,b2bClientId)
        }

        return {
            statusCode: 200,
            body: JSON.stringify({
              message: "Vehicle mapping successful"
            }),
        };

    } catch(error) {
        console.log('---------handler function error error------------')
        console.log(error)
        return  {
            statusCode: 500,
            body: JSON.stringify({
              message: "Vehicle mapping failed"
            }),
        };
    }
};
