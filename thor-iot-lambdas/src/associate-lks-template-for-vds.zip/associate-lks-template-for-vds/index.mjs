import { IoTFleetWiseClient,UpdateVehicleCommand,GetStateTemplateCommand,GetVehicleCommand   }  from "@aws-sdk/client-iotfleetwise";
const client = new IoTFleetWiseClient({region: process.env.AWS_REGION});

export const handler = async (event) => {
  console.log('event:',event);
  try {
  
  const vehicleName = event.TCU_ID
  const ACCOUNT_ID = process.env.ACCOUNT_ID;
  const REGION = process.env.AWS_REGION;
  const MODEL = event.VehicleProperties.Model;
  const TENANT_ID = event.TENANT_ID;
  const VIRTUAL_ID = event.MaskedPayload.Payload.VIRTUAL_ID;
  const modelManifestArn = `arn:aws:iotfleetwise:${REGION}:${ACCOUNT_ID}:model-manifest/${MODEL}`;
  const decoderManifestArn = `arn:aws:iotfleetwise:${REGION}:${ACCOUNT_ID}:decoder-manifest/${MODEL}`;
  const VDS = event.VehicleProperties.VDS;
  const attributes = { 
    "hmcl.tenantId": TENANT_ID,
    "hmcl.virtualId" : VIRTUAL_ID,
    "hmcl.vds": VDS
  };
  
  
  //get the vehilce details
  const vehicleInput = {
    vehicleName: vehicleName,
  };
  
  console.log('UK2 Regions:',REGION);
  
  const vehicleCommand = new GetVehicleCommand(vehicleInput);
  const vehicleResponse = await client.send(vehicleCommand);
  console.log("vehicleResponse:",vehicleResponse);
  
  if('stateTemplates' in vehicleResponse) {
    
     return {
        statusCode: 200,
        body: JSON.stringify({
          status: "success",
          message: "LKS template is already attached with vehicle.",
          data: {
            vehicleName:vehicleResponse.vehicleName,
            stateTemplates : vehicleResponse.stateTemplates
          },
          error: null
        }),
      };
      
  } else {

  //get the id from the state
  const stateInput = {
    identifier : "HMCL-"+TENANT_ID
  }
  const stateCommand = new GetStateTemplateCommand(stateInput);
  const stateResponse = await client.send(stateCommand);
  
  const identifierId = stateResponse.id?stateResponse.id:'';
  
  //step 2
  const lksInput = {
  vehicleName: vehicleName,
  modelManifestArn: modelManifestArn,
  decoderManifestArn: decoderManifestArn,
  attributes: attributes,
  attributeUpdateMode: "Merge",
  stateTemplatesToAdd:[
    {
      identifier: identifierId,
      stateTemplateUpdateStrategy : {
        periodic : {
          stateTemplateUpdateRate : {
            unit:"MILLISECOND",
            value:5000
          }
        }
      }
    }
    ],
  };
  const lksCommand = new UpdateVehicleCommand(lksInput);
  const lksResponse = await client.send(lksCommand);
  
   return {
        statusCode: 200,
        body: JSON.stringify({
          status: "success",
          message: "LKS template has been associated with vehicle successfully.",
          data: {
            vehicleName:lksResponse.vehicleName,
            stateTemplates : lksResponse.stateTemplates
          },
          error: null
        }),
      };
  }
  } catch (error) {
    console.error("Error", error);
    return {
      statusCode: 500,
      body: JSON.stringify({
        status : "failed",
        error: error.message,
        message : "Error while processing the request",
        data : null,
      }),
    };
  }
  
};
