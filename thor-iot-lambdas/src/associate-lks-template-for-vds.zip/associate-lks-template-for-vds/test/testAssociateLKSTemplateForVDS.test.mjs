import { handler } from '../';
import { mockClient } from 'aws-sdk-client-mock';
import { IoTFleetWiseClient,UpdateVehicleCommand,GetStateTemplateCommand,GetVehicleCommand   }  from "@aws-sdk/client-iotfleetwise";

describe("Test Assocate LKS Template For VDS", () => {
    it("should return statusCode 200 on success", async () => {
        const iotFleetWiseClientMock = mockClient(IoTFleetWiseClient);
        process.env.ACCOUNT_ID = "test-accountId";
        process.env.AWS_REGION = "test-region";

        iotFleetWiseClientMock.on(GetStateTemplateCommand).resolves({
            "arn": "arn:aws:iotfleetwise:region:account:statetemplate/MyStateTemplate",
            "name": "MyStateTemplate",
            "description": "MyStateTemplate",
            "id": "test-id",
            "signalCatalog": "test-signal-catalog",
            "stateTemplateProperties": ['test-state-template']
        });

        iotFleetWiseClientMock.on(GetVehicleCommand).resolves({
            "arn": "arn:aws:iotfleetwise:region:account:vehicle/MyVehicle",
            "vehicleName": "MyVehicle",
            "decoderManifestArn": "arn:aws:iotfleetwise:region:account:decoder-manifest/MyDecoderManifest",
            "modelManifestArn": "arn:aws:iotfleetwise:region:account:model-manifest/MyModelManifest",
            "attributes": {
                "hmcl.tenantId": "test-tenantId",
                "hmcl.virtualId": "test-virtualId",
                "hmcl.vds": "test-vdsCode"
            },
            "creationTime": "2023-01-01T00:00:00.000Z",
            "lastModificationTime": "2023-01-01T00:00:00.000Z"
        });

        iotFleetWiseClientMock.on(UpdateVehicleCommand).resolves({
            "arn": "arn:aws:iotfleetwise:region:account:vehicle/MyVehicle",
            "vehicleName": "MyVehicle"
        });

        const event = {
            "TCU_ID": "test-virtualId",
            "TENANT_ID": "test-tenantId",
            "VehicleProperties": {
                "Model": "test-model",
                "VDS": "test-vdsCode"
            },
            "MaskedPayload": {
                "Payload": {
                    "VIRTUAL_ID": "test-virtualId"
                }
            }
        }

        const response = await handler(event);
        console.log(response);
        expect(response.statusCode).toBe(200);
    });

    it("should return statusCode 200 when LKS template is already associated with vehicle", async () => {
        const iotFleetWiseClientMock = mockClient(IoTFleetWiseClient);
        process.env.ACCOUNT_ID = "test-accountId";
        process.env.AWS_REGION = "test-region";

        iotFleetWiseClientMock.on(GetStateTemplateCommand).resolves({
            "arn": "arn:aws:iotfleetwise:region:account:statetemplate/MyStateTemplate",
            "name": "MyStateTemplate",
            "description": "MyStateTemplate",
            "id": "test-id",
            "signalCatalog": "test-signal-catalog",
            "stateTemplateProperties": ['test-state-template']
        });

        iotFleetWiseClientMock.on(GetVehicleCommand).resolves({
            "arn": "arn:aws:iotfleetwise:region:account:vehicle/MyVehicle",
            "vehicleName": "MyVehicle",
            "decoderManifestArn": "arn:aws:iotfleetwise:region:account:decoder-manifest/MyDecoderManifest",
            "modelManifestArn": "arn:aws:iotfleetwise:region:account:model-manifest/MyModelManifest",
            "attributes": {
                "hmcl.tenantId": "test-tenantId",
                "hmcl.virtualId": "test-virtualId",
                "hmcl.vds": "test-vdsCode"
            },
            "creationTime": "2023-01-01T00:00:00.000Z",
            "lastModificationTime": "2023-01-01T00:00:00.000Z",
            "stateTemplates": ["test-state-template"]
        });

        iotFleetWiseClientMock.on(UpdateVehicleCommand).resolves({
            "arn": "arn:aws:iotfleetwise:region:account:vehicle/MyVehicle",
            "vehicleName": "MyVehicle"
        });

        const event = {
            "TCU_ID": "test-virtualId",
            "TENANT_ID": "test-tenantId",
            "VehicleProperties": {
                "Model": "test-model",
                "VDS": "test-vdsCode"
            },
            "MaskedPayload": {
                "Payload": {
                    "VIRTUAL_ID": "test-virtualId"
                }
            }
        }

        const response = await handler(event);
        console.log(response);
        expect(response.statusCode).toBe(200);
    });
})
