import { handler } from '../';
import { SSMClient, GetParameterCommand } from "@aws-sdk/client-ssm"; 
import { ACMPCAClient, IssueCertificateCommand, GetCertificateCommand } from "@aws-sdk/client-acm-pca"; 
import { IoTClient, RegisterCertificateCommand, AttachPolicyCommand, DescribeEndpointCommand } from "@aws-sdk/client-iot";
import { SecretsManagerClient, PutSecretValueCommand } from "@aws-sdk/client-secrets-manager";
import { mockClient } from 'aws-sdk-client-mock';

describe("testHandler", () => {
    it("should update the connection check certificates", async() => {
        const ssmClientMock = mockClient(SSMClient);
        ssmClientMock.on(GetParameterCommand).resolves({
            Parameter: {
                Value: "ARN_OF_INTERMEDIATE_CA"
            }
        });

        const acmPcaClientMock = mockClient(ACMPCAClient);
        acmPcaClientMock.on(IssueCertificateCommand).resolves({
            CertificateArn: "ARN_OF_CERTIFICATE"
        });
        acmPcaClientMock.on(GetCertificateCommand).resolves({
            Certificate: "CERTIFICATE_CONTENT",
            CertificateChain: "CERTIFICATE_CHAIN"
        });

        const iotClientMock = mockClient(IoTClient);
        iotClientMock.on(DescribeEndpointCommand).resolves({
            endpointAddress: "ENDPOINT_ADDRESS"
        });
        iotClientMock.on(RegisterCertificateCommand).resolves({
            certificateId: "CERTIFICATE_ID"
        });
        iotClientMock.on(AttachPolicyCommand).resolves({});

        const secretsManagerClientMock = mockClient(SecretsManagerClient);
        secretsManagerClientMock.on(PutSecretValueCommand).resolves({});

        const response = await handler();
        expect(response.statusCode).toEqual(200);
    });
})
