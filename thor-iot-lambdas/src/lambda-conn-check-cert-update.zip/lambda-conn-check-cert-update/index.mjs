import forge from 'node-forge';
import { SSMClient, GetParameterCommand } from "@aws-sdk/client-ssm"; 
import { ACMPCAClient, IssueCertificateCommand, GetCertificateCommand } from "@aws-sdk/client-acm-pca"; 
import { IoTClient, RegisterCertificateCommand, AttachPolicyCommand, DescribeEndpointCommand } from "@aws-sdk/client-iot";
import { SecretsManagerClient, PutSecretValueCommand } from "@aws-sdk/client-secrets-manager";
import crypto from 'crypto';

const config = { region: process.env.REGION };
const acmPCAClient = new ACMPCAClient(config);
const iotClient = new IoTClient(config);
const secretsManagerClient = new SecretsManagerClient(config);
const ssmClient = new SSMClient(config);

function generateKeys(subjectName, subjectValue) {
    // Generate a 2048-bit RSA private key
    const pki = forge.pki;
    const keys = pki.rsa.generateKeyPair(2048);
    const privateKey = pki.privateKeyToPem(keys.privateKey);
    console.log("Private Key Created");

    // Generate a CSR
    const csr = pki.createCertificationRequest();
    csr.publicKey = keys.publicKey;
    csr.setSubject([{
        name: subjectName,
        value: subjectValue
    }]);
    csr.sign(keys.privateKey);
    const csrPem = pki.certificationRequestToPem(csr);
    console.log("CSR Created");

    return {
        privateKey: privateKey,
        csr: csrPem
    };
}

async function getArn(name) {
    const input = { // GetParameterRequest
        Name: name, // required
        WithDecryption: true
    };
    const command = new GetParameterCommand(input);
    const response = await ssmClient.send(command);
    return response.Parameter.Value;
}

function getRandomNumberUsingCrypto() {
    const array = new Uint32Array(1);
    crypto.getRandomValues(array);
    return array[0];
}

function getEncodedCSR(csr) {
    let randomString = (getRandomNumberUsingCrypto() + 1).toString(36).substring(2);
    const csrUint8Array = new TextEncoder().encode(csr);
    console.log("Csr Encoded Value");
    return { csrUint8Array, randomString };
}

async function issueCertificate(caArn, csrUint8Array, randomString, validity, validity_type) {
    let input = {
        CertificateAuthorityArn: caArn,
        Csr: csrUint8Array,
        SigningAlgorithm: "SHA256WITHRSA",
        TemplateArn: "arn:aws:acm-pca:::template/EndEntityCertificate/V1",
        Validity: {
            Value: validity,
            Type: validity_type,
        },
        IdempotencyToken: randomString
    };

    console.log("IssueCertificateCommand payload. \n", input);
    let command = new IssueCertificateCommand(input);
    const issueCertResponse = await acmPCAClient.send(command);
    console.log("IssueCertificateCommand response. \n", issueCertResponse);
    return { issueCertResponse };
}

async function getCertificate(caArn, issueCertResponse) {
    console.log("Getting Certificate");
    let retries = 1;
    let delay = 1000;
    let maxRetries = 6;
    while (retries < maxRetries) {
        try {
            console.log("Try:", retries);
            let input = {
                CertificateAuthorityArn: caArn,
                CertificateArn: issueCertResponse.CertificateArn
            };
            const getCertCommand = new GetCertificateCommand(input);
            const getCertResponse = await acmPCAClient.send(getCertCommand);
    
            console.log(issueCertResponse.CertificateArn);
            console.log("Get Cert Response", getCertResponse);
            return  getCertResponse;
        } catch (error) {
            retries++;
            delay *= 2;
            await new Promise(resolve => setTimeout(resolve, delay));
        }
    }
}

async function registerCertToAWSIOT(getCertResponse) {
    let input = {
        certificatePem: getCertResponse.Certificate,
        caCertificatePem: getCertResponse.CertificateChain,
        setAsActive: true
    };
    let command = new RegisterCertificateCommand(input);
    const registerIoTCertResponse = await iotClient.send(command);
    console.log(registerIoTCertResponse.certificateArn);
    return registerIoTCertResponse;
}

async function attachPolicy(policyName, registerIoTCertResponse) {
    // Attach AWS IoT Policy to Newly created AWS IoT Certificate
    let input = {
        policyName: policyName,
        target: registerIoTCertResponse.certificateArn
    };

    let command = new AttachPolicyCommand(input);
    await iotClient.send(command);
    console.log("Attached IoT Policy to Certificate");
}

async function setSecret(secretJson) {
    const secretJsonStr = {
        PrivateKey: secretJson.PrivateKey,
        CertificatePem: secretJson.CertificatePem,
        CACertificatePem: secretJson.CACertificatePem,        
        Endpoint: secretJson.Endpoint,
        CertificateId: secretJson.CertificateId,
        AmazonRootCa: secretJson.AmazonRootCa
    };

    const params = {
        SecretId: secretJson.secretName,
        SecretString: JSON.stringify(secretJsonStr)
    };

    const command = new PutSecretValueCommand(params);
    await secretsManagerClient.send(command);
    console.log("Secret updated successfully!");
}

async function getIOTEndpoint(endpointType) {
    let input = {
        endpointType: endpointType,
    };
    let command = new DescribeEndpointCommand(input);
    const describeEndpointResponse = await iotClient.send(command);
    return describeEndpointResponse;
}

export const handler = async(event) => {
    const { privateKey, csr } = generateKeys("commonName", "CLAIM CERTIFICATE");

    const INTERMEDIATE_CA_PARAMETER_NAME = process.env.INTERMEDIATE_CA_PARAMETER_NAME
    const ROOT_CA_PARAMETER_NAME = process.env.ROOT_CA_PARAMETER_NAME
    const caArn = await getArn(INTERMEDIATE_CA_PARAMETER_NAME);
    const rootCA = await getArn(ROOT_CA_PARAMETER_NAME);

    let { csrUint8Array, randomString } = getEncodedCSR(csr);

    let { issueCertResponse } = await issueCertificate(caArn, csrUint8Array, randomString, 
        parseInt(process.env.VALIDITY), process.env.VALIDITY_TYPE);

    // Get Newly issued certificate ARN
    let getCertResponse = await getCertificate(caArn, issueCertResponse);

    // // Register newly created certificate with AWS IoT
    let registerIoTCertResponse = await registerCertToAWSIOT(getCertResponse);

    await attachPolicy(process.env.IOT_POLICY_NAME, registerIoTCertResponse);

     // Get the local AWS IoT Endpoint. Comment out when using custom endpoint
    const describeEndpointResponse = await getIOTEndpoint("iot:Data-ATS");

    // Create secret payload
    const secretJson = {
        PrivateKey: privateKey,
        CertificatePem: getCertResponse.Certificate,
        CACertificatePem: getCertResponse.CertificateChain,
        CertificateId: registerIoTCertResponse.certificateId,
        Endpoint: describeEndpointResponse.endpointAddress,
        secretName: process.env.SECRET_NAME,
        AmazonRootCa: rootCA
    };
    await setSecret(secretJson);
    console.log("Connection check certificate updated successully");
    return {
        statusCode: 200
    }
}


