// Define all message constants
export const message = {
  // Error messages
  ERROR: {
    // Error message for invalid input
    INVALID_INPUT: "Invalid input",
    // Error message for missing required fields
    MISSING_REQUIRED_FIELDS: "Missing required fields",
    // Error message for not found
    NOT_FOUND: "VIN not found",
    // Error message for internal server error
    INTERNAL_SERVER_ERROR: "Internal server error",
    // Error message for failure to fetch VIN
    FAILURE_TO_FETCH_VIN: "Failure to fetch VIN",
    // Error message for vehicle already decommissioned
    VEHICLE_ALREADY_DECOMMISSIONED: "Vehicle already decommissioned",
  },

  // Success messages
  SUCCESS: {
    // Success message for successful operation
    SUCCESSFUL_OPERATION: "Successful operation",
    // Success message for successful login
  },
};