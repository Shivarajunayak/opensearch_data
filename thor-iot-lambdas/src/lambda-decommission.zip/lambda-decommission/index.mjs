import { IoTFleetWiseClient, DeleteVehicleCommand } from "@aws-sdk/client-iotfleetwise";
import { createHash } from "crypto";
import { getAccountId } from './lib/getAccount.mjs';
import { listAndDeleteCertificates, deleteThing } from './lib/listAndDeleteCertsAndThing.mjs';
import { getDeviceLedgerData, updateDeviceLedger } from "./lib/deviceLedger.mjs";
import { getSecret } from "./lib/getSecret.mjs";
import { message } from "./constants/message.mjs";
import { validateVIN } from "./lib/validator.mjs";
import { successResponse, failureResponse } from "./lib/response.mjs";

const REGION = process.env.REGION || "ap-south-1";
const config = { region: REGION };
const fwClient = new IoTFleetWiseClient(config);
const DEVICE_LEDGER_DB = process.env.DEVICE_LEDGER_DB || 'hmcl_cv_dev_device_ledger';
const VIN_SECRET = process.env.VIN_SECRET || 'hmcl-cv-dev-stepfunction-secret';

export const handler = async (event) => {
    console.log("Lambda Decomissioning Started");
    try {
        if (event?.VIN === undefined) {
            console.error(message.ERROR.MISSING_REQUIRED_FIELDS);
            return failureResponse(400, message.ERROR.MISSING_REQUIRED_FIELDS);
        }
        if (!validateVIN(event.VIN)) {
            console.error(message.ERROR.INVALID_INPUT);
            return failureResponse(400, message.ERROR.INVALID_INPUT);
        }

        const VIN = event.VIN;

        if (!VIN_SECRET) {
            console.error("VIN secret is not defined");
            return failureResponse(500, message.ERROR.FAILURE_TO_FETCH_VIN);
        }

        let secretResponse = await getSecret(VIN_SECRET);

        const pepper = secretResponse.secretStringForMaskedVin;
        console.log("pepper", pepper);
        if (!pepper) {
            console.error("Pepper is not defined");
            return failureResponse(500, message.ERROR.FAILURE_TO_FETCH_VIN);
        }
        const hashedVIN = hash_with_pepper(VIN, pepper);
        console.log("hashedVIN", hashedVIN);

        const deviceLedgerData = await getDeviceLedgerData(DEVICE_LEDGER_DB, hashedVIN);

        if (!deviceLedgerData || deviceLedgerData.length === 0) {
            console.error("No data found for the given VIN");
            return failureResponse(401, message.ERROR.NOT_FOUND);
        }

        if (deviceLedgerData[0].VehicleStatus === "DECOMMISSIONED") {
            return failureResponse(400, message.ERROR.VEHICLE_ALREADY_DECOMMISSIONED);
        }

        const vehicle = deviceLedgerData[0].TCU_ID;
        const virtualId = deviceLedgerData[0].VIRTUAL_ID;

        const accountId = await getAccountId();
        console.log("Account Id:", accountId);
        if(deviceLedgerData[0].VehicleStatus === "ACTIVE"  
            || deviceLedgerData[0].VehicleStatus === "QUARANTINED"){
            await listAndDeleteCertificates({ thingName: vehicle }, accountId);
            await deleteThing({ thingName: vehicle });
            await deleteVehicle({ vehicleName: vehicle });
        }
        
        await updateDeviceLedger(DEVICE_LEDGER_DB, virtualId, "DECOMMISSIONED");
        console.log(`Lambda Decomissioning Completed for VIN ${VIN}`)
        return successResponse(`Decomissioning completed for VIN ${VIN}`);

    } catch (e) {
        console.error(e.message);
        return failureResponse(500, e.message);
    }
};

async function deleteVehicle(input) {
    try{
        console.log("Delete Vehicle", input);
        const command = new DeleteVehicleCommand(input);
        await fwClient.send(command);
    } catch (e) {
        console.error(e.message);
        return failureResponse(500, e.message);
    }
}

function hash_with_pepper(data, pepper) {
    const combined_input = data + pepper;
    return createHash("sha512").update(combined_input).digest("hex");
};
