import { handler } from '../';
import { mockClient } from 'aws-sdk-client-mock';
import { DynamoDBDocumentClient, UpdateCommand, QueryCommand } from '@aws-sdk/lib-dynamodb';
import { DynamoDBClient } from "@aws-sdk/client-dynamodb";
import { STSClient, GetCallerIdentityCommand } from "@aws-sdk/client-sts";
import {
    IoTClient,
    ListThingPrincipalsCommand,
    UpdateCertificateCommand,
    DetachThingPrincipalCommand,
    DeleteCertificateCommand,
    DeleteThingCommand
}
    from "@aws-sdk/client-iot";
import { SecretsManagerClient, GetSecretValueCommand } from '@aws-sdk/client-secrets-manager';
import { IoTFleetWiseClient, DeleteVehicleCommand } from "@aws-sdk/client-iotfleetwise";

describe("testHandler", () => {
    it("should return a 200 status code and a success message when the vehicle is successfully decommissioned", async () => {
        const secretMockClient = mockClient(SecretsManagerClient);
        secretMockClient.on(GetSecretValueCommand).resolves({
            SecretString: JSON.stringify({
                SecretString:"hmclsecret"
            })
        });

        const dynamodbMock = mockClient(DynamoDBClient);
        dynamodbMock.on(QueryCommand).resolves({
            "Items": [
                {
                    "TCU_ID": "1",
                    "VIRTUAL_ID": "12",
                    "VehicleStatus": "ACTIVE"
                }
            ]
        });
        
        const dynamodbDocumentClientMock = mockClient(DynamoDBDocumentClient);
        dynamodbDocumentClientMock.on(UpdateCommand).resolves({});

        const stsClientMock = mockClient(STSClient);
        stsClientMock.on(GetCallerIdentityCommand).resolves({
            "Account": "123456789012"
        });

        const iotClientMock = mockClient(IoTClient);
        iotClientMock.on(ListThingPrincipalsCommand).resolves({
            "principals": [
                "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX"
            ]
        });
        iotClientMock.on(UpdateCertificateCommand).resolves({
            "certificateId": "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX"
        });
        iotClientMock.on(DetachThingPrincipalCommand).resolves({
            "certificateId": "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX"
        });
        iotClientMock.on(DeleteCertificateCommand).resolves({
            "certificateId": "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX"
        });
        iotClientMock.on(DeleteThingCommand).resolves({});

        const iotfleetwiseClientMock = mockClient(IoTFleetWiseClient);
        iotfleetwiseClientMock.on(DeleteVehicleCommand).resolves({});

        const event = {
            "VIN": "TEST1234567890VAB"
        };

        const result = await handler(event);
        console.log(result);
        expect(result.statusCode).toEqual(200);
    });

    it("should return 400 for missing VIN", async() => {
        const event = {}
        const result = await handler(event);
        console.log(result);
        expect(result.statusCode).toEqual(400);
    })

    it("should return 400 for invalid VIN - string not matching regex", async() => {
        const event = {
            "VIN": "TEST1234567890VAI"
        }
        const result = await handler(event);
        console.log(result);
        expect(result.statusCode).toEqual(400);
    })

    it("should return 400 for invalid VIN - string length insufficient", async() => {
        const event = {
            "VIN": "TEST"
        }
        const result = await handler(event);
        console.log(result);
        expect(result.statusCode).toEqual(400);
    })

    it("should return 400 for invalid VIN - not string", async() => {
        const event = {
            "VIN": 1234
        }
        const result = await handler(event);
        console.log(result);
        expect(result.statusCode).toEqual(400);
    })

    it("should return 500 for pepper not defined", async() => {
        const secretMockClient = mockClient(SecretsManagerClient);
        secretMockClient.on(GetSecretValueCommand).resolves({
            SecretString: JSON.stringify({})
        });

        const event = {
            "VIN": "TEST1234567890VAB"
        }
        const result = await handler(event);
        console.log(result);
        expect(result.statusCode).toEqual(500);
    })

    it("should return 401 status code when VIN not found in DB", async () => {
        const secretMockClient = mockClient(SecretsManagerClient);
        secretMockClient.on(GetSecretValueCommand).resolves({
            SecretString: JSON.stringify({
                SecretString:"hmclsecret"
            })
        });

        const dynamodbMock = mockClient(DynamoDBClient);
        dynamodbMock.on(QueryCommand).resolves({
            "Items": []
        });        

        const event = {
            "VIN": "TEST1234567890VAB"
        };

        const result = await handler(event);
        console.log(result);
        expect(result.statusCode).toEqual(401);
    });

    it("should return 400 status code when vehicle already decommissioned", async () => {
        const secretMockClient = mockClient(SecretsManagerClient);
        secretMockClient.on(GetSecretValueCommand).resolves({
            SecretString: JSON.stringify({
                SecretString:"hmclsecret"
            })
        });

        const dynamodbMock = mockClient(DynamoDBClient);
        dynamodbMock.on(QueryCommand).resolves({
            "Items": [
                {
                    "TCU_ID": "1",
                    "VIRTUAL_ID": "12",
                    "VehicleStatus": "DECOMMISSIONED"
                }
            ]
        });        

        const event = {
            "VIN": "TEST1234567890VAB"
        };

        const result = await handler(event);
        console.log(result);
        expect(result.statusCode).toEqual(400);
    });

    it("should return a 500 status code when there is an error decommissioning the vehicle", async () => {
        const secretMockClient = mockClient(SecretsManagerClient);
        secretMockClient.on(GetSecretValueCommand).resolves({
            SecretString: JSON.stringify({
                SecretString:"hmclsecret"
            })
        });

        const dynamodbMock = mockClient(DynamoDBClient);
        dynamodbMock.on(QueryCommand).resolves({
            "Items": [
                {
                    "TCU_ID": "1",
                    "VIRTUAL_ID": "12",
                    "VehicleStatus": "ACTIVE"
                }
            ]
        });

        const stsClientMock = mockClient(STSClient);
        stsClientMock.on(GetCallerIdentityCommand).resolves({
            "Account": "123456789012"
        });

        const iotClientMock = mockClient(IoTClient);
        iotClientMock.on(ListThingPrincipalsCommand).resolves({
            "principals": [
                "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX"
            ]
        });
        iotClientMock.on(UpdateCertificateCommand).resolves({
            "certificateId": "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX"
        });
        iotClientMock.on(DetachThingPrincipalCommand).resolves({
            "certificateId": "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX"
        });
        iotClientMock.on(DeleteCertificateCommand).resolves({
            "certificateId": "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX"
        });
        iotClientMock.on(DeleteThingCommand).resolves({});

        const iotfleetwiseClientMock = mockClient(IoTFleetWiseClient);
        iotfleetwiseClientMock.on(DeleteVehicleCommand).resolves({});
        
        const event = {
            "VIN": "TEST1234567890VAB"
        };

        const dynamodbDocumentClientMock = mockClient(DynamoDBDocumentClient);
        dynamodbDocumentClientMock.on(UpdateCommand).rejects(new Error("Error decommissioning vehicle"));

        const result = await handler(event);
        expect(result.statusCode).toEqual(500);
    });

    it("should return a 500 status code when failure in listAndDelete certs", async () => {
        const secretMockClient = mockClient(SecretsManagerClient);
        secretMockClient.on(GetSecretValueCommand).resolves({
            SecretString: JSON.stringify({
                SecretString:"hmclsecret"
            })
        });

        const dynamodbMock = mockClient(DynamoDBClient);
        dynamodbMock.on(QueryCommand).resolves({
            "Items": [
                {
                    "TCU_ID": "1",
                    "VIRTUAL_ID": "12",
                    "VehicleStatus": "ACTIVE"
                }
            ]
        });
        
        const dynamodbDocumentClientMock = mockClient(DynamoDBDocumentClient);
        dynamodbDocumentClientMock.on(UpdateCommand).resolves({});

        const stsClientMock = mockClient(STSClient);
        stsClientMock.on(GetCallerIdentityCommand).resolves({
            "Account": "123456789012"
        });

        const iotClientMock = mockClient(IoTClient);
        iotClientMock.on(ListThingPrincipalsCommand).rejects({
            error: "Error listAndDelete certs"
        });

        const event = {
            "VIN": "TEST1234567890VAB"
        };

        const result = await handler(event);
        console.log(result);
        expect(result.statusCode).toEqual(500);
    });
}
)