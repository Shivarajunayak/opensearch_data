import { IoTClient, DescribeCertificateCommand } from "@aws-sdk/client-iot";
const config = { region: process.env.AWS_REGION };

export const handler = async (event) => {
  try {
    const client = new IoTClient(config);
    const CertificateID = event.CertificateID;
    const input = {
      certificateId: CertificateID,
    };

    if (CertificateID === undefined || CertificateID === "") {
      return {
        statusCode: 400,
        body: JSON.stringify({
          status: "FAILED",
          errorMessage: `Please pass the CertificateID`,
        }),
      };
    }

    const command = new DescribeCertificateCommand(input);
    const response = await client.send(command);

    return {
      statusCode: 200,
      body: JSON.stringify({
        status: "SUCCEEDED",
        CertificateStatus: response.certificateDescription.status,
      }),
    };
  } catch (error) {
    // Handle any errors
    return {
      statusCode: 500,
      body: JSON.stringify({
        status: "FAILED",
        errorMessage: JSON.stringify({ error: error.message }),
      }),
    };
  }
};
