import { handler } from '../index.mjs';
import { mockClient } from 'aws-sdk-client-mock';
import { IoTClient, DescribeCertificateCommand } from "@aws-sdk/client-iot";

describe("testHandler", () => {

    it("CertificateID should be passed as mandatory field and should return statusCode 400", async () => {
        const event = {
            CertificateID : ''
        };
        const ioTClientMock = mockClient(IoTClient);                
        ioTClientMock.on(DescribeCertificateCommand).resolves({certificateId:event.CertificateID}); 
        const response = await handler(event);
        expect(response.statusCode).toBe(400);
    });

    it("Get certificate status should return statusCode 200", async () => {
        const event = {
            CertificateID : '44ec0185bfcd44e184f2b9f5c7138a8f54abe322c076bcaf6f8e0a667931d525'
        };
        const ioTClientMock = mockClient(IoTClient);                
        ioTClientMock.on(DescribeCertificateCommand).resolves({certificateDescription:{status:"SUCCEEDED",CertificateStatus:"ACTIVE"}}); 
        const response = await handler(event);
        expect(response.statusCode).toBe(200);
    });

    it("Wrong CertificateID format check and should return statusCode 500", async () => {
        const event = {
            CertificateID : 'abcdef'
        };
        const ioTClientMock = mockClient(IoTClient);                
        ioTClientMock.on(DescribeCertificateCommand).resolves({body:{status:"Failed"}}); 
        const response = await handler(event);
        expect(response.statusCode).toBe(500);
    });
    
});