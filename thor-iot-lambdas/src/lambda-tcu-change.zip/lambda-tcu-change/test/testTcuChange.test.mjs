import { handler } from '../';
import { mockClient } from 'aws-sdk-client-mock';

import { DynamoDBDocumentClient, QueryCommand, UpdateCommand } from "@aws-sdk/lib-dynamodb";
import { IoTClient, DeleteThingCommand, DeleteCertificateCommand, ListThingPrincipalsCommand, UpdateCertificateCommand, DetachThingPrincipalCommand } from "@aws-sdk/client-iot";
import { IoTFleetWiseClient, DeleteVehicleCommand } from "@aws-sdk/client-iotfleetwise";
import { SecretsManagerClient, GetSecretValueCommand } from "@aws-sdk/client-secrets-manager";

describe("Test TCU Change", () => {
    it("should return statusCode 200 when tcu change is successfull", async() => {
        const docClientMock = mockClient(DynamoDBDocumentClient);
        const iotClientMock = mockClient(IoTClient);
        const iotFleetWiseClientMock = mockClient(IoTFleetWiseClient);
        const secretMockClient = mockClient(SecretsManagerClient);

        process.env.DEVICE_LEDGER_TABLE = "hmcl_cv_dev_device_ledger";
        process.env.TCU_TABLE = "hmcl_cv_dev_tcu";
        process.env.TCU_INDEX = "TCU_ID"

        docClientMock.on(QueryCommand).resolvesOnce({
            Items: [
                {
                    "VIRTUAL_ID": "test-thing-virtual-id",
                    "TCU_ID": "test-thing",
                    "VehicleStatus": "ACTIVE",
                    "IMEI": "123456789023456",
                    "VIN": "4e420cf1f018543e0ed4b78b58707e07f966bd2d59fc1592a477407e42d7cf16b40e9ee29af29709e2197848df98f2155ea37a1ab531b5aac9732f326b67c6cf"
                }
            ]
        })
        .resolvesOnce({
            Items: []
        })
        .resolvesOnce({
            Items: [
                {
                    "TCU_ID": "test-thing-new",
                    "TCU_METADATA": {
                        "BLE_PIN": "ble-pin-new",
                        "IMEI": "123456789012345"
                    }
                }
            ]
        });

        secretMockClient.on(GetSecretValueCommand).resolves({
            SecretString: JSON.stringify({
                SecretString : "hmclsecret"
            })
        });

        iotClientMock.on(ListThingPrincipalsCommand).resolves({
            principals: ["certificateArn/test-principal"]
        });
        iotClientMock.on(DetachThingPrincipalCommand).resolves({});
        iotClientMock.on(UpdateCertificateCommand).resolves({});
        iotClientMock.on(DeleteCertificateCommand).resolves({});

        iotFleetWiseClientMock.on(DeleteVehicleCommand).resolves({});

        iotClientMock.on(DeleteThingCommand).resolves({});

        docClientMock.on(UpdateCommand).resolves({});

        const event = {
            "TCU_ID": "test-thing",
            "VIN": "test-vin",
            "TCU_ID_NEW": "test-thing-new"
        };

        const response = await handler(event);
        console.log(response);
        expect(response.statusCode).toBe(200);
    });

    it("should return statusCode 200 when tcu delete is successfull", async() => {
        const docClientMock = mockClient(DynamoDBDocumentClient);
        const iotClientMock = mockClient(IoTClient);
        const iotFleetWiseClientMock = mockClient(IoTFleetWiseClient);
        const secretMockClient = mockClient(SecretsManagerClient);

        process.env.DEVICE_LEDGER_TABLE = "hmcl_cv_dev_device_ledger";
        process.env.TCU_TABLE = "hmcl_cv_dev_tcu";
        process.env.TCU_INDEX = "TCU_ID"

        docClientMock.on(QueryCommand).resolvesOnce({
            Items: [
                {
                    "VIRTUAL_ID": "test-thing-virtual-id",
                    "TCU_ID": "test-thing",
                    "VehicleStatus": "ACTIVE",
                    "VIN": "4e420cf1f018543e0ed4b78b58707e07f966bd2d59fc1592a477407e42d7cf16b40e9ee29af29709e2197848df98f2155ea37a1ab531b5aac9732f326b67c6cf"
                }
            ]
        })
        .resolvesOnce({
            Items: []
        })
        .resolvesOnce({
            Items: [
                {
                    "TCU_ID": "test-thing-new",
                    "TCU_METADATA": {
                        "BLE_PIN": "ble-pin-new"
                    }
                }
            ]
        });

        secretMockClient.on(GetSecretValueCommand).resolves({
            SecretString: JSON.stringify({
                SecretString : "hmclsecret"
            })
        });

        iotClientMock.on(ListThingPrincipalsCommand).resolves({
            principals: ["certificateArn/test-principal"]
        });
        iotClientMock.on(DetachThingPrincipalCommand).resolves({});
        iotClientMock.on(UpdateCertificateCommand).resolves({});
        iotClientMock.on(DeleteCertificateCommand).resolves({});

        iotFleetWiseClientMock.on(DeleteVehicleCommand).resolves({});

        iotClientMock.on(DeleteThingCommand).resolves({});

        docClientMock.on(UpdateCommand).resolves({});

        const event = {
            "TCU_ID": "test-thing",
            "VIN": "test-vin"
        };

        const response = await handler(event);
        console.log(response);
        expect(response.statusCode).toBe(200);
    });

    it("should return statusCode 400 when tcu is already decommissioned", async() => {
        const docClientMock = mockClient(DynamoDBDocumentClient);
        process.env.DEVICE_LEDGER_TABLE = "hmcl_cv_dev_device_ledger";
        process.env.TCU_TABLE = "hmcl_cv_dev_tcu";
        process.env.TCU_INDEX = "TCU_ID"

        docClientMock.on(QueryCommand).resolvesOnce({
            Items: [
                {
                    "VIRTUAL_ID": "test-thing-virtual-id",
                    "TCU_ID": "test-thing",
                    "VehicleStatus": "DECOMMISSIONED",
                    "VIN": "4e420cf1f018543e0ed4b78b58707e07f966bd2d59fc1592a477407e42d7cf16b40e9ee29af29709e2197848df98f2155ea37a1ab531b5aac9732f326b67c6cf"
                }
            ]
        })

        const event = {
            "TCU_ID": "test-thing",
            "VIN": "test-vin",
            "TCU_ID_NEW": "test-thing-new"
        };

        const response = await handler(event);
        console.log(response);
        expect(response.statusCode).toBe(400);
    });

    it("should return statusCode 400 when new tcu is already associated with another VIN", async() => {
        const docClientMock = mockClient(DynamoDBDocumentClient);
        process.env.DEVICE_LEDGER_TABLE = "hmcl_cv_dev_device_ledger";
        process.env.TCU_TABLE = "hmcl_cv_dev_tcu";
        process.env.TCU_INDEX = "TCU_ID"

        docClientMock.on(QueryCommand).resolvesOnce({
            Items: [
                {
                    "VIRTUAL_ID": "test-thing-virtual-id",
                    "TCU_ID": "test-thing",
                    "VehicleStatus": "ACTIVE",
                    "VIN": "4e420cf1f018543e0ed4b78b58707e07f966bd2d59fc1592a477407e42d7cf16b40e9ee29af29709e2197848df98f2155ea37a1ab531b5aac9732f326b67c6cf"
                }
            ]
        })
        .resolvesOnce({
            Items: [
                {
                    "VIRTUAL_ID": "test-thing-virtual-id-2",
                    "TCU_ID": "test-thing-mew",
                    "VehicleStatus": "ACTIVE",
                    "VIN": "41420cf1f018543e0ed4b78b58707e07f966bd2d59fc1592a477407e42d7cf16b40e9ee29af29709e2197848df98f2155ea37a1ab531b5aac9732f326b67c6cf"
                }
            ]
        })

        const event = {
            "TCU_ID": "test-thing",
            "VIN": "test-vin",
            "TCU_ID_NEW": "test-thing-new"
        };

        const response = await handler(event);
        console.log(response);
        expect(response.statusCode).toBe(400);
    });

    it("should return statusCode 400 when new TCU_ID does not exist in TCU DB", async() => {
        const docClientMock = mockClient(DynamoDBDocumentClient);
        const secretMockClient = mockClient(SecretsManagerClient);

        process.env.DEVICE_LEDGER_TABLE = "hmcl_cv_dev_device_ledger";
        process.env.TCU_TABLE = "hmcl_cv_dev_tcu";
        process.env.TCU_INDEX = "TCU_ID"

        docClientMock.on(QueryCommand).resolvesOnce({
            Items: [
                {
                    "VIRTUAL_ID": "test-thing-virtual-id",
                    "TCU_ID": "test-thing",
                    "VehicleStatus": "ACTIVE",
                    "VIN": "4e420cf1f018543e0ed4b78b58707e07f966bd2d59fc1592a477407e42d7cf16b40e9ee29af29709e2197848df98f2155ea37a1ab531b5aac9732f326b67c6cf"
                }
            ]
        })
        .resolvesOnce({
            Items: []
        })
        .resolvesOnce({
            Items: []
        });

        secretMockClient.on(GetSecretValueCommand).resolves({
            SecretString: JSON.stringify({
                SecretString : "hmclsecret"
            })
        });

        const event = {
            "TCU_ID": "test-thing",
            "VIN": "test-vin",
            "TCU_ID_NEW": "test-thing-new"
        };

        const response = await handler(event);
        console.log(response);
        expect(response.statusCode).toBe(400);
    });

    it("should return Vin Mismatch when VIN different from existing VIN", async() => {
        const docClientMock = mockClient(DynamoDBDocumentClient);
        const secretMockClient = mockClient(SecretsManagerClient);

        process.env.DEVICE_LEDGER_TABLE = "hmcl_cv_dev_device_ledger";
        process.env.TCU_TABLE = "hmcl_cv_dev_tcu";
        process.env.TCU_INDEX = "TCU_ID"

        docClientMock.on(QueryCommand).resolvesOnce({
            Items: [
                {
                    "VIRTUAL_ID": "test-thing-virtual-id",
                    "TCU_ID": "test-thing",
                    "VehicleStatus": "ACTIVE",
                    "VIN": "4e420cf1f018543e0ed4b78b58707e07f966bd2d59fc1592a477407e42d7cf16b40e9ee29af29709e2197848df98f2155ea37a1ab531b5aac9732f326b67c6cf"
                }
            ]
        })
        .resolvesOnce({
            Items: []
        })
        .resolvesOnce({
            Items: []
        });

        secretMockClient.on(GetSecretValueCommand).resolves({
            SecretString: JSON.stringify({
                SecretString : "hmclsecret"
            })
        });

        const event = {
            "TCU_ID": "test-thing",
            "VIN": "test-vin2",
            "TCU_ID_NEW": "test-thing-new"
        };

        const response = await handler(event);
        console.log(response);
        expect(response.statusCode).toBe(400);
    });
})