import { DynamoDBClient } from "@aws-sdk/client-dynamodb";
import { DynamoDBDocumentClient, QueryCommand, UpdateCommand } from "@aws-sdk/lib-dynamodb";
import { IoTClient, DeleteThingCommand, DeleteCertificateCommand, ListThingPrincipalsCommand, UpdateCertificateCommand, DetachThingPrincipalCommand } from "@aws-sdk/client-iot";
import { IoTFleetWiseClient, DeleteVehicleCommand } from "@aws-sdk/client-iotfleetwise";
import { createHash } from "crypto";
import { SecretsManagerClient, GetSecretValueCommand } from "@aws-sdk/client-secrets-manager";

const dynamoClient = new DynamoDBClient({});
const docClient = DynamoDBDocumentClient.from(dynamoClient);
const iotClient = new IoTClient({});
const iotFleetWiseClient = new IoTFleetWiseClient({});
const secretsClient = new SecretsManagerClient({});

const DEVICE_LEDGER_TABLE = process.env.DEVICE_LEDGER_TABLE;
const TCU_TABLE = process.env.TCU_TABLE;
const TCU_INDEX = process.env.TCU_INDEX;
const SECRET_STRING_NAME = process.env.SECRET_STRING_NAME;

export const handler = async (event) => {
    console.log('Received event:', event);
    try {
        let { TCU_ID, VIN, TCU_ID_NEW } = event;
        if (event.body) {
            const body = JSON.parse(event.body);
            TCU_ID = body.TCU_ID;
            VIN = body.VIN;
            TCU_ID_NEW = body.TCU_ID_NEW;
        }
        console.log(`Processing TCU change for TCU_ID: ${TCU_ID}`);

        const Item = await getVehicleFromDeviceLedger(TCU_ID);

        if (Item.VehicleStatus === 'DECOMMISSIONED') {
            if (TCU_ID_NEW) {
                console.error(`Cannot update DECOMMISSIONED TCU: ${TCU_ID}`);
                return {
                    statusCode: 400,
                    body: JSON.stringify({ status: "FAILURE", message: `Cannot update DECOMMISSIONED TCU: ${TCU_ID}` })
                };
            }
        }

        console.log('Fetching pepper from Secrets Manager');
        const pepper = await getSecretManagerValue();
        const hashedVIN = hash_with_pepper(VIN, pepper);

        console.log(`Comparing hashed VIN: ${hashedVIN.substring(0, 10)}... with stored VIN: ${Item.VIN.substring(0, 10)}...`);
        if (hashedVIN !== Item.VIN) {
            console.error('VIN mismatch');
            return {
                statusCode: 400,
                body: JSON.stringify({ status: "FAILURE", message: 'VIN mismatch' })
            };
        }

        let newBlePinValue = null;
        let newImei = null;
        if (TCU_ID_NEW) {
            const newTcuQueryParams = {
                TableName: DEVICE_LEDGER_TABLE,
                IndexName: TCU_INDEX,
                KeyConditionExpression: 'TCU_ID = :tcuId',
                ExpressionAttributeValues: {
                    ':tcuId': TCU_ID_NEW
                }
            };
            const newTcuItems = await docClient.send(new QueryCommand(newTcuQueryParams));
            if (newTcuItems.Items && newTcuItems.Items.length > 0 && newTcuItems.Items[0].VehicleStatus != "DECOMMISSIONED") {
                console.error(`TCU_ID_NEW ${TCU_ID_NEW} is already associated with another VIN`);
                return {
                    statusCode: 400,
                    body: JSON.stringify({ status: "FAILURE", message: `TCU_ID_NEW ${TCU_ID_NEW} is already associated with another VIN` })
                };
            }

            const tcuQueryParams = {
                TableName: TCU_TABLE,
                KeyConditionExpression: 'TCU_ID = :tcuId',
                ExpressionAttributeValues: {
                    ':tcuId': TCU_ID_NEW
                }
            };
            const tcuItems = await docClient.send(new QueryCommand(tcuQueryParams));
            if (!tcuItems.Items || tcuItems.Items.length === 0) {
                console.error(`TCU_ID_NEW ${TCU_ID_NEW} not found in hmcl_cv_dev_tcu table`);
                return {
                    statusCode: 400,
                    body: JSON.stringify({ status: "FAILURE", message: `TCU_ID_NEW ${TCU_ID_NEW} not found in tcu table` })
                };
            }
            newBlePinValue = tcuItems.Items[0].TCU_METADATA.BLE_PIN;
            newImei = tcuItems.Items[0].IMEI;
        }
        if (Item.VehicleStatus !== 'DECOMMISSIONED') {
            await deleteActiveVehicles(TCU_ID);
        }
        await updateModifiedVehicles(TCU_ID_NEW, Item, newBlePinValue, newImei);

        console.log('TCU change completed successfully');
        return {
            statusCode: 200,
            body: JSON.stringify({ status: "SUCCESS", message: 'TCU change completed successfully' })
        };
    } catch (error) {
        console.error('Error:', error);
        return {
            statusCode: error.code || 500,
            body: JSON.stringify({ status: 'FAILURE', message: error.message })
        };
    }
};

async function updateModifiedVehicles(TCU_ID_NEW, Item, newBlePinValue, newImei) {
    let updateExpression = 'SET TCU_ID = :newTCU_ID, updatedTsp = :timestamp';
    let expressionAttributeValues = {
        ':newTCU_ID': TCU_ID_NEW || "NULL",
        ':timestamp': new Date().toISOString()
    };

    if (Item.VehicleStatus !== 'DECOMMISSIONED') {
        updateExpression += ', VehicleStatus = :status';
        expressionAttributeValues[':status'] = TCU_ID_NEW ? 'TCU_UPDATED' : 'TCU_DELINKED';
    }

    if(!TCU_ID_NEW) {
        updateExpression += ', VehicleProperties.BLE_PIN = :newBlePin';
        expressionAttributeValues[':newBlePin'] = "NULL";
        updateExpression += ', IMEI = :imei';
        expressionAttributeValues[':imei'] = "NULL";
    }
    
    if (newBlePinValue) {
        updateExpression += ', VehicleProperties.BLE_PIN = :newBlePin';
        expressionAttributeValues[':newBlePin'] = newBlePinValue;
    }

    if (newImei) {
        updateExpression += ', IMEI = :imei';
        expressionAttributeValues[':imei'] = newImei;
    }

    const updateParams = {
        TableName: DEVICE_LEDGER_TABLE,
        Key: { VIRTUAL_ID: Item.VIRTUAL_ID },
        UpdateExpression: updateExpression,
        ExpressionAttributeValues: expressionAttributeValues
    };
    console.log('Updating DynamoDB:', JSON.stringify(updateParams, null, 2));
    await docClient.send(new UpdateCommand(updateParams));
}

async function deleteActiveVehicles(TCU_ID) {
    console.log(`Deleting certificates for TCU_ID: ${TCU_ID}`);
    const listCertificatesParams = {
        thingName: TCU_ID
    };
    const certificates = await iotClient.send(new ListThingPrincipalsCommand(listCertificatesParams));
    for (const certificateArn of certificates.principals) {
        const certificateId = certificateArn.split('/')[1];
        console.log(`Detaching certificate: ${certificateId} from thing: ${TCU_ID}`);
        await iotClient.send(new DetachThingPrincipalCommand({ thingName: TCU_ID, principal: certificateArn }));

        console.log(`Deactivating certificate: ${certificateId}`);
        await iotClient.send(new UpdateCertificateCommand({ certificateId, newStatus: 'INACTIVE' }));
        console.log(`Deleting certificate: ${certificateId}`);
        await iotClient.send(new DeleteCertificateCommand({ certificateId, forceDelete: true }));
    }

    console.log(`Deleting Fleetwise Vehicle: ${TCU_ID}`);
    const deleteVehicleParams = {
        vehicleName: TCU_ID
    };
    await iotFleetWiseClient.send(new DeleteVehicleCommand(deleteVehicleParams));

    console.log(`Deleting IoT Thing: ${TCU_ID}`);
    await iotClient.send(new DeleteThingCommand({ thingName: TCU_ID }));
}

async function getVehicleFromDeviceLedger(TCU_ID) {
    const queryParams = {
        TableName: DEVICE_LEDGER_TABLE,
        IndexName: TCU_INDEX,
        KeyConditionExpression: 'TCU_ID = :tcuId',
        ExpressionAttributeValues: {
            ':tcuId': TCU_ID
        }
    };
    console.log('Querying DynamoDB:', JSON.stringify(queryParams, null, 2));
    const { Items } = await docClient.send(new QueryCommand(queryParams));

    if (!Items || Items.length === 0) {
        console.error(`TCU_ID ${TCU_ID} not found in Device Ledger DB`);
        const error = new Error('TCU_ID not found in Device Ledger DB');
        error.code = "404"
        throw error;
    }

    const Item = Items[0];
    console.log('Found item in DynamoDB:', JSON.stringify(Item, null, 2));
    return Item;
}

function hash_with_pepper(data, pepper) {
    const combined_input = data + pepper;
    return createHash("sha512").update(combined_input).digest("hex");
}

async function getSecretManagerValue() {
    try {
        const response = await secretsClient.send(
            new GetSecretValueCommand({
                SecretId: SECRET_STRING_NAME,
                VersionStage: "AWSCURRENT",
            })
        );
        const secret = JSON.parse(response.SecretString);
        return secret.secretStringForMaskedVin;
    } catch (error) {
        console.error('Error fetching secret:', error);
        throw error;
    }
}
