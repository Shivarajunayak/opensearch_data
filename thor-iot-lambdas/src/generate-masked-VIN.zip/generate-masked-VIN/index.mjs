import { createHash } from "crypto";
import { IoTFleetWiseClient,GetFleetCommand,GetDecoderManifestCommand,GetModelManifestCommand }  from "@aws-sdk/client-iotfleetwise";
import {
  SecretsManagerClient,
  GetSecretValueCommand,
} from "@aws-sdk/client-secrets-manager";
const client = new IoTFleetWiseClient({region: process.env.AWS_REGION});
import pg from 'pg'
const { Client } = pg

import { KMSClient, EncryptCommand } from "@aws-sdk/client-kms";

const findFleet = async(fleetName) => {
  try {
    const command = new GetFleetCommand({fleetId:fleetName});
    const response = await client.send(command);
    return true
  } catch(error){
    console.log(error.message)
    return false
  }
}


const findModelManifest = async(model) => {
  try {
    const command = new GetModelManifestCommand({name:model});
    const response = await client.send(command);
    return true
  } catch(error) {
    console.log(error.message)
    return false
  }
}

const findDecoderManifest = async(decoder) => {
  try {
    const command = new GetDecoderManifestCommand({name:decoder});
    const response = await client.send(command);
    return true
  } catch(error) {
    console.log(error.message)
    return false
  }
}
//validate model,decoder,fleets present
const validateFleetResource = async(inputData) => {
  try {
    let resourceNotPresent = []
    //check tenant fleet present
    let isTntFltPresent = await findFleet(inputData.TENANT_ID)
    if(!isTntFltPresent) {
      resourceNotPresent.push(`Tenant Fleet ${inputData.TENANT_ID} Not Found`)
    }

    //check model fleet present 
    let isMdlFltPresent = await findFleet(inputData.VehicleProperties.VDS)
    if(!isMdlFltPresent) {
      resourceNotPresent.push(`Model Fleet ${inputData.VehicleProperties.VDS} Not Found`)
    }
    
    //check model manifest exists
    let isMMPresent = await findModelManifest(inputData.VehicleProperties.VDS)
    if(!isMMPresent) {
      resourceNotPresent.push(`Model Manifest ${inputData.VehicleProperties.VDS} Not Found`)
    }

    //check decoder manifest exists
    let isDMPresent = await findDecoderManifest(inputData.VehicleProperties.VDS)
    if(!isDMPresent) {
      resourceNotPresent.push(`Decoder Manifest ${inputData.VehicleProperties.VDS} Not Found`)
    }

    return resourceNotPresent

  } catch(error) {
    console.log("Something went wronng",error.toString())
    return []
  }
}

const queryPostgres = async(query,rdsClient) => {
  try{
      const res = await rdsClient.query(query)
      return {status: true,data: res.rows}
  } catch(error){ 
      console.log(error)
      console.log('error while querying rds', JSON.stringify(error))
      return {status:false,data:[]}
  }
}

const getTcuData = async(TCU_ID,secretString) => {
  try {
    const tableName = 'vehicle_provisioning.tcu_detail' //can be env variable

    const rdsClient = new Client({
      user: secretString['db.username'],
      password: secretString['db.password'],
      host: secretString['db.host'],
      port: secretString['db.port'],
      database: secretString['db.database'],
      ssl: {
          rejectUnauthorized: false // Accept self-signed certificates (adjust as needed)
      }
    })
    
    await rdsClient.connect()
    
    rdsClient.on('error', (err) => {
      console.error('---RDS Client Failed To Connect---', err)
      return null
    })
    
    const getTcuQuery =  `select tcu_id,ble_pin from ${process.env.TCU_TABLE} where tcu_id = '${TCU_ID}'`;
    const tcuData = await queryPostgres(getTcuQuery,rdsClient)
    await rdsClient.end();
    return tcuData.data
  } catch(error) {
    console.log('Error While connecting to RDS',error)
    return null
  }
}

const formatTcuResponse = async(tcuData) => {
  try {
     return {
      "TCU_ID": {
        "S": tcuData.tcu_id
      },
      "TCU_METADATA": {
        "M": {
          "BLE_PIN": {
            "S": tcuData.ble_pin
          }
        }
      }
    }

  } catch(error) {
    console.log('error formatting tcu data')
  }
}

export const handler = async (event) => {
  console.log(event);
  const VIN = event.VIN;
  let secret_name = process.env.RDS_SCRET; //should be env variable
  const KMS_KEYID = process.env.KMS_KEYID;
  const REGION = process.env.AWS_REGION;

  let preReqFleetResourceMissing = await validateFleetResource(event)
  console.log(preReqFleetResourceMissing)

  if(preReqFleetResourceMissing.length > 0) {
    return {
      statusCode: 404,
      data: preReqFleetResourceMissing
    };
  }

  const rdsSecret = await getSecretManagerValue();
  let tcuData = await getTcuData(event.TCU_ID,rdsSecret)
  
  if(tcuData == null) {
     return {
      statusCode: 500,
      data: `DataBase Client Error - Please retry provisioning`
    };
  }

  if(tcuData.length == 0) {
    return {
      statusCode: 404,
      data: `TCU ${event.TCU_ID} not provisioned`
    };
  } else {
    tcuData = tcuData[0]
  }

  tcuData = await formatTcuResponse(tcuData)

  secret_name = process.env.SECRET_STRING_NAME;

  let pepperRes = await getSecretManagerValue();
  const pepper = pepperRes.secretStringForMaskedVin;
  console.log("pepper:", pepper);
  const hashedVIN = hash_with_pepper(VIN, pepper);
  const uuid = generateUuidByVIN(VIN);
  const kmsEncryptedVIN = await getEncryptedHashedKMS(VIN);
  console.log("kmsEncryptedVIN:", kmsEncryptedVIN);

  function hash_with_pepper(data, pepper) {
    const combined_input = data + pepper;
    return createHash("sha512").update(combined_input).digest("hex");
  }

  function generateUuidByVIN(VIN) {
    const hash = createHash("sha256").update(VIN).digest("hex");
    const uuid = [
      hash.substring(0, 8),
      hash.substring(8, 4),
      "4" + hash.substring(12, 3),
      "8" + hash.substring(15, 3),
      hash.substring(18, 12),
    ].join("-");

    return uuid;
  }

  async function getSecretManagerValue() {
    const client = new SecretsManagerClient({
      region: REGION,
    });
    let resp;
    try {
      resp = await client.send(
        new GetSecretValueCommand({
          SecretId: secret_name,
          VersionStage: "AWSCURRENT",
        })
      );
    } catch (error) {
      return {
        errorMessage:error
      }
    }

    const secret = JSON.parse(resp.SecretString);
    // console.log("secret:", secret);
    return secret
  }

  async function getEncryptedHashedKMS(VIN) {
    const config = { region: REGION };
    const client = new KMSClient(config);
    const input = {
      KeyId: KMS_KEYID,
      Plaintext: new TextEncoder().encode(VIN),
    };
    const command = new EncryptCommand(input);
    const response = await client.send(command);
    return JSON.stringify(response.CiphertextBlob);
  }

  return {
    statusCode: 200,
    hashedVIN,
    kmsEncryptedVIN,
    VIRTUAL_ID: uuid,
    tcuData:tcuData
  };
};