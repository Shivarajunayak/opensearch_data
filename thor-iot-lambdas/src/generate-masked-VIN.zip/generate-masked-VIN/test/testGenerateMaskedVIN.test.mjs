import { handler } from '../';
import { mockClient } from 'aws-sdk-client-mock';
import {
    SecretsManagerClient,
    GetSecretValueCommand,
  } from "@aws-sdk/client-secrets-manager";
  
import { KMSClient, EncryptCommand } from "@aws-sdk/client-kms";

describe('Test Generate Masked VIN', () => {
    const kmsMock = mockClient(KMSClient);
    const secretsManagerMock = mockClient(SecretsManagerClient);

    beforeEach(() => {
        kmsMock.reset();
        secretsManagerMock.reset();
    });
    afterEach(() => {
        kmsMock.restore();
        secretsManagerMock.restore();
    });
    it('should encrypt the secret value and return statusCode 200', async () => {
        secretsManagerMock.on(GetSecretValueCommand).resolves({
            SecretString: JSON.stringify({
                SecretString:"hmclsecret"
            })
        });
        kmsMock.on(EncryptCommand).resolves({
            CiphertextBlob: Buffer.from('encrypted-value'),
        });
        const event = {
            VIN: 'test-vin'
        };
        const result = await handler(event);
        console.log(result);
        expect(result.statusCode).toEqual(200);
    });
});