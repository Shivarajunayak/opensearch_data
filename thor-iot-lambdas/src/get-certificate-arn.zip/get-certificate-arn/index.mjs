import { createHash } from "crypto";

export const handler = async (event) => {
  const cert = event.PemPayload.Certificate;
  const REGION = process.env.AWS_REGION;
  const ACCOUNT_ID = process.env.ACCOUNT_ID;

  const base64Der = cert.replace(
    /(-----(BEGIN|END) CERTIFICATE-----|\r|\n)/g,
    ""
  );
  const derBytes = Buffer.from(base64Der, "base64");
  const hash = createHash("sha256").update(derBytes).digest("hex");
  const CertificateId = hash.toLowerCase().replace(/(.{2})(?=.)/g, "$1");

  const CertificateArn = `arn:aws:iot:${REGION}:${ACCOUNT_ID}:cert/${CertificateId}`;

  const response = {
    CertificateId,
    CertificateArn,
    TCU_ID: event.TCU_ID,
    VIRTUAL_ID: event.MaskedPayload.Payload.VIRTUAL_ID,
    PemPayload: event.PemPayload,
  };

  return response;
};
