import { handler } from "../index.mjs";
describe("testHandler", () => {
    it("Should return 200 for the success", async () => {
      process.env.ACCOUNT_ID = 905418263290;
      const event =  {
        PemPayload : {
          Certificate : "-----BEGIN CERTIFICATE-----MIIEAzCCAuugAwIBAgIQR57f1i2JnM/qoVvI0ZvAVjANBgkqhkiG9w0BAQsFADAxMS8wLQYDVQQDDCZobWNsLWN2LWF1ZGl0LWtvbm5lY3QuaGVyb21vdG9jb3JwLmNvbTAeFw0yNDEwMDkwOTI0NDRaFw0yOTEwMDkxMDI0NDNaMIGOMQswCQYDVQQGEwJVUzELMAkGA1UECAwCQ0ExETAPBgNVBAcMCFNhcmF0b2dhMRIwEAYDVQQKDAlFeGNlbGZvcmUxEzARBgNVBAsMCnhsNF9kZXZpY2UxNjA0BgNVBAMMLTYxN2I4YzZhLThjNmEtNGI4YzZhYjBjMC04YjhjNmFiMGMwYzRjLWM0YzA1ZTCCASIwDQYJKoZIhvcNAQEBBQADggEPADCCAQoCggEBAKVjwKFtwPmqDsBrjtSQiSB11xg9xte52SccvSmyQknzMC1HWpjjxI8tR3xsEAqZjHnZsFr08MV82Xa7qZn6iThm8g5d/gIGySHpB5xSD7sMsx2BIC3JG7p9SaMhcIDG6bHkyOz/9m1t3RbF3bXNoxQqltr968E3SxxtSnB3M7ONxbIdCnGsbQK3FWJwd6eT0eQiPJe15xsUryz6hzP04oy4gk7jESuFL3qrrkAdTGstI96/busQ5nxZmE/3JWiwiM/Suzy7Gl2y/SARxbf0468x/QSZWhQw4DjkKAGjr1nX58cyi7atH77soR7+yBlhLQ0ClgxqH7HXYf6MerN7s3cCAwEAAaOBuDCBtTAqBgNVHREEIzAhgh9vdGEtZGV2Lm5vbnByb2QuaG1jbGNvbm5lY3QuY29tMAkGA1UdEwQCMAAwHwYDVR0jBBgwFoAUSv+IKxpw0Fp1I0VnCwNcTy3Mw6cwHQYDVR0OBBYEFECsrRBQLWo43W/lijq5ZTD3vxiLMCQGCWCGSAGG+EIBDQQXFhVFeGNlbGZvcmUgZGV2aWNlIGNlcnQwFgYKKwYBBAGC4yEBAQQIMQYWBHNpZ24wDQYJKoZIhvcNAQELBQADggEBAAG3Sk8RUQf30OYgXhT4JhSh/S5ase1O9tXun1njQtQjaYHryrxj33gCUFpsPM+oOdgGKu1ei+hKFWCNa67HKnBFLzAZ7zJR5iWb29i2bvTGQCtuf5D2tIh1FvVgTqHWnKm1S8cjztC5v5A/ZQVNEIpvF9LO5HBipp6SACgkftTe42sPAae58PwZJhOOxiBjQC6NkCqQkn6v5wAkwgGIBrJMnC0sQ8Nwbsbe8Sx0v8DZcxX2ysJ9dNUp+uhfuLRjZYKR6xA1Y60BIIjuXAwW8cbU2MtDPQRQnlXSUKwY63fuOoUYwZSsV2t3QF8oHL3m2SIYj55TRr1FKmGhw9Fp190=-----END CERTIFICATE-----"
        },
        MaskedPayload : {
          Payload : {
            VIRTUAL_ID : "617b8c6a-8c6a-4b8c6ab0c0-8b8c6ab0c0c4c-c4c05e"
          }
        },
        TCU_ID : 'TCU-uk-test-1'
      };
      const response = await handler(event);
      expect(response.CertificateId).toEqual('060758b28db3ad05046381d5a9bf377a54f82db311ff638f7fe8d31088fd1bf5');
    });
});