// Create jest unit test case for the directory lambda-conn-check-cert-fetch
// Import the lambda-conn-check-cert-fetch function
import { handler } from '../';
import { mockClient } from 'aws-sdk-client-mock';
import { SecretsManagerClient, GetSecretValueCommand } from '@aws-sdk/client-secrets-manager';

describe('testHandler', () => {
    it('should return the secret value', async () => {
        const secretMockClient = mockClient(SecretsManagerClient);
        secretMockClient.on(GetSecretValueCommand).resolves({
            SecretString: 'mock_secret'
        });
        
        const response = await handler();
        expect(response.statusCode).toBe(200);
    });
});


