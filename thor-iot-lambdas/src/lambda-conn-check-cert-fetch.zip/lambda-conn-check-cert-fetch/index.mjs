import { SecretsManagerClient, GetSecretValueCommand } from "@aws-sdk/client-secrets-manager";

const config = { region: process.env.REGION };
const client = new SecretsManagerClient(config);

async function getSecret(secretName) {
    const command = new GetSecretValueCommand({ SecretId: secretName });
    const response = await client.send(command);
    return response.SecretString;
}

export const handler = async(event, context, callback) => {
    try{
        const secretName = process.env.SECRET_NAME;
        const secret = await getSecret(secretName);
        const response = {
            statusCode: 200,
            headers: {
                "Content-Type": "application/json"
            },
            body: secret
        };        
        return response;
    } catch(err) {
        const response = {
            statusCode: 500, // Can be 4XX or 5XX depending on the error
            body: `{"error": ${err.messge}}`
        }        
        return response;
    }
}