import { IoTFleetWiseClient,UpdateVehicleCommand,GetVehicleCommand   }  from "@aws-sdk/client-iotfleetwise";
import {
    SecretsManagerClient,
    GetSecretValueCommand,
  } from "@aws-sdk/client-secrets-manager";
const client = new IoTFleetWiseClient({region: 'ap-south-1'});
import pg from 'pg'
const { Client } = pg

const getVehicle = async(vehicleName) => {
    try {
        let vehicleInput = {
            vehicleName: vehicleName,
            region: process.env['REGION']
        }

        const vehicleCommand = new GetVehicleCommand(vehicleInput);
        const vehicleResponse = await client.send(vehicleCommand);
        return {
            status: true,
            vehicleResponse: vehicleResponse
        }
    } catch(error) {
        console.log(`---getVehicle function error-- ${vehicleName}`)
        console.log('error while getting vehicle data')
        return formatErrorResponse('error while getting vehicle data',error.message,500)
    }
}

const updateVehicle = async(vehicleData) => {
    try {
        const updateVehicleCmd = new UpdateVehicleCommand(vehicleData);
        const lksResponse = await client.send(updateVehicleCmd);
        return {
            status: true,
        }
    } catch(error) {
        console.log(`Error updateVehicle function ${vehicleData.vehicleName}`)
        console.log(error)
        return formatErrorResponse('Error updateVehicle function',error.message,500)
    }
}

const updateVehicleClientId = async(vehicle, clientId) => {
    try {
        let vehicleData = await getVehicle(vehicle)
        if(vehicleData.status == true) {
            const vehicleRes = vehicleData.vehicleResponse
            let attributes = vehicleRes.attributes
            attributes["hmcl.b2bClientId"] = clientId
            let b2bData = {
                    "vehicleName": vehicleRes.vehicleName,
                    "modelManifestArn": vehicleRes.modelManifestArn,
                    "decoderManifestArn": vehicleRes.decoderManifestArn,
                    "attributeUpdateMode": "Merge",
                    "attributes": attributes
                }
            await updateVehicle(b2bData)
            console.log(`clientId for the vehicle ${vehicle} update successfully`)
        }
        return true
    } catch(error) {
        console.log(`updateVehicleClientId function failed ${vehicle}`)
        console.log(error)
        return formatErrorResponse('Error updateVehicle function',error.message,500)
    }
}

async function formatErrorResponse(message,error,statusCode,data=null) {
    console.log({
      statusCode: statusCode,
      body: {
        status : "failed",
        error: error,
        message : message,
        data : data,
      }
    })
    return {
      statusCode: 200,
      body: {
        message: "B2B client Id updated succesfully"
      }
    }
};

const getSecretValue = async(secret_name) => {
    try {
        const client = new SecretsManagerClient({
            region: 'ap-south-1'
        });
        const redisConfigs = await client.send(
            new GetSecretValueCommand({
              SecretId: secret_name,
              VersionStage: "AWSCURRENT", 
            })
        );
        return JSON.parse(redisConfigs.SecretString);
    } catch(error) {
        console.log('error while getting secret value')
        return formatErrorResponse('error while getting secret value',error.message,500);
    }
}

const getMappingRecord = async(vid) => {
    try {
        const secret_name = process.env.RDS_SCRET
        let rdsSecret = await getSecretValue(secret_name)
        const rdsClient = new Client({
            user: rdsSecret['db.username'],
            password: rdsSecret['db.password'],
            host: rdsSecret['db.host'],
            port: rdsSecret['db.port'],
            database: rdsSecret['db.database'],
            ssl: {
                rejectUnauthorized: false // Accept self-signed certificates (adjust as needed)
            }
          })

          await rdsClient.connect()
          console.log('RDS cliet connected succesfully')
          
          rdsClient.on('error', (err) => {
              console.error('---RDS Client Failed To Connect---', err)
              return null
          })
          
          const getTcuQuery =  `select b2b_client_id from ${process.env.B2B_MAPPING_TABLE} where vid = '${vid}' and status = 'LINKED'`; 
          const res = await rdsClient.query(getTcuQuery)
          await rdsClient.end()
          return {status: true,data: res.rows}
    } catch(error) {
        console.log(error)
        console.log('error fetching the data')
        return formatErrorResponse('error fetching the data',error.message,500);
    }
}

export const handler = async (event) => {
    try {
        let vid = event[0].MaskedPayload.Payload.VIRTUAL_ID
        let tcuId = event[0].TCU_ID
        let b2bClientId = "null"
        
        let b2bMappingData = await getMappingRecord(vid)
        
        if(b2bMappingData == null) {
            return formatErrorResponse('error fetching the data',"RDS Client Conn Failed",500);
        }
        
        if(b2bMappingData.data.length > 0) {
            b2bClientId = b2bMappingData.data[0].b2b_client_id
        } else {
            return {
                "statusCode": 200,
                "message": "B2B ClietId is not mapped to this vehicle so exiting"
            }
        }
        
        await updateVehicleClientId(tcuId,b2bClientId)
        return {
            "statusCode": 200,
            "message": "vehicle b2b mapped succesfully"
        }

    } catch(error) {
        console.log('---------handler function error error------------')
        console.log(error)
        return formatErrorResponse('error fetching the data',error.message,500);
    }
};
