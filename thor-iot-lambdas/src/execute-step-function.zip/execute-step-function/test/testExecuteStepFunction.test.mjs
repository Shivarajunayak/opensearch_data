import { handler } from "../index.mjs";
import { mockClient } from "aws-sdk-client-mock";
import { SFNClient, StartSyncExecutionCommand } from "@aws-sdk/client-sfn";

describe("testHandler", () => {
 
    it("Mandatory fields should be passed and should return statusCode 400", async () => {
       const event = {
            CSR: "",
            IMEI: "1565140126092028",
            TENANT_ID: "EV-VIDA",
            VehicleProperties: {
              FuelType: "EV",
              BatteryCapacity: "82KWH",
              VehicleType: "bike",
              Color: "blue",
              ElectricRange: "200",
              Year: "2022",
              Model: "",
              Make: "HERO",
              VDS : ""
            }
        };
        const sFNClientMock = mockClient(SFNClient);                
        sFNClientMock.on(StartSyncExecutionCommand).resolves({}); 
        const response = await handler(event);
        expect(response.statusCode).toBe(400);
    });

  it("should return statusCode 200 if response is success", async () => {
    process.env.STEPFUNCTION_ARN =
      "arn:aws:states:ap-south-1:905418263290:stateMachine:hmcl-cv-dev-device-provisioning";
    process.env.IOT_ENDPOINT = "ado8g9wcnzhl5-ats.iot.ap-south-1.amazonaws.com";
    process.env.XL4_DEVICE_ENDPOINT =
      "https://hero-esync.excelfore.com:8443/snap/oma";
    const event = {
      CSR: "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX",
      VIN: "JN1HS36P2LW140218",
      TCU_ID: "TCU-uk-test-1",
      IMEI: "1565140126092028",
      TENANT_ID: "EV-VIDA",
      VehicleProperties: {
        FuelType: "EV",
        BatteryCapacity: "82KWH",
        VehicleType: "bike",
        Color: "blue",
        ElectricRange: "200",
        Year: "2022",
        Model: "DEMO_EV_VEHICLE_MODEL",
        Make: "HERO",
        VDS: "123456",
      },
    };

    const sFNClientMock = mockClient(SFNClient);
    sFNClientMock
      .on(StartSyncExecutionCommand)
      .resolves({
        status: "SUCCEEDED",
        output: '{"CertPem":"","Virtual_ID":"8d5b9fac-9fac-4b9facfbda-8b9facfbdaea9-ea986d","CACertPem":""}'
      });
    const response = await handler(event);
    console.log("Test response:", response);
    expect(response.statusCode).toBe(200);
  }, 30000); 


  it("should return Status Code 400", async () => {
    process.env.STEPFUNCTION_ARN ="";
    process.env.IOT_ENDPOINT = "ado8g9wcnzhl5-ats.iot.ap-south-1.amazonaws.com";
    process.env.XL4_DEVICE_ENDPOINT =
      "https://hero-esync.excelfore.com:8443/snap/oma";
    const event = {
      CSR: "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX",
      VIN: "JN1HS36P2LW140218",
      TCU_ID: "TCU-uk-test-1",
      IMEI: "1565140126092028",
      TENANT_ID: "EV-VIDA",
      VehicleProperties: {
        FuelType: "EV",
        BatteryCapacity: "82KWH",
        VehicleType: "bike",
        Color: "blue",
        ElectricRange: "200",
        Year: "2022",
        Model: "DEMO_EV_VEHICLE_MODEL",
        Make: "HERO",
        VDS: "123456",
      },
    };

    const sFNClientMock = mockClient(SFNClient);
    sFNClientMock
      .on(StartSyncExecutionCommand)
      .resolves({
        status: "FAILED",
        cause:"No CA certificate exists for the given certificate (Service: Iot, Status Code: 400, Request ID: 6d0bf3d2-08cf-4962-9679-47a3d47e8649"});
    const response = await handler(event);
    console.log("Test response2:", response);
    expect(parseInt(response.statusCode)).toBe(400);
  }, 30000);

});