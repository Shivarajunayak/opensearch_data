import { SFNClient, StartSyncExecutionCommand } from "@aws-sdk/client-sfn";

const sfnClient = new SFNClient({ region: process.env.AWS_REGION });

const stateMachineArn = process.env.STEPFUNCTION_ARN;

function getErrorStatusCode(errorMessage) {
  const statusCodeMatch = errorMessage.match(/Status Code:\s*(\d+)/);

  if (statusCodeMatch) {
    const statusCode = statusCodeMatch[1];
    return statusCode;
  } else {
    return 400;
  }
}

export const handler = async (event) => {
  console.log("event:", event);
  const input = JSON.stringify(event);

  const requiredFields = ["CSR", "VIN", "TCU_ID", "IMEI", "TENANT_ID"];
  const missingFields = requiredFields.filter((field) => !event[field]);

  if (
    missingFields.length > 0 ||
    !(
      event.VehicleProperties.Model !== undefined &&
      event.VehicleProperties.Model !== ""
    ) || !(
      event.VehicleProperties.VDS !== undefined &&
      event.VehicleProperties.VDS !== ""
    )
  ) {
    return {
      statusCode: 400,
      body: JSON.stringify({
        status: "FAILED",
        errorMessage: `Mandatory required fields : ${requiredFields.join(
          ", "
        )}, VehicleProperties.Model,VehicleProperties.VDS`,
      }),
    };
  }

  try {
    // Poll for Step Function execution status
    //while (true) {
    const describeParams = {
      stateMachineArn,
      input,
    };
    const describeCommand = new StartSyncExecutionCommand(describeParams);
    console.log("describeCommand:", describeCommand);
    const describeResponse = await sfnClient.send(describeCommand);

    console.log("Polling Step Function status...", describeResponse);

    if (describeResponse.status === "SUCCEEDED") {
      const response = JSON.parse(describeResponse.output);
      console.log("final repsonse:", response);

      return {
        statusCode: 200,
        body: JSON.stringify({
          status: describeResponse.status,
          CertPem: response.CertPem,
          CACertPem: response.CACertPem,
          Endpoint: process.env.IOT_ENDPOINT,
          Virtual_ID: response.Virtual_ID,
          Xl4_device_endpoint: process.env.XL4_DEVICE_ENDPOINT,
        }),
      };
    }

    if (describeResponse.status === "FAILED") {
      console.log("describeResponse:", describeResponse);
      const errorMessage = describeResponse.cause;
      const statusCodeFromError = getErrorStatusCode(errorMessage);
      return {
        statusCode: statusCodeFromError,
        body: JSON.stringify({
          status: describeResponse.status,
          errorMessage,
        }),
      };
    }
    // Sleep for a while before polling again
    await new Promise((resolve) => setTimeout(resolve, 5000));
    //}
  } catch (error) {
    console.error("Error", error);
    return {
      statusCode: 500,
      body: JSON.stringify({
        errorMessage: error.message
      }),
    };
  }
};
