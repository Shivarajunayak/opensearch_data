import { IoTClient, UpdateCertificateCommand,DeleteCertificateCommand,ListThingPrincipalsCommand,DetachThingPrincipalCommand } from "@aws-sdk/client-iot";

export const handler = async (event) => {
  console.log('event11:',event);
  console.log('body:',event.Records[0].body);
  const REGION= process.env.AWS_REGION;
  const sqsBody = JSON.parse(event.Records[0].body);
  const thingName = sqsBody.TCU_ID;
  console.log('thingName:',thingName);
  const config = { region: REGION };

  const client = new IoTClient(config);
  
   const listPrincipalCertificateInput = { 
    thingName,
   };
  const currentCertificateId = sqsBody.CertificateId; 
  const principalCertificateListCommand = new ListThingPrincipalsCommand(listPrincipalCertificateInput);
  const principalCertificateListResponse = await client.send(principalCertificateListCommand);
  const certificateList = principalCertificateListResponse.principals;
  console.log("certificateList:",certificateList);
  if(certificateList.length>0) {
    certificateList.forEach(async(certificateArn)=>{
        const splitArr = certificateArn.split('/');
        const certificateId = splitArr[1];
        if(currentCertificateId!==certificateId){
          console.log('certificateId to delete:',certificateId);
          
          //DetachThingPrincipal
          try {
            console.log("DetachThingPrincipal called");
            const detatchPrincipalInput = {
              thingName,
              principal: certificateArn,
            };
            const detatchPrincipalCommand = new DetachThingPrincipalCommand(detatchPrincipalInput);
            const detatchPrincipalResponse = await client.send(detatchPrincipalCommand);
            console.log("detatchPrincipalResponse:",detatchPrincipalResponse);
            
          } catch (error) {
            return error;
          }
          
          //UpdateCertificate
          try {
            console.log("UpdateCertificate called");
             let updateCertificateInput = { 
              certificateId,
              newStatus: "INACTIVE"
            };
            let updateCertificateCommand = new UpdateCertificateCommand(updateCertificateInput);
            let updateCertificateResponse =  await client.send(updateCertificateCommand);
            console.log("updateCertificateResponse:",updateCertificateResponse);
  
          } catch (error) {
            return error;
          }
          
          //DeleteCertificate
          try {
             console.log("DeleteCertificate called");
            const deleteCertificateInput = {
              certificateId,
              forceDelete: true,
            };
            
            const deleteCertificateCommand = new DeleteCertificateCommand(deleteCertificateInput);
            const deleteCertificateResponse = await client.send(deleteCertificateCommand);
            console.log("deleteCertificateResponse:",deleteCertificateResponse);
  
          } catch (error) {
            return error;
          }
          
        } 
    })
 } 

  const response = {
    statusCode: 200,
    body: JSON.stringify('Certificates successfully deactivated/deleted!'),
  };
  return response;
};