import { handler } from '../';
import { mockClient } from 'aws-sdk-client-mock';
import { IoTClient, UpdateCertificateCommand,DeleteCertificateCommand,ListThingPrincipalsCommand,DetachThingPrincipalCommand } from "@aws-sdk/client-iot";

describe("Test Deactivate And Delete Older Certificate", () => {
    it("should deactivate and delete the older certificate", async () => {
        const iotClientMock = mockClient(IoTClient);
        iotClientMock.on(UpdateCertificateCommand).resolves({ certificateArn: 'XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX' });
        iotClientMock.on(ListThingPrincipalsCommand).resolves({ principals: ['arn/test-certificate-id-1', 'arn/test-certificate-id-2', 'arn/test-certificate-id-3'] });
        iotClientMock.on(DetachThingPrincipalCommand).resolves({});
        iotClientMock.on(DeleteCertificateCommand).resolves({});

        const event = {
            Records: [
              {
                messageId: 'test-message-id',
                receiptHandle: 'test-handle',
                body: '{"CertificateId":"test-certificate-id-1","TCU_ID":"test-tcu-id"}',
                attributes: [Object],
                messageAttributes: {},
                md5OfBody: 'testMd5',
                eventSource: 'aws:sqs',
                eventSourceARN: 'arn:aws:sqs:region:account:hmcl-cv-dev-deactivate-and-delete-older-certificate-sqs',
                awsRegion: 'region'
              }
            ]
        };

        const result = await handler(event);
        console.log(result);
        expect(result.statusCode).toBe(200);
    });
})