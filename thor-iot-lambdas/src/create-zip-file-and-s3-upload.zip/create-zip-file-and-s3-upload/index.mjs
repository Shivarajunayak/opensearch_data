import {
  S3Client,
  PutObjectCommand,
  GetObjectCommand,
} from "@aws-sdk/client-s3";
import { getSignedUrl } from "@aws-sdk/s3-request-presigner";
import archiver from "archiver";
import fs from "fs";
import path from "path";

const s3Client = new S3Client({ region: process.env.AWS_REGION });

export const handler = async (event) => {
  console.log("event:", event);

  const Xl4_device_endpoint = process.env.Xl4_device_endpoint;
  const Endpoint = process.env.Endpoint;
  const vehicleName = event[0].TCU_ID;
  const virtualId = event[0].MaskedPayload.Payload.VIRTUAL_ID;
  const certificate = event[0].PemPayload.Certificate;
  const cacertificate = event[0].PemPayload.CertificateChain;

  const bucketName = process.env.BUCKET_NAME;
  const zipFileName = vehicleName + ".zip";
  const zipFilePath = path.join("/tmp", zipFileName);

  const expiresIn = process.env.PresignedExpiresTime;

  try {
    // Create a file to stream archive data to
    const output = fs.createWriteStream(zipFilePath);
    const archive = archiver("zip", { zlib: { level: 9 } });

    // Listen for all archive data to be written
    output.on("close", () => {
      console.log(`${archive.pointer()} total bytes`);
      console.log(
        "archiver has been finalized and the output file descriptor has closed."
      );
    });

    archive.on("warning", (err) => {
      if (err.code !== "ENOENT") {
        throw err;
      }
    });

    // Catch critical errors
    archive.on("error", (err) => {
      throw err;
    });

    // Pipe archive data to the file
    archive.pipe(output);

    // Append files to the archive
    archive.append(Xl4_device_endpoint, { name: "xl4-endpoint.txt" });
    archive.append(Endpoint, { name: "iot-endpoint.txt" });

    archive.append(vehicleName, { name: "vehicle-name.txt" });
    archive.append(virtualId, { name: "virtualId.txt" });

    archive.append(certificate, { name: "certificate.pem" });
    archive.append(cacertificate, { name: "cacertificate.pem" });

    // Finalize the archive (ie we are done appending files but streams have to finish yet)
    await archive.finalize();

    // Wait for the output stream to be closed
    await new Promise((resolve, reject) => {
      output.on("close", resolve);
      output.on("error", reject);
    });

    // Read the zip file content
    const zipFileContent = fs.readFileSync(zipFilePath);

    // Upload the zip file to S3
    const uploadParams = {
      Bucket: bucketName,
      Key: zipFileName,
      Body: zipFileContent,
    };

    const data = await s3Client.send(new PutObjectCommand(uploadParams));
    console.log("Success", data);
    //generate the presigned url
    // Set the parameters for the getObject operation
    const params = {
      Bucket: bucketName,
      Key: vehicleName + ".zip",
      Expires: expiresIn,
    };
    const command = new GetObjectCommand(params);
    const signedUrl = await getSignedUrl(s3Client, command, { expiresIn });
    return {
      presignedUrl: signedUrl,
      key: vehicleName + ".zip",
      Virtual_ID:virtualId,
    };
  } catch (err) {
    console.error("Error", err);
    return {
      body: JSON.stringify({
        message: "Error uploading zip file",
        error: err.message,
      }),
    };
  }
};
