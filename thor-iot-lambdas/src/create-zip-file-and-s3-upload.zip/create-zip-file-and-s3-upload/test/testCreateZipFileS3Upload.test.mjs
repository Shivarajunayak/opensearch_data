import { handler } from '../index.mjs';
import { mockClient } from 'aws-sdk-client-mock';
import {
    S3Client,
    PutObjectCommand,
    GetObjectCommand,
  } from "@aws-sdk/client-s3";

describe("testHandler", () => {

    it("Get certificate retuned zip file should match", async () => {
        
        process.env.Xl4_device_endpoint='dfasdfdsdf';
        process.env.BUCKET_NAME='hmcl-cv-dev-aps1-vehicle-provisioning-unaq';
        process.env.Endpoint = 'dfsdfs';
        process.env.AWS_REGION = 'ap-south-1';
        process.env.AWS_ACCESS_KEY_ID="test"
        process.env.AWS_SECRET_ACCESS_KEY="test"
        process.env.AWS_SESSION_TOKEN="test"

        const event = [{
            TCU_ID : 'TCU-uk-test-1',
            MaskedPayload : {
                Payload: {
                    VIRTUAL_ID:'2323'
                }
            },
            PemPayload : {
                Certificate : 'XXXXXXXXXXX',
                CertificateChain : 'XXXXXXXX'
            }
        }];

        const s3ClientMock = mockClient(S3Client);                
        s3ClientMock.on(GetObjectCommand).resolves({}); 

        s3ClientMock.on(PutObjectCommand).resolves({}); 
      
        const response = await handler(event);
        expect(response.key).toEqual('TCU-uk-test-1.zip');
    });
    
});