import { SSMClient, GetParameterCommand } from '@aws-sdk/client-ssm';
import { ACMPCAClient, IssueCertificateCommand,GetCertificateCommand } from "@aws-sdk/client-acm-pca";
import { IoTClient, RegisterCertificateCommand,DescribeCertificateCommand } from "@aws-sdk/client-iot"; 

const config = { region: process.env.AWS_REGION };
const ssmClient = new SSMClient(config);
const acmPcaClient = new ACMPCAClient(config);
const iotClient = new IoTClient(config);

//Add delay in the response
const delay = ms => new Promise(resolve => setTimeout(resolve, ms));

//Get ARN from the Parameter store
async function GetCaArnFromSharedParameterStore() {
  
  const parameterName = process.env.PARAMETER_STORE_NAME;
    if (!parameterName) {
      throw new Error('Parameter name is required');
    }

    // Set up the GetParameterCommand to retrieve the Root CA ARN
    const getParameterCommand = new GetParameterCommand({
      Name: parameterName,
      WithDecryption: true,
    });

    // Send the command to the SSM client
    const response = await ssmClient.send(getParameterCommand);
    const arn = response.Parameter.Value;
    return {
      arn
    };
}

//Get the Certificate CSR Signed by RootCA
async function GetCertificateCsrSignedByRootCA(caArn, csrUint8Array, validity, validity_type,CommonName,OrganizationalUnit) {
  console.log("validity:",validity,validity_type,CommonName,OrganizationalUnit);
  try { 
    let input = {
        CertificateAuthorityArn: caArn,
        Csr: csrUint8Array,
        SigningAlgorithm: "SHA256WITHRSA",
        TemplateArn: "arn:aws:acm-pca:::template/BlankEndEntityCertificate_CSRPassthrough/V1",
        Validity: {
            Value: parseInt(validity),
            Type: validity_type,
        },
        Subject: {
            CommonName,
            Country : "US",
            Locality : "Saratoga",
            Organization : "Excelfore",
            OrganizationalUnit,
            State : "CA"
         }
    };
    console.log("input:",input);
    
    let command = new IssueCertificateCommand(input);
    const issueCertResponse = await acmPcaClient.send(command);
    console.log("issueCertResponse:",issueCertResponse);
    await delay(5000);
    return { CertificateArn : issueCertResponse.CertificateArn };
  } catch (error) {
    console.log("error:",error);
    // Handle any errors
    return {
      statusCode: 500,
      message: JSON.stringify({ error: error.message })
    };
  }
}

//Convert CSR for to be used as encoded
function GenerateEncodedCSR(CSR) {
    const encodedCSR = new TextEncoder().encode(CSR);
    return { encodedCSR };
}

//Get certificate and chain certificate from ACM PCA
async function getCertificateAndCertificateChainFromAcmPca(CertificateArn,rootCaArn) {
  
    const params = {
      CertificateArn: CertificateArn,
      CertificateAuthorityArn : rootCaArn
    }; 
    const command = new GetCertificateCommand(params);
    const response = await acmPcaClient.send(command);
    
    //Return the certificate details
    return {
        Certificate: response.Certificate,
        CertificateChain: response.CertificateChain
    };
}

//Register Certificate on IoT
async function registerCertificateOnIoT(certificatePem,caCertificatePem) {
   const input = { 
      certificatePem: certificatePem, // required
      caCertificatePem: caCertificatePem,
      setAsActive: true,
    };
    const command = new RegisterCertificateCommand(input);
    const response = await iotClient.send(command);
    
     return {
        certificateArn: response.certificateArn,
        certificateId: response.certificateId
    };
}

export const handler = async (event) => {
  try {
    const { arn } = await GetCaArnFromSharedParameterStore();
    
    const { encodedCSR } = GenerateEncodedCSR(event.CSR);
    const {CertificateArn} = await GetCertificateCsrSignedByRootCA(arn, encodedCSR, process.env.VALIDITY, process.env.VALIDITY_TYPE,event.CommonName,event.OrganizationalUnit);
    console.log('CertificateArn:',CertificateArn);
    
    const {Certificate,CertificateChain} = await getCertificateAndCertificateChainFromAcmPca(CertificateArn,arn);
    console.log('Certificate:',Certificate);
    console.log('CertificateChain:',CertificateChain);
    const {certificateId} = await registerCertificateOnIoT(Certificate,CertificateChain);
    
    // Create the command with the certificateId
    const getCertificateCommand = new DescribeCertificateCommand({ certificateId });
    const getCertificateResponse = await iotClient.send(getCertificateCommand);

    // Return the response or format it as needed
    return {
        statusCode: 200,
        body: JSON.stringify({
         message: 'Certificate retrieved successfully',
        certificateArn: getCertificateResponse.certificateDescription.certificateArn,
        certificatePem: getCertificateResponse.certificateDescription.certificatePem,
        status: getCertificateResponse.certificateDescription.status,
      }),
      };

    
  } catch (error) {
    // Handle any errors
    return {
      statusCode: 500,
      body: JSON.stringify({
      message: JSON.stringify({ error: error.message })
    }),
    };
  }
  
};