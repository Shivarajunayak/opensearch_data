import { handler } from '../index.mjs';
import { mockClient } from 'aws-sdk-client-mock';
import { SSMClient, GetParameterCommand } from '@aws-sdk/client-ssm';
import { ACMPCAClient, IssueCertificateCommand,GetCertificateCommand } from "@aws-sdk/client-acm-pca";
import { IoTClient, RegisterCertificateCommand,DescribeCertificateCommand } from "@aws-sdk/client-iot";

describe("testHandler", () => {

    it("Check that parameter store name not passed,it should return 500 status", async () => {
        const event = {
            "CSR": "XXXXXXXXXXXXXX",
            "CommonName": "uktest",
            "OrganizationalUnit": "xl4_device"
        };

        const sSMClientMock = mockClient(SSMClient);                
        sSMClientMock.on(GetParameterCommand).resolves({Parameter:{value:'XXXXX'}}); 
        const response = await handler(event);
        expect(response.statusCode).toBe(500);
    }); 

    it("Excelfore API status should return statusCode 200", async () => {
        
        process.env.PARAMETER_STORE_NAME='hmcl-cv-dev-iot-acmpca-intermediate-ca';
        process.env.VALIDITY=5;
        process.env.VALIDITY_TYPE='YEARS';

        const event = {
            "CSR": "XXXXXXXXXXXXXX",
            "CommonName": "uktest",
            "OrganizationalUnit": "xl4_device"
        };

        const sSMClientMock = mockClient(SSMClient);                
        sSMClientMock.on(GetParameterCommand).resolves({Parameter:{value:'XXXXX'}}); 

        const aCMPCAClientMock = mockClient(ACMPCAClient);                
        aCMPCAClientMock.on(IssueCertificateCommand).resolves({CertificateArn:'XXXXX',certificateArn:'XXXXX'}); 
        aCMPCAClientMock.on(GetCertificateCommand).resolves({certificateArn:'XXXXX',certificatePem:'XXXXX'}); 

        const ioTClientMock = mockClient(IoTClient);                
        ioTClientMock.on(RegisterCertificateCommand).resolves({certificateArn:'XXXXX',certificateId:'XXXXX'}); 
        ioTClientMock.on(DescribeCertificateCommand).resolves({certificateDescription:{certificateArn:'XXXXX',certificatePem:'XXXXX',status:'XXXXX'}}); 

        const response = await handler(event);
        expect(response.statusCode).toBe(200);

    },30000);
    
});