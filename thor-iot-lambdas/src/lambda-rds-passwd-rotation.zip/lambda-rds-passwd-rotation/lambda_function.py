import json
import re
import boto3
import os
import string
import random
import psycopg2
import time
from typing import Dict, Any

# Initialize AWS clients
REGION = os.environ["REGION"]
S3_BUCKET = os.environ["S3_BUCKET"]
SNS_TOPIC_ARN = os.environ["SNS_TOPIC_ARN"]
PASSWD_LENGTH = int(os.environ["PASSWD_LENGTH"])

client = boto3.client('secretsmanager', region_name=REGION)
sns = boto3.client('sns', region_name=REGION)
s3 = boto3.client('s3', region_name=REGION)

def upload_report_s3(report):
    """Uploads the report to S3 and generates a presigned URL."""
    try:
        file_name = f"{time.time()}.json"
        data = json.dumps(report, indent=4)
        s3.put_object(Bucket=S3_BUCKET, Key=file_name, Body=data)

        presigned_url = s3.generate_presigned_url(
            'get_object',
            Params={"Bucket": S3_BUCKET, "Key": file_name},
            ExpiresIn=3600
        )
        return {"status": True, "download_url": presigned_url}
    except Exception as e:
        print(f"Upload to S3 failed: {str(e)}")
        return {"status": False, "errors": str(e)}

def send_sns_notification(message, subject):
    """Sends an SNS notification."""
    try:
        sns.publish(TopicArn=SNS_TOPIC_ARN, Message=message, Subject=subject)
    except Exception as e:
        print(f"Error while sending SNS notification: {str(e)}")

def generate_password(length):
    """Generates a random password."""
    characters = string.digits + string.ascii_uppercase + string.ascii_lowercase
    return ''.join(random.choice(characters) for _ in range(length))

def connect_to_db(db_creds):
    """Attempts to connect to the database."""
    try:
        connection = psycopg2.connect(
            host=db_creds['db.host'],
            user=db_creds['db.username'],
            password=db_creds['db.password'],
            port=db_creds['db.port'],
            dbname=db_creds['db.database'],
            sslmode='require'
        )
        return {"connString": connection}
    except Exception as e:
        print(f"DB connection failed: {str(e)}")
        return {"connString": None, "errors": str(e)}

def update_db_password(connection, username, password):
    """Updates the database password."""
    try:
        cursor = connection.cursor()
        cursor.execute(f"ALTER USER {username} WITH PASSWORD '{password}';")
        connection.commit()
        cursor.close()
        return {"status": True, "errors": None}
        
    except Exception as e:
        print(f"RDS password update failed: {str(e)}")
        return {"status": False, "errors": str(e)}

def update_secret_manager(secret_name, secret_payload):
    """Updates the secret in AWS Secrets Manager."""
    try:
        client.update_secret(
            SecretId=secret_name,
            SecretString=json.dumps(secret_payload)
        )
        print(f"Secret {secret_name} updated successfully.")
        return {"status": True, "errors": None}
    except Exception as e:
        print(f"Secrets Manager update failed: {str(e)}")
        return {"status": False, "errors": str(e)}

def process_secret(secret):
    """Processes a single RDS secret."""
    secret_name = secret['Name']
    secret_value = json.loads(client.get_secret_value(SecretId=secret_name)['SecretString'])

    required_keys = {"db.host", "db.username", "db.password", "db.port", "db.database"}
    if not required_keys.issubset(secret_value.keys()):
        return None

    details = {
        "secret_string": secret_name,
        "new_password_generated": {"status": "FAILED", "error": None},
        "db_connection": {"status": "FAILED", "error": None},
        "db_passwd_update": {"status": "FAILED", "error": None},
        "secret_manager_update": {"status": "FAILED", "error": None},
        "revert_db_update": {"status": "Not Required", "error": None},
    }

    try:
        new_password = generate_password(PASSWD_LENGTH)
        details['new_password_generated']['status'] = "SUCCESS"
        conn_status = connect_to_db(secret_value)
        print(f'----{conn_status}-----')

        if conn_status['connString']:
            details['db_connection']['status'] = "SUCCESS"
            connection = conn_status['connString']

            db_update_status = update_db_password(connection, secret_value['db.username'], new_password)
            if db_update_status['status']:
                details['db_passwd_update']['status'] = "SUCCESS"
                old_password = secret_value['db.password']
                print(f'--------------old passowrd{old_password}------------')
                secret_value['db.password'] = new_password
                secret_value['password'] = new_password

                secret_update_status = update_secret_manager(secret_name, secret_value)
                if secret_update_status['status']:
                    details['secret_manager_update']['status'] = "SUCCESS"
                else:
                    details['secret_manager_update']['error'] = secret_update_status['errors']
                    revert_status = update_db_password(connection, secret_value['db.username'], old_password)
                    details['revert_db_update']['status'] = "revert-SUCCESS" if revert_status['status'] else "revert-FAILED"
                    details['revert_db_update']['error'] = revert_status['errors']
            else:
                details['db_passwd_update']['error'] = db_update_status['errors']
            connection.close()
        else:
            details['db_connection']['error'] = conn_status['errors']
    except Exception as e:
        print(f"Error processing secret {secret_name}: {str(e)}")
    return details

def list_rds_secrets():
    """Lists and processes RDS secrets."""
    try:
        # secrets = client.list_secrets(MaxResults=100)['SecretList']
        # rds_secrets = [s for s in secrets if re.search('.*hmcl.cv.*', s['Name']) and re.search('.*rds.*', s['Name'])]
        results = []
        rds_secrets = [
            {
                "Name": "hmcl-cv-dev-feature-management-rds-secret"
            }
        ]
        for secret in rds_secrets:
            resp = process_secret(secret)
            if resp:
                results.append(resp)
        return {"status": True, "response": results} if results else {"status": False, "response": []}
    except Exception as e:
        print(f"Error listing RDS secrets: {str(e)}")
        return {"status": False, "response": [], "error": str(e)}

def lambda_handler(event, context):
    """Main Lambda handler."""
    response_payload = list_rds_secrets()
    presigned_url = None

    if response_payload['status']:
        s3_upload_status = upload_report_s3(response_payload['response'])
        if s3_upload_status['status']:
            presigned_url = s3_upload_status['download_url']
           
            

    message = (
        f"Hi, RDS password rotation report uploaded to S3 Successfully.\nReport: {response_payload['response']}"
        if presigned_url
        else f"RDS password rotation report upload failed. Check CloudWatch logs for error.\n\nReport: {response_payload['response']}"
    )
    
    send_sns_notification(message, "RDS Rotation Report")

    return {
        "statusCode": 200,
        "body": json.dumps({"message": "RDS Password rotation completed"})
    }