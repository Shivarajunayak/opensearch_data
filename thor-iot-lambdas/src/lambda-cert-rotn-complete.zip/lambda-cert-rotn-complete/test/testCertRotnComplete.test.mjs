import { handler } from '../';
import { mockClient } from 'aws-sdk-client-mock';
import { DynamoDBDocumentClient, UpdateCommand, QueryCommand } from '@aws-sdk/lib-dynamodb';
import { IoTDataPlaneClient, PublishCommand } from '@aws-sdk/client-iot-data-plane';
import { SQSClient, SendMessageCommand } from '@aws-sdk/client-sqs';

describe("Test Certificate rotation complete", () => {
    it("should return statusCode as 200 when cert rotation is complete", async () => {
        const ddbMock = mockClient(DynamoDBDocumentClient);
        const iotMock = mockClient(IoTDataPlaneClient);
        const sqsMock = mockClient(SQSClient);
        process.env.SQS_QUEUE_URL = "test-topic";

        ddbMock.on(UpdateCommand).resolves({});
        ddbMock.on(QueryCommand).resolves({
            Items: [{
                "TCU_ID": "test-thing",
                "VIRTUAL_ID": "test-virtual-id",
                "vehicleStatus": "ACTIVE"
            }]
        });
        iotMock.on(PublishCommand).resolves({});

        sqsMock.on(SendMessageCommand).resolves({
            "MessageId": "test-message-id"
        });
        const event = {
            "tcuId": "test-thing",
            "CertificateId": "test-cert-id"
        }
        const response = await handler(event);
        console.log(response);
        expect(response.statusCode).toBe(200);    
    });

    it("should return statusCode as 500 when no CertificateId passed", async () => {
        const ddbMock = mockClient(DynamoDBDocumentClient);
        const iotMock = mockClient(IoTDataPlaneClient);
        const sqsMock = mockClient(SQSClient);
        process.env.SQS_QUEUE_URL = "test-topic";

        ddbMock.on(UpdateCommand).resolves({});
        ddbMock.on(QueryCommand).resolves({
            Items: [{
                "TCU_ID": "test-thing",
                "VIRTUAL_ID": "test-virtual-id",
                "vehicleStatus": "ACTIVE"
            }]
        });
        iotMock.on(PublishCommand).resolves({});
        
        sqsMock.on(SendMessageCommand).resolves({
            "MessageId": "test-message-id"
        });
        const event = {
            "tcuId": "test-thing"
        }
        const response = await handler(event);
        console.log(response);
        expect(response.statusCode).toBe(500);    
    });
})