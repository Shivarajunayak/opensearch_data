import { DynamoDBClient } from '@aws-sdk/client-dynamodb';
import { DynamoDBDocumentClient, UpdateCommand, QueryCommand } from '@aws-sdk/lib-dynamodb';
import { IoTDataPlaneClient, PublishCommand } from '@aws-sdk/client-iot-data-plane';
import { SQSClient, SendMessageCommand } from '@aws-sdk/client-sqs';

const dynamoDBClient = new DynamoDBClient({ region: process.env.REGION });
const documentClient = DynamoDBDocumentClient.from(dynamoDBClient);
const iotClient = new IoTDataPlaneClient({ region: process.env.REGION });
const sqsClient = new SQSClient({ region: process.env.REGION });

export const handler = async (event) => {
    console.log("Event: ", JSON.stringify(event));
    event.CertificateId = event.certificateId
    delete event.certificateId
    try {
        if(!event.CertificateId) {
            throw new Error("CertificateId is missing in the event");
        }
        await updateDynamoDB(event);
        await publishToSQS(event);
        await deleteRetainedMessage(event);
 
        return {
            statusCode: 200,
            body: JSON.stringify({ message: "Certificate rotation acknowledged successfully" }),
        };
    } catch (error) {
        console.error('Error in handler:', error);
        return {
            statusCode: 500,
            body: JSON.stringify({ "status": "FAILURE", error: error.message }),
        };
    }
};

async function updateDynamoDB(event) {
    const queryParams = {
        TableName: process.env.device_ledger_table,
        IndexName: process.env.tcu_index,
        KeyConditionExpression: 'TCU_ID = :tcuId',
        ExpressionAttributeValues: {
            ':tcuId': event.TCU_ID
        }
    };

    const queryResult = await documentClient.send(new QueryCommand(queryParams));

    if (queryResult.Items && queryResult.Items.length > 0) {
        const item = queryResult.Items[0];

        const updateParams = {
            TableName: process.env.device_ledger_table,
            Key: {
                'VIRTUAL_ID': item.VIRTUAL_ID
            },
            UpdateExpression: 'set certUpdateTime = :certUpdate',
            ExpressionAttributeValues: {
                ':certUpdate': event.timestamp
            },
            ReturnValues: 'ALL_NEW'
        };

        const result = await documentClient.send(new UpdateCommand(updateParams));
        console.log("DynamoDB Update Result: ", JSON.stringify(result));
    } else {
        console.log("No item found with the given TCU_ID");
        throw new Error("Item not found in DynamoDB");
    }
}

async function deleteRetainedMessage(event) {
    const topic = `hmcl/tcu/${event.TCU_ID}/rotation/csr-req`;    
    const params = {
        topic,
        payload: '', // Empty payload
        qos: 0,
        retain: true
    };

    try {
        const command = new PublishCommand(params);
        await iotClient.send(command);
        console.log('Successfully deleted retained message');
    } catch (err) {
        console.error('Failed to delete retained message:', err);
        throw err;
    }
}

async function publishToSQS(event) {
    const queueUrl = process.env.SQS_QUEUE_URL;
    const messageBody = {
        CertificateId: event.CertificateId,
        TCU_ID: event.TCU_ID
    };

    const params = {
        QueueUrl: queueUrl,
        MessageBody: JSON.stringify(messageBody),
        MessageAttributes: {
            'id': {
                DataType: 'String',
                StringValue: event.CertificateId
            }
        }
    };
    console.log("SQS Params: ", params);

    try {
        const command = new SendMessageCommand(params);
        const response = await sqsClient.send(command);
        console.log('Message sent to SQS:', response.MessageId);
    } catch (error) {
        console.error('Error sending message to SQS:', error);
        throw error;
    }
}