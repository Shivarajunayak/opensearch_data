import { S3Client, GetObjectCommand } from "@aws-sdk/client-s3";
import { getSignedUrl } from "@aws-sdk/s3-request-presigner";
import { DynamoDBClient } from "@aws-sdk/client-dynamodb";
import { DynamoDBDocumentClient, QueryCommand } from "@aws-sdk/lib-dynamodb";

const REGION = process.env.AWS_REGION;
const s3Client = new S3Client({ region: REGION });
const dynamoClient = new DynamoDBClient({ region: REGION });
const docClient = DynamoDBDocumentClient.from(dynamoClient);

export const handler = async (event) => {
  console.log('-----In handler---------');
  const { TCU_ID } = event;
  const expiresIn = process.env.PresignedExpiresTime;
  const BUCKET_NAME = process.env.BUCKET_NAME;
  const DEVICE_LEDGER_TABLE = process.env.DEVICE_LEDGER_TABLE;
  const TCU_INDEX = process.env.TCU_INDEX;

  const requiredFields = ["TCU_ID"];
  const missingFields = requiredFields.filter((field) => !event[field]);
  if (missingFields.length > 0) {
    return {
      statusCode: 400,
      body: JSON.stringify({
        status: "FAILED",
        errorMessage: `Mandatory required fields: ${requiredFields.join(", ")}`,
      }),
    };
  }

  // Check if TCU_ID exists in the device ledger database
  try {
    const queryParams = {
      TableName: DEVICE_LEDGER_TABLE,
      IndexName: TCU_INDEX,
      KeyConditionExpression: 'TCU_ID = :tcuId',
      ExpressionAttributeValues: {
        ':tcuId': TCU_ID
      }
    };

    const { Items } = await docClient.send(new QueryCommand(queryParams));
    console.log('-----Items---------',Items);
    if (!Items || Items.length === 0) {
      return {
        statusCode: 404,
        body: JSON.stringify({
          status: "FAILED",
          errorMessage: `TCU_ID ${TCU_ID} not found in Device Ledger DB`,
        }),
      };
    }
  } catch (err) {
    console.error("Error querying DynamoDB:", err);
    return {
      statusCode: 500,
      body: JSON.stringify({
        status: "FAILED",
        errorMessage: "Error checking TCU_ID in Device Ledger DB",
      }),
    };
  }

  // Set the parameters for the getObject operation
  const params = {
    Bucket: BUCKET_NAME,
    Key: TCU_ID + ".zip",
    Expires: expiresIn,
  };

  try {
    const command = new GetObjectCommand(params);
    const signedUrl = await getSignedUrl(s3Client, command, { expiresIn });

    return {
      statusCode: 200,
      body: JSON.stringify({
        presignedUrl: signedUrl,
        key: TCU_ID + ".zip",
      }),
    };
  } catch (err) {
    console.log("Error generating presigned URL:", err);
    return {
      statusCode: 400,
      body: JSON.stringify({ error: "Failed to generate presigned URL" }),
    };
  }
};
