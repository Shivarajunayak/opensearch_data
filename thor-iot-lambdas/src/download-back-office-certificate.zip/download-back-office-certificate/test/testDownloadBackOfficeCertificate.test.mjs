import { handler } from '../index.mjs';
import { mockClient } from 'aws-sdk-client-mock';
import { S3Client, GetObjectCommand } from "@aws-sdk/client-s3";
import { DynamoDBDocumentClient, QueryCommand } from "@aws-sdk/lib-dynamodb";

describe("testHandler", () => {

    it("TCU_ID should be passed as mandatory field and should return statusCode 400", async () => {
        const event = {
            TCU_ID : ''
        };
        const response = await handler(event);
        expect(response.statusCode).toBe(400);
    });

    it("Get certificate status should return statusCode 200", async () => {
        
        process.env.PresignedExpiresTime=120;
        process.env.BUCKET_NAME='hmcl-cv-dev-aps1-vehicle-provisioning-unaq';
        process.env.DEVICE_LEDGER_TABLE='hmcl_cv_dev_device_ledger';
        process.env.TCU_INDEX='TCU_ID';
        process.env.AWS_REGION='ap-south-1';
        process.env.AWS_ACCESS_KEY_ID="test"
        process.env.AWS_SECRET_ACCESS_KEY="test"
        process.env.AWS_SESSION_TOKEN="test"

        const event = {
            TCU_ID : 'TCU-uk-test-1'
        };

        const s3ClientMock = mockClient(S3Client);                
        s3ClientMock.on(GetObjectCommand).resolves({}); 

        const dynamoDBDocumentClientMock = mockClient(DynamoDBDocumentClient);               
        dynamoDBDocumentClientMock.on(QueryCommand).resolves({
            Items: [{
                "TCU_ID": "TCU-uk-test-1",
                "VIRTUAL_ID": "test-virtual-id",
                "vehicleStatus": "ACTIVE"
            }]
        });
        const response = await handler(event);
        console.log(response);
        expect(response.statusCode).toBe(200);
    });

    it("Check TCU_ID exists in DB and it should returnm StatusCode 400", async () => {
        
        process.env.PresignedExpiresTime=120;
        process.env.BUCKET_NAME='hmcl-cv-dev-aps1-vehicle-provisioning-unaq';
        process.env.DEVICE_LEDGER_TABLE='hmcl_cv_dev_device_ledger';
        process.env.TCU_INDEX='TCU_ID';
        process.env.AWS_REGION='ap-south-1'

        const event = {
            TCU_ID : 'TCU-uk-test-1-1'
        };

        const s3ClientMock = mockClient(S3Client);                
        s3ClientMock.on(GetObjectCommand).resolves({}); 

        const dynamoDBDocumentClientMock = mockClient(DynamoDBDocumentClient);               
        dynamoDBDocumentClientMock.on(QueryCommand).resolves({});
        const response = await handler(event);
        expect(response.statusCode).toBe(404);
    });
    
});