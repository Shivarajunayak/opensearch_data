import { IoTDataPlaneClient, PublishCommand } from "@aws-sdk/client-iot-data-plane";
import { SSMClient, GetParameterCommand } from "@aws-sdk/client-ssm";
import { ACMPCAClient, IssueCertificateCommand, GetCertificateCommand } from "@aws-sdk/client-acm-pca";
import { IoTClient, RegisterCertificateCommand, AttachPolicyCommand, AttachThingPrincipalCommand } from "@aws-sdk/client-iot";
import { DynamoDBClient } from "@aws-sdk/client-dynamodb";
import {QueryCommand,DynamoDBDocumentClient} from "@aws-sdk/lib-dynamodb";
import crypto from 'crypto';

const config = { region: process.env.REGION };
const acmPCAClient = new ACMPCAClient(config);
const iotClient = new IoTClient(config);
const ssmClient = new SSMClient(config);
const iotDataClient = new IoTDataPlaneClient(config);
const dynamoClient = new DynamoDBClient({});
const docClient = DynamoDBDocumentClient.from(dynamoClient);


const getDeviceDetails = async(TCU_ID) => {
    try {
        const queryParams = {
            TableName: 'hmcl_cv_dev_device_ledger',
            IndexName: 'TCU_ID',
            KeyConditionExpression: 'TCU_ID = :tcuId',
            ExpressionAttributeValues: {
                ':tcuId': TCU_ID
            }
        };
        const deviceData = await docClient.send(new QueryCommand(queryParams));
        if(deviceData.Items.length > 0) {
            for(let item of deviceData.Items) {
                if(item.VehicleStatus == "ACTIVE") {
                    return item
                }
            }
        } else {
            return null
        }
    } catch(error) {
        console.log("Error while retreiving device data",error)
        return []
    }
}


export const handler = async (event, context, callback) => {
    try {
        console.log(event);
        const CSR = event.CSR
        const tcuId = event.TCU_ID

        if (!CSR) {
            throw new Error("CSR is missing or empty");
        }
        if (!tcuId) {
            throw new Error("TCU_ID is missing or empty");
        }
        
        let deviceData = await getDeviceDetails(tcuId)

        if(deviceData == null) {
            return
        }
        const INTERMEDIATE_CA_PARAMETER_NAME = process.env.INTERMEDIATE_CA_PARAMETER_NAME
        const ROOT_CA_PARAMETER_NAME = process.env.ROOT_CA_PARAMETER_NAME
        const caArn = await getArn(INTERMEDIATE_CA_PARAMETER_NAME);
        const rootCA = await getArn(ROOT_CA_PARAMETER_NAME);
        console.log("Retrieved CA ARN:", caArn);

        let { csrUint8Array, randomString } = getEncodedCSR(CSR);

        let { issueCertResponse } = await issueCertificate(caArn, csrUint8Array, randomString,
            parseInt(process.env.VALIDITY), process.env.VALIDITY_TYPE,deviceData.VIRTUAL_ID);

        // Get Newly issued certificate
        let getCertResponse = await getCertificate(caArn, issueCertResponse);

        // Register newly created certificate with AWS IoT
        let registerIoTCertResponse = await registerCertToAWSIOT(getCertResponse);

        // Attach the policy to the certificate
        await attachPolicy(process.env.IOT_POLICY_NAME, registerIoTCertResponse);

        // Attach the certificate to the Thing (tcuId)
        await attachCertificateIoTThing(tcuId, registerIoTCertResponse.certificateArn);

        const payload = {
            CertPem: getCertResponse.Certificate,
            CACertPem: getCertResponse.CertificateChain,
            CertificateId: registerIoTCertResponse.certificateId,
            AmazonRootCa: rootCA
        };

        const topic = (process.env.TOPIC).replace("{tcuId}", tcuId);
        await publishToTopic(topic, payload);

        return { statusCode: 200, body: payload }
    } catch (error) {
        console.error("Error in Lambda handler:", error);
        return { statusCode: 500, error: error };
    }
}

async function getArn(name) {
    const input = {
        Name: name,
        WithDecryption: true
    };
    const command = new GetParameterCommand(input);
    try {
        const response = await ssmClient.send(command);
        console.log("Retrieved SSM parameter value");
        return response.Parameter.Value;
    } catch (error) {
        console.error("Error retrieving SSM parameter:", error);
        throw error;
    }
}

function getRandomNumberUsingCrypto() {
    const array = new Uint32Array(1);
    crypto.getRandomValues(array);
    return array[0];
}

function getEncodedCSR(csr) {
    let randomString = (getRandomNumberUsingCrypto() + 1).toString(36).substring(2);
    const csrUint8Array = new TextEncoder().encode(csr);
    console.log("CSR Encoded. Length:", csrUint8Array.length);
    return { csrUint8Array, randomString };
}

async function issueCertificate(caArn, csrUint8Array, randomString, validity, validity_type, vid) {
    let input = {
        "ApiPassthrough": {
            "Subject": {
              "CommonName": vid,
              "Country": "US",
              "Locality": "Saratoga",
              "Organization": "Excelfore",
              "OrganizationalUnit": "xl4_device",
              "State": "CA"
            }
        },
        CertificateAuthorityArn: caArn,
        Csr: csrUint8Array,
        SigningAlgorithm: "SHA256WITHRSA",
        TemplateArn: "arn:aws:acm-pca:::template/BlankEndEntityCertificate_APICSRPassthrough/V1",
        Validity: {
            Value: validity,
            Type: validity_type,
        },
        IdempotencyToken: randomString
    };

    console.log("IssueCertificateCommand payload:", JSON.stringify(input, null, 2));
    let command = new IssueCertificateCommand(input);
    try {
        const issueCertResponse = await acmPCAClient.send(command);
        console.log("IssueCertificateCommand response:", JSON.stringify(issueCertResponse, null, 2));
        return { issueCertResponse };
    } catch (error) {
        console.error("Error issuing certificate:", error);
        throw error;
    }
}

async function getCertificate(caArn, issueCertResponse) {
    console.log("Getting Certificate");
    let retries = 1;
    let delay = 1000;
    let maxRetries = 6;
    while (retries < maxRetries) {
        try {
            console.log("Try:", retries);
            let input = {
                CertificateAuthorityArn: caArn,
                CertificateArn: issueCertResponse.CertificateArn
            };
            const getCertCommand = new GetCertificateCommand(input);
            const getCertResponse = await acmPCAClient.send(getCertCommand);

            console.log("Certificate ARN:", issueCertResponse.CertificateArn);
            console.log("Get Cert Response received. Certificate length:", getCertResponse.Certificate.length);
            return getCertResponse;
        } catch (error) {
            console.error("Error getting certificate, attempt", retries, ":", error);
            retries++;
            delay *= 2;
            await new Promise(resolve => setTimeout(resolve, delay));
        }
    }
    throw new Error("Failed to get certificate after maximum retries");
}

async function registerCertToAWSIOT(getCertResponse) {
    let input = {
        certificatePem: getCertResponse.Certificate,
        caCertificatePem: getCertResponse.CertificateChain,
        setAsActive: true
    };
    let command = new RegisterCertificateCommand(input);
    try {
        const registerIoTCertResponse = await iotClient.send(command);
        console.log("Registered certificate. Certificate ARN:", registerIoTCertResponse.certificateArn);
        return registerIoTCertResponse;
    } catch (error) {
        console.error("Error registering certificate with AWS IoT:", error);
        throw error;
    }
}

async function attachPolicy(policyName, registerIoTCertResponse) {
    let input = {
        policyName: policyName,
        target: registerIoTCertResponse.certificateArn
    };

    let command = new AttachPolicyCommand(input);
    try {
        await iotClient.send(command);
        console.log("Attached IoT Policy to Certificate:", policyName);
    } catch (error) {
        console.error("Error attaching policy to certificate:", error);
        throw error;
    }
}

async function attachCertificateIoTThing(thingName, certificateArn) {
    const input = {
        thingName: thingName,
        principal: certificateArn,
    };
    const command = new AttachThingPrincipalCommand(input);
    try {
        await iotClient.send(command);
        console.log(`Successfully attached certificate to Thing: ${thingName}`);
    } catch (error) {
        console.error(`Error attaching certificate to Thing: ${thingName}`, error);
        throw error;
    }
}

async function publishToTopic(topic, payload) {
    let input = {
        topic: topic,
        payload: JSON.stringify(payload),
        qos: 0
    };
    console.log("Publishing to topic:", topic);
    console.log("Payload:", JSON.stringify(payload, null, 2));
    const command = new PublishCommand(input);
    try {
        await iotDataClient.send(command);
        console.log("Successfully published to topic");
    } catch (error) {
        console.error("Error publishing to topic:", error);
        throw error;
    }
}