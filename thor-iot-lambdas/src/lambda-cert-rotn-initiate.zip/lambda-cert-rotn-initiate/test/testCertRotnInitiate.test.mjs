import { handler } from '../';
import { mockClient } from 'aws-sdk-client-mock';
import { IoTDataPlaneClient, PublishCommand } from "@aws-sdk/client-iot-data-plane";
import { SSMClient, GetParameterCommand } from "@aws-sdk/client-ssm";
import { ACMPCAClient, IssueCertificateCommand, GetCertificateCommand } from "@aws-sdk/client-acm-pca";
import { IoTClient, RegisterCertificateCommand, AttachPolicyCommand, AttachThingPrincipalCommand } from "@aws-sdk/client-iot";

describe("Test Certificate Rotation Initiate", () => {
    it("should return statusCode 200 when certificate rotation is initiated by TCU", async () => {
        const ssmClientMock = mockClient(SSMClient);
        ssmClientMock.on(GetParameterCommand).resolves({
            Parameter: {
                Value: "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX"
            }
        });

        const acmpcaClientMock = mockClient(ACMPCAClient);
        acmpcaClientMock.on(IssueCertificateCommand).resolves({
            CertificateArn: "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX"
        });
        acmpcaClientMock.on(GetCertificateCommand).resolves({
            Certificate: "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX",
            CertificateChain: "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX"
        });

        const iotClientMock = mockClient(IoTClient);
        iotClientMock.on(RegisterCertificateCommand).resolves({
            certificateArn: "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX",
            certificateId: "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX"
        });
        iotClientMock.on(AttachPolicyCommand).resolves({});
        iotClientMock.on(AttachThingPrincipalCommand).resolves({});
        const iotDataPlaneClientMock = mockClient(IoTDataPlaneClient);
        iotDataPlaneClientMock.on(PublishCommand).resolves({});

        const event = {
            CSR: "XXX",
            tcuId: "test_123"
        }
        process.env.IOT_POLICY_NAME = "testPolicy"
        process.env.TOPIC = "testTopic/{tcuId}"
        const response = await handler(event);
        console.log(response);
        expect(response.statusCode).toBe(200);
    })

    it("should return 500 if CSR is not passed", async() => {
        const event = {}
        const response = await handler(event);
        console.log(response);
        expect(response.statusCode).toBe(500);
    });

    it("should return 500 if tcuId is not passed", async() => {
        const event = {
            CSR: "XXX"
        }
        const response = await handler(event);
        console.log(response);
        expect(response.statusCode).toBe(500);
    });
});