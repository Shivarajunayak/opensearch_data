import { createHash } from "crypto";
import {
    SecretsManagerClient,
    GetSecretValueCommand,
} from "@aws-sdk/client-secrets-manager";
import { DynamoDBClient, UpdateItemCommand } from '@aws-sdk/client-dynamodb';
import { DynamoDBDocumentClient, QueryCommand } from '@aws-sdk/lib-dynamodb';

import { IoTClient, AddThingToThingGroupCommand, RemoveThingFromThingGroupCommand } from "@aws-sdk/client-iot";
const REGION = process.env.REGION;
const dynamoDBClient = new DynamoDBClient({ region: REGION });
const documentClient = DynamoDBDocumentClient.from(dynamoDBClient);
const iotClient = new IoTClient({ region: REGION })
const secret_name = process.env.secret_name;
const TABLENAME = process.env.TABLENAME;

const checkInput = (event,  VIN, ProfileId, Action) => {
    if (!VIN || !ProfileId || !Action) {
        return {
            statusCode: 400,
            body: JSON.stringify({ errorMessage: 'Required parameters missing', status: 'FAILED' })
        }
    }
    const ActionArr = ['dequarantine', 'quarantine'];
    if (!ActionArr.includes(Action)) {
        return {
            statusCode: 400,
            body: JSON.stringify({ errorMessage: 'Action should be either quarantine or dequarantine', status: 'FAILED' })
        }
    }
    
    if(!event.request_headers.authorization) {
        return {
            statusCode: 401,
            body: JSON.stringify({ errorMessage: 'Missing Authorization token', status: 'FAILED' })
        }
    }
    return null;
}

const checkVehicleStatus = (VehicleStatus, Action) => {
    if (VehicleStatus === 'DECOMMISSIONED') {
        return {
            statusCode: 400,
            body: JSON.stringify({ errorMessage: 'Vehicle is already decomissioned', status: 'FAILED' })
        }
    }
    if ((VehicleStatus === 'QUARANTINED' && Action === 'quarantine')||(VehicleStatus === 'ACTIVE' && Action === 'dequarantine')) {
        return {
            statusCode: 400,
            body: JSON.stringify({ errorMessage: `Vehicle is already ${VehicleStatus}`, status: 'FAILED' })
        }
    }
    return null;
}

export const handler = async (event) => {
    const { VIN, ProfileId, Action } = JSON.parse(event.request_body);    
    try {
        const resp = checkInput(event, VIN, ProfileId, Action);

        if (resp) {
            return resp;
        }
        
        /**VIN encryption START */
        const pepper = await getSecretManagerValue();
        const hashedVIN = hash_with_pepper(VIN, pepper);
        /**VIN encryption END */
        const res = await getData(hashedVIN, 'VIN');
        if (res.length === 0) {
            return {
                statusCode: 404,
                body: JSON.stringify({ errorMessage: 'VIN does not exist', status: 'FAILED' })
            }
        }
        const VehicleStatus = res[0].VehicleStatus;        
        const respVehStatus = checkVehicleStatus(VehicleStatus, Action);
        if(respVehStatus){
            return respVehStatus;
        }
        
        const TCU_ID = res[0].TCU_ID;
        if(TCU_ID == "NULL") {
            console.error(`TCU_ID ${TCU_ID} not found in Device Ledger DB`);
            return {
                statusCode: 400,
                body: JSON.stringify({ errorMessage: `TCU_ID associated is ${TCU_ID} for the VIN ${VIN}`, status: 'FAILED' })
            }
        }
        //move to quarantine group and update status in db
        const virtualId = await moveToQuarantineGroup(res, Action);
        
        let value = false;
        if(Action === 'quarantine') {
            value=true 
        }
        //REMOTE COMMAND
        const { response, token, url } = await callCommand(virtualId, ProfileId, value, event);

        if (response.status === 'FAILURE') {
            if(response.data?.commandRefId) {
                const getOption = getOptions(response.data.commandRefId, token, url);
                const checkStatus = retry(getOption).then(res => res).catch(err => err);
                console.log(checkStatus);
            }

            return {
                statusCode: 202,
                body: JSON.stringify({
                    message: `Vehicle successfully ${Action === 'quarantine' ? 'quarantined' : 'de-quarantined'}, but remote command failed`,
                    status: 'FAILED'
                })
            }
        }       

        if (Action === 'quarantine') {
            return {
                statusCode: 200,
                body: JSON.stringify({ message: 'Vehicle successfully quarantined', status: 'SUCCEEDED' })
            }
        }
        return {
            statusCode: 200,
            body: JSON.stringify({ message: 'Vehicle successfully de-quarantined', status: 'SUCCEEDED' })
        }

    }
    catch (error) {
        console.error('Error in handler:', error);
        return {
            statusCode: 500,
            body: JSON.stringify({
                errorMessage: error.message,
                status: 'FAILED'
            })
        };
    }
};

async function moveToQuarantineGroup(res, Action) {
    const thingName = res[0].TCU_ID;
    const virtualId = res[0].VIRTUAL_ID;
    await moveThingToOtherThingGroup(thingName, Action);
    if (Action === 'quarantine') {
        await updateDbVehicleStatus(virtualId, 'QUARANTINED');
    }
    else {
        await updateDbVehicleStatus(virtualId, 'ACTIVE');
    }
    return virtualId;
}

async function callCommand(virtualId, ProfileId, value, event) {
    const postData = JSON.stringify({
        vehicleIdentifier: virtualId,
        commandCode: process.env.commandCode,
        userType: "INTERNAL",
        profileId: ProfileId,
        commandSource: "CLOUD",
        commandType: "NON_UDS",
        value: value,
        commandExecutionTimeout: process.env.commandExecutionTimeout || 10
    });
    
    const token = event.request_headers.authorization;
    if(!token) {
        throw new Error("Missing Authorization token")
    }
    
    const postOptions = {
        method: 'post',
        headers: { 
          'Content-Type': 'application/json', 
          'Authorization': `${token}`,
          "Content-Length": postData.length
        }
      };
    const response = await makeCommandRequest(postOptions, postData);
    return { response, token, url:response.url };
}

function hash_with_pepper(data, pepper) {
    const combined_input = data + pepper;
    return createHash("sha512").update(combined_input).digest("hex");
};

async function getSecretManagerValue() {

    const client = new SecretsManagerClient({
        region: REGION,
    });
    let resp;
    try {
        resp = await client.send(
            new GetSecretValueCommand({
                SecretId: secret_name,
                VersionStage: "AWSCURRENT",
            })
        );
    } catch (error) {
        return {
            errorMessage:error
          }
    }

    const secret = JSON.parse(resp.SecretString);
    return secret.secretStringForMaskedVin;
};

//get data from db with VIN
const getData = async (toSearch, key) => {
    let queryParams;
    if (key === 'VIN') {
        queryParams = {
            TableName: TABLENAME,
            IndexName: 'VIN',
            KeyConditionExpression: 'VIN = :VIN',
            ExpressionAttributeValues: {
                ':VIN': toSearch
            }
        };
    }
    try {
        const queryRes = await documentClient.send(new QueryCommand(queryParams));
        return queryRes.Items;
    }
    catch (err) {
        console.log("Unable to get data", err.message);
        throw new Error("Unable to get data")
    }
};

//update vehicle Status in dynamodb
async function updateDbVehicleStatus(virtualId, status) {
    const updatedTsp = new Date().toISOString();
    const params = {
        TableName: TABLENAME,
        Key: {
            "VIRTUAL_ID": { S: virtualId }
        },
        UpdateExpression: "set VehicleStatus =:status, updatedTsp =:updatedTsp",
        ExpressionAttributeValues: {
            ":status": { S: status },
            ":updatedTsp": { S: updatedTsp }
        },
        ReturnValues: 'ALL_NEW'
    };

    try {
        const res = await dynamoDBClient.send(new UpdateItemCommand(params));
        return res;
    }
    catch (err) {
        console.log("Unable to update vehicle status", err.message)
    }

};

//move one thing group to another
async function moveThingToOtherThingGroup(thingName, Action) {
    let thingGroupName = process.env.quarantineGroup;
    const params = {
        thingName,
        thingGroupName: thingGroupName
    };
    let response;
    try {
        if (Action === 'quarantine') {
            response = await iotClient.send(new AddThingToThingGroupCommand(params));
            return response;
        }
        else {
            response = await iotClient.send(new RemoveThingFromThingGroupCommand(params));
            return response;
        }
    }
    catch (err) {
        console.log("Could not move the things", err.message);
    }
};

//make start command api call and check status
async function makeCommandRequest(options, data = null) {
    return new Promise((resolve,reject)=> {
        let url = process.env.apiUrl;
        if(data != null) {
            options.body = data
        } else {
            url = `${process.env.apiUrl}/${options.id}`
            delete options.id
        }
        fetch(url, options)
        .then((response) => response.text())
        .then((result) => {
            result = JSON.parse(result)
            result.url = url
            resolve(result)
        })
        .catch((error) => {
            console.log(error)
            resolve({"status":'FAILURE',"data":{},"url":url})
        });
    })
};

const getOptions = (id, token) => {
    const option = {
        method: "GET",
        headers: {
            'Authorization': `${token}`
        },
        id: id
    };
    return option;
};

async function retry(option) {
    console.log("inside retry------------")
    let retries = 1;
    let delay = 1000;
    let maxRetries = 6;
    while (retries < maxRetries) {
        try {
            const checkStatus = await makeCommandRequest(option);
            if (checkStatus.status === 'SUCCESS') {
                return checkStatus;
            }
            throw new Error("Get Command execution failed. Retrying...")
        } catch (error) {
            if (retries === maxRetries) {
                throw error
            }
            retries++;
            // console.log(`Retrying...........${retries}/${maxRetries}`)
            await new Promise(resolve => setTimeout(resolve, delay));
            delay *= 2;
        }
    }
}
