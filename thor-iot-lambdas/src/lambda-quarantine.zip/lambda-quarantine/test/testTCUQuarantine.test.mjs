import { handler } from '../';
import { mockClient } from 'aws-sdk-client-mock';

import {
    SecretsManagerClient,
    GetSecretValueCommand
} from "@aws-sdk/client-secrets-manager";
import { DynamoDBClient, UpdateItemCommand } from '@aws-sdk/client-dynamodb';
import { DynamoDBDocumentClient, QueryCommand } from '@aws-sdk/lib-dynamodb';
import { IoTClient, AddThingToThingGroupCommand, RemoveThingFromThingGroupCommand } from "@aws-sdk/client-iot";
import https from 'https';

jest.mock('https')

describe("Test TCU Qurantine", () => {
    const ddbMock = mockClient(DynamoDBClient);
    const ddbDocMock = mockClient(DynamoDBDocumentClient);
    const secretsMock = mockClient(SecretsManagerClient);
    const iotClientMock = mockClient(IoTClient);

    afterEach(() => {
        ddbMock.reset();
        ddbDocMock.reset();
        secretsMock.reset();
        jest.resetAllMocks();
    });

    it("should return 200 when quarantine is successful for a vehicle", async () => {
        process.env.TABLE_NAME = "hmcl_cv_dev_device_ledger"
        process.env.TABLE_NAME_USER = "hmcl_cv_dev_user_management"
        process.env.apiUrl = "https://commandapi/test"
        process.env.commandCode = "TEST"

        secretsMock.on(GetSecretValueCommand).resolves({
            SecretString: JSON.stringify({
                SecretString: "hmclsecret"
            })
        });
        ddbDocMock.on(QueryCommand)
            .resolvesOnce({
                Items: [
                    {
                        "TCU_ID": "test-thing",
                        "VIRTUAL_ID": "test-virtual-id",
                        "VIN": "test-vin",
                        "VehicleStatus": "ACTIVE"
                    }
                ]
            });

        iotClientMock.on(AddThingToThingGroupCommand).resolves({
            "thingName": "test-thing",
            "thingGroupName": "test-thing-group"
        })
        iotClientMock.on(RemoveThingFromThingGroupCommand).resolves({
            "thingName": "test-thing",
            "thingGroupName": "test-thing-group"
        })

        await https.request.mockImplementation((options, callback) => {
            const res = {
                statusCode: 200,
                on: jest.fn().mockImplementation((event, handler) => {
                    if (event === 'data') {
                        handler(JSON.stringify({
                            data: {
                                commandRefId: "test-command-ref-id"
                            }
                        }));
                    }
                    if (event === 'end') {
                        handler();
                    }
                    if (event === 'error') {
                        handler(new Error('HTTPS request failed'));
                    }
                }),
            };
            console.log(res);
            callback(res);
            return {
                end: jest.fn(),
                on: jest.fn(),
                write: jest.fn(),
            };
        });

        ddbMock.on(UpdateItemCommand).resolves({})        

        const event = {
            request_headers: {
                authorization: 'Bearer testToken'
            },
            request_body: JSON.stringify({
                "VIN": "test-vin",
                "ProfileId": "test-profile-id",
                "Action": "quarantine",
            })
        }

        const response = await handler(event);
        console.log(response);
        expect(response.statusCode).toBe(200);
    }, 5000)

    it("should return 200 when dequarantine is successful for a vehicle", async () => {
        process.env.TABLE_NAME = "hmcl_cv_dev_device_ledger"
        process.env.TABLE_NAME_USER = "hmcl_cv_dev_user_management"
        process.env.apiUrl = "https://commandapi/test"
        process.env.commandCode = "TEST"

        secretsMock.on(GetSecretValueCommand).resolves({
            SecretString: JSON.stringify({
                SecretString: "hmclsecret"
            })
        });
        ddbDocMock.on(QueryCommand)
            .resolvesOnce({
                Items: [
                    {
                        "TCU_ID": "test-thing",
                        "VIRTUAL_ID": "test-virtual-id",
                        "VIN": "test-vin",
                        "VehicleStatus": "QUARANTINED"
                    }
                ]
            });

        iotClientMock.on(AddThingToThingGroupCommand).resolves({
            "thingName": "test-thing",
            "thingGroupName": "test-thing-group"
        })
        iotClientMock.on(RemoveThingFromThingGroupCommand).resolves({
            "thingName": "test-thing",
            "thingGroupName": "test-thing-group"
        })

        await https.request.mockImplementation((options, callback) => {
            const res = {
                statusCode: 200,
                on: jest.fn().mockImplementation((event, handler) => {
                    if (event === 'data') {
                        handler(JSON.stringify({
                            data: {
                                commandRefId: "test-command-ref-id"
                            }
                        }));
                    }
                    if (event === 'end') {
                        handler();
                    }
                    if (event === 'error') {
                        handler(new Error('HTTPS request failed'));
                    }
                }),
            };
            console.log(res);
            callback(res);
            return {
                end: jest.fn(),
                on: jest.fn(),
                write: jest.fn(),
            };
        });

        ddbMock.on(UpdateItemCommand).resolves({})        

        const event = {
            request_headers: {
                authorization: 'Bearer testToken'
            },
            request_body: JSON.stringify({
                "VIN": "test-vin",
                "ProfileId": "test-profile-id",
                "Action": "dequarantine",
            })
        }

        const response = await handler(event);
        console.log(response);
        expect(response.statusCode).toBe(200);
    }, 5000)

    it("should return 400 when VIN is not given in request", async () => {
        const event = {
            request_body : JSON.stringify({
            "ProfileId": "test-profile-id",
            "Action": "quarantine",
            })
        }

        const response = await handler(event);
        console.log(response);
        expect(response.statusCode).toBe(400);
    })

    it("should return 400 when wrong Action is given", async () => {
        const event = {
            request_body : JSON.stringify({
            "VIN": "test-vin",
            "ProfileId": "test-profile-id",
            "Action": "ACTIVE",
            })
        }

        const response = await handler(event);
        console.log(response);
        expect(response.statusCode).toBe(400);
    });

    it("should return 400 when vehicle is already decommissioned", async() => {
        process.env.TABLE_NAME = "hmcl_cv_dev_device_ledger"
        process.env.TABLE_NAME_USER = "hmcl_cv_dev_user_management"
        process.env.apiUrl = "https://commandapi/test"

        secretsMock.on(GetSecretValueCommand).resolves({
            SecretString: JSON.stringify({
                SecretString: "hmclsecret"
            })
        });
        ddbDocMock.on(QueryCommand)
            .resolvesOnce({
                Items: [
                    {
                        "TCU_ID": "test-thing",
                        "VIRTUAL_ID": "test-virtual-id",
                        "VIN": "test-vin",
                        "VehicleStatus": "DECOMMISSIONED"
                    }
                ]
            });

        const event = {
            request_headers: {
                authorization: 'Bearer testToken'
            },
            request_body : JSON.stringify({
            "VIN": "test-vin",
            "ProfileId": "test-profile-id",
            "Action": "quarantine",
            })
        }

        const response = await handler(event);
        console.log(response);
        expect(response.statusCode).toBe(400);
    });

    it("should return 400 when vehicle is already quarantined", async () => {
        process.env.TABLE_NAME = "hmcl_cv_dev_device_ledger"
        process.env.TABLE_NAME_USER = "hmcl_cv_dev_user_management"
        process.env.apiUrl = "XXXXXXXXXXXXXXXXXXXXXXX"

        secretsMock.on(GetSecretValueCommand).resolves({
            SecretString: JSON.stringify({
                SecretString: "hmclsecret"
            })
        });
        ddbDocMock.on(QueryCommand)
            .resolvesOnce({
                Items: [
                    {
                        "TCU_ID": "test-thing",
                        "VIRTUAL_ID": "test-virtual-id",
                        "VIN": "test-vin",
                        "VehicleStatus": "QUARANTINED"
                    }
                ]
            });

        const event = {
            request_headers: {
                authorization: 'Bearer testToken'
            },
            request_body : JSON.stringify({
            "VIN": "test-vin",
            "ProfileId": "test-profile-id",
            "Action": "quarantine",
            })
        }

        const response = await handler(event);
        console.log(response);
        expect(response.statusCode).toBe(400);
    })

    it("should return 400 when vehicle is already dequarantined", async () => {
        process.env.TABLE_NAME = "hmcl_cv_dev_device_ledger"
        process.env.TABLE_NAME_USER = "hmcl_cv_dev_user_management"
        process.env.apiUrl = "XXXXXXXXXXXXXXXXXXXXXXX"

        secretsMock.on(GetSecretValueCommand).resolves({
            SecretString: JSON.stringify({
                SecretString: "hmclsecret"
            })
        });
        ddbDocMock.on(QueryCommand)
            .resolvesOnce({
                Items: [
                    {
                        "TCU_ID": "test-thing",
                        "VIRTUAL_ID": "test-virtual-id",
                        "VIN": "test-vin",
                        "VehicleStatus": "ACTIVE"
                    }
                ]
            });

        const event = {
            request_headers: {
                authorization: 'Bearer testToken'
            },
            request_body : JSON.stringify({
            "VIN": "test-vin",
            "ProfileId": "test-profile-id",
            "Action": "dequarantine",
            })
        }

        const response = await handler(event);
        console.log(response);
        expect(response.statusCode).toBe(400);
    })

    it("should return 202 when quarantine command is failure", async () => {
        process.env.TABLE_NAME = "hmcl_cv_dev_device_ledger"
        process.env.TABLE_NAME_USER = "hmcl_cv_dev_user_management"
        process.env.apiUrl = "https://commandapi/test"

        secretsMock.on(GetSecretValueCommand).resolves({
            SecretString: JSON.stringify({
                SecretString: "hmclsecret"
            })
        });
        ddbDocMock.on(QueryCommand)
            .resolvesOnce({
                Items: [
                    {
                        "TCU_ID": "test-thing",
                        "VIRTUAL_ID": "test-virtual-id",
                        "VIN": "test-vin",
                        "VehicleStatus": "ACTIVE"
                    }
                ]
            });

        iotClientMock.on(AddThingToThingGroupCommand).resolves({
            "thingName": "test-thing",
            "thingGroupName": "test-thing-group"
        })
        iotClientMock.on(RemoveThingFromThingGroupCommand).resolves({
            "thingName": "test-thing",
            "thingGroupName": "test-thing-group"
        })

        await https.request.mockImplementation((options, callback) => {
            const res = {
                statusCode: 400,
                on: jest.fn().mockImplementation((event, handler) => {
                    if (event === 'data') {
                        handler(JSON.stringify({
                            status: "FAILURE",
                            data: {
                                commandRefId: "test-command-ref-id"
                            }
                        }));
                    }
                    if (event === 'end') {
                        handler();
                    }
                    if (event === 'error') {
                        handler(new Error('HTTPS request failed'));
                    }
                }),
            };
            console.log(res);
            callback(res);
            return {
                end: jest.fn(),
                on: jest.fn(),
                write: jest.fn(),
            };
        });

        const event = {
            request_headers: {
                authorization: 'Bearer testToken'
            },
            request_body : JSON.stringify({
            "VIN": "test-vin",
            "ProfileId": "test-profile-id",
            "Action": "quarantine",
            })
        }

        const response = await handler(event);
        console.log(response);
        expect(response.statusCode).toBe(202);
    })
})
