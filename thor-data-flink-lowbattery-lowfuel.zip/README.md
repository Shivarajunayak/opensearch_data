# thor-data-cloud-alerts

# Steps:
1. **DOWNLOAD AND INSTALL KAFKA**: https://kafka.apache.org/quickstart
2. **RUN ZOOKEEPER**: bin/zookeeper-server-start.sh config/zookeeper.properties
3. **RUN KAFKA**: bin/kafka-server-start.sh config/server.properties
4. **DOWNLOAD FLINK**: https://www.apache.org/dyn/closer.lua/flink/flink-1.19.0/flink-1.19.0-bin-scala_2.12.tgz
5. **EXTRACT CONTENT**: tar -xzf flink-*.tgz
6. **START FLINK**: ./bin/start-cluster.sh
7. **SUBMIT JOB**: ./bin/flink run /filepath/thor-data-lowbattery-lowfuel-alerts/target/thor-data-lowbattery-lowfuel-alerts-1.0-SNAPSHOT.jar
8. **PUSH SPEED DATA TO SOURCE TOPIC**: bin/kafka-console-producer.sh --topic thor.data.low.battery.source.v1 --bootstrap-server localhost:9092, RECORD: {"deviceId":"device_01","VIN":"user1","batterySoC":18,"timestamp":1715781422000}

bin/kafka-console-producer.sh --topic thor.data.low.fuel.source.v1 --bootstrap-server localhost:9092, RECORD: {"deviceId":"device_01","VIN":"user1","fuelLevel":4.5,"timestamp":1715781422000}

9. **LISTEN ON TO SINK TOPIC FOR ALERT**: bin/kafka-console-consumer.sh --topic thor.data.low.battery.sink.v1 --from-beginning --bootstrap-server localhost:9092

bin/kafka-console-consumer.sh --topic thor.data.low.fuel.sink.v1 --from-beginning --bootstrap-server localhost:9092
