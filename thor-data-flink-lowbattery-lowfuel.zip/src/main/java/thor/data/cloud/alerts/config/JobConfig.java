package thor.data.cloud.alerts.config;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

@AllArgsConstructor
@NoArgsConstructor
@Data
@Builder
public class JobConfig implements Serializable {
    private String jobName;
    private int restartAttempts;
    private int delayBetweenRestarts;
    private CheckpointConfigs checkpointConfigs;
    private KafkaConfig consumerConfigs;
    private KafkaConfig producerConfigs;
    private StreamConfig lowFuel;
    private StreamConfig lowTractionBattery;
    private StreamConfig modelConfig;
    private int redisTtl;
    private String externalUrl;
}
