package thor.data.cloud.alerts.config;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class CheckpointConfigs implements Serializable {
    private boolean checkpointingEnabled;
    private long checkpointInterval;
    private long minPauseBetweenCheckpoints;
    private long checkpointTimeoutInterval;
    private int maxConcurrentCheckpoints;
    private boolean preferCheckpointForRecovery;
    private String checkpointDataUri;
    private String checkpointStorageUrl;
}
