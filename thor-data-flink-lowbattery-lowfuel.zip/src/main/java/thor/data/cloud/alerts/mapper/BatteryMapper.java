package thor.data.cloud.alerts.mapper;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.extern.slf4j.Slf4j;
import org.apache.flink.api.common.functions.MapFunction;
import thor.data.cloud.alerts.model.BatteryData;
import thor.data.cloud.alerts.model.CampaignData;
import thor.data.cloud.alerts.model.SocUserValues;

import java.util.*;


@Slf4j
public class BatteryMapper implements MapFunction<String, BatteryData> {
    private final ObjectMapper mapper = new ObjectMapper();

    public BatteryData map(String event) throws Exception {
        try {
            CampaignData campaignData = mapper.readValue(event, CampaignData.class);
            return setBatteryData(campaignData);
        }catch (Exception e){
            log.error("batteryData ERROR: {}", event);
            log.error("Error: ", e);
            return null;
        }
    }

    private BatteryData setBatteryData(CampaignData campaignData) throws JsonProcessingException {
        BatteryData batteryData = new BatteryData();
        if(campaignData.getDimensions().get("hmcl.virtualId") != null){
            batteryData.setDeviceId(campaignData.getDimensions().get("hmcl.virtualId"));
        }
        if(campaignData.getDimensions().get("hmcl.vds") != null){
            batteryData.setVds(campaignData.getDimensions().get("hmcl.vds"));
        }
        if(campaignData.getDimensions().get("hmcl.tenantId") != null){
            batteryData.setTenantId(campaignData.getDimensions().get("hmcl.tenantId"));
        }
        if(campaignData.getCollectionEventTime() != null){
            batteryData.setTimestamp(campaignData.getCollectionEventTime().toString());
        }
        if(campaignData.getSignals().get("hmcl.ev.can0.bms1_soc_user_percentage") != null){
            batteryData.setBms1_soc_user_percentage(
                    getLatestBatterySocUserValues(campaignData.getSignals().get("hmcl.ev.can0.bms1_soc_user_percentage")));
        }
        if(campaignData.getSignals().get("hmcl.ev.can0.bms2_soc_user_percentage") != null){
            batteryData.setBms2_soc_user_percentage(
                    getLatestBatterySocUserValues(campaignData.getSignals().get("hmcl.ev.can0.bms2_soc_user_percentage")));
        }
        if(campaignData.getSignals().get("hmcl.common.vcan0.latitude") != null){
            batteryData.setLatitude(
                    getLatestBatterySocUserValues(campaignData.getSignals().get("hmcl.common.vcan0.latitude")));
        }

        if(campaignData.getSignals().get("hmcl.common.vcan0.longitude") != null){
            batteryData.setLongitude(
                    getLatestBatterySocUserValues(campaignData.getSignals().get("hmcl.common.vcan0.longitude")));
        }
        if(campaignData.getSignals().get("hmcl.ev.can0.odo_reading") != null){
            batteryData.setOdo_reading(
                    getLatestBatterySocUserValues(campaignData.getSignals().get("hmcl.ev.can0.odo_reading")));
        }
        if(campaignData.getSignals().get("hmcl.common.vcan0.tcu_ignition") != null){
            batteryData.setTcu_ignition(
                    getLatestBatterySocUserValues(campaignData.getSignals().get("hmcl.common.vcan0.tcu_ignition")));
        }
        if(campaignData.getSignals().get("hmcl.common.vcan0.gps_fix") != null){
            batteryData.setGps_fix(
                    getLatestBatterySocUserValues(campaignData.getSignals().get("hmcl.common.vcan0.gps_fix")));
        }
        if(campaignData.getSignals().get("hmcl.common.vcan0.gps_valid") != null){
            batteryData.setGps_valid(
                    getLatestBatterySocUserValues(campaignData.getSignals().get("hmcl.common.vcan0.gps_valid")));
        }
        if(campaignData.getSignals().get("hmcl.common.vcan0.vdop") != null){
            batteryData.setVdop(
                    getLatestBatterySocUserValues(campaignData.getSignals().get("hmcl.common.vcan0.vdop")));
        }
        if(campaignData.getSignals().get("hmcl.common.vcan0.pdop") != null){
            batteryData.setPdop(
                    getLatestBatterySocUserValues(campaignData.getSignals().get("hmcl.common.vcan0.pdop")));
        }
        if(campaignData.getSignals().get("hmcl.common.vcan0.hdop") != null){
            batteryData.setHdop(
                    getLatestBatterySocUserValues(campaignData.getSignals().get("hmcl.common.vcan0.hdop")));
        }
        if(null == batteryData.getBms1_soc_user_percentage() || null == batteryData.getBms2_soc_user_percentage())
            return null;
        return batteryData;
    }

    private SocUserValues getLatestBatterySocUserValues(ArrayList<SocUserValues> batterySocValues) throws JsonProcessingException {
        SocUserValues battery_soc_user_value = batterySocValues.stream().max(Comparator.comparing(SocUserValues::getTime)).get();
        return battery_soc_user_value;
    }

}
