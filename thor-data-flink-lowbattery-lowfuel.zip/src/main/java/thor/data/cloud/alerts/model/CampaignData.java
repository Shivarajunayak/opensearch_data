package thor.data.cloud.alerts.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.Map;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class CampaignData {
    private String campaignName;
    private String vehicleName;
    private Long eventId;
    private Long collectionEventTime;
    private Map<String,String> dimensions;
    private Map<String, ArrayList<SocUserValues>> signals;
}
