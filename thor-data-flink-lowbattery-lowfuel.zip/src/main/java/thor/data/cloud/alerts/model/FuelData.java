package thor.data.cloud.alerts.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class FuelData {
    private String deviceId;
    private String vds;
    private String tenantId;
    private String timestamp;
    private SocUserValues fuel_percentage;
    private SocUserValues fuel_level_volts;
    private SocUserValues latitude;
    private SocUserValues longitude;
    private SocUserValues odo_reading;
    private SocUserValues tcu_ignition;
    private SocUserValues gps_fix;
    private SocUserValues gps_valid;
    private SocUserValues vdop;
    private SocUserValues pdop;
    private SocUserValues hdop;
}
