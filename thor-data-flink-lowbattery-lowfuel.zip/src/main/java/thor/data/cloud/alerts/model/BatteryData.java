package thor.data.cloud.alerts.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Map;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class BatteryData {
    private String deviceId;
    private String vds;
    private String tenantId;
    private String timestamp;
    private SocUserValues bms1_soc_user_percentage;
    private SocUserValues bms2_soc_user_percentage;
    private SocUserValues latitude;
    private SocUserValues longitude;
    private SocUserValues odo_reading;
    private SocUserValues tcu_ignition;
    private SocUserValues gps_fix;
    private SocUserValues gps_valid;
    private SocUserValues vdop;
    private SocUserValues pdop;
    private SocUserValues hdop;
}
