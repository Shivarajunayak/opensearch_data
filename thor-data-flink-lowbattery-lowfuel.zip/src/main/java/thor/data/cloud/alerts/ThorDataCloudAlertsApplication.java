package thor.data.cloud.alerts;

import com.amazonaws.services.s3.model.BucketLifecycleConfiguration;
import lombok.extern.slf4j.Slf4j;
import org.apache.flink.api.common.eventtime.WatermarkStrategy;
import org.apache.flink.api.common.functions.MapFunction;
import org.apache.flink.api.common.serialization.SimpleStringSchema;
import org.apache.flink.api.common.state.MapStateDescriptor;
import org.apache.flink.api.common.typeinfo.BasicTypeInfo;
import org.apache.flink.api.common.typeinfo.TypeInformation;
import org.apache.flink.api.common.typeinfo.Types;
import org.apache.flink.api.java.tuple.Tuple2;
import org.apache.flink.api.java.typeutils.ListTypeInfo;
import org.apache.flink.api.java.utils.ParameterTool;
import org.apache.flink.connector.base.DeliveryGuarantee;
import org.apache.flink.connector.kafka.sink.KafkaRecordSerializationSchema;
import org.apache.flink.connector.kafka.sink.KafkaSink;
import org.apache.flink.connector.kafka.source.KafkaSource;
import org.apache.flink.connector.kafka.source.enumerator.initializer.OffsetsInitializer;
import org.apache.flink.connector.kafka.source.reader.deserializer.KafkaRecordDeserializationSchema;
import org.apache.flink.contrib.streaming.state.RocksDBStateBackend;
import org.apache.flink.runtime.state.StateBackend;
import org.apache.flink.shaded.jackson2.com.fasterxml.jackson.dataformat.yaml.YAMLFactory;
import org.apache.flink.streaming.api.CheckpointingMode;
import org.apache.flink.streaming.api.datastream.*;
import org.apache.flink.streaming.api.environment.CheckpointConfig;
import org.apache.flink.streaming.api.environment.StreamExecutionEnvironment;


import org.apache.flink.streaming.api.functions.co.CoMapFunction;
import org.apache.kafka.common.serialization.StringDeserializer;
import org.apache.kerby.config.Conf;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;

import thor.data.cloud.alerts.config.CheckpointConfigs;
import thor.data.cloud.alerts.config.KafkaConfig;
import thor.data.cloud.alerts.config.StreamConfig;
import thor.data.cloud.alerts.constants.RuntimeConstants;
import thor.data.cloud.alerts.filters.NullFilters;
import thor.data.cloud.alerts.mapper.BatteryMapper;
import thor.data.cloud.alerts.mapper.FuelMapper;
import thor.data.cloud.alerts.mapper.ModelConfigMapper;
import thor.data.cloud.alerts.model.BatteryData;
import thor.data.cloud.alerts.model.ConfigModel;
import thor.data.cloud.alerts.model.FuelData;
import thor.data.cloud.alerts.processor.LowFuelProcessor;
import thor.data.cloud.alerts.processor.LowTractionBatteryProcessor;
import thor.data.cloud.alerts.config.JobConfig;
import thor.data.cloud.alerts.util.FileUtil;
import thor.data.cloud.alerts.util.ConnectorUtils;

@Slf4j
public class ThorDataCloudAlertsApplication {

    private static final Logger logger = LoggerFactory.getLogger(ThorDataCloudAlertsApplication.class);
    private static final String JASS_CONFIG = "software.amazon.msk.auth.iam.IAMLoginModule required awsRoleArn=\"%s\" awsRoleSessionName=\"%s\" awsStsRegion=\"%s\";";

    public static void main(String[] args) throws Exception {
        final StreamExecutionEnvironment env = StreamExecutionEnvironment.getExecutionEnvironment();
        JobConfig jobConfig = null;
        try{
            logger.info("Fetching Configs from Runtime Props.......");
            final ParameterTool parameterTool = ConnectorUtils.getRuntimeParameters(args, env);
            jobConfig = fetchRuntimeConfigs(parameterTool);
        } catch (Exception e){
            logger.info("No Runtime Props available!");
            logger.info("Fetching Configs from local config.yml.......");
            jobConfig = new org.apache.flink.shaded.jackson2.com.fasterxml.jackson.databind.ObjectMapper(new YAMLFactory()).readValue(FileUtil.readFile(args[0]), JobConfig.class);
        }
        logger.info("JOB CONFIG: {}", jobConfig);
        configureCheckpoint(env, jobConfig);
        process(env, jobConfig);
        env.execute(jobConfig.getJobName());
    }

    private static void configureCheckpoint(StreamExecutionEnvironment env, JobConfig config) throws Exception {
        if(config.getCheckpointConfigs().isCheckpointingEnabled()) {
            env.getCheckpointConfig().setCheckpointingMode(CheckpointingMode.AT_LEAST_ONCE);
            env.getCheckpointConfig().setCheckpointStorage(config.getCheckpointConfigs().getCheckpointStorageUrl());
            env.enableCheckpointing(config.getCheckpointConfigs().getCheckpointInterval());
            env.getCheckpointConfig().setMinPauseBetweenCheckpoints(config.getCheckpointConfigs().getMinPauseBetweenCheckpoints());
            env.getCheckpointConfig().setCheckpointTimeout(config.getCheckpointConfigs().getCheckpointTimeoutInterval());
            env.getCheckpointConfig().setMaxConcurrentCheckpoints(config.getCheckpointConfigs().getMaxConcurrentCheckpoints());
            env.getCheckpointConfig()
                    .enableExternalizedCheckpoints(
                            CheckpointConfig.ExternalizedCheckpointCleanup.RETAIN_ON_CANCELLATION);
            StateBackend rocksDBStateBackend = new RocksDBStateBackend(config.getCheckpointConfigs().getCheckpointDataUri(),
                    true);
            env.setStateBackend(rocksDBStateBackend);
        }
    }

    private static Map<String, Properties> setConsumerAndProducerProperties(JobConfig config) {
        Map<String, Properties> properties = new HashMap<>();
        Properties consumerProps = new Properties();
        consumerProps.setProperty("bootstrap.servers", config.getConsumerConfigs().getBootstrapServers());
        consumerProps.setProperty("group.id", config.getConsumerConfigs().getGroupId());
        consumerProps.setProperty("auto.offset.reset", config.getConsumerConfigs().getAutoOffsetReset());
        Properties producerProps = new Properties();
        producerProps.setProperty("bootstrap.servers", config.getProducerConfigs().getBootstrapServers());
        producerProps.setProperty("acks", String.valueOf(config.getProducerConfigs().getProducerAcks()));
        properties.put("consumerProps",consumerProps);
        properties.put("producerProps",producerProps);
        return properties;
    }

    public static void process(StreamExecutionEnvironment env, JobConfig config){
        Map<String, Properties> properties = setConsumerAndProducerProperties(config);
        String jassConfig = String.format(JASS_CONFIG, config.getConsumerConfigs().getMskRoleArn(),
                config.getConsumerConfigs().getMskSessionName(), config.getConsumerConfigs().getMskAwsRegion());

        KafkaSource<String> modelconfigSource =  KafkaSource.<String>builder()
                .setBootstrapServers(config.getConsumerConfigs().getBootstrapServers()).setTopics(config.getModelConfig().getSourceTopic())
                .setGroupId(config.getConsumerConfigs().getGroupId() + "_MC").setStartingOffsets(OffsetsInitializer.latest())
                .setProperty("partition.discovery.interval.ms", "10000") // discover new partitions per 10 seconds
                .setProperty("security.protocol", "SASL_SSL")
                .setProperty("sasl.mechanism", "AWS_MSK_IAM")
                .setProperty("sasl.jaas.config", jassConfig)
                .setProperty("sasl.client.callback.handler.class", "software.amazon.msk.auth.iam.IAMClientCallbackHandler")
                .setValueOnlyDeserializer(new SimpleStringSchema()).build();

        KafkaSource<String> telemetrySourceLB =  KafkaSource.<String>builder()
                .setBootstrapServers(config.getConsumerConfigs().getBootstrapServers()).setTopics(config.getLowTractionBattery().getSourceTopic())
                .setGroupId(config.getConsumerConfigs().getGroupId() + "_LB").setStartingOffsets(OffsetsInitializer.latest())
                .setProperty("partition.discovery.interval.ms", "10000") // discover new partitions per 10 seconds
                .setProperty("security.protocol", "SASL_SSL")
                .setProperty("sasl.mechanism", "AWS_MSK_IAM")
                .setProperty("sasl.jaas.config", jassConfig)
                .setProperty("sasl.client.callback.handler.class", "software.amazon.msk.auth.iam.IAMClientCallbackHandler")
                .setValueOnlyDeserializer(new SimpleStringSchema()).build();

        KafkaSource<String> telemetrySourceLF =  KafkaSource.<String>builder()
                .setBootstrapServers(config.getConsumerConfigs().getBootstrapServers()).setTopics(config.getLowFuel().getSourceTopic())
                .setGroupId(config.getConsumerConfigs().getGroupId() + "_LF").setStartingOffsets(OffsetsInitializer.latest())
                .setProperty("partition.discovery.interval.ms", "10000") // discover new partitions per 10 seconds
                .setProperty("security.protocol", "SASL_SSL")
                .setProperty("sasl.mechanism", "AWS_MSK_IAM")
                .setProperty("sasl.jaas.config", jassConfig)
                .setProperty("sasl.client.callback.handler.class", "software.amazon.msk.auth.iam.IAMClientCallbackHandler")
                .setValueOnlyDeserializer(new SimpleStringSchema()).build();

        KafkaSink<String> alertSink = KafkaSink.<String>builder()
                .setBootstrapServers(config.getConsumerConfigs().getBootstrapServers()).setKafkaProducerConfig(properties.get("producerProps"))
                .setProperty("security.protocol", "SASL_SSL")
                .setProperty("sasl.mechanism", "AWS_MSK_IAM")
                .setProperty("sasl.jaas.config", jassConfig)
                .setProperty("sasl.client.callback.handler.class", "software.amazon.msk.auth.iam.IAMClientCallbackHandler")
                .setRecordSerializer(KafkaRecordSerializationSchema.builder()
                        .setTopic(config.getLowTractionBattery().getSinkTopic()) // alert topic for both streams is same.
                        .setValueSerializationSchema(new SimpleStringSchema())
                        .build()
                )
                .setDeliveryGuarantee(DeliveryGuarantee.AT_LEAST_ONCE)
                .build();

        DataStreamSource<String> modelconfigStream = env.fromSource(modelconfigSource, WatermarkStrategy.noWatermarks(), "model-config-source");
        DataStreamSource<String> telemetryStreamLB = env.fromSource(telemetrySourceLB, WatermarkStrategy.noWatermarks(), "telemetry-source-lb");
        DataStreamSource<String> telemetryStreamLF = env.fromSource(telemetrySourceLF, WatermarkStrategy.noWatermarks(), "telemetry-source-lf");

        MapStateDescriptor<String, ConfigModel> modelConfigStateDescriptor =
                new MapStateDescriptor<>("modelconfig", Types.STRING, Types.POJO(ConfigModel.class));

        BroadcastStream<ConfigModel> modelConfigBroadcastStream = modelconfigStream
                .map(new ModelConfigMapper()).name("mc-mapper").uid("mc-mapper")
                .broadcast(modelConfigStateDescriptor);

        DataStream<String> lbStream = telemetryStreamLB
                .map(new BatteryMapper()).name("lb-mapper").uid("lb-mapper")
                .filter(new NullFilters<>()).name("lb-null-filter").uid("lb-null-filter")
                .keyBy(BatteryData::getDeviceId)
                .connect(modelConfigBroadcastStream)
                .process(new LowTractionBatteryProcessor(config)).name("lb-process").uid("lb-process");
        lbStream.sinkTo(alertSink).name("lb-alert-sink").uid("lb-alert-sink");

        DataStream<String> lfStream = telemetryStreamLF
                .map(new FuelMapper()).name("lf-mapper").uid("lf-mapper")
               .filter(new NullFilters<>()).name("lf-null-filter").uid("lf-null-filter")
               .keyBy(FuelData::getDeviceId)
                .connect(modelConfigBroadcastStream)
                .process(new LowFuelProcessor(config)).name("lf-process").uid("lf-process");
        lfStream.sinkTo(alertSink).name("lf-alert-sink").uid("lf-alert-sink");
    }

    public static JobConfig fetchRuntimeConfigs(ParameterTool parameterTool){
        KafkaConfig kafkaConfig = KafkaConfig.builder()
                .bootstrapServers(parameterTool.get(RuntimeConstants.KAFKA_BOOTSTRAP_SERVERS))
                .autoOffsetReset(parameterTool.get(RuntimeConstants.KAFKA_AUTO_OFFSET_RESET, "latest"))
                .groupId(parameterTool.get(RuntimeConstants.KAFKA_GROUP_ID, "thor-lf-lb-alert-v1"))
                .producerAcks(parameterTool.getInt(RuntimeConstants.KAFKA_PRODUCER_ACKS, 1))
                .mskAwsRegion(parameterTool.get(RuntimeConstants.KAFKA_MSK_AWS_REGION, "ap-south-1"))
                .mskRoleArn(parameterTool.get(RuntimeConstants.KAFKA_MSK_ROLE_ARN, "roleArn"))
                .mskSessionName(parameterTool.get(RuntimeConstants.KAFKA_MSK_SESSION_NAME, "sessionName"))
                .build();
        CheckpointConfigs checkpointConfigs = CheckpointConfigs.builder()
                .checkpointingEnabled(parameterTool.getBoolean(RuntimeConstants.CHECKPOINT_CHECKPOINTING_ENABLED, true))
                .checkpointInterval(parameterTool.getLong(RuntimeConstants.CHECKPOINT_CHECKPOINTING_INTERVAL_IN_MS, 60000L))
                .checkpointDataUri(parameterTool.get(RuntimeConstants.CHECKPOINT_DATA_URI, "file:///localpath"))
                .checkpointStorageUrl(parameterTool.get(RuntimeConstants.CHECKPOINT_DATA_URI, "file:///localpath"))
                .checkpointTimeoutInterval(parameterTool.getLong(RuntimeConstants.CHECKPOINT_CHECKPOINTING_TIMEOUT_INTERVAL_IN_MS, 10000L))
                .minPauseBetweenCheckpoints(parameterTool.getLong(RuntimeConstants.CHECKPOINT_MIN_PAUSE_BTN_CHECKPOINTS_IN_MS, 10000L))
                .maxConcurrentCheckpoints(parameterTool.getInt(RuntimeConstants.CHECKPOINT_MAX_CONCURRENT_CHECKPOINTS, 1))
                .build();
        StreamConfig lowFuelStreamConfig = StreamConfig.builder()
                .sourceTopic(parameterTool.get(RuntimeConstants.LOW_FUEL_SOURCE_TOPIC, "low_fuel_source_v1"))
                .sourceParallelism(parameterTool.getInt(RuntimeConstants.LOW_FUEL_SOURCE_PARALLELISM, 1))
                .mapParallelism(parameterTool.getInt(RuntimeConstants.LOW_FUEL_MAP_PARALLELISM, 1))
                .processParallelism(parameterTool.getInt(RuntimeConstants.LOW_FUEL_PROCESS_PARALLELISM, 1))
                .sinkTopic(parameterTool.get(RuntimeConstants.LOW_FUEL_SINK_TOPIC, "notification_sink_v1"))
                .sinkParallelism(parameterTool.getInt(RuntimeConstants.LOW_FUEL_SINK_PARALLELISM, 1))
                .build();
        StreamConfig lowTractionBatteryStreamConfig = StreamConfig.builder()
                .sourceTopic(parameterTool.get(RuntimeConstants.LOW_TRACTION_BATTERY_SOURCE_TOPIC, "low_traction_battery_source_v1"))
                .sourceParallelism(parameterTool.getInt(RuntimeConstants.LOW_TRACTION_BATTERY_SOURCE_PARALLELISM, 1))
                .mapParallelism(parameterTool.getInt(RuntimeConstants.LOW_TRACTION_BATTERY_MAP_PARALLELISM, 1))
                .processParallelism(parameterTool.getInt(RuntimeConstants.LOW_TRACTION_BATTERY_PROCESS_PARALLELISM, 1))
                .sinkTopic(parameterTool.get(RuntimeConstants.LOW_TRACTION_BATTERY_SINK_TOPIC, "notification_sink_v1"))
                .sinkParallelism(parameterTool.getInt(RuntimeConstants.LOW_TRACTION_BATTERY_SINK_PARALLELISM, 1))
                .build();
        StreamConfig modelConfigStreamConfig = StreamConfig.builder()
                .sourceTopic(parameterTool.get(RuntimeConstants.MODEL_CONFIG_SOURCE_TOPIC, "model_config_source_v1"))
                .build();
        return JobConfig.builder()
                .jobName("thor-lowfuel-lowtractionbattery-job")
                .restartAttempts(1)
                .delayBetweenRestarts(5)
                .checkpointConfigs(checkpointConfigs)
                .consumerConfigs(kafkaConfig)
                .producerConfigs(kafkaConfig)
                .lowFuel(lowFuelStreamConfig)
                .lowTractionBattery(lowTractionBatteryStreamConfig)
                .modelConfig(modelConfigStreamConfig)
                .redisTtl(parameterTool.getInt(RuntimeConstants.REDIS_TTL, 8))
                .externalUrl(parameterTool.get(RuntimeConstants.SERVICE_URL_MODEL_CONFIGS, "localhost:8000"))
                .build();
    }


}
