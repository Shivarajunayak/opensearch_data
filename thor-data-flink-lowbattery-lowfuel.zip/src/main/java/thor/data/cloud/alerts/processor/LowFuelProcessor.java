package thor.data.cloud.alerts.processor;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.extern.slf4j.Slf4j;
import org.apache.flink.api.common.state.BroadcastState;
import org.apache.flink.api.common.state.MapState;
import org.apache.flink.api.common.state.MapStateDescriptor;
import org.apache.flink.api.common.typeinfo.Types;
import org.apache.flink.configuration.Configuration;
import org.apache.flink.streaming.api.functions.KeyedProcessFunction;
import org.apache.flink.streaming.api.functions.co.KeyedBroadcastProcessFunction;
import org.apache.flink.util.Collector;
import org.json.JSONObject;
import thor.data.cloud.alerts.config.JobConfig;
import thor.data.cloud.alerts.model.*;

import java.util.*;

@Slf4j
public class LowFuelProcessor extends KeyedBroadcastProcessFunction<String, FuelData,ConfigModel, String> {
    private MapState<String, LowFuelAlertState> fuelState;
    private MapState<String, LowFuelAlertState> fuelStateForLatePackets;
    private BroadcastState<String, ConfigModel> bcState;
    private final ObjectMapper mapper = new ObjectMapper();
    private Double fuelLevelThresholdForPercentage;
    private Double fuelLevelThresholdForVolts;
    private final Long outOfOrderTimeThresholdInMSforAlertNotification = 60000L; // 10 mins
    private final Long outOfOrderTimeThresholdInMSforAlert = 14400000L; // 4 hours
    private final Long outOfOrderTimeThresholdInMS = 86400000L; // 1 day
    private MapStateDescriptor<String, ConfigModel> modelConfigMap;

    private JobConfig jobConfig;

    public LowFuelProcessor(JobConfig jobConfig) {
        this.jobConfig = jobConfig;
    }

    public void open(Configuration configuration) throws Exception {
        MapStateDescriptor<String, LowFuelAlertState> vehicleStateMap = new MapStateDescriptor<>("fuel_map", String.class, LowFuelAlertState.class);
        MapStateDescriptor<String, LowFuelAlertState> vehicleStateforLatePacketsMap = new MapStateDescriptor<>("fuel_late_arriving_map", String.class, LowFuelAlertState.class);
        this.fuelState = getRuntimeContext().getMapState(vehicleStateMap);
        this.fuelStateForLatePackets = getRuntimeContext().getMapState(vehicleStateforLatePacketsMap);
        modelConfigMap = new MapStateDescriptor<>("modelconfig", Types.STRING, Types.POJO(ConfigModel.class));

    }
    public void processElement(FuelData fuelData, KeyedBroadcastProcessFunction<String, FuelData,ConfigModel, String>.ReadOnlyContext context, Collector<String> collector) throws Exception {
        try {
            ConfigModel configModel = getConfigData(fuelData);
            String fuelValue = null;
            SocUserValues fuelLevel = null;

            fuelValue = configModel.getConfigDetails().get("unit").toString();
            Map<String, Boolean> filterMetadata = filterPacketsOnTimeOfArrival(fuelData, context.getCurrentKey(),
                    fuelValue.equalsIgnoreCase("fuel_percentage"));
            if(filterMetadata.get("isPacketReject"))
                return;
            if(null != fuelData.getFuel_percentage() && fuelValue.equalsIgnoreCase("fuel_percentage")) {
                    fuelLevel = fuelData.getFuel_percentage();
                    fuelLevelThresholdForPercentage = Double.parseDouble(configModel.getConfigDetails().get("lowThreshold").toString());
                    if(!filterMetadata.get("isLatePacket"))
                        computeLowFuel(fuelData, context, collector, fuelLevel, true);
                    else
                        computeLowFuelForOOOPackets(fuelData, context, collector, fuelLevel, true);
            }
             if(null != fuelData.getFuel_level_volts() && fuelValue.equalsIgnoreCase("fuel_level_volts")) {
                    fuelLevel = fuelData.getFuel_level_volts();
                    fuelLevelThresholdForVolts = Double.valueOf(configModel.getConfigDetails().get("lowThreshold").toString());
                    log.info("fuelLevelThresholdForVolts: {}", fuelLevelThresholdForVolts);

                    if(!filterMetadata.get("isLatePacket"))
                        computeLowFuel(fuelData, context, collector, fuelLevel, false);
                    else
                        computeLowFuelForOOOPackets(fuelData, context, collector, fuelLevel, false);
            }
        }catch (Exception e){
            log.error("Exception in processor", e);
        }
    }


    private void computeLowFuelForOOOPackets(FuelData fuelData, KeyedBroadcastProcessFunction<String, FuelData,ConfigModel, String>.ReadOnlyContext context,
                                             Collector<String> collector, SocUserValues fuelLevel, Boolean isFuelPercentage) throws Exception {
        log.info("LF Processing OOO Packet: {}", context.getCurrentKey());
        boolean isFuelLevelLow = false; long packetTimestamp = getTimeValue(fuelLevel.getTime());
        if(isFuelPercentage){
            if(Double.parseDouble(fuelLevel.getValue().toString()) <= fuelLevelThresholdForPercentage){
                log.info("Low Fuel in fuel_percentage detected: {}", fuelData);
                isFuelLevelLow = true;
            }
        } else{
            if(Double.parseDouble(fuelLevel.getValue().toString()) <= fuelLevelThresholdForVolts){
                log.info("Low Fuel in fuel_volts detected: {}", fuelData);
                isFuelLevelLow = true;
            }
        }
        if(isFuelLevelLow){
            if (fuelStateForLatePackets.isEmpty()) {
                log.info("LF No existing late packet state found for: {}", context.getCurrentKey());
                LowFuelAlertState lowFuelAlertState = LowFuelAlertState.builder().build();
                sendAlert(fuelData, context, collector, false);
                setLatePacketLowFuelAlertState(fuelData, true, context, lowFuelAlertState);
            } else {
                LowFuelAlertState lowFuelAlertState = fuelStateForLatePackets.get(context.getCurrentKey());
                log.info("LF Existing late packet state found for: {}", context.getCurrentKey());
                if (packetTimestamp < lowFuelAlertState.getDetectionWindowStartTimestamp()){
                    sendAlert(fuelData, context, collector, false);
                    setLatePacketLowFuelAlertState(fuelData, true, context, lowFuelAlertState);
                } else{
                    if (!lowFuelAlertState.getIsAlertSent()) {
                        log.info("LF Reached a new low after reset! Sending Alert!");
                        setLatePacketLowFuelAlertState(fuelData, true, context, lowFuelAlertState);
                        sendAlert(fuelData, context, collector, false);
                    }
                }
            }
        }else{
            if(!fuelStateForLatePackets.isEmpty()){
                log.info("LF Resetting late packet state for: {}", context.getCurrentKey());
                LowFuelAlertState lowFuelAlertState = fuelStateForLatePackets.get(context.getCurrentKey());
                setLatePacketLowFuelAlertState(fuelData,false, context, lowFuelAlertState);
            }
        }

    }


    private void computeLowFuel(FuelData fuelData,KeyedBroadcastProcessFunction<String, FuelData,ConfigModel, String>.ReadOnlyContext context, Collector<String> collector, SocUserValues fuelLevel, Boolean isFuelPercentage) throws Exception {
        if(isFuelPercentage){
            if(Double.parseDouble(fuelLevel.getValue().toString()) <= fuelLevelThresholdForPercentage){
                log.info("Low Fuel in fuel_percentage detected: {}", fuelData);
                checkAgainstThreshold(fuelData, context, collector);
            }
            else{
                if(!fuelState.isEmpty()){
                    log.info("LF Resetting STATE for: {}", context.getCurrentKey());
                    LowFuelAlertState lowFuelAlertState = fuelState.get(context.getCurrentKey());
                    setLowFuelAlertState(fuelData,false, context, lowFuelAlertState);
                }
            }
        }else{
            if(Double.parseDouble(fuelLevel.getValue().toString()) <= fuelLevelThresholdForVolts){
                log.info("Low Fuel in fuel_level_volts detected: {}", fuelData);
                checkAgainstThreshold(fuelData, context, collector);
            }
            else{
                if(!fuelState.isEmpty()){
                    log.info("LF Resetting STATE for: {}", context.getCurrentKey());
                    LowFuelAlertState lowFuelAlertState = fuelState.get(context.getCurrentKey());
                    setLowFuelAlertState(fuelData,false, context, lowFuelAlertState);
                }
            }
        }

    }

    // This is need because simulator send a 10-digit timestamp and TCU sends 13-digit.
    private Long getTimeValue(Long timestamp){
        if(timestamp.toString().length() == 10)
            return timestamp * 1000;
        return timestamp;
    }

    private Map<String, Boolean> filterPacketsOnTimeOfArrival(FuelData fuelData, String key, Boolean isFuelPercentage){
        Map<String, Boolean> filteredPacketMap = new HashMap<>();
        boolean isPacketReject = false; boolean isAlertEnabled = false; boolean isNotificationEnabled = false; boolean isLatePacket = false;
        long dataPacketTimestamp = 0L;
        if(isFuelPercentage)
            dataPacketTimestamp = fuelData.getFuel_percentage().getTime();
        else
            dataPacketTimestamp = fuelData.getFuel_level_volts().getTime();
        dataPacketTimestamp = getTimeValue(dataPacketTimestamp);
        long diff = System.currentTimeMillis() - dataPacketTimestamp;
        if(diff < 0){
            log.info("LB Time Traveller found! timestamp: {} | diff: {} | currentTime: {}", dataPacketTimestamp, diff,System.currentTimeMillis());
            isPacketReject = true;
        } else {
            if (diff >= outOfOrderTimeThresholdInMS) {
                log.info("LF Late arriving packet, late by {} seconds | Threshold: {} seconds", (diff / 1000), (outOfOrderTimeThresholdInMS / 1000));
                isPacketReject = true;
                isLatePacket = true;
            } else if (diff >= outOfOrderTimeThresholdInMSforAlert) {
                log.info("LF Late arriving packet - no ALERT no NOTIFICATION");
                isLatePacket = true;
            } else if (diff >= outOfOrderTimeThresholdInMSforAlertNotification) {
                isLatePacket = true;
                isAlertEnabled = true;
                log.info("LF Late arriving packet - only ALERT no NOTIFICATION");
            } else {
                isAlertEnabled = true;
                isNotificationEnabled = true;
                log.info("LF Late arriving packet - ALERT & NOTIFICATION");
            }
            try {
                if(!isLatePacket) {
                    if (!fuelState.isEmpty()) {
                        LowFuelAlertState lowFuelAlertState = fuelState.get(key);
                        if (dataPacketTimestamp < lowFuelAlertState.getDetectionWindowStartTimestamp()) {
                            log.info("LF out of order packet, latest state timestamp: {}", lowFuelAlertState.getDetectionWindowStartTimestamp());
                            isPacketReject = true;
                        }
                    }
                }
            } catch (Exception e) {
                log.error("Exception while check state", e);
            }
        }
        filteredPacketMap.put("isPacketReject", isPacketReject);
        filteredPacketMap.put("isLatePacket", isLatePacket);
        filteredPacketMap.put("isAlertEnabled", isAlertEnabled);
        filteredPacketMap.put("isNotificationEnabled", isNotificationEnabled);
        return filteredPacketMap;
    }

    private void checkAgainstThreshold(FuelData fuelData, KeyedBroadcastProcessFunction<String, FuelData,ConfigModel, String>.ReadOnlyContext context, Collector<String> collector) throws Exception {
        if (fuelState.isEmpty()) {
            log.info("LF No existing state found for: {}", context.getCurrentKey());
            LowFuelAlertState lowFuelAlertState = LowFuelAlertState.builder().build();
            sendAlert(fuelData, context, collector, true);
            setLowFuelAlertState(fuelData, true, context, lowFuelAlertState);
        } else {
            LowFuelAlertState lowFuelAlertState = fuelState.get(context.getCurrentKey());
            log.info("LF Existing state found for: {}", context.getCurrentKey());
            if (!lowFuelAlertState.getIsAlertSent()) {
                log.info("LF Reached a new low after reset! Sending Alert!");
                setLowFuelAlertState(fuelData, true, context, lowFuelAlertState);
                sendAlert(fuelData, context, collector, true);
            }
        }
    }

    private void setLowFuelAlertState(FuelData fuelData,Boolean isAlertSent, KeyedBroadcastProcessFunction<String, FuelData,ConfigModel, String>.ReadOnlyContext context, LowFuelAlertState lowFuelAlertState) throws Exception {
        log.info("Setting low fuel alert state: {}", context.getCurrentKey());
        lowFuelAlertState.setIsAlertSent(isAlertSent);
        lowFuelAlertState.setFuel_percentage(fuelData.getFuel_percentage());
        lowFuelAlertState.setFuel_level_volts(fuelData.getFuel_level_volts());
        lowFuelAlertState.setDetectionWindowStartTimestamp(System.currentTimeMillis());
        fuelState.put(context.getCurrentKey(), lowFuelAlertState);
    }

    private void setLatePacketLowFuelAlertState(FuelData fuelData,Boolean isAlertSent, KeyedBroadcastProcessFunction<String, FuelData,ConfigModel, String>.ReadOnlyContext context, LowFuelAlertState lowFuelAlertState) throws Exception {
        log.info("Setting late packet low fuel alert state: {}", context.getCurrentKey());
        lowFuelAlertState.setIsAlertSent(isAlertSent);
        lowFuelAlertState.setFuel_percentage(fuelData.getFuel_percentage());
        lowFuelAlertState.setFuel_level_volts(fuelData.getFuel_level_volts());
        lowFuelAlertState.setDetectionWindowStartTimestamp(System.currentTimeMillis());
        fuelStateForLatePackets.put(context.getCurrentKey(), lowFuelAlertState);
    }

    private void sendAlert(FuelData fuelData,KeyedBroadcastProcessFunction<String, FuelData,ConfigModel, String>.ReadOnlyContext context, Collector<String> collector, Boolean isNotifReq) throws JsonProcessingException {
        AlertDetails alertDetails = AlertDetails.builder().build();
        try {
            log.info("Sending Low Fuel Alert for: {}", context.getCurrentKey());
            if (null != fuelData.getLatitude())
                alertDetails.setLat((Double) fuelData.getLatitude().getValue());
            if (null != fuelData.getLongitude())
                alertDetails.setLongitude((Double) fuelData.getLongitude().getValue());
            if (null != fuelData.getTcu_ignition())
                alertDetails.setIgnitionStatus(fuelData.getTcu_ignition().getValue().toString());
            if (null != fuelData.getGps_fix())
                alertDetails.setGpsStatus(fuelData.getGps_fix().getValue().toString());
            if (null != fuelData.getGps_valid())
                alertDetails.setGpsValidity((Boolean) fuelData.getGps_valid().getValue());
            if (null != fuelData.getVdop())
                alertDetails.setVDOP(Double.parseDouble(fuelData.getVdop().getValue().toString()));
            if (null != fuelData.getHdop())
                alertDetails.setHDOP(Double.parseDouble(fuelData.getHdop().getValue().toString()));
            if (null != fuelData.getPdop())
                alertDetails.setPDOP(Double.parseDouble(fuelData.getPdop().getValue().toString()));
            Alert alert = Alert.builder()
                    .vid(context.getCurrentKey())
                    .tenantId(fuelData.getTenantId())
                    .timestamp(fuelData.getTimestamp())
                    .alertName("LowFuelAlert")
                    .alertCode("F013")
                    .alertPriority("High")
                    .alertType("Vehicle Health")
                    .tcuId(fuelData.getTenantId())
                    .isNotificationRequired(isNotifReq)
                    .alertDetails(alertDetails)
                    .build();
            log.info("LF_ALERT: {}", mapper.writeValueAsString(alert));
            collector.collect(mapper.writeValueAsString(alert));
        }catch (Exception e){
            log.error("Exception while generating LF_ALERT!", e);
        }
    }

    private ConfigModel getConfigData(FuelData fuelData) throws Exception {
        ConfigModel configModel = new ConfigModel();
        if(null != bcState){
            configModel = bcState.get(fuelData.getVds()+"LOW_FUEL");
        }
        else{
            JSONObject configDetails = new JSONObject();
            configDetails.put("lowThreshold", "5");
            configDetails.put("midThreshold", "50");
            configDetails.put("highThreshold", "80");
            configDetails.put("unit", "fuel_level_volts");

            configModel.setConfigDetails(configDetails);
            configModel.setConfigType("Alert");
            configModel.setConfigSubType("LOW_FUEL");
            configModel.setVehicleModelId("DH002");
            configModel.setTenantId("EV-VIDA");
            configModel.setVdsCode("DH002");
        }

        return configModel;
    }

    @Override
    public void processBroadcastElement(ConfigModel configModel, KeyedBroadcastProcessFunction<String, FuelData, ConfigModel, String>.Context context, Collector<String> collector) throws Exception {
        log.info("broadcastdata:{}",configModel);
        if(null != configModel){
            bcState = context.getBroadcastState(modelConfigMap);
            bcState.put(configModel.getVdsCode()+configModel.getConfigSubType(), configModel);
        }
    }
}