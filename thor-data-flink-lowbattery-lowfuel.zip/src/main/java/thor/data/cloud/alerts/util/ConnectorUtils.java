package thor.data.cloud.alerts.util;

import com.amazonaws.services.kinesisanalytics.runtime.KinesisAnalyticsRuntime;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import org.apache.flink.api.java.utils.ParameterTool;
import org.apache.flink.streaming.api.environment.StreamExecutionEnvironment;

import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;

public final class ConnectorUtils {
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();

    private ConnectorUtils() {
    }

    public static ParameterTool getRuntimeParameters(String[] args, StreamExecutionEnvironment env) throws Exception {
        Map<String, Properties> applicationProperties = KinesisAnalyticsRuntime.getApplicationProperties();
        Properties flinkProperties = applicationProperties.get("FlinkApplicationProperties");
        if (flinkProperties == null) {
            String test = Arrays.toString(args) + env.getClass().getName();
            throw new Exception("Unable to load FlinkApplicationProperties properties from runtime properties: - " + test);
        }
        Map<String, String> map = new HashMap<>(flinkProperties.size());
        flinkProperties.forEach((k, v) -> map.put((String) k, (String) v));
        return ParameterTool.fromMap(map);
    }

    public static String toJson(Object object) {
        return GSON.toJson(object);
    }
}
