package thor.data.cloud.alerts.model;

import com.fasterxml.jackson.annotation.JsonGetter;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonSetter;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.*;
import org.json.JSONObject;

import java.io.Serializable;
import java.util.Map;


@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class ConfigModel implements Serializable {

    private String id;
    @JsonProperty("config_type")
    private String configType;
    @JsonProperty("config_sub_type")
    private String configSubType;
    @JsonProperty("vehicle_model_id")
    private String vehicleModelId;
    @JsonProperty("config_details")
    private JSONObject configDetails;
    @JsonProperty("created_by")
    private String createdBy;
    @JsonProperty("config_tsp")
    private Long createdTsp;
    @JsonProperty("updated_by")
    private String updatedBy;
    @JsonProperty("updated_tsp")
    private Long updatedTsp;
    @JsonProperty("vehicle_model_name")
    private String vehicleModelName;
    @JsonProperty("vehicle_count")
    private Integer vehicleCount;
    @JsonProperty("tenant_id")
    private String tenantId;
    @JsonProperty("vds_code")
    private String vdsCode;
    @JsonProperty("is_active")
    private Boolean isActive;
    @JsonProperty("is_deleted")
    private Boolean isDeleted;
    private String description;
}