package thor.data.cloud.alerts.model;

import lombok.*;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
@ToString
public class LowFuelAlertState {
    private Long detectionWindowStartTimestamp;
    private SocUserValues fuel_percentage;
    private SocUserValues fuel_level_volts;
    private Boolean isAlertSent;
}
