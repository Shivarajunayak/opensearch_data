package thor.data.cloud.alerts.processor;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.extern.slf4j.Slf4j;
import org.apache.flink.api.common.state.BroadcastState;
import org.apache.flink.api.common.state.MapState;
import org.apache.flink.api.common.state.MapStateDescriptor;
import org.apache.flink.api.common.typeinfo.Types;
import org.apache.flink.configuration.Configuration;
import org.apache.flink.streaming.api.functions.KeyedProcessFunction;
import org.apache.flink.streaming.api.functions.co.CoFlatMapFunction;
import org.apache.flink.streaming.api.functions.co.KeyedBroadcastProcessFunction;
import org.apache.flink.util.Collector;

import org.json.JSONObject;
import thor.data.cloud.alerts.config.JobConfig;
import thor.data.cloud.alerts.model.*;

import java.util.*;


@Slf4j
public class LowTractionBatteryProcessor extends KeyedBroadcastProcessFunction<String, BatteryData,ConfigModel, String> {
    private MapState<String, LowTractionBatteryAlertState> tractionState;
    private MapState<String, LowTractionBatteryAlertState> tractionStateForLatePackets;
    private BroadcastState<String, ConfigModel> bcState;
    private final ObjectMapper mapper = new ObjectMapper();
    private final Long outOfOrderTimeThresholdInMSforAlertNotification = 60000L; // 10 mins
    private final Long outOfOrderTimeThresholdInMSforAlert = 14400000L; // 4 hours
    private final Long outOfOrderTimeThresholdInMS = 86400000L; // 1 day
    private Double batterySocThreshold;
    private MapStateDescriptor<String, ConfigModel> modelConfigMap;

    private JobConfig jobConfig;

    public LowTractionBatteryProcessor(JobConfig jobConfig) {
            this.jobConfig = jobConfig;
    }

    public void open(Configuration configuration) throws Exception {
        MapStateDescriptor<String, LowTractionBatteryAlertState> vehicleStateMap = new MapStateDescriptor<>("traction_map", String.class, LowTractionBatteryAlertState.class);
        MapStateDescriptor<String, LowTractionBatteryAlertState> vehicleStateforLatePacketsMap = new MapStateDescriptor<>("traction_late_arriving_map", String.class, LowTractionBatteryAlertState.class);
        this.tractionState = getRuntimeContext().getMapState(vehicleStateMap);
        this.tractionStateForLatePackets = getRuntimeContext().getMapState(vehicleStateforLatePacketsMap);
        modelConfigMap = new MapStateDescriptor<>("modelconfig", Types.STRING, Types.POJO(ConfigModel.class));
    }
    public void processElement(BatteryData batteryData, KeyedBroadcastProcessFunction<String, BatteryData, ConfigModel, String>.ReadOnlyContext context, Collector<String> collector) throws Exception {
        try {
            ConfigModel configModel = getConfigData(batteryData);
            Map<String, Boolean> filterMetadata = filterPacketsOnTimeOfArrival(batteryData, context.getCurrentKey());
            if(filterMetadata.get("isPacketReject"))
                return;
            log.info(configModel.getConfigDetails().toString());
            batterySocThreshold = Double.valueOf(configModel.getConfigDetails().get("lowThreshold").toString());
            if(!filterMetadata.get("isLatePacket"))
                computeLowTraction(batteryData, context, collector);
            else
                computeLowTractionBatteryForOOOPackets(batteryData, context, collector);
        }catch (Exception e){
            log.error("Exception in processor", e);
        }
    }

    private void computeLowTractionBatteryForOOOPackets(BatteryData batteryData,  KeyedBroadcastProcessFunction<String, BatteryData, ConfigModel, String>.ReadOnlyContext context,
                                             Collector<String> collector) throws Exception {
        log.info("LB Processing OOO Packet: {}", context.getCurrentKey());
        boolean isBatteryLevelLow = false;
        long packetTimestamp = getTimeValue(batteryData.getBms1_soc_user_percentage().getTime());
        if((Double.parseDouble(batteryData.getBms1_soc_user_percentage().getValue().toString()) <= batterySocThreshold) &&
                (Double.parseDouble(batteryData.getBms2_soc_user_percentage().getValue().toString()) <= batterySocThreshold)){
            log.info("Low battery detected: {}", batteryData);
            isBatteryLevelLow = true;
        }

        if(isBatteryLevelLow){
            if (tractionStateForLatePackets.isEmpty()) {
                log.info("LB No existing late packet state found for: {}", context.getCurrentKey());
                LowTractionBatteryAlertState lowTractionBatteryAlertState = LowTractionBatteryAlertState.builder().build();
                sendAlert(batteryData, context, collector, false);
                setLatePacketLowTractionBatteryState(batteryData, true, context, lowTractionBatteryAlertState);
            } else {
                LowTractionBatteryAlertState lowTractionBatteryAlertState = tractionStateForLatePackets.get(context.getCurrentKey());
                log.info("LB Existing late packet state found for: {}", context.getCurrentKey());
                if (packetTimestamp < lowTractionBatteryAlertState.getDetectionWindowStartTimestamp()){
                    sendAlert(batteryData, context, collector, false);
                    setLatePacketLowTractionBatteryState(batteryData, true, context, lowTractionBatteryAlertState);
                } else{
                    if (!lowTractionBatteryAlertState.getIsAlertSent()) {
                        log.info("LB Reached a new low after reset! Sending Alert!");
                        setLatePacketLowTractionBatteryState(batteryData, true, context, lowTractionBatteryAlertState);
                        sendAlert(batteryData, context, collector, false);
                    }
                }
            }
        }else{
            if(!tractionStateForLatePackets.isEmpty()){
                log.info("LB Resetting late packet state for: {}", context.getCurrentKey());
                LowTractionBatteryAlertState lowTractionBatteryAlertState = tractionStateForLatePackets.get(context.getCurrentKey());
                setLatePacketLowTractionBatteryState(batteryData,false, context, lowTractionBatteryAlertState);
            }
        }

    }

    private void computeLowTraction(BatteryData batteryData, KeyedBroadcastProcessFunction<String, BatteryData, ConfigModel, String>.ReadOnlyContext context, Collector<String> collector) throws Exception {
            if((Double.parseDouble(batteryData.getBms1_soc_user_percentage().getValue().toString()) <= batterySocThreshold) &&
                    (Double.parseDouble(batteryData.getBms2_soc_user_percentage().getValue().toString()) <= batterySocThreshold)){
                log.info("Low battery detected: {}", batteryData);
                checkAgainstThreshold(batteryData, context, collector);
            }
            else{
                if(!tractionState.isEmpty()){
                    log.info("LB Resetting STATE for: {}", context.getCurrentKey());
                    LowTractionBatteryAlertState lowTractionBatteryAlertState = tractionState.get(context.getCurrentKey());
                    setLatePacketLowTractionBatteryState(batteryData,false, context, lowTractionBatteryAlertState);
                }

        }

    }

    // This is need because simulator send a 10-digit timestamp and TCU sends 13-digit.
    private Long getTimeValue(Long timestamp){
        if(timestamp.toString().length() == 10)
            return timestamp * 1000;
        return timestamp;
    }

    private Map<String, Boolean> filterPacketsOnTimeOfArrival(BatteryData batteryData, String key){
        Map<String, Boolean> filteredPacketMap = new HashMap<>();
        boolean isPacketReject = false; boolean isAlertEnabled = false; boolean isNotificationEnabled = false; boolean isLatePacket = false;
        long dataPacketTimestamp = 0L;
        dataPacketTimestamp = batteryData.getBms1_soc_user_percentage().getTime();
        dataPacketTimestamp = getTimeValue(dataPacketTimestamp);
        long diff = System.currentTimeMillis() - dataPacketTimestamp;
        if(diff < 0){
            log.info("LB Time Traveller found! timestamp: {} | diff: {} | currentTime: {}", dataPacketTimestamp, diff,System.currentTimeMillis());
            isPacketReject = true;
        } else {
            if (diff >= outOfOrderTimeThresholdInMS) {
                log.info("LB Late arriving packet, late by {} seconds | Threshold: {} seconds", (diff / 1000), (outOfOrderTimeThresholdInMS / 1000));
                isPacketReject = true;
                isLatePacket = true;
            } else if (diff >= outOfOrderTimeThresholdInMSforAlert) {
                log.info("LB Late arriving packet - no ALERT no NOTIFICATION");
                isLatePacket = true;
            } else if (diff >= outOfOrderTimeThresholdInMSforAlertNotification) {
                isLatePacket = true;
                isAlertEnabled = true;
                log.info("LB Late arriving packet - only ALERT no NOTIFICATION");
            } else {
                isAlertEnabled = true;
                isNotificationEnabled = true;
                log.info("LB Late arriving packet - ALERT & NOTIFICATION");
            }
            try {
                if(!isLatePacket) {
                    if (!tractionState.isEmpty()) {
                        LowTractionBatteryAlertState lowTractionBatteryAlertState = tractionState.get(key);
                        if (dataPacketTimestamp < lowTractionBatteryAlertState.getDetectionWindowStartTimestamp()) {
                            log.info("LB out of order packet, latest state timestamp: {}", lowTractionBatteryAlertState.getDetectionWindowStartTimestamp());
                            isPacketReject = true;
                        }
                    }
                }
            } catch (Exception e) {
                log.error("Exception while check state", e);
            }
        }
        filteredPacketMap.put("isPacketReject", isPacketReject);
        filteredPacketMap.put("isLatePacket", isLatePacket);
        filteredPacketMap.put("isAlertEnabled", isAlertEnabled);
        filteredPacketMap.put("isNotificationEnabled", isNotificationEnabled);
        return filteredPacketMap;
    }

    private void checkAgainstThreshold(BatteryData batteryData, KeyedBroadcastProcessFunction<String, BatteryData, ConfigModel, String>.ReadOnlyContext context, Collector<String> collector) throws Exception {
        if (tractionState.isEmpty()) {
            log.info("LB No existing state found for: {}", context.getCurrentKey());
            LowTractionBatteryAlertState lowTractionBatteryAlertState = LowTractionBatteryAlertState.builder().build();
            sendAlert(batteryData, context, collector, true);
            setLowTractionBatteryAlertState(batteryData, true, context, lowTractionBatteryAlertState);
        } else {
            LowTractionBatteryAlertState lowTractionBatteryAlertState = tractionState.get(context.getCurrentKey());
            log.info("LB Existing state found for: {}", context.getCurrentKey());
            if (!lowTractionBatteryAlertState.getIsAlertSent()) {
                log.info("LB Reached a new low after reset! Sending Alert!");
                setLowTractionBatteryAlertState(batteryData, true, context, lowTractionBatteryAlertState);
                sendAlert(batteryData, context, collector, true);
            }
        }
    }

    private void setLowTractionBatteryAlertState(BatteryData batteryData, Boolean isAlertSent, KeyedBroadcastProcessFunction<String, BatteryData, ConfigModel, String>.ReadOnlyContext context, LowTractionBatteryAlertState lowTractionBatteryAlertState) throws Exception {
        log.info("Setting low battery alert state: {}", context.getCurrentKey());
        lowTractionBatteryAlertState.setIsAlertSent(isAlertSent);
        lowTractionBatteryAlertState.setBms1_soc_user_percentage(batteryData.getBms1_soc_user_percentage());
        lowTractionBatteryAlertState.setBms2_soc_user_percentage(batteryData.getBms2_soc_user_percentage());
        lowTractionBatteryAlertState.setDetectionWindowStartTimestamp(System.currentTimeMillis());
        tractionState.put(context.getCurrentKey(), lowTractionBatteryAlertState);
    }

    private void setLatePacketLowTractionBatteryState(BatteryData batteryData,Boolean isAlertSent, KeyedBroadcastProcessFunction<String, BatteryData, ConfigModel, String>.ReadOnlyContext context, LowTractionBatteryAlertState lowTractionBatteryAlertState) throws Exception {
        log.info("Setting late packet low traction battery alert state: {}", context.getCurrentKey());
        lowTractionBatteryAlertState.setIsAlertSent(isAlertSent);
        lowTractionBatteryAlertState.setBms1_soc_user_percentage(batteryData.getBms1_soc_user_percentage());
        lowTractionBatteryAlertState.setBms2_soc_user_percentage(batteryData.getBms2_soc_user_percentage());
        lowTractionBatteryAlertState.setDetectionWindowStartTimestamp(System.currentTimeMillis());
        tractionStateForLatePackets.put(context.getCurrentKey(), lowTractionBatteryAlertState);
    }

    private void sendAlert(BatteryData batteryData, KeyedBroadcastProcessFunction<String, BatteryData, ConfigModel, String>.ReadOnlyContext context, Collector<String> collector, Boolean isNotifReq) throws JsonProcessingException {
        AlertDetails alertDetails = AlertDetails.builder().build();
        try {
            log.info("Sending Low Battery Alert for: {}", context.getCurrentKey());
            if (null != batteryData.getLatitude())
                alertDetails.setLat((Double) batteryData.getLatitude().getValue());
            if (null != batteryData.getLongitude())
                alertDetails.setLongitude((Double) batteryData.getLongitude().getValue());
            if (null != batteryData.getTcu_ignition())
                alertDetails.setIgnitionStatus(batteryData.getTcu_ignition().getValue().toString());
            if (null != batteryData.getGps_fix())
                alertDetails.setGpsStatus(batteryData.getGps_fix().getValue().toString());
            if (null != batteryData.getGps_valid())
                alertDetails.setGpsValidity((Boolean) batteryData.getGps_valid().getValue());
            if (null != batteryData.getVdop())
                alertDetails.setVDOP(Double.parseDouble(batteryData.getVdop().getValue().toString()));
            if (null != batteryData.getHdop())
                alertDetails.setHDOP(Double.parseDouble(batteryData.getHdop().getValue().toString()));
            if (null != batteryData.getPdop())
                alertDetails.setPDOP(Double.parseDouble(batteryData.getPdop().getValue().toString()));
            Alert alert = Alert.builder()
                    .vid(context.getCurrentKey())
                    .tenantId(batteryData.getTenantId())
                    .timestamp(batteryData.getTimestamp())
                    .alertName("LowTractionBatteryAlert")
                    .alertCode("F012")
                    .alertPriority("High")
                    .alertType("Vehicle Health")
                    .tcuId(batteryData.getTenantId())
                    .isNotificationRequired(isNotifReq)
                    .alertDetails(alertDetails)
                    .build();
            log.info("LTB_ALERT: {}", mapper.writeValueAsString(alert));
            collector.collect(mapper.writeValueAsString(alert));
        }catch (Exception e){
            log.error("Exception while generating LTB_ALERT!", e);
        }
    }

    private ConfigModel getConfigData(BatteryData batteryData) throws Exception {
        ConfigModel configModel = new ConfigModel();
        if(null != bcState){
            configModel = bcState.get(batteryData.getVds()+"LOW_TRACTION_BATTERY");
        }
        else{
            JSONObject configDetails = new JSONObject();
            configDetails.put("lowThreshold", "20");
            configModel.setConfigDetails(configDetails);
            configModel.setConfigType("Alert");
            configModel.setConfigSubType("LOW_TRACTION_BATTERY");
            configModel.setVehicleModelId("DH002");
            configModel.setTenantId("EV-VIDA");
            configModel.setVdsCode("DH002");
        }

        return configModel;
    }

    @Override
    public void processBroadcastElement(ConfigModel configModel, KeyedBroadcastProcessFunction<String, BatteryData, ConfigModel, String>.Context context, Collector<String> collector) throws Exception {
        log.info("broadcastdata:{}", configModel);
        if (configModel != null) {
            bcState = context.getBroadcastState(modelConfigMap);
            bcState.put(configModel.getVdsCode() + configModel.getConfigSubType(), configModel);
        }
    }
}
