package thor.data.cloud.alerts.config;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class StreamConfig implements Serializable {
    private String sourceTopic;
    private String sinkTopic;
    private int sourceParallelism;
    private int mapParallelism;
    private int sinkParallelism;
    private int processParallelism;
}
