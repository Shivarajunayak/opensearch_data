package thor.data.cloud.alerts.config;

import lombok.*;

import java.io.Serializable;

@AllArgsConstructor
@NoArgsConstructor
@Data
public class ApplicationConfig implements Serializable {

    private String checkpointStorageUrl;

    private Long checkpointInterval;

    private Long checkpointTimeout;

    private Long minPauseBetweenCheckpoints;

    private Integer maxConcurrentCheckpoints;

    private Integer parallelism;

    private String bootstrapServers;

    private String groupId;

    private String redisTtl;

    private String externalUrl;

}
