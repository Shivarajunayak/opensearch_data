package thor.data.cloud.alerts.util;

import org.apache.commons.io.output.ByteArrayOutputStream;
import org.apache.flink.core.fs.FSDataInputStream;
import org.apache.flink.core.fs.FileSystem;
import org.apache.flink.core.fs.Path;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.util.Properties;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;
import java.util.zip.ZipOutputStream;

/**
 * @author shreyas b
 **/


public class FileUtil {

    /**
     * Reads file from both hadoop based FileSystem (hdfs,wasb,s3) and local FileSystem (file:// )
     * @param filePath
     * @return FSDataInputStream
     * @throws IOException
     */
    public static FSDataInputStream readFile(String filePath) throws IOException {
        Path path = new Path(filePath);
        return FileSystem.get(path.toUri()).open(path);
    }


    /**
     * Checks whether requiredProperties are present in properties
     * @param properties
     * @param requiredProperties
     * @throws  IllegalArgumentException
     */
    public static void checkProperty(Properties properties, String[] requiredProperties) {
        for (String key:requiredProperties) {
            if (!properties.containsKey(key)) {
                throw new IllegalArgumentException("Required property '" + key + "' not set.");
            }
        }
    }

    public static byte[] byteArrayToZip(byte[] input) throws IOException {
        ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
        ZipOutputStream zos = new ZipOutputStream(byteArrayOutputStream);
        ZipEntry entry = new ZipEntry("hfe-packet");
        entry.setSize(input.length);
        zos.putNextEntry(entry);
        zos.write(input);
        zos.closeEntry();
        zos.close();
        return byteArrayOutputStream.toByteArray();
    }


    public static byte[] zipBytesToUnzipByteArray(byte[] inputByte) throws IOException {
        ZipInputStream zipStream = new ZipInputStream(new ByteArrayInputStream(inputByte));
        ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
        while ((zipStream.getNextEntry()) != null) {
            byte[] byteBuff = new byte[4096];
            int bytesRead = 0;
            while ((bytesRead = zipStream.read(byteBuff)) > 0 ) {
                byteArrayOutputStream.write(byteBuff, 0, bytesRead);
            }
        }
        zipStream.close();
        return byteArrayOutputStream.toByteArray();
    }

}
