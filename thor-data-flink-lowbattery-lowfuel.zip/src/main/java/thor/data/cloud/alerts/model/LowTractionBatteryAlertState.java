package thor.data.cloud.alerts.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class LowTractionBatteryAlertState {
    private Long detectionWindowStartTimestamp;
    private SocUserValues bms1_soc_user_percentage;
    private SocUserValues bms2_soc_user_percentage;
    private Boolean isAlertSent;
}
