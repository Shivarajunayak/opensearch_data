package thor.data.cloud.alerts.mapper;

import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.gson.JsonObject;
import lombok.extern.slf4j.Slf4j;
import org.apache.flink.api.common.functions.MapFunction;
import org.codehaus.jackson.map.DeserializationConfig;
import org.json.JSONObject;
import thor.data.cloud.alerts.model.*;

import java.io.DataInput;
import java.util.ArrayList;
import java.util.Comparator;


@Slf4j
public class ModelConfigMapper implements MapFunction<String, ConfigModel> {
    private final ObjectMapper mapper = new ObjectMapper();

    public ConfigModel map(String event) throws Exception {
        try{
            mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);

            JSONObject jsonObj = new JSONObject(event);
            JSONObject payload = jsonObj.getJSONObject("payload");
            JSONObject after = payload.getJSONObject("after");
            ConfigModel configModel = mapper.readValue(after.toString(), ConfigModel.class);

            log.info(configModel.getConfigDetails().toString());
            return configModel;
        }catch (Exception e){
            log.error("modelConfig ERROR: {}", event);
            log.error("Error: ", e);
            return null;
        }

    }
}
