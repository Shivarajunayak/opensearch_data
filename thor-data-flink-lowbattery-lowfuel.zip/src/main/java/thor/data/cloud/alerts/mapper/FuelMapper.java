package thor.data.cloud.alerts.mapper;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.extern.slf4j.Slf4j;
import org.apache.flink.api.common.functions.MapFunction;
import thor.data.cloud.alerts.model.BatteryData;
import thor.data.cloud.alerts.model.CampaignData;
import thor.data.cloud.alerts.model.FuelData;
import thor.data.cloud.alerts.model.SocUserValues;

import java.util.ArrayList;
import java.util.Comparator;

@Slf4j
public class FuelMapper implements MapFunction<String, FuelData> {
    private final ObjectMapper mapper = new ObjectMapper();

    public FuelData map(String event) throws Exception {
        try {
            CampaignData campaignData = mapper.readValue(event, CampaignData.class);
            return setFuelData(campaignData);
        }catch (Exception e){
            log.error("fuelData ERROR: {}", event);
            log.error("Error: ", e);
            return null;
        }
    }

    private FuelData setFuelData(CampaignData campaignData) throws JsonProcessingException {
        FuelData fuelData = new FuelData();
        if(campaignData.getDimensions().get("hmcl.virtualId") != null){
            fuelData.setDeviceId(campaignData.getDimensions().get("hmcl.virtualId"));
        }
        if(campaignData.getDimensions().get("hmcl.vds") != null){
            fuelData.setVds(campaignData.getDimensions().get("hmcl.vds"));
        }
        if(campaignData.getDimensions().get("hmcl.tenantId") != null){
            fuelData.setTenantId(campaignData.getDimensions().get("hmcl.tenantId"));
        }
        if(campaignData.getCollectionEventTime() != null){
            fuelData.setTimestamp(campaignData.getCollectionEventTime().toString());
        }
        if(campaignData.getSignals().get("hmcl.ice.can0.fuel_percentage") != null){
            fuelData.setFuel_percentage(
                    getLatestFuelSocUserValues(campaignData.getSignals().get("hmcl.ice.can0.fuel_percentage")));        }

        if(campaignData.getSignals().get("hmcl.common.vcan0.fuel_level_volts") != null){
            fuelData.setFuel_level_volts(
                    getLatestFuelSocUserValues(campaignData.getSignals().get("hmcl.common.vcan0.fuel_level_volts")));        }

        if(campaignData.getSignals().get("hmcl.common.vcan0.latitude") != null){
            fuelData.setLatitude(
                    getLatestFuelSocUserValues(campaignData.getSignals().get("hmcl.common.vcan0.latitude")));
        }

        if(campaignData.getSignals().get("hmcl.common.vcan0.longitude") != null){
            fuelData.setLongitude(
                    getLatestFuelSocUserValues(campaignData.getSignals().get("hmcl.common.vcan0.longitude")));
        }

        if(campaignData.getSignals().get("hmcl.ev.can0.odo_reading") != null){
            fuelData.setOdo_reading(
                    getLatestFuelSocUserValues(campaignData.getSignals().get("hmcl.ev.can0.odo_reading")));
        }

        if(campaignData.getSignals().get("hmcl.common.vcan0.tcu_ignition") != null){
            fuelData.setTcu_ignition(
                    getLatestFuelSocUserValues(campaignData.getSignals().get("hmcl.common.vcan0.tcu_ignition")));
        }

        if(campaignData.getSignals().get("hmcl.common.vcan0.gps_fix") != null){
            fuelData.setGps_fix(
                    getLatestFuelSocUserValues(campaignData.getSignals().get("hmcl.common.vcan0.gps_fix")));
        }

        if(campaignData.getSignals().get("hmcl.common.vcan0.gps_valid") != null){
            fuelData.setGps_valid(
                    getLatestFuelSocUserValues(campaignData.getSignals().get("hmcl.common.vcan0.gps_valid")));
        }

        if(campaignData.getSignals().get("hmcl.common.vcan0.vdop") != null){
            fuelData.setVdop(
                    getLatestFuelSocUserValues(campaignData.getSignals().get("hmcl.common.vcan0.vdop")));
        }

        if(campaignData.getSignals().get("hmcl.common.vcan0.pdop") != null){
            fuelData.setPdop(
                    getLatestFuelSocUserValues(campaignData.getSignals().get("hmcl.common.vcan0.pdop")));
        }

        if(campaignData.getSignals().get("hmcl.common.vcan0.hdop") != null){
            fuelData.setHdop(
                    getLatestFuelSocUserValues(campaignData.getSignals().get("hmcl.common.vcan0.hdop")));
        }
        if(null == fuelData.getFuel_percentage() && null == fuelData.getFuel_level_volts())
            return null;
        return fuelData;
    }

    private SocUserValues getLatestFuelSocUserValues(ArrayList<SocUserValues> fuelSocValues) throws JsonProcessingException {
        return fuelSocValues.stream().max(Comparator.comparing(SocUserValues::getTime)).get();
    }

}
