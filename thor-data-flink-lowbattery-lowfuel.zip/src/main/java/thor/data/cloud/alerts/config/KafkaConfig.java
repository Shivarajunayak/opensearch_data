package thor.data.cloud.alerts.config;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class KafkaConfig implements Serializable {
    private String bootstrapServers;
    private String groupId;
    private String autoOffsetReset;
    private String mskRoleArn;
    private String mskSessionName;
    private String mskAwsRegion;
    private int producerAcks;
}
