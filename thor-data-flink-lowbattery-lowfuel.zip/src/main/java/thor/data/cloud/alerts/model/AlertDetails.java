package thor.data.cloud.alerts.model;

import com.fasterxml.jackson.annotation.JsonGetter;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;


@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class AlertDetails {
  private Double lat;
  private Double longitude;
  private String soc;
  private Double fuelLevel;
  private Double odometer;
  private String ignitionStatus;
  private String gpsStatus;
  private Boolean gpsValidity;
  private Double VDOP;
  private Double PDOP;
  private Double HDOP;
  private String chargingStatus;
  private String sideStandStatus;
  private String vehicleState;
  private String drivingMode;
  private String boundaryCondition;

  @JsonGetter("long")
  public Double getLongitude() {
    return longitude;
  }
}
