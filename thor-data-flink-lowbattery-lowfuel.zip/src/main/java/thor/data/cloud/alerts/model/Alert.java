package thor.data.cloud.alerts.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class Alert {
    private String vid;
    private String tenantId;
    private String tcuId;
    private String alertName;
    private String alertCode;
    private String alertType;
    private String alertPriority;
    private Boolean isNotificationRequired;
    private Long geofenceId;
    private Long timefenceId;
    private String timestamp;
    private AlertDetails alertDetails;
}
