import json
import random
import time

from pykafka import KafkaClient

kafka_brokers = "localhost:9092"
low_battery_source_data = "thor.data.low.battery.source.v1"
client = KafkaClient(hosts=kafka_brokers)
topic = client.topics[low_battery_source_data]
producer = topic.get_sync_producer()
low_battery_threshold = 20
random_neg_margin = 10
random_pos_margin = 10
no_of_packets = 1000
devices = ["d_01", "d_02", "d_03"]


def push_battery_data(data):
    message = json.dumps(data)
    message_bytes = message.encode('utf-8')
    producer.produce(message_bytes)



def prepare_data():
    f = open('data.json')
    data = json.load(f)
    print(data)
    push_battery_data(data)



if __name__ == '__main__':
    prepare_data()

