package org.hmcl.cvp.dataplatform.bruno.contracts;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class MQTTSinkData {
    private String vid;
    private String topic;
    private String message;
    private int qos;
}