package org.hmcl.cvp.dataplatform.bruno.job;

import lombok.extern.slf4j.Slf4j;
import org.apache.flink.api.common.eventtime.WatermarkStrategy;
import org.apache.flink.api.common.functions.FlatMapFunction;
import org.apache.flink.api.java.utils.ParameterTool;
import org.apache.flink.connector.kafka.source.KafkaSource;
import org.apache.flink.streaming.api.datastream.DataStream;
import org.apache.flink.streaming.api.environment.StreamExecutionEnvironment;
import org.apache.flink.streaming.api.functions.ProcessFunction;
import org.hmcl.cvp.dataplatform.bruno.contracts.MQTTConstants;
import org.hmcl.cvp.dataplatform.bruno.contracts.MQTTSinkData;
import org.hmcl.cvp.dataplatform.bruno.operator.AsyncMqttPublishingProcessFunction;
import org.hmcl.cvp.dataplatform.bruno.operator.B2BChargingMapperFunction;
import org.hmcl.cvp.dataplatform.bruno.operator.B2BNotificationMapperFunction;
import org.hmcl.cvp.dataplatform.bruno.operator.B2BTelemetryMapperFunction;
import org.hmcl.cvp.dataplatform.bruno.operator.NotificationFunction;
import org.hmcl.cvp.dataplatform.bruno.operator.OperatorNames;
import org.hmcl.cvp.dataplatform.commons.connector.KafkaConnector;
import org.hmcl.cvp.dataplatform.commons.constants.FlinkRuntime;
import org.hmcl.cvp.dataplatform.commons.operator.TelemetryFlatMapFunction;
import org.hmcl.cvp.dataplatform.commons.utils.ConnectorUtils;
import org.hmcl.cvp.dataplatform.contract.notification.Notification;
import org.hmcl.cvp.dataplatform.contract.telemetry.Telemetry;

@Slf4j
public class B2BBrunoFlink {
    private static final FlatMapFunction<String, Telemetry> telemetryMapFunction = new TelemetryFlatMapFunction();
    private static final FlatMapFunction<String, Notification> notificationMapperFunction = new NotificationFunction();

    public static void main(String[] args) throws Exception {
        final StreamExecutionEnvironment env = StreamExecutionEnvironment.getExecutionEnvironment();
        final ParameterTool parameterTool = ConnectorUtils.loadApplicationParameters(args, env);
        env.getConfig().setGlobalJobParameters(parameterTool);
        boolean isTest = parameterTool.getBoolean(FlinkRuntime.IS_TEST, Boolean.FALSE);
        String mqttBrokerUrl = parameterTool.get(MQTTConstants.MQTT_BROKER_URL, "tcp://emqx1");
        String mqttClientId = parameterTool.get(MQTTConstants.MQTT_CLIENT_ID, "bruno_mqtt_client");
        String mqttBrokerPort = parameterTool.get(MQTTConstants.MQTT_BROKER_PORT, "");
        final ProcessFunction<MQTTSinkData, String> mqttSinkTelemetry = new AsyncMqttPublishingProcessFunction(mqttBrokerUrl, mqttBrokerPort, mqttClientId + "_telemetry");
        final ProcessFunction<MQTTSinkData, String> mqttSinkCharging = new AsyncMqttPublishingProcessFunction(mqttBrokerUrl, mqttBrokerPort, mqttClientId + "_charging");
        final ProcessFunction<MQTTSinkData, String> mqttSinkNotification = new AsyncMqttPublishingProcessFunction(mqttBrokerUrl, mqttBrokerPort, mqttClientId + "_notification");

        DataStream<Telemetry> telemetryStream = getTelemetryStream(env, parameterTool, isTest);
        DataStream<Telemetry> chargingStream = getChargingStream(env, parameterTool, isTest);

        DataStream<Notification> notificationStream = getNotificationDataStream(env, parameterTool, isTest);

        telemetryStream
                .flatMap(new B2BTelemetryMapperFunction())
                .name(OperatorNames.B2B_TELEMETRY_WRAPPER)
                .uid(OperatorNames.B2B_TELEMETRY_WRAPPER)
                .process(mqttSinkTelemetry)
                .name(OperatorNames.MQTT_TELEMETRY_SINK)
                .uid(OperatorNames.MQTT_TELEMETRY_SINK);

        chargingStream
                .flatMap(new B2BChargingMapperFunction())
                .name(OperatorNames.B2B_CHARGING_WRAPPER)
                .uid(OperatorNames.B2B_CHARGING_WRAPPER)
                .process(mqttSinkCharging)
                .name(OperatorNames.MQTT_CHARGING_SINK)
                .uid(OperatorNames.MQTT_CHARGING_SINK);

        notificationStream
                .flatMap(new B2BNotificationMapperFunction())
                .name(OperatorNames.B2B_NOTIFICATION_WRAPPER)
                .uid(OperatorNames.B2B_NOTIFICATION_WRAPPER)
                .process(mqttSinkNotification)
                .name(OperatorNames.MQTT_NOTIFICATION_SINK)
                .uid(OperatorNames.MQTT_NOTIFICATION_SINK);

        env.execute();

    }

    private static DataStream<Telemetry> getChargingStream(StreamExecutionEnvironment env, ParameterTool parameterTool, boolean isTest) {
        String chargingCampaignTopic = parameterTool.get(FlinkRuntime.Kafka.CHARGING_CAMPAIGN_TOPIC);
        String chargingConsumer = parameterTool.get(FlinkRuntime.Kafka.CAMPAIGN_GROUP) + "Charging";
        KafkaConnector.KafkaProperties chargingKafkaProps = KafkaConnector.getTelemetryKafkaProperties(parameterTool, chargingConsumer, chargingCampaignTopic);
        KafkaSource<String> chargingCampaignSource = KafkaConnector.createStringKafkaSource(chargingKafkaProps, parameterTool, isTest);

        // Data stream created from charging campaigns
        return env.fromSource(chargingCampaignSource,
                        WatermarkStrategy.noWatermarks(),
                        chargingCampaignTopic)
                .flatMap(telemetryMapFunction)
                .name(OperatorNames.CHARGING_CAMPAIGN_SOURCE)
                .uid(OperatorNames.CHARGING_CAMPAIGN_SOURCE);
    }

    private static DataStream<Telemetry> getTelemetryStream(final StreamExecutionEnvironment env,
                                                            final ParameterTool parameterTool,
                                                            final boolean isTest) {
        String telemetryCampaignTopic = parameterTool.get(FlinkRuntime.Kafka.TELEMETRY_CAMPAIGN_TOPIC);
        String telemetryConsumer = parameterTool.get(FlinkRuntime.Kafka.CAMPAIGN_GROUP) + "Master";
        KafkaConnector.KafkaProperties telemetryKafkaProps = KafkaConnector.getTelemetryKafkaProperties(parameterTool, telemetryConsumer, telemetryCampaignTopic);
        KafkaSource<String> masterCampaignSource = KafkaConnector.createStringKafkaSource(telemetryKafkaProps, parameterTool, isTest);

        // Data stream created from telemetry campaign
        return env.fromSource(masterCampaignSource,
                        WatermarkStrategy.noWatermarks(),
                        telemetryCampaignTopic)
                .flatMap(telemetryMapFunction)
                .name(OperatorNames.MASTER_CAMPAIGN_SOURCE)
                .uid(OperatorNames.MASTER_CAMPAIGN_SOURCE);


    }

    private static DataStream<Notification> getNotificationDataStream(final StreamExecutionEnvironment env,
                                                                      final ParameterTool parameterTool,
                                                                      boolean isTest) {
        String priorityTopic = parameterTool.get(FlinkRuntime.Kafka.NOTIFICATION_PRIORITY_TOPIC);
        KafkaConnector.KafkaProperties priorityTopicKafkaProps = KafkaConnector.getNotificationKafkaProperties(parameterTool, priorityTopic);
        KafkaSource<String> notificationSource = KafkaConnector.createStringKafkaSource(priorityTopicKafkaProps, parameterTool, isTest);

        return env.fromSource(notificationSource,
                        WatermarkStrategy.noWatermarks(),
                        priorityTopic)
                .flatMap(notificationMapperFunction)
                .name(OperatorNames.NOTIFICATION_JSON_SOURCE)
                .uid(OperatorNames.NOTIFICATION_JSON_SOURCE);
    }
}
