package org.hmcl.cvp.dataplatform.bruno.operator;

import com.google.gson.Gson;
import lombok.extern.slf4j.Slf4j;
import org.apache.flink.api.common.functions.RichFlatMapFunction;
import org.apache.flink.util.Collector;
import org.hmcl.cvp.dataplatform.commons.utils.GsonUtils;
import org.hmcl.cvp.dataplatform.contract.notification.AlertDetails;
import org.hmcl.cvp.dataplatform.contract.notification.Notification;

import java.util.Objects;

@Slf4j
public class NotificationFunction extends RichFlatMapFunction<String, Notification> {

    private static final Gson GSON = GsonUtils.getGson();

    @Override
    public void flatMap(String value, Collector<Notification> out) {

        try {

            Notification notification = GSON.fromJson(value, Notification.class);
            if (Objects.isNull(notification)) {
                log.debug("Notification is null for {}", value);
                return;
            }

            AlertDetails alertDetails = notification.getAlertDetails();
            if (Objects.isNull(alertDetails)) {
                log.debug("AlertDetails is null for {}", value);
                return;
            }

            out.collect(notification);

        } catch (Exception e) {
            log.error("An error occurred while normalising  alert notification {} to Telemetry: ", value, e);
        }

    }

}
