package org.hmcl.cvp.dataplatform.bruno.operator;

import lombok.extern.slf4j.Slf4j;
import org.apache.flink.api.common.functions.FlatMapFunction;
import org.apache.flink.util.Collector;
import org.hmcl.cvp.dataplatform.bruno.contracts.MQTTSinkData;
import org.hmcl.cvp.dataplatform.contract.notification.Notification;

import java.util.Objects;

import static org.hmcl.cvp.dataplatform.bruno.contracts.QOS.NOTIFICATION_QOS;

@Slf4j
public class B2BNotificationMapperFunction implements FlatMapFunction<Notification, MQTTSinkData> {

    @Override
    public void flatMap(Notification value, Collector<MQTTSinkData> out) {

        try {
            if (Objects.isNull(value)) return;

            log.info("Received Notification data: {}", value);

            String vid = value.getVehicleVid();
            String b2bId = value.getB2bClientId();
            if (b2bId == null) {
                log.warn("B2B ID is null for notification data: {}", value);
                return;
            }

            String topic = "alert/" + b2bId;

            MQTTSinkData wrapper = MQTTSinkData
                    .builder()
                    .vid(vid)
                    .message(value.toString())
                    .topic(topic)
                    .qos(NOTIFICATION_QOS)
                    .build();
            out.collect(wrapper);

        } catch (Exception e) {
            log.error("An error occurred while normalising notification data {} to B2B mqtt sink data: ", value, e);
        }

    }

}
