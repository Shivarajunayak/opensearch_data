package org.hmcl.cvp.dataplatform.bruno.contracts;

public class MQTTConstants {
    public static final String MQTT_BROKER_URL = "mqtt.server.url";
    public static final String MQTT_BROKER_PORT = "mqtt.server.port";
    public static final String MQTT_CLIENT_ID = "mqtt.client.id";


    private MQTTConstants() {
    }
}
