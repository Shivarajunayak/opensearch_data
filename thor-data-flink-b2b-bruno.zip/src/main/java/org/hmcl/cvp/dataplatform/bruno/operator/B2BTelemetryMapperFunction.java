package org.hmcl.cvp.dataplatform.bruno.operator;

import lombok.extern.slf4j.Slf4j;
import org.apache.flink.api.common.functions.FlatMapFunction;
import org.apache.flink.util.Collector;
import org.hmcl.cvp.dataplatform.bruno.contracts.MQTTSinkData;
import org.hmcl.cvp.dataplatform.commons.utils.TelemetryUtils;
import org.hmcl.cvp.dataplatform.contract.telemetry.Telemetry;

import java.util.Objects;

import static org.hmcl.cvp.dataplatform.bruno.contracts.QOS.TELEMETRY_QOS;

@Slf4j
public class B2BTelemetryMapperFunction implements FlatMapFunction<Telemetry, MQTTSinkData> {


    @Override
    public void flatMap(Telemetry value, Collector<MQTTSinkData> out) {

        try {
            if (Objects.isNull(value) || Objects.isNull(value.getDimensions())) return;

            log.info("Received Telemetry data: {}", value);

            String vid = TelemetryUtils.getVirtualId(value);
            String b2bId = TelemetryUtils.getB2BClientId(value);
            if (b2bId == null) {
                log.warn("B2B ID is null for telemetry data: {}", value);
                return;
            }

            String topic = "telemetry/" + b2bId;

            MQTTSinkData wrapper = MQTTSinkData
                    .builder()
                    .vid(vid)
                    .message(value.toString())
                    .topic(topic)
                    .qos(TELEMETRY_QOS)
                    .build();
            out.collect(wrapper);


        } catch (Exception e) {
            log.error("An error occurred while normalising telemetry {} to B2B mqtt sink data: ", value, e);
        }

    }

}
