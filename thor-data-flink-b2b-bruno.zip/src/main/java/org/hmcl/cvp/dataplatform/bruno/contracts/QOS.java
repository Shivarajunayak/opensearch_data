package org.hmcl.cvp.dataplatform.bruno.contracts;

public class QOS {
    public static final int TELEMETRY_QOS = 0;
    public static final int CHARGING_QOS = 1;
    public static final int NOTIFICATION_QOS = 1;

    private QOS() {
        // Prevent instantiation
    }
}
