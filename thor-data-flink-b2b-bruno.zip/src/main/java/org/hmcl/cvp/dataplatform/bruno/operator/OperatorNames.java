package org.hmcl.cvp.dataplatform.bruno.operator;

public class OperatorNames {

    public static final String MASTER_CAMPAIGN_SOURCE = "master-campaign-source";
    public static final String CHARGING_CAMPAIGN_SOURCE = "charging-campaign-source";
    public static final String NOTIFICATION_JSON_SOURCE = "notification-json-source";
    public static final String B2B_TELEMETRY_WRAPPER = "b2b-telemetry-wrapper";
    public static final String B2B_CHARGING_WRAPPER = "b2b-charging-wrapper";
    public static final String B2B_NOTIFICATION_WRAPPER = "b2b-notification-wrapper";
    public static final String MQTT_TELEMETRY_SINK = "MQTT Telemetry sink";
    public static final String MQTT_CHARGING_SINK = "MQTT Charging sink";
    public static final String MQTT_NOTIFICATION_SINK = "MQTT Notification sink";


    private OperatorNames() {
    }
}
