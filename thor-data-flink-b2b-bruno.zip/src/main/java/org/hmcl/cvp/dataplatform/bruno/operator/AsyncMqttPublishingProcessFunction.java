package org.hmcl.cvp.dataplatform.bruno.operator;

import lombok.extern.slf4j.Slf4j;
import org.apache.flink.configuration.Configuration;
import org.apache.flink.streaming.api.functions.ProcessFunction;
import org.apache.flink.util.Collector;
import org.eclipse.paho.client.mqttv3.IMqttActionListener;
import org.eclipse.paho.client.mqttv3.IMqttToken;
import org.eclipse.paho.client.mqttv3.MqttAsyncClient;
import org.eclipse.paho.client.mqttv3.MqttClientPersistence;
import org.eclipse.paho.client.mqttv3.MqttConnectOptions;
import org.eclipse.paho.client.mqttv3.MqttMessage;
import org.eclipse.paho.client.mqttv3.persist.MemoryPersistence;
import org.hmcl.cvp.dataplatform.bruno.contracts.MQTTSinkData;

@Slf4j
public class AsyncMqttPublishingProcessFunction extends ProcessFunction<MQTTSinkData, String> {
    private transient MqttAsyncClient client;
    private final String brokerUrl;
    private final String brokerPort;
    private final String clientId;


    public AsyncMqttPublishingProcessFunction(String brokerUrl, String brokerPort, String mqttClientId) {
        this.brokerUrl = brokerUrl;
        this.brokerPort = brokerPort;
        this.clientId = mqttClientId;
    }

    @Override
    public void open(Configuration parameters) throws Exception {
        String mqttBrokerUrl = brokerPort != null && !brokerPort.isEmpty() ? brokerUrl + ":" + brokerPort : brokerUrl;
        MqttClientPersistence persistence = new MemoryPersistence();  // 👈 Using in-memory persistence

        client = new MqttAsyncClient(mqttBrokerUrl, clientId, persistence);

        // Configure connection options
        MqttConnectOptions options = new MqttConnectOptions();
        options.setCleanSession(false);

        // Connect asynchronously
        log.info("Connecting to broker: {} for client: {}", mqttBrokerUrl, clientId);
        client.connect(options, null, new IMqttActionListener() {
            @Override
            public void onSuccess(IMqttToken asyncActionToken) {
                log.info("Connected to broker: {}", mqttBrokerUrl);
            }

            @Override
            public void onFailure(IMqttToken asyncActionToken, Throwable exception) {
                log.error("Failed to connect to broker: {}", mqttBrokerUrl, exception);
            }
        });
    }

    @Override
    public void processElement(MQTTSinkData value, Context ctx, Collector<String> out) throws Exception {
        log.info("Received data: {}", value);
        log.info("current client status: client id: {}, isClientConnected: {}", clientId, client != null && client.isConnected());
        if (client != null && client.isConnected()) {
            MqttMessage message = new MqttMessage(value.getMessage().getBytes());
            message.setQos(value.getQos());

            client.publish(value.getTopic(), message, null, new IMqttActionListener() {
                @Override
                public void onSuccess(IMqttToken asyncActionToken) {
                    log.info("Message published successfully: {}", value);
                }

                @Override
                public void onFailure(IMqttToken asyncActionToken, Throwable exception) {
                    log.error("Failed to publish message: {}", value, exception);
                }
            });
        } else {
            log.warn("Client is not connected. Skipping message: {}", value);
        }
    }

    @Override
    public void close() throws Exception {
        log.info("Closing MQTT client connection");
        if (client != null && client.isConnected()) {
            client.disconnect(null, new IMqttActionListener() {
                @Override
                public void onSuccess(IMqttToken asyncActionToken) {
                    log.info("Disconnected from broker");
                }

                @Override
                public void onFailure(IMqttToken asyncActionToken, Throwable exception) {
                    log.error("Failed to disconnect from broker", exception);
                }
            });
            client.close();
        }
    }
}