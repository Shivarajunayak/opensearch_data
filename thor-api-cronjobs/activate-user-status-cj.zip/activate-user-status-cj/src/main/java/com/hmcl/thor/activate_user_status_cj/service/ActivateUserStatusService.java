package com.hmcl.thor.activate_user_status_cj.service;

import com.hmcl.thor.activate_user_status_cj.dto.BatchResult;
import com.hmcl.thor.activate_user_status_cj.dto.CleanupResult;
import com.hmcl.thor.activate_user_status_cj.dto.UserManagementProperties;
import com.hmcl.thor.activate_user_status_cj.dto.UserProfileEntityKeys;
import com.hmcl.thor.activate_user_status_cj.repository.UserManagementSchedulerRepository;
import jakarta.annotation.PostConstruct;
import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.SpringApplication;
import org.springframework.context.ApplicationContext;
import org.springframework.stereotype.Service;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

import java.time.Instant;
import java.util.List;

@Service
@Slf4j
public class ActivateUserStatusService {

    private final UserManagementProperties userManagementProperties;
    private final UserManagementSchedulerRepository userManagementSchedulerRepository;
    private final ApplicationContext applicationContext;

    public ActivateUserStatusService(
            UserManagementProperties userManagementProperties,
            UserManagementSchedulerRepository userManagementSchedulerRepository,
            ApplicationContext applicationContext) {
        this.userManagementProperties = userManagementProperties;
        this.userManagementSchedulerRepository = userManagementSchedulerRepository;
        this.applicationContext = applicationContext;
    }

    @PostConstruct
    public void onStartup() {
        updateInactiveToActiveStatus()
                .subscribe(
                        result -> {
                            log.info("Startup status update result: {}", result);
                            int exitCode = SpringApplication.exit(applicationContext, () -> 0);
                            System.exit(exitCode);
                        },
                        error -> {
                            log.error("Error during startup status update", error);
                            int exitCode = SpringApplication.exit(applicationContext, () -> 1);
                            System.exit(exitCode);
                        }
                );
    }

    public Mono<CleanupResult> updateInactiveToActiveStatus() {
        long currentTimestamp = Instant.now().toEpochMilli();
        return userManagementSchedulerRepository.countInactiveSecondaryUsers(currentTimestamp)
                .flatMap(totalRecords -> {
                    log.info("Found {} inactive secondary user records to process.", totalRecords);
                    return processInactiveUsersInBatches(currentTimestamp, totalRecords);
                })
                .doOnSuccess(result -> log.info("Inactive to active status update completed successfully: {}", result))
                .doOnError(error -> log.error("Error during updating the status to active", error));
    }

    private Mono<CleanupResult> processInactiveUsersInBatches(long currentTimestamp, long totalRecords) {
        return Flux.defer(() -> fetchAndProcessNextBatch(currentTimestamp))
                .expand(result -> {
                    if (result.getProcessedCount() == Integer.parseInt(userManagementProperties.getActivateUserBatchSize())) {
                        return fetchAndProcessNextBatch(currentTimestamp);
                    }
                    return Mono.empty();
                })
                .reduce(new CleanupResult(0L, totalRecords), this::combineResults);
    }

    private Mono<BatchResult> fetchAndProcessNextBatch(long currentTimestamp) {
        return userManagementSchedulerRepository.findInactiveSecondaryUsers(
                        currentTimestamp,
                        Integer.parseInt(userManagementProperties.getActivateUserBatchSize())
                )
                .next()
                .filter(users -> !users.isEmpty())
                .flatMap(users -> {
                    List<UserProfileEntityKeys> userKeys = users.stream()
                            .map(user -> new UserProfileEntityKeys(user.getVid(), user.getProfileId(), user.getPrimaryProfileId()))
                            .toList();
                    return userManagementSchedulerRepository.updateProfileStatusToActive(userKeys)
                            .map(BatchResult::new);
                });
    }

    private CleanupResult combineResults(CleanupResult acc, BatchResult current) {
        return new CleanupResult(
                acc.getProcessedCount() + current.getProcessedCount(),
                acc.getTotalRecords()
        );
    }
}