package com.hmcl.thor.activate_user_status_cj.dto;

import lombok.Builder;
import lombok.Getter;
import software.amazon.awssdk.enhanced.dynamodb.mapper.annotations.*;


@DynamoDbBean
@Getter
@Builder
public class UserProfileEntity {
    private String vid;
    private String profileId;
    private String primaryProfileId;
    private String profileType;
    private Long accessValidTillTsp;
    private String profileStatus;

    @DynamoDbPartitionKey
    @DynamoDbAttribute("vid")
    public String getVid() {
        return vid;
    }

    @DynamoDbSortKey
    @DynamoDbAttribute("profileId")
    public String getProfileId() {
        return profileId;
    }

    @DynamoDbAttribute("profileType")
    public String getProfileType() {
        return profileType;
    }

    @DynamoDbAttribute("primaryProfileId")
    public String getPrimaryProfileId() {
        return primaryProfileId;
    }

    @DynamoDbAttribute("accessValidTillTsp")
    public Long getAccessValidTillTsp() {
        return accessValidTillTsp;
    }

    @DynamoDbAttribute("profileStatus")
    public String getProfileStatus() {
        return profileStatus;
    }

}
