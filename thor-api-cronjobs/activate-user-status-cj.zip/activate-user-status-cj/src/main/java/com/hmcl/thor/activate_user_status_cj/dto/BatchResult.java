package com.hmcl.thor.activate_user_status_cj.dto;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class BatchResult {
    private final long processedCount;
}
