package com.hmcl.thor.activate_user_status_cj.dto;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonValue;

import java.io.Serializable;

public enum PreferredNotificationEnum implements Serializable {
    SMS("SMS"),
    EMAIL("Email"),
    PUSH("Push"),
    ALL("All"),
    NA("NA");

    private String value;

    private PreferredNotificationEnum(String value) {
        this.value = value;
    }

    @JsonValue
    public String getValue() {
        return this.value;
    }

    @Override
    public String toString() {
        return String.valueOf(this.value);
    }

    @JsonCreator
    public static PreferredNotificationEnum fromValue(String value) {
        PreferredNotificationEnum[] var1 = values();
        int var2 = var1.length;

        for(int var3 = 0; var3 < var2; ++var3) {
            PreferredNotificationEnum b = var1[var3];
            if (b.value.equals(value)) {
                return b;
            }
        }

        throw new IllegalArgumentException("Unexpected value '" + value + "'");
    }
}