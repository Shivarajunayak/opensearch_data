package com.hmcl.thor.activate_user_status_cj.config;


import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.hmcl.thor.activate_user_status_cj.dto.UserManagementProperties;

import lombok.Getter;
import lombok.Setter;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.io.Resource;

import java.io.IOException;
import java.io.InputStream;
import java.util.Map;

/**
 *
 * Application configuration
 */
@Configuration
@Slf4j
public class ApplicationPropertiesConfig {

    @Autowired
    private ObjectMapper mapper;

    @Value("${activate-user-status-cj.config}")
    private Resource userManagementSecretFiles;

    @Bean
    public UserManagementProperties userManagementProperties() throws Exception{

        Map<String, String> props;
        log.info("Loading user management properties from path: {}", userManagementSecretFiles.getFile().getAbsolutePath());
        try(InputStream inputStream = userManagementSecretFiles.getInputStream()){
            props = mapper.readValue(inputStream, new TypeReference<Map<String, String>>() {});
            log.info("Loaded properties: {}", props.keySet());
        } catch (IOException e) {
            log.error("Failed to load user management properties", e);
            throw e;
        }

        UserManagementProperties properties = new UserManagementProperties();
        properties.setActivateUserBatchSize(props.get("activateUserBatchSize"));
        properties.setRegion(props.get("region"));
        properties.setDdbEndpoint(props.get("ddbEndpoint"));
        properties.setDdbCustPrefTable(props.get("ddbCustPrefTable"));

        log.info("UserManagementProperties initialized: {}", properties);

        return properties;
    }

}
