package com.hmcl.thor.activate_user_status_cj.dto;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import jakarta.validation.constraints.*;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.io.Serializable;
import java.util.List;


@AllArgsConstructor
@NoArgsConstructor
@Setter
@Getter
@JsonIgnoreProperties(ignoreUnknown=true)
public class UserProfile implements Serializable {
    private String vin;
    private String vid;
    private String profileId;
    private String name;
    private String countryCode;
    private String phone;
    private String email;
    private String customerId;
    private String tenantId;
    private ProfileTypeEnum profileType;
    private String vehicleModel;
    private Long vinMappingTsp;
    private Long accessValidFromTsp;
    private Long accessValidTillTsp;
    private String registrationNumber;
    private List<PreferredNotificationChannel> preferredNotificationChannel;
    private String primaryProfileId;
    private String fcmToken;
    private ProfileStatusEnum profileStatus;
    private Boolean isRider;
    private String createdBy;
    private String updatedBy;
    private Long createdTsp;
    private Long updatedTsp;
}