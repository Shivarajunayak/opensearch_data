package com.hmcl.thor.activate_user_status_cj.mapper;



import com.hmcl.thor.activate_user_status_cj.dto.ProfileTypeEnum;
import com.hmcl.thor.activate_user_status_cj.dto.UserManagementProperties;
import com.hmcl.thor.activate_user_status_cj.dto.UserProfile;
import lombok.AllArgsConstructor;

import org.springframework.stereotype.Component;
import software.amazon.awssdk.services.dynamodb.model.AttributeValue;
import software.amazon.awssdk.services.dynamodb.model.AttributeValueUpdate;

import java.time.Instant;
import java.util.*;
import java.util.stream.Collectors;

import static com.hmcl.thor.activate_user_status_cj.util.ApplicationConstants.*;

@Component
@AllArgsConstructor
public class UserProfileMapper {

    private UserManagementProperties properties;


    public static UserProfile fromMap(Map<String, AttributeValue> attributeValueMap) {
        UserProfile profile = new UserProfile();
        if (null != attributeValueMap) {
            profile.setVid(attributeValueMap.get(VID).s());
            profile.setName(attributeValueMap.get(NAME).s());
            profile.setProfileId(attributeValueMap.get(PROFILE_ID).s());
            profile.setEmail(attributeValueMap.get(EMAIL).s());
            profile.setCountryCode(attributeValueMap.get(COUNTRY_CODE) != null ? attributeValueMap.get(COUNTRY_CODE).s() : DEFAULT_COUNTRY_CODE);
            profile.setPhone(attributeValueMap.get(PHONE).s());
            profile.setTenantId(attributeValueMap.get(TENANT_ID).s());
            profile.setProfileType(ProfileTypeEnum.fromValue(attributeValueMap.get(PROFILE_TYPE).s()));
            profile.setCustomerId(attributeValueMap.get(CUSTOMER_ID).s());
            profile.setVehicleModel(attributeValueMap.get(VEHICLE_MODEL).s());
            profile.setCreatedTsp(Long.valueOf(attributeValueMap.get(CREATED_TSP).n()));
            profile.setUpdatedTsp(Long.valueOf(attributeValueMap.get(UPDATED_TSP).n()));
            profile.setVinMappingTsp(Long.valueOf(attributeValueMap.get(VIN_MAPPING_TSP).n()));
            if(attributeValueMap.get(FCM_TOKEN)!=null)
                profile.setFcmToken(attributeValueMap.get(FCM_TOKEN).s());
            if(attributeValueMap.get(ACCESS_VALID_FROM_TSP) != null)
                profile.setAccessValidFromTsp(Long.valueOf(attributeValueMap.get(ACCESS_VALID_FROM_TSP).n()));
            if(attributeValueMap.get(ACCESS_VALID_TILL_TSP) != null)
                profile.setAccessValidTillTsp(Long.valueOf(attributeValueMap.get(ACCESS_VALID_TILL_TSP).n()));
            if(attributeValueMap.get(REGISTRATION_NUMBER) != null)
                profile.setRegistrationNumber(attributeValueMap.get(REGISTRATION_NUMBER).s());
            profile.setIsRider(attributeValueMap.get(IS_RIDER).bool());
            profile.setCreatedBy(attributeValueMap.get(CREATED_BY).s());
            if(attributeValueMap.get(UPDATED_BY) != null)
                profile.setUpdatedBy(attributeValueMap.get(UPDATED_BY).s());
            profile.setCreatedTsp(Long.parseLong(attributeValueMap.get(CREATED_TSP).n()));
            profile.setUpdatedTsp(Long.parseLong(attributeValueMap.get(UPDATED_TSP).n()));

        }
        return profile;
    }


}