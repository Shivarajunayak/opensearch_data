package com.hmcl.thor.activate_user_status_cj.repository;

import com.hmcl.thor.activate_user_status_cj.dto.*;
import com.hmcl.thor.activate_user_status_cj.exceptions.UnknownException;
//import com.hmcl.thor.activate_user_status_cj.service.UserManagementService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Repository;
import reactor.core.publisher.Mono;
import software.amazon.awssdk.services.dynamodb.DynamoDbAsyncClient;
import software.amazon.awssdk.services.dynamodb.model.*;
import reactor.core.publisher.Flux;

import java.util.List;
import java.util.Map;
import java.util.concurrent.ExecutionException;
import java.util.stream.Collectors;

import static com.hmcl.thor.activate_user_status_cj.util.ApplicationConstants.*;

@Repository
@Slf4j
public class UserManagementSchedulerRepository {
    private final DynamoDbAsyncClient dynamoDbAsyncClient;
    private final String custPreferenceTable;
//    private final UserManagementService userManagementService;
//    private final UserManagementElasticCacheService userManagementElasticCacheService;


    public UserManagementSchedulerRepository(UserManagementProperties userManagementProperties, DynamoDbAsyncClient dynamoDbAsyncClient) {
        this.dynamoDbAsyncClient = dynamoDbAsyncClient;
        this.custPreferenceTable = userManagementProperties.getDdbCustPrefTable();
//        this.userManagementService = userManagementService;
//        this.userManagementElasticCacheService = userManagementElasticCacheService;

    }

    public Mono<Long> countExpiredSecondaryUsers(long currentTimestamp) {
        log.info("Counting expired secondary users at timestamp: {}", currentTimestamp);
        ScanRequest scanRequest = ScanRequest.builder()
                .tableName(custPreferenceTable)
                .filterExpression("profileType = :secondary AND profileStatus = :active AND accessValidTillTsp < :currentTimestamp")
                .expressionAttributeValues(Map.of(
                        ":secondary", AttributeValue.builder().s(ProfileTypeEnum.SECONDARY.getValue()).build(),
                        ":active", AttributeValue.builder().s(ProfileStatusEnum.ACTIVE.getValue()).build(),
                        ":currentTimestamp", AttributeValue.builder().n(String.valueOf(currentTimestamp)).build()
                ))
                .build();
        return Mono.fromFuture(() -> dynamoDbAsyncClient.scan(scanRequest))
                .doOnSuccess(response -> log.info("Scan completed for expired secondary users, count: {}", response.count()))
                .map(ScanResponse::count)
                .map(Long::valueOf)
                .onErrorResume(ex -> {
                    log.error("Error counting expired secondary users", ex);
                    return Mono.just(0L);
                });
    }

    private Flux<UserProfileEntity> scanWithPagination(ScanRequest initialScanRequest) {
        log.info("Starting paginated scan with request: {}", initialScanRequest);
        return Flux.create(sink -> {
            final ScanRequest[] currentRequest = {initialScanRequest};
            Mono.defer(() -> Mono.fromFuture(() -> dynamoDbAsyncClient.scan(currentRequest[0])))
                    .repeat()
                    .doOnNext(response -> {
                        log.debug("Scan page received with {} items", response.items().size());
                        response.items().forEach(item -> sink.next(mapToEntity(item)));
                        if (response.lastEvaluatedKey() == null || response.lastEvaluatedKey().isEmpty()) {
                            log.info("Pagination complete for scan.");
                            sink.complete();
                        } else {
                            log.debug("Continuing pagination with lastEvaluatedKey: {}", response.lastEvaluatedKey());
                            currentRequest[0] = currentRequest[0].toBuilder()
                                    .exclusiveStartKey(response.lastEvaluatedKey())
                                    .build();
                        }
                    })
                    .doOnError(e -> {
                        log.error("Error during paginated scan", e);
                        sink.error(e);
                    })
                    .subscribe();
        });
    }

    public Flux<List<UserProfileEntity>> findExpiredSecondaryUsers(long currentTimestamp, int batchSize) {
        log.info("Finding expired secondary users at timestamp: {} with batch size: {}", currentTimestamp, batchSize);
        ScanRequest scanRequest = ScanRequest.builder()
                .tableName(custPreferenceTable)
                .filterExpression("profileType = :secondary AND profileStatus = :active AND accessValidTillTsp < :currentTimestamp")
                .expressionAttributeValues(Map.of(
                        ":secondary", AttributeValue.builder().s(ProfileTypeEnum.SECONDARY.getValue()).build(),
                        ":active", AttributeValue.builder().s(ProfileStatusEnum.ACTIVE.getValue()).build(),
                        ":currentTimestamp", AttributeValue.builder().n(String.valueOf(currentTimestamp)).build()
                ))
                .limit(batchSize)
                .build();
        return scanWithPagination(scanRequest)
                .buffer(batchSize)
                .doOnNext(batch -> log.info("Fetched batch of expired secondary users, size: {}", batch.size()))
                .doOnError(e -> log.error("Error fetching expired secondary users", e));
    }

    private UserProfileEntity mapToEntity(Map<String, AttributeValue> item) {
        log.debug("Mapping DynamoDB item to UserProfileEntity: {}", item);
        return UserProfileEntity.builder()
                .vid(item.get(VID).s())
                .profileId(item.get(PROFILE_ID).s())
                .profileType(item.get(PROFILE_TYPE).s())
                .profileStatus(item.get(PROFILE_STATUS).s())
                .accessValidTillTsp(Long.parseLong(item.get(ACCESS_VALID_TILL_TSP).n()))
                .primaryProfileId(item.get(PRIMARY_PROFILE_ID).s())
                .build();
    }

    public Mono<Long> countInactiveSecondaryUsers(long currentTimestamp) {
        log.info("Counting inactive secondary users at timestamp: {}", currentTimestamp);
        ScanRequest scanRequest = ScanRequest.builder()
                .tableName(custPreferenceTable)
                .filterExpression("profileType = :secondary AND profileStatus = :upcoming AND accessValidFromTsp <= :currentTimestamp")
                .expressionAttributeValues(Map.of(
                        ":secondary", AttributeValue.builder().s(ProfileTypeEnum.SECONDARY.getValue()).build(),
                        ":upcoming", AttributeValue.builder().s(ProfileStatusEnum.UPCOMING.getValue()).build(),
                        ":currentTimestamp", AttributeValue.builder().n(String.valueOf(currentTimestamp)).build()
                ))
                .build();
        return Mono.fromFuture(() -> dynamoDbAsyncClient.scan(scanRequest))
                .doOnSuccess(response -> log.info("Scan completed for inactive secondary users, count: {}", response.count()))
                .map(ScanResponse::count)
                .map(Long::valueOf)
                .onErrorResume(ex -> {
                    log.error("Error counting inactive secondary users", ex);
                    return Mono.just(0L);
                });
    }

    public Flux<List<UserProfileEntity>> findInactiveSecondaryUsers(long currentTimestamp, int batchSize) {
        log.info("Finding inactive secondary users at timestamp: {} with batch size: {}", currentTimestamp, batchSize);
        ScanRequest scanRequest = ScanRequest.builder()
                .tableName(custPreferenceTable)
                .filterExpression("profileType = :secondary AND profileStatus = :upcoming AND accessValidFromTsp <= :currentTimestamp")
                .expressionAttributeValues(Map.of(
                        ":secondary", AttributeValue.builder().s(ProfileTypeEnum.SECONDARY.getValue()).build(),
                        ":upcoming", AttributeValue.builder().s(ProfileStatusEnum.UPCOMING.getValue()).build(),
                        ":currentTimestamp", AttributeValue.builder().n(String.valueOf(currentTimestamp)).build()
                ))
                .limit(batchSize)
                .build();
        return scanWithPagination(scanRequest)
                .buffer(batchSize)
                .doOnNext(batch -> log.info("Fetched batch of inactive secondary users, size: {}", batch.size()))
                .doOnError(e -> log.error("Error fetching inactive secondary users", e));
    }

    public Mono<Integer> updateProfileStatusToActive(List<UserProfileEntityKeys> keys) {
        log.info("Updating profile status to ACTIVE for {} items", keys.size());
        return Flux.fromIterable(keys)
                .flatMap(key -> {
                    Map<String, AttributeValue> itemKey = Map.of(
                            "vid", AttributeValue.builder().s(key.getVid()).build(),
                            "profileId", AttributeValue.builder().s(key.getProfileId()).build()
                    );

                    Map<String, AttributeValue> updatedAttributes = Map.of(
                            "profileStatus", AttributeValue.builder().s(ProfileStatusEnum.ACTIVE.getValue()).build()
                    );
                    UpdateItemRequest updateRequest = UpdateItemRequest.builder()
                            .tableName(custPreferenceTable)
                            .key(itemKey)
                            .attributeUpdates(updatedAttributes.entrySet().stream()
                                    .collect(Collectors.toMap(
                                            Map.Entry::getKey,
                                            entry -> AttributeValueUpdate.builder()
                                                    .value(entry.getValue())
                                                    .action(AttributeAction.PUT)
                                                    .build()
                                    )))
                            .build();

                    log.info("Updating profile status to ACTIVE for vid: {}, profileId: {}", key.getVid(), key.getProfileId());

                    return Mono.fromFuture(() -> dynamoDbAsyncClient.updateItem(updateRequest))
                            .doOnSuccess(response -> log.debug("UpdateItem succeeded for vid: {}, profileId: {}", key.getVid(), key.getProfileId()))
                            .doOnError(e -> log.error("UpdateItem failed for vid: {}, profileId: {}", key.getVid(), key.getProfileId(), e));
                })
                .count()
                .map(Long::intValue)
                .doOnSuccess(count -> log.info("Successfully updated {} items to ACTIVE", count))
                .onErrorResume(e -> {
                    log.error("Error processing profile status updates", e);
                    return Mono.just(0);
                });
    }

}