package com.hmcl.thor.activate_user_status_cj.util;

public class ApplicationConstants {

    private ApplicationConstants() {}

    public static final String FAIL="FAIL";
    public static final String SUCCESS="SUCCESS";

    public static final String SUCCESS_MSG="Saved/Updated Successfully";
    public static final String ERROR_MSG = "Please check the errors";
    public static final String UPDATE_MSG="Updated Successfully";
    public static final String DELETE_MSG="Deleted Successfully";

    public static final String VALID_PHONE="Please provide a valid Phone Number";

    public static final String VID_PROFILE_ID_ERROR="Please check the Profile and Vid details";

    public static final String THRESHOLD_MESSAGE="Please check the threshold";
    public static final String LIMIT_UNIT_MESSAGE="Please check the Limit and Unit";

    public static final String FENCE_TYPE_MESSAGE="Please check Fence type";

    public static final String RADIUS_UNIT_MESSAGE="Radius and Unit are mandatory for Fence type as circle";
    public static final String COORDINATES_MESSAGE="Please check the Co-ordinates";
    public static final String RADIUS_LIMIT="Radius should be between 1-100";
    public static final String UNIT_TYPE_MESSAGE="Unit can be km,metre or miles for Fence type as circle";
    public static final String SPEED_LIMIT_KM="Speed Limit threshold should be between 30-180 km/hr";
    public static final String SPEED_LIMIT_MILES= "Speed Limit threshold should be between 18-112 miles/hr";
    public static final String EV_STREAM_TENANT_ID = "EV-VIDA";
    public static final String ICE_HERO_STREAM_TENANT_ID = "ICE-HERO";

    //UserProfileMapper constants start
    public static final int SUCCESS_CODE=200;
    public static final int CREATED_CODE=201;
    public static final int BAD_REQUEST_CODE=400;
    public static final String UPDATE_VALIDATION_MESSAGE = "These Fields are not allowed to update Vid, ProfileId, TenantId, VehicleModel, PrimaryProfileId";
    public static final String VIN_ERROR_MESSAGE = "Vin should not be null or empty";
    public static final String UPDATE_ALLOWED_VALIDATION_MESSAGE = "Only Primary user can update the profile. Please check the UpdatedBy field.";
    public static final String ACCESS_VALID_TILL_TSP_FOR_SECONDARY = "Primary user only can update the AccessValidTillTsp for secondary";
    public static final String ACCESS_VALID_FROM_TSP_NOT_VALID = "Provided accessValidFromTsp value not valid. It should not be past data and time.";
    public static final String ACCESS_VALID_FROM_TSP_NOT_VALID_FOR_ISRIDER = "Cannot update isRider to true. please update the accessValidTillTsp, it should not be past data and time.";
    public static final String ACCESS_INVALID_TILL_TSP = "AccessValidTillTsp value should be greater than AccessValidFromTsp";

    public static final String NAME = "name";
    public static final String PREFERRED_NOTIFICATION = "preferredNotification";
    public static final String CHANNEL = "channel";
    public static final String CODE = "code";
    public static final String ENABLED = "enabled";
    public static final String SEND_NOTIFICATION_TO_PRIMARY = "sendNotificationToPrimary";
    public static final String ALERT_ENABLED = "alertEnabled";
    public static final String TAG_PROFILES = "tagProfiles";
    public static final String TAGGED_PROFILE = "taggedProfile";
    public static final String OPT_IN_FOR_NOTIFICATION = "optInForNotification";
    public static final String COORDINATES = "coordinates";
    public static final String LONGITUDE = "longitude";
    public static final String LATITUDE = "latitude";
    public static final String FENCE_TYPE = "fenceType";
    public static final String RADIUS = "radius";
    public static final String UNIT = "unit";
    public static final String GEOFENCE_SET_BY = "geofenceSetBy";
    public static final String CREATED_TSP = "createdTsp";
    public static final String UPDATED_TSP = "updatedTsp";
    public static final String STATUS = "status";
    public static final String AUTO_IMMOBILISATION_ENABLED = "autoImmobilisationEnabled";
    public static final String NOTIFICATION_SET_BY = "notificationSetBy";
    public static final String DAYS = "days";
    public static final String DAY = "day";
    public static final String FROM_TSP = "fromTsp";
    public static final String TO_TSP = "toTsp";
    public static final String TIMEFENCE_SET_BY = "timefenceSetBy";
    public static final String ASSIGNED_FEATURES = "assignedFeatures";
    public static final String STANDARD_FEATURES = "standardFeatures";
    public static final String PREFERRED_NOTIFICATION_CHANNEL = "preferredNotificationChannel";
    public static final String FCM_TOKEN = "fcmToken";
    public static final String GEOFENCE_FEATURES = "geofenceFeatures";
    public static final String TIMEFENCE_FEATURES = "timefenceFeatures";
    public static final String DEFAULT_FEATURES = "defaultFeatures";
    public static final String SUBSCRIPTION_FEATURES = "subscriptionFeatures";
    public static final String OPTIONAL_FEATURES = "optionalFeatures";
    public static final String MASTER_FEATURES = "masterFeatures";
    public static final String OVER_SPEED_LIMIT = "overSpeedLimit";
    public static final String BATTERY_CHARGING_LIMIT = "batteryChargingLimit";
    public static final String VID = "vid";
    public static final String PROFILE_ID = "profileId";
    public static final String EMAIL = "email";
    public static final String COUNTRY_CODE = "countryCode";
    public static final String DEFAULT_COUNTRY_CODE = "+91";
    public static final String PHONE = "phone";
    public static final String PHONE_HASH = "phoneHash";
    public static final String TENANT_ID = "tenantId";
    public static final String PROFILE_TYPE = "profileType";
    public static final String CUSTOMER_ID = "customerId";
    public static final String VEHICLE_MODEL = "vehicleModel";
    public static final String VIN_MAPPING_TSP = "vinMappingTsp";
    public static final String ACCESS_VALID_FROM_TSP = "accessValidFromTsp";
    public static final String ACCESS_VALID_TILL_TSP = "accessValidTillTsp";
    public static final String REGISTRATION_NUMBER = "registrationNumber";
    public static final String PROFILE_STATUS = "profileStatus";
    public static final String PRIMARY_PROFILE_ID = "primaryProfileId";
    public static final String AVAILABLE_FEATURES = "availableFeatures";
    public static final String EMERGENCY_CONTACTS = "emergencyContacts";
    public static final String PHONE_NUMBER = "phoneNumber";
    public static final String ID = "id";
    public static final String IS_RIDER = "isRider";
    public static final String CREATED_BY = "createdBy";
    public static final String UPDATED_BY = "updatedBy";
    public static final String SYSTEM = "System";
    public static final String GEOFENCE_CMD_STATUS = "geoFenceCommandStatus";
    public static final String LIMIT = "limit";
    public static final String NEW_LIMIT = "newLimit";
    public static final String OVERSPEED_STATUS = "status";
    public static final String OVERSPEED_SOURCE = "commandSource";
    public static final String RAISE_ALERT_FOR = "raiseAlertFor";
    public static final String SECONDARY_PROFILE_ERROR = " Please provide the PrimaryProfileId for secondary profile.";
    public static final String VALIDATION_ERROR1 = "Please check values for fields ";
    public static final String VALIDATION_ERROR2 = " are not valid.";
    public static final String TSP_MIN_VALUE_ERROR = "is not valid, Min value 1000000000000";
    public static final String TSP_MAX_VALUE_ERROR = "is not valid, Max vlaue 9999999999999";
    public static final String TSP_MIN_VALUE = "1000000000000";
    public static final String TSP_MAX_VALUE = "9999999999999";
    public static final String INVALID_UPDATE_BY_PROFILEID_ERROR = "Invalid updateBy Primary ProfileId for the secondary profile";
    public static final String INVALID_SECONDARY_PROFILEID_ERROR = "The provided ProfileId is not a secondary profile.";
    //UserProfileMapper constants End

    public static final String VID_INVALID_PARAM = "Vid is not valid, it should be 45 chars";
    public static final String PROFILE_INVALID_PARAM = "ProfileId is not valid, it should be 8 characters";
    public static final String PRIMARY_USER_PROFILE_ERROR = "Only 1 Primary user allowed for Vehicle";
    public static final String CUSTOMER_ID_USER_PROFILE_ERROR = "Customer Id is already exist in present vehicle Vid";
    public static final String PRIMARY_USER_PROFILE_NOT_AVAILABLE_ERROR = "There is no Primary user profile exist for Vid.";
    public static final String VID_PROFILE_LIMIT = "For each Vehicle id the max number of Active/Upcoming Secondary user profile limit is ";
    public static final String VID_PROFILEID_ERROR  = "Please check the VID and ProfileId";
    public static final String VID_PROFILEID_SUCCESS =  "Successfully fetched the user profile by Vid and ProfileId";
    public static final String STATUS_NOT_VALID =  "Please provide the user profile status";
    public static final String STATUS_CANT_UPDATE =  "Profile Status cannot be updated for the Deleted Profiles";
    public static final String PROFILEID_ERROR = "Please check the ProfileId, Profile is not exist";
    public static final String PROFILEID_SUCCESS = "Successfully fetched the user profile by ProfileId";
    public static final String PROFILE_BY_PHONE_SUCCESS = "Successfully fetched the user profile by Phone Number";
    public static final String VID_ERROR = "Please check the VID, Profiles are not exist";
    public static final String VIN_ERROR = "Please check the VIN, Profiles are not exist";
    public static final String VID_SUCCESS = "Profiles fetched by vid successfully.";
    public static final String VID_ACTIVE_PROFILES_ERROR = "Please check the VID, Active Profiles are not exist";
    public static final String VID_ACTIVE_PROFILES_SUCCESS = "Active Profiles fetched by vid successfully.";
    public static final String PROFILE_ID_INDEX = "profileId-index";
    public static final String COMMAND_EXECUTION_SUCCESSFULLY = "Command Execution Status fetched successfully.";
    public static final String NOTIFICATION_SUCCESSFULLY = "Notification Details fetched successfully.";
    public static final String NOTIFICATION_HISTORY_SUCCESSFULLY = "Notification History fetched successfully.";
    public static final String PROFILE_UPDATE_ERROR = "Please check the VID and ProfileId, There no user profile to update";
    public static final String PHONE_INDEX = "phoneHash-index";
    public static final String CUSTOMER_ID_INDEX = "customerId-index";
    public static final String PHONE_NUMBER_ERROR = "Please check the MobileNumber, Profile is not exist";
    public static final String PROFILE_EXPIRED = "Profile is already expired";
    public static final String PROFILE_DELETED = "Profile is already deleted";
    public static final String PROFILE_INACTIVE = "Profile is yet to be active";
    public static final String FEATURE_CODE = "featureCode";
    public static final String FEATURE_NAME = "featureName";
    public static final String MASTER_FEATURE_CODE = "masterFeatureCode";
    public static final String FEATURE_FOR_PRIMARY_USER = "primaryUserOnly";
    public static final String FEATURE_TYPE = "featureType";
    public static final String FEATURE_CATEGORY = "featureCategory";
    public static final String POLYGON = "polygon";
    public static final String CIRCLE = "circle";

    public static final String CHANNELS = "channels";
    public static final String ACTION = "action";
    public static final String DATE_FORMAT = "yyyy-MM-dd'T'HH:mm'Z'";
    public static final String SMS = "SMS";
    public static final String PUSH = "Push";

    public static final String CREATE = "Create";
    public static final String UPDATE = "Update";
    public static final String DELETE = "Delete";
    //user profile error messages
    public static final String NAME_ERROR = "Name cannot be empty or null";
    public static final String PHONE_ERROR_MESSAGE = "Phone Number cannot be empty or null";
    public static final String COUNTRY_CODE_ERROR_MESSAGE = "Country Code cannot be empty or null";
    public static final String COUNTRY_CODE_INVALID_MESSAGE = "Invalid country code format";
    public static final String EMAIL_ERROR_MESSAGE = "Email is not valid";
    public static final String CUSTOMER_LENGTH_ERROR_MESSAGE = "CustomerId length should be in between 3 to 50 chars";
    public static final String TENANT_LENGTH_ERROR_MESSAGE = "TenantId length should be in between 3 to 30 chars";
    public static final String VEHICLEMODEL_LENGTH_ERROR_MESSAGE = "VehicleModel length should be in between 1 to 100 chars";
    public static final String CUSTOMERID_ERROR_MESSAGE = "CustomerId cannot be empty or null";
    public static final String TENANTID_ERROR_MESSAGE = "TenentId cannot be empty or null";
    public static final String USERTYPE_ERROR_MESSAGE = "UserType cannot be empty or null";
    public static final String VEHICLEMODEL_ERROR_MESSAGE = "Vehicle Model cannot be empty or null";
    public static final String CREATE_TSP_ERROR_MESSAGE = "CreatedTsp cannot be empty or null";
    public static final String UPDATE_TSP_ERROR_MESSAGE = "UpdatedTsp cannot be empty or null";
    public static final String VINMAPPING_TSP_ERROR_MESSAGE = "VinMappingTsp cannot be empty or null";
    public static final String ACCESS_VALID_FROM_TSP_ERROR_MESSAGE = "AccessValidFromTsp cannot be empty or null";
    public static final String ACCESS_VALID_TILL_TSP_ERROR_MESSAGE = "AccessValidTillTsp cannot be empty or null";
    public static final String AND = " And ";
    public static final String ACCESS_VALID_MIN_MAX_ERROR_MESSAGE = "Value should in Between " + TSP_MIN_VALUE + AND + TSP_MAX_VALUE;
    public static final String REGISTRATION_ERROR_MESSAGE = "RegistrationNumber cannot be empty or null";
    public static final String NAME_LENGTH_ERROR_MESSAGE = "Name length should be in between 3 to 50 chars";
    public static final String VID_LENGTH_ERRROR_MESSAGE = "Vid length should be in between 45 to 50 chars";
    public static final String VID_ERROR_MESSAGE = "Vid cannot be empty or null";
    public static final String PROFILE_ID_LENGTH_ERROR_MESSAGE = "ProfileId length should be 8 chars";
    public static final String PROFILE_ID_ERROR_MESSAGE = "ProfileId cannot be empty or null";
    public static final String UPDATED_BY_ERROR_MESSAGE = "UpdatedBy cannot be empty or null";
    public static final String FEATURE_NOT_VALID  = "Please provided feature code to update";
    public static final String ASSIGNED_FEATURE_NOT_VALID = "Assigned Features : FeatureCode, FeatureName, MasterFeatureCode, FeatureType and FeatureCategory are mandatory.";
    public static final String ASSIGNED_FEATURE_CODE_NOT_VALID = "Assigned Features : FeatureCode can not be empty.";
    public static final String ASSIGNED_FEATURE_DEFAULT_ERROR = "Assigned Features : All Default Features are assigned from Primary to Secondary, please remove Default features from list.";
    public static final String ASSIGNED_FEATURE_CODE_NOT_AVALILABLE = "Assigned Features : Feature is not assigned to the Primary user as Optional or Subscription, Feature Code : ";
    public static final String ASSIGNED_FEATURE_CODE_NOT_ALLOWED = "Assigned Features : Feature is not allow to assign for Secondary user, Feature Code : ";

    public static final String DEFULAT_FEATURES_NOT_VALID = "Assigned Features : Default Features are not allowed, Default feature will be assigned from Primary profile.";

    public static final String FEATURE_NOT_ASSIGNED = "Provided feature is not assigned to the profile";
    public static final String GEOFENCE_VALIDATIONS = "Geofence validations";
    public static final String OVER_SPEED_SECONDARY_ALERT_ENABLED_ERROR = "OverSpeed : alertEnabled update not allowed for the Secondary users.";
    public static final String GEOFENCE_ID_NOT_VALID = "Geofence id should not null or empty for update";
    public static final String GEOFENCE_COUNT_VALIDATION = "Reached the max limit of GeoFences, max limit is ";
    public static final String GEOFENCE_FEATURE_NOT_VALID = "Geofence feature should not be null";
    public static final String TOP_SPEED_ERROR = " Speed Limit is more than the Top Speed of the Vehicle Model. Please check and update";
    public static final String UNEXPECTED_VALUE = "Unexpected value '";
    public static final String EXCEEDED_MAX_NUMBER_OF_COORDINATES_IN_GEOFENCE = "Exceeded max number of coordinates in geofence, max coordinates allowed are ";
    public static final String MAX_DISTANCE_BETWEEN_TWO_COORDINATES_OF_POLYGON = "Max distance between two coordinates of polygon cannot be more then 50km";
    public static final String MIN_DISTANCE_BETWEEN_TWO_COORDINATES_OF_POLYGON = "Min distance between two coordinates of polygon cannot be less then 100m";
    public static final String MAX_RADIUS_OF_CIRCLE_ALLOWED_FOR_GEOFENCE_IN_KILOMETER = "Max radius of circle allowed for geofence in kilometer is 50";
    public static final String GEOFENCE_ENABLED_NOT_VALID = "Geofence enabled/alertEnabled should not null or empty for update";
    public static final String MIN_RADIUS_OF_CIRCLE_ALLOWED_FOR_GEOFENCE_IN_METER = "Min radius of circle allowed for geofence in metre is 100";
    public static final String MIN_RADIUS_OF_CIRCLE_ALLOWED_FOR_GEOFENCE_IN_KILOMETER = "Min radius of circle allowed for geofence in kilometer is 0.1";

    //Custom Ride Profile Constants start
    //CRP service class constants
    public static final String BO_PROFILE_ID = "BKOFFICE";
    public static final String CRP_PROFILE_TYPE = "profileType";
    public static final String CUSTOM_RIDE_PROFILES = "customRideProfiles";
    public static final String CRP_TENANT_ID = "tenantId";
    public static final String CRP_CREATED_BY = "createdBy";
    public static final String CRP_CREATED_TSP = "createdTsp";
    public static final String CRP_UPDATED_BY = "updatedBy";
    public static final String CRP_UPDATED_TSP = "updatedTsp";
    public static final String CRP_SOURCE = "source";
    public static final String GEO_FENCE = "geoFence";
    public static final String SPEED_LIMIT = "speedLimit";
    public static final String REGENERATION = "regeneration";
    public static final String ACCELERATION = "acceleration";
    public static final String CRP_ID = "id";
    public static final String CRP_NAME = "name";
    public static final String CRP_PROFILE_ID = "profileId";
    public static final String CRP_VID = "vid";
    public static final String CRP_LAST_TRIGGERED_ACTION = "lastTriggeredAction";
    public static final String CRP_BO_SOURCE = "BO";
    public static final String CRP_CAPP_SOURCE = "CAPP";
    public static final String COMMAND_REF_ID = "commandRefId";
    public static final String ACTIVE_CUSTOM_RIDE_PROFILE_ID = "activeCustomRideProfileId";
    public static final String CLOUD = "CLOUD";
    public static final String BLE = "BLE";
    public static final String BACKOFFICE = "BACKOFFICE";
    public static final String CUSTOM_RIDE_MODE_KAFKA_COMMAND_CODE = "C48934C";

    public static final String CRP_ONLY_5_PROFILES_ALLOWED_ERROR_MSG = "Only 5 custom ride profiles are allowed on a vehicle for a particular user";
    public static final String CRP_VID_OR_PROFILE_DOES_NOT_EXISTS_ERROR_MSG = "Given vid or profileId does not exists";
    public static final String CRP_MULTIPLE_PROFILES_FOR_VID_ERROR_MSG = "Multiple custom ride profiles record with different primary profileID found for the given vid.Please delete the old records and try again";
    public static final String CRP_ISSUED_BO_PROFILE_ALREADY_EXISTS_ERROR_MSG = "Custom ride profile of BO with issued status already exits for the given vid. Please wait for it to complete before creating a new one.";
    public static final int CRP_MAX_PROFILE_PER_USER_VALUE = 5;
    public static final String CRP_CREATION_SUCCESS_RESPONSE_MSG = "Custom ride profile created successfully";
    public static final String CRP_DELETION_SUCCESS_RESPONSE_MSG = "Custom ride profile deleted successfully";
    public static final String CRP_UPDATION_SUCCESS_RESPONSE_MSG = "Custom ride profile updated successfully";
    public static final String GIVEN_CRP_FOR_UPDATION_DOES_NOT_EXISTS_ERR_MSG = "Given custom ride profile does not exists";
    public static final String INVALID_ACTION_VALUE_TO_GET_CRP_ERR_MSG = "Invalid action, action could be either all or search";
    public static final String CRP_GET_ACTION_ALL = "all";
    public static final String CRP_GET_ACTION_SEARCH = "search";
    public static final String NO_CRP_FOUND_ERR_MSG = "No custom ride profiles found";
    public static final String CRP_FOUND_SUCCESS_RESPONSE_MSG = "Custom ride profiles found successfully";
    public static final String CRP_ID_VALUE_CANNOT_BE_NULL_ERR_MSG = "Custom ride profile ID cannot be null";
    public static final String CRP_ACTIVATE_ACTION = "activate";
    public static final String CRP_DEACTIVATE_ACTION = "deactivate";
    public static final String CRP_ACTIVATE_API_REQUEST_ACTION_CANNOT_BE_NULL_ERR_MSG = "Invalid action, action could be either activate or deactivate";
    public static final String CRP_ACTIVATE_API_REQUEST_SUCCESS_MSG = "Custom ride profile command issued successfully";
    public static final String CRP_ACTIVATE_API_REQUEST_FAILED_MSG = "Custom ride profile command activation failed";
    public static final String CRP_ACTIVE_PROFILE_CANNOT_BE_UPDATED_ERR_MSG = "Active/Issued status custom ride profile cannot be updated or deleted";
    public static final String CRP_ONLY_PRIMARY_USER_CAN_CREATE_UPDATE_PROFILE_ERROR_MSG = "Only primary user can create/update custom ride profile";
    public static final String NEW_CRP_COMMAND_CANNOT_BE_ISSUED_BEFORE_THE_PREVIOUS_ONE_IS_COMPLETED_ERR_MSG = "New custom profile command cannot be issued before the previous one is completed";
    public static final String CRP_PROFILE_ALREADY_ACTIVE_ERR_MSG = "Custom ride profile is already active";
    public static final String CRP_PROFILE_ALREADY_INACTIVE_ERR_MSG = "Custom ride profile is already inactive";
    public static final String CRP_SPEED_LIMIT_EXCEEDS_ERROR_MSG = "Given speed limit is more than the top speed limit of the vehicle model (which is %s) , Please update the speed value and try again.";
    //CRP Validation Constants
    public static final String CRP_NAME_REGEX = "^\\w+( \\w+)*$";
    public static final String CRP_ACC_MIN_VALUE = "1";
    public static final String CRP_ACC_MAX_VALUE = "10";
    public static final String CRP_REGEN_MIN_VALUE = "1";
    public static final String CRP_REGEN_MAX_VALUE = "10";
    public static final String CRP_SPEED_LIMIT_MIN_VALUE = "30";
    public static final String CRP_SPEED_LIMIT_MAX_VALUE = "250";
    //Custom Ride Profile Constants end

    //geofence validations start
    public static final String GEO_FENCE_TAG_PROFILE_ID_VALIDATION = "GeoFence : TagProfile Id should be one of the secondary user profile Id. ";
    public static final String GEO_FENCE_UPDATE_VALIDATION = "GeoFence : Geofence Id is not available in geofence list to update.  ";
    public static final String GEO_FENCE_CIRCLE_THE_RADIUS_VALIDATION_METERS = "GeoFence : If Geofence Type is Circle, the radius should be greater than 0 and less than or equal to %s for unit Meter";
    public static final String GEOFENCE_UPDATE_VALIDATION = "GeoFence: Update not allowed for the fenceType, Coordinates and geofenceSetBy. please delete and create a new geofence.";
    public static final String GEO_FENCE_NAME_EMPTY_OR_NULL = "GeoFence: Name should not be empty or null";
    public static final String GEO_FENCE_NAME_UNIQUE = "GeoFence: Names should be unique for the profile";
    public static final String GEO_FENCE_ID_UNIQUE = "GeoFence: ID should be unique for the profile";
    public static final String GEO_FENCE_RAISE_FOR_ALERT_VALIDATION = "GeoFence: Raise for alert should not be null, allowed values are Entry,Exit and EntryAndExit";
    public static final String GEO_FENCE_CREATE_TSP = "GeoFence : CreateTsp should in be in between ";
    public static final String GEO_FENCE_DELETE_VALIDATION = "GeoFence : Provided geofence id is not available in geofence list";
    public static final String GEO_FENCE_DELETE_STATUS_VALIDATION = "GeoFence : Please check the status of geofence, to delete geofence it should in DeActivated Status.";

    public static final String GEO_FENCE_UPDATED_TSP = "GeoFence : UpdatedTsp should in be in between ";
    public static final String GEO_FENCE_UPDATED_TSP_VALIDATION = "GeoFence : Updated timestamp should be greater than or equal to created timestamp";
    public static final String GEO_FENCE_PREFERRED_NOTIFICATION_MANDATORY = "GeoFence : preferredNotification mandatory";
    public static final String GEO_FENCE_PRIMARY_PROFILE_ONLY_SET_AUTO_IMMOBILIZATION = "GeoFence : Primary Profile only set Auto-immobilization ";
    public static final String GEO_FENCE_ONLY_ONE_GEO_FENCE_IMMOBILIZATION = "GeoFence : Only one Geo-fence with Auto-immobilization will be active for Primary ";
    public static final String GEO_FENCE_TAGGED_PROFILES_VALIDATION = "GeoFence : Tagged profiles not allowed for the secondary user profile ";
    public static final String GEO_FENCE_GEO_FENCE_SET_BY_VALIDATION = "GeoFence : geoFenceSetBy should be profileId for Primary user profile. For Secondary profile, it can be primary profile id or Secondary profile Id ";
    public static final String GEO_FENCE_POLYGON_COORDINATES_VALIDATION = "GeoFence : 1st and last Coordinates should be equal for polygon";
    public static final String GEO_FENCE_POLYGON_COORDINATES_COUNT_VALIDATION = "GeoFence : Polygon coordinates should more than 4";
    public static final String GEO_FENCE_POLYGON_NOT_VALID = "GeoFence : Not a valid polygon";
    public static final String GEO_FENCE_POLYGON_INVALID = "GeoFence : Polygon should not be null";
    public static final String GEO_FENCE_CIRCLE_UNIT_VALIDATION = "GeoFence : If GeoFenceType is Circle, the radius should be > 0 and unit should be km,miles, and metre mandatory";
    public static final String GEO_FENCE_CIRCLE_THE_RADIUS_VALIDATION_KM_MILES = "GeoFence : If GeoFenceType is Circle, the radius should be greater than 0  and less than or equal to 50 for unit Km and Miles";
    public static final String GEO_FENCE_CIRCLE_THE_RADIUS_VALIDATION_YARDS = "GeoFence : If GeoFenceType is Circle, the radius should be greater than 0 and less than or equal to 880 for unit Yards";
    public static final String GEO_FENCE_CIRCLE_INVALID = "GeoFence : Circle should not be null";
    public static final String OVER_SPEED_UNIT_VALIDATION = "OverSpeed: For OverSpeed Unit should be km/hr or miles/hr";
    public static final String OVER_SPEED_LIMIT_VALIDATION = "OverSpeed: For OverSpeed Speed Limit should greater than zero";
    public static final String OVER_SPEED_SECONDARY_ERROR = " OverSpeed : New Speed update not allowed for the Secondary users. ";
    public static final String OVER_SPEED_CANT_UPDATE = "OverSpeed: It is already in pending status, can't update now";
    public static final String GEO_FENCE_NOT_EXIST  = "Please check the Profile, there are no geofences to update";
    public static final String BATTERY_CHARGING_LIMIT_VALIDATION = "Battery Charging: Limit should not be in between 0 and 100";
    public static final String GEO_FENCE_LIMIT = "GeoFence: For Profile we can have only max of 5 geoFences";
    public static final String COMMAND_SUCCEEDED_STATUS = "SUCCEEDED";
    public static final String ALERT_TYPE = "alertType";
    public static final String ALERT_TYPE_VALUE = "BasicCommandResponse";
    public static final String AUTO_IMMOBILIZATION_CAN_ONLY_BE_SET_IF_IT_IS_NOT_AN_ENTRY_CONDITION = "Auto-immobilisation is only set when it's an exit and both condition";
    public static final String OVER_SPEED_NEW_CURRENT_SPEED_LIMIT_SAME = "OverSpeed: New speed limit is same as current speed limit, which is already set in vehicle";
    public static final String GEOFENCE_STATUS_TRANSITION_VALIDATIONS = "Geofence Status Transition Validations";
    public static final String GEOFENCE_STATUS_TRANSITION_FROM_SAVED_TO_DEACTIVATED = "Transition from SAVED to DEACTIVATED is not allowed.";
    public static final String GEOFENCE_STATUS_TRANSITION_FROM_DEACTIVATED_TO_SAVED = "Transition from DEACTIVATED to SAVED is not allowed.";
    public static final String GEOFENCE_STATUS_TRANSITION_FROM_ACTIVE_TO_SAVED = "Transition from ACTIVE to SAVED is not allowed.";
    //geofence validation ends
    public static final String BEARER = "Bearer ";

    //Encryption endpoints start
    public static final String USER_PROFILE_WITH_VID_PROFILE_ID = "/api/v1/users/vehicle/profiles/profile-details";
    public static final String USER_PROFILE_WITH_VID = "/api/v1/users/vehicle/profiles";
    public static final String USER_PROFILE_WITH_VID_ACTIVE = "/api/v1/users/vehicle/active-profiles";
    public static final String USER_PROFILE_WITH_PROFILE_ID = "/api/v1/users/profiles/profile-details";
    public static final String USER_PROFILE_WITH_PHONE = "/api/v1/users/phone/profile-details";
    public static final String USER_PROFILE_SECONDARY_LIST = "/api/v1/users/profile/secondary/profile-id-list";
    //Encryption endpoints end
}
