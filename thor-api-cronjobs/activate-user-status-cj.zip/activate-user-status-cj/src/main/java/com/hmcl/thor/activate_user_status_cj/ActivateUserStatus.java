package com.hmcl.thor.activate_user_status_cj;


import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication(scanBasePackages  = "com.hmcl.thor")
public class ActivateUserStatus {

	public static void main(String[] args) {
		SpringApplication.run(ActivateUserStatus.class, args);
	}

}
