package com.hmcl.thor.activate_user_status_cj.config;

import com.hmcl.thor.activate_user_status_cj.dto.UserManagementProperties;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import software.amazon.awssdk.auth.credentials.DefaultCredentialsProvider;
import software.amazon.awssdk.regions.Region;
import software.amazon.awssdk.services.dynamodb.DynamoDbAsyncClient;

import java.net.URI;

@Slf4j
@Configuration
@AllArgsConstructor
public class DynamoDBConfig {

    private UserManagementProperties properties;

    /**
     * Creating DynamoDbAsyncClient bean object to connect DDB
     * @return
     */
    @Bean
    public DynamoDbAsyncClient dynamoDbAsyncClient() {
        return DynamoDbAsyncClient.builder()
                .region(Region.of(properties.getRegion()))
                .endpointOverride(URI.create(properties.getDdbEndpoint()))
                .credentialsProvider(DefaultCredentialsProvider.create())
                .build();
    }
}


