import os
import json
import requests
import asyncio
import base64
import logging
from dotenv import load_dotenv

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

load_dotenv()

def get_config():
    with open("/kong-apispec-sync-cj/conf/app-config.json", "r") as f:
        return json.load(f)

async def getAuthToken(deply_env, config):
    url = config[f'{deply_env}CognitoEndpoint']
    ClientId = config[f'{deply_env}ClientId']
    ClientSecret = config[f'{deply_env}ClientSecret']
    GrantType = config[f'{deply_env}GrantType']

    try:
        payload = f'client_secret={ClientSecret}&client_id={ClientId}&grant_type={GrantType}'
        headers = {
            'Content-Type': 'application/x-www-form-urlencoded'
        }
        response = requests.post(url, headers=headers, data=payload)
        response.raise_for_status()  # Raise an exception for bad status codes
        responseJson = response.json()
        return responseJson['access_token']
    except requests.exceptions.RequestException as e:
        logger.error(f"Error retrieving Cognito Token: {e}")
        print(f"Error retrieving Cognito Token: {e}")
        raise

async def getApiSpec(deply_env, data, token, config):
    try:
        domainUrl = config[f'{deply_env}ApiEndpoint']
        apiSpecUrl = f'{domainUrl}{data["SpecURL"]}'
        headers = {
            'Authorization': f'Bearer {token}',
            'Cookie': 'HttpOnly=true; authorization=AQAAhcTcXLvxqa2T; HttpOnly=true',
            'Content-Type': 'text/plain'
        }
        response = requests.get(apiSpecUrl, headers=headers)
        response.raise_for_status()
        responseJson = response.text
        jsonBytes = responseJson.encode('utf-8')
        base64Bytes = base64.b64encode(jsonBytes)
        return base64Bytes.decode('utf-8')  # Decode to string for consistency data
    except requests.exceptions.RequestException as e:
        console.log(f'{domainUrl}{data["SpecURL"]}')
        logger.error(f"Error retrieving API Spec: {e}")
        print(f"Error retrieving API Spec: {e}")
        raise

async def uploadDocumentation(data, content, config):
    try:
        kongDocUploadUrl = f'{config["kongURL"]}/{data["productId"]}/documents/{data["ProductDocId"]}'
        payload = json.dumps({
            "status": "published",
            "content": content
        })
        headers = {
            'Authorization': f'Bearer {config["kongPAT"]}',
            'Content-Type': 'application/json'
        }
        response = requests.patch(kongDocUploadUrl, headers=headers, data=payload)
        response.raise_for_status()
        return response.text
    except requests.exceptions.RequestException as e:
        logger.error(f"Error uploading Documentation: {e}")
        print(f"Error uploading Documentation: {e}")
        raise

async def uploadSpecification(data, content, config):
    try:
        kongSpecUploadUrl = f'{config["kongURL"]}/{data["productId"]}/product-versions/{data["productVersionId"]}/specifications/{data["ProductSpecId"]}'
        payload = json.dumps({
            "name": data['specName'],
            "content": content
        })
        headers = {
            'Authorization': f'Bearer {config["kongPAT"]}',
            'Content-Type': 'application/json'
        }
        response = requests.patch(kongSpecUploadUrl, headers=headers, data=payload)
        response.raise_for_status()
        return response.text
    except requests.exceptions.RequestException as e:
        logger.error(f"Error uploading Specification: {e}")
        print(f"Error uploading Specification: {e}")
        raise

async def main():
    config = get_config()
    deplyEnv = config["env"]
    try:
        token = await getAuthToken(deplyEnv, config)
    except Exception:
        return

    directory = os.fsencode(f'./{deplyEnv}/')
    for file in os.listdir(directory):
        filename = os.fsdecode(file)
        if filename.endswith(".json"):
            path = f'{os.fsdecode(directory)}{filename}'
            try:
                with open(path, 'r') as f:
                    data = json.load(f)
                    try:
                        specBase64 = await getApiSpec(deplyEnv, data, token, config)
                        uploadDocRes = await uploadDocumentation(data, specBase64, config)
                        uploadSpecRes = await uploadSpecification(data, specBase64, config)
                        print(f'file {filename} processed successfully')
                        logger.info(f'file {filename} processed successfully')
                    except Exception:
                        pass # Errors within file processing are already logged
            except FileNotFoundError:
                logger.error(f"File not found: {path}")
                print(f"File not found: {path}")
            except json.JSONDecodeError:
                logger.error(f"Error decoding JSON in file: {path}")
                print(f"Error decoding JSON in file: {path}")
            except Exception as e:
                logger.error(f'Error processing file {filename}: {e}')
                print(f"Error processing file {filename}: {e}")

    logger.info('Task completed')

if __name__ == "__main__":
    asyncio.run(main())