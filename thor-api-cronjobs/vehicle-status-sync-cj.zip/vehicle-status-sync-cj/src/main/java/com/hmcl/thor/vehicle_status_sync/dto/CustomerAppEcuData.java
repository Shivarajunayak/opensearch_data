package com.hmcl.thor.vehicle_status_sync.dto;

import lombok.Builder;
import lombok.Data;

@Builder
@Data
public class CustomerAppEcuData {
    String ecuName;
    String ecuAbb;
}
