package com.hmcl.thor.vehicle_status_sync;


import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.transaction.annotation.EnableTransactionManagement;

@SpringBootApplication(scanBasePackages  = "com.hmcl.thor")
@EnableTransactionManagement
public class CronJobsApplication {

	public static void main(String[] args) {
		SpringApplication.run(CronJobsApplication.class, args);
	}

}
