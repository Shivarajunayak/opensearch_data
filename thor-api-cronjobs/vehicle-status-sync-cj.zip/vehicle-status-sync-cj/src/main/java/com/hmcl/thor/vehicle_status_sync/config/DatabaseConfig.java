package com.hmcl.thor.vehicle_status_sync.config;

import com.hmcl.thor.vehicle_status_sync.properties.DatabaseProperties;

import com.zaxxer.hikari.HikariConfig;
import com.zaxxer.hikari.HikariDataSource;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.jdbc.datasource.DriverManagerDataSource;

import javax.sql.DataSource;
import java.io.IOException;

//This if for connecting to the database
@Configuration
@Slf4j
public class DatabaseConfig {



    @Autowired
    private DatabaseProperties databaseProperties;

    @Bean
    public DataSource devDataSource(DatabaseProperties databaseProperties) throws IOException {
        log.debug("Inside DatabaseConfig class :: devDataSource method, to connect with database...");
        return buildDataSource(databaseProperties);
    }

    private DataSource buildDataSource(DatabaseProperties databaseProperties) {
        if (databaseProperties==null) {
            throw new IllegalStateException("Properties could not be loaded");
        }

        HikariConfig dataSource = new HikariConfig();
        dataSource.setDriverClassName("org.postgresql.Driver");
        dataSource.setJdbcUrl("jdbc:postgresql://" + databaseProperties.getHost() + ":" + Integer.parseInt(databaseProperties.getPort()) + "/" + databaseProperties.getDatabase());
        dataSource.setUsername(databaseProperties.getUsername());
        dataSource.setPassword(databaseProperties.getPassword());
        return new HikariDataSource(dataSource);
    }


}
