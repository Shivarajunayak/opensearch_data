package com.hmcl.thor.vehicle_status_sync.entity;

import jakarta.persistence.*;
import lombok.*;

@Entity
@Table(name = "default_campaign", schema = "vehicle_management")
@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
@Data
public class DefaultCampaign {
    @Id
    private Long id;
    private String name;
    private String status;
    private boolean isDeleted;
    private Long updatedTsp;
    @Column(name = "xl4_campaign_id")
    private Long xl4CampaignId;
}