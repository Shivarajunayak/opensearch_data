package com.hmcl.thor.vehicle_status_sync.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.ZonedDateTime;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class UpdateEndpoints {
	private String id;
    private String version = ""; // default value is empty
    private ZonedDateTime lastUpdated;
    
    public void setVersion(String version) {
    	this.version= (version==null) ? "" : version;
    }
}
