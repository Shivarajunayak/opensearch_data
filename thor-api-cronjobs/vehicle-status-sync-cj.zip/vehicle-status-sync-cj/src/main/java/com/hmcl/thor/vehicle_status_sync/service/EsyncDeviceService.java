package com.hmcl.thor.vehicle_status_sync.service;


import com.hmcl.thor.vehicle_status_sync.dto.ClientInfoRequestDTO;
import com.hmcl.thor.vehicle_status_sync.dto.ClientInfoResponseDTO;
import com.hmcl.thor.vehicle_status_sync.dto.UpdateEndpoints;
import com.hmcl.thor.vehicle_status_sync.properties.VehicleStatusSyncPropertiesMapper;
import lombok.extern.slf4j.Slf4j;
import org.hibernate.service.spi.ServiceException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.web.client.RestClientSsl;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestClient;

import java.time.Instant;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Collections;
import java.util.List;

import static org.springframework.http.MediaType.APPLICATION_JSON;

@Slf4j
@Service
public class EsyncDeviceService {
    private final RestClient restClient;
	private final VehicleStatusSyncPropertiesMapper vehicleStatusSyncPropertiesMapper;

    public EsyncDeviceService(RestClient.Builder restClientBuilder, RestClientSsl ssl,
							  VehicleStatusSyncPropertiesMapper vehicleStatusSyncPropertiesMapper)  {
        this.restClient = restClientBuilder.apply(ssl.fromBundle("thorbundle")).build();
		this.vehicleStatusSyncPropertiesMapper = vehicleStatusSyncPropertiesMapper;
    }



	public List<UpdateEndpoints> getDeviceInfo(String vid) {
		try {
			ResponseEntity<List<UpdateEndpoints>> response = restClient.get()
					.uri(vehicleStatusSyncPropertiesMapper.getOtaBaseUrl() + "/cdb/client/endpoints?clientId=" + vid)
					.retrieve().toEntity(new ParameterizedTypeReference<List<UpdateEndpoints>>() {
					});
			return response.getBody();
		} catch (Exception e) {
			log.error("Exception Occured while fetching the details from excelfore for ecu firmwares : " + e);
			return Collections.emptyList();
		}
	}

	public String getDeviceLastSyncTspToOTAServer(String vid) {
		try {
			ClientInfoResponseDTO response = restClient.post()
					.uri(vehicleStatusSyncPropertiesMapper.getOtaBaseUrl() + "/cdb/client/get")
					.body(ClientInfoRequestDTO.builder().clientId(vid).build())
					.retrieve()
					.toEntity(ClientInfoResponseDTO.class).getBody();

			if(response == null || response.getLastSeen() == null) {
				return "";
			}
            return convertToEpochMillis(response.getLastSeen()).toString();
		} catch (Exception e) {
			log.error("Exception Occured while fetching the last seen timestamp from excelfore for vid: " + vid + " : " + e);
			return null;
		}
	}
	public static Long convertToEpochMillis(String lastSeen) {
		ZonedDateTime zonedDateTime = ZonedDateTime.parse(lastSeen, DateTimeFormatter.ISO_ZONED_DATE_TIME);
		Instant instant = zonedDateTime.toInstant();
		return instant.toEpochMilli();
	}
}
