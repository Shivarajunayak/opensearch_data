package com.hmcl.thor.vehicle_status_sync.properties;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
//@JsonIgnoreProperties(ignoreUnknown = true)
public class VehicleStatusSyncPropertiesMapper {
    private String otaBaseUrl;
    private String fileMgmtServiceEndpoint;
    private Long BatchSize;
}
