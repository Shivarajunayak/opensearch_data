package com.hmcl.thor.vehicle_status_sync.service;

import com.hmcl.thor.vehicle_status_sync.dto.CustomerAppEcuData;
import com.hmcl.thor.vehicle_status_sync.dto.ECUFirmwareDetails;
import com.hmcl.thor.vehicle_status_sync.dto.UpdateEndpoints;
import com.hmcl.thor.vehicle_status_sync.properties.VehicleStatusSyncPropertiesMapper;
import com.hmcl.thor.vehicle_status_sync.repository.VehicleRepository;
import lombok.extern.slf4j.Slf4j;
import org.hibernate.service.spi.ServiceException;
import org.springframework.boot.context.event.ApplicationReadyEvent;
import org.springframework.context.event.EventListener;
import org.springframework.stereotype.Service;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.concurrent.*;

@Slf4j
@Service
public class VehicleStatusSync {

    private final VehicleRepository vehicleRepository;
    private final EsyncDeviceService esyncDeviceService;
    private final Map<String, CustomerAppEcuData> customerAppEcuData = new HashMap<>();
    private final S3vehicleAuditUploadService s3vehicleAuditUploadService;
    private final VehicleStatusSyncPropertiesMapper vehicleStatusSyncPropertiesMapper;


    public VehicleStatusSync(VehicleRepository vehicleRepository, EsyncDeviceService esyncDeviceService,
                             S3vehicleAuditUploadService s3vehicleAuditUploadService, VehicleStatusSyncPropertiesMapper vehicleStatusSyncPropertiesMapper) {
        this.vehicleRepository = vehicleRepository;
        this.esyncDeviceService = esyncDeviceService;
        this.s3vehicleAuditUploadService = s3vehicleAuditUploadService;
        this.vehicleStatusSyncPropertiesMapper = vehicleStatusSyncPropertiesMapper;

        customerAppEcuData.put("7C", CustomerAppEcuData.builder().ecuName("Body Control Module").ecuAbb("BCM").build());
        customerAppEcuData.put("7F", CustomerAppEcuData.builder().ecuName("Engine Control Unit").ecuAbb("ECM").build());
        customerAppEcuData.put("7J", CustomerAppEcuData.builder().ecuName("Motor Control Unit").ecuAbb("MCU").build());
        customerAppEcuData.put("7M", CustomerAppEcuData.builder().ecuName("Telematics Control Unit").ecuAbb("TCU").build());
        customerAppEcuData.put("7Y", CustomerAppEcuData.builder().ecuName("METER INDICATOR LAMPS AND THE RELATED").ecuAbb("IC").build());
        customerAppEcuData.put("8D", CustomerAppEcuData.builder().ecuName("Battery Management System").ecuAbb("BMS").build());
        customerAppEcuData.put("8J", CustomerAppEcuData.builder().ecuName("KEYLESS, IMMOBILIZER AND THE RELATED").ecuAbb("EHLU").build());
        customerAppEcuData.put("8L", CustomerAppEcuData.builder().ecuName("Vehicle Control Unit").ecuAbb("VCU").build());
        customerAppEcuData.put("8M", CustomerAppEcuData.builder().ecuName("ISG AND THE RELATED").ecuAbb("ISG").build());
        customerAppEcuData.put("8N", CustomerAppEcuData.builder().ecuName("ACU AND THE RELATED").ecuAbb("ACU").build());
        customerAppEcuData.put("3F", CustomerAppEcuData.builder().ecuName("Antilock Braking System").ecuAbb("ABS").build());
        customerAppEcuData.put("7U", CustomerAppEcuData.builder().ecuName("CHARGER AND THE RELATED").ecuAbb("CU").build());
        customerAppEcuData.put("7L", CustomerAppEcuData.builder().ecuName("SWITCHES AND THE RELATED").ecuAbb("LHCP").build());
    }

    @EventListener(ApplicationReadyEvent.class)
    public void onApplicationReady() {
        log.info("Application is ready, starting ECU firmware sync...");
        getTheDataAndUploadToS3();
        if (!isTestEnvironment()) {
            System.exit(0);
        }
    }

    private boolean isTestEnvironment() {
        return Boolean.parseBoolean(System.getProperty("test.environment", "false"));
    }

    private List<String> getTheListOfAllVids() {
        return vehicleRepository.findAll().stream()
                .map(vehicle -> vehicle.getVid())
                .filter(Objects::nonNull)
                .toList();
    }

    public List<ECUFirmwareDetails> getECUFirmwareDetails(String vid) {
        try {
            String lastSyncTsp = esyncDeviceService.getDeviceLastSyncTspToOTAServer(vid);
            List<UpdateEndpoints> endpoints = esyncDeviceService.getDeviceInfo(vid);
            endpoints.sort(Comparator.comparing(e -> e.getLastUpdated().toInstant()));
            return parseEndpoints(endpoints, vid, lastSyncTsp);
        } catch (Exception e) {
            log.error("Error fetching ECU firmware details for VID {}: {}", vid, e.getMessage(), e);
            return Collections.emptyList();
        }
    }

    public List<ECUFirmwareDetails> parseEndpoints(List<UpdateEndpoints> endpoints, String vid, String lastSyncTsp) {
        Map<String, ECUFirmwareDetails> ecuMap = new HashMap<>();
        for (UpdateEndpoints endpoint : endpoints) {
            processEndpoint(endpoint, ecuMap, vid, lastSyncTsp);
        }
        return new ArrayList<>(ecuMap.values());
    }

    private void processEndpoint(UpdateEndpoints endpoint, Map<String, ECUFirmwareDetails> ecuMap, String vid, String lastSyncTsp) {
        String[] parts = endpoint.getId().split("_");
        if (parts.length < 1) {
            log.warn("Invalid endpoint ID format: {}", endpoint.getId());
            return;
        }

        String ecuID = parts[0];
        String ecuPrefix = ecuID.length() >= 2 ? ecuID.substring(0, 2) : ecuID;

        CustomerAppEcuData ecuData = customerAppEcuData.get(ecuPrefix);
        String ecuName = ecuData != null ? getOrDefault(ecuData.getEcuName(), "") : "";
        String ecuAbbreviation = ecuData != null ? getOrDefault(ecuData.getEcuAbb(), "") : "";

        String hardwareVersion = getHardwareVersion(parts);
        String type = getType(parts);

        ECUFirmwareDetails details = ecuMap.getOrDefault(ecuID, new ECUFirmwareDetails());
        populateECUFirmwareDetails(details, vid, ecuID, ecuName, ecuAbbreviation, hardwareVersion, type, endpoint, lastSyncTsp);
        ecuMap.put(ecuID, details);
    }

    private void populateECUFirmwareDetails(ECUFirmwareDetails details, String vid, String ecuID, String ecuName,
                                            String ecuAbbreviation, String hardwareVersion, String type,
                                            UpdateEndpoints endpoint, String lastSyncTsp) {
        details.setVid(vid);
        details.setEcuId(ecuID);
        details.setEcuName(ecuName);
        details.setEcuAbbreviation(ecuAbbreviation);
        details.setHardwareVersion(hardwareVersion);
        details.setLastConnectedTsp(lastSyncTsp);

        if ("SW".equalsIgnoreCase(type)) {
            details.setSoftwareVersion(endpoint.getVersion());
        }
    }

    private String getOrDefault(String value, String defaultValue) {
        return value != null ? value : defaultValue;
    }

    private String getType(String[] parts) {
        return parts.length > 2 ? parts[2] : "";
    }

    private String getHardwareVersion(String[] parts) {
        return parts.length > 3 && !parts[3].isEmpty() ? parts[3] : "";
    }

    public void getTheDataAndUploadToS3() {
        Long cronJobStartTime = System.currentTimeMillis();
        List<String> vids = getTheListOfAllVids();
        Map<String, List<ECUFirmwareDetails>> vidToDetails = new HashMap<>();
        Map<String, String> vidToLastSyncTsp = new HashMap<>();

        Long batchSize = vehicleStatusSyncPropertiesMapper.getBatchSize();
        int totalThreads = (int) Math.ceil((double) vids.size() / batchSize);
        ExecutorService executor = Executors.newFixedThreadPool(Math.min(totalThreads, 10));

        List<Callable<Void>> tasks = new ArrayList<>();
        for (long i = 0; i < vids.size(); i += batchSize) {
            long end = Math.min(i + batchSize, vids.size());
            List<String> batch = vids.subList((int) i, (int) end);

            tasks.add(() -> {
                for (String vid : batch) {
                    try {
                        log.info("Processing VID: {}", vid);

                        String lastSyncTsp = "";
                        try {
                            lastSyncTsp = esyncDeviceService.getDeviceLastSyncTspToOTAServer(vid);
                            if (lastSyncTsp != null) {
                                vidToLastSyncTsp.put(vid, lastSyncTsp);
                            }
                            else {
                                log.warn("Last sync timestamp is null for VID {}", vid);
                                continue;
                            }
                        } catch (ServiceException e) {
                            log.warn("Failed to fetch last sync timestamp for VID {}: {}", vid, e.getMessage());
                        }

                        List<ECUFirmwareDetails> details = null;
                        try {
                            details = getECUFirmwareDetails(vid);
                        } catch (Exception ex) {
                            log.error("Failed to get ECU firmware details for VID {}: {}", vid, ex.getMessage(), ex);
                        }

                        // Ensure non-null list for details
                        if (details == null || details.isEmpty()) {
                            ECUFirmwareDetails empty = new ECUFirmwareDetails();
                            empty.setVid(vid);
                            empty.setLastConnectedTsp(lastSyncTsp);
                            details = new ArrayList<>();
                            details.add(empty);
                        }

                        // 🔐 Absolute null safety at put()
                        if (vid != null && details != null) {
                            vidToDetails.put(vid, details);
                            log.info("VID {} has {} ECU details", vid, details.size());
                        } else {
                            log.warn("Skipping vidToDetails.put due to null key/value. vid={}, details={}", vid, details);
                        }

                    } catch (Exception e) {
                        log.error("Unexpected error processing VID {}: {}", vid, e.getMessage(), e);
                    }
                }


                return null;
            });
        }

        try {
            executor.invokeAll(tasks);
        } catch (InterruptedException e) {
            log.error("Thread interrupted while processing: {}", e.getMessage(), e);
            Thread.currentThread().interrupt(); // Reset interrupt flag
        } finally {
            executor.shutdown();
            try {
                if (!executor.awaitTermination(5, TimeUnit.MINUTES)) {
                    log.warn("Executor did not terminate in the expected time.");
                }
            } catch (InterruptedException e) {
                log.error("Await termination interrupted: {}", e.getMessage(), e);
                Thread.currentThread().interrupt();
            }
        }

        // Verify that all VIDs were processed
        Set<String> missingVids = new HashSet<>(vids);
        missingVids.removeAll(vidToDetails.keySet());
        if (!missingVids.isEmpty()) {
            log.warn("The following VIDs were not processed: {}", missingVids);
            // Optionally: reprocess them or throw exception
        } else {
            log.info("All VIDs processed successfully. Count: {}", vids.size());
        }

        // Write to file and upload
        try {
            String date = LocalDate.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd"));
            Path filePath = Paths.get("esync_connectivity_" + date + ".csv");
            File file = Files.exists(filePath) ? filePath.toFile() : Files.createFile(filePath).toFile();
            log.info("Writing vehicle details to CSV file: {}", file.getAbsolutePath());

            writeFirmwareDetailsToCSV(vidToDetails, file);

            String s3Key = s3vehicleAuditUploadService.uploadToS3(file);
            if (s3Key != null) {
                log.info("File uploaded successfully to S3 with key: {}", s3Key);
            } else {
                log.error("Failed to upload file to S3");
            }
            Long cronJobEndTime = System.currentTimeMillis();
            log.info("Cron Job Ran in time" + (cronJobEndTime - cronJobStartTime)/(1000*60) + " minutes");
        } catch (IOException e) {
            log.error("Error generating/uploading firmware details CSV: {}", e.getMessage(), e);
        }
    }



    public void writeFirmwareDetailsToCSV(Map<String, List<ECUFirmwareDetails>> vidToDetailsMap, File file) {
        try (FileWriter writer = new FileWriter(file)) {
            writer.append("vid,ecuId,ecuAbbreviation,ecuName,softwareVersion,hardwareVersion,last_connected_tsp\n");

            for (List<ECUFirmwareDetails> detailsList : vidToDetailsMap.values()) {
                for (ECUFirmwareDetails d : detailsList) {
                    writer.append(String.format("%s,%s,%s,%s,%s,%s,%s\n",
                            safe(d.getVid()),
                            safe(d.getEcuId()),
                            safe(d.getEcuAbbreviation()),
                            safe(d.getEcuName()),
                            safe(d.getSoftwareVersion()),
                            safe(d.getHardwareVersion()),
                            safe(d.getLastConnectedTsp())));
                }
            }

            writer.flush();
            log.info("Firmware details written to CSV at: {}", file.getAbsolutePath());
        } catch (IOException e) {
            log.error("Error writing to CSV: {}", e.getMessage(), e);
        }
    }

    private String safe(String s) {
        return s != null ? s : "";
    }
}