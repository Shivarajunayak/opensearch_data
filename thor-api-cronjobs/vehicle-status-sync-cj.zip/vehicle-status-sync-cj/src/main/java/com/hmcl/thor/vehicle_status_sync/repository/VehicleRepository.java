package com.hmcl.thor.vehicle_status_sync.repository;

import com.hmcl.thor.vehicle_status_sync.entity.Vehicle;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;

public interface VehicleRepository extends JpaRepository<Vehicle, Long> {
    // JPA query to get the list of 'vid' based on the list of 'vin'
    @Query("SELECT v.vid FROM Vehicle v WHERE v.vin IN :vins")
    List<String> findVidsByVins(@Param("vins") List<String> vins);

    @Query("SELECT COUNT(v) FROM Vehicle v WHERE v.thorVehicleModelId = :thorVehicleModelId")
    int countByThorVehicleModelId(@Param("thorVehicleModelId") Long thorVehicleModelId);

    @Query("SELECT COUNT(v) FROM Vehicle v WHERE v.thorVehicleModelId = :thorVehicleModelId AND v.year IN :mfgYears")
    int countByThorVehicleModelIdAndMfgYearIn(@Param("thorVehicleModelId") Long thorVehicleModelId, @Param("mfgYears") List<String> mfgYears);

    @Query(value = "SELECT make FROM vehicle_provisioning.vehicles WHERE thor_vehicle_model_id = :thorVehicleModelId LIMIT 1", nativeQuery = true)
    String findMakeByThorVehicleModelId(@Param("thorVehicleModelId") Long thorVehicleModelId);

    @Override
    List<Vehicle> findAll();
}
