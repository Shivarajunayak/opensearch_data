package com.hmcl.thor.vehicle_status_sync.properties;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class DatabaseProperties {

    private String host;
    private String port;
    private String username;
    private String password;
    private String database;
    private String bootstrapservers;
}
