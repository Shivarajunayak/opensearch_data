package com.hmcl.thor.vehicle_status_sync.config;


import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.hmcl.thor.vehicle_status_sync.properties.DatabaseProperties;
import com.hmcl.thor.vehicle_status_sync.properties.VehicleStatusSyncPropertiesMapper;
import com.hmcl.thor.vehicle_status_sync.service.VehicleStatusSync;
import lombok.Getter;
import lombok.Setter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.io.Resource;

import java.io.IOException;
import java.io.InputStream;
import java.util.Map;

/**
 *
 * Application configuration
 */
@Configuration
@Getter
@Setter
public class ApplicationPropertiesConfig {

    @Value("${vehicle-status-sync.rds}")
    private Resource databaseSecretsFilePath;

    @Value("${vehicle-status-sync.config}")
    private Resource vehicleStatusSyncPropertiesFilePath;

    @Autowired
    private ObjectMapper mapper;

    @Bean
    public DatabaseProperties databaseProperties() throws Exception {
        try {
            Map<String, String> props;
            try (InputStream inputStream = databaseSecretsFilePath.getInputStream()) {
                props = mapper.readValue(inputStream, new TypeReference<Map<String, String>>() {
                });
            }
            DatabaseProperties properties = new DatabaseProperties();
            properties.setHost(props.get("db.host"));
            properties.setPort(String.valueOf(props.get("db.port")));
            properties.setDatabase(props.get("db.database"));
            properties.setUsername(props.get("db.username"));
            properties.setPassword(props.get("db.password"));
            properties.setBootstrapservers(props.get("bootstrapservers"));
            return properties;
        }catch (IOException e){
            throw new IOException("Error reading database properties file : "+e.getMessage(), e);
        }catch (Exception e){
            throw new Exception("Error reading database properties file : "+e.getMessage(), e);
        }
    }

    @Bean
    public VehicleStatusSyncPropertiesMapper vehicleStatusSyncPropertiesMapper() throws Exception {
        try {
            Map<String, String> propertiesMap;
            VehicleStatusSyncPropertiesMapper propertiesMapper = new VehicleStatusSyncPropertiesMapper();
            try (InputStream inputStream = vehicleStatusSyncPropertiesFilePath.getInputStream();) {
                propertiesMap = mapper.readValue(vehicleStatusSyncPropertiesFilePath.getInputStream(), new TypeReference<Map<String, String>>() {});
            }
            propertiesMapper.setOtaBaseUrl(propertiesMap.get("otaBaseUrl"));
            propertiesMapper.setFileMgmtServiceEndpoint(propertiesMap.get("fileMgmtServiceEndpoint"));
            propertiesMapper.setBatchSize(Long.parseLong(propertiesMap.get("batchSize")));
            return propertiesMapper;
        }catch (IOException e) {
            throw new IOException("Error reading vehicle status sync properties file : " + e.getMessage(), e);
        }catch (Exception e) {
            throw new Exception("Error reading vehicle status sync properties file : " + e.getMessage(), e);
        }

    }





}
