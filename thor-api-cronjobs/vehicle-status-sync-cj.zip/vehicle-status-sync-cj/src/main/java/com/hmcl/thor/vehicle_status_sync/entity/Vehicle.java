package com.hmcl.thor.vehicle_status_sync.entity;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity
@Table(name = "Vehicles", schema = "vehicle_provisioning")
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class Vehicle {

    @Id
    private Long id;
    private String vin;
    private String vid;
    private String make;
    private String model;
    private String year;
    private Long thorVehicleModelId;


}
