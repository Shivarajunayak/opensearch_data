package com.hmcl.thor.vehicle_status_sync.dto;

import lombok.Data;

@Data
public class ApiError {
    private String code;
    private String message;
    private String description;

    public ApiError() {}

    public ApiError(String code, String message, String description) {
        this.code = code;
        this.message = message;
        this.description = description;
    }
}
