package com.hmcl.thor.vehicle_status_sync.service;

import com.hmcl.thor.vehicle_status_sync.dto.ApiResponse;
import com.hmcl.thor.vehicle_status_sync.properties.VehicleStatusSyncPropertiesMapper;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.FileSystemResource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.RestClient;

import java.io.File;
import java.net.URI;
import java.util.Collections;

@Slf4j
@Service
public class S3vehicleAuditUploadService {

    private final RestClient restClient;
    private final VehicleStatusSyncPropertiesMapper vehicleStatusSyncPropertiesMapper;


    public S3vehicleAuditUploadService(RestClient.Builder restClientBuilder,
                                    VehicleStatusSyncPropertiesMapper vehicleStatusSyncPropertiesMapper) {
        this.restClient = restClientBuilder.build();
        this.vehicleStatusSyncPropertiesMapper = vehicleStatusSyncPropertiesMapper;
    }

    public String uploadToS3(File vehicleAuditFile) {
        log.info("Uploading file to S3");

        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.MULTIPART_FORM_DATA);
        headers.add("x-fileType", "vehicleAudit");

        MultiValueMap<String, Object> form = new LinkedMultiValueMap<>();
        form.add("file", new FileSystemResource(vehicleAuditFile));

        String url = vehicleStatusSyncPropertiesMapper.getFileMgmtServiceEndpoint() + "/upload";

        try {
            ApiResponse response = restClient.post()
                    .uri(URI.create(url))
                    .headers(h -> h.addAll(headers))
                    .body(form)
                    .retrieve()
                    .body(ApiResponse.class);

            if (response != null) {
                log.info("Object key {}, error {}", response.getData(), response.getErrors());
                return (String) response.getData();
            } else {
                log.error("Failed to upload file to S3. No response from server.");
                return null;
            }
        } catch (Exception e) {
            log.error("Error uploading to S3: ", e);
            return null;
        }
    }

    public void deleteFromS3(String s3ObjectKey) {
        String deleteUrl = vehicleStatusSyncPropertiesMapper.getFileMgmtServiceEndpoint() + "/delete";

        try {
            ResponseEntity<String> response = restClient.method(HttpMethod.POST)
                    .uri(URI.create(deleteUrl))
                    .headers(headers -> {
                        headers.set("x-fileType", "vehicleAudit");
                        headers.set("x-s3ObjectKey", s3ObjectKey);
                        headers.setAccept(Collections.singletonList(MediaType.ALL));
                    })
                    .retrieve()
                    .toEntity(String.class);

            if (response.getStatusCode() == HttpStatus.OK) {
                log.info("File deleted successfully: {}", response.getBody());
            } else {
                log.warn("Unexpected response during file deletion: {}", response);
            }
        } catch (HttpClientErrorException e) {
            log.error("Client error while deleting file from S3", e);
        } catch (Exception ex) {
            log.error("Failed to delete file from S3 during rollback", ex);
        }
    }

    public String getPresignedUrl(String objectKey, String fileType) {
        String url = vehicleStatusSyncPropertiesMapper.getFileMgmtServiceEndpoint() + "/api/v1/file-upload/presigned-url";

        try {
            ApiResponse response = restClient.get()
                    .uri(URI.create(url))
                    .headers(headers -> {
                        headers.add("x-s3ObjectKey", objectKey);
                        headers.add("x-fileType", fileType);
                    })
                    .retrieve()
                    .body(ApiResponse.class);

            if (response != null) {
                log.info("Presigned URL {}, error {}", response.getData(), response.getErrors());
                return (String) response.getData();
            } else {
                log.error("Failed to get presigned URL. No response from server.");
                return null;
            }
        } catch (Exception e) {
            log.error("Error getting presigned URL: ", e);
            return null;
        }
    }
}