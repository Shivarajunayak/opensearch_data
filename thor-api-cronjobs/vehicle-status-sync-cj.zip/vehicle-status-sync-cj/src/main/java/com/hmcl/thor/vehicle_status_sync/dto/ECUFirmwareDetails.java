package com.hmcl.thor.vehicle_status_sync.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class ECUFirmwareDetails {
    private String ecuId;
    private String ecuAbbreviation;
    private String ecuName;
    private String softwareVersion = "";
    private String hardwareVersion;
    private String vid;
    private String lastConnectedTsp;
    
    public void setSoftwareVersion(String softwareVersion) {
    	this.softwareVersion= (softwareVersion==null) ? "" : softwareVersion;
    }
}
