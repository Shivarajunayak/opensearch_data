package com.hmcl.thor.vehicle_status_sync.entity;

import jakarta.persistence.Column;
import jakarta.persistence.EntityListeners;
import jakarta.persistence.MappedSuperclass;
import lombok.Data;
import org.springframework.data.annotation.CreatedBy;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedBy;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

@MappedSuperclass
@Data
public abstract class Auditable<U,D> {

    @CreatedBy
    @Column(updatable = false)
    private U createdBy;
    @CreatedDate
    @Column(updatable = false)
    private D createdTsp;
    @LastModifiedBy
    private U updatedBy;
    @LastModifiedDate
    private D updatedTsp;

    // getters and setter here
}
