package com.hmcl.thor.vehicle_status_sync.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Collections;
import java.util.List;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class ApiResponse<T> {
    private static final String SUCCESS_STATUS = "SUCCESS";

    private String status;
    private String message;
    private T data;
    private List<ApiError> errors;

    public ApiResponse(String status, String message, T data) {
        this(status, message, data, null);
    }

    public ApiResponse(String status, String message) {
        this(status, message, null, null);
    }

    public static <T> ApiResponse<T> success(String message, T data) {
        return new ApiResponse<>(SUCCESS_STATUS, message, data);
    }

    public static <T> ApiResponse<T> success(String message) {
        return new ApiResponse<>(SUCCESS_STATUS, message, null);
    }

    public static <T> ApiResponse<T> error(String message, List<ApiError> errors) {
        return new ApiResponse<>("ERROR", message, null, errors);
    }

    public static <T> ApiResponse<T> errorResponse(String message, String errorDetail) {
        ApiResponse<T> response = new ApiResponse<>();
        response.setStatus("ERROR");
        response.setMessage(message);
        ApiError error = new ApiError("INTERNAL_ERROR", message, errorDetail);
        response.setErrors(Collections.singletonList(error));
        return response;
    }

    // Method to check if the ApiResponse indicates success
    public boolean isSuccess() {
        return SUCCESS_STATUS.equalsIgnoreCase(status);
    }
}