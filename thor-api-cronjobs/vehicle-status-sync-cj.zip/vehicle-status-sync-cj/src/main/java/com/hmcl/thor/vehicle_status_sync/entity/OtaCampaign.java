package com.hmcl.thor.vehicle_status_sync.entity;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.*;

import java.util.List;

@Builder
@Entity
@Data
@AllArgsConstructor
@NoArgsConstructor
@Table(name = "ota_campaign", schema = "ota_datapipeline")
public class OtaCampaign {

    @Id
    private Long id;
    private String status;
    private Long updated_on;
    private Long created_on;
    private String campaign_name;
    private List<Long> vehicle_count;
    private List<String> vehicle_models;
}
