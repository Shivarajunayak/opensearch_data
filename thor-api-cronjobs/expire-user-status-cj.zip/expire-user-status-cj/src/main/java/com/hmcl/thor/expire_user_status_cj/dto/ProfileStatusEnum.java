package com.hmcl.thor.expire_user_status_cj.dto;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonValue;

import java.io.Serializable;

public enum ProfileStatusEnum implements Serializable {
    ACTIVE("Active"),
    EXPIRED("Expired"),
    DELETED("Deleted"),
    UPCOMING("Upcoming");

    private String value;

    private ProfileStatusEnum(String value) {
        this.value = value;
    }

    @JsonValue
    public String getValue() {
        return this.value;
    }

    @Override
    public String toString() {
        return String.valueOf(this.value);
    }

    @JsonCreator
    public static ProfileStatusEnum fromValue(String value) {
        ProfileStatusEnum[] var1 = values();
        int var2 = var1.length;

        for(int var3 = 0; var3 < var2; ++var3) {
            ProfileStatusEnum b = var1[var3];
            if (b.value.equals(value)) {
                return b;
            }
        }

        throw new IllegalArgumentException("Unexpected value '" + value + "'");
    }
}