package com.hmcl.thor.expire_user_status_cj.service;

import com.hmcl.thor.expire_user_status_cj.dto.BatchResult;
import com.hmcl.thor.expire_user_status_cj.dto.CleanupResult;
import com.hmcl.thor.expire_user_status_cj.dto.UserManagementProperties;
import com.hmcl.thor.expire_user_status_cj.dto.UserProfileEntityKeys;
import com.hmcl.thor.expire_user_status_cj.repository.UserManagementSchedulerRepository;

import jakarta.annotation.PostConstruct;
import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.SpringApplication;
import org.springframework.context.ApplicationContext;
import org.springframework.stereotype.Service;

import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

import java.time.Instant;
import java.util.List;

@Service
@Slf4j
public class ExpireUserStatusService {
    private final UserManagementProperties userManagementProperties;
    private final UserManagementSchedulerRepository userManagementSchedulerRepository;
    private final ApplicationContext applicationContext;

    public ExpireUserStatusService(
            UserManagementProperties userManagementProperties,
            UserManagementSchedulerRepository userManagementSchedulerRepository,
            ApplicationContext applicationContext) {
        this.userManagementProperties = userManagementProperties;
        this.userManagementSchedulerRepository = userManagementSchedulerRepository;
        this.applicationContext = applicationContext;
    }

    @PostConstruct
    public void onStartup() {
        updateExpiredStatusRecordsInBatches()
                .subscribe(
                        result -> {
                            log.info("Startup expired status update result: {}", result);
                            int exitCode = SpringApplication.exit(applicationContext, () -> 0);
                            System.exit(exitCode);
                        },
                        error -> {
                            log.error("Error during startup expired status update", error);
                            int exitCode = SpringApplication.exit(applicationContext, () -> 1);
                            System.exit(exitCode);
                        }
                );
    }

    public Mono<CleanupResult> updateExpiredStatusRecordsInBatches() {
        long currentTimestamp = Instant.now().toEpochMilli();
        return userManagementSchedulerRepository.countExpiredSecondaryUsers(currentTimestamp)
                .flatMap(totalRecords -> {
                    log.info("Found {} expired secondary user records to process.", totalRecords);
                    return Flux.defer(() -> fetchAndProcessNextBatch(currentTimestamp))
                            .expand(result -> {
                                if (result.getProcessedCount() == Integer.parseInt(userManagementProperties.getExpiredStatusUpdateBatchSize())) {
                                    return fetchAndProcessNextBatch(currentTimestamp);
                                }
                                return Mono.empty();
                            })
                            .flatMap(Mono::just, 10) // limit concurrency to 10
                            .reduce(new CleanupResult(0L, totalRecords), this::combineResults);
                })
                .doOnSuccess(result -> log.info("Expired status update completed successfully: {}", result))
                .doOnError(error -> log.error("Error during updating the status to expired", error));
    }

    private Mono<CleanupResult> processExpiredUsersInBatches(long currentTimestamp, long totalRecords) {
        return Flux.defer(() -> fetchAndProcessNextBatch(currentTimestamp))
                .expand(result -> {
                    if (result.getProcessedCount() == Integer.parseInt(userManagementProperties.getExpiredStatusUpdateBatchSize())) {
                        return fetchAndProcessNextBatch(currentTimestamp);
                    }
                    return Mono.empty();
                })
                .reduce(new CleanupResult(0L, totalRecords), this::combineResults);
    }

    private Mono<BatchResult> fetchAndProcessNextBatch(long currentTimestamp) {
        return userManagementSchedulerRepository.findExpiredSecondaryUsers(
                        currentTimestamp,
                        Integer.parseInt(userManagementProperties.getExpiredStatusUpdateBatchSize())
                )
                .next()
                .filter(users -> !users.isEmpty())
                .flatMap(users -> {
                    List<UserProfileEntityKeys> userKeys = users.stream()
                            .map(user -> new UserProfileEntityKeys(user.getVid(), user.getProfileId(), user.getPrimaryProfileId()))
                            .toList();
                    return userManagementSchedulerRepository.updateProfileStatusToExpired(userKeys)
                            .map(BatchResult::new);
                });
    }

    private CleanupResult combineResults(CleanupResult acc, BatchResult current) {
        return new CleanupResult(
                acc.getProcessedCount() + current.getProcessedCount(),
                acc.getTotalRecords()
        );
    }
}