package com.hmcl.thor.expire_user_status_cj.dto;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class CleanupResult {
        private long processedCount;
        private long totalRecords;
}
