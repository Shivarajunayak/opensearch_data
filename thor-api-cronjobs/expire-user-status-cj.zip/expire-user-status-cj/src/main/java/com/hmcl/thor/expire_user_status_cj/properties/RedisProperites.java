package com.hmcl.thor.expire_user_status_cj.properties;

import lombok.Data;
import org.springframework.stereotype.Component;

@Component
@Data
public class RedisProperites {

    private String redisHostname;
    private String redisPort;
    private String redisUser;
    private String redisAuthToken;
    private String redisTimeout;
    private String ttlMinutes;
    private Integer maxActive;
    private Integer maxIdle;
    private Integer minIdle;
    private String mode;
    private String maxRedirects;
    private String nodes;
    private String ssl;
}
