package com.hmcl.thor.expire_user_status_cj.config;


import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.hmcl.thor.expire_user_status_cj.dto.UserManagementProperties;

import com.hmcl.thor.expire_user_status_cj.properties.RedisProperites;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.io.Resource;

import java.io.InputStream;
import java.util.Map;

/**
 *
 * Application configuration
 */
@Configuration
@Slf4j
public class ApplicationPropertiesConfig {



    @Autowired
    private ObjectMapper mapper;

    @Value("${expire-user-status-cj.config}")
    private Resource userManagementSecretFiles;

//    @Value("${redis.volume.mount}")
//    private Resource redisSecretsFile;

    @Bean
    public UserManagementProperties userManagementProperties() throws Exception{

        Map<String, String> props;
        try(InputStream inputStream = userManagementSecretFiles.getInputStream()){
            props = mapper.readValue(inputStream, new TypeReference<Map<String, String>>() {});
        }

        UserManagementProperties properties = new UserManagementProperties();
        properties.setActivateUserBatchSize(props.get("activateUserBatchSize"));
        properties.setRegion(props.get("region"));
        properties.setDdbEndpoint(props.get("ddbEndpoint"));
        properties.setDdbCustPrefTable(props.get("ddbCustPrefTable"));
        properties.setExpiredStatusUpdateBatchSize(props.get("expiredStatusUpdateBatchSize"));
        return properties;
    }

//    @Bean
//    public RedisProperites redisProperites() throws Exception{
//        Map<String,String> props;
//        try(InputStream inputStream = redisSecretsFile.getInputStream()){
//            props = mapper.readValue(inputStream, new TypeReference<Map<String, String>>() {});
//        }
//        RedisProperites properties = new RedisProperites();
//        properties.setRedisUser(props.get("redis.user"));
//        properties.setRedisHostname(props.get("redis.host"));
//        properties.setRedisPort(props.get("redis.port"));
//        properties.setRedisAuthToken(props.get("redis.auth.token"));
//        properties.setRedisTimeout(props.get("redis.timeout"));
//        properties.setTtlMinutes(props.get("redis.ttlMinutes"));
//        properties.setMaxActive(Integer.parseInt(props.getOrDefault("redis.maxConnections","100")));
//        properties.setMaxIdle(Integer.parseInt(props.getOrDefault("redis.maxIdle","60")));
//        properties.setMinIdle(Integer.parseInt(props.getOrDefault("redis.minIdle","5")));
//        properties.setMode(props.get("redis.mode"));
//        properties.setNodes(props.get("redis.nodes"));
//        properties.setSsl(props.get("redis.ssl"));
//        properties.setMaxRedirects(props.get("redis.maxRedirects"));
//        log.info("Loading redis properties...............");
//        return properties;
//    }

}
