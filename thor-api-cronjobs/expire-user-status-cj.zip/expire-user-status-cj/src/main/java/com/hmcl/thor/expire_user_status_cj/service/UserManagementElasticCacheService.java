//package com.hmcl.thor.expire_user_status_cj.service;
//
//
//import com.hmcl.thor.expire_user_status_cj.dto.UserProfile;
//import com.hmcl.thor.expire_user_status_cj.repository.UserManagementElasticCacheDAO;
//import lombok.AllArgsConstructor;
//import org.springframework.stereotype.Service;
//
//import java.util.Collections;
//import java.util.List;
//import java.util.Optional;
//
//@Service
//@AllArgsConstructor
//public class UserManagementElasticCacheService {
//
//    private final UserManagementElasticCacheDAO userManagementElasticCacheDAO;
//
//
//
//
//
//
//
//
//
//    public void removeVid(String vid) {
//        userManagementElasticCacheDAO.removeVid(vid);
//    }
//
//    public void removeAllUserManagementKeys() {
//        userManagementElasticCacheDAO.removeAllUserManagementKeys();
//    }
//
//
//
//
//
//
//
//}
