package com.hmcl.thor.expire_user_status_cj;


import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication(scanBasePackages  = "com.hmcl.thor")
public class ExpireUserStatus {

	public static void main(String[] args) {
		SpringApplication.run(ExpireUserStatus.class, args);
	}

}
