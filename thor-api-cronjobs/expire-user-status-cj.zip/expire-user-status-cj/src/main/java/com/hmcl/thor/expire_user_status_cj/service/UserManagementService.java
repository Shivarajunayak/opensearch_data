package com.hmcl.thor.expire_user_status_cj.service;

import com.fasterxml.jackson.databind.JsonNode;
import com.hmcl.thor.expire_user_status_cj.dto.UserManagementProperties;
import com.hmcl.thor.expire_user_status_cj.dto.UserProfile;

import com.hmcl.thor.expire_user_status_cj.mapper.UserProfileMapper;
import lombok.extern.slf4j.Slf4j;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;
import software.amazon.awssdk.services.dynamodb.DynamoDbAsyncClient;
import software.amazon.awssdk.services.dynamodb.model.*;

import java.time.Instant;
import java.time.ZonedDateTime;
import java.util.*;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutionException;



import static com.hmcl.thor.expire_user_status_cj.util.ApplicationConstants.PROFILE_ID;
import static com.hmcl.thor.expire_user_status_cj.util.ApplicationConstants.VID;

@Component
@Slf4j
public class UserManagementService {

    private static final Logger logger = LoggerFactory.getLogger(UserManagementService.class);

    private final DynamoDbAsyncClient dynamoDbAsyncClient;
    private final String custPreferenceTable;
//    private final UserManagementElasticCacheService userManagementElasticCacheService;
    private final UserProfileMapper userProfileMapper;
    private final UserManagementProperties properties;
    /**
     *  Constructor to create or assign the objects and values
     * @param dynamoDbAsyncClient
     * @param properties
     * @param userManagementElasticCacheService
     */
    public UserManagementService(DynamoDbAsyncClient dynamoDbAsyncClient, UserManagementProperties properties, UserProfileMapper userProfileMapper) {
        this.dynamoDbAsyncClient = dynamoDbAsyncClient;
        this.custPreferenceTable = properties.getDdbCustPrefTable();
//        this.userManagementElasticCacheService = userManagementElasticCacheService;
        this.userProfileMapper = userProfileMapper;
        this.properties = properties;

    }

    private void updateItem(UserProfile userProfileOld) throws ExecutionException, InterruptedException {
        HashMap<String, AttributeValue> keyToUpdate = new HashMap<>();
        keyToUpdate.put(VID, AttributeValue.builder().s(userProfileOld.getVid()).build());
        keyToUpdate.put(PROFILE_ID, AttributeValue.builder().s(userProfileOld.getProfileId()).build());

        UpdateItemRequest updateItemRequest = UpdateItemRequest.builder()
                .tableName(custPreferenceTable)
                .key(keyToUpdate)
                .attributeUpdates(userProfileMapper.toUpdateMap(userProfileOld))
                .build();
        CompletableFuture<UpdateItemResponse> updateItemResponse = dynamoDbAsyncClient.updateItem(updateItemRequest);
        updateItemResponse.get();
    }
    public void updateIsRiderForPrimaryProfile(UserProfile currentProfile) throws ExecutionException, InterruptedException {
        if(Boolean.FALSE.equals(currentProfile.getIsRider())){
            //update isRider to true for primary profile, if primary profile isRider is false
            currentProfile.setIsRider(true);
            updateItem(currentProfile);
        }
    }


    public UserProfile userProfileByVidAndProfileId(String vid, String profileId, boolean cacheFlag) throws ExecutionException, InterruptedException {
        UserProfile profile = userProfileByVidAndProfileIdEncrypted(vid, profileId, cacheFlag);
        if (profile != null)
            return profile;
        return null;
    }

    private UserProfile userProfileByVidAndProfileIdEncrypted(String vid, String profileId, boolean cacheFlag) throws ExecutionException, InterruptedException {

        logger.info("UserManagementService userProfileByVidAndProfileId method called");
        //getting from cache
        UserProfile profileByProfileId = null;

            //getting from DDB
        HashMap<String, AttributeValue> keyToGet = new HashMap<>();
        keyToGet.put(VID, AttributeValue.builder().s(vid).build());
        keyToGet.put(PROFILE_ID, AttributeValue.builder().s(profileId).build());
        GetItemRequest request = GetItemRequest.builder().key(keyToGet).tableName(custPreferenceTable).build();
        CompletableFuture<GetItemResponse> getItemResponse = dynamoDbAsyncClient.getItem(request);
        getItemResponse.get();
        Map<String, AttributeValue> allItems = getItemResponse.join().item();
        if (!allItems.isEmpty()) {
            profileByProfileId = UserProfileMapper.fromMap(allItems);
        }

        //Add profiles to redis cache
        return profileByProfileId;
    }


}