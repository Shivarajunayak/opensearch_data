//package com.hmcl.thor.expire_user_status_cj.repository;
//
//
////import com.hmcl.thor.expire_user_status_cj.config.RedisConfig;
//import com.hmcl.thor.expire_user_status_cj.dto.UserProfile;
//import lombok.AllArgsConstructor;
//import org.slf4j.Logger;
//import org.slf4j.LoggerFactory;
//import org.springframework.data.redis.core.RedisTemplate;
//import org.springframework.stereotype.Repository;
//
//import java.time.Duration;
//import java.util.Collections;
//import java.util.List;
//import java.util.Objects;
//import java.util.Set;
//
//@Repository
//@AllArgsConstructor
//public class UserManagementElasticCacheDAO {
//
//    private RedisTemplate<String,List<String>> vidTemplate;
//    private RedisTemplate<String, UserProfile> profileTemplate;
//    private static final String USER_MANAGEMENT_HASH = "UM_";
//    private static final String VID_HASH = USER_MANAGEMENT_HASH + "VID_";
//    private static final String PROFILE_HASH = USER_MANAGEMENT_HASH + "PROFILE_";
//    private static final String USER_PROFILE_SUMMARY_HASH = USER_MANAGEMENT_HASH + "PROFILE_SUMMARY_";
//    private static final Logger logger = LoggerFactory.getLogger(UserManagementElasticCacheDAO.class);
////    private final RedisConfig redisConfig;
//
//    public void addVehicleAndProfiles(String vid, List<UserProfile> profiles){
//        logger.info("UserManagementElasticCacheDAO addVehicleAndProfiles Method called");
//
//        if(profiles != null) {
//            List<String> listProfileIds = profiles.stream().map(profile -> {
//            addProfile(profile);
//            return profile.getProfileId();
//        }).toList();
//
//            addVehicle(vid, listProfileIds);
//        }
//    }
//    public void addVehicle(String vid, List<String> profileIds) {
//        vidTemplate.opsForValue().set(VID_HASH + vid, profileIds, Duration.ofMinutes(redisConfig.getTTL()));
//    }
//
//    public void addProfile(UserProfile profile) {
//        String profileIdKey = PROFILE_HASH + profile.getVid() + "~" + profile.getProfileId();
//        profileTemplate.opsForValue().set(profileIdKey, profile, Duration.ofMinutes(redisConfig.getTTL()));
//    }
//
//    public UserProfile findByProfileId(String profileId) {
//        logger.info("UserManagementElasticCacheDAO findByProfileId Method called");
//
//        return profileTemplate.opsForValue().get(profileId);
//    }
//
//    public UserProfile findByProfileIdAndVid(String vid, String profileId) {
//        logger.info("UserManagementElasticCacheDAO findByProfileIdAndVid Method called");
//        String profileIdKey = PROFILE_HASH + vid + "~" + profileId;
//        return profileTemplate.opsForValue().get(profileIdKey);
//    }
//
//    public UserProfile findByPhoneNumber(String phoneNumber) {
//        logger.info("UserManagementElasticCacheDAO findByPhoneNumber Method called");
//
//        return profileTemplate.opsForValue().get(phoneNumber);
//    }
//
//    public List<UserProfile> findAllProfilesByVid(String vid) {
//        logger.info("UserManagementElasticCacheDAO findAllProfilesByVid Method called");
//
//        List<UserProfile> profiles = null;
//        List<String> profileIds = vidTemplate.opsForValue().get(VID_HASH + vid);
//        if(profileIds != null && !profileIds.isEmpty()) {
//            profiles =  profileIds.stream().map(profileId -> {
//                String profileIdKey = PROFILE_HASH + vid + "~" + profileId;
//                return profileTemplate.opsForValue().get(profileIdKey);
//            }).toList();
//        }
//        if(profiles != null && profiles.stream().anyMatch(Objects::isNull)) {
//            removeVid(vid);
//            return Collections.emptyList();
//        }
//        return profiles;
//    }
//
//    public void removeVid(String vid) {
//        logger.info("UserManagementElasticCacheDAO removeVid Method called");
//
//        List<String> profileIds = vidTemplate.opsForValue().get(VID_HASH + vid);
//        if (profileIds != null && !profileIds.isEmpty()) {
//            profileIds.forEach(profileId -> {
//                String profileIdKey = PROFILE_HASH + vid + "~" + profileId;
//                profileTemplate.delete(profileIdKey);
//            });
//            vidTemplate.delete(VID_HASH + vid);
//        }
//    }
//
//    public void removeAllUserManagementKeys() {
//        logger.info("UserManagementElasticCacheDAO removeAllUserManagementKeys Method called");
//        Set<String> keys = vidTemplate.keys(USER_MANAGEMENT_HASH + "*");
//        if (keys != null)
//            keys.forEach(key -> vidTemplate.delete(key));
//    }
//
//
//
//}
//
