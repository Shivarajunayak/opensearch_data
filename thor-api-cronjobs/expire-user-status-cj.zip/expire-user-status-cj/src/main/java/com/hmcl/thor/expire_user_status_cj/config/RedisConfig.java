//package com.hmcl.thor.expire_user_status_cj.config;
//
//import com.fasterxml.jackson.databind.ObjectMapper;
//import com.fasterxml.jackson.databind.type.TypeFactory;
//
//import com.hmcl.thor.expire_user_status_cj.dto.UserProfile;
//import com.hmcl.thor.expire_user_status_cj.properties.RedisProperites;
//import io.lettuce.core.ClientOptions;
//import io.lettuce.core.resource.ClientResources;
//import io.lettuce.core.resource.DefaultClientResources;
//import lombok.AllArgsConstructor;
//import lombok.extern.slf4j.Slf4j;
//import org.apache.commons.pool2.impl.GenericObjectPoolConfig;
//import org.springframework.context.annotation.Bean;
//import org.springframework.context.annotation.Configuration;
//import org.springframework.data.redis.connection.RedisClusterConfiguration;
//import org.springframework.data.redis.connection.RedisConnectionFactory;
//import org.springframework.data.redis.connection.RedisPassword;
//import org.springframework.data.redis.connection.RedisStandaloneConfiguration;
//import org.springframework.data.redis.connection.lettuce.LettuceClientConfiguration;
//import org.springframework.data.redis.connection.lettuce.LettuceConnectionFactory;
//import org.springframework.data.redis.connection.lettuce.LettucePoolingClientConfiguration;
//import org.springframework.data.redis.core.RedisTemplate;
//import org.springframework.data.redis.serializer.Jackson2JsonRedisSerializer;
//import org.springframework.data.redis.serializer.StringRedisSerializer;
//
//import java.time.Duration;
//import java.util.Arrays;
//import java.util.List;
//
//@Configuration
//@AllArgsConstructor
//@Slf4j
//public class RedisConfig {
//
//    private RedisProperites redisProperties;
//
//    @Bean(destroyMethod = "shutdown")
//    public ClientResources clientResources() {
//        return DefaultClientResources.create();
//    }
//
//    @Bean
//    public LettuceConnectionFactory redisConnectionFactory() {
//        GenericObjectPoolConfig<Object> poolConfig = new GenericObjectPoolConfig<>();
//        poolConfig.setMaxTotal(redisProperties.getMaxActive());  // Max connections
//        poolConfig.setMaxIdle(redisProperties.getMaxIdle());
//        poolConfig.setMinIdle(redisProperties.getMinIdle());
//        RedisStandaloneConfiguration redisConfig = new RedisStandaloneConfiguration();
//        redisConfig.setHostName(redisProperties.getRedisHostname());
//        redisConfig.setPort(Integer.parseInt(redisProperties.getRedisPort()));
//        redisConfig.setPassword(RedisPassword.of(redisProperties.getRedisAuthToken()));
//        LettuceClientConfiguration clientConfig = LettucePoolingClientConfiguration.builder()
//                .commandTimeout(Duration.ofSeconds(Long.parseLong(redisProperties.getRedisTimeout())))
//                .poolConfig(poolConfig)
//                .clientOptions(ClientOptions.builder().build())
//                .useSsl()
//                .build();
//        if (redisProperties.getMode().equalsIgnoreCase("cluster")) {
//            log.info("Creating Redis Cluster ConnectionFactory");
//            List<String> nodes = Arrays.asList(redisProperties.getNodes().split(","));
//            RedisClusterConfiguration clusterConfig = new RedisClusterConfiguration(nodes);
//            if (!redisProperties.getRedisAuthToken().isEmpty()) {
//                clusterConfig.setPassword(redisProperties.getRedisAuthToken());
//            }
//            clusterConfig.setMaxRedirects(Integer.parseInt(redisProperties.getMaxRedirects()));
//            return Boolean.parseBoolean(redisProperties.getSsl()) ?  new LettuceConnectionFactory(clusterConfig, clientConfig) : new LettuceConnectionFactory(clusterConfig);
//
//        } else {
//            log.info("Creating Redis Standalone ConnectionFactory");
//            RedisStandaloneConfiguration standaloneConfig = new RedisStandaloneConfiguration(
//                    redisProperties.getRedisHostname(), Integer.parseInt(redisProperties.getRedisPort()));
//            if (!redisProperties.getRedisAuthToken().isEmpty()) {
//                standaloneConfig.setPassword(RedisPassword.of(redisProperties.getRedisAuthToken()));
//            }
//            return Boolean.parseBoolean(redisProperties.getSsl()) ?  new LettuceConnectionFactory(standaloneConfig, clientConfig) : new LettuceConnectionFactory(standaloneConfig);
//        }
//    }
//
//    @Bean
//    public RedisTemplate<String, List<String>> listRedisTemplate(RedisConnectionFactory redisConnectionFactory) {
//        RedisTemplate<String, List<String>> template = new RedisTemplate<>();
//        template.setConnectionFactory(redisConnectionFactory);
//
//        ObjectMapper objectMapper = new ObjectMapper();
//        TypeFactory typeFactory = objectMapper.getTypeFactory();
//        Jackson2JsonRedisSerializer<List<String >> serializer = new Jackson2JsonRedisSerializer<>(typeFactory.constructCollectionType(List.class,String.class));
//        template.setValueSerializer(serializer);
//
//        // Use StringRedisSerializer for the key serializer
//        template.setKeySerializer(new StringRedisSerializer());
//        return template;
//    }
//
//
//    @Bean
//    public RedisTemplate<String, UserProfile> userProfileRedisTemplate(RedisConnectionFactory redisConnectionFactory) {
//        RedisTemplate<String, UserProfile> template = new RedisTemplate<>();
//        template.setConnectionFactory(redisConnectionFactory);
//
//        // Use Jackson2JsonRedisSerializer for the value serializer
//        Jackson2JsonRedisSerializer<UserProfile> serializer = new Jackson2JsonRedisSerializer<>(UserProfile.class);
//        template.setValueSerializer(serializer);
//
//        // Use StringRedisSerializer for the key serializer
//        template.setKeySerializer(new StringRedisSerializer());
//        return template;
//    }
//
//
//
//    public int getTTL() {
//        return Integer.parseInt(redisProperties.getTtlMinutes());
//    }
//
//}