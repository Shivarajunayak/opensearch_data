package com.hmcl.thor.expire_user_status_cj.dto;


import java.io.Serializable;

public class PreferredNotificationChannel implements Serializable {
    private PreferredNotificationEnum channel;


    public PreferredNotificationChannel(PreferredNotificationEnum channel) {
        this.channel = channel;
    }

    public PreferredNotificationChannel() {

    }

    public PreferredNotificationEnum getChannel() {
        return channel;
    }

    public void setChannel(PreferredNotificationEnum channel) {
        this.channel = channel;
    }

}