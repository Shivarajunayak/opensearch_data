package com.hmcl.thor.expire_user_status_cj.dto;

import lombok.*;

@AllArgsConstructor
@NoArgsConstructor
@Setter
@Getter
@ToString
public class UserProfileEntityKeys {
    private String vid;
    private String profileId;
    private String primaryProfileId;
}
