package com.hmcl.thor.expire_user_status_cj.repository;

import com.hmcl.thor.expire_user_status_cj.dto.*;
import com.hmcl.thor.expire_user_status_cj.exceptions.UnknownException;
import com.hmcl.thor.expire_user_status_cj.service.UserManagementService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Repository;
import reactor.core.publisher.Mono;
import software.amazon.awssdk.services.dynamodb.DynamoDbAsyncClient;
import software.amazon.awssdk.services.dynamodb.model.*;
import reactor.core.publisher.Flux;

import java.util.List;
import java.util.Map;
import java.util.concurrent.ExecutionException;
import java.util.stream.Collectors;

import static com.hmcl.thor.expire_user_status_cj.dto.ProfileTypeEnum.SECONDARY;
import static com.hmcl.thor.expire_user_status_cj.util.ApplicationConstants.*;

@Repository
@Slf4j
public class UserManagementSchedulerRepository {
    private final DynamoDbAsyncClient dynamoDbAsyncClient;
    private final String custPreferenceTable;
    private final UserManagementService userManagementService;




    public UserManagementSchedulerRepository(UserManagementProperties userManagementProperties, DynamoDbAsyncClient dynamoDbAsyncClient, UserManagementService userManagementService) {
        this.dynamoDbAsyncClient = dynamoDbAsyncClient;
        this.custPreferenceTable = userManagementProperties.getDdbCustPrefTable();
        this.userManagementService = userManagementService;
    }

    public Mono<Long> countExpiredSecondaryUsers(long currentTimestamp) {
        ScanRequest scanRequest = ScanRequest.builder()
                .tableName(custPreferenceTable)
                .filterExpression("profileType = :secondary AND profileStatus = :active AND accessValidTillTsp < :currentTimestamp")
                .expressionAttributeValues(Map.of(
                        ":secondary", AttributeValue.builder().s(SECONDARY.getValue()).build(),
                        ":active", AttributeValue.builder().s(ProfileStatusEnum.ACTIVE.getValue()).build(),
                        ":currentTimestamp", AttributeValue.builder().n(String.valueOf(currentTimestamp)).build()
                ))
                .build();
        return Mono.fromFuture(() -> dynamoDbAsyncClient.scan(scanRequest))
                .map(ScanResponse::count)
                .map(Long::valueOf)
                .onErrorResume(ex -> {
                    log.error("Error counting expired secondary users", ex);
                    return Mono.just(0L);
                });
    }

    private Flux<UserProfileEntity> scanWithPagination(ScanRequest initialScanRequest) {
        return Flux.create(sink -> {
            final ScanRequest[] currentRequest = {initialScanRequest};
            // Recursive function to handle pagination
            Mono.defer(() -> Mono.fromFuture(() -> dynamoDbAsyncClient.scan(currentRequest[0])))
                    .repeat()
                    .doOnNext(response -> {
                        response.items().forEach(item -> sink.next(mapToEntity(item)));
                        if (response.lastEvaluatedKey() == null || response.lastEvaluatedKey().isEmpty()) {
                            sink.complete();
                        } else {
                            currentRequest[0] = currentRequest[0].toBuilder()
                                    .exclusiveStartKey(response.lastEvaluatedKey())
                                    .build();
                        }
                    })
                    .doOnError(sink::error)
                    .subscribe();
        });
    }


    public Flux<List<UserProfileEntity>> findExpiredSecondaryUsers(long currentTimestamp, int batchSize) {
        ScanRequest scanRequest = ScanRequest.builder()
                .tableName(custPreferenceTable)
                .filterExpression("profileType = :secondary AND profileStatus = :active AND accessValidTillTsp < :currentTimestamp")
                .expressionAttributeValues(Map.of(
                        ":secondary", AttributeValue.builder().s(SECONDARY.getValue()).build(),
                        ":active", AttributeValue.builder().s(ProfileStatusEnum.ACTIVE.getValue()).build(),
                        ":currentTimestamp", AttributeValue.builder().n(String.valueOf(currentTimestamp)).build()
                ))
                .limit(batchSize)
                .build();
        return scanWithPagination(scanRequest).buffer(batchSize);
    }

    public Mono<Integer> updateProfileStatusToExpired(List<UserProfileEntityKeys> keys) {
        log.info("Starting updateProfileStatusToExpired for {} keys", keys.size());
        return Flux.fromIterable(keys)
                .flatMap(key -> {
                    log.debug("Processing key: {}", key);
                    if (key.getVid() == null || key.getVid().isEmpty() ||
                            key.getProfileId() == null || key.getProfileId().isEmpty()) {
                        log.warn("Skipping update due to missing vid or profileId: {}", key);
                        return Mono.empty();
                    }
                    Map<String, AttributeValue> itemKey = Map.of(
                            "vid", AttributeValue.builder().s(key.getVid()).build(),
                            "profileId", AttributeValue.builder().s(key.getProfileId()).build()
                    );

                    // update primary profile isRider Flag to true
                    UserProfile primaryUserProfile = null;
                    if (key.getVid() == null || key.getPrimaryProfileId() == null || key.getProfileId() == null) {
                        log.warn("Skipping update due to missing primary profile information for VID: {}", key.getVid());
                        return Mono.empty();
                    }
                    try {
                        log.debug("Fetching primary user profile for vid: {}, primaryProfileId: {}", key.getVid(), key.getPrimaryProfileId());
                        primaryUserProfile = userManagementService.userProfileByVidAndProfileId(key.getVid(), key.getPrimaryProfileId(), false);
                        if (primaryUserProfile != null) {
                            log.debug("Updating isRider for primary profile: {}", primaryUserProfile);
                            userManagementService.updateIsRiderForPrimaryProfile(primaryUserProfile);
                            log.info("Updated isRider to true for primary profile vid: {}, profileId: {}", key.getVid(), key.getPrimaryProfileId());
                        } else {
                            log.info("Primary user profile not found for vid: {}, primaryProfileId: {}", key.getVid(), key.getPrimaryProfileId());
                        }
                    } catch (InterruptedException | ExecutionException ex) {
                        log.error("Exception while updating isRider for primary profile vid: {}, primaryProfileId: {}", key.getVid(), key.getPrimaryProfileId(), ex);
                        Thread.currentThread().interrupt();
                        throw new UnknownException(ex.getMessage());
                    }
                    // update secondary profile isRider Flag to false and profile status to expired
                    Map<String, AttributeValue> updatedAttributes = Map.of(
                            "profileStatus", AttributeValue.builder().s(ProfileStatusEnum.EXPIRED.getValue()).build(),
                            "isRider", AttributeValue.builder().bool(false).build()
                    );

                    UpdateItemRequest updateRequest = UpdateItemRequest.builder()
                            .tableName(custPreferenceTable)
                            .key(itemKey)
                            .attributeUpdates(updatedAttributes.entrySet().stream()
                                    .collect(Collectors.toMap(
                                            Map.Entry::getKey,
                                            entry -> AttributeValueUpdate.builder()
                                                    .value(entry.getValue())
                                                    .action(AttributeAction.PUT)
                                                    .build()
                                    )))
                            .build();

                    log.debug("Sending update request for secondary profile: {}", updateRequest);

                    return Mono.fromFuture(() -> dynamoDbAsyncClient.updateItem(updateRequest))
                            .doOnSuccess(response -> {
                                log.info("Updated profile status to EXPIRED and isRider to false for VID: {}, profileId: {}", key.getVid(), key.getProfileId());
                            })
                            .doOnError(e -> {
                                log.error("Error updating profile status for key: {}", key, e);
                            });
                })
                .count()
                .map(Long::intValue)
                .doOnSuccess(count -> log.info("Successfully updated {} profiles to EXPIRED", count))
                .onErrorResume(e -> {
                    log.error("Error processing profile status updates", e);
                    return Mono.just(0);
                });
    }


    private UserProfileEntity mapToEntity(Map<String, AttributeValue> item) {
        return UserProfileEntity.builder()
                .vid(item.get(VID) != null ? item.get(VID).s() : null)
                .profileId(item.get(PROFILE_ID) != null ? item.get(PROFILE_ID).s() : null)
                .profileType(item.get(PROFILE_TYPE) != null ? item.get(PROFILE_TYPE).s() : null)
                .profileStatus(item.get(PROFILE_STATUS) != null ? item.get(PROFILE_STATUS).s() : null)
                .accessValidTillTsp(item.get(ACCESS_VALID_TILL_TSP) != null ? Long.parseLong(item.get(ACCESS_VALID_TILL_TSP).n()) : null)
                .primaryProfileId(item.get(PRIMARY_PROFILE_ID) != null ? item.get(PRIMARY_PROFILE_ID).s() : null)
                .build();
    }


    public Mono<Long> countInactiveSecondaryUsers(long currentTimestamp) {
        ScanRequest scanRequest = ScanRequest.builder()
                .tableName(custPreferenceTable)
                .filterExpression("profileType = :secondary AND profileStatus = :upcoming AND accessValidFromTsp <= :currentTimestamp")
                .expressionAttributeValues(Map.of(
                        ":secondary", AttributeValue.builder().s(SECONDARY.getValue()).build(),
                        ":upcoming", AttributeValue.builder().s(ProfileStatusEnum.UPCOMING.getValue()).build(),
                        ":currentTimestamp", AttributeValue.builder().n(String.valueOf(currentTimestamp)).build()
                ))
                .build();
        return Mono.fromFuture(() -> dynamoDbAsyncClient.scan(scanRequest))
                .map(ScanResponse::count)
                .map(Long::valueOf)
                .onErrorResume(ex -> {
                    log.error("Error counting inactive secondary users", ex);
                    return Mono.just(0L);
                });
    }

    public Flux<List<UserProfileEntity>> findInactiveSecondaryUsers(long currentTimestamp, int batchSize) {
        ScanRequest scanRequest = ScanRequest.builder()
                .tableName(custPreferenceTable)
                .filterExpression("profileType = :secondary AND profileStatus = :upcoming AND accessValidFromTsp <= :currentTimestamp")
                .expressionAttributeValues(Map.of(
                        ":secondary", AttributeValue.builder().s(SECONDARY.getValue()).build(),
                        ":upcoming", AttributeValue.builder().s(ProfileStatusEnum.UPCOMING.getValue()).build(),
                        ":currentTimestamp", AttributeValue.builder().n(String.valueOf(currentTimestamp)).build()
                ))
                .limit(batchSize)
                .build();
        return scanWithPagination(scanRequest).buffer(batchSize);
    }



}