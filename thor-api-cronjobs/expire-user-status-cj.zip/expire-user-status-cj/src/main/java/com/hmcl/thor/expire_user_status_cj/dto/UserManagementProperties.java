package com.hmcl.thor.expire_user_status_cj.dto;

import lombok.Getter;
import lombok.Setter;
import org.springframework.stereotype.Component;

@Component
@Getter
@Setter
public class UserManagementProperties {
    private String consumerGroup;
    private String userManagementTopic;
    private String mskBroker;
    private String region;
    private String ddbEndpoint;
    private String ddbCustPrefTable;
    private String customRideProfileTable;
    private String geoFenceAlertCode;
    private String masterFeaturesURL;
    private String maxActiveSecondaryProfilesPerVid;
    private String cncBaseURL;
    private String commandHistoryByVidURL;
    private String commandHistoryByVidAndProfileIdURL;
    private String notificationBaseURL;
    private String notificationHistoryByVidURL;
    private String notificationHistoryByVidAndProfileIdURL;
    private String bleCommandTopic;
    private String cncCustomRideModeApiURL;
    private String customRideModeKafkaCommandCode;
    private String defaultSpeedGetUrl;
    private String commandStatusTopic;
    private String overSpeedCommandCode;
    private String commandStatusConsumerGroup;
    private int maxCoordinatesInPolygonOfGeoFence;
    private int maxDistanceBetweenTwoCoordinatesOfGeoFence;
    private int maxRadiusOfCircleAllowedForGeoFenceInKilometer;
    private String kmsKeyForPIIData;
    private String authValidateUrl;
    private String dataPermissionKey;
    private String secretStringForMaskedPhone;
    private String overSpeedLimitFeatureCode;
    private int geoFenceCircleRadiusMetreMaxValue;
    private String authLogoutEndpoint;
    private int maxGeoFencesPerProfile;
    private String expiredStatusUpdateCronExpression;
    private String expiredStatusUpdateBatchSize;
    private String activateUserCronExpression;
    private String activateUserBatchSize;
    private int minDistanceForGeoFenceInMeter;
    private double minDistanceForGeoFenceInKilometer;
    private long cncCustomRideModeCommandExecutionTimeout;
    private String kmsKeyPostgres;
}

