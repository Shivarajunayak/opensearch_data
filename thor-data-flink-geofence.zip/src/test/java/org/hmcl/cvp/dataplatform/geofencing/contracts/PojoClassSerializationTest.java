package org.hmcl.cvp.dataplatform.geofencing.contracts;

import org.apache.flink.types.PojoTestUtils;
import org.hmcl.cvp.dataplatform.contract.enriched.AlertNotification;
import org.hmcl.cvp.dataplatform.contract.enriched.EnrichedTelemetry;
import org.hmcl.cvp.dataplatform.contract.telemetry.Telemetry;
import org.hmcl.cvp.dataplatform.contract.userpreference.GeoFenceFeature;
import org.hmcl.cvp.dataplatform.contract.userpreference.UserPreference;
import org.hmcl.cvp.dataplatform.geofencing.contract.*;
import org.junit.Test;

public class PojoClassSerializationTest {

    @Test
    public void testTelemetry() {
        PojoTestUtils.assertSerializedAsPojo(Telemetry.class);
    }

    @Test
    public void testUserPreference() {
        PojoTestUtils.assertSerializedAsPojo(UserPreference.class);
    }

    @Test
    public void testGeoFenceFeature() {
        PojoTestUtils.assertSerializedAsPojo(GeoFenceFeature.class);
    }

    @Test
    public void testGeoEnrichedTelemetry() {
        PojoTestUtils.assertSerializedAsPojo(GeoEnrichedTelemetry.class);
    }

    @Test
    public void testGeoUserPreference() {
        PojoTestUtils.assertSerializedAsPojo(GeoUserPreference.class);
    }

    @Test
    public void testIndividualAndTaggedFence() {
        PojoTestUtils.assertSerializedAsPojo(IndividualAndTaggedFence.class);
    }

    @Test
    public void testFenceAndPolygon() {
        PojoTestUtils.assertSerializedAsPojo(FenceAndPolygon.class);
    }

    @Test
    public void testVehicleState() {
        PojoTestUtils.assertSerializedAsPojo(VehicleState.class);
    }

    @Test
    public void testEnrichedTelemetry() {
        PojoTestUtils.assertSerializedAsPojo(EnrichedTelemetry.class);
    }

    @Test
    public void testEnrichedGeoFence() {
        PojoTestUtils.assertSerializedAsPojo(EnrichedGeoFence.class);
    }

    @Test
    public void testAlertNotification() {
        PojoTestUtils.assertSerializedAsPojo(AlertNotification.class);
    }
}
