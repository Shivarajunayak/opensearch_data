package org.hmcl.cvp.dataplatform.geofencing.operator;

import org.apache.flink.api.common.typeinfo.BasicTypeInfo;
import org.apache.flink.api.java.functions.KeySelector;
import org.apache.flink.api.java.utils.ParameterTool;
import org.apache.flink.runtime.jobgraph.OperatorID;
import org.apache.flink.runtime.metrics.groups.InternalOperatorMetricGroup;
import org.apache.flink.runtime.metrics.util.InterceptingOperatorMetricGroup;
import org.apache.flink.runtime.metrics.util.InterceptingTaskMetricGroup;
import org.apache.flink.runtime.operators.testutils.MockEnvironment;
import org.apache.flink.runtime.operators.testutils.MockEnvironmentBuilder;
import org.apache.flink.runtime.testutils.MiniClusterResourceConfiguration;
import org.apache.flink.streaming.api.operators.KeyedProcessOperator;
import org.apache.flink.streaming.runtime.streamrecord.StreamRecord;
import org.apache.flink.streaming.util.KeyedOneInputStreamOperatorTestHarness;
import org.apache.flink.test.util.MiniClusterWithClientResource;
import org.hmcl.cvp.dataplatform.commons.constants.FlinkRuntime;
import org.hmcl.cvp.dataplatform.commons.utils.DateUtils;
import org.hmcl.cvp.dataplatform.commons.utils.FlinkUtils;
import org.hmcl.cvp.dataplatform.commons.utils.TelemetryUtils;
import org.hmcl.cvp.dataplatform.geofencing.contract.EnrichedGeoFence;
import org.hmcl.cvp.dataplatform.geofencing.contract.GeoEnrichedTelemetry;
import org.hmcl.cvp.dataplatform.geofencing.utils.GeoFenceData;
import org.junit.Assert;
import org.junit.ClassRule;
import org.junit.Test;

import java.time.Instant;
import java.util.*;

public class GeoFenceShutDownFunctionTest {

    @ClassRule
    public static MiniClusterWithClientResource flinkCluster =
            new MiniClusterWithClientResource(
                    new MiniClusterResourceConfiguration.Builder()
                            .setNumberSlotsPerTaskManager(2)
                            .setNumberTaskManagers(1)
                            .build());

    private final InterceptingOperatorMetricGroup interceptingOperatorMetricGroup = new InterceptingOperatorMetricGroup();
    private final InterceptingTaskMetricGroup interceptingTaskMetricGroup = new InterceptingTaskMetricGroup() {
        @Override
        public InternalOperatorMetricGroup getOrAddOperator(OperatorID operatorID, String name) {
            return interceptingOperatorMetricGroup;
        }
    };

    private final MockEnvironment mockEnvironment = new MockEnvironmentBuilder().setMetricGroup(interceptingTaskMetricGroup).build();

    private final GeoFenceShutDownFunction shutDownFunction = new GeoFenceShutDownFunction();

    private KeyedOneInputStreamOperatorTestHarness<String, GeoEnrichedTelemetry, String> getTestHarness() throws Exception {
        ParameterTool parameterTool = ParameterTool.fromMap(new HashMap<>());
        parameterTool = FlinkUtils.addProperties(parameterTool, Map.of(FlinkRuntime.GeoFence.WAIT_TIME_AFTER_BREACH_IN_MIN, "5"));
        parameterTool = FlinkUtils.addProperties(parameterTool, Map.of(FlinkRuntime.GeoFence.NUM_OF_BREACHES_FOR_IMMOBILISATION, "5"));
        parameterTool = FlinkUtils.addProperties(parameterTool, Map.of(FlinkRuntime.ENV, "dev"));
        mockEnvironment.getExecutionConfig().setGlobalJobParameters(parameterTool);

        return new KeyedOneInputStreamOperatorTestHarness<>(
                new KeyedProcessOperator<>(shutDownFunction),
                (KeySelector<GeoEnrichedTelemetry, String>) value -> TelemetryUtils.getVirtualId(value.getTelemetry()),
                BasicTypeInfo.STRING_TYPE_INFO, mockEnvironment
        );
    }

    @Test
    public void testGeoFenceShutDownFunction_breachCountGreaterThanFive() {
        try (KeyedOneInputStreamOperatorTestHarness<String, GeoEnrichedTelemetry, String> testHarness = getTestHarness()) {
            testHarness.setup();
            testHarness.open();

            GeoEnrichedTelemetry enrichedTelemetry = GeoFenceData.getAutoImmobilization(Instant.now(), 6);
            List<StreamRecord<GeoEnrichedTelemetry>> streamRecords = List.of(new StreamRecord<>(enrichedTelemetry, enrichedTelemetry.getTelemetry().getCollectionEventTime()));

            testHarness.processElements(streamRecords);
            Assert.assertEquals(1, testHarness.getRecordOutput().size());
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    @Test
    public void testGeoFenceShutDownFunction_breachCountOlderThanFiveMinutes() {
        try (KeyedOneInputStreamOperatorTestHarness<String, GeoEnrichedTelemetry, String> testHarness = getTestHarness()) {
            testHarness.setup();
            testHarness.open();

            GeoEnrichedTelemetry enrichedTelemetry = GeoFenceData.getAutoImmobilization(Instant.now(), 1);
            Set<EnrichedGeoFence> geoFences = enrichedTelemetry.getEnrichedGeoFences();

            long breachedTime = new ArrayList<>(geoFences).get(0).getBreachTimestamp();
            long immobilizedTime = DateUtils.addMinutes(breachedTime, 5);

            List<StreamRecord<GeoEnrichedTelemetry>> streamRecords = List.of(new StreamRecord<>(enrichedTelemetry, enrichedTelemetry.getTelemetry().getCollectionEventTime()));

            testHarness.processElements(streamRecords);

            // There should be 1 timer corresponding to the first breach
            int timers = testHarness.numEventTimeTimers();
            Assert.assertEquals(1, timers);

            // Forward the watermark to the trigger time so that onTimer function will be triggered
            testHarness.processWatermark(immobilizedTime);
            testHarness.setProcessingTime(immobilizedTime);

            Assert.assertEquals(1, testHarness.getRecordOutput().size());
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    @Test
    public void testGeoFenceDeRegisterTimersAndStateFunction_emptyFences() {
        GeoEnrichedTelemetry stateValue = new GeoEnrichedTelemetry();
        shutDownFunction.deRegisterTimersAndState("vid", stateValue, Collections.singleton(new EnrichedGeoFence()), null);
    }

    @Test
    public void testGeoFenceDeRegisterTimersAndStateFunction() {
        GeoEnrichedTelemetry enrichedTelemetry = GeoFenceData.getAutoImmobilization(Instant.now(), 1);
        Set<EnrichedGeoFence> geoFences = enrichedTelemetry.getEnrichedGeoFences();


        GeoEnrichedTelemetry stateValue = new GeoEnrichedTelemetry();
        stateValue.setEnrichedGeoFences(geoFences);

        shutDownFunction.deRegisterTimersAndState("vid", stateValue, Collections.singleton(new EnrichedGeoFence()), null);
    }
}
