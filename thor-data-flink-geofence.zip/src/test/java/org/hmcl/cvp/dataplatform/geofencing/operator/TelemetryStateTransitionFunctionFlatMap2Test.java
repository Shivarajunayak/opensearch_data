package org.hmcl.cvp.dataplatform.geofencing.operator;

import org.apache.flink.api.common.state.MapState;
import org.apache.flink.api.common.typeinfo.BasicTypeInfo;
import org.apache.flink.api.java.functions.KeySelector;
import org.apache.flink.api.java.utils.ParameterTool;
import org.apache.flink.runtime.testutils.MiniClusterResourceConfiguration;
import org.apache.flink.streaming.api.operators.co.CoStreamFlatMap;
import org.apache.flink.streaming.runtime.streamrecord.StreamRecord;
import org.apache.flink.streaming.util.KeyedTwoInputStreamOperatorTestHarness;
import org.apache.flink.test.util.MiniClusterWithClientResource;
import org.hmcl.cvp.dataplatform.commons.constants.FlinkRuntime;
import org.hmcl.cvp.dataplatform.commons.testdata.UserPreferenceGenerator;
import org.hmcl.cvp.dataplatform.commons.utils.FlinkUtils;
import org.hmcl.cvp.dataplatform.commons.utils.TelemetryUtils;
import org.hmcl.cvp.dataplatform.commons.utils.UserPreferenceUtils;
import org.hmcl.cvp.dataplatform.contract.telemetry.Telemetry;
import org.hmcl.cvp.dataplatform.contract.userpreference.GeoFenceFeature;
import org.hmcl.cvp.dataplatform.contract.userpreference.TagProfile;
import org.hmcl.cvp.dataplatform.contract.userpreference.UserPreference;
import org.hmcl.cvp.dataplatform.geofencing.contract.*;
import org.hmcl.cvp.dataplatform.geofencing.utils.GeoFenceData;
import org.junit.Assert;
import org.junit.ClassRule;
import org.junit.Test;
import org.testcontainers.shaded.org.awaitility.Awaitility;

import java.time.Duration;
import java.time.Instant;
import java.util.*;
import java.util.stream.Collectors;

// NOTE
// 1. Add test cases for tagged fences
// 2. Add test cases for multiple fences
public class TelemetryStateTransitionFunctionFlatMap2Test {

    @ClassRule
    public static MiniClusterWithClientResource flinkCluster =
            new MiniClusterWithClientResource(
                    new MiniClusterResourceConfiguration.Builder()
                            .setNumberSlotsPerTaskManager(2)
                            .setNumberTaskManagers(1)
                            .build());

    private final KeySelector<Telemetry, String> telemetryKeySelector = TelemetryUtils::getVirtualId;
    private final KeySelector<UserPreference, String> userPreferenceStringKeySelector = UserPreference::getVid;

    TelemetryStateTransitionFunction telemetryStateTransitionFunction = new TelemetryStateTransitionFunction();

    private KeyedTwoInputStreamOperatorTestHarness<String, Telemetry, UserPreference, GeoEnrichedTelemetry> testHarness() throws Exception {
        ParameterTool parameterTool = ParameterTool.fromMap(new HashMap<>());
        parameterTool = FlinkUtils.addProperties(parameterTool, Map.of(FlinkRuntime.GeoFence.WAIT_TIME_AFTER_BREACH_IN_MIN, "5"));
        parameterTool = FlinkUtils.addProperties(parameterTool, Map.of(FlinkRuntime.USER_PREFERENCE_STATE_TTL_IN_DAYS, "1"));
        parameterTool = FlinkUtils.addProperties(parameterTool, Map.of(FlinkRuntime.GEOFENCE_SIMULATOR_RUN, "FALSE"));
        parameterTool = FlinkUtils.addProperties(parameterTool, Map.of(FlinkRuntime.NO_LAST_DIGITS_TO_IGNORE_IN_MILLIS, "0"));
        parameterTool = FlinkUtils.addProperties(parameterTool, Map.of(FlinkRuntime.ENV, "dev"));

        KeyedTwoInputStreamOperatorTestHarness<String, Telemetry, UserPreference, GeoEnrichedTelemetry> testHarness =
                new KeyedTwoInputStreamOperatorTestHarness<>(new CoStreamFlatMap<>(telemetryStateTransitionFunction),
                        telemetryKeySelector,
                        userPreferenceStringKeySelector,
                        BasicTypeInfo.STRING_TYPE_INFO);

        testHarness.getEnvironment().getExecutionConfig().setGlobalJobParameters(parameterTool);

        return testHarness;
    }

    private MapState<String, Map<String, GeoUserPreference>> getPreferencesStateMap(KeyedTwoInputStreamOperatorTestHarness<String, Telemetry, UserPreference, GeoEnrichedTelemetry> testHarness) {
        return testHarness.getOperator()
                .getKeyedStateStore()
                .getMapState(MapStateDescriptors.userPreferenceMapStateDescriptor());
    }

    @Test
    public void testTelemetryStateTransitionFunction_incomingPrimaryNonRider() {
        try (KeyedTwoInputStreamOperatorTestHarness<String, Telemetry, UserPreference, GeoEnrichedTelemetry> testHarness = testHarness()) {

            testHarness.setup();
            testHarness.open();

            UserPreference primaryUser = UserPreferenceGenerator.getPrimaryUser(GeoFenceData.VIRTUAL_ID);
            StreamRecord<UserPreference> streamRecord = new StreamRecord<>(primaryUser);

            testHarness.processElement2(streamRecord);

            MapState<String, Map<String, GeoUserPreference>> preferencesStateMap = getPreferencesStateMap(testHarness);

            Map<String, GeoUserPreference> preferences = preferencesStateMap.get(GeoFenceData.VIRTUAL_ID);

            Assert.assertNotNull(preferences);
            Assert.assertTrue(preferences.containsKey(UserPreferenceType.PRIMARY.value()));

        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    @Test
    public void testTelemetryStateTransitionFunction_incomingPrimaryRider() {
        try (KeyedTwoInputStreamOperatorTestHarness<String, Telemetry, UserPreference, GeoEnrichedTelemetry> testHarness = testHarness()) {

            testHarness.setup();
            testHarness.open();

            UserPreference primaryRider = UserPreferenceGenerator.getPrimaryRider(GeoFenceData.VIRTUAL_ID);
            StreamRecord<UserPreference> streamRecord = new StreamRecord<>(primaryRider);

            testHarness.processElement2(streamRecord);

            MapState<String, Map<String, GeoUserPreference>> preferencesStateMap = getPreferencesStateMap(testHarness);

            Map<String, GeoUserPreference> preferences = preferencesStateMap.get(GeoFenceData.VIRTUAL_ID);

            GeoUserPreference rider = preferences.getOrDefault(UserPreferenceType.RIDER.value(), null);
            GeoUserPreference primary = preferences.getOrDefault(UserPreferenceType.PRIMARY.value(), null);

            Assert.assertNotNull(preferences);
            Assert.assertEquals(2, preferences.size());

            Assert.assertNotNull(rider);
            Assert.assertNotNull(primary);

            Assert.assertEquals(rider.getProfileId(), primary.getProfileId());


        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    @Test
    public void testTelemetryStateTransitionFunction_incomingSecondaryRider() {
        try (KeyedTwoInputStreamOperatorTestHarness<String, Telemetry, UserPreference, GeoEnrichedTelemetry> testHarness = testHarness()) {

            testHarness.setup();
            testHarness.open();

            UserPreference secondaryRider = UserPreferenceGenerator.getSecondaryRider(GeoFenceData.VIRTUAL_ID);
            StreamRecord<UserPreference> streamRecord = new StreamRecord<>(secondaryRider);

            testHarness.processElement2(streamRecord);

            MapState<String, Map<String, GeoUserPreference>> preferencesStateMap = getPreferencesStateMap(testHarness);

            Map<String, GeoUserPreference> preferences = preferencesStateMap.get(GeoFenceData.VIRTUAL_ID);
            GeoUserPreference rider = preferences.getOrDefault(UserPreferenceType.RIDER.value(), null);
            GeoUserPreference primary = preferences.getOrDefault(UserPreferenceType.PRIMARY.value(), null);

            Assert.assertNotNull(preferences);
            Assert.assertEquals(1, preferences.size());

            Assert.assertNull(primary);
            Assert.assertNotNull(rider);


        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    @Test
    public void testTelemetryStateTransitionFunction_incomingPrimaryRider_withTaggedFences() {
        try (KeyedTwoInputStreamOperatorTestHarness<String, Telemetry, UserPreference, GeoEnrichedTelemetry> testHarness = testHarness()) {

            testHarness.setup();
            testHarness.open();

            UserPreference primaryUser = UserPreferenceGenerator.getPrimaryUser(GeoFenceData.VIRTUAL_ID);
            UserPreference secondaryUser = UserPreferenceGenerator.getSecondaryUser(GeoFenceData.VIRTUAL_ID);
            UserPreference taggedPrimaryUser = GeoFenceData.tagPrimaryUser(primaryUser, secondaryUser.getProfileId());
            taggedPrimaryUser.setIsRider(true);

            long countOfIndividualFences = taggedPrimaryUser.getAssignedFeatures().getGeoFenceFeatures()
                    .stream().filter(f -> Objects.isNull(f.getTagProfiles()) || f.getTagProfiles().isEmpty())
                    .count();

            StreamRecord<UserPreference> streamPrimaryRecord = new StreamRecord<>(taggedPrimaryUser);
            testHarness.processElement2(streamPrimaryRecord);

            MapState<String, Map<String, GeoUserPreference>> preferencesStateMap = getPreferencesStateMap(testHarness);

            Map<String, GeoUserPreference> preferences = preferencesStateMap.get(GeoFenceData.VIRTUAL_ID);
            GeoUserPreference rider = preferences.getOrDefault(UserPreferenceType.RIDER.value(), null);
            GeoUserPreference primary = preferences.getOrDefault(UserPreferenceType.PRIMARY.value(), null);

            Assert.assertNotNull(preferences);
            Assert.assertEquals(2, preferences.size());

            Assert.assertNotNull(primary);
            Assert.assertNotNull(rider);

            // 2 individual
            Assert.assertEquals(countOfIndividualFences, rider.getRelatedFences().size());
            Assert.assertEquals(countOfIndividualFences, rider.getFencesAndPolygons().size());

        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    @Test
    public void testTelemetryStateTransitionFunction_incomingSecondaryRider_withTaggedFences() {
        try (KeyedTwoInputStreamOperatorTestHarness<String, Telemetry, UserPreference, GeoEnrichedTelemetry> testHarness = testHarness()) {

            testHarness.setup();
            testHarness.open();

            UserPreference primaryUser = UserPreferenceGenerator.getPrimaryUser(GeoFenceData.VIRTUAL_ID);
            UserPreference secondaryRider = UserPreferenceGenerator.getSecondaryRider(GeoFenceData.VIRTUAL_ID);
            UserPreference taggedPrimaryUser = GeoFenceData.tagPrimaryUser(primaryUser, secondaryRider.getProfileId());

            int countOfTaggedFences = taggedPrimaryUser.getAssignedFeatures().getGeoFenceFeatures().size();
            int countOfIndividualFences = secondaryRider.getAssignedFeatures().getGeoFenceFeatures().size();

            StreamRecord<UserPreference> streamSecondaryRecord = new StreamRecord<>(secondaryRider);
            StreamRecord<UserPreference> streamPrimaryRecord = new StreamRecord<>(taggedPrimaryUser);

            testHarness.processElement2(streamPrimaryRecord);
            testHarness.processElement2(streamSecondaryRecord);

            MapState<String, Map<String, GeoUserPreference>> preferencesStateMap = getPreferencesStateMap(testHarness);

            Map<String, GeoUserPreference> preferences = preferencesStateMap.get(GeoFenceData.VIRTUAL_ID);
            GeoUserPreference rider = preferences.getOrDefault(UserPreferenceType.RIDER.value(), null);
            GeoUserPreference primary = preferences.getOrDefault(UserPreferenceType.PRIMARY.value(), null);

            Assert.assertNotNull(preferences);
            Assert.assertEquals(2, preferences.size());

            Assert.assertNotNull(primary);
            Assert.assertNotNull(rider);

            // 2 individual + 2 tagged
            Assert.assertEquals(countOfTaggedFences + countOfIndividualFences, rider.getRelatedFences().size());
            Assert.assertEquals(countOfTaggedFences + countOfIndividualFences, rider.getFencesAndPolygons().size());

        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    @Test
    public void testTelemetryStateTransitionFunction_incomingSecondaryRider_withFenceDifferences() {
        try (KeyedTwoInputStreamOperatorTestHarness<String, Telemetry, UserPreference, GeoEnrichedTelemetry> testHarness = testHarness()) {

            testHarness.setup();
            testHarness.open();

            UserPreference secondaryRider = UserPreferenceGenerator.getSecondaryRider(GeoFenceData.VIRTUAL_ID);
            List<GeoFenceFeature> features = secondaryRider.getAssignedFeatures().getGeoFenceFeatures();
            features.forEach(f -> {
                f.setAutoImmobilisationEnabled(true);
            });
            secondaryRider.getAssignedFeatures().setGeoFenceFeatures(features);

            StreamRecord<UserPreference> secondaryRecord = new StreamRecord<>(secondaryRider);

            testHarness.processElement2(secondaryRecord);

            MapState<String, Map<String, GeoUserPreference>> preferencesStateMap1 = getPreferencesStateMap(testHarness);
            Map<String, GeoUserPreference> preferences1 = preferencesStateMap1.get(GeoFenceData.VIRTUAL_ID);
            Assert.assertNotNull(preferences1);
            GeoUserPreference geoUserPreference1 = preferences1.getOrDefault(UserPreferenceType.RIDER.value(), null);
            Assert.assertNotNull(geoUserPreference1);
            Assert.assertNotEquals(0, geoUserPreference1.getFencesAndPolygons().size());

            UserPreference secondaryRider2 = UserPreferenceUtils.deepCopy(secondaryRider);
            assert secondaryRider2 != null;
            List<GeoFenceFeature> features2 = secondaryRider2.getAssignedFeatures().getGeoFenceFeatures();
            features2.forEach(f -> {
                f.setAutoImmobilisationEnabled(false);
            });
            secondaryRider.getAssignedFeatures().setGeoFenceFeatures(features2);
            StreamRecord<UserPreference> secondaryRecord2 = new StreamRecord<>(secondaryRider2);

            testHarness.processElement2(secondaryRecord2);
            MapState<String, Map<String, GeoUserPreference>> preferencesStateMap2 = getPreferencesStateMap(testHarness);
            Map<String, GeoUserPreference> preferences2 = preferencesStateMap2.get(GeoFenceData.VIRTUAL_ID);
            Assert.assertNotNull(preferences2);
            GeoUserPreference geoUserPreference2 = preferences2.getOrDefault(UserPreferenceType.RIDER.value(), null);
            Assert.assertNotNull(geoUserPreference2);
            Assert.assertNotEquals(0, geoUserPreference2.getFencesAndPolygons().size());

        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    @Test
    public void testTelemetryStateTransitionFunction_incomingSecondaryNonRider() {
        try (KeyedTwoInputStreamOperatorTestHarness<String, Telemetry, UserPreference, GeoEnrichedTelemetry> testHarness = testHarness()) {

            testHarness.setup();
            testHarness.open();

            UserPreference secondaryNonRider = UserPreferenceGenerator.getSecondaryUser(GeoFenceData.VIRTUAL_ID);
            StreamRecord<UserPreference> secondaryRecord = new StreamRecord<>(secondaryNonRider);

            testHarness.processElement2(secondaryRecord);

            MapState<String, Map<String, GeoUserPreference>> preferencesStateMap = getPreferencesStateMap(testHarness);

            Map<String, GeoUserPreference> preferences = preferencesStateMap.get(GeoFenceData.VIRTUAL_ID);
            Assert.assertNull(preferences);

        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    @Test
    public void testTelemetryStateTransitionFunction_firstPrimaryRiderThenSecondaryRider() {
        try (KeyedTwoInputStreamOperatorTestHarness<String, Telemetry, UserPreference, GeoEnrichedTelemetry> testHarness = testHarness()) {

            testHarness.setup();
            testHarness.open();

            UserPreference primaryRider = UserPreferenceGenerator.getPrimaryRider(GeoFenceData.VIRTUAL_ID);
            UserPreference primaryUser = UserPreferenceUtils.deepCopy(primaryRider);
            assert primaryUser != null;
            primaryUser.setIsRider(false);

            UserPreference secondaryRider = UserPreferenceGenerator.getSecondaryRider(GeoFenceData.VIRTUAL_ID);

            StreamRecord<UserPreference> primaryRiderRecord = new StreamRecord<>(primaryRider);
            StreamRecord<UserPreference> primaryUserRecord = new StreamRecord<>(primaryUser);
            StreamRecord<UserPreference> secondaryRiderRecord = new StreamRecord<>(secondaryRider);

            testHarness.processElement2(primaryRiderRecord);
            MapState<String, Map<String, GeoUserPreference>> preferencesStateMap1 = getPreferencesStateMap(testHarness);
            Map<String, GeoUserPreference> preferences1 = preferencesStateMap1.get(GeoFenceData.VIRTUAL_ID);

            GeoUserPreference rider1 = preferences1.getOrDefault(UserPreferenceType.RIDER.value(), null);
            GeoUserPreference primary1 = preferences1.getOrDefault(UserPreferenceType.PRIMARY.value(), null);

            Assert.assertNotNull(preferences1);
            Assert.assertEquals(2, preferences1.size());
            Assert.assertNotNull(primary1);
            Assert.assertNotNull(rider1);
            Assert.assertEquals(rider1.getProfileId(), primary1.getProfileId());

            testHarness.processElement2(primaryUserRecord);
            MapState<String, Map<String, GeoUserPreference>> preferencesStateMap2 = getPreferencesStateMap(testHarness);

            Map<String, GeoUserPreference> preferences2 = preferencesStateMap2.get(GeoFenceData.VIRTUAL_ID);
            GeoUserPreference rider2 = preferences2.getOrDefault(UserPreferenceType.RIDER.value(), null);
            GeoUserPreference primary2 = preferences2.getOrDefault(UserPreferenceType.PRIMARY.value(), null);

            Assert.assertEquals(1, preferences2.size());
            Assert.assertNotNull(primary2);
            Assert.assertFalse(primary2.isRider());
            Assert.assertNull(rider2);

            testHarness.processElement2(secondaryRiderRecord);
            MapState<String, Map<String, GeoUserPreference>> preferencesStateMap3 = getPreferencesStateMap(testHarness);
            Map<String, GeoUserPreference> preferences3 = preferencesStateMap3.get(GeoFenceData.VIRTUAL_ID);

            GeoUserPreference rider3 = preferences3.getOrDefault(UserPreferenceType.RIDER.value(), null);
            GeoUserPreference primary3 = preferences3.getOrDefault(UserPreferenceType.PRIMARY.value(), null);

            Assert.assertNotNull(preferences3);
            Assert.assertEquals(2, preferences3.size());
            Assert.assertNotNull(primary3);
            Assert.assertNotNull(rider3);
            Assert.assertEquals(rider3.getProfileId(), secondaryRider.getProfileId());

        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    @Test
    public void testTelemetryStateTransitionFunction_firstPrimaryRiderThenSecondaryRider_withoutPrimaryRiderFalse() {
        try (KeyedTwoInputStreamOperatorTestHarness<String, Telemetry, UserPreference, GeoEnrichedTelemetry> testHarness = testHarness()) {

            testHarness.setup();
            testHarness.open();

            UserPreference primaryRider = UserPreferenceGenerator.getPrimaryRider(GeoFenceData.VIRTUAL_ID);
            UserPreference secondaryRider = UserPreferenceGenerator.getSecondaryRider(GeoFenceData.VIRTUAL_ID);
            UserPreference olderRider = UserPreferenceUtils.deepCopy(primaryRider);
            assert olderRider != null;
            olderRider.setUpdatedTsp(Instant.now().minus(Duration.ofMinutes(1)).toEpochMilli());

            StreamRecord<UserPreference> primaryRiderRecord = new StreamRecord<>(primaryRider);
            StreamRecord<UserPreference> secondaryRiderRecord = new StreamRecord<>(secondaryRider);
            StreamRecord<UserPreference> olderRiderRecord = new StreamRecord<>(olderRider);

            testHarness.processElement2(primaryRiderRecord);
            MapState<String, Map<String, GeoUserPreference>> preferencesStateMap1 = getPreferencesStateMap(testHarness);
            Map<String, GeoUserPreference> preferences1 = preferencesStateMap1.get(GeoFenceData.VIRTUAL_ID);

            GeoUserPreference rider1 = preferences1.getOrDefault(UserPreferenceType.RIDER.value(), null);
            GeoUserPreference primary1 = preferences1.getOrDefault(UserPreferenceType.PRIMARY.value(), null);

            Assert.assertNotNull(preferences1);
            Assert.assertEquals(2, preferences1.size());
            Assert.assertNotNull(primary1);
            Assert.assertNotNull(rider1);
            Assert.assertEquals(rider1.getProfileId(), primary1.getProfileId());

            testHarness.processElement2(secondaryRiderRecord);
            MapState<String, Map<String, GeoUserPreference>> preferencesStateMap2 = getPreferencesStateMap(testHarness);
            Map<String, GeoUserPreference> preferences2 = preferencesStateMap2.get(GeoFenceData.VIRTUAL_ID);

            GeoUserPreference rider2 = preferences2.getOrDefault(UserPreferenceType.RIDER.value(), null);
            GeoUserPreference primary2 = preferences2.getOrDefault(UserPreferenceType.PRIMARY.value(), null);

            Assert.assertNotNull(preferences2);
            Assert.assertEquals(2, preferences2.size());
            Assert.assertNotNull(rider2);
            Assert.assertNotNull(primary2);

            // Here, the secondary user only should be the rider.
            // Primary value should not be updated since the incoming value is old
            testHarness.processElement2(olderRiderRecord);
            MapState<String, Map<String, GeoUserPreference>> preferencesStateMap3 = getPreferencesStateMap(testHarness);
            Map<String, GeoUserPreference> preferences3 = preferencesStateMap3.get(GeoFenceData.VIRTUAL_ID);

            GeoUserPreference rider3 = preferences3.getOrDefault(UserPreferenceType.RIDER.value(), null);
            GeoUserPreference primary3 = preferences3.getOrDefault(UserPreferenceType.PRIMARY.value(), null);

            Assert.assertNotNull(preferences2);
            Assert.assertEquals(2, preferences2.size());
            Assert.assertNotNull(rider3);
            Assert.assertNotNull(primary3);
            Assert.assertEquals(rider3.getProfileId(), rider2.getProfileId());
            Assert.assertEquals(primary3.getUpdatedTsp(), primary2.getUpdatedTsp());

        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    @Test
    public void testTelemetryStateTransitionFunction_incomingSecondaryIsRiderFlagChange() {
        try (KeyedTwoInputStreamOperatorTestHarness<String, Telemetry, UserPreference, GeoEnrichedTelemetry> testHarness = testHarness()) {

            testHarness.setup();
            testHarness.open();

            UserPreference primaryUser = UserPreferenceGenerator.getPrimaryUser(GeoFenceData.VIRTUAL_ID);
            UserPreference secondaryRider = UserPreferenceGenerator.getSecondaryRider(GeoFenceData.VIRTUAL_ID);

            StreamRecord<UserPreference> primaryRecord = new StreamRecord<>(primaryUser);
            StreamRecord<UserPreference> secondaryRecord = new StreamRecord<>(secondaryRider);

            testHarness.processElement2(primaryRecord);
            testHarness.processElement2(secondaryRecord);

            MapState<String, Map<String, GeoUserPreference>> preferencesStateMap1 = getPreferencesStateMap(testHarness);
            Map<String, GeoUserPreference> preferences1 = preferencesStateMap1.get(GeoFenceData.VIRTUAL_ID);

            GeoUserPreference rider1 = preferences1.getOrDefault(UserPreferenceType.RIDER.value(), null);
            GeoUserPreference primary1 = preferences1.getOrDefault(UserPreferenceType.PRIMARY.value(), null);

            Assert.assertNotNull(preferences1);
            Assert.assertEquals(2, preferences1.size());
            Assert.assertNotNull(primary1);
            Assert.assertNotNull(rider1);
            Assert.assertEquals(rider1.getProfileId(), secondaryRider.getProfileId());
            Assert.assertNotEquals(rider1.getProfileId(), primary1.getProfileId());

            UserPreference secondaryNonRider = UserPreferenceUtils.deepCopy(secondaryRider);
            assert secondaryNonRider != null;
            secondaryNonRider.setIsRider(false);

            StreamRecord<UserPreference> secondaryRecord1 = new StreamRecord<>(secondaryNonRider);
            testHarness.processElement2(secondaryRecord1);

            MapState<String, Map<String, GeoUserPreference>> preferencesStateMap2 = getPreferencesStateMap(testHarness);
            Map<String, GeoUserPreference> preferences2 = preferencesStateMap2.get(GeoFenceData.VIRTUAL_ID);

            GeoUserPreference rider2 = preferences2.getOrDefault(UserPreferenceType.RIDER.value(), null);
            GeoUserPreference primary2 = preferences2.getOrDefault(UserPreferenceType.PRIMARY.value(), null);

            Assert.assertEquals(1, preferences2.size());
            Assert.assertNotNull(primary2);
            Assert.assertNull(rider2);

        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    @Test
    public void testTelemetryStateTransitionFunction_taggedFence() {
        try (KeyedTwoInputStreamOperatorTestHarness<String, Telemetry, UserPreference, GeoEnrichedTelemetry> testHarness = testHarness()) {

            testHarness.setup();
            testHarness.open();

            Instant instant = Instant.now().minusSeconds(60);
            UserPreference primaryUser = UserPreferenceGenerator.getPrimaryUser(GeoFenceData.VIRTUAL_ID);
            primaryUser.setIsRider(false);
            primaryUser.setUpdatedTsp(instant.toEpochMilli());

            // Secondary User is the rider
            UserPreference secondaryRider = UserPreferenceGenerator.getSecondaryUser(GeoFenceData.VIRTUAL_ID);
            secondaryRider.setIsRider(true);
            secondaryRider.setUpdatedTsp(instant.plusSeconds(30).toEpochMilli());

            // Tag secondary user to the primary fence
            String secondaryProfileId = secondaryRider.getProfileId();
            List<TagProfile> tagProfiles = new ArrayList<>();
            TagProfile tagProfile = TagProfile.builder().taggedProfileId(secondaryProfileId).optInForNotification(true).build();
            tagProfiles.add(tagProfile);
            primaryUser.getAssignedFeatures().getGeoFenceFeatures().forEach(f -> f.setTagProfiles(tagProfiles));

            StreamRecord<UserPreference> primaryRecord = new StreamRecord<>(primaryUser);
            testHarness.processElement2(primaryRecord);

            Awaitility.await()
                    .timeout(Duration.ofSeconds(3))
                    .pollDelay(Duration.ofSeconds(2))
                    .untilAsserted(() -> Assert.assertTrue(true));

            StreamRecord<UserPreference> secondaryRecord = new StreamRecord<>(secondaryRider);
            testHarness.processElement2(secondaryRecord);

            MapState<String, Map<String, GeoUserPreference>> preferencesStateMap = getPreferencesStateMap(testHarness);
            Map<String, GeoUserPreference> preferences = preferencesStateMap.get(GeoFenceData.VIRTUAL_ID);

            GeoUserPreference rider = preferences.getOrDefault(UserPreferenceType.RIDER.value(), null);
            GeoUserPreference primary = preferences.getOrDefault(UserPreferenceType.PRIMARY.value(), null);

            Assert.assertEquals(2, preferences.size());
            Assert.assertNotNull(primary);
            Assert.assertNotNull(rider);

            List<IndividualAndTaggedFence> secondaryFences = rider.getRelatedFences();
            List<IndividualAndTaggedFence> taggedFences = secondaryFences.stream().filter(IndividualAndTaggedFence::getIsTagged).collect(Collectors.toList());
            Assert.assertNotEquals(0, taggedFences.size());

        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    @Test
    public void testTelemetryStateTransitionFunction_taggedFence_noSecondaryChanges() {
        try (KeyedTwoInputStreamOperatorTestHarness<String, Telemetry, UserPreference, GeoEnrichedTelemetry> testHarness = testHarness()) {

            testHarness.setup();
            testHarness.open();

            Instant instant = Instant.now().minusSeconds(60);
            UserPreference primaryUser = UserPreferenceGenerator.getPrimaryUser(GeoFenceData.VIRTUAL_ID);
            primaryUser.setIsRider(false);
            primaryUser.setUpdatedTsp(instant.toEpochMilli());

            StreamRecord<UserPreference> primaryRecord = new StreamRecord<>(primaryUser);
            testHarness.processElement2(primaryRecord);

            Awaitility.await()
                    .timeout(Duration.ofSeconds(3))
                    .pollDelay(Duration.ofSeconds(2))
                    .untilAsserted(() -> Assert.assertTrue(true));

            // Secondary User is the rider
            UserPreference secondaryRider = UserPreferenceGenerator.getSecondaryUser(GeoFenceData.VIRTUAL_ID);
            secondaryRider.setIsRider(true);
            secondaryRider.setUpdatedTsp(instant.plusSeconds(30).toEpochMilli());

            StreamRecord<UserPreference> secondaryRecord = new StreamRecord<>(secondaryRider);
            testHarness.processElement2(secondaryRecord);

            MapState<String, Map<String, GeoUserPreference>> preferencesStateMap = getPreferencesStateMap(testHarness);
            Map<String, GeoUserPreference> preferences = preferencesStateMap.get(GeoFenceData.VIRTUAL_ID);

            GeoUserPreference rider = preferences.getOrDefault(UserPreferenceType.RIDER.value(), null);
            GeoUserPreference primary = preferences.getOrDefault(UserPreferenceType.PRIMARY.value(), null);

            Assert.assertEquals(2, preferences.size());
            Assert.assertNotNull(primary);
            Assert.assertNotNull(rider);

            List<IndividualAndTaggedFence> secondaryFences = rider.getRelatedFences();
            List<IndividualAndTaggedFence> taggedFences = secondaryFences.stream().filter(IndividualAndTaggedFence::getIsTagged).collect(Collectors.toList());
            Assert.assertEquals(0, taggedFences.size());

            // Tag secondary user to the primary fence
            UserPreference primaryUser1 = UserPreferenceUtils.deepCopy(primaryUser);
            assert primaryUser1 != null;
            primaryUser1.setIsRider(false);
            primaryUser1.setUpdatedTsp(instant.plusSeconds(10).toEpochMilli());

            String secondaryProfileId = secondaryRider.getProfileId();
            List<TagProfile> tagProfiles = new ArrayList<>();
            TagProfile tagProfile = TagProfile.builder().taggedProfileId(secondaryProfileId).optInForNotification(true).build();
            tagProfiles.add(tagProfile);
            primaryUser1.getAssignedFeatures().getGeoFenceFeatures().forEach(f -> f.setTagProfiles(tagProfiles));

            StreamRecord<UserPreference> primaryRecord1 = new StreamRecord<>(primaryUser1);
            testHarness.processElement2(primaryRecord1);

            MapState<String, Map<String, GeoUserPreference>> preferencesStateMap1 = getPreferencesStateMap(testHarness);
            Map<String, GeoUserPreference> preferences1 = preferencesStateMap1.get(GeoFenceData.VIRTUAL_ID);

            GeoUserPreference rider1 = preferences1.getOrDefault(UserPreferenceType.RIDER.value(), null);
            GeoUserPreference primary1 = preferences1.getOrDefault(UserPreferenceType.PRIMARY.value(), null);

            Assert.assertEquals(2, preferences1.size());
            Assert.assertNotNull(primary1);
            Assert.assertNotNull(rider1);

            List<IndividualAndTaggedFence> secondaryFences1 = rider1.getRelatedFences();
            List<IndividualAndTaggedFence> taggedFences1 = secondaryFences1.stream().filter(IndividualAndTaggedFence::getIsTagged).collect(Collectors.toList());
            Assert.assertNotEquals(0, taggedFences1.size());

        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    @Test
    public void testTelemetryStateTransitionFunction_taggedFenceRemoved() {
        try (KeyedTwoInputStreamOperatorTestHarness<String, Telemetry, UserPreference, GeoEnrichedTelemetry> testHarness = testHarness()) {

            testHarness.setup();
            testHarness.open();

            Instant instant = Instant.now().minusSeconds(5 * 60);
            UserPreference primaryUser = UserPreferenceGenerator.getPrimaryUser(GeoFenceData.VIRTUAL_ID);
            primaryUser.setIsRider(false);
            primaryUser.setUpdatedTsp(instant.toEpochMilli());

            // Secondary User is the rider
            UserPreference secondaryRider = UserPreferenceGenerator.getSecondaryUser(GeoFenceData.VIRTUAL_ID);
            secondaryRider.setIsRider(true);
            secondaryRider.setUpdatedTsp(instant.plusSeconds(5 * 30).toEpochMilli());

            // Tag secondary user to the primary fence
            String secondaryProfileId = secondaryRider.getProfileId();
            List<TagProfile> tagProfiles = new ArrayList<>();
            TagProfile tagProfile = TagProfile.builder().taggedProfileId(secondaryProfileId).optInForNotification(true).build();
            tagProfiles.add(tagProfile);
            primaryUser.getAssignedFeatures().getGeoFenceFeatures().forEach(f -> f.setTagProfiles(tagProfiles));

            StreamRecord<UserPreference> primaryRecord = new StreamRecord<>(primaryUser);
            testHarness.processElement2(primaryRecord);

            Awaitility.await()
                    .timeout(Duration.ofSeconds(3))
                    .pollDelay(Duration.ofSeconds(2))
                    .untilAsserted(() -> Assert.assertTrue(true));

            StreamRecord<UserPreference> secondaryRecord = new StreamRecord<>(secondaryRider);
            testHarness.processElement2(secondaryRecord);

            MapState<String, Map<String, GeoUserPreference>> preferencesStateMap = getPreferencesStateMap(testHarness);
            Map<String, GeoUserPreference> preferences = preferencesStateMap.get(GeoFenceData.VIRTUAL_ID);

            GeoUserPreference rider = preferences.getOrDefault(UserPreferenceType.RIDER.value(), null);
            GeoUserPreference primary = preferences.getOrDefault(UserPreferenceType.PRIMARY.value(), null);

            Assert.assertEquals(2, preferences.size());
            Assert.assertNotNull(primary);
            Assert.assertNotNull(rider);

            List<IndividualAndTaggedFence> secondaryFences = rider.getRelatedFences();
            List<IndividualAndTaggedFence> taggedFences = secondaryFences.stream().filter(IndividualAndTaggedFence::getIsTagged).collect(Collectors.toList());
            Assert.assertNotEquals(0, taggedFences.size());

            UserPreference primaryUser1 = UserPreferenceUtils.deepCopy(primaryUser);
            assert primaryUser1 != null;
            primaryUser1.setIsRider(false);
            primaryUser1.setUpdatedTsp(instant.plusSeconds(7 * 30).toEpochMilli());
            primaryUser1.getAssignedFeatures().getGeoFenceFeatures().forEach(f -> f.setTagProfiles(new ArrayList<>()));

            StreamRecord<UserPreference> primaryRecord1 = new StreamRecord<>(primaryUser1);
            testHarness.processElement2(primaryRecord1);

            MapState<String, Map<String, GeoUserPreference>> preferencesStateMap1 = getPreferencesStateMap(testHarness);
            Map<String, GeoUserPreference> preferences1 = preferencesStateMap1.get(GeoFenceData.VIRTUAL_ID);

            GeoUserPreference rider1 = preferences1.getOrDefault(UserPreferenceType.RIDER.value(), null);
            GeoUserPreference primary1 = preferences1.getOrDefault(UserPreferenceType.PRIMARY.value(), null);

            Assert.assertEquals(2, preferences1.size());
            Assert.assertNotNull(rider1);
            Assert.assertNotNull(primary1);

            List<IndividualAndTaggedFence> secondaryFences1 = rider1.getRelatedFences();
            List<IndividualAndTaggedFence> taggedFences1 = secondaryFences1.stream().filter(IndividualAndTaggedFence::getIsTagged).collect(Collectors.toList());
            Assert.assertEquals(0, taggedFences1.size());

        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

}
