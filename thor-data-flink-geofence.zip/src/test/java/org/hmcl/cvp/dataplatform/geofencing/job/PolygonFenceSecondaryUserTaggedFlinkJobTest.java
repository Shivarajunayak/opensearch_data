package org.hmcl.cvp.dataplatform.geofencing.job;

import com.google.gson.Gson;
import com.salesforce.kafka.test.KafkaTestCluster;
import com.salesforce.kafka.test.KafkaTestUtils;
import lombok.extern.slf4j.Slf4j;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.apache.kafka.clients.producer.KafkaProducer;
import org.apache.kafka.clients.producer.Producer;
import org.apache.kafka.clients.producer.ProducerConfig;
import org.apache.kafka.clients.producer.ProducerRecord;
import org.apache.kafka.common.serialization.StringDeserializer;
import org.hmcl.cvp.dataplatform.commons.testdata.UserPreferenceGenerator;
import org.hmcl.cvp.dataplatform.commons.utils.GsonUtils;
import org.hmcl.cvp.dataplatform.contract.telemetry.Telemetry;
import org.hmcl.cvp.dataplatform.contract.userpreference.TagProfile;
import org.hmcl.cvp.dataplatform.contract.userpreference.UserPreference;
import org.hmcl.cvp.dataplatform.geofencing.utils.GeoFenceData;
import org.junit.AfterClass;
import org.junit.Assert;
import org.junit.BeforeClass;
import org.junit.Test;
import org.testcontainers.shaded.org.awaitility.Awaitility;

import java.time.Duration;
import java.time.Instant;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

@Slf4j
public class PolygonFenceSecondaryUserTaggedFlinkJobTest {

    private static final Gson GSON = GsonUtils.getGson();

    private static final String CAMPAIGN_INPUT_TOPIC = "telemetry";
    private static final String GEOFENCE_INPUT_TOPIC = "geofence";
    private static final String USER_PREF_INPUT_TOPIC = "user.preference";
    private static final String PRIORITY_OUTPUT_TOPIC = "priority";
    private static final String COMMAND_OUTPUT_TOPIC = "command.and.control";

    private static KafkaTestUtils utils;
    private static KafkaTestCluster cluster;

    @BeforeClass
    public static void testKafkaUnit() throws Throwable {
        // Setup InMemory  Kafka Cluster
        cluster = new KafkaTestCluster(1);
        cluster.start();
        utils = new KafkaTestUtils(cluster);

        utils.createTopic(CAMPAIGN_INPUT_TOPIC, 1, (short) 1);
        utils.createTopic(GEOFENCE_INPUT_TOPIC, 1, (short) 1);
        utils.createTopic(USER_PREF_INPUT_TOPIC, 1, (short) 1);
        utils.createTopic(PRIORITY_OUTPUT_TOPIC, 1, (short) 1);
        utils.createTopic(COMMAND_OUTPUT_TOPIC, 1, (short) 1);
    }

    @AfterClass
    public static void deleteTopic() throws Exception {
        cluster.close();
    }

    private static String[] getSystemArgs() {
        return new String[]{
                "--env", "dev",
                // SET ONLY WHILE RUNNING TEST - DEFAULT VALUE FALSE
                "--is.run.test.case", "TRUE",
                "--is.file.sink", "FALSE",
                "--aws.region", "ap-south-1",
                "--max.out.of.order.in.sec", "60", // one minutes
                "--idle.timeout.in.sec", "5",
                "--wait.time.after.breach.in.min", "5",
                "--num.of.breaches.for.immobilisation", "5",
                "--is.geofence.simulator.run", "FALSE",
                "--user.preference.state.ttl.in.days", "1",
                "--no.last.digits.to.ignore.in.millis", "0",
                "--hdop.value.should.be.less.than", "1.0",
                "--command.execution.timeout", "60",

                // KAFKA Telemetry PROPERTY
                "--kafka.campaign.bootstrap.brokers", cluster.getKafkaConnectString(),
                "--kafka.telemetry.campaign.input.topic", CAMPAIGN_INPUT_TOPIC,
                "--kafka.geofence.campaign.input.topic", GEOFENCE_INPUT_TOPIC,
                "--kafka.campaign.group.id", "GeoFenceCampaignGroup",
                "--kafka.campaign.role.arn", "XXXXX",
                "--kafka.campaign.session.name", "GeoFenceCampaignSession",

                // KAFKA User preference PROPERTY
                "--kafka.userpref.bootstrap.brokers", cluster.getKafkaConnectString(),
                "--kafka.userpref.input.topic", USER_PREF_INPUT_TOPIC,
                "--kafka.userpref.group.id", "GeoFenceUserPrefGroup",
                "--kafka.userpref.role.arn", "XXXXX",
                "--kafka.userpref.session.name", "GeoFenceUserPrefSession",

                // KAFKA AlertNotification PROPERTY
                "--kafka.notification.bootstrap.brokers", cluster.getKafkaConnectString(),
                "--kafka.notification.priority.topic", PRIORITY_OUTPUT_TOPIC,
                "--kafka.notification.group.id", "GeoFenceNotificationGroup",
                "--kafka.notification.role.arn", "XXXXX",
                "--kafka.notification.session.name", "GeoFenceNotificationSession",
                "--sink.acks", "all",

                // KAFKA Command PROPERTY
                "--kafka.command.request.bootstrap.brokers", cluster.getKafkaConnectString(),
                "--kafka.command.request.topic", COMMAND_OUTPUT_TOPIC,
                "--kafka.command.request.group.id", "GeoFenceCommandRequestGroup",
                "--kafka.command.request.role.arn", "XXXXX",
                "--kafka.command.request.session.name", "GeoFenceCommandRequestSession",

        };
    }

    private static Producer<String, String> getProducer() {
        Properties props = new Properties();

        props.put(ProducerConfig.BOOTSTRAP_SERVERS_CONFIG, cluster.getKafkaConnectString());
        props.put("security.protocol", "PLAINTEXT");
        props.put(ProducerConfig.ACKS_CONFIG, "all");
        props.put(ProducerConfig.RETRIES_CONFIG, 2);
        props.put(ProducerConfig.LINGER_MS_CONFIG, 2);
        props.put(ProducerConfig.KEY_SERIALIZER_CLASS_CONFIG, "org.apache.kafka.common.serialization.StringSerializer");
        props.put(ProducerConfig.VALUE_SERIALIZER_CLASS_CONFIG, "org.apache.kafka.common.serialization.StringSerializer");

        return new KafkaProducer<>(props);
    }

    private void sendUserPreferenceData(List<UserPreference> userPreferences) {
        Producer<String, String> producer = getProducer();

        userPreferences.forEach(v -> {
            String message = GSON.toJson(v);
            ProducerRecord<String, String> producerRecord = new ProducerRecord<>(USER_PREF_INPUT_TOPIC, message);
            producer.send(producerRecord);
            producer.flush();

            Awaitility.await()
                    .timeout(Duration.ofSeconds(5))
                    .pollDelay(Duration.ofSeconds(2))
                    .untilAsserted(() -> Assert.assertTrue(true));
        });

        producer.close();

    }

    private void sendCampaignData(List<Telemetry> telemetryData, String topic) {
        Producer<String, String> producer = getProducer();

        telemetryData.forEach(v -> {
            String message = GSON.toJson(v);
            ProducerRecord<String, String> producerRecord = new ProducerRecord<>(topic, message);
            producer.send(producerRecord);
            producer.flush();
        });

        producer.close();
    }

    private Long getOutputEvents() {

        // READ DATA FROM NOTIFICATION_OUTPUT_TOPIC and display it
        List<ConsumerRecord<String, String>> consumerRecords = utils.consumeAllRecordsFromTopic(
                PolygonFenceSecondaryUserTaggedFlinkJobTest.PRIORITY_OUTPUT_TOPIC,
                StringDeserializer.class,
                StringDeserializer.class
        );

        for (ConsumerRecord<String, String> consumerRecord : consumerRecords) {
            log.info("{}", consumerRecord);
        }
        int count = consumerRecords.size();
        log.info("Number of records in {}: {}", PolygonFenceSecondaryUserTaggedFlinkJobTest.PRIORITY_OUTPUT_TOPIC, count);

        return (long) count;
    }

    @Test
    public void testGeoFenceAlert() throws InterruptedException {
        boolean circular = false;
        boolean polygon = true;
        boolean autoImmobilize = true;

        int numOfBreaches = 1;
        int numOfEntries = 1;
        int countOfEachSignal = 1;

        Instant instant = Instant.now().minusSeconds(60);
        UserPreference primaryUser = UserPreferenceGenerator.getPrimaryUser(GeoFenceData.VIRTUAL_ID, circular, polygon);
        primaryUser.setIsRider(false);
        primaryUser.setUpdatedTsp(instant.toEpochMilli());
        primaryUser.getAssignedFeatures().getGeoFenceFeatures().forEach(f -> f.setAutoImmobilisationEnabled(autoImmobilize));

        // Secondary User is the rider
        UserPreference secondaryRider = UserPreferenceGenerator.getSecondaryUser(GeoFenceData.VIRTUAL_ID, circular, polygon);
        secondaryRider.setIsRider(true);
        secondaryRider.setUpdatedTsp(instant.plusSeconds(30).toEpochMilli());
        secondaryRider.getAssignedFeatures().getGeoFenceFeatures().forEach(f -> f.setAutoImmobilisationEnabled(autoImmobilize));

        // Tag secondary user to the primary fence
        String secondaryProfileId = secondaryRider.getProfileId();
        List<TagProfile> tagProfiles = new ArrayList<>();
        TagProfile tagProfile = TagProfile.builder().taggedProfileId(secondaryProfileId).optInForNotification(true).build();
        tagProfiles.add(tagProfile);
        primaryUser.getAssignedFeatures().getGeoFenceFeatures().forEach(f -> f.setTagProfiles(tagProfiles));

        sendUserPreferenceData(List.of(primaryUser, secondaryRider));

        Awaitility.await()
                .timeout(Duration.ofSeconds(15))
                .pollDelay(Duration.ofSeconds(10))
                .untilAsserted(() -> Assert.assertTrue(true));

        Instant vehicleEnteredTime = Instant.now().minusSeconds(15 * 60);
        Instant vehicleExitTime = vehicleEnteredTime.plusSeconds(5 * 60);

        List<Telemetry> vehicleStarted = GeoFenceData.getTelemetryWithinBoundary(primaryUser, circular, vehicleEnteredTime, numOfEntries, countOfEachSignal);
        sendCampaignData(vehicleStarted, CAMPAIGN_INPUT_TOPIC);

        Awaitility.await()
                .timeout(Duration.ofSeconds(10))
                .pollDelay(Duration.ofSeconds(5))
                .untilAsserted(() -> Assert.assertTrue(true));

        List<Telemetry> vehicleExited = GeoFenceData.getFenceBreachEvents(primaryUser, circular, vehicleExitTime, numOfBreaches, countOfEachSignal);
        sendCampaignData(vehicleExited, GEOFENCE_INPUT_TOPIC);

        Thread flinkJOb = new Thread(() -> {
            try {
                GeoFencingFlink.main(getSystemArgs());
            } catch (Exception e) {
                throw new RuntimeException(e);
            }
        });

        flinkJOb.start();

        // Interrupt the thread after 30 seconds
        flinkJOb.join(Duration.ofSeconds(30).toMillis());

        // Two records in priority topic corresponding to one tagged and one individual
        long priorityKafkaRecordsSize = getOutputEvents();
        Assert.assertEquals(2, priorityKafkaRecordsSize);

    }

}
