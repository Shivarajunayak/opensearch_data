package org.hmcl.cvp.dataplatform.geofencing.helper;

import com.google.gson.Gson;
import org.hmcl.cvp.dataplatform.commons.testdata.UserPreferenceGenerator;
import org.hmcl.cvp.dataplatform.commons.utils.DateUtils;
import org.hmcl.cvp.dataplatform.commons.utils.GsonUtils;
import org.hmcl.cvp.dataplatform.contract.telemetry.Telemetry;
import org.hmcl.cvp.dataplatform.contract.userpreference.*;
import org.hmcl.cvp.dataplatform.geofencing.contract.IndividualAndTaggedFence;
import org.hmcl.cvp.dataplatform.geofencing.contract.Location;
import org.hmcl.cvp.dataplatform.geofencing.utils.GeoFenceData;
import org.junit.Assert;
import org.junit.Test;

import java.time.Instant;
import java.util.ArrayList;
import java.util.List;

public class GeoFenceHelperTest {

    private static final Gson GSON = GsonUtils.getGson();

    private static GeoFenceFeature fromJson(String value) {
        return GSON.fromJson(value, GeoFenceFeature.class);
    }

    @Test
    public void testGeoFenceHelper_getIndividualAndTaggedFences_autoImmobiliseFlag() {
        List<IndividualAndTaggedFence> cachedFences = new ArrayList<>();
        List<GeoFenceFeature> features = UserPreferenceGenerator.getGeoFenceFeatures("123", true, true, true);

        features.forEach(f -> {
            IndividualAndTaggedFence individualAndTaggedFence = IndividualAndTaggedFence.builder()
                    .geoFenceFeature(f)
                    .build();

            cachedFences.add(individualAndTaggedFence);
        });

        List<IndividualAndTaggedFence> incomingFences = new ArrayList<>();
        cachedFences.forEach(f -> {
            String featureStr = GsonUtils.toJson(f.getGeoFenceFeature());

            GeoFenceFeature feature = fromJson(featureStr);
            feature.setAutoImmobilisationEnabled(false);
            IndividualAndTaggedFence individualAndTaggedFence = IndividualAndTaggedFence.builder()
                    .geoFenceFeature(feature)
                    .build();

            incomingFences.add(individualAndTaggedFence);
        });

        List<IndividualAndTaggedFence> diff = GeoFenceHelper.getDiffOfGeoFences(incomingFences, cachedFences);
        Assert.assertEquals(2, diff.size());
    }

    @Test
    public void testGeoFenceHelper_getIndividualAndTaggedFences_polygonCoordinatesChange() {
        List<IndividualAndTaggedFence> cachedFences = new ArrayList<>();
        List<GeoFenceFeature> features = UserPreferenceGenerator.getGeoFenceFeatures("123", false, true, true);

        features.forEach(f -> {
            IndividualAndTaggedFence individualAndTaggedFence = IndividualAndTaggedFence.builder()
                    .geoFenceFeature(f)
                    .build();

            cachedFences.add(individualAndTaggedFence);
        });

        List<IndividualAndTaggedFence> incomingFences = new ArrayList<>();
        cachedFences.forEach(f -> {
            String featureStr = GsonUtils.toJson(f.getGeoFenceFeature());

            GeoFenceFeature feature = fromJson(featureStr);
            feature.setPolygon(new Polygon());
            IndividualAndTaggedFence individualAndTaggedFence = IndividualAndTaggedFence.builder()
                    .geoFenceFeature(feature)
                    .build();

            incomingFences.add(individualAndTaggedFence);
        });

        List<IndividualAndTaggedFence> diff = GeoFenceHelper.getDiffOfGeoFences(incomingFences, cachedFences);
        Assert.assertEquals(1, diff.size());
        Assert.assertEquals(diff.get(0).getFenceId(), incomingFences.get(0).getFenceId());
    }

    @Test
    public void testGeoFenceHelper_getIndividualAndTaggedFences_circleRadiusChange() {
        List<IndividualAndTaggedFence> cachedFences = new ArrayList<>();
        List<GeoFenceFeature> features = UserPreferenceGenerator.getGeoFenceFeatures("123", true, false, true);

        features.forEach(f -> {
            IndividualAndTaggedFence individualAndTaggedFence = IndividualAndTaggedFence.builder()
                    .geoFenceFeature(f)
                    .build();

            cachedFences.add(individualAndTaggedFence);
        });

        List<IndividualAndTaggedFence> incomingFences = new ArrayList<>();
        cachedFences.forEach(f -> {
            String featureStr = GsonUtils.toJson(f.getGeoFenceFeature());

            GeoFenceFeature feature = fromJson(featureStr);
            feature.getCircle().setCoordinates(new Coordinate());
            IndividualAndTaggedFence individualAndTaggedFence = IndividualAndTaggedFence.builder()
                    .geoFenceFeature(feature)
                    .build();

            incomingFences.add(individualAndTaggedFence);
        });

        List<IndividualAndTaggedFence> diff = GeoFenceHelper.getDiffOfGeoFences(incomingFences, cachedFences);
        Assert.assertEquals(1, diff.size());
        Assert.assertEquals(diff.get(0).getFenceId(), incomingFences.get(0).getFenceId());
    }

    @Test
    public void testGeoFenceHelper_getIndividualAndTaggedFences_circleSizeChange() {
        List<IndividualAndTaggedFence> cachedFences = new ArrayList<>();
        List<GeoFenceFeature> features = UserPreferenceGenerator.getGeoFenceFeatures("123", true, false, true);

        features.forEach(f -> {
            f.getCircle().setRadius(5.0);
            IndividualAndTaggedFence individualAndTaggedFence = IndividualAndTaggedFence.builder()
                    .geoFenceFeature(f)
                    .build();

            cachedFences.add(individualAndTaggedFence);
        });

        List<IndividualAndTaggedFence> incomingFences = new ArrayList<>();
        cachedFences.forEach(f -> {
            String featureStr = GsonUtils.toJson(f.getGeoFenceFeature());

            GeoFenceFeature feature = fromJson(featureStr);
            feature.getCircle().setRadius(10.0);
            IndividualAndTaggedFence individualAndTaggedFence = IndividualAndTaggedFence.builder()
                    .geoFenceFeature(feature)
                    .build();

            incomingFences.add(individualAndTaggedFence);
        });

        List<IndividualAndTaggedFence> diff = GeoFenceHelper.getDiffOfGeoFences(incomingFences, cachedFences);
        Assert.assertEquals(1, diff.size());
        Assert.assertEquals(diff.get(0).getFenceId(), incomingFences.get(0).getFenceId());
    }

    @Test
    public void testGeoFenceHelper_getIndividualAndTaggedFences_circleUnitChange() {
        List<IndividualAndTaggedFence> cachedFences = new ArrayList<>();
        List<GeoFenceFeature> features = UserPreferenceGenerator.getGeoFenceFeatures("123", true, false, true);

        features.forEach(f -> {
            f.getCircle().setUnit(GeoFenceUnit.KILO_METERS);
            IndividualAndTaggedFence individualAndTaggedFence = IndividualAndTaggedFence.builder()
                    .geoFenceFeature(f)
                    .build();

            cachedFences.add(individualAndTaggedFence);
        });

        List<IndividualAndTaggedFence> incomingFences = new ArrayList<>();
        cachedFences.forEach(f -> {
            String featureStr = GsonUtils.toJson(f.getGeoFenceFeature());

            GeoFenceFeature feature = fromJson(featureStr);
            feature.getCircle().setUnit(GeoFenceUnit.METERS);
            IndividualAndTaggedFence individualAndTaggedFence = IndividualAndTaggedFence.builder()
                    .geoFenceFeature(feature)
                    .build();

            incomingFences.add(individualAndTaggedFence);
        });

        List<IndividualAndTaggedFence> diff = GeoFenceHelper.getDiffOfGeoFences(incomingFences, cachedFences);
        Assert.assertEquals(1, diff.size());
        Assert.assertEquals(diff.get(0).getFenceId(), incomingFences.get(0).getFenceId());
    }

    @Test
    public void testGeoFenceHelper_getLocationSignals_simulator() {
        String vid = GeoFenceData.VIRTUAL_ID;
        Instant instant = Instant.now();
        int numEvents = 1;
        int countOfEachSignal = 1;
        int digitsToIgnore = 3;
        long normalizedTime = DateUtils.normalizeEpochMilli(instant.toEpochMilli(), digitsToIgnore);

        UserPreference primaryUser = UserPreferenceGenerator.getPrimaryUser(vid, true, true);
        List<Telemetry> vehicleStarted = GeoFenceData.getFenceBreachEvents(primaryUser, true, instant, numEvents, countOfEachSignal);


        List<Location> locations = GeoFenceHelper.getLocationSignals(vid, vehicleStarted.get(0), digitsToIgnore, true);

        Assert.assertEquals(countOfEachSignal, locations.size());
        Assert.assertEquals(normalizedTime, locations.get(0).getTimestamp());

    }

    @Test
    public void testGeoFenceHelper_getLocationSignals() {
        String vid = GeoFenceData.VIRTUAL_ID;
        Instant instant = Instant.now();
        int numEvents = 1;
        int countOfEachSignal = 3;
        int digitsToIgnore = 0;

        UserPreference primaryUser = UserPreferenceGenerator.getPrimaryUser(vid, true, true);
        List<Telemetry> vehicleStarted = GeoFenceData.getFenceBreachEvents(primaryUser, true, instant, numEvents, countOfEachSignal);


        List<Location> locations = GeoFenceHelper.getLocationSignals(vid, vehicleStarted.get(0), digitsToIgnore, false);

        Assert.assertEquals(countOfEachSignal, locations.size());

    }
}
