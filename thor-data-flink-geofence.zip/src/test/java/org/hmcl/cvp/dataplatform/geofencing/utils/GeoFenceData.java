package org.hmcl.cvp.dataplatform.geofencing.utils;

import org.apache.commons.compress.harmony.unpack200.bytecode.forms.IincForm;
import org.apache.flink.api.java.tuple.Tuple3;
import org.apache.flink.streaming.runtime.streamrecord.StreamRecord;
import org.hmcl.cvp.dataplatform.commons.catalogue.SignalCatalogue;
import org.hmcl.cvp.dataplatform.commons.testdata.AlertMapping;
import org.hmcl.cvp.dataplatform.commons.testdata.CampaignDataGenerator;
import org.hmcl.cvp.dataplatform.commons.testdata.SignalGenerator;
import org.hmcl.cvp.dataplatform.commons.testdata.UserPreferenceGenerator;
import org.hmcl.cvp.dataplatform.commons.utils.GeoUtils;
import org.hmcl.cvp.dataplatform.commons.utils.SignalUtils;
import org.hmcl.cvp.dataplatform.commons.utils.UserPreferenceUtils;
import org.hmcl.cvp.dataplatform.contract.enriched.AlertNotification;
import org.hmcl.cvp.dataplatform.contract.notification.AlertType;
import org.hmcl.cvp.dataplatform.contract.notification.GeoFenceType;
import org.hmcl.cvp.dataplatform.contract.telemetry.*;
import org.hmcl.cvp.dataplatform.contract.userpreference.*;
import org.hmcl.cvp.dataplatform.geofencing.contract.EnrichedGeoFence;
import org.hmcl.cvp.dataplatform.geofencing.contract.GeoEnrichedTelemetry;
import org.hmcl.cvp.dataplatform.geofencing.contract.Location;
import org.locationtech.jts.geom.Polygon;

import java.time.Instant;
import java.util.*;
import java.util.stream.Collectors;

public class GeoFenceData {

    public static final String VIRTUAL_ID = "test-virtual-id-4";
    public static final String CAMPAIGN_NAME = "thor_alert_cond_v1";

    private GeoFenceData() {
    }

    public static UserPreference tagPrimaryUser(UserPreference preference, String secondaryProfileId) {
        List<GeoFenceFeature> existingFences = preference.getAssignedFeatures().getGeoFenceFeatures();
        existingFences.forEach(f -> f.setTagProfiles(List.of(new TagProfile(secondaryProfileId, true))));

        preference.getAssignedFeatures().setGeoFenceFeatures(existingFences);

        return preference;
    }

    public static Tuple3<Coordinate, GeoFenceFeature, Coordinate> getBengaluruPolygon(String profileId, boolean immobilise) {
        GeoFenceFeature geoFenceFeature = UserPreferenceGenerator.getGeoFenceFeature(profileId,
                AlertMapping.GEOFENCE_BREACH.alertCode(), immobilise);
        geoFenceFeature.setIsFenceTypeCircle(false);

        List<Coordinate> coordinates = new ArrayList<>();

        coordinates.add(new Coordinate(12.916622, 77.572996));
        coordinates.add(new Coordinate(12.957778, 77.566129));
        coordinates.add(new Coordinate(12.986216, 77.698995));
        coordinates.add(new Coordinate(12.884495, 77.684232));
        coordinates.add(new Coordinate(12.916622, 77.572996));

        org.hmcl.cvp.dataplatform.contract.userpreference.Polygon polygon = org.hmcl.cvp.dataplatform.contract.userpreference.Polygon.builder()
                .coordinates(coordinates)
                .build();

        geoFenceFeature.setPolygon(polygon);

        Coordinate inside = new Coordinate(12.937311, 77.626691);
        Coordinate outside = new Coordinate(12.962572, 77.748742);

        return new Tuple3<>(inside, geoFenceFeature, outside);
    }

    public static Tuple3<Coordinate, GeoFenceFeature, Coordinate> getDelhiPolygon(String profileId, boolean immobilise) {
        GeoFenceFeature geoFenceFeature = UserPreferenceGenerator.getGeoFenceFeature(profileId,
                AlertMapping.GEOFENCE_BREACH.alertCode(), immobilise);
        geoFenceFeature.setIsFenceTypeCircle(false);

        List<Coordinate> coordinates = new ArrayList<>();

        coordinates.add(new Coordinate(28.703522, 77.122042));
        coordinates.add(new Coordinate(28.752897, 77.340396));
        coordinates.add(new Coordinate(28.566115, 77.374728));
        coordinates.add(new Coordinate(28.519066, 77.105563));
        coordinates.add(new Coordinate(28.703522, 77.122042));

        org.hmcl.cvp.dataplatform.contract.userpreference.Polygon polygon = org.hmcl.cvp.dataplatform.contract.userpreference.Polygon.builder()
                .coordinates(coordinates)
                .build();

        geoFenceFeature.setPolygon(polygon);

        Coordinate inside = new Coordinate(28.615235, 77.217012);
        Coordinate outside = new Coordinate(28.503361, 77.521282);

        return new Tuple3<>(inside, geoFenceFeature, outside);
    }

    public static Tuple3<Coordinate, GeoFenceFeature, Coordinate> getBengaluruCircle(String profileId, boolean immobilise) {
        GeoFenceFeature geoFenceFeature = UserPreferenceGenerator.getGeoFenceFeature(profileId,
                AlertMapping.GEOFENCE_BREACH.alertCode(), immobilise);
        geoFenceFeature.setIsFenceTypeCircle(true);

        Coordinate center = Coordinate.builder()
                .latitude(12.949691)
                .longitude(77.584419)
                .build();

        Circle circle = Circle.builder()
                .coordinates(center)
                .radius(5.0)
                .unit(GeoFenceUnit.KILO_METERS)
                .build();

        geoFenceFeature.setCircle(circle);

        Coordinate inside = new Coordinate(12.944940,77.569871);
        Coordinate outside = new Coordinate(12.921517,77.695527);

        return new Tuple3<>(inside, geoFenceFeature, outside);
    }

    public static Tuple3<Coordinate, GeoFenceFeature, Coordinate> getMumbaiCircle(String profileId, boolean immobilise) {
        GeoFenceFeature geoFenceFeature = UserPreferenceGenerator.getGeoFenceFeature(profileId,
                AlertMapping.GEOFENCE_BREACH.alertCode(), immobilise);
        geoFenceFeature.setIsFenceTypeCircle(true);

        Coordinate center = Coordinate.builder()
                .latitude(19.075118)
                .longitude(72.869509)
                .build();

        Circle circle = Circle.builder()
                .coordinates(center)
                .radius(5.0)
                .unit(GeoFenceUnit.KILO_METERS)
                .build();

        geoFenceFeature.setCircle(circle);

        Coordinate inside = new Coordinate(19.090043,72.878436);
        Coordinate outside = new Coordinate(19.064086,73.027438);

        return new Tuple3<>(inside, geoFenceFeature, outside);
    }

    public static List<Tuple3<Coordinate, GeoFenceFeature, Coordinate>> getPolygonAndCircle(String profileId, boolean immobilise) {
        List<Tuple3<Coordinate, GeoFenceFeature, Coordinate>> list = new ArrayList<>();
        list.add(getBengaluruPolygon(profileId, immobilise));
        list.add(getBengaluruCircle(profileId, immobilise));
        return list;
    }

    public static List<Tuple3<Coordinate, GeoFenceFeature, Coordinate>> getConcentricCircles(String profileId, boolean immobilise) {
        List<Tuple3<Coordinate, GeoFenceFeature, Coordinate>> list = new ArrayList<>();

        GeoFenceFeature geoFenceFeature1 = UserPreferenceGenerator.getGeoFenceFeature(profileId,
                AlertMapping.GEOFENCE_BREACH.alertCode(), immobilise);
        geoFenceFeature1.setIsFenceTypeCircle(true);

        geoFenceFeature1.setCircle(
                Circle.builder()
                        .coordinates(Coordinate.builder()
                                .latitude(20.930723)
                                .longitude(77.754780)
                                .build())
                .radius(5.0)
                .unit(GeoFenceUnit.KILO_METERS)
                .build());

        Coordinate inside = new Coordinate(20.928515,77.757014);
        Coordinate outside1 = new Coordinate(20.948294,77.837105);

        list.add(new Tuple3<>(inside, geoFenceFeature1, outside1));

        GeoFenceFeature geoFenceFeature2 = UserPreferenceGenerator.getGeoFenceFeature(profileId,
                AlertMapping.GEOFENCE_BREACH.alertCode(), immobilise);
        geoFenceFeature2.setIsFenceTypeCircle(true);

        geoFenceFeature2.setCircle(
                Circle.builder()
                        .coordinates(Coordinate.builder()
                                .latitude(20.930723)
                                .longitude(77.754780)
                                .build())
                        .radius(10.0)
                        .unit(GeoFenceUnit.KILO_METERS)
                        .build());

        Coordinate outside2 = new Coordinate(20.942715,77.892981);
        list.add(new Tuple3<>(inside, geoFenceFeature2, outside2));

        return list;
    }

    public static List<Tuple3<Coordinate, GeoFenceFeature, Coordinate>> getCircleInsidePolygon(String profileId, boolean immobilise) {
        List<Tuple3<Coordinate, GeoFenceFeature, Coordinate>> list = new ArrayList<>();

        GeoFenceFeature geoFenceFeature1 = UserPreferenceGenerator.getGeoFenceFeature(profileId,
                AlertMapping.GEOFENCE_BREACH.alertCode(), immobilise);
        geoFenceFeature1.setIsFenceTypeCircle(true);

        geoFenceFeature1.setCircle(
                Circle.builder()
                        .coordinates(Coordinate.builder()
                                .latitude(26.907253)
                                .longitude(75.789785)
                                .build())
                        .radius(2.0)
                        .unit(GeoFenceUnit.KILO_METERS)
                        .build());

        Coordinate inside = new Coordinate(26.913498,75.755539);
        Coordinate outside1 = new Coordinate(26.960389,75.913467);

        list.add(new Tuple3<>(inside, geoFenceFeature1, outside1));

        GeoFenceFeature geoFenceFeature2 = UserPreferenceGenerator.getGeoFenceFeature(profileId,
                AlertMapping.GEOFENCE_BREACH.alertCode(), immobilise);
        geoFenceFeature2.setIsFenceTypeCircle(false);

        List<Coordinate> coordinates = new ArrayList<>();

        coordinates.add(new Coordinate(27.629451, 75.116449));
        coordinates.add(new Coordinate(27.561296, 76.627069));
        coordinates.add(new Coordinate(26.327321, 77.308221));
        coordinates.add(new Coordinate(26.061154, 75.056024));
        coordinates.add(new Coordinate(27.200342, 73.737665));
        coordinates.add(new Coordinate(27.629451, 75.116449));

        geoFenceFeature2.setPolygon(org.hmcl.cvp.dataplatform.contract.userpreference.Polygon.builder()
                .coordinates(coordinates)
                .build());

        Coordinate outside2 = new Coordinate(28.438025, 74.762920);
        list.add(new Tuple3<>(inside, geoFenceFeature2, outside2));

        return list;
    }

    public static List<Telemetry> getFenceBreachEvents(String campaignName, GeoFenceFeature geoFenceFeature, Instant instant, int numEvents, int countOfEachSignal) {
        List<Telemetry> telemetryData = new ArrayList<>();

        List<Coordinate> coordinates = getOutsideBoundary(geoFenceFeature, countOfEachSignal);

        for (int i = 0; i < numEvents; i++) {
            Telemetry alert = getTelemetry(campaignName,
                    coordinates,
                    instant.plusSeconds(i * 10L),
                    countOfEachSignal
            );

            telemetryData.add(alert);
        }

        return telemetryData;
    }

    public static List<Telemetry> getFenceReEntryEvents(String campaignName, List<Coordinate> coordinates, Instant instant, int numEvents,  int countOfEachSignal) {
        List<Telemetry> telemetryData = new ArrayList<>();

        for (int i = 0; i < numEvents; i++) {
            Telemetry alert = getTelemetry(campaignName,
                    coordinates,
                    instant,
                    countOfEachSignal
            );
            telemetryData.add(alert);
        }

        return telemetryData;
    }

    public static List<StreamRecord<Telemetry>> getTelemetryStreamRecords(List<Telemetry> telemetries) {
        if (telemetries.isEmpty()) return new ArrayList<>();

        return telemetries.stream().map(StreamRecord::new).collect(Collectors.toList());
    }

    public static List<StreamRecord<GeoEnrichedTelemetry>> getGeoStreamRecords(List<GeoEnrichedTelemetry> enrichedTelemetries) {
        if (enrichedTelemetries.isEmpty()) return new ArrayList<>();

        return enrichedTelemetries.stream().map(StreamRecord::new).collect(Collectors.toList());
    }

    public static List<StreamRecord<GeoEnrichedTelemetry>> getGeoStreamRecord(GeoEnrichedTelemetry enrichedTelemetry) {
        return getGeoStreamRecords(List.of(enrichedTelemetry));
    }

    public static List<Telemetry> getTelemetryWithinBoundary(UserPreference userPreference,
                                                             boolean circularFence,
                                                             Instant instant,
                                                             int numEvents,
                                                             int countOfEachSignal) {
        String campaignName = CAMPAIGN_NAME + "_inside";
        GeoFenceFeature geoFenceFeature = getGeoFenceFeature(userPreference, circularFence);
        Polygon polygon = GeoUtils.getShapeFromCoordinate(VIRTUAL_ID, geoFenceFeature);
        assert polygon != null;

        List<org.locationtech.jts.geom.Coordinate> geomCoordinates = new ArrayList<>(Arrays.asList(polygon.getCoordinates()).subList(0, countOfEachSignal));

        List<Coordinate> coordinates = GeoUtils.toCoordinates(geomCoordinates);
        List<Telemetry> campaignData = new ArrayList<>(numEvents);
        for (int i = 0; i < numEvents; i++) {
            campaignData.add(getTelemetry(campaignName, coordinates, instant.plusSeconds(10L * i), countOfEachSignal));
        }

        return campaignData;
    }

    public static List<Telemetry> getFenceBreachEvents(UserPreference user,
                                                       boolean circularFence,
                                                       Instant instant,
                                                       int numEvents,
                                                       int countOfEachSignal) {

        GeoFenceFeature geoFenceFeature = getGeoFenceFeature(user, circularFence);
        String campaignName = CAMPAIGN_NAME + "_outside";
        return getFenceBreachEvents(campaignName, geoFenceFeature, instant, numEvents, countOfEachSignal);
    }

    public static GeoEnrichedTelemetry getBreachNotification(Instant instant, int countOfExistingBreaches) {
        UserPreference userPreference = UserPreferenceGenerator.getPrimaryUser(VIRTUAL_ID);

        List<GeoFenceFeature> geoFenceFeatures = userPreference.getAssignedFeatures().getGeoFenceFeatures();
        GeoFenceFeature geoFenceFeature = geoFenceFeatures.get(0);

        List<Telemetry> telemetryData = getFenceBreachEvents(CAMPAIGN_NAME + "-exit", geoFenceFeature, instant, 1, 1);
        Telemetry telemetry = telemetryData.get(0);
        List<LatLongPair> latLongTime = SignalUtils.getLatitudeLongitudeWithTime(telemetry, 0);

        AlertNotification alertNotification = AlertNotification.builder()
                .alertCode(AlertMapping.GEOFENCE_BREACH.alertCode())
                .alertType(AlertType.VEHICLE_CONTROL)
                .alertName(AlertMapping.GEOFENCE_BREACH.alertName())
                .build();

        GeoEnrichedTelemetry geoEnrichedTelemetry = new GeoEnrichedTelemetry();
        geoEnrichedTelemetry.setTelemetry(telemetry);
        geoEnrichedTelemetry.setNotification(alertNotification);

        for (GeoFenceFeature fenceFeature : geoFenceFeatures) {
            EnrichedGeoFence enrichedGeoFence = EnrichedGeoFence.builder()
                    .geoFenceFeature(fenceFeature)
                    .breachTimestamp(latLongTime.get(0).getTimestamp())
                    .fenceId(fenceFeature.getId())
                    .count(countOfExistingBreaches)
                    .isFirstAlert(countOfExistingBreaches == 1)
                    .fenceType(GeoFenceType.EXIT)
                    .location(Location.builder()
                            .gpsValid(true)
                            .hDop(0.87)
                            .longitude(latLongTime.get(0).getLongitude())
                            .latitude(latLongTime.get(0).getLatitude())
                            .build())
                    .build();
            geoEnrichedTelemetry.addEnrichedGeoFence(enrichedGeoFence);
        }

        return geoEnrichedTelemetry;
    }

    public static GeoEnrichedTelemetry getReEntryNotification(Instant instant, int countOfExistingBreaches) {
        UserPreference userPreference = UserPreferenceGenerator.getPrimaryUser(VIRTUAL_ID);

        List<GeoFenceFeature> geoFenceFeatures = userPreference.getAssignedFeatures().getGeoFenceFeatures();
        GeoFenceFeature geoFenceFeature = geoFenceFeatures.get(0);

        List<Coordinate> coordinates = geoFenceFeature.getIsFenceTypeCircle()
                ? List.of(geoFenceFeature.getCircle().getCoordinates())
                : geoFenceFeature.getPolygon().getCoordinates();

        List<Telemetry> telemetryData = getFenceReEntryEvents(CAMPAIGN_NAME + "-entry", coordinates, instant, 1, 1);
        Telemetry telemetry = telemetryData.get(0);
        List<LatLongPair> latLongTime = SignalUtils.getLatitudeLongitudeWithTime(telemetry, 0);

        AlertNotification alertNotification = AlertNotification.builder()
                .alertCode(AlertMapping.GEOFENCE_BREACH.alertCode())
                .alertType(AlertType.VEHICLE_CONTROL)
                .alertName(AlertMapping.GEOFENCE_BREACH.alertName())
                .build();

        GeoEnrichedTelemetry geoEnrichedTelemetry = new GeoEnrichedTelemetry();
        geoEnrichedTelemetry.setTelemetry(telemetry);
        geoEnrichedTelemetry.setNotification(alertNotification);

        for (GeoFenceFeature fenceFeature : geoFenceFeatures) {
            EnrichedGeoFence enrichedGeoFence = EnrichedGeoFence.builder()
                    .geoFenceFeature(fenceFeature)
                    .breachTimestamp(latLongTime.get(0).getTimestamp())
                    .location(Location.builder()
                            .gpsValid(true)
                            .hDop(0.87)
                            .longitude(latLongTime.get(0).getLongitude())
                            .latitude(latLongTime.get(0).getLatitude())
                            .build())
                    .fenceId(fenceFeature.getId())
                    .count(countOfExistingBreaches)
                    .isFirstAlert(true)
                    .fenceType(GeoFenceType.ENTRY)
                    .build();

            geoEnrichedTelemetry.addEnrichedGeoFence(enrichedGeoFence);
        }

        return geoEnrichedTelemetry;
    }

    public static GeoEnrichedTelemetry getAutoImmobilization(Instant instant, int countOfExistingBreaches) {
        GeoEnrichedTelemetry geoEnrichedTelemetry = getBreachNotification(instant, countOfExistingBreaches);
        Set<EnrichedGeoFence> fences = geoEnrichedTelemetry.getEnrichedGeoFences();
        fences.forEach(v -> v.getGeoFenceFeature().setAutoImmobilisationEnabled(true));
        geoEnrichedTelemetry.setEnrichedGeoFences(fences);
        return geoEnrichedTelemetry;
    }

    public static List<GeoEnrichedTelemetry> getCollectedData(Collection<StreamRecord<GeoEnrichedTelemetry>> testHarnessOutput) {
        return testHarnessOutput.stream().map(StreamRecord::getValue).collect(Collectors.toList());
    }

    public static GeoFenceFeature getGeoFenceFeature(UserPreference userPreference, boolean needCircularFence) {
        List<GeoFenceFeature> geoFenceFeatures = userPreference.getAssignedFeatures().getGeoFenceFeatures();

        if (needCircularFence) {
            GeoFenceFeature circularFenceFeature = null;
            for (GeoFenceFeature geoFenceFeature : geoFenceFeatures) {
                if (geoFenceFeature.getIsFenceTypeCircle()) {
                    circularFenceFeature = geoFenceFeature;
                    break;
                }
            }
            assert Objects.nonNull(circularFenceFeature);
            return circularFenceFeature;
        } else {
            GeoFenceFeature polygonFenceFeature = null;
            for (GeoFenceFeature geoFenceFeature : geoFenceFeatures) {
                if (!geoFenceFeature.getIsFenceTypeCircle()) {
                    polygonFenceFeature = geoFenceFeature;
                    break;
                }
            }
            assert Objects.nonNull(polygonFenceFeature);
            return polygonFenceFeature;
        }

    }

    public static Telemetry getTelemetry(String campaignName,
                                         List<Coordinate> coordinates,
                                         Instant instant,
                                         int countOfEachSignal) {
        Tenant tenant = CampaignDataGenerator.getRandomTenant();
       return getTelemetry(campaignName, coordinates, tenant, instant, countOfEachSignal);
    }

    public static Telemetry getTelemetry(String campaignName,
                                              List<Coordinate> coordinates,
                                              Tenant tenant,
                                              Instant instant,
                                              int countOfEachSignal) {
        Telemetry telemetry = CampaignDataGenerator.getTelemetry(campaignName, VIRTUAL_ID, tenant, countOfEachSignal);
        telemetry.setCollectionEventTime(instant.toEpochMilli());
        Map<String, Set<SignalData>> signals = CampaignDataGenerator.getMandatoryAlertSignals(coordinates, tenant, instant, countOfEachSignal);
        telemetry.setSignals(signals);

        return telemetry;
    }

    public static List<Coordinate> getOutsideBoundary(GeoFenceFeature geoFenceFeature, int countOfEachSignals) {
        Polygon polygon = SignalGenerator.getCoordinatesPolygon(UserPreferenceUtils.getCoordinates(geoFenceFeature),
                geoFenceFeature.getIsFenceTypeCircle(),
                UserPreferenceUtils.getRadius(geoFenceFeature));

        org.locationtech.jts.geom.Coordinate geomCoordinate = polygon.getBoundary().getCoordinate();
        Coordinate coordinate = new Coordinate(geomCoordinate.y + 1, geomCoordinate.x + 1);

        List<Coordinate> outsideCoordinates = new ArrayList<>();
        for (int i = 0; i < countOfEachSignals; i++) {
            outsideCoordinates.add(coordinate);
        }

        return outsideCoordinates;
    }

    public static Telemetry getDummyEvent(Instant instant) {
        Telemetry telemetry = CampaignDataGenerator.getTelemetry(GeoFenceData.VIRTUAL_ID, Tenant.EV, instant, 1);
        telemetry.setCollectionEventTime(instant.toEpochMilli());
        Map<String, Set<SignalData>> signals = telemetry.getSignals();
        removeSignal(signals, SignalCatalogue.getLongitudeInfo());
        removeSignal(signals, SignalCatalogue.getLatitudeInfo());
        removeSignal(signals, SignalCatalogue.getHDopInfo());
        removeSignal(signals, SignalCatalogue.getGpsValidInfo());

        telemetry.setSignals(signals);

        return telemetry;
    }

    public static void removeSignal( Map<String, Set<SignalData>> signals, SignalInfo signalToRemove) {
        signals.remove(signalToRemove.getKey());
    }

    public static String getFenceIdFromUserPreference(UserPreference userPreference, boolean circular) {
        if(Objects.isNull(userPreference)) return null;

        AssignedFeatures assignedFeatures = userPreference.getAssignedFeatures();
        if(Objects.isNull(assignedFeatures)) return null;

        List<GeoFenceFeature> geoFenceFeatures = assignedFeatures.getGeoFenceFeatures();
        if(Objects.isNull(geoFenceFeatures) || geoFenceFeatures.isEmpty()) return null;

        Optional<GeoFenceFeature> geoFenceFeature = geoFenceFeatures.stream().filter(f -> f.getIsFenceTypeCircle() == circular).findFirst();
        return geoFenceFeature.map(GeoFenceFeature::getId).orElse(null);
    }

}
