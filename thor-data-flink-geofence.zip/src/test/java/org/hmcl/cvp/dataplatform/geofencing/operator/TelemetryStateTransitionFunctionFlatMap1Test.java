package org.hmcl.cvp.dataplatform.geofencing.operator;

import org.apache.flink.api.common.state.MapState;
import org.apache.flink.api.common.typeinfo.BasicTypeInfo;
import org.apache.flink.api.java.functions.KeySelector;
import org.apache.flink.api.java.utils.ParameterTool;
import org.apache.flink.runtime.testutils.MiniClusterResourceConfiguration;
import org.apache.flink.streaming.api.operators.co.CoStreamFlatMap;
import org.apache.flink.streaming.runtime.streamrecord.StreamRecord;
import org.apache.flink.streaming.util.KeyedTwoInputStreamOperatorTestHarness;
import org.apache.flink.test.util.MiniClusterWithClientResource;
import org.hmcl.cvp.dataplatform.commons.constants.FlinkRuntime;
import org.hmcl.cvp.dataplatform.commons.testdata.UserPreferenceGenerator;
import org.hmcl.cvp.dataplatform.commons.utils.FlinkUtils;
import org.hmcl.cvp.dataplatform.commons.utils.TelemetryUtils;
import org.hmcl.cvp.dataplatform.commons.utils.UserPreferenceUtils;
import org.hmcl.cvp.dataplatform.contract.telemetry.Telemetry;
import org.hmcl.cvp.dataplatform.contract.userpreference.TagProfile;
import org.hmcl.cvp.dataplatform.contract.userpreference.UserPreference;
import org.hmcl.cvp.dataplatform.geofencing.contract.EnrichedGeoFence;
import org.hmcl.cvp.dataplatform.geofencing.contract.GeoEnrichedTelemetry;
import org.hmcl.cvp.dataplatform.geofencing.contract.VehicleState;
import org.hmcl.cvp.dataplatform.geofencing.utils.GeoFenceData;
import org.junit.Assert;
import org.junit.ClassRule;
import org.junit.Test;
import org.testcontainers.shaded.org.awaitility.Awaitility;

import java.time.Duration;
import java.time.Instant;
import java.util.*;
import java.util.stream.Collectors;

// NOTE
// 1. Add test cases for multiple fences
public class TelemetryStateTransitionFunctionFlatMap1Test {

    @ClassRule
    public static MiniClusterWithClientResource flinkCluster =
            new MiniClusterWithClientResource(
                    new MiniClusterResourceConfiguration.Builder()
                            .setNumberSlotsPerTaskManager(2)
                            .setNumberTaskManagers(1)
                            .build());

    private final KeySelector<Telemetry, String> telemetryKeySelector = TelemetryUtils::getVirtualId;
    private final KeySelector<UserPreference, String> userPreferenceStringKeySelector = UserPreference::getVid;

    TelemetryStateTransitionFunction telemetryStateTransitionFunction = new TelemetryStateTransitionFunction();

    private KeyedTwoInputStreamOperatorTestHarness<String, Telemetry, UserPreference, GeoEnrichedTelemetry> testHarness() throws Exception {
        ParameterTool parameterTool = ParameterTool.fromMap(new HashMap<>());
        parameterTool = FlinkUtils.addProperties(parameterTool, Map.of(FlinkRuntime.GeoFence.WAIT_TIME_AFTER_BREACH_IN_MIN, "5"));
        parameterTool = FlinkUtils.addProperties(parameterTool, Map.of(FlinkRuntime.USER_PREFERENCE_STATE_TTL_IN_DAYS, "1"));
        parameterTool = FlinkUtils.addProperties(parameterTool, Map.of(FlinkRuntime.GEOFENCE_SIMULATOR_RUN, "FALSE"));
        parameterTool = FlinkUtils.addProperties(parameterTool, Map.of(FlinkRuntime.NO_LAST_DIGITS_TO_IGNORE_IN_MILLIS, "0"));
        parameterTool = FlinkUtils.addProperties(parameterTool, Map.of(FlinkRuntime.ENV, "dev"));

        KeyedTwoInputStreamOperatorTestHarness<String, Telemetry, UserPreference, GeoEnrichedTelemetry> testHarness =
                new KeyedTwoInputStreamOperatorTestHarness<>(new CoStreamFlatMap<>(telemetryStateTransitionFunction),
                        telemetryKeySelector,
                        userPreferenceStringKeySelector,
                        BasicTypeInfo.STRING_TYPE_INFO);

        testHarness.getEnvironment().getExecutionConfig().setGlobalJobParameters(parameterTool);

        return testHarness;
    }

    private MapState<String, Map<String, VehicleState>> getVehicleStateMap(KeyedTwoInputStreamOperatorTestHarness<String, Telemetry, UserPreference, GeoEnrichedTelemetry> testHarness) {
        return testHarness.getOperator()
                .getKeyedStateStore()
                .getMapState(MapStateDescriptors.getVehicleStateDescriptor());
    }

    @Test
    public void testTelemetryStateTransitionFunction_vehicleStartedInsidePolygonFence() {
        try (KeyedTwoInputStreamOperatorTestHarness<String, Telemetry, UserPreference, GeoEnrichedTelemetry> testHarness = testHarness()) {

            testHarness.setup();
            testHarness.open();

            vehicleStartedInsideFence(false, true, testHarness);

        } catch (Exception e) {
            throw new RuntimeException(e);
        }

    }

    @Test
    public void testTelemetryStateTransitionFunction_vehicleStartedInsideCircularFence() {
        try (KeyedTwoInputStreamOperatorTestHarness<String, Telemetry, UserPreference, GeoEnrichedTelemetry> testHarness = testHarness()) {

            testHarness.setup();
            testHarness.open();

            vehicleStartedInsideFence(true, false, testHarness);

        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    private void vehicleStartedInsideFence(boolean circular,
                                           boolean polygon,
                                           KeyedTwoInputStreamOperatorTestHarness<String, Telemetry, UserPreference, GeoEnrichedTelemetry> testHarness) throws Exception {

        int numEvents = 1;
        int countOfEachSignal = 1;

        UserPreference primaryUser = UserPreferenceGenerator.getPrimaryUser(GeoFenceData.VIRTUAL_ID, circular, polygon);
        primaryUser.setIsRider(true);
        StreamRecord<UserPreference> primaryRecord = new StreamRecord<>(primaryUser);
        testHarness.processElement2(primaryRecord);

        List<Telemetry> vehicleStart = GeoFenceData.getTelemetryWithinBoundary(primaryUser, circular, Instant.now(), numEvents, countOfEachSignal);
        StreamRecord<Telemetry> campaignRecord = new StreamRecord<>(vehicleStart.get(0));
        testHarness.processElement1(campaignRecord);

        MapState<String, Map<String, VehicleState>> vehicleStateMap = getVehicleStateMap(testHarness);
        Map<String, VehicleState> vehicleState = vehicleStateMap.get(GeoFenceData.VIRTUAL_ID);
        Assert.assertNotNull(vehicleState);
        int count = 0;
        if (circular) count++;
        if (polygon) count++;
        Assert.assertEquals(count, vehicleState.size());

        VehicleState state = vehicleState.values().stream().findFirst().orElse(null);
        Assert.assertNotNull(state);
        Assert.assertEquals(VehicleState.State.IN, state.getStartingState());


        List<GeoEnrichedTelemetry> collectedData = GeoFenceData.getCollectedData(testHarness.getRecordOutput());
        Assert.assertEquals(0, collectedData.size());
    }

    @Test
    public void testTelemetryStateTransitionFunction_vehicleStartedOutsidePolygonFence() {

        try (KeyedTwoInputStreamOperatorTestHarness<String, Telemetry, UserPreference, GeoEnrichedTelemetry> testHarness = testHarness()) {

            testHarness.setup();
            testHarness.open();

            vehicleStartedOutsideFence(false, true, testHarness);

        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    @Test
    public void testTelemetryStateTransitionFunction_vehicleStartedOutsideCircularFence() {
        try (KeyedTwoInputStreamOperatorTestHarness<String, Telemetry, UserPreference, GeoEnrichedTelemetry> testHarness = testHarness()) {

            testHarness.setup();
            testHarness.open();

            vehicleStartedOutsideFence(true, false, testHarness);

        } catch (Exception e) {
            throw new RuntimeException(e);
        }

    }

    private void vehicleStartedOutsideFence(boolean circular,
                                            boolean polygon,
                                            KeyedTwoInputStreamOperatorTestHarness<String, Telemetry, UserPreference, GeoEnrichedTelemetry> testHarness) throws Exception {

        int numEvents = 1;
        int countOfEachSignal = 1;

        UserPreference primaryUser = UserPreferenceGenerator.getPrimaryUser(GeoFenceData.VIRTUAL_ID, circular, polygon);
        primaryUser.setIsRider(true);
        StreamRecord<UserPreference> primaryRecord = new StreamRecord<>(primaryUser);
        testHarness.processElement2(primaryRecord);

        Instant instant = Instant.now();
        List<Telemetry> vehicleStart = GeoFenceData.getFenceBreachEvents(primaryUser, circular, instant, numEvents, countOfEachSignal);
        StreamRecord<Telemetry> campaignRecord = new StreamRecord<>(vehicleStart.get(0));
        testHarness.processElement1(campaignRecord);

        MapState<String, Map<String, VehicleState>> vehicleStateMap = getVehicleStateMap(testHarness);
        Map<String, VehicleState> vehicleState = vehicleStateMap.get(GeoFenceData.VIRTUAL_ID);
        Assert.assertNotNull(vehicleState);
        Assert.assertEquals(1, vehicleState.size());

        VehicleState state = vehicleState.values().stream().findFirst().orElse(null);
        Assert.assertNotNull(state);
        Assert.assertEquals(VehicleState.State.OUT, state.getStartingState());


        List<GeoEnrichedTelemetry> collectedData = GeoFenceData.getCollectedData(testHarness.getRecordOutput());
        Assert.assertEquals(0, collectedData.size());
    }

    @Test
    public void testTelemetryStateTransitionFunction_vehicleEnteredPolygonFence() {
        boolean circular = false;
        boolean polygon = true;

        int numEvents = 1;
        int countOfEachSignal = 3;

        try (KeyedTwoInputStreamOperatorTestHarness<String, Telemetry, UserPreference, GeoEnrichedTelemetry> testHarness = testHarness()) {
            testHarness.setup();
            testHarness.open();

            UserPreference primaryUser = UserPreferenceGenerator.getPrimaryUser(GeoFenceData.VIRTUAL_ID, circular, polygon);
            primaryUser.setIsRider(true);
            StreamRecord<UserPreference> primaryRecord = new StreamRecord<>(primaryUser);
            testHarness.processElement2(primaryRecord);

            Instant vehicleExitedTime = Instant.now().minusSeconds(15 * 60);
            Instant vehicleEnteredTime = vehicleExitedTime.plusSeconds(5 * 60);

            List<Telemetry> vehicleStarted = GeoFenceData.getFenceBreachEvents(primaryUser, circular, vehicleExitedTime, numEvents, countOfEachSignal);
            StreamRecord<Telemetry> vehicleStartedRecord = new StreamRecord<>(vehicleStarted.get(0));
            testHarness.processElement1(vehicleStartedRecord);

            MapState<String, Map<String, VehicleState>> vehicleStateMap = getVehicleStateMap(testHarness);
            Map<String, VehicleState> vehicleState = vehicleStateMap.get(GeoFenceData.VIRTUAL_ID);
            Assert.assertNotNull(vehicleState);
            Assert.assertEquals(1, vehicleState.size());

            // Since vehicle state was empty, no data should be collected
            List<GeoEnrichedTelemetry> collectedData1 = GeoFenceData.getCollectedData(testHarness.getRecordOutput());
            Assert.assertEquals(0, collectedData1.size());

            VehicleState state = vehicleState.values().stream().findFirst().orElse(null);
            Assert.assertNotNull(state);
            Assert.assertEquals(VehicleState.State.OUT, state.getStartingState());

            List<Telemetry> campaignData = GeoFenceData.getTelemetryWithinBoundary(primaryUser, circular, vehicleEnteredTime, numEvents, countOfEachSignal);
            StreamRecord<Telemetry> campaignRecord = new StreamRecord<>(campaignData.get(0));
            testHarness.processElement1(campaignRecord);

            MapState<String, Map<String, VehicleState>> vehicleStateMap1 = getVehicleStateMap(testHarness);
            Map<String, VehicleState> vehicleState1 = vehicleStateMap1.get(GeoFenceData.VIRTUAL_ID);
            Assert.assertNotNull(vehicleState1);
            Assert.assertEquals(1, vehicleState1.size());

            VehicleState state1 = vehicleState1.values().stream().findFirst().orElse(null);
            Assert.assertNotNull(state1);
            Assert.assertEquals(VehicleState.State.IN, state1.getStartingState());

            List<GeoEnrichedTelemetry> collectedData2 = GeoFenceData.getCollectedData(testHarness.getRecordOutput());
            // There should only be one reEntry alert for  multiple lat long signals in a single packet
            Assert.assertEquals(1, collectedData2.size());

        } catch (Exception e) {
            throw new RuntimeException(e);
        }

    }

    @Test
    public void testTelemetryStateTransitionFunction_vehicleEnteredCircularFence() {
        boolean circular = true;
        boolean polygon = false;

        int numEvents = 1;
        int countOfEachSignal = 1;

        try (KeyedTwoInputStreamOperatorTestHarness<String, Telemetry, UserPreference, GeoEnrichedTelemetry> testHarness = testHarness()) {
            testHarness.setup();
            testHarness.open();

            UserPreference primaryUser = UserPreferenceGenerator.getPrimaryUser(GeoFenceData.VIRTUAL_ID, circular, polygon);
            primaryUser.setIsRider(true);
            StreamRecord<UserPreference> primaryRecord = new StreamRecord<>(primaryUser);
            testHarness.processElement2(primaryRecord);

            Instant vehicleExitedTime = Instant.now().minusSeconds(15 * 60);
            Instant vehicleEnteredTime = vehicleExitedTime.plusSeconds(5 * 60);

            List<Telemetry> vehicleStarted = GeoFenceData.getFenceBreachEvents(primaryUser, circular, vehicleExitedTime, numEvents, countOfEachSignal);
            StreamRecord<Telemetry> vehicleStartedRecord = new StreamRecord<>(vehicleStarted.get(0));
            testHarness.processElement1(vehicleStartedRecord);

            MapState<String, Map<String, VehicleState>> vehicleStateMap = getVehicleStateMap(testHarness);
            Map<String, VehicleState> vehicleState = vehicleStateMap.get(GeoFenceData.VIRTUAL_ID);
            Assert.assertNotNull(vehicleState);
            Assert.assertEquals(1, vehicleState.size());

            // Since vehicle state was empty, no data should be collected
            List<GeoEnrichedTelemetry> collectedData1 = GeoFenceData.getCollectedData(testHarness.getRecordOutput());
            Assert.assertEquals(0, collectedData1.size());

            VehicleState state = vehicleState.values().stream().findFirst().orElse(null);
            Assert.assertNotNull(state);
            Assert.assertEquals(VehicleState.State.OUT, state.getStartingState());

            List<Telemetry> campaignData = GeoFenceData.getTelemetryWithinBoundary(primaryUser, circular, vehicleEnteredTime, numEvents, countOfEachSignal);
            StreamRecord<Telemetry> campaignRecord = new StreamRecord<>(campaignData.get(0));
            testHarness.processElement1(campaignRecord);

            MapState<String, Map<String, VehicleState>> vehicleStateMap1 = getVehicleStateMap(testHarness);
            Map<String, VehicleState> vehicleState1 = vehicleStateMap1.get(GeoFenceData.VIRTUAL_ID);
            Assert.assertNotNull(vehicleState1);
            Assert.assertEquals(1, vehicleState1.size());

            VehicleState state1 = vehicleState1.values().stream().findFirst().orElse(null);
            Assert.assertNotNull(state1);
            Assert.assertEquals(VehicleState.State.IN, state1.getStartingState());

            List<GeoEnrichedTelemetry> collectedData2 = GeoFenceData.getCollectedData(testHarness.getRecordOutput());
            Assert.assertEquals(1, collectedData2.size());

        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    @Test
    public void testTelemetryStateTransitionFunction_immobilizationEnabled_vehicleExitedPolygonFence() {
        try (KeyedTwoInputStreamOperatorTestHarness<String, Telemetry, UserPreference, GeoEnrichedTelemetry> testHarness = testHarness()) {

            testHarness.setup();
            testHarness.open();

            vehicleExitedFence(false, true, true, testHarness);

        } catch (Exception e) {
            throw new RuntimeException(e);
        }

    }

    @Test
    public void testTelemetryStateTransitionFunction_immobilizationEnabled_vehicleExitedCircularFence() {
        try (KeyedTwoInputStreamOperatorTestHarness<String, Telemetry, UserPreference, GeoEnrichedTelemetry> testHarness = testHarness()) {

            testHarness.setup();
            testHarness.open();

            vehicleExitedFence(true, false, true, testHarness);

        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    @Test
    public void testTelemetryStateTransitionFunction_immobilizationDisabled_vehicleExitedPolygonFence() {
        try (KeyedTwoInputStreamOperatorTestHarness<String, Telemetry, UserPreference, GeoEnrichedTelemetry> testHarness = testHarness()) {

            testHarness.setup();
            testHarness.open();

            vehicleExitedFence(false, true, false, testHarness);

        } catch (Exception e) {
            throw new RuntimeException(e);
        }

    }

    @Test
    public void testTelemetryStateTransitionFunction_immobilizationDisabled_vehicleExitedCircularFence() {
        try (KeyedTwoInputStreamOperatorTestHarness<String, Telemetry, UserPreference, GeoEnrichedTelemetry> testHarness = testHarness()) {

            testHarness.setup();
            testHarness.open();

            vehicleExitedFence(true, false, false, testHarness);

        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    private void vehicleExitedFence(boolean circular,
                                    boolean polygon,
                                    boolean autoImmobilize,
                                    KeyedTwoInputStreamOperatorTestHarness<String, Telemetry, UserPreference, GeoEnrichedTelemetry> testHarness) throws Exception {

        int numEvents = 1;
        int countOfEachSignal = 3;

        UserPreference primaryUser = UserPreferenceGenerator.getPrimaryUser(GeoFenceData.VIRTUAL_ID, circular, polygon);
        primaryUser.setIsRider(true);
        primaryUser.getAssignedFeatures().getGeoFenceFeatures().forEach(f -> f.setAutoImmobilisationEnabled(autoImmobilize));
        StreamRecord<UserPreference> primaryRecord = new StreamRecord<>(primaryUser);
        testHarness.processElement2(primaryRecord);

        Instant vehicleEnteredTime = Instant.now().minusSeconds(15 * 60);
        Instant vehicleExitTime = vehicleEnteredTime.plusSeconds(5 * 60);

        List<Telemetry> vehicleStarted = GeoFenceData.getTelemetryWithinBoundary(primaryUser, circular, vehicleEnteredTime, numEvents, countOfEachSignal);
        StreamRecord<Telemetry> vehicleStartedRecord = new StreamRecord<>(vehicleStarted.get(0));
        testHarness.processElement1(vehicleStartedRecord);

        List<Telemetry> vehicleExited = GeoFenceData.getFenceBreachEvents(primaryUser, circular, vehicleExitTime, numEvents, countOfEachSignal);
        StreamRecord<Telemetry> vehicleExitedRecord = new StreamRecord<>(vehicleExited.get(0));
        testHarness.processElement1(vehicleExitedRecord);

        MapState<String, Map<String, VehicleState>> vehicleStateMap = getVehicleStateMap(testHarness);
        Map<String, VehicleState> vehicleState = vehicleStateMap.get(GeoFenceData.VIRTUAL_ID);
        Assert.assertNotNull(vehicleState);
        Assert.assertEquals(1, vehicleState.size());

        VehicleState state1 = vehicleState.values().stream().findFirst().orElse(null);
        Assert.assertNotNull(state1);
        Assert.assertEquals(VehicleState.State.EXIT, state1.getTransitionedState());

        List<GeoEnrichedTelemetry> collectedData = GeoFenceData.getCollectedData(testHarness.getRecordOutput());
        if (autoImmobilize) {
            // There should be multiple exit alerts corresponding to the number of lat long signals in each packet
            Assert.assertEquals(countOfEachSignal, collectedData.size());
        } else {
            // Since auto immobilization is disabled, further breaches will not be collected.
            Assert.assertEquals(1, collectedData.size());
        }

    }

    @Test
    public void testTelemetryStateTransitionFunction_userPreferenceUpdatedWithEmptyFences() {
        try (KeyedTwoInputStreamOperatorTestHarness<String, Telemetry, UserPreference, GeoEnrichedTelemetry> testHarness = testHarness()) {

            testHarness.setup();
            testHarness.open();

            sameUserPreferenceUpdatedWithEmptyFences(testHarness);

        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    private void sameUserPreferenceUpdatedWithEmptyFences(KeyedTwoInputStreamOperatorTestHarness<String, Telemetry, UserPreference, GeoEnrichedTelemetry> testHarness) throws Exception {

        int numEvents = 1;
        int countOfEachSignal = 1;

        Instant profileUpdatedTsp1 = Instant.now().minusSeconds(60);

        UserPreference primaryUser1 = UserPreferenceGenerator.getPrimaryUser(GeoFenceData.VIRTUAL_ID, true, false);
        primaryUser1.setIsRider(true);
        primaryUser1.setUpdatedTsp(profileUpdatedTsp1.toEpochMilli());
        StreamRecord<UserPreference> primaryRecord1 = new StreamRecord<>(primaryUser1);
        testHarness.processElement2(primaryRecord1);

        Instant vehicleEnteredTime = Instant.now().minusSeconds(15 * 60);
        Instant vehicleExitTime = vehicleEnteredTime.plusSeconds(5 * 60);
        Instant vehicleEnteredAgainTime = vehicleExitTime.plusSeconds(2 * 60);

        List<Telemetry> vehicleStarted = GeoFenceData.getTelemetryWithinBoundary(primaryUser1, true, vehicleEnteredTime, numEvents, countOfEachSignal);
        StreamRecord<Telemetry> vehicleStartedRecord = new StreamRecord<>(vehicleStarted.get(0));
        testHarness.processElement1(vehicleStartedRecord);

        MapState<String, Map<String, VehicleState>> vehicleStateMap1 = getVehicleStateMap(testHarness);
        Map<String, VehicleState> vehicleState1 = vehicleStateMap1.get(GeoFenceData.VIRTUAL_ID);
        Assert.assertNotNull(vehicleState1);
        VehicleState state1 = vehicleState1.values().stream().findFirst().orElse(null);
        Assert.assertNotNull(state1);
        Assert.assertEquals(VehicleState.State.IN, state1.getStartingState());

        // Resent a userPreference empty geoFences
        Instant profileUpdatedTsp2 = profileUpdatedTsp1.plusSeconds(10);
        UserPreference primaryUser2 = UserPreferenceUtils.deepCopy(primaryUser1);
        assert primaryUser2 != null;
        primaryUser2.setUpdatedTsp(profileUpdatedTsp2.toEpochMilli());
        primaryUser2.getAssignedFeatures().setGeoFenceFeatures(new ArrayList<>());
        StreamRecord<UserPreference> primaryRecord2 = new StreamRecord<>(primaryUser2);
        testHarness.processElement2(primaryRecord2);

        MapState<String, Map<String, VehicleState>> vehicleStateMap2 = getVehicleStateMap(testHarness);
        Map<String, VehicleState> vehicleState2 = vehicleStateMap2.get(GeoFenceData.VIRTUAL_ID);
        Assert.assertEquals(0, vehicleState2.size());

        List<Telemetry> vehicleExited = GeoFenceData.getFenceBreachEvents(primaryUser1, true, vehicleExitTime, numEvents, countOfEachSignal);
        StreamRecord<Telemetry> vehicleExitedRecord = new StreamRecord<>(vehicleExited.get(0));
        testHarness.processElement1(vehicleExitedRecord);

        // No records should be there since there are no fences in the user preference
        MapState<String, Map<String, VehicleState>> vehicleStateMap3 = getVehicleStateMap(testHarness);
        Map<String, VehicleState> vehicleState3 = vehicleStateMap3.get(GeoFenceData.VIRTUAL_ID);
        Assert.assertEquals(0, vehicleState3.size());

        Instant profileUpdatedTsp3 = profileUpdatedTsp2.plusSeconds(10);
        UserPreference primaryUser3 = UserPreferenceUtils.deepCopy(primaryUser1);
        assert primaryUser3 != null;
        primaryUser3.setUpdatedTsp(profileUpdatedTsp3.toEpochMilli());
        StreamRecord<UserPreference> primaryRecord3 = new StreamRecord<>(primaryUser3);
        testHarness.processElement2(primaryRecord3);

        List<Telemetry> vehicleEntered = GeoFenceData.getTelemetryWithinBoundary(primaryUser3, true, vehicleEnteredAgainTime, numEvents, countOfEachSignal);
        StreamRecord<Telemetry> vehicleEnteredRecord = new StreamRecord<>(vehicleEntered.get(0));
        testHarness.processElement1(vehicleEnteredRecord);

        MapState<String, Map<String, VehicleState>> vehicleStateMap4 = getVehicleStateMap(testHarness);
        Map<String, VehicleState> vehicleState4 = vehicleStateMap4.get(GeoFenceData.VIRTUAL_ID);
        Assert.assertEquals(1, vehicleState4.size());

        VehicleState state4 = vehicleState4.values().stream().findFirst().orElse(null);
        Assert.assertNotNull(state4);
        Assert.assertEquals(VehicleState.State.IN, state4.getStartingState());

        List<GeoEnrichedTelemetry> collectedData = GeoFenceData.getCollectedData(testHarness.getRecordOutput());
        // There should be not be any alerts for breaches since just before breach we received updated user preference with [] fences
        Assert.assertEquals(0, collectedData.size());
    }

    @Test
    public void testTelemetryStateTransitionFunction_vehicleMultipleExitsPolygonFence_autoImmobilize() {
        boolean circular = false;
        boolean polygon = true;
        boolean autoImmobilize = true;
        int numOfRecords = 6;
        int countOfEachSignal = 1;

        try (KeyedTwoInputStreamOperatorTestHarness<String, Telemetry, UserPreference, GeoEnrichedTelemetry> testHarness = testHarness()) {

            testHarness.setup();
            testHarness.open();

            UserPreference primaryUser = UserPreferenceGenerator.getPrimaryUser(GeoFenceData.VIRTUAL_ID, circular, polygon);
            primaryUser.setIsRider(true);
            primaryUser.getAssignedFeatures().getGeoFenceFeatures().forEach(f -> f.setAutoImmobilisationEnabled(autoImmobilize));

            StreamRecord<UserPreference> primaryRecord = new StreamRecord<>(primaryUser);
            testHarness.processElement2(primaryRecord);

            Instant vehicleEnteredTime = Instant.now().minusSeconds(15 * 60);
            Instant vehicleExitTime = vehicleEnteredTime.plusSeconds(5 * 60);

            List<Telemetry> vehicleStarted = GeoFenceData.getTelemetryWithinBoundary(primaryUser, circular, vehicleEnteredTime, 1, countOfEachSignal);
            StreamRecord<Telemetry> vehicleStartedRecord = new StreamRecord<>(vehicleStarted.get(0));
            testHarness.processElement1(vehicleStartedRecord);

            List<Telemetry> vehicleExited = GeoFenceData.getFenceBreachEvents(primaryUser, circular, vehicleExitTime, numOfRecords, countOfEachSignal);
            List<StreamRecord<Telemetry>> vehicleExitedRecords = GeoFenceData.getTelemetryStreamRecords(vehicleExited);

            for (int i = 0; i < numOfRecords; i++) {
                testHarness.processElement1(vehicleExitedRecords.get(i));
            }

            MapState<String, Map<String, VehicleState>> vehicleStateMap = getVehicleStateMap(testHarness);
            Map<String, VehicleState> vehicleState = vehicleStateMap.get(GeoFenceData.VIRTUAL_ID);
            Assert.assertNotNull(vehicleState);
            Assert.assertEquals(1, vehicleState.size());

            VehicleState state1 = vehicleState.values().stream().findFirst().orElse(null);
            Assert.assertNotNull(state1);
            Assert.assertEquals(VehicleState.State.EXIT, state1.getTransitionedState());

            List<GeoEnrichedTelemetry> collectedData = GeoFenceData.getCollectedData(testHarness.getRecordOutput());

            Set<Integer> counters = collectedData.stream()
                    .flatMap(g -> g.getEnrichedGeoFences().stream())
                    .map(EnrichedGeoFence::getCount)
                    .sorted()
                    .collect(Collectors.toCollection(LinkedHashSet::new));

            // AutoImmobilization is enabled, then the counters should have increased
            // Each record will have different count
            Assert.assertEquals(numOfRecords, counters.size());
            Assert.assertEquals(numOfRecords, collectedData.size());

        } catch (Exception e) {
            throw new RuntimeException(e);
        }

    }

    @Test
    public void testTelemetryStateTransitionFunction_vehicleMultipleExitsCircularFence_autoImmobilize() {
        boolean circular = true;
        boolean polygon = false;
        boolean autoImmobilize = true;
        int numOfRecords = 6;
        int countOfEachSignal = 1;
        try (KeyedTwoInputStreamOperatorTestHarness<String, Telemetry, UserPreference, GeoEnrichedTelemetry> testHarness = testHarness()) {

            testHarness.setup();
            testHarness.open();

            UserPreference primaryUser = UserPreferenceGenerator.getPrimaryUser(GeoFenceData.VIRTUAL_ID, circular, polygon);
            primaryUser.setIsRider(true);
            primaryUser.getAssignedFeatures().getGeoFenceFeatures().forEach(f -> f.setAutoImmobilisationEnabled(autoImmobilize));

            StreamRecord<UserPreference> primaryRecord = new StreamRecord<>(primaryUser);
            testHarness.processElement2(primaryRecord);

            Instant vehicleEnteredTime = Instant.now().minusSeconds(15 * 60);
            Instant vehicleExitTime = vehicleEnteredTime.plusSeconds(5 * 60);

            List<Telemetry> vehicleStarted = GeoFenceData.getTelemetryWithinBoundary(primaryUser, circular, vehicleEnteredTime, 1, countOfEachSignal);
            StreamRecord<Telemetry> vehicleStartedRecord = new StreamRecord<>(vehicleStarted.get(0));
            testHarness.processElement1(vehicleStartedRecord);

            List<Telemetry> vehicleExited = GeoFenceData.getFenceBreachEvents(primaryUser, circular, vehicleExitTime, numOfRecords, countOfEachSignal);
            List<StreamRecord<Telemetry>> vehicleExitedRecords = GeoFenceData.getTelemetryStreamRecords(vehicleExited);

            for (int i = 0; i < numOfRecords; i++) {
                testHarness.processElement1(vehicleExitedRecords.get(i));
            }

            MapState<String, Map<String, VehicleState>> vehicleStateMap = getVehicleStateMap(testHarness);
            Map<String, VehicleState> vehicleState = vehicleStateMap.get(GeoFenceData.VIRTUAL_ID);
            Assert.assertNotNull(vehicleState);
            Assert.assertEquals(1, vehicleState.size());

            VehicleState state1 = vehicleState.values().stream().findFirst().orElse(null);
            Assert.assertNotNull(state1);
            Assert.assertEquals(VehicleState.State.EXIT, state1.getTransitionedState());

            List<GeoEnrichedTelemetry> collectedData = GeoFenceData.getCollectedData(testHarness.getRecordOutput());

            Set<Integer> counters = collectedData.stream()
                    .flatMap(g -> g.getEnrichedGeoFences().stream())
                    .map(EnrichedGeoFence::getCount)
                    .sorted()
                    .collect(Collectors.toCollection(LinkedHashSet::new));

            // AutoImmobilization is enabled, then the counters should have increased
            // Each record will have different count
            Assert.assertEquals(numOfRecords, counters.size());
            Assert.assertEquals(numOfRecords, collectedData.size());

        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    @Test
    public void testTelemetryStateTransitionFunction_vehicleMultipleExitsPolygonFence_autoImmobilizeDisabled() throws Exception {
        boolean circular = false;
        boolean polygon = true;
        boolean autoImmobilize = false;
        int numOfRecords = 6;
        int countOfEachSignal = 1;
        try (KeyedTwoInputStreamOperatorTestHarness<String, Telemetry, UserPreference, GeoEnrichedTelemetry> testHarness = testHarness()) {

            testHarness.setup();
            testHarness.open();

            UserPreference primaryUser = UserPreferenceGenerator.getPrimaryUser(GeoFenceData.VIRTUAL_ID, circular, polygon);
            primaryUser.setIsRider(true);
            primaryUser.getAssignedFeatures().getGeoFenceFeatures().forEach(f -> f.setAutoImmobilisationEnabled(autoImmobilize));

            StreamRecord<UserPreference> primaryRecord = new StreamRecord<>(primaryUser);
            testHarness.processElement2(primaryRecord);

            Instant vehicleEnteredTime = Instant.now().minusSeconds(15 * 60);
            Instant vehicleExitTime = vehicleEnteredTime.plusSeconds(5 * 60);

            List<Telemetry> vehicleStarted = GeoFenceData.getTelemetryWithinBoundary(primaryUser, circular, vehicleEnteredTime, 1, countOfEachSignal);
            StreamRecord<Telemetry> vehicleStartedRecord = new StreamRecord<>(vehicleStarted.get(0));
            testHarness.processElement1(vehicleStartedRecord);

            List<Telemetry> vehicleExited = GeoFenceData.getFenceBreachEvents(primaryUser, circular, vehicleExitTime, numOfRecords, countOfEachSignal);
            List<StreamRecord<Telemetry>> vehicleExitedRecords = GeoFenceData.getTelemetryStreamRecords(vehicleExited);

            for (int i = 0; i < numOfRecords; i++) {
                testHarness.processElement1(vehicleExitedRecords.get(i));
            }

            MapState<String, Map<String, VehicleState>> vehicleStateMap = getVehicleStateMap(testHarness);
            Map<String, VehicleState> vehicleState = vehicleStateMap.get(GeoFenceData.VIRTUAL_ID);
            Assert.assertNotNull(vehicleState);
            Assert.assertEquals(1, vehicleState.size());

            VehicleState state1 = vehicleState.values().stream().findFirst().orElse(null);
            Assert.assertNotNull(state1);
            Assert.assertEquals(VehicleState.State.EXIT, state1.getTransitionedState());

            List<GeoEnrichedTelemetry> collectedData = GeoFenceData.getCollectedData(testHarness.getRecordOutput());

            Set<Integer> counters = collectedData.stream()
                    .flatMap(g -> g.getEnrichedGeoFences().stream())
                    .map(EnrichedGeoFence::getCount)
                    .sorted()
                    .collect(Collectors.toCollection(LinkedHashSet::new));

            // AutoImmobilization is enabled, then the counters should have increased
            // Since auto immobilization is disabled, each record will same count
            Assert.assertEquals(1, counters.size());
            Assert.assertEquals(1, collectedData.size());

        } catch (Exception e) {
            throw new RuntimeException(e);
        } finally {
            testHarness().close();
        }
    }

    @Test
    public void testTelemetryStateTransitionFunction_vehicleMultipleExitsCircularFence_autoImmobilizeDisabled() throws Exception {
        boolean circular = true;
        boolean polygon = false;
        boolean autoImmobilize = false;
        int numOfRecords = 6;
        int countOfEachSignal = 1;

        try (KeyedTwoInputStreamOperatorTestHarness<String, Telemetry, UserPreference, GeoEnrichedTelemetry> testHarness = testHarness()) {

            testHarness.setup();
            testHarness.open();

            UserPreference primaryUser = UserPreferenceGenerator.getPrimaryUser(GeoFenceData.VIRTUAL_ID, circular, polygon);
            primaryUser.setIsRider(true);
            primaryUser.getAssignedFeatures().getGeoFenceFeatures().forEach(f -> f.setAutoImmobilisationEnabled(autoImmobilize));

            StreamRecord<UserPreference> primaryRecord = new StreamRecord<>(primaryUser);
            testHarness.processElement2(primaryRecord);

            Instant vehicleEnteredTime = Instant.now().minusSeconds(15 * 60);
            Instant vehicleExitTime = vehicleEnteredTime.plusSeconds(5 * 60);

            List<Telemetry> vehicleStarted = GeoFenceData.getTelemetryWithinBoundary(primaryUser, circular, vehicleEnteredTime, 1, countOfEachSignal);
            StreamRecord<Telemetry> vehicleStartedRecord = new StreamRecord<>(vehicleStarted.get(0));
            testHarness.processElement1(vehicleStartedRecord);

            List<Telemetry> vehicleExited = GeoFenceData.getFenceBreachEvents(primaryUser, circular, vehicleExitTime, numOfRecords, countOfEachSignal);
            List<StreamRecord<Telemetry>> vehicleExitedRecords = GeoFenceData.getTelemetryStreamRecords(vehicleExited);

            for (int i = 0; i < numOfRecords; i++) {
                testHarness.processElement1(vehicleExitedRecords.get(i));
            }

            MapState<String, Map<String, VehicleState>> vehicleStateMap = getVehicleStateMap(testHarness);
            Map<String, VehicleState> vehicleState = vehicleStateMap.get(GeoFenceData.VIRTUAL_ID);
            Assert.assertNotNull(vehicleState);
            Assert.assertEquals(1, vehicleState.size());

            VehicleState state1 = vehicleState.values().stream().findFirst().orElse(null);
            Assert.assertNotNull(state1);
            Assert.assertEquals(VehicleState.State.EXIT, state1.getTransitionedState());

            List<GeoEnrichedTelemetry> collectedData = GeoFenceData.getCollectedData(testHarness.getRecordOutput());

            Set<Integer> counters = collectedData.stream()
                    .flatMap(g -> g.getEnrichedGeoFences().stream())
                    .map(EnrichedGeoFence::getCount)
                    .sorted()
                    .collect(Collectors.toCollection(LinkedHashSet::new));

            // AutoImmobilization is enabled, then the counters should have increased
            // Since auto immobilization is disabled, each record will same count
            Assert.assertEquals(1, counters.size());
            Assert.assertEquals(1, collectedData.size());

        } catch (Exception e) {
            throw new RuntimeException(e);
        } finally {
            testHarness().close();
        }
    }

    @Test
    public void testTelemetryStateTransitionFunction_vehicleExitAndReEntryPolygonFence_autoImmobilize() {
        try (KeyedTwoInputStreamOperatorTestHarness<String, Telemetry, UserPreference, GeoEnrichedTelemetry> testHarness = testHarness()) {

            testHarness.setup();
            testHarness.open();

            vehicleMultipleExitsAndReEntry(false, true, true, testHarness);

        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    @Test
    public void testTelemetryStateTransitionFunction_vehicleExitAndReEntryCircularFence_autoImmobilize() {
        try (KeyedTwoInputStreamOperatorTestHarness<String, Telemetry, UserPreference, GeoEnrichedTelemetry> testHarness = testHarness()) {

            testHarness.setup();
            testHarness.open();

            vehicleMultipleExitsAndReEntry(true, false, true, testHarness);

        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    @Test
    public void testTelemetryStateTransitionFunction_vehicleExitAndReEntryPolygonFence_autoImmobilizeDisabled() {
        try (KeyedTwoInputStreamOperatorTestHarness<String, Telemetry, UserPreference, GeoEnrichedTelemetry> testHarness = testHarness()) {

            testHarness.setup();
            testHarness.open();

            vehicleMultipleExitsAndReEntry(false, true, false, testHarness);

        } catch (Exception e) {
            throw new RuntimeException(e);
        }

    }

    @Test
    public void testTelemetryStateTransitionFunction_vehicleExitAndReEntryCircularFence_autoImmobilizeDisabled() {
        try (KeyedTwoInputStreamOperatorTestHarness<String, Telemetry, UserPreference, GeoEnrichedTelemetry> testHarness = testHarness()) {

            testHarness.setup();
            testHarness.open();

            vehicleMultipleExitsAndReEntry(true, false, false, testHarness);

        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    private void vehicleMultipleExitsAndReEntry(boolean circular,
                                                boolean polygon,
                                                boolean autoImmobilize,
                                                KeyedTwoInputStreamOperatorTestHarness<String, Telemetry, UserPreference, GeoEnrichedTelemetry> testHarness) throws Exception {
        int numOfRecords = 6;
        int numOfEntries = 2;
        int countOfEachSignal = 1;

        UserPreference primaryUser = UserPreferenceGenerator.getPrimaryUser(GeoFenceData.VIRTUAL_ID, circular, polygon);
        primaryUser.setIsRider(true);
        primaryUser.getAssignedFeatures().getGeoFenceFeatures().forEach(f -> f.setAutoImmobilisationEnabled(autoImmobilize));

        StreamRecord<UserPreference> primaryRecord = new StreamRecord<>(primaryUser);
        testHarness.processElement2(primaryRecord);

        Instant vehicleEnteredTime = Instant.now().minusSeconds(15 * 60);
        Instant vehicleExitTime = vehicleEnteredTime.plusSeconds(5 * 60);

        List<Telemetry> vehicleStarted = GeoFenceData.getTelemetryWithinBoundary(primaryUser, circular, vehicleEnteredTime, 1, countOfEachSignal);
        StreamRecord<Telemetry> vehicleStartedRecord = new StreamRecord<>(vehicleStarted.get(0));
        testHarness.processElement1(vehicleStartedRecord);

        List<Telemetry> vehicleExited = GeoFenceData.getFenceBreachEvents(primaryUser, circular, vehicleExitTime, numOfRecords, countOfEachSignal);
        List<StreamRecord<Telemetry>> vehicleExitedRecords = GeoFenceData.getTelemetryStreamRecords(vehicleExited);

        for (int i = 0; i < numOfRecords; i++) {
            testHarness.processElement1(vehicleExitedRecords.get(i));
        }

        Instant vehicleReEnteredTime = vehicleExitTime.plusSeconds(2 * 60);
        Instant vehicleExitedAgainTime = vehicleReEnteredTime.plusSeconds(2 * 60);

        List<Telemetry> vehicleReEntered = GeoFenceData.getTelemetryWithinBoundary(primaryUser, circular, vehicleReEnteredTime, numOfEntries, countOfEachSignal);
        List<StreamRecord<Telemetry>> vehicleReEnteredRecord = GeoFenceData.getTelemetryStreamRecords(vehicleReEntered);
        for (int i = 0; i < numOfEntries; i++) {
            testHarness.processElement1(vehicleReEnteredRecord.get(i));
        }

        List<Telemetry> vehicleExitedAgain = GeoFenceData.getFenceBreachEvents(primaryUser, circular, vehicleExitedAgainTime, numOfRecords, countOfEachSignal);
        List<StreamRecord<Telemetry>> vehicleExitedAgainRecords = GeoFenceData.getTelemetryStreamRecords(vehicleExitedAgain);

        for (int i = 0; i < numOfRecords; i++) {
            testHarness.processElement1(vehicleExitedAgainRecords.get(i));
        }

        MapState<String, Map<String, VehicleState>> vehicleStateMap = getVehicleStateMap(testHarness);
        Map<String, VehicleState> vehicleState = vehicleStateMap.get(GeoFenceData.VIRTUAL_ID);
        Assert.assertNotNull(vehicleState);
        Assert.assertEquals(1, vehicleState.size());

        VehicleState state1 = vehicleState.values().stream().findFirst().orElse(null);
        Assert.assertNotNull(state1);
        Assert.assertEquals(VehicleState.State.IN, state1.getStartingState());

        List<GeoEnrichedTelemetry> collectedData = GeoFenceData.getCollectedData(testHarness.getRecordOutput());
        long totalExitAlerts = collectedData.stream()
                .flatMap(g -> g.getEnrichedGeoFences().stream())
                .filter(EnrichedGeoFence::isExit)
                .count();

        long firstTimeAlerts = collectedData.stream()
                .flatMap(g -> g.getEnrichedGeoFences().stream())
                .filter(EnrichedGeoFence::getIsFirstAlert)
                .count();

        long entryAlerts = collectedData.stream()
                .flatMap(g -> g.getEnrichedGeoFences().stream())
                .filter(EnrichedGeoFence::isEntry)
                .count();

        if (autoImmobilize) {
            int total = (numOfRecords * 2) + 1;
            Assert.assertEquals(total, collectedData.size());
            Assert.assertEquals(3, firstTimeAlerts);
            Assert.assertEquals((numOfRecords * 2), totalExitAlerts);
            Assert.assertEquals(1, entryAlerts);
        } else {
            Assert.assertEquals(3, collectedData.size());
            Assert.assertEquals(3, firstTimeAlerts);
            Assert.assertEquals(2, totalExitAlerts);
            Assert.assertEquals(1, entryAlerts);
        }

    }

    @Test
    public void testVehicleExitedTaggedAndIndividualCircularFencesForSecondary_autoImmobilizeDisabled() {
        try (KeyedTwoInputStreamOperatorTestHarness<String, Telemetry, UserPreference, GeoEnrichedTelemetry> testHarness = testHarness()) {

            testHarness.setup();
            testHarness.open();

            vehicleExitedTaggedAndIndividualFencesForSecondary(true, false, false, testHarness);

        } catch (Exception e) {
            throw new RuntimeException(e);
        }

    }

    @Test
    public void testVehicleExitedTaggedAndIndividualCircularFencesForSecondary_autoImmobilize() {
        try (KeyedTwoInputStreamOperatorTestHarness<String, Telemetry, UserPreference, GeoEnrichedTelemetry> testHarness = testHarness()) {

            testHarness.setup();
            testHarness.open();

            vehicleExitedTaggedAndIndividualFencesForSecondary(true, false, true, testHarness);

        } catch (Exception e) {
            throw new RuntimeException(e);
        }

    }

    @Test
    public void testVehicleExitedTaggedAndIndividualPolygonFencesForSecondary_autoImmobilizeDisabled() {
        try (KeyedTwoInputStreamOperatorTestHarness<String, Telemetry, UserPreference, GeoEnrichedTelemetry> testHarness = testHarness()) {

            testHarness.setup();
            testHarness.open();

            vehicleExitedTaggedAndIndividualFencesForSecondary(false, true, false, testHarness);

        } catch (Exception e) {
            throw new RuntimeException(e);
        }

    }

    @Test
    public void testVehicleExitedTaggedAndIndividualPolygonFencesForSecondary_autoImmobilize() {
        try (KeyedTwoInputStreamOperatorTestHarness<String, Telemetry, UserPreference, GeoEnrichedTelemetry> testHarness = testHarness()) {

            testHarness.setup();
            testHarness.open();

            vehicleExitedTaggedAndIndividualFencesForSecondary(false, true, true, testHarness);

        } catch (Exception e) {
            throw new RuntimeException(e);
        }

    }

    private void vehicleExitedTaggedAndIndividualFencesForSecondary(boolean circular,
                                                                    boolean polygon,
                                                                    boolean autoImmobilize,
                                                                    KeyedTwoInputStreamOperatorTestHarness<String, Telemetry, UserPreference, GeoEnrichedTelemetry> testHarness) throws Exception {

        int numEntryEvents = 1;
        int numBreachEvents = 1;
        int countOfEachSignal = 3;
        double radius = 10.5;

        Instant instant = Instant.now().minusSeconds(60);
        UserPreference primaryUser = UserPreferenceGenerator.getPrimaryUser(GeoFenceData.VIRTUAL_ID, circular, polygon);
        String secondaryTaggedFenceId = GeoFenceData.getFenceIdFromUserPreference(primaryUser, circular);
        primaryUser.setIsRider(false);
        primaryUser.setUpdatedTsp(instant.toEpochMilli());
        primaryUser.getAssignedFeatures().getGeoFenceFeatures().forEach(f -> f.setAutoImmobilisationEnabled(autoImmobilize));

        // Secondary User is the rider
        UserPreference secondaryRider = UserPreferenceGenerator.getSecondaryUser(GeoFenceData.VIRTUAL_ID, circular, polygon);
        secondaryRider.setIsRider(true);
        secondaryRider.setUpdatedTsp(instant.plusSeconds(30).toEpochMilli());
        secondaryRider.getAssignedFeatures().getGeoFenceFeatures().forEach(f -> f.setAutoImmobilisationEnabled(autoImmobilize));
        String secondaryFenceId = GeoFenceData.getFenceIdFromUserPreference(secondaryRider, circular);

        // Tag secondary user to the primary fence
        String secondaryProfileId = secondaryRider.getProfileId();
        List<TagProfile> tagProfiles = new ArrayList<>();
        TagProfile tagProfile = TagProfile.builder().taggedProfileId(secondaryProfileId).optInForNotification(true).build();
        tagProfiles.add(tagProfile);
        primaryUser.getAssignedFeatures().getGeoFenceFeatures().forEach(f -> f.setTagProfiles(tagProfiles));

        if (circular) {
            primaryUser.getAssignedFeatures().getGeoFenceFeatures().get(0).getCircle().setRadius(radius);
            secondaryRider.getAssignedFeatures().getGeoFenceFeatures().get(0).getCircle().setRadius(radius);
        }

        StreamRecord<UserPreference> primaryRecord = new StreamRecord<>(primaryUser);
        testHarness.processElement2(primaryRecord);

        Awaitility.await()
                .timeout(Duration.ofSeconds(3))
                .pollDelay(Duration.ofSeconds(2))
                .untilAsserted(() -> Assert.assertTrue(true));

        StreamRecord<UserPreference> secondaryRecord = new StreamRecord<>(secondaryRider);
        testHarness.processElement2(secondaryRecord);

        Instant vehicleEnteredTime = Instant.now().minusSeconds(15 * 60);
        Instant vehicleExitTime = vehicleEnteredTime.plusSeconds(5 * 60);

        List<Telemetry> vehicleStarted = GeoFenceData.getTelemetryWithinBoundary(primaryUser, circular, vehicleEnteredTime, numEntryEvents, countOfEachSignal);
        StreamRecord<Telemetry> vehicleStartedRecord = new StreamRecord<>(vehicleStarted.get(0));
        testHarness.processElement1(vehicleStartedRecord);

        Awaitility.await()
                .timeout(Duration.ofSeconds(3))
                .pollDelay(Duration.ofSeconds(2))
                .untilAsserted(() -> Assert.assertTrue(true));

        List<Telemetry> vehicleExited = GeoFenceData.getFenceBreachEvents(primaryUser, circular, vehicleExitTime, numBreachEvents, countOfEachSignal);
        StreamRecord<Telemetry> vehicleExitedRecord = new StreamRecord<>(vehicleExited.get(0));
        testHarness.processElement1(vehicleExitedRecord);

        MapState<String, Map<String, VehicleState>> vehicleStateMap = getVehicleStateMap(testHarness);
        Map<String, VehicleState> vehicleState = vehicleStateMap.get(GeoFenceData.VIRTUAL_ID);
        Assert.assertNotNull(vehicleState);
        Assert.assertEquals(2, vehicleState.size());
        Assert.assertTrue(vehicleState.containsKey(secondaryTaggedFenceId));
        Assert.assertTrue(vehicleState.containsKey(secondaryFenceId));

        VehicleState secondaryTaggedFenceState = vehicleState.get(secondaryTaggedFenceId);
        VehicleState secondaryFenceState = vehicleState.get(secondaryFenceId);

        Assert.assertNotNull(secondaryTaggedFenceState);
        Assert.assertEquals(VehicleState.State.IN, secondaryTaggedFenceState.getStartingState());
        Assert.assertEquals(VehicleState.State.EXIT, secondaryTaggedFenceState.getTransitionedState());

        Assert.assertNotNull(secondaryFenceState);
        Assert.assertEquals(VehicleState.State.IN, secondaryFenceState.getStartingState());
        Assert.assertEquals(VehicleState.State.EXIT, secondaryFenceState.getTransitionedState());

        List<GeoEnrichedTelemetry> collectedData = GeoFenceData.getCollectedData(testHarness.getRecordOutput());
        if (autoImmobilize) {
            // There should be multiple exit alerts corresponding to the number of lat long signals in each packet
            Assert.assertEquals(countOfEachSignal, collectedData.size());
        } else {
            // Since auto immobilization is disabled, further breaches will not be collected.
            Assert.assertEquals(1, collectedData.size());
            // Since there are 2 fences - one tagged and one individual
            Set<EnrichedGeoFence> enrichedGeoFences = collectedData.get(0).getEnrichedGeoFences();
            Assert.assertEquals(2, enrichedGeoFences.size());
            Assert.assertTrue(enrichedGeoFences.stream().anyMatch(f -> f.getFenceId().equals(secondaryTaggedFenceId)));
            Assert.assertTrue(enrichedGeoFences.stream().anyMatch(f -> f.getFenceId().equals(secondaryFenceId)));

            EnrichedGeoFence taggedFence = enrichedGeoFences.stream()
                    .filter(f -> f.getFenceId().equals(secondaryTaggedFenceId)).findFirst().orElse(null);

            EnrichedGeoFence individualFence = enrichedGeoFences.stream()
                    .filter(f -> f.getFenceId().equals(secondaryTaggedFenceId)).findFirst().orElse(null);

            Assert.assertNotNull(taggedFence);
            Assert.assertNotNull(individualFence);
            Assert.assertTrue(taggedFence.getIsFirstAlert());
            Assert.assertTrue(individualFence.getIsFirstAlert());

        }

    }

    @Test
    public void testVehicleExitedTaggedAndIndividualCircularFencesForSecondary_withoutSecondaryChange_autoImmobilizeDisabled() {
        try (KeyedTwoInputStreamOperatorTestHarness<String, Telemetry, UserPreference, GeoEnrichedTelemetry> testHarness = testHarness()) {

            testHarness.setup();
            testHarness.open();

            vehicleExitedTaggedAndIndividualFencesForSecondary_withoutSecondaryChange(true, false, false, testHarness);

        } catch (Exception e) {
            throw new RuntimeException(e);
        }

    }

    @Test
    public void testVehicleExitedTaggedAndIndividualCircularFencesForSecondary_withoutSecondaryChange_autoImmobilize() {
        try (KeyedTwoInputStreamOperatorTestHarness<String, Telemetry, UserPreference, GeoEnrichedTelemetry> testHarness = testHarness()) {

            testHarness.setup();
            testHarness.open();

            vehicleExitedTaggedAndIndividualFencesForSecondary_withoutSecondaryChange(true, false, true, testHarness);

        } catch (Exception e) {
            throw new RuntimeException(e);
        }

    }

    @Test
    public void testVehicleExitedTaggedAndIndividualPolygonFencesForSecondary_withoutSecondaryChange_autoImmobilizeDisabled() {
        try (KeyedTwoInputStreamOperatorTestHarness<String, Telemetry, UserPreference, GeoEnrichedTelemetry> testHarness = testHarness()) {

            testHarness.setup();
            testHarness.open();

            vehicleExitedTaggedAndIndividualFencesForSecondary_withoutSecondaryChange(false, true, false, testHarness);

        } catch (Exception e) {
            throw new RuntimeException(e);
        }

    }

    @Test
    public void testVehicleExitedTaggedAndIndividualPolygonFencesForSecondary_withoutSecondaryChange_autoImmobilize() {
        try (KeyedTwoInputStreamOperatorTestHarness<String, Telemetry, UserPreference, GeoEnrichedTelemetry> testHarness = testHarness()) {

            testHarness.setup();
            testHarness.open();

            vehicleExitedTaggedAndIndividualFencesForSecondary_withoutSecondaryChange(false, true, true, testHarness);

        } catch (Exception e) {
            throw new RuntimeException(e);
        }

    }

    private void vehicleExitedTaggedAndIndividualFencesForSecondary_withoutSecondaryChange(boolean circular,
                                                                                           boolean polygon,
                                                                                           boolean autoImmobilize,
                                                                                           KeyedTwoInputStreamOperatorTestHarness<String, Telemetry, UserPreference, GeoEnrichedTelemetry> testHarness) throws Exception {

        int numEntryEvents = 1;
        int numBreachEvents = 1;
        int countOfEachSignal = 3;
        double radius = 10.5;

        Instant instant = Instant.now().minusSeconds(60);
        UserPreference primaryUser = UserPreferenceGenerator.getPrimaryUser(GeoFenceData.VIRTUAL_ID, circular, polygon);
        String secondaryTaggedFenceId = GeoFenceData.getFenceIdFromUserPreference(primaryUser, circular);
        primaryUser.setIsRider(false);
        primaryUser.setUpdatedTsp(instant.toEpochMilli());
        primaryUser.getAssignedFeatures().getGeoFenceFeatures().forEach(f -> f.setAutoImmobilisationEnabled(autoImmobilize));

        // Secondary User is the rider
        UserPreference secondaryRider = UserPreferenceGenerator.getSecondaryUser(GeoFenceData.VIRTUAL_ID, circular, polygon);
        secondaryRider.setIsRider(true);
        secondaryRider.setUpdatedTsp(instant.plusSeconds(30).toEpochMilli());
        secondaryRider.getAssignedFeatures().getGeoFenceFeatures().forEach(f -> f.setAutoImmobilisationEnabled(autoImmobilize));
        String secondaryFenceId = GeoFenceData.getFenceIdFromUserPreference(secondaryRider, circular);

        if (circular) {
            primaryUser.getAssignedFeatures().getGeoFenceFeatures().get(0).getCircle().setRadius(radius);
            secondaryRider.getAssignedFeatures().getGeoFenceFeatures().get(0).getCircle().setRadius(radius);
        }

        StreamRecord<UserPreference> primaryRecord = new StreamRecord<>(primaryUser);
        testHarness.processElement2(primaryRecord);

        Awaitility.await()
                .timeout(Duration.ofSeconds(3))
                .pollDelay(Duration.ofSeconds(2))
                .untilAsserted(() -> Assert.assertTrue(true));

        StreamRecord<UserPreference> secondaryRecord = new StreamRecord<>(secondaryRider);
        testHarness.processElement2(secondaryRecord);

        UserPreference primaryUser1 = UserPreferenceUtils.deepCopy(primaryUser);
        assert primaryUser1 != null;
        primaryUser1.setUpdatedTsp(instant.plusSeconds(10).toEpochMilli());

        // Tag secondary user to the primary fence
        String secondaryProfileId = secondaryRider.getProfileId();
        List<TagProfile> tagProfiles = new ArrayList<>();
        TagProfile tagProfile = TagProfile.builder().taggedProfileId(secondaryProfileId).optInForNotification(true).build();
        tagProfiles.add(tagProfile);
        primaryUser1.getAssignedFeatures().getGeoFenceFeatures().forEach(f -> f.setTagProfiles(tagProfiles));

        StreamRecord<UserPreference> primaryRecord1 = new StreamRecord<>(primaryUser1);
        testHarness.processElement2(primaryRecord1);

        Instant vehicleEnteredTime = Instant.now().minusSeconds(15 * 60);
        Instant vehicleExitTime = vehicleEnteredTime.plusSeconds(5 * 60);

        List<Telemetry> vehicleStarted = GeoFenceData.getTelemetryWithinBoundary(primaryUser, circular, vehicleEnteredTime, numEntryEvents, countOfEachSignal);
        StreamRecord<Telemetry> vehicleStartedRecord = new StreamRecord<>(vehicleStarted.get(0));
        testHarness.processElement1(vehicleStartedRecord);

        Awaitility.await()
                .timeout(Duration.ofSeconds(3))
                .pollDelay(Duration.ofSeconds(2))
                .untilAsserted(() -> Assert.assertTrue(true));

        List<Telemetry> vehicleExited = GeoFenceData.getFenceBreachEvents(primaryUser, circular, vehicleExitTime, numBreachEvents, countOfEachSignal);
        StreamRecord<Telemetry> vehicleExitedRecord = new StreamRecord<>(vehicleExited.get(0));
        testHarness.processElement1(vehicleExitedRecord);

        MapState<String, Map<String, VehicleState>> vehicleStateMap = getVehicleStateMap(testHarness);
        Map<String, VehicleState> vehicleState = vehicleStateMap.get(GeoFenceData.VIRTUAL_ID);
        Assert.assertNotNull(vehicleState);
        Assert.assertEquals(2, vehicleState.size());
        Assert.assertTrue(vehicleState.containsKey(secondaryTaggedFenceId));
        Assert.assertTrue(vehicleState.containsKey(secondaryFenceId));

        VehicleState secondaryTaggedFenceState = vehicleState.get(secondaryTaggedFenceId);
        VehicleState secondaryFenceState = vehicleState.get(secondaryFenceId);

        Assert.assertNotNull(secondaryTaggedFenceState);
        Assert.assertEquals(VehicleState.State.IN, secondaryTaggedFenceState.getStartingState());
        Assert.assertEquals(VehicleState.State.EXIT, secondaryTaggedFenceState.getTransitionedState());

        Assert.assertNotNull(secondaryFenceState);
        Assert.assertEquals(VehicleState.State.IN, secondaryFenceState.getStartingState());
        Assert.assertEquals(VehicleState.State.EXIT, secondaryFenceState.getTransitionedState());

        List<GeoEnrichedTelemetry> collectedData = GeoFenceData.getCollectedData(testHarness.getRecordOutput());
        if (autoImmobilize) {
            // There should be multiple exit alerts corresponding to the number of lat long signals in each packet
            Assert.assertEquals(countOfEachSignal, collectedData.size());
        } else {
            // Since auto immobilization is disabled, further breaches will not be collected.
            Assert.assertEquals(1, collectedData.size());
            // Since there are 2 fences - one tagged and one individual
            Set<EnrichedGeoFence> enrichedGeoFences = collectedData.get(0).getEnrichedGeoFences();
            Assert.assertEquals(2, enrichedGeoFences.size());
            Assert.assertTrue(enrichedGeoFences.stream().anyMatch(f -> f.getFenceId().equals(secondaryTaggedFenceId)));
            Assert.assertTrue(enrichedGeoFences.stream().anyMatch(f -> f.getFenceId().equals(secondaryFenceId)));

            EnrichedGeoFence taggedFence = enrichedGeoFences.stream()
                    .filter(f -> f.getFenceId().equals(secondaryTaggedFenceId)).findFirst().orElse(null);

            EnrichedGeoFence individualFence = enrichedGeoFences.stream()
                    .filter(f -> f.getFenceId().equals(secondaryTaggedFenceId)).findFirst().orElse(null);

            Assert.assertNotNull(taggedFence);
            Assert.assertNotNull(individualFence);
            Assert.assertTrue(taggedFence.getIsFirstAlert());
            Assert.assertTrue(individualFence.getIsFirstAlert());

        }

    }

    @Test
    public void primaryRiderWithAllTaggedFences() {

        try (KeyedTwoInputStreamOperatorTestHarness<String, Telemetry, UserPreference, GeoEnrichedTelemetry> testHarness = testHarness()) {

            testHarness.setup();
            testHarness.open();

            int numEvents = 1;
            int countOfEachSignal = 3;

            UserPreference primaryUser = UserPreferenceGenerator.getPrimaryUser(GeoFenceData.VIRTUAL_ID, true, true);
            primaryUser.setIsRider(true);
            UserPreference taggedPrimaryUser = GeoFenceData.tagPrimaryUser(primaryUser, "abc");
            StreamRecord<UserPreference> primaryRecord = new StreamRecord<>(taggedPrimaryUser);
            testHarness.processElement2(primaryRecord);

            Instant vehicleEnteredTime = Instant.now().minusSeconds(15 * 60);
            Instant vehicleExitTime = vehicleEnteredTime.plusSeconds(5 * 60);

            List<Telemetry> vehicleStarted = GeoFenceData.getTelemetryWithinBoundary(taggedPrimaryUser, true, vehicleEnteredTime, numEvents, countOfEachSignal);
            StreamRecord<Telemetry> vehicleStartedRecord = new StreamRecord<>(vehicleStarted.get(0));
            testHarness.processElement1(vehicleStartedRecord);

            List<Telemetry> vehicleExited = GeoFenceData.getFenceBreachEvents(taggedPrimaryUser, true, vehicleExitTime, numEvents, countOfEachSignal);
            StreamRecord<Telemetry> vehicleExitedRecord = new StreamRecord<>(vehicleExited.get(0));
            testHarness.processElement1(vehicleExitedRecord);

            MapState<String, Map<String, VehicleState>> vehicleStateMap = getVehicleStateMap(testHarness);
            Map<String, VehicleState> vehicleState = vehicleStateMap.get(GeoFenceData.VIRTUAL_ID);
            Assert.assertNull(vehicleState);

            // Since all the fences are tagged fences
            List<GeoEnrichedTelemetry> collectedData = GeoFenceData.getCollectedData(testHarness.getRecordOutput());
            Assert.assertEquals(0, collectedData.size());

        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }


    @Test
    public void UserPreferenceState_nullCheck() {
        try (KeyedTwoInputStreamOperatorTestHarness<String, Telemetry, UserPreference, GeoEnrichedTelemetry> testHarness = testHarness()) {

            testHarness.setup();
            testHarness.open();

            StreamRecord<Telemetry> campaignRecord = new StreamRecord<>(null);
            testHarness.processElement1(campaignRecord);


        } catch (Exception e) {
            throw new RuntimeException(e);
        }

    }
}
