package org.hmcl.cvp.dataplatform.geofencing.operator;

import org.apache.flink.runtime.jobgraph.OperatorID;
import org.apache.flink.runtime.metrics.groups.InternalOperatorMetricGroup;
import org.apache.flink.runtime.metrics.util.InterceptingOperatorMetricGroup;
import org.apache.flink.runtime.metrics.util.InterceptingTaskMetricGroup;
import org.apache.flink.runtime.operators.testutils.MockEnvironment;
import org.apache.flink.runtime.operators.testutils.MockEnvironmentBuilder;
import org.apache.flink.runtime.testutils.MiniClusterResourceConfiguration;
import org.apache.flink.streaming.api.operators.StreamFlatMap;
import org.apache.flink.streaming.runtime.streamrecord.StreamRecord;
import org.apache.flink.streaming.util.OneInputStreamOperatorTestHarness;
import org.apache.flink.test.util.MiniClusterWithClientResource;
import org.hmcl.cvp.dataplatform.geofencing.contract.GeoEnrichedTelemetry;
import org.hmcl.cvp.dataplatform.geofencing.utils.GeoFenceData;
import org.junit.Assert;
import org.junit.ClassRule;
import org.junit.Test;

import java.time.Instant;
import java.util.List;

public class GeoFenceNotificationFunctionTest {

    @ClassRule
    public static MiniClusterWithClientResource flinkCluster =
            new MiniClusterWithClientResource(
                    new MiniClusterResourceConfiguration.Builder()
                            .setNumberSlotsPerTaskManager(2)
                            .setNumberTaskManagers(1)
                            .build());

    private final InterceptingOperatorMetricGroup interceptingOperatorMetricGroup = new InterceptingOperatorMetricGroup();
    private final InterceptingTaskMetricGroup interceptingTaskMetricGroup = new InterceptingTaskMetricGroup() {
        @Override
        public InternalOperatorMetricGroup getOrAddOperator(OperatorID operatorID, String name) {
            return interceptingOperatorMetricGroup;
        }
    };

    private final MockEnvironment mockEnvironment = new MockEnvironmentBuilder().setMetricGroup(interceptingTaskMetricGroup).build();

    private final GeoFenceNotificationFunction geoFenceNotificationFunction = new GeoFenceNotificationFunction();

    @Test
    public void testGeoFenceNotificationFunction_noNotification() {

        try (OneInputStreamOperatorTestHarness<GeoEnrichedTelemetry, String> testHarness
                     = new OneInputStreamOperatorTestHarness<>(new StreamFlatMap<>(geoFenceNotificationFunction), mockEnvironment)) {
            testHarness.setup();
            testHarness.open();

            GeoEnrichedTelemetry enrichedTelemetry = GeoFenceData.getBreachNotification(Instant.now(), 3);
            List<StreamRecord<GeoEnrichedTelemetry>> streamRecords = GeoFenceData.getGeoStreamRecord(enrichedTelemetry);

            testHarness.processElements(streamRecords);

            Assert.assertEquals(0, testHarness.getOutput().size());
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    @Test
    public void testGeoFenceNotificationFunction_alertNotification() {
        try (OneInputStreamOperatorTestHarness<GeoEnrichedTelemetry, String> testHarness
                     = new OneInputStreamOperatorTestHarness<>(new StreamFlatMap<>(geoFenceNotificationFunction), mockEnvironment)) {
            testHarness.setup();
            testHarness.open();

            GeoEnrichedTelemetry enrichedTelemetry = GeoFenceData.getBreachNotification(Instant.now(), 1);
            List<StreamRecord<GeoEnrichedTelemetry>> streamRecords = List.of(new StreamRecord<>(enrichedTelemetry));

            testHarness.processElements(streamRecords);

            Assert.assertEquals(2, testHarness.getOutput().size());
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    @Test
    public void testGeoFenceNotificationFunction_reEntryNotification() {
        try (OneInputStreamOperatorTestHarness<GeoEnrichedTelemetry, String> testHarness
                     = new OneInputStreamOperatorTestHarness<>(new StreamFlatMap<>(geoFenceNotificationFunction), mockEnvironment)) {
            testHarness.setup();
            testHarness.open();

            GeoEnrichedTelemetry enrichedTelemetry = GeoFenceData.getReEntryNotification(Instant.now(), 1);
            List<StreamRecord<GeoEnrichedTelemetry>> streamRecords = List.of(new StreamRecord<>(enrichedTelemetry));

            testHarness.processElements(streamRecords);

            Assert.assertEquals(2, testHarness.getOutput().size());
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

}
