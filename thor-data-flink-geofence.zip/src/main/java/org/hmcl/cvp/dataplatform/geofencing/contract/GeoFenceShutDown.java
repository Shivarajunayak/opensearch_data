package org.hmcl.cvp.dataplatform.geofencing.contract;

import com.google.gson.annotations.SerializedName;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class GeoFenceShutDown implements Serializable {

    @SerializedName("vehicleIdentifier")
    private String vehicleIdentifier;

    @SerializedName("profileId")
    private String profileId;

    @SerializedName("userType")
    private UserType userType;

    @SerializedName("commandCode")
    private String commandCode;

    @SerializedName("value")
    private Boolean value;

    @SerializedName("commandType")
    private CommandType commandType;

    @SerializedName("commandSource")
    private CommandSource commandSource;

    @SerializedName("commandExecutionTimeout")
    private Long commandExecutionTimeout;

    public static GeoFenceShutDown withDefaults(String code) {
        GeoFenceShutDown geoFenceShutDown = new GeoFenceShutDown();
        geoFenceShutDown.setCommandCode(code); // this code is for auto-immobilise and de-mobilise
        geoFenceShutDown.setUserType(UserType.SYSTEM);
        geoFenceShutDown.setCommandType(CommandType.NON_UDS);
        geoFenceShutDown.setCommandSource(CommandSource.FENCE_BREACH);
        geoFenceShutDown.setValue(true);
        return geoFenceShutDown;
    }

}
