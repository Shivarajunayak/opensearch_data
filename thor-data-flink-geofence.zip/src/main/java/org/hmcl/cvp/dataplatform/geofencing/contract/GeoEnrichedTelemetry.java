package org.hmcl.cvp.dataplatform.geofencing.contract;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.hmcl.cvp.dataplatform.contract.enriched.EnrichedTelemetry;

import java.util.HashSet;
import java.util.List;
import java.util.Objects;
import java.util.Set;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class GeoEnrichedTelemetry extends EnrichedTelemetry {

    // Provision for multiple breaches
    private Set<EnrichedGeoFence> enrichedGeoFences;

    public static GeoEnrichedTelemetry fromEnrichedTelemetry(EnrichedTelemetry enrichedTelemetry) {
        // Cloning the enrichedTelemetry object
        // Here no need for deep copy,since GeoEnrichedTelemetry will act as wrapper around enrichedTelemetry only.
        GeoEnrichedTelemetry geoEnrichedTelemetry = new GeoEnrichedTelemetry();
        geoEnrichedTelemetry.setTelemetry(enrichedTelemetry.getTelemetry());
        geoEnrichedTelemetry.setUserPreferences(enrichedTelemetry.getUserPreferences());
        geoEnrichedTelemetry.setNotification(enrichedTelemetry.getNotification());
        return geoEnrichedTelemetry;
    }

    public void addEnrichedGeoFence(EnrichedGeoFence fence) {
        Set<EnrichedGeoFence> existingFences = getEnrichedGeoFences();
        existingFences.add(fence);
        this.enrichedGeoFences = existingFences;
    }

    public Set<EnrichedGeoFence> getEnrichedGeoFences() {
        if (Objects.isNull(this.enrichedGeoFences)) return new HashSet<>();
        return this.enrichedGeoFences;
    }

    public void setEnrichedGeoFences(List<EnrichedGeoFence> fences) {
        enrichedGeoFences = new HashSet<>();
        enrichedGeoFences.addAll(fences);
    }

    public void setEnrichedGeoFences(Set<EnrichedGeoFence> fences) {
        enrichedGeoFences = new HashSet<>();
        enrichedGeoFences.addAll(fences);
    }

    @Override
    public boolean equals(Object obj) {
        return super.equals(obj);
    }

    @Override
    public int hashCode() {
        return super.hashCode();
    }
}
