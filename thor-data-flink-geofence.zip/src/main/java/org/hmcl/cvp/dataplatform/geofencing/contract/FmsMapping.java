package org.hmcl.cvp.dataplatform.geofencing.contract;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public enum FmsMapping {

    GEOFENCE_BREACH("geofence-breach"),

    AUTO_IMMOBILIZATION("auto-immobilization"),

    ;

    private static final Map<String, FmsMapping> CONSTANTS = new HashMap<>();

    private final String value;

    FmsMapping(String value) {
        this.value = value;
    }

    static {
        for (FmsMapping c : values()) {
            CONSTANTS.put(c.value, c);
        }
    }

    public static List<FmsMapping> getAllFmsMapping() {
        return new ArrayList<>(CONSTANTS.values());
    }

    public String value() {
        return value;
    }


}
