package org.hmcl.cvp.dataplatform.geofencing.operator;

import org.apache.flink.api.common.state.MapStateDescriptor;
import org.apache.flink.api.common.typeinfo.TypeHint;
import org.apache.flink.api.common.typeinfo.TypeInformation;
import org.hmcl.cvp.dataplatform.commons.utils.FlinkUtils;
import org.hmcl.cvp.dataplatform.geofencing.contract.GeoEnrichedTelemetry;
import org.hmcl.cvp.dataplatform.geofencing.contract.GeoUserPreference;
import org.hmcl.cvp.dataplatform.geofencing.contract.VehicleState;

import java.util.Map;

public class MapStateDescriptors {

    private MapStateDescriptors() {
    }

    public static MapStateDescriptor<String, Map<String, GeoUserPreference>> userPreferenceMapStateDescriptor() {
        return new MapStateDescriptor<>("userPreferenceMapState",
                TypeInformation.of(String.class),
                TypeInformation.of(new TypeHint<Map<String, GeoUserPreference>>() {
                })
        );
    }

    public static MapStateDescriptor<String, Long> getLastProcessedTimeDescriptor() {
        return new MapStateDescriptor<>("lastProcessedTimeMapState",
                TypeInformation.of(String.class),
                TypeInformation.of(new TypeHint<Long>() {
                })
        );
    }

    public static MapStateDescriptor<String, Map<String, VehicleState>> getVehicleStateDescriptor() {
        return new MapStateDescriptor<>("vehicleStateWRTFencesMapState",
                TypeInformation.of(String.class),
                TypeInformation.of(new TypeHint<Map<String, VehicleState>>() {
                })
        );
    }

    public static MapStateDescriptor<String, Map<String, Integer>> getBreachedAlertsCounterDescriptor() {
        return new MapStateDescriptor<>("breachedAlertsCounterMapState",
                TypeInformation.of(String.class),
                TypeInformation.of(new TypeHint<Map<String, Integer>>() {
                })
        );
    }

    public static MapStateDescriptor<String, GeoEnrichedTelemetry> getGeoFenceAlertsDescriptor(long ttlInMin) {
        MapStateDescriptor<String, GeoEnrichedTelemetry> geoFenceAlertsDescriptor = new MapStateDescriptor<>("breachedAlertsMapState",
                TypeInformation.of(String.class),
                TypeInformation.of(new TypeHint<GeoEnrichedTelemetry>() {
                })
        );
        geoFenceAlertsDescriptor.enableTimeToLive(FlinkUtils.getStateTTLInMinsConfig(ttlInMin));
        return geoFenceAlertsDescriptor;
    }
}
