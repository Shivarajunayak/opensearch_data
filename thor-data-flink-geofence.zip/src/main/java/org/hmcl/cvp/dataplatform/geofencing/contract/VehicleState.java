package org.hmcl.cvp.dataplatform.geofencing.contract;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;
import java.util.Objects;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class VehicleState {

    private String profileId;

    private boolean isTagged;

    private String primaryProfileId;

    private String fenceId;

    private State startingState;

    private State transitionedState;

    public boolean getIsTagged() {
        return isTagged;
    }

    public void setIsTagged(boolean tagged) {
        isTagged = tagged;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof VehicleState)) return false;
        VehicleState that = (VehicleState) o;
        return Objects.equals(profileId, that.profileId) && Objects.equals(fenceId, that.fenceId);
    }

    @Override
    public int hashCode() {
        return Objects.hash(profileId, fenceId);
    }

    public enum State {
        IN,
        OUT,
        ENTRY,
        EXIT,
        UNKNOWN;

        public static List<State> transitionValues() {
            return List.of(EXIT, ENTRY);
        }
    }
}
