package org.hmcl.cvp.dataplatform.geofencing.contract;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.hmcl.cvp.dataplatform.contract.userpreference.UserPreference;

import java.util.List;
import java.util.Objects;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class GeoUserPreference {

    private UserPreference userPreference;

    private List<IndividualAndTaggedFence> relatedFences;

    private List<FenceAndPolygon> fencesAndPolygons;

    public boolean isRider() {
        if (Objects.isNull(userPreference)) return false;
        return userPreference.getIsRider();
    }

    public String getProfileId() {
        if (Objects.isNull(userPreference)) return null;
        return userPreference.getProfileId();
    }

    public long getUpdatedTsp() {
        if (Objects.isNull(userPreference)) return 0;
        return userPreference.getUpdatedTsp();
    }
}
