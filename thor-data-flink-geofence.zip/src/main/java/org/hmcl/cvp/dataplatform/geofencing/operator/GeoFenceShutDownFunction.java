package org.hmcl.cvp.dataplatform.geofencing.operator;


import com.google.gson.Gson;
import lombok.extern.slf4j.Slf4j;
import org.apache.flink.api.common.state.MapState;
import org.apache.flink.api.common.state.MapStateDescriptor;
import org.apache.flink.api.java.utils.ParameterTool;
import org.apache.flink.configuration.Configuration;
import org.apache.flink.metrics.Counter;
import org.apache.flink.streaming.api.functions.KeyedProcessFunction;
import org.apache.flink.util.Collector;
import org.hmcl.cvp.dataplatform.commons.constants.Constants;
import org.hmcl.cvp.dataplatform.commons.constants.FlinkRuntime;
import org.hmcl.cvp.dataplatform.commons.utils.DateUtils;
import org.hmcl.cvp.dataplatform.commons.utils.GsonUtils;
import org.hmcl.cvp.dataplatform.contract.userpreference.GeoFenceFeature;
import org.hmcl.cvp.dataplatform.geofencing.contract.GeoFenceShutDown;
import org.hmcl.cvp.dataplatform.geofencing.contract.EnrichedGeoFence;
import org.hmcl.cvp.dataplatform.geofencing.contract.GeoEnrichedTelemetry;
import org.hmcl.cvp.dataplatform.geofencing.helper.FmsMappingHelper;

import java.util.*;
import java.util.stream.Collectors;

/**
 * Immobilizing the earliest breach
 */
@Slf4j
public class GeoFenceShutDownFunction extends KeyedProcessFunction<String, GeoEnrichedTelemetry, String> {

    private static final Gson GSON = GsonUtils.getGson();

    private transient Counter numInputImmobizeEventCounter;

    private transient int minWaitTimeAfterBreach;
    private transient int numBreachesForImmobilise;
    private transient String env;
    private transient String commandCode;

    /**
     * Stores the first breached telemetry for a vehicle
     * This state will be cleared for the VirtualId for the following
     * 1. 5 alerts
     * 2. Trigger
     * 3. 5 min
     * Key - VirtualId
     * Value - GeoEnrichedTelemetry
     */
    private transient MapState<String, GeoEnrichedTelemetry> breachedAlertsState;

    private Counter counterInitializer() {
        return getRuntimeContext()
                .getMetricGroup()
                .addGroup(Constants.METRIC_GROUP_NAME)
                .addGroup("GeoFenceShutDown")
                .counter("numImmobilizeEvents");
    }

    @Override
    public void open(Configuration parameters) throws Exception {
        super.open(parameters);

        final ParameterTool parameterTool = (ParameterTool) getRuntimeContext().getExecutionConfig().getGlobalJobParameters();
        minWaitTimeAfterBreach = parameterTool.getInt(FlinkRuntime.GeoFence.WAIT_TIME_AFTER_BREACH_IN_MIN, 5);
        numBreachesForImmobilise = parameterTool.getInt(FlinkRuntime.GeoFence.NUM_OF_BREACHES_FOR_IMMOBILISATION, 5);
        env = parameterTool.getRequired(FlinkRuntime.ENV);

        numInputImmobizeEventCounter = counterInitializer();

        long ttlInMin = minWaitTimeAfterBreach + 5L;
        MapStateDescriptor<String, GeoEnrichedTelemetry> breachedAlerts = MapStateDescriptors.getGeoFenceAlertsDescriptor(ttlInMin);
        breachedAlertsState = getRuntimeContext().getMapState(breachedAlerts);

        // Get Command mapping
        log.info("Fetching alert mappings for env {}", env);
        commandCode = FmsMappingHelper.getAutoImmobilizationCode(env);
    }

    @Override
    public void processElement(GeoEnrichedTelemetry value, Context ctx, Collector<String> out) {
        String vid = ctx.getCurrentKey();

        long watermark = ctx.timerService().currentWatermark();
        long timestamp = ctx.timestamp();
        log.debug("For vehicle {}, Current timestamp is {} and current watermark is {}", vid, timestamp, watermark);

        // Register first time breaches with the timer service and update state
        registerFirstBreachesInTimerAndState(vid, value, watermark, ctx);

        // Checking for reEntries and clearing timer and states accordingly
        checkForReEntries(vid, value, ctx);

        // Get the fences with 6 breaches (one more than numBreachesForImmobilise)  and auto immobilize enabled
        int numBreachesToConsiderForImmobilise =  numBreachesForImmobilise + 1;
        List<EnrichedGeoFence> autoImmobilizeFences = value.getEnrichedGeoFences().stream()
                .filter(e -> Objects.nonNull(e.getGeoFenceFeature()))
                .filter(v -> v.getGeoFenceFeature().isAutoImmobilisationEnabled() && v.getCount() == numBreachesToConsiderForImmobilise)
                .collect(Collectors.toList());

        EnrichedGeoFence earliestBreach = autoImmobilizeFences.stream()
                .min(Comparator.comparingLong(EnrichedGeoFence::getBreachTimestamp))
                .orElse(null);

        GeoFenceShutDown shutDownCommand = getGeoFenceShutDown(vid, earliestBreach);
        if (Objects.nonNull(shutDownCommand)) {

            log.info("Sending AutoImmobilization command since more than specified number of breaches detected for vehicle {}", vid);
            out.collect(GSON.toJson(shutDownCommand));
            numInputImmobizeEventCounter.inc();

            log.debug("Clearing existing state since more than specified number of breaches detected for {}", vid);
            removeState(vid);
        }

    }

    @Override
    public void onTimer(long timestamp, OnTimerContext ctx, Collector<String> out) throws Exception {
        super.onTimer(timestamp, ctx, out);
        try {
            String vid = ctx.getCurrentKey();
            log.debug("Timer triggered for vehicle {} at {}", vid, timestamp);

            GeoEnrichedTelemetry geoEnrichedTelemetry = getCachedEnrichedTelemetry(vid);
            if (Objects.isNull(geoEnrichedTelemetry)) return;

            // Set ordered by the lat-long timestamp to get the earliest fences
            Set<EnrichedGeoFence> breaches = geoEnrichedTelemetry.getEnrichedGeoFences().stream()
                    .filter(EnrichedGeoFence::isExit)
                    .sorted(Comparator.comparingLong(EnrichedGeoFence::getBreachTimestamp))
                    .collect(Collectors.toCollection(LinkedHashSet::new));

            if (breaches.isEmpty()) {
                log.debug("No exit fence alerts found in cache in OnTimer method for vehicle {}", vid);
                return;
            }

            GeoFenceShutDown shutDownCommand = null;
            log.info("DEBUGLOG geoEnriched telemtetry {} for vehicle {} at timestamp {}",
                    geoEnrichedTelemetry, vid, timestamp);
            log.info("DEBUGLOG before going into breaches loop, breaches size is {} for vehicle {} at timestamp {}, breaches ==> {}",
                    breaches.size(), vid, timestamp, breaches);
            for (EnrichedGeoFence breach : breaches) {
                log.info("DEBUGLOG current processing breach {} for vid: {}", breach, vid);

                GeoFenceFeature geoFenceFeature = breach.getGeoFenceFeature();
                log.info("DEBUGLOG geoFenceFeature.isAutoImmobilisationEnabled() {} for vid: {}", geoFenceFeature.isAutoImmobilisationEnabled(), vid);

                if (geoFenceFeature.isAutoImmobilisationEnabled() && breach.getTriggerTime() >= timestamp) {

                    removeState(vid);

                    // One immobilization command should be sent. So keep resetting this object
                    shutDownCommand = getGeoFenceShutDown(vid, breach);
                }
            }

            if (Objects.nonNull(shutDownCommand)) {
                log.info("Sending AutoImmobilization command for {} since it has been more than 5 min outside fence", vid);
                out.collect(GSON.toJson(shutDownCommand));
                numInputImmobizeEventCounter.inc();
            }
        } catch (Exception e) {
            log.error("Ontimer exception for vehicle {} at timestamp {}",
                    ctx.getCurrentKey(), timestamp, e);
        }

    }

    private void registerFirstBreachesInTimerAndState(String vid, GeoEnrichedTelemetry value, long currentWatermark, Context ctx) {
        Set<EnrichedGeoFence> firstBreaches = value.getEnrichedGeoFences().stream()
                .filter(v -> v.getIsFirstAlert() && v.isExit())
                .collect(Collectors.toSet());

        if (firstBreaches.isEmpty()) return;

        if(currentWatermark < 0) {
            long newWatermark = value.getTelemetry().getCollectionEventTime();
            log.debug("For vehicle {} since watermark {} is less than zero, considering collectionEventTime {} instead", vid, currentWatermark, newWatermark);
            currentWatermark = newWatermark;
        }

        long triggerTime = getTriggerTime(currentWatermark);
        log.debug("Found first time breaches for {}. Registering timer services at {}", vid, triggerTime);
        ctx.timerService().registerEventTimeTimer(triggerTime);

        log.debug("Updating state for {}", vid);
        firstBreaches.forEach(v -> {
            v.setTriggerTime(triggerTime);
            updateState(vid, value, v);
        });
    }

    private void checkForReEntries(String vid, GeoEnrichedTelemetry value, Context ctx) {

        try {
            Set<EnrichedGeoFence> reEntries = value.getEnrichedGeoFences().stream()
                    .filter(EnrichedGeoFence::isEntry)
                    .collect(Collectors.toSet());

            if (reEntries.isEmpty()) return;


            Optional<GeoEnrichedTelemetry> stateValue = Optional.ofNullable(breachedAlertsState.get(vid));

            log.debug("State value found for {}. Checking if any fences were re-entered and removing them from state", vid);
            stateValue.ifPresent(geoEnrichedTelemetry -> deRegisterTimersAndState(vid, geoEnrichedTelemetry, reEntries, ctx));
        } catch (Exception e) {
            log.error("Exception while accessing state for vehicle {}", vid, e);
        }

    }

    public void deRegisterTimersAndState(String vid, GeoEnrichedTelemetry stateValue, Set<EnrichedGeoFence> reEntries, Context ctx) {
        Set<EnrichedGeoFence> stateFences = stateValue.getEnrichedGeoFences();

        if (stateFences.isEmpty()) return;

        log.debug("Checking if timers need to be De-registered for {}.", vid);
        reEntries.forEach(reEntry -> {

            String reEntryFenceId = reEntry.getFenceId();
            Optional<EnrichedGeoFence> stateFence = stateFences.stream()
                    .filter(f -> Objects.nonNull(f.getGeoFenceFeature()))
                    .filter(f -> reEntryFenceId != null && reEntryFenceId.equals(f.getFenceId()))
                    .findFirst();

            if (stateFence.isPresent() && (reEntry.getBreachTimestamp() > stateFence.get().getBreachTimestamp())) {
                log.debug("De-registering timer for fence {} since the timestamp is latest for vehicle {}.", reEntryFenceId, vid);
                ctx.timerService().deleteEventTimeTimer(stateFence.get().getTriggerTime());

                removeState(vid, reEntry);
            }
        });
    }

    private long getTriggerTime(long timestamp) {
        return DateUtils.addMinutes(timestamp, minWaitTimeAfterBreach);
    }

    private GeoEnrichedTelemetry getCachedEnrichedTelemetry(String vid) {

        try {
            return breachedAlertsState.get(vid);
        } catch (Exception e) {
            log.error("Exception while updating state for vehicle {}", vid, e);
        }

        return null;
    }

    private void updateState(String vid, GeoEnrichedTelemetry value, EnrichedGeoFence fence) {
        try {

            GeoEnrichedTelemetry existingValue = getCachedEnrichedTelemetry(vid);

            if (Objects.nonNull(existingValue)) {
                log.debug("State already exists for {}", vid);
                existingValue.addEnrichedGeoFence(fence);
            } else {
                log.debug("No previous state exists for {}", vid);
                breachedAlertsState.put(vid, value);
            }

        } catch (Exception e) {
            log.error("Exception while updating state for vehicle {}", vid, e);
        }

    }

    private void removeState(String vid, EnrichedGeoFence fence) {
        try {
            if (breachedAlertsState.contains(vid)) {
                log.debug("State exists for {}", vid);
                GeoEnrichedTelemetry existingValue = breachedAlertsState.get(vid);
                Set<EnrichedGeoFence> stateFences = existingValue.getEnrichedGeoFences();
                stateFences.remove(fence);

                if (stateFences.isEmpty()) {
                    log.debug("No fence states exist for {}. Removing state", vid);
                    breachedAlertsState.remove(vid);
                } else {
                    existingValue.setEnrichedGeoFences(stateFences);
                }
            }
        } catch (Exception e) {
            log.error("Exception while clearing state for vehicle {}", vid, e);
        }

    }

    private void removeState(String vid) {
        try {
            if (breachedAlertsState.contains(vid)) {
                log.debug("Removing state for vehicle {} since auto immob may have been triggered or reEntry may have been detected", vid);
                breachedAlertsState.remove(vid);
            }
        } catch (Exception e) {
            log.error("Exception while clearing state for vehicle {}", vid, e);
        }

    }

    private GeoFenceShutDown getGeoFenceShutDown(String vid, EnrichedGeoFence earliestBreach) {
        // If commandCode is null, populate it.
        if(Objects.isNull(commandCode)) commandCode = FmsMappingHelper.getAutoImmobilizationCode(env);

        if (Objects.nonNull(earliestBreach)) {
            GeoFenceShutDown geoFenceShutDown = GeoFenceShutDown.withDefaults(commandCode);
            geoFenceShutDown.setVehicleIdentifier(vid);
            geoFenceShutDown.setProfileId(earliestBreach.getProfileId());
            return geoFenceShutDown;
        }

        return null;

    }

}
