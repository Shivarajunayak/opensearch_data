package org.hmcl.cvp.dataplatform.geofencing.contract;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;
import java.util.Map;
import java.util.Objects;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class StateTransition {

    private long transitionedTime;

    private boolean stateUpdated;

    private Map<String, VehicleState> vehicleState;

    private List<FenceAndState> transitionedFences;

    public boolean statePresent() {
        return Objects.nonNull(vehicleState) && !vehicleState.isEmpty();
    }

    public boolean transitionsPresent() {
        return Objects.nonNull(transitionedFences) && !transitionedFences.isEmpty();
    }
}
