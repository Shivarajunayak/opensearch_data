package org.hmcl.cvp.dataplatform.geofencing.contract;

import com.google.gson.annotations.SerializedName;

import java.util.HashMap;
import java.util.Map;

public enum CommandSource {

    @SerializedName("FENCE_BREACH")
    FENCE_BREACH("FENCE_BREACH"),

    @SerializedName("CLOUD")
    CLOUD("CLOUD"),

    @SerializedName("BLE")
    BLE("BLE"),

    @SerializedName("WIFI")
    WIFI("WIFI");

    private static final Map<String, CommandSource> CONSTANTS = new HashMap<>();

    static {
        for (CommandSource c : values()) {
            CONSTANTS.put(c.value, c);
        }
    }

    private final String value;

    CommandSource(String value) {
        this.value = value;
    }

    public static CommandSource fromValue(String value) {
        CommandSource constant = CONSTANTS.get(value);
        if (constant == null) {
            throw new IllegalArgumentException(value);
        } else {
            return constant;
        }
    }

    @Override
    public String toString() {
        return this.value;
    }

    public String value() {
        return this.value;
    }

}
