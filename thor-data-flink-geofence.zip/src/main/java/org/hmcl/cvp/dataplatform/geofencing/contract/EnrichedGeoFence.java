package org.hmcl.cvp.dataplatform.geofencing.contract;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.hmcl.cvp.dataplatform.contract.notification.GeoFenceType;
import org.hmcl.cvp.dataplatform.contract.userpreference.GeoFenceFeature;

import java.io.Serializable;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class EnrichedGeoFence implements Serializable {

    private GeoFenceFeature geoFenceFeature;

    private String fenceId;

    private boolean isFirstAlert;

    private int count;

    private String profileId;

    private GeoFenceType fenceType;

    private Long breachTimestamp;

    private Long triggerTime;

    private Location location;

    public boolean getIsFirstAlert() {
        return isFirstAlert;
    }

    public void setIsFirstAlert(boolean firstAlert) {
        isFirstAlert = firstAlert;
    }

    public boolean isExit() {
        return GeoFenceType.EXIT.equals(this.fenceType);
    }

    public boolean isEntry() {
        return GeoFenceType.ENTRY.equals(this.fenceType);
    }

    @Override
    public boolean equals(Object obj) {
        return super.equals(obj);
    }

    @Override
    public int hashCode() {
        return super.hashCode();
    }

}
