package org.hmcl.cvp.dataplatform.geofencing.operator;

import lombok.extern.slf4j.Slf4j;
import org.apache.flink.api.common.state.MapState;
import org.apache.flink.api.common.state.MapStateDescriptor;
import org.apache.flink.api.java.utils.ParameterTool;
import org.apache.flink.configuration.Configuration;
import org.apache.flink.metrics.Counter;
import org.apache.flink.streaming.api.functions.co.RichCoFlatMapFunction;
import org.apache.flink.util.Collector;
import org.hmcl.cvp.dataplatform.commons.constants.Constants;
import org.hmcl.cvp.dataplatform.commons.constants.FlinkRuntime;
import org.hmcl.cvp.dataplatform.commons.utils.TelemetryUtils;
import org.hmcl.cvp.dataplatform.contract.enriched.AlertNotification;
import org.hmcl.cvp.dataplatform.contract.enriched.EnrichedTelemetry;
import org.hmcl.cvp.dataplatform.contract.notification.AlertInfo;
import org.hmcl.cvp.dataplatform.contract.notification.GeoFenceType;
import org.hmcl.cvp.dataplatform.contract.telemetry.Telemetry;
import org.hmcl.cvp.dataplatform.contract.userpreference.UserPreference;
import org.hmcl.cvp.dataplatform.geofencing.contract.*;
import org.hmcl.cvp.dataplatform.geofencing.helper.FmsMappingHelper;
import org.hmcl.cvp.dataplatform.geofencing.helper.GeoFenceHelper;
import org.locationtech.jts.geom.Point;

import java.util.*;
import java.util.stream.Collectors;

@Slf4j
public class TelemetryStateTransitionFunction extends RichCoFlatMapFunction<Telemetry, UserPreference, GeoEnrichedTelemetry> {

    // The number of digits to ignore in the timestamp
    private static final Integer DIGITS_TO_IGNORE = 4;
    private static final Double HDOP_VALUE = 1.0;

    /**
     * Counters
     */
    private transient Counter numInputEventCounter;
    private transient Counter numInvalidGpsCounter;
    private transient Counter numErrorEventCounter;
    private transient Counter numExitAlertsCounter;
    private transient Counter numEntryAlertsCounter;
    private transient Counter numUserPreferenceCounter;
    private transient Counter numUserPreferenceUpdatedCounter;
    private transient Counter numUserPreferenceIgnoredCounter;
    private transient Counter numEnrichedTelemetryCounter;
    private transient Counter numNotEnrichedTelemetryCounter;

    /**
     * MapState to hold userPreferences for each profile
     * Key - vehicleId
     * Value - Map of user preferences with the key being RIDER or PRIMARY and value Tuple of profileId and UserPreference object
     * VirtualId -> <PRIMARY/RIDER, GeoUserPreference>
     */
    private transient MapState<String, Map<String, GeoUserPreference>> preferencesStateMap;

    /**
     * Store the vehicle state
     * - the fences in which the vehicle is present at the time of vehicle start.
     * - the fences that the vehicle has entered or exited
     * Key - VirtualId
     * Value - Map of vehicleState objects with key being fenceId and value the state
     * VirtualId -> <GeoFenceId, VehicleState>
     */
    private transient MapState<String, Map<String, VehicleState>> vehicleFenceState;

    /**
     * Store the last processed lat-long time for a vehicle
     * Key - VirtualId
     * Value - lat-long time
     * VirtualId -> epoch milliseconds
     */
    private transient MapState<String, Long> lastProcessedTimeState;

    /**
     * Stores all breached alerts for a particular vehicle.
     * This state will be cleared for the VirtualId for the following
     * 1. 5 alerts
     * 2. Re Entry
     * Key - VirtualId
     * Value - Map of the geoFenceIds and their count
     */
    private transient MapState<String, Map<String, Integer>> breachedAlertsCounterState;

    private transient boolean simulator;
    private transient int digitsToIgnore;
    private transient Double hDopThresholdValue;
    private transient String env;

    private transient AlertInfo alertInfo;

    private Counter counterInitializer(String counterName) {
        return getRuntimeContext()
                .getMetricGroup()
                .addGroup(Constants.METRIC_GROUP_NAME)
                .addGroup("StateTransition")
                .counter(counterName);
    }

    @Override
    public void open(Configuration parameters) throws Exception {
        super.open(parameters);

        ParameterTool parameterTool = (ParameterTool) getRuntimeContext().getExecutionConfig().getGlobalJobParameters();
        simulator = parameterTool.getBoolean(FlinkRuntime.GEOFENCE_SIMULATOR_RUN, Boolean.FALSE);
        digitsToIgnore = parameterTool.getInt(FlinkRuntime.NO_LAST_DIGITS_TO_IGNORE_IN_MILLIS, DIGITS_TO_IGNORE);
        env = parameterTool.getRequired(FlinkRuntime.ENV);
        hDopThresholdValue = parameterTool.getDouble(FlinkRuntime.VALID_HDOP_THRESHOLD_VALUE, HDOP_VALUE);

        MapStateDescriptor<String, Map<String, GeoUserPreference>> userPreferencesDescriptor = MapStateDescriptors.userPreferenceMapStateDescriptor();
        preferencesStateMap = getRuntimeContext().getMapState(userPreferencesDescriptor);

        MapStateDescriptor<String, Map<String, VehicleState>> vehicleStateDescriptor = MapStateDescriptors.getVehicleStateDescriptor();
        vehicleFenceState = getRuntimeContext().getMapState(vehicleStateDescriptor);

        // No TTL for this
        MapStateDescriptor<String, Long> lastProcessedTimeDescriptor = MapStateDescriptors.getLastProcessedTimeDescriptor();
        lastProcessedTimeState = getRuntimeContext().getMapState(lastProcessedTimeDescriptor);

        // TTL will be same as User preference
        MapStateDescriptor<String, Map<String, Integer>> breachedAlertsCounterDescriptor = MapStateDescriptors.getBreachedAlertsCounterDescriptor();
        breachedAlertsCounterState = getRuntimeContext().getMapState(breachedAlertsCounterDescriptor);

        numInputEventCounter = counterInitializer("numInputEvents");
        numInvalidGpsCounter = counterInitializer("numGpsInvalid");
        numErrorEventCounter = counterInitializer("numErrorEvents");
        numExitAlertsCounter = counterInitializer("numExitEvents");
        numEntryAlertsCounter = counterInitializer("numEntryEvents");
        numUserPreferenceCounter = counterInitializer("numUserPreferences");
        numUserPreferenceUpdatedCounter = counterInitializer("numUserPreferenceUpdated");
        numUserPreferenceIgnoredCounter = counterInitializer("numUserPreferenceIgnored");
        numEnrichedTelemetryCounter = counterInitializer("numEnrichedEvents");
        numNotEnrichedTelemetryCounter = counterInitializer("numNotEnrichedEvents");

        // Get Alert mappings
        log.info("Fetching alert mappings for env {}", env);
        alertInfo = FmsMappingHelper.getAlertInfo(env);
    }

    @Override
    public void flatMap1(Telemetry incomingValue, Collector<GeoEnrichedTelemetry> out) {
        numInputEventCounter.inc();

        String incomingVid = TelemetryUtils.getVirtualId(incomingValue);
        log.debug("Current vehicle - {}", incomingVid);

        Map<String, GeoUserPreference> state = getUserPreferenceState(incomingVid);
        if (state.isEmpty()) {
            numNotEnrichedTelemetryCounter.inc();
            log.warn("No user preferences found for vehicle {}", incomingVid);
            return;
        }

        GeoUserPreference rider = GeoFenceHelper.getRider(state);
        if (Objects.isNull(rider)) {
            numNotEnrichedTelemetryCounter.inc();
            log.debug("No rider found for vehicle {}", incomingVid);
            return;
        }

        // If alertInfo is null, populate it.
        if(Objects.isNull(alertInfo)) alertInfo = FmsMappingHelper.getAlertInfo(env);

        // If alertInfo is still null, return
        if(Objects.isNull(alertInfo)) {
            log.error("No alertInfo found for vehicle {}", incomingVid);
            numNotEnrichedTelemetryCounter.inc();
            return;
        }

        log.debug("Current rider for vehicle {} is {}", incomingVid, rider.getProfileId());

        List<FenceAndPolygon> fencesAndPolygons = rider.getFencesAndPolygons();
        if (fencesAndPolygons.isEmpty()) {
            numNotEnrichedTelemetryCounter.inc();
            log.debug("No fences and their corresponding polygons (including tagged ones) found for vehicle {}", incomingVid);
            return;
        }

        List<Location> locations = GeoFenceHelper.getLocationSignals(incomingVid, incomingValue, digitsToIgnore, simulator);
        if(locations.isEmpty()) {
            numNotEnrichedTelemetryCounter.inc();
            log.debug("No matching pairs of lat, long, hDop and gpsValid found for vehicle {}", incomingVid);
            return;
        }

        long lastProcessedTime = getLastProcessedTime(incomingVid);
        List<Location> latestLocations = locations.stream()
                .filter(l -> l.getTimestamp() > lastProcessedTime)
                .sorted(Comparator.comparing(Location::getTimestamp))
                .collect(Collectors.toList());

        if(latestLocations.isEmpty()) {
            numNotEnrichedTelemetryCounter.inc();
            log.debug("No latest location details found for vehicle {} compared to last processed time {}", incomingVid, lastProcessedTime);
            return;
        }

        // Updating the newest location time in state so that location signals of older time will not be processed.
        long newestLocationTime = GeoFenceHelper.getNewestLocationTime(latestLocations);
        updateLastProcessedTime(incomingVid, newestLocationTime);

        for(Location location: latestLocations) {
            log.debug("Processing {} for vehicle {}", location, incomingVid);
            if(GeoFenceHelper.isLocationValid(location, hDopThresholdValue)) {
                processLocation(incomingVid, incomingValue, location, fencesAndPolygons, out);
            } else {
                log.debug("Incoming location {} is not valid for vehicle {}", location, incomingVid);
                numInvalidGpsCounter.inc();
            }
        }

    }

    // Add secondary profile only if he is riding
    @Override
    public void flatMap2(UserPreference incomingUserPreference, Collector<GeoEnrichedTelemetry> out) {

        numUserPreferenceCounter.inc();
        String incomingVid = incomingUserPreference.getVid();
        String incomingProfileId = incomingUserPreference.getProfileId();

        // Only having getUpdatedTsp >= to allow for state to be updated once per week.
        // A Job will scan the UserPreference DB and Push it to UserPreference MSK topic
        Map<String, GeoUserPreference> cachedUserState = getUserPreferenceState(incomingVid);
        GeoUserPreference cachedGeoUserPreference = GeoFenceHelper.getUserFromState(incomingProfileId, cachedUserState);

        boolean isLatestValue = GeoFenceHelper.isLatestPreference(incomingUserPreference, cachedGeoUserPreference);
        if (!isLatestValue) {
            numUserPreferenceIgnoredCounter.inc();
            log.info("Incoming user profile {} is out of order for vehicle {}", incomingVid, incomingVid);
            return;
        }

        processIncomingUserPreference(incomingVid, incomingProfileId, incomingUserPreference, cachedUserState, cachedGeoUserPreference);

        if(GeoFenceHelper.isPrimaryUserAndNotARider(incomingUserPreference)) {
            log.info("Incoming profile {} is a primary and not a rider for vehicle {}. " +
                    "Checking if tagged fences for secondary needs to be refreshed.", incomingProfileId, incomingVid);

            processAnyTaggedGeoFences(incomingVid);

        }

    }

    private void processIncomingUserPreference(String incomingVid,
                                       String incomingProfileId,
                                       UserPreference incomingUserPreference,
                                       Map<String, GeoUserPreference> cachedUserState,
                                       GeoUserPreference cachedGeoUserPreference) {

        UserPreferenceChanges updated = GeoFenceHelper
                .getUpdatedUserPreferences(incomingVid, incomingUserPreference, cachedUserState, cachedGeoUserPreference);

        boolean stateUpdated = updated.isUpdateState();
        boolean riderChanged = updated.isRiderChanged();
        List<IndividualAndTaggedFence> fenceDiff = updated.getChangedFences();

        if (!stateUpdated) {

            numUserPreferenceIgnoredCounter.inc();
            log.info("Incoming user {} is secondary and is not a rider and not present in state for vehicle {}", incomingProfileId, incomingVid);

            // It may happen that secondary non rider - who was a rider previously and related data is present in cache for that profile.
            // This event may come late and another user may have been updated as a rider in the cache.
            // This results in cached data present for this user. Clearing them from state if there are any.
            List<IndividualAndTaggedFence> relatedFences = GeoFenceHelper.getRelatedFencesFromState(incomingProfileId, cachedUserState);

            // Removing counters for secondary non rider
            updateBreachedCounter(incomingVid, false, relatedFences);

            // Removing states for secondary non rider
            updateVehicleState(incomingVid, false, relatedFences);

            return;
        }

        log.info("Updating user preference state, vehicle state and breach counter state for vehicle {}", incomingVid);

        Map<String, GeoUserPreference> updatedPreferences = updated.getUpdatedUserState();

        userPreferenceRelatedStateUpdates(incomingVid, updatedPreferences, riderChanged, fenceDiff);

        numUserPreferenceUpdatedCounter.inc();
    }

    private void processAnyTaggedGeoFences(String incomingVid) {
        Map<String, GeoUserPreference> state = getUserPreferenceState(incomingVid);

        GeoUserPreference existingRider = GeoFenceHelper.getRider(state);
        if (Objects.isNull(existingRider)) return;

        GeoUserPreference updatedRider = GeoFenceHelper.getGeoUserPreference(incomingVid, existingRider.getUserPreference(), state);
        List<IndividualAndTaggedFence> fenceDiff = GeoFenceHelper.getDiffOfTaggedFences(updatedRider, existingRider);
        if(fenceDiff.isEmpty()) {
            log.info("No tagged fence updates for vehicle {}", incomingVid);
            return;
        }

        String riderProfileId = existingRider.getProfileId();
        log.info("Updating state for secondary profile {} since tagged fences changes for vehicle {}", riderProfileId, incomingVid);
        state.put(UserPreferenceType.RIDER.value(), updatedRider);
        userPreferenceRelatedStateUpdates(incomingVid, state, false, fenceDiff);
        numUserPreferenceUpdatedCounter.inc();
    }

    private void processLocation(String incomingVid,
                                 Telemetry incomingValue,
                                 Location location,
                                 List<FenceAndPolygon> fencesAndPolygons,
                                 Collector<GeoEnrichedTelemetry> out) {



        Point point = GeoFenceHelper.getLocationPoint(incomingVid, location);
        if (Objects.isNull(point)) {
            log.debug("No location point for vehicle {}", incomingVid);
            numErrorEventCounter.inc();
            return;
        }

        Map<String, VehicleState> existingStates = getVehicleState(incomingVid);
        if (existingStates.isEmpty()) {
            Map<String, VehicleState> updatedState = GeoFenceHelper.getStateUpdates(incomingVid, point, fencesAndPolygons);
            log.debug("Starting State got updated for vehicle {}. Transition will be done for subsequent events!", incomingVid);
            updateVehicleState(incomingVid, updatedState);
            numNotEnrichedTelemetryCounter.inc();
            return;
        }

        // Check for state transition
        Map<String, Integer> counterMap = getBreachCounterMap(incomingVid);
        StateTransition stateTransition = GeoFenceHelper.checkForStateTransitions(incomingVid, point, existingStates, counterMap, fencesAndPolygons);

        if (stateTransition.isStateUpdated()) {
            log.debug("State transition detected for vehicle {}", incomingVid);

            // Update vehicle state in map state
            updateVehicleState(incomingVid, stateTransition.getVehicleState());

            List<EnrichedGeoFence> enrichedGeoFences = getGeoEnrichedFences(incomingVid, stateTransition, location);
            if (!enrichedGeoFences.isEmpty()) {
                numEnrichedTelemetryCounter.inc();

                EnrichedTelemetry enrichedTelemetry = new EnrichedTelemetry();

                AlertNotification alertNotification = AlertNotification.builder()
                        .alertCode(alertInfo.getCode())
                        .alertName(alertInfo.getName())
                        .alertType(alertInfo.getType())
                        .build();

                enrichedTelemetry.setTelemetry(incomingValue);
                enrichedTelemetry.setNotification(alertNotification);

                GeoEnrichedTelemetry geoEnrichedTelemetry = GeoEnrichedTelemetry.fromEnrichedTelemetry(enrichedTelemetry);
                geoEnrichedTelemetry.setEnrichedGeoFences(enrichedGeoFences);

                out.collect(geoEnrichedTelemetry);
            }
        }
    }



    // Only having getUpdatedTsp >= to allow for state to be updated once per week.
    // A Job will scan the UserPreference DB and Push it to UserPreference MSK topic
    private Map<String, GeoUserPreference> getUserPreferenceState(String incomingVid) {
        try {
            return Objects.isNull(preferencesStateMap.get(incomingVid)) ? new HashMap<>() : preferencesStateMap.get(incomingVid);
        } catch (Exception e) {
            log.error("Exception while access userPreferenceState for vehicle {}: ", incomingVid, e);
        }

        return new HashMap<>();
    }

    private void userPreferenceRelatedStateUpdates(String incomingVid,
                                                   Map<String, GeoUserPreference> updatedPreferences,
                                                   boolean riderChanged,
                                                   List<IndividualAndTaggedFence> fencesToRemove) {

        // Updating user preference state
        updateUserPreferenceState(incomingVid, updatedPreferences);

        // If needed, invalidate the existing vehicle state
        updateVehicleState(incomingVid, riderChanged, fencesToRemove);

        // If needed, invalidate counter state too
        updateBreachedCounter(incomingVid, riderChanged, fencesToRemove);
    }

    private void updateUserPreferenceState(String incomingVid, Map<String, GeoUserPreference> newValue) {
        try {
            preferencesStateMap.put(incomingVid, newValue);
        } catch (Exception e) {
            log.error("Exception while updating user preference state for vehicle {}", incomingVid);
        }
    }

    private void updateVehicleState(String incomingVid, boolean riderChanged, List<IndividualAndTaggedFence> fencesToRemove) {

        // Rider flag changed or fences were changed. Invalidating the vehicle state
        if (riderChanged) {
            log.debug("Rider has changed for vehicle {}. So invalidating vehicle state cache!", incomingVid);
            updateVehicleState(incomingVid, new HashMap<>());
            return;
        }

        if(!fencesToRemove.isEmpty()) {
            Map<String, VehicleState> cachedState = getVehicleState(incomingVid);
            Map<String, VehicleState> updatedState = new HashMap<>(cachedState);
            fencesToRemove.forEach(f -> {
                String fenceId = f.getFenceId();
                log.debug("{} fence is marked for removal for vehicle {}. So invalidating vehicle state related to the fence.", fenceId, incomingVid);
                updatedState.remove(fenceId);
            });

            updateVehicleState(incomingVid, updatedState);
        }
    }

    private void updateVehicleState(String incomingVid, Map<String, VehicleState> newVehicleState) {
        try {
            log.debug("Updating vehicle state for vehicle {}", incomingVid);
            vehicleFenceState.put(incomingVid, newVehicleState);
        } catch (Exception e) {
            log.error("Exception while updating vehicle state for vehicle {}: ", incomingVid, e);
        }
    }

    private Map<String, VehicleState> getVehicleState(String incomingVid) {
        try {
            return Objects.isNull(vehicleFenceState.get(incomingVid)) ? new HashMap<>() : vehicleFenceState.get(incomingVid);
        } catch (Exception e) {
            log.error("Exception while accessing vehicle state for vehicle {}: ", incomingVid, e);
        }

        return new HashMap<>();
    }

    private Map<String, Integer> getBreachCounterMap(String incomingVid) {
        try {
            return Objects.isNull(breachedAlertsCounterState.get(incomingVid))
                    ? new HashMap<>()
                    : breachedAlertsCounterState.get(incomingVid);
        } catch (Exception e) {
            log.error("Exception while accessing breached alerts counter for vehicle {}: ", incomingVid, e);
        }

        return new HashMap<>();
    }

    private Integer getBreachCounter(String incomingVid, String fenceId) {
        Map<String, Integer> existingCounter = getBreachCounterMap(incomingVid);
        return existingCounter.getOrDefault(fenceId, 0);
    }

    private void updateBreachedCounter(String incomingVid, Map<String, Integer> counters) {
        try {
            log.debug("Updating breach counters for vehicle {} with {}", incomingVid, counters);
            breachedAlertsCounterState.put(incomingVid, counters);
        } catch (Exception e) {
            log.error("Exception while updating breached alerts counter for vehicle {}: ", incomingVid, e);
        }
    }

    private void updateBreachedCounter(String incomingVid, boolean riderChanged, List<IndividualAndTaggedFence> fencesToRemove) {
        // Rider flag changed or fences were changed. Invalidating the breach counters

        if(riderChanged) {
            log.debug("Rider has changed for vehicle {}. So invalidating breach counters cache!", incomingVid);
            updateBreachedCounter(incomingVid, new HashMap<>());
            return;
        }

        if(!fencesToRemove.isEmpty()) {
            Map<String, Integer> cachedState = getBreachCounterMap(incomingVid);
            Map<String, Integer> updatedState = new HashMap<>(cachedState);
            fencesToRemove.forEach(f -> {
                String fenceId = f.getFenceId();
                log.debug("{} fenceId is marked for removal. So removing it from breach counters for vehicle {}.", fenceId, incomingVid);
                updatedState.remove(fenceId);
            });

            updateBreachedCounter(incomingVid, updatedState);
        }

    }

    private void updateBreachedCounter(String incomingVid, String fenceId, Integer count) {
        try {
            Map<String, Integer> existingCounter = getBreachCounterMap(incomingVid);
            existingCounter.put(fenceId, count);

            updateBreachedCounter(incomingVid, existingCounter);
        } catch (Exception e) {
            log.error("Exception while updating breached alerts counter for vehicle {} and fence {}: ", incomingVid, fenceId, e);
        }

    }

    private void clearBreachedCounter(String incomingVid, String fenceId) {
        try {
            Map<String, Integer> existingCounter = getBreachCounterMap(incomingVid);
            existingCounter.put(fenceId, 0);

            updateBreachedCounter(incomingVid, existingCounter);
        } catch (Exception e) {
            log.error("Exception while updating breached alerts counter for vehicle {} and fence {}: ", incomingVid, fenceId, e);
        }

    }

    private long getLastProcessedTime(String incomingVid) {
        try {
            return lastProcessedTimeState.contains(incomingVid) ? lastProcessedTimeState.get(incomingVid) : 0;
        } catch (Exception e) {
            log.error("Error while accessing last processed time state for vehicle {}: ", incomingVid, e);
        }

        return 0;
    }

    private void updateLastProcessedTime(String incomingVid, Long incomingEventTime) {
        try {
            log.debug("Updating lastProcessedTime to {} for vehicle {}", incomingEventTime, incomingVid);
            lastProcessedTimeState.put(incomingVid, incomingEventTime);
        } catch (Exception e) {
            log.error("Error while updating last processed time state for vehicle {}: ", incomingVid, e);
        }
    }

    private List<EnrichedGeoFence> getGeoEnrichedFences(String incomingVid, StateTransition stateTransition, Location location) {

        List<FenceAndState> fenceAndStates = stateTransition.getTransitionedFences();
        if (fenceAndStates.isEmpty()) return new ArrayList<>();

        long transitionedTime = location.getTimestamp();

        List<EnrichedGeoFence> enrichedGeoFences = new ArrayList<>();

        for (FenceAndState fenceAndState : fenceAndStates) {

            IndividualAndTaggedFence fence = fenceAndState.getFence();
            VehicleState vehicleState = fenceAndState.getVehicleState();
            String fenceId = fence.getFenceId();
            boolean autoImmobilize = fence.getGeoFenceFeature().isAutoImmobilisationEnabled();

            // Checking for entries
            if (VehicleState.State.ENTRY.equals(vehicleState.getTransitionedState())) {
                numEntryAlertsCounter.inc();

                // Clear any breached counters for the fence
                clearBreachedCounter(incomingVid, fenceId);
                EnrichedGeoFence enrichedGeoFence = EnrichedGeoFence.builder()
                        .fenceId(fenceId)
                        .geoFenceFeature(fence.getGeoFenceFeature())
                        .profileId(fence.getRiderProfileId())
                        .isFirstAlert(true)
                        .location(location)
                        .breachTimestamp(transitionedTime)
                        .fenceType(GeoFenceType.ENTRY)
                        .build();

                enrichedGeoFences.add(enrichedGeoFence);
            }

            // Checking for exits
            if (VehicleState.State.EXIT.equals(vehicleState.getTransitionedState())) {
                numExitAlertsCounter.inc();

                Integer cachedCount = getBreachCounter(incomingVid, fenceId);
                if (!autoImmobilize && cachedCount == 1) {
                    log.debug("Since auto-immobilization is disabled and user is already notified, " +
                            "ignoring {} exit alert for vehicle {}", fenceId, incomingVid);
                    continue;
                }

                int newCount = updateAndGetBreachedCounter(incomingVid, fenceId, cachedCount, autoImmobilize);
                log.debug("Number of state transitions for fence {} and vehicle {} is {}", fenceId, incomingVid, newCount);

                EnrichedGeoFence enrichedGeoFence = EnrichedGeoFence.builder()
                        .fenceId(fenceId)
                        .geoFenceFeature(fence.getGeoFenceFeature())
                        .fenceType(GeoFenceType.EXIT)
                        .breachTimestamp(transitionedTime)
                        .location(location)
                        .isFirstAlert(newCount == 1)
                        .profileId(fence.getRiderProfileId())
                        .count(newCount)
                        .build();

                enrichedGeoFences.add(enrichedGeoFence);
            }
        }

        return enrichedGeoFences;

    }

    private int updateAndGetBreachedCounter(String incomingVid, String fenceId, Integer cachedCount, boolean autoImmobilize) {

        if (autoImmobilize) {
            int newCount = cachedCount + 1;
            updateBreachedCounter(incomingVid, fenceId, newCount);

            return newCount;
        }

        // For non autoImmobilization, no need to increment count.
        // But still need to maintain counter to determine weather to send notification or not
        int newCount = 1;
        updateBreachedCounter(incomingVid, fenceId, newCount);

        return newCount;

    }
}
