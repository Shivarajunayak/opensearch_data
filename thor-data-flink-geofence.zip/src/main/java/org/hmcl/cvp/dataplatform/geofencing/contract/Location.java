package org.hmcl.cvp.dataplatform.geofencing.contract;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class Location implements Serializable {

    private double latitude;

    private double longitude;

    private double hDop;

    private boolean gpsValid;

    private long timestamp;

}
