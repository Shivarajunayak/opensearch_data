package org.hmcl.cvp.dataplatform.geofencing.contract;

import com.google.gson.annotations.SerializedName;

import java.util.HashMap;
import java.util.Map;

public enum UserType {

    @SerializedName("CUSTOMER")
    CUSTOMER("CUSTOMER"),

    @SerializedName("PARTNER")
    PARTNER("PARTNER"),

    @SerializedName("INTERNAL")
    INTERNAL("INTERNAL"),

    @SerializedName("SYSTEM")
    SYSTEM("SYSTEM");

    private static final Map<String, UserType> CONSTANTS = new HashMap<>();

    static {
        for (UserType c : values()) {
            CONSTANTS.put(c.value, c);
        }
    }

    private final String value;

    UserType(String value) {
        this.value = value;
    }

    public static UserType fromValue(String value) {
        UserType constant = CONSTANTS.get(value);
        if (constant == null) {
            throw new IllegalArgumentException(value);
        } else {
            return constant;
        }
    }

    @Override
    public String toString() {
        return this.value;
    }

    public String value() {
        return this.value;
    }

}
