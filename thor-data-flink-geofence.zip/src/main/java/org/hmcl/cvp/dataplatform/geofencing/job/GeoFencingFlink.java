package org.hmcl.cvp.dataplatform.geofencing.job;

import lombok.extern.slf4j.Slf4j;
import org.apache.flink.api.common.eventtime.WatermarkStrategy;
import org.apache.flink.api.common.functions.FlatMapFunction;
import org.apache.flink.api.java.functions.KeySelector;
import org.apache.flink.api.java.utils.ParameterTool;
import org.apache.flink.connector.kafka.sink.KafkaSink;
import org.apache.flink.connector.kafka.source.KafkaSource;
import org.apache.flink.streaming.api.datastream.DataStream;
import org.apache.flink.streaming.api.datastream.KeyedStream;
import org.apache.flink.streaming.api.datastream.SingleOutputStreamOperator;
import org.apache.flink.streaming.api.environment.StreamExecutionEnvironment;
import org.hmcl.cvp.dataplatform.commons.connector.KafkaConnector;
import org.hmcl.cvp.dataplatform.commons.constants.FlinkRuntime;
import org.hmcl.cvp.dataplatform.commons.operator.TelemetryFlatMapFunction;
import org.hmcl.cvp.dataplatform.commons.operator.UserPreferenceFlatMapFunction;
import org.hmcl.cvp.dataplatform.commons.stream.SourceStream;
import org.hmcl.cvp.dataplatform.commons.utils.ConnectorUtils;
import org.hmcl.cvp.dataplatform.commons.utils.FlinkUtils;
import org.hmcl.cvp.dataplatform.commons.utils.TelemetryUtils;
import org.hmcl.cvp.dataplatform.contract.telemetry.Telemetry;
import org.hmcl.cvp.dataplatform.contract.userpreference.UserPreference;
import org.hmcl.cvp.dataplatform.geofencing.contract.GeoEnrichedTelemetry;
import org.hmcl.cvp.dataplatform.geofencing.operator.GeoFenceNotificationFunction;
import org.hmcl.cvp.dataplatform.geofencing.operator.GeoFenceShutDownFunction;
import org.hmcl.cvp.dataplatform.geofencing.operator.OperatorNames;
import org.hmcl.cvp.dataplatform.geofencing.operator.TelemetryStateTransitionFunction;

import java.io.IOException;
import java.time.Duration;

@Slf4j
public class GeoFencingFlink {
    private static final String FEATURE_NAME = "geoFenceAlert";

    // Convert JSON -> Telemetry Object.  String -> JSON
    private static final FlatMapFunction<String, Telemetry> telemetryFlatMapFunction = new TelemetryFlatMapFunction();

    // Convert  JSON to UserPreference Object. String -> JSON
    private static final FlatMapFunction<String, UserPreference> userPrefFlatMapFunction = new UserPreferenceFlatMapFunction();

    // Connect Telemetry and UserPreference objects and find the vehicle state
    // Detect breach, Generate Alerts and Notification. Alerts can lead to Auto-Immobilization while Entry and Exit will lead to notification
    private static final TelemetryStateTransitionFunction stateTransitionFunction = new TelemetryStateTransitionFunction();

    // Notification when Entry or Exit has occurred
    private static final GeoFenceNotificationFunction notificationMap = new GeoFenceNotificationFunction();

    //Auto-Immobilize when Alert is generated 4 times or 5 minutes has elapsed - configurable
    private static final GeoFenceShutDownFunction shutDownFunction = new GeoFenceShutDownFunction();

    public static void main(String[] args) throws IOException {
        final StreamExecutionEnvironment env = StreamExecutionEnvironment.getExecutionEnvironment();
        final ParameterTool parameterTool = ConnectorUtils.loadApplicationParameters(args, env);

        // Counter Suffix
        ParameterTool extendedParameterTool = FlinkUtils.addProperties(parameterTool, "alert.name", FEATURE_NAME);
        env.getConfig().setGlobalJobParameters(extendedParameterTool);

        boolean isTest = parameterTool.getBoolean(FlinkRuntime.IS_TEST, Boolean.FALSE);
        boolean isGeofenceSimulatorRun = parameterTool.getBoolean(FlinkRuntime.GEOFENCE_SIMULATOR_RUN, Boolean.FALSE);
        // Ignore events older than 1 minute
        int maxOutOfOrderInSec = parameterTool.getInt(FlinkRuntime.MAX_OUT_OF_ORDER_IN_SEC, 60);
        int idleTimeoutInSec = parameterTool.getInt(FlinkRuntime.IDLE_TIMEOUT_IN_SEC);

        log.info("Is this being executed as part of test case? {}", isTest);
        log.info("Is this being executed as part of Simulator? {}", isGeofenceSimulatorRun);

        try {

            // Watermark strategy with Idlesness to ensure - the sink read doesn't halt - as it reads from two Kafka Sources
            WatermarkStrategy<Telemetry> watermarkStrategy = WatermarkStrategy
                    .<Telemetry>forBoundedOutOfOrderness(Duration.ofSeconds(maxOutOfOrderInSec))
                    .withTimestampAssigner((event, timestamp) -> event.getCollectionEventTime())
                    .withIdleness(Duration.ofSeconds(idleTimeoutInSec));

            // Read from Two Kafka Telemetry Sink topic (2 in No ) , Union , Key VID and return a telemetryKeyedStream
            KeyedStream<Telemetry, String> telemetryKeyedStream = getKeyedTelemetryStream(env, parameterTool, watermarkStrategy);

            // Read from UserPreference Kafka Topic and Key by VID and return userPreferKeyedStream
            KeyedStream<UserPreference, String> userPreferKeyedStream = getKeyedUserPreferenceStream(env, parameterTool);

            // Encapsulate Telemetry and UserPreference in EnrichedTelemetry and find the state
            SingleOutputStreamOperator<GeoEnrichedTelemetry> enrichedTelemetryStringStream = telemetryKeyedStream
                    .connect(userPreferKeyedStream)
                    .flatMap(stateTransitionFunction)
                    .name(OperatorNames.STATE_TRANSITION)
                    .uid(OperatorNames.STATE_TRANSITION);

            //  Notification Sink to generate Notification -> wil be consumed by NOTIFICATION SERVICE
            KafkaSink<String> notificationSink = getNotificationSink(parameterTool, isTest);

            // Notify any breaches
            enrichedTelemetryStringStream
                    .startNewChain()
                    .flatMap(notificationMap)
                    .name(OperatorNames.NOTIFICATION_MAPPER)
                    .uid(OperatorNames.NOTIFICATION_MAPPER)
                    .sinkTo(notificationSink)
                    .name(OperatorNames.NOTIFICATION_SINK)
                    .uid(OperatorNames.NOTIFICATION_SINK);

            //  AUTO IMMOBILIZATION
            //  Notification Sink to generate Notification -> wil be consumed by COMMAND AND CONTROL SERVICE
            KafkaSink<String> shutDownSink = getShutDownSink(parameterTool, isTest);

            WatermarkStrategy<GeoEnrichedTelemetry> autoImmobWatermarkStrategy = WatermarkStrategy
                    .<GeoEnrichedTelemetry>forBoundedOutOfOrderness(Duration.ofSeconds(maxOutOfOrderInSec))
                    .withTimestampAssigner((event, timestamp) -> event.getTelemetry().getCollectionEventTime())
                    .withIdleness(Duration.ofSeconds(idleTimeoutInSec));

            // Send any immobilization commands
            enrichedTelemetryStringStream
                    .assignTimestampsAndWatermarks(autoImmobWatermarkStrategy)
                    .keyBy((KeySelector<GeoEnrichedTelemetry, String>) value -> TelemetryUtils.getVirtualId(value.getTelemetry()))
                    .process(shutDownFunction)
                    .name(OperatorNames.AUTO_IMMOBILIZATION)
                    .uid(OperatorNames.AUTO_IMMOBILIZATION)
                    .sinkTo(shutDownSink)
                    .name(OperatorNames.COMMAND_SINK)
                    .uid(OperatorNames.COMMAND_SINK);

            env.execute();

        } catch (Exception e) {
            log.error("Error executing geo fencing job", e);
        }
    }

    // Union both the regular ignition on a campaign with the geo fence campaign
    private static KeyedStream<Telemetry, String> getKeyedTelemetryStream(final StreamExecutionEnvironment env,
                                                                          final ParameterTool parameterTool,
                                                                          final WatermarkStrategy<Telemetry> watermarkStrategy) {
        Boolean isTest = parameterTool.getBoolean(FlinkRuntime.IS_TEST, Boolean.FALSE);

        String telemetryCampaign = parameterTool.get(FlinkRuntime.Kafka.TELEMETRY_CAMPAIGN_TOPIC);
        KafkaConnector.KafkaProperties telemetryKafkaProps = KafkaConnector.getTelemetryKafkaProperties(parameterTool, telemetryCampaign);
        KafkaSource<String> telemetrySource = KafkaConnector.createStringKafkaSource(telemetryKafkaProps, parameterTool, isTest);

        DataStream<Telemetry> slowerCampaignData = env.fromSource(telemetrySource,
                WatermarkStrategy.noWatermarks(),
                telemetryCampaign)
                .flatMap(telemetryFlatMapFunction)
                .assignTimestampsAndWatermarks(watermarkStrategy)
                .name(OperatorNames.TELEMETRY_SOURCE)
                .uid(OperatorNames.TELEMETRY_SOURCE);

        String geoFenceTopic = parameterTool.get(FlinkRuntime.Kafka.GEO_CAMPAIGN_TOPIC);
        KafkaConnector.KafkaProperties geoFenceKafkaProps = KafkaConnector.getTelemetryKafkaProperties(parameterTool, geoFenceTopic);
        KafkaSource<String> geoCampaignSource = KafkaConnector.createStringKafkaSource(geoFenceKafkaProps, parameterTool, isTest);

        DataStream<Telemetry> fasterCampaignData =  env.fromSource(geoCampaignSource,
                        WatermarkStrategy.noWatermarks(),
                        geoFenceTopic)
                .flatMap(telemetryFlatMapFunction)
                .assignTimestampsAndWatermarks(watermarkStrategy)
                .name(OperatorNames.GEOFENCE_CAMPAIGN_SOURCE)
                .uid(OperatorNames.GEOFENCE_CAMPAIGN_SOURCE);

        return fasterCampaignData
                .union(slowerCampaignData)
                .keyBy((KeySelector<Telemetry, String>) TelemetryUtils::getVirtualId);
    }

    private static KeyedStream<UserPreference, String> getKeyedUserPreferenceStream(final StreamExecutionEnvironment env, final ParameterTool parameterTool) {
        KafkaConnector.KafkaProperties thresholdKafkaProps = KafkaConnector.getThresholdKafkaProperties(parameterTool);
        return SourceStream.getUserPreferenceStream(env,
                parameterTool,
                thresholdKafkaProps,
                userPrefFlatMapFunction,
                OperatorNames.USER_PREFERENCE_SOURCE);
    }

    private static KafkaSink<String> getNotificationSink(final ParameterTool parameterTool, boolean isTest) {
        String topic = parameterTool.get(FlinkRuntime.Kafka.NOTIFICATION_PRIORITY_TOPIC);
        KafkaConnector.KafkaProperties sinkProperties = KafkaConnector.getNotificationKafkaProperties(parameterTool, topic);
        return KafkaConnector.getKafkaSink(sinkProperties, parameterTool, isTest);
    }

    private static KafkaSink<String> getShutDownSink(final ParameterTool parameterTool, boolean isTest) {
        KafkaConnector.KafkaProperties kafkaProperties = new KafkaConnector.KafkaProperties(parameterTool);
        kafkaProperties.setBrokerFromParams(FlinkRuntime.Kafka.COMMAND_REQUEST_BROKER);
        kafkaProperties.setTopicsFromParams(FlinkRuntime.Kafka.COMMAND_REQUEST_TOPIC);
        kafkaProperties.setConsumerNameFromParams(FlinkRuntime.Kafka.COMMAND_REQUEST_GROUP);
        kafkaProperties.setRoleArnFromParams(FlinkRuntime.Kafka.COMMAND_REQUEST_ARN);
        kafkaProperties.setSessionNameFromParams(FlinkRuntime.Kafka.COMMAND_REQUEST_SESSION);
        kafkaProperties.setAwsRegionFromParams(FlinkRuntime.REGION_KEY);

        return KafkaConnector.getKafkaSink(kafkaProperties, parameterTool, isTest);
    }

}

