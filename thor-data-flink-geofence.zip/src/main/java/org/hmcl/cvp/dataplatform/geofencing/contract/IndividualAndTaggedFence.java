package org.hmcl.cvp.dataplatform.geofencing.contract;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.hmcl.cvp.dataplatform.commons.utils.UserPreferenceUtils;
import org.hmcl.cvp.dataplatform.contract.userpreference.GeoFenceFeature;
import org.hmcl.cvp.dataplatform.contract.userpreference.UserPreference;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class IndividualAndTaggedFence {

    private String riderProfileId;

    private String primaryProfileId;

    private boolean isTagged;

    private GeoFenceFeature geoFenceFeature;

    public boolean getIsTagged() {
        return isTagged;
    }

    public void setIsTagged(boolean tagged) {
        isTagged = tagged;
    }

    public static List<IndividualAndTaggedFence> from(UserPreference rider) {
        List<GeoFenceFeature> activeFences = UserPreferenceUtils.getActiveGeoFences(rider);
        return activeFences.stream()
                .filter(a -> Objects.isNull(a.getTagProfiles()) || a.getTagProfiles().isEmpty())
                .map(f -> IndividualAndTaggedFence.builder()
                        .riderProfileId(rider.getProfileId())
                        .isTagged(false)
                        .geoFenceFeature(f)
                        .build())
                .collect(Collectors.toList());
    }

    public static List<IndividualAndTaggedFence> from(GeoUserPreference primary, String secondaryProfileId) {
        if (Objects.isNull(primary)) return new ArrayList<>();

        UserPreference primaryUser = primary.getUserPreference();
        List<GeoFenceFeature> taggedFences = UserPreferenceUtils.getTaggedFences(primaryUser, secondaryProfileId);
        return taggedFences.stream()
                .map(f -> IndividualAndTaggedFence.builder()
                        .riderProfileId(secondaryProfileId)
                        .primaryProfileId(primaryUser.getProfileId())
                        .isTagged(true)
                        .geoFenceFeature(f)
                        .build())
                .collect(Collectors.toList());
    }

    public String getFenceId() {
        if (Objects.isNull(geoFenceFeature)) return null;
        return geoFenceFeature.getId();
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof IndividualAndTaggedFence)) return false;
        IndividualAndTaggedFence fence = (IndividualAndTaggedFence) o;
        return Objects.equals(geoFenceFeature, fence.geoFenceFeature);
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(geoFenceFeature);
    }
}
