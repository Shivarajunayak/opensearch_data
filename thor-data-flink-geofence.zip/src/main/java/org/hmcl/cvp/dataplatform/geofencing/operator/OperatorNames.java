package org.hmcl.cvp.dataplatform.geofencing.operator;

public class OperatorNames {

    public static final String USER_PREFERENCE_SOURCE = "geofence-user-preference-source";
    public static final String GEOFENCE_CAMPAIGN_SOURCE = "geofence-campaign-source";
    public static final String TELEMETRY_SOURCE = "geofence-telemetry-source";
    public static final String STATE_TRANSITION = "geofence-state-transition";
    public static final String VALID_GPS_FILTER = "geofence-valid-gps-filter";
    public static final String NOTIFICATION_MAPPER = "geofence-notification-mapper";
    public static final String AUTO_IMMOBILIZATION = "geofence-auto-immobilization";
    public static final String NOTIFICATION_SINK = "geofence-notification-sink";
    public static final String COMMAND_SINK = "geofence-command-sink";
    public static final String FILE_SINK = "geofence-file-sink";
    private OperatorNames() {
    }
}
