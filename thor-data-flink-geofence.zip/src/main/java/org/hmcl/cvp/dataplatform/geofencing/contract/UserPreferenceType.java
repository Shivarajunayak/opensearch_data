package org.hmcl.cvp.dataplatform.geofencing.contract;

public enum UserPreferenceType {

    PRIMARY("PRIMARY"),
    RIDER("RIDER");

    private final String value;

    UserPreferenceType(String value) {
        this.value = value;
    }

    public String value() {
        return value;
    }
}
