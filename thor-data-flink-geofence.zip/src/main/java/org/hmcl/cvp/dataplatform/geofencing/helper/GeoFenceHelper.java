package org.hmcl.cvp.dataplatform.geofencing.helper;

import lombok.extern.slf4j.Slf4j;
import org.apache.flink.api.java.tuple.Tuple2;
import org.hmcl.cvp.dataplatform.commons.catalogue.SignalCatalogue;
import org.hmcl.cvp.dataplatform.commons.utils.DateUtils;
import org.hmcl.cvp.dataplatform.commons.utils.GeoUtils;
import org.hmcl.cvp.dataplatform.commons.utils.SignalUtils;
import org.hmcl.cvp.dataplatform.commons.utils.UserPreferenceUtils;
import org.hmcl.cvp.dataplatform.contract.telemetry.SignalData;
import org.hmcl.cvp.dataplatform.contract.telemetry.SignalInfo;
import org.hmcl.cvp.dataplatform.contract.telemetry.Telemetry;
import org.hmcl.cvp.dataplatform.contract.userpreference.GeoFenceFeature;
import org.hmcl.cvp.dataplatform.contract.userpreference.UserPreference;
import org.hmcl.cvp.dataplatform.geofencing.contract.*;
import org.locationtech.jts.geom.Point;
import org.locationtech.jts.geom.Polygon;

import java.time.ZonedDateTime;
import java.util.*;
import java.util.stream.Collectors;

@Slf4j
public class GeoFenceHelper {

    private GeoFenceHelper() {}

    private static final Double INVALID_LAT_LONG = 0.0;

    public static UserPreferenceChanges getUpdatedUserPreferences(String incomingVid,
                                                                  UserPreference incomingUserPreference,
                                                                  Map<String, GeoUserPreference> cachedUserPreferences,
                                                                  GeoUserPreference cachedGeoUserPreference) {

        ZonedDateTime currentTime = DateUtils.currentDateTime();
        log.debug("Incoming User Preference for vehicle {} at {} - {} ", incomingVid, currentTime, incomingUserPreference);

        final Map<String, GeoUserPreference> finalState = new HashMap<>(cachedUserPreferences);

        boolean stateUpdated = false;
        boolean riderFlagChanged = false;
        List<IndividualAndTaggedFence> fenceDiff = new ArrayList<>();

        try {

            GeoUserPreference existingRider = getRider(cachedUserPreferences);

            String profileId = incomingUserPreference.getProfileId();
            boolean isRiderNow = incomingUserPreference.getIsRider();

            // Checking if incoming rider is the latest compared to the existing rider
            if (isRiderNow && !isLatestPreference(incomingUserPreference, existingRider)) {
                log.info("Incoming rider {} is older rider for vehicle {}", incomingUserPreference.getProfileId(), incomingVid);
                return UserPreferenceChanges.builder()
                        .updateState(false)
                        .riderChanged(false)
                        .updatedUserState(finalState)
                        .changedFences(fenceDiff)
                        .build();
            }

            boolean isPrimary = UserPreferenceUtils.isPrimary(incomingUserPreference);
            boolean wasUserARider = Objects.nonNull(existingRider) && existingRider.getProfileId().equals(incomingUserPreference.getProfileId());

            // Need this to invalidate the state
            riderFlagChanged = wasUserARider && !isRiderNow;

            log.debug("Incoming profile {}; isRiderNow {}; isPrimary {}; wasUserARider {}, riderFlagChanged {}",
                    profileId, isRiderNow, isPrimary, wasUserARider, riderFlagChanged);

            if (riderFlagChanged) {
                stateUpdated = true;

                log.info("Incoming primary is not a rider anymore. Removing from state for vehicle {}!", incomingVid);
                finalState.remove(UserPreferenceType.RIDER.value());
            }

            if(Objects.nonNull(existingRider)) log.debug("Cached user preference was updated on {} for vehicle {}", existingRider.getUpdatedTsp(), incomingVid);

            if (isRiderNow || isPrimary) {

                // Some state update is happening
                stateUpdated = true;

                log.info("Updating user preference {} updated on {} for vehicle {}", profileId, incomingUserPreference.getUpdatedTsp(), incomingVid);

                GeoUserPreference geoUserPreference = getGeoUserPreference(incomingVid, incomingUserPreference,
                        cachedUserPreferences);

                fenceDiff = getDiffOfGeoFences(geoUserPreference, cachedGeoUserPreference);

                // Updating primary value
                if (isPrimary) finalState.put(UserPreferenceType.PRIMARY.value(), geoUserPreference);

                // Updating rider value. If the primary is user, PRIMARY and RIDER values will be same
                // Only update the latest user as the rider. This is to handle the scenario where multiple users
                // can be riders due to data loss or out of order
                if (isRiderNow) finalState.put(UserPreferenceType.RIDER.value(), geoUserPreference);
            }

        } catch (Exception e) {
            log.error("Exception while updating user preference state for vehicle {} : ", incomingVid, e);
        }

        return UserPreferenceChanges.builder()
                .updateState(stateUpdated)
                .riderChanged(riderFlagChanged)
                .updatedUserState(finalState)
                .changedFences(fenceDiff)
                .build();

    }

    public static StateTransition checkForStateTransitions(String incomingVid,
                                                           Point currentLocation,
                                                           Map<String, VehicleState> cachedVehicleStates,
                                                           Map<String, Integer> exitCounters,
                                                           List<FenceAndPolygon> fencesAndPolygons) {

        log.debug("Checking for state transitions for vehicle {}", incomingVid);

        List<FenceAndState> transitionedFences = new ArrayList<>();
        Map<String, VehicleState> newStates = new HashMap<>(cachedVehicleStates);
        boolean stateUpdate = false;

        for (FenceAndPolygon f : fencesAndPolygons) {

            IndividualAndTaggedFence fence = f.getFence();
            Polygon polygon = f.getPolygon();
            String fenceId = fence.getFenceId();
            boolean vehicleExited = exitCounters.getOrDefault(fenceId, 0) >= 1;

            VehicleState baseState = getState(fenceId, cachedVehicleStates);

            log.debug("Base state for fence {} and vehicle {} is {}", fenceId, incomingVid, baseState);

            // ReCalculate base state
            if (Objects.isNull(baseState)) {
                stateUpdate = true;
                log.debug("Base state for fence {} and vehicle {} not found. So recalculating!", fenceId, incomingVid);
                baseState = createVehicleState(currentLocation, f);
                newStates.put(fenceId, baseState);
                continue;
            }

            VehicleState.State startingState = baseState.getStartingState();
            VehicleState.State newState = calculateStateTransition(incomingVid, currentLocation, polygon, startingState, vehicleExited);

            log.debug("State transitioned for fence {} and vehicle {} is {}", fenceId, incomingVid, newState);

            // Checking if the calculated state is the same as starting state
            // Since startingState is only updated with "OUT" state when the vehicle first started, checking if vehicle reentered
            if(VehicleState.State.transitionValues().contains(newState)) {
                stateUpdate = true;

                if (newState.equals(VehicleState.State.ENTRY)) {
                    // Reset the starting state when the vehicle reEnters
                    startingState = VehicleState.State.IN;
                }

                VehicleState vehicleState = VehicleState.builder()
                        .fenceId(fenceId)
                        .profileId(fence.getRiderProfileId())
                        .isTagged(fence.getIsTagged())
                        .primaryProfileId(fence.getPrimaryProfileId())
                        .startingState(startingState)
                        .transitionedState(newState)
                        .build();

                FenceAndState fenceAndState = FenceAndState.builder()
                        .fence(fence)
                        .vehicleState(vehicleState)
                        .build();

                transitionedFences.add(fenceAndState);
                newStates.put(fenceId, vehicleState);
            }

        }

        return StateTransition.builder()
                .stateUpdated(stateUpdate)
                .transitionedFences(transitionedFences)
                .vehicleState(newStates)
                .build();
    }

    public static GeoUserPreference getUserFromState(String incomingProfileId, Map<String, GeoUserPreference> stateValue) {
        if (stateValue.isEmpty()) return null;

        return stateValue.values()
                .stream()
                .filter(u -> incomingProfileId.equals(u.getProfileId()))
                .max(Comparator.comparing(GeoUserPreference::getUpdatedTsp))
                .orElse(null);

    }

    public static boolean isPrimaryUserAndNotARider( UserPreference incomingUserPreference) {
        return UserPreferenceUtils.isPrimary(incomingUserPreference) && !incomingUserPreference.getIsRider();
    }

    public static GeoUserPreference getGeoUserPreference(String incomingVid,
                                                         UserPreference userPreference,
                                                         Map<String, GeoUserPreference> cachedUserPreferences) {

        List<IndividualAndTaggedFence> incomingFences = getIndividualAndTaggedFences(userPreference, cachedUserPreferences);
        List<FenceAndPolygon> incomingFencesAndPolygons =  getGeoFencePolygons(incomingVid, incomingFences);

        return GeoUserPreference.builder()
                .userPreference(userPreference)
                .relatedFences(incomingFences)
                .fencesAndPolygons(incomingFencesAndPolygons)
                .build();
    }

    public static GeoUserPreference getRider(Map<String, GeoUserPreference> stateValue) {
        if (Objects.isNull(stateValue)) return null;

        if (stateValue.containsKey(UserPreferenceType.RIDER.value()))
            return stateValue.get(UserPreferenceType.RIDER.value());

        return null;
    }

    public static GeoUserPreference getPrimaryUser(Map<String, GeoUserPreference> stateValue) {
        if (Objects.isNull(stateValue)) return null;

        if (stateValue.containsKey(UserPreferenceType.PRIMARY.value()))
            return stateValue.get(UserPreferenceType.PRIMARY.value());

        return null;
    }

    public static List<IndividualAndTaggedFence> getIndividualAndTaggedFences(UserPreference user,
                                                                              Map<String, GeoUserPreference> cachedState) {

        boolean isPrimaryRider = UserPreferenceUtils.isPrimary(user);
        List<IndividualAndTaggedFence> wrapperFences = IndividualAndTaggedFence.from(user);

        if (!isPrimaryRider) {
            String secondaryProfile = user.getProfileId();
            // Getting tagged fences from primary user
            GeoUserPreference primary = getPrimaryUser(cachedState);

            if(Objects.nonNull(primary)) {
                wrapperFences.addAll( IndividualAndTaggedFence.from(primary, secondaryProfile));
            }

        }

        return wrapperFences;
    }

    public static List<IndividualAndTaggedFence> getRelatedFencesFromState(String incomingProfileId,
                                                                 Map<String, GeoUserPreference> cachedState) {
        if(cachedState.isEmpty()) return new ArrayList<>();
        return cachedState.values().stream()
                .filter(v -> Objects.nonNull(v.getRelatedFences()) && !v.getRelatedFences().isEmpty())
                .flatMap(v -> v.getRelatedFences().stream())
                .filter(f -> incomingProfileId.equals(f.getRiderProfileId()))
                .collect(Collectors.toList());
        }

    public static List<FenceAndPolygon> getGeoFencePolygons(String incomingVid, List<IndividualAndTaggedFence> relatedFences) {

        if (relatedFences.isEmpty()) {
            log.warn("No fences found for {}.", incomingVid);
            return new ArrayList<>();
        }

        List<FenceAndPolygon> geoFencePolygons = new ArrayList<>(relatedFences.size());

        relatedFences.parallelStream().forEach(f -> {
            GeoFenceFeature feature = f.getGeoFenceFeature();
            Polygon polygon = GeoUtils.getShapeFromCoordinate(incomingVid, feature);

            if (Objects.nonNull(polygon)) {
                FenceAndPolygon fencesAndPolygon = FenceAndPolygon.builder()
                        .fence(f)
                        .polygon(polygon)
                        .build();
                geoFencePolygons.add(fencesAndPolygon);
            }

        });

        return geoFencePolygons;
    }

    public static List<IndividualAndTaggedFence> getDiffOfGeoFences(List<IndividualAndTaggedFence> incomingFences,
                                                                    List<IndividualAndTaggedFence> cachedFences) {

        // Get the differences. Supported fields for difference calculation is present in the equals and hashCode implementation
        List<IndividualAndTaggedFence> differences = new ArrayList<>(cachedFences);
        differences.removeAll(incomingFences);

        return differences;
    }

    public static List<IndividualAndTaggedFence> getDiffOfGeoFences(GeoUserPreference incomingUserPreference,
                                                                    GeoUserPreference cachedUserPreference) {

        List<IndividualAndTaggedFence> incomingFences = Objects.isNull(incomingUserPreference)
                ? new ArrayList<>()
                : incomingUserPreference.getRelatedFences();

        List<IndividualAndTaggedFence> cachedFences = Objects.isNull(cachedUserPreference)
                ? new ArrayList<>()
                : cachedUserPreference.getRelatedFences();

        return getDiffOfGeoFences(incomingFences, cachedFences);
    }

    public static List<IndividualAndTaggedFence> getDiffOfTaggedFences(GeoUserPreference incomingUserPreference,
                                                                       GeoUserPreference cachedUserPreference) {
        List<IndividualAndTaggedFence> incomingFences = Objects.isNull(incomingUserPreference)
                ? new ArrayList<>()
                : incomingUserPreference.getRelatedFences();

        List<IndividualAndTaggedFence> incomingTaggedFences = incomingFences.stream()
                .filter(IndividualAndTaggedFence::getIsTagged)
                .collect(Collectors.toList());

        List<IndividualAndTaggedFence> cachedFences = Objects.isNull(cachedUserPreference)
                ? new ArrayList<>()
                : cachedUserPreference.getRelatedFences();

        List<IndividualAndTaggedFence> cachedTaggedFences = cachedFences.stream()
                .filter(IndividualAndTaggedFence::getIsTagged)
                .collect(Collectors.toList());

        // When tagged fences are removed
        if(cachedTaggedFences.size() > incomingTaggedFences.size()) return getDiffOfGeoFences(incomingTaggedFences, cachedTaggedFences);

        return getDiffOfGeoFences(cachedTaggedFences, incomingTaggedFences);
    }


    public static boolean isLatestPreference(UserPreference incomingUserPref, GeoUserPreference cachedGeoUserPref) {
        if (Objects.isNull(cachedGeoUserPref)) return true;

        return incomingUserPref.getUpdatedTsp() >= cachedGeoUserPref.getUpdatedTsp();
    }

    public static List<Location> getLocationSignals(String vid, Telemetry incomingTelemetry, int digitsToIgnore, boolean simulator) {
        List<Location> locations = new ArrayList<>();

        List<SignalData> latitudeSignals = getOrderedSignals(incomingTelemetry, SignalCatalogue.getLatitudeInfo());
        List<SignalData> longitudeSignals = getOrderedSignals(incomingTelemetry, SignalCatalogue.getLongitudeInfo());
        List<SignalData> hDopSignals = getOrderedSignals(incomingTelemetry, SignalCatalogue.getHDopInfo());
        List<SignalData> gpsValidSignals = getOrderedSignals(incomingTelemetry, SignalCatalogue.getGpsValidInfo());

        if(latitudeSignals.isEmpty() || longitudeSignals.isEmpty() || hDopSignals.isEmpty() || gpsValidSignals.isEmpty()) return locations;

        // Since all the above signals are collected from one sensor, we need to have same number of signals
        Set<Integer> signalSizes = new HashSet<>();
        signalSizes.add(latitudeSignals.size());
        signalSizes.add(longitudeSignals.size());
        signalSizes.add(hDopSignals.size());
        signalSizes.add(gpsValidSignals.size());

        if(signalSizes.size() > 1) log.warn("Lat/Long/HDop/GPS Valid signals are of different sizes for vehicle {}", vid);

        int leastSize = Collections.min(signalSizes);

        for(int i = 0; i < leastSize; i++) {
            SignalData latitude = latitudeSignals.get(i);
            SignalData longitude = longitudeSignals.get(i);
            SignalData hDop = hDopSignals.get(i);
            SignalData gpsValid = gpsValidSignals.get(i);

            Location location = getLocation(latitude, longitude, hDop, gpsValid, digitsToIgnore, simulator);
            if(Objects.nonNull(location)) locations.add(location);
        }

        return locations;
    }

    public static List<SignalData> getOrderedSignals(Telemetry incomingTelemetry, SignalInfo signalInfo) {
        return SignalUtils.getSignals(incomingTelemetry, signalInfo).stream()
                .sorted(Comparator.comparing(SignalData::getTime))
                .collect(Collectors.toList());
    }

    // If all the n th signal has same timestamp has the normalised time, return location object else null
    public static Location getLocation(SignalData latitude,
                                       SignalData longitude,
                                       SignalData hDop,
                                       SignalData gpsValid,
                                       int digitsToIgnore,
                                       boolean simulator) {

        Set<Long> signalTimes = new HashSet<>();

        long latitudeTime = latitude.getTime();
        long normalizedLatTime = simulator ?  DateUtils.normalizeEpochMilli(latitudeTime, digitsToIgnore) : latitudeTime;
        signalTimes.add(normalizedLatTime);

        long longitudeTime = longitude.getTime();
        long normalizedLongTime = simulator ?  DateUtils.normalizeEpochMilli(longitudeTime, digitsToIgnore) : longitudeTime;
        signalTimes.add(normalizedLongTime);

        long hDopTime = hDop.getTime();
        long normalizedHDopTime = simulator ?  DateUtils.normalizeEpochMilli(hDopTime, digitsToIgnore) : hDopTime;
        signalTimes.add(normalizedHDopTime);

        long gpsValidTime = gpsValid.getTime();
        long normalizedGpsValidTime = simulator ?  DateUtils.normalizeEpochMilli(gpsValidTime, digitsToIgnore) : gpsValidTime;
        signalTimes.add(normalizedGpsValidTime);

        if(signalTimes.size() == 1) {
            return Location.builder()
                    .timestamp(normalizedLatTime)
                    .latitude(getDoubleValue(latitude))
                    .longitude(getDoubleValue(longitude))
                    .hDop(getDoubleValue(hDop))
                    .gpsValid(getBooleanValue(gpsValid))
                    .build();
        }

        return null;

    }

    public static double getDoubleValue(SignalData signalData) {
        return (double) signalData.getValue();
    }

    public static boolean getBooleanValue(SignalData signalData) {
        return (boolean) signalData.getValue();
    }

    public static long getNewestLocationTime(List<Location> locations) {
        return Collections.max(locations.stream().map(Location::getTimestamp).collect(Collectors.toList()));
    }

    public static boolean isLocationValid(Location location, double hDopThresholdValue) {
        double hDop = location.getHDop();
        boolean gpsValid = location.isGpsValid();

        return gpsValid && hDop <= hDopThresholdValue;
    }

    public static Point getLocationPoint(String incomingVid, Location location) {

        if (INVALID_LAT_LONG.equals(location.getLatitude()) || INVALID_LAT_LONG.equals(location.getLongitude())) {
            log.error("Invalid latitude and longitude captured for vehicle {}.", incomingVid);
            return null;
        }

        return GeoUtils.getLocationPoint(new Tuple2<>(location.getLatitude(), location.getLongitude()));

    }

    public static VehicleState.State calculateState(Point location, Polygon polygon) {
        if (Objects.isNull(location) || Objects.isNull(polygon)) return VehicleState.State.UNKNOWN;

        if (GeoUtils.pointInsidePolygon(location, polygon)) return VehicleState.State.IN;

        return VehicleState.State.OUT;

    }

    public static VehicleState.State calculateStateTransition(String incomingVid,
                                                              Point currentLocation,
                                                              Polygon polygon,
                                                              VehicleState.State startingState,
                                                              boolean vehicleHadBreached) {

        VehicleState.State newState = calculateState(currentLocation, polygon);

        log.debug("Vehicle: {}, Current Location: {}, starting State: {}, new state: {}, anyBreaches: {}",
                incomingVid, currentLocation.getCoordinate(), startingState, newState, vehicleHadBreached);

        // Vehicle was outside the fence when started and it reEntered
        if(newState.equals(VehicleState.State.IN) && startingState.equals(VehicleState.State.OUT)) return VehicleState.State.ENTRY;

        // Vehicle was inside fence when started and it exited
        if(newState.equals(VehicleState.State.OUT) && startingState.equals(VehicleState.State.IN)) return VehicleState.State.EXIT;

        // Vehicle reEntered fence
        if(vehicleHadBreached && newState.equals(VehicleState.State.IN)) return VehicleState.State.ENTRY;

        return VehicleState.State.UNKNOWN;
    }

    public static VehicleState getState(String fenceId, Map<String, VehicleState> vehicleStates) {
        if (vehicleStates.isEmpty()) return null;

        return vehicleStates.values().stream()
                .filter(v -> v.getFenceId().equals(fenceId))
                .findFirst()
                .orElse(null);

    }

    public static Map<String, VehicleState> getValidStates(Map<String, VehicleState> states) {
        if (states.isEmpty()) return states;

        // Filter out unknown states
        return states.values().stream()
                .filter(s -> !s.getStartingState().equals(VehicleState.State.UNKNOWN))
                .collect(Collectors.toMap(VehicleState::getFenceId, v -> v));
    }

    public static VehicleState createVehicleState(Point currentLocation, FenceAndPolygon fenceAndPolygon) {
        IndividualAndTaggedFence fence = fenceAndPolygon.getFence();
        Polygon polygon = fenceAndPolygon.getPolygon();
        String fenceId = fence.getFenceId();

        VehicleState.State state = calculateState(currentLocation, polygon);

        return VehicleState.builder()
                .fenceId(fenceId)
                .profileId(fence.getRiderProfileId())
                .isTagged(fence.getIsTagged())
                .primaryProfileId(fence.getPrimaryProfileId())
                .startingState(state)
                .build();
    }

    public static Map<String, VehicleState> getStateUpdates(String incomingVid,
                                                            Point currentLocation,
                                                            List<FenceAndPolygon> fencesAndPolygons) {

        log.debug("Updating state for vehicle {}", incomingVid);

        Map<String, VehicleState> vehicleStates = new HashMap<>();
        if (fencesAndPolygons.isEmpty()) return vehicleStates;

        for (FenceAndPolygon f : fencesAndPolygons) {
            IndividualAndTaggedFence fence = f.getFence();
            String fenceId = fence.getFenceId();
            VehicleState vehicleState = createVehicleState(currentLocation, f);
            vehicleStates.put(fenceId, vehicleState);
        }

        return getValidStates(vehicleStates);
    }

}
