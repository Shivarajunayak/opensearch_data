package org.hmcl.cvp.dataplatform.geofencing.contract;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.locationtech.jts.geom.Polygon;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class FenceAndPolygon {

    private IndividualAndTaggedFence fence;

    private Polygon polygon;

}
