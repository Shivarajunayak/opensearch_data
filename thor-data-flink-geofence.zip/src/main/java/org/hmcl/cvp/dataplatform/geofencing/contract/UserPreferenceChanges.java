package org.hmcl.cvp.dataplatform.geofencing.contract;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;
import java.util.Map;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class UserPreferenceChanges {

    private boolean updateState;

    private boolean riderChanged;

    private boolean isPrimary;

    private List<IndividualAndTaggedFence> changedFences;

    private Map<String, GeoUserPreference> updatedUserState;
}
