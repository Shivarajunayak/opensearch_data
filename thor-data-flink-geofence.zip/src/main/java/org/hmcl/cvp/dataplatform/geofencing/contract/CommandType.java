package org.hmcl.cvp.dataplatform.geofencing.contract;

import com.google.gson.annotations.SerializedName;

import java.util.HashMap;
import java.util.Map;

public enum CommandType {

    @SerializedName("UDS")
    UDS("UDS"),

    @SerializedName("NON_UDS")
    NON_UDS("NON_UDS");

    private static final Map<String, CommandType> CONSTANTS = new HashMap<>();

    static {
        for (CommandType c : values()) {
            CONSTANTS.put(c.value, c);
        }
    }

    private final String value;

    CommandType(String value) {
        this.value = value;
    }

    public static CommandType fromValue(String value) {
        CommandType constant = CONSTANTS.get(value);
        if (constant == null) {
            throw new IllegalArgumentException(value);
        } else {
            return constant;
        }
    }

    @Override
    public String toString() {
        return this.value;
    }

    public String value() {
        return this.value;
    }

}
