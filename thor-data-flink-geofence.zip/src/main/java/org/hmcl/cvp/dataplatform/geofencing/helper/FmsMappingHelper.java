package org.hmcl.cvp.dataplatform.geofencing.helper;

import lombok.extern.slf4j.Slf4j;
import org.hmcl.cvp.dataplatform.contract.notification.AlertInfo;
import org.hmcl.cvp.dataplatform.contract.notification.AlertType;
import org.hmcl.cvp.dataplatform.geofencing.contract.FmsMapping;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.*;

@Slf4j
public class FmsMappingHelper {

    private FmsMappingHelper() {}

    public static String getFmsMappingFileName(String env) {
        return String.format("fms-mappings-%s.properties", env.toLowerCase());
    }

    public static Properties getProperties(String env) {
        final String fileName = getFmsMappingFileName(env);
        final Properties properties = new Properties();
        ClassLoader classLoader = FmsMappingHelper.class.getClassLoader();
        try
        {
            var fileInputStream =  classLoader.getResourceAsStream(fileName);
            properties.load(fileInputStream);
        } catch(Exception e) {
            log.error("Exception while loading {} ", fileName, e);
        }
        log.info("properties extracted from resource file is {} ",properties);
        return properties;
    }

    public static AlertInfo getAlertInfo(String env) {
        Properties properties = getProperties(env);

        if(properties.isEmpty()) return null;

        String baseKey = FmsMapping.GEOFENCE_BREACH.value();
        String code = baseKey + ".code";
        String name = baseKey + ".name";
        String type = baseKey + ".type";

        if(!properties.containsKey(code) || !properties.containsKey(name) || !properties.containsKey(type)) return null;

        String typeString = properties.getProperty(type);
        AlertType alertType = AlertType.fromValue(typeString);

        return AlertInfo.builder()
                .code(properties.getProperty(code))
                .type(alertType)
                .name(properties.getProperty(name))
                .build();
    }

    public static String getAutoImmobilizationCode(String env) {
        Properties properties = getProperties(env);

        if(properties.isEmpty()) return null;

        String baseKey = FmsMapping.AUTO_IMMOBILIZATION.value();
        String code = baseKey + ".code";

        return properties.getProperty(code);
    }

}
