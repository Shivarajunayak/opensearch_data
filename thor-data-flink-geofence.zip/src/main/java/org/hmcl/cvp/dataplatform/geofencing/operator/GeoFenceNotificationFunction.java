package org.hmcl.cvp.dataplatform.geofencing.operator;

import lombok.extern.slf4j.Slf4j;
import org.apache.flink.configuration.Configuration;
import org.apache.flink.metrics.Counter;
import org.apache.flink.util.Collector;
import org.hmcl.cvp.dataplatform.commons.operator.AlertNotificationFlatMap;
import org.hmcl.cvp.dataplatform.commons.utils.TelemetryUtils;
import org.hmcl.cvp.dataplatform.contract.enriched.AlertNotification;
import org.hmcl.cvp.dataplatform.contract.notification.AlertDetails;
import org.hmcl.cvp.dataplatform.contract.notification.AlertPriority;
import org.hmcl.cvp.dataplatform.contract.notification.Notification;
import org.hmcl.cvp.dataplatform.geofencing.contract.EnrichedGeoFence;
import org.hmcl.cvp.dataplatform.geofencing.contract.GeoEnrichedTelemetry;
import org.hmcl.cvp.dataplatform.geofencing.contract.Location;

import java.io.Serializable;
import java.time.Instant;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

@Slf4j
public class GeoFenceNotificationFunction extends AlertNotificationFlatMap<GeoEnrichedTelemetry> implements Serializable {

    private transient Counter numBreachEventCounter;
    private transient Counter numReEntryEventCounter;

    @Override
    public void open(Configuration parameters) throws Exception {
        super.open(parameters);
        numBreachEventCounter = counterInitializer("numBreachEvents");
        numReEntryEventCounter = counterInitializer("numReEntryEvents");
    }

    @Override
    public void flatMap(GeoEnrichedTelemetry value, Collector<String> out) throws Exception {
        String vid = TelemetryUtils.getVirtualId(value.getTelemetry());

        // Collecting any first time exit breaches
        List<String> exitNotifications = getExitNotifications(vid, value);
        exitNotifications.forEach(out::collect);

        // Collecting any reEntries
        List<String> reEntryNotifications = getReEntryNotifications(vid, value);
        reEntryNotifications.forEach(out::collect);
    }

    private List<String> getExitNotifications(String vid, GeoEnrichedTelemetry value) {
        Set<EnrichedGeoFence> enrichedGeoFences = value.getEnrichedGeoFences();
        Set<EnrichedGeoFence> firstBreaches = enrichedGeoFences.stream()
                .filter(v -> v.isExit() && v.getIsFirstAlert())
                .collect(Collectors.toSet());

        log.info("Number of exit alerts to be notified for vehicle {} is {}", vid, firstBreaches.size());

        List<String> notifications = new ArrayList<>(firstBreaches.size());
        for (EnrichedGeoFence enrichedGeoFence : firstBreaches) {
            log.debug("Sending geo fence breach alert {} for vehicle {}", enrichedGeoFence.getFenceId(), vid);
            Notification notification = createNotification(value, enrichedGeoFence);
            notification.setAlertPriority(getAlertPriorityForBreach());
            notification.setNotificationReasoning("Vehicle exited fence");
            notifications.add(GSON.toJson(notification));

            numInputEventCounter.inc();
            numBreachEventCounter.inc();
        }

        log.debug("Vehicle {} Exit notifications: {}", vid, notifications);

        return notifications;
    }

    private List<String> getReEntryNotifications(String vid, GeoEnrichedTelemetry value) {
        Set<EnrichedGeoFence> enrichedGeoFences = value.getEnrichedGeoFences();
        Set<EnrichedGeoFence> reEntries = enrichedGeoFences.stream()
                .filter(EnrichedGeoFence::isEntry)
                .collect(Collectors.toSet());

        List<String> notifications = new ArrayList<>(reEntries.size());
        for (EnrichedGeoFence enrichedGeoFence : reEntries) {
            log.debug("Sending geo fence re-entry alert {} for vehicle {}", enrichedGeoFence.getFenceId(), vid);
            Notification notification = createNotification(value, enrichedGeoFence);
            notification.setAlertPriority(getAlertPriorityForBreach());
            notification.setNotificationReasoning("Vehicle Re-Entered fence");

            notifications.add(GSON.toJson(notification));

            numInputEventCounter.inc();
            numReEntryEventCounter.inc();
        }

        log.debug("Vehicle {} Entry notifications: {}", vid, notifications);
        return notifications;
    }

    private Notification createNotification(GeoEnrichedTelemetry value, EnrichedGeoFence enrichedGeoFence) {
        Notification notification = getNotification(value);
        notification.setNotificationRequired(true);
        // Setting the timestamp of the lat-long signals where the breach happened
        notification.setEventTimestamp(String.valueOf(enrichedGeoFence.getBreachTimestamp()));

        AlertNotification alertNotification = value.getNotification();
        notification.setGeofenceId(enrichedGeoFence.getFenceId());
        notification.setAlertCode(alertNotification.getAlertCode());
        notification.setAlertName(alertNotification.getAlertName());

        // Setting alert details
        AlertDetails alertDetails = notification.getAlertDetails();
        Location location = enrichedGeoFence.getLocation();
        alertDetails.setLatitude(location.getLatitude());
        alertDetails.setLongitude(location.getLongitude());
        alertDetails.setHDop(location.getHDop());
        alertDetails.setGpsValidity(location.isGpsValid());

        alertDetails.setBoundaryCondition(enrichedGeoFence.getFenceType());
        notification.setAlertDetails(alertDetails);

        // Additional details
        // Added Extra fields for debugging
        notification.setAlert(true);
        notification.setNotificationSystemTimeStamp(Instant.now().toEpochMilli());

        return notification;
    }

    // By default, all alerts will be high priority
    private AlertPriority getAlertPriorityForBreach() {
        return AlertPriority.HIGH;
    }

}
