#!/bin/bash -e

java_home=
tmp_files=

umask 077

source $PWD/../config.cfg
THIS_DIR="$( cd -P "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"

function make_tmp() {

    local var="$1"
    local t="$(mktemp)"
    eval ${var}="${t}"
    tmp_files="$tmp_files $t"

}

function cleanup() {

    echo "Cleaning up"
    if test -n "$tmp_files"; then
        rm $tmp_files
    fi

}

function notthere() {

    if ! test -f "$1"; then
        return 0
    fi

    echo "$1 exists, will not re-create"
    echo "remove and re-start me to re-create it"

    return 1

}

moo=`dd if=/dev/urandom bs=512 count=1 status=none | sha256sum | awk '{print $1}'`

# $1 - prompt
# $2 - variable to store into
# $3 - 0 - ask for password
# $3 - 1 - ask and confirm password
# $4 (if set) - min chars
function get_pass() {

    local var="$2"
    local cfm
    local p

    while true; do

        p="Enter $1"
        if test -n "$4"; then
            p="$p ($4 chars min)"
        fi
        p="${p}:"

        read -r -s -p "$p" $var
        echo

        v="$(eval echo \$$var)"
        if test -z "$v"; then
            echo "Password can not be empty"
            continue
        fi

        if test -n "$4"; then
            p=$(echo -n $v|wc -c)
            p=$(expr $p + 0)
            if test $p -lt "$4"; then
                echo "At least $4 characters required"
                continue
            fi
        fi

        if test "$3" -eq 0; then return; fi;

        read -r -s -p "Re-enter $1:" cfm
        echo

        if test "$v" == $cfm; then
            return
        fi

        echo "Passwords don't match"

    done
}

trap cleanup EXIT

set -e

if test -n "$JDK_HOME"; then
    java_home="$JDK_HOME"
elif test -n "$JAVA_HOME"; then
    java_home="$JAVA_HOME";
fi

if test -n "$java_home"; then
    javac="$java_home"/bin/javac
    java="$java_home"/bin/java
    keytool="$java_home"/bin/keytool
else
    javac=javac
    java=java
    keytool=keytool
fi

for i in $java $javac $keytool; do

    if type -p "$i" > /dev/null; then
        true;
    else
        echo "$i not found"
        echo "Either set your JDK_HOME or JAVA_HOME environment variables"
        echo "Or make sure java bin directory is in the path"
        exit 1
    fi

done

mvn -v >/dev/null || {
    echo "You don't have Maven executable. Please install Maven"
    echo "And make sure that 'mvn' is in your $PATH"
    exit 1
}

# download dependencies

mvn org.apache.maven.plugins:maven-dependency-plugin:3.1.1:get -Dartifact=org.bouncycastle:bcprov-jdk15on:1.60:jar
mvn org.apache.maven.plugins:maven-dependency-plugin:3.1.1:get -Dartifact=org.bouncycastle:bcprov-jdk15on:1.46:jar
mvn org.apache.maven.plugins:maven-dependency-plugin:3.1.1:get -Dartifact=org.bouncycastle:bcprov-jdk15on:1.68:jar

make_tmp maven_repo
mvn help:evaluate -Dexpression=settings.localRepository -q -Doutput="$maven_repo"
maven_repo="$(cat "$maven_repo")"

bcp_160="$(find "$maven_repo" -name bcprov-jdk15on-1.60.jar|head -1)"
bcp_146="$(find "$maven_repo" -name bcprov-jdk15on-1.46.jar|head -1)"

if ! test -f ca/ca.pem; then
    echo "You haven't created CA certificate! Create it first"
    echo "(If you are not running me from pki directory, please do)"
    exit 0
fi

# check if we need to create CA trust store

if notthere signature_truststore.jks; then

    if [[ -f ca_old/ca.pem && -f ca/ca_inter.pem ]]; then
        $keytool -importcert -noprompt -v -file ca_old/ca.pem -alias xl4ca -keystore $THIS_DIR/signature_truststore.jks -storepass ${SIGNATURE_TRUSTSTORE_JKS_PWD} -trustcacerts
    else
        $keytool -importcert -noprompt -v -file ca/ca.pem -alias xl4ca -keystore $THIS_DIR/signature_truststore.jks -storepass ${SIGNATURE_TRUSTSTORE_JKS_PWD} -trustcacerts
    fi

fi

if notthere server_signature_truststore.jks; then

    $keytool -importcert -noprompt -v -file ca/ca.pem -alias xl4ca -keystore $THIS_DIR/server_signature_truststore.jks -storepass ${SERVER_SIGNATURE_TRUSTSTORE_JKS_PWD} -trustcacerts

fi

if notthere device_connector_truststore.jks; then

    if [[ -f ca_old/ca.pem && -f ca/ca_inter.pem ]]; then
        cat ca_old/ca.pem ca/ca.pem > $THIS_DIR/all_ca.pem
        CERTS=$(grep 'END CERTIFICATE' all_ca.pem | wc -l)
        for N in $(seq 0 $(($CERTS - 1))); do
            ALIAS="xl4ca-$N"
            cat $THIS_DIR/all_ca.pem |
            awk "n==$N { print }; /END CERTIFICATE/ { n++ }" |
            keytool -noprompt -import -trustcacerts -alias $ALIAS -keystore $THIS_DIR/device_connector_truststore.jks -storepass ${DEVICE_CONNECTOR_TRUSTSTORE_JKS_PWD}
        done
    else
        $keytool -importcert -noprompt -v -file ca/ca.pem -alias xl4ca -keystore $THIS_DIR/device_connector_truststore.jks -storepass ${DEVICE_CONNECTOR_TRUSTSTORE_JKS_PWD} -trustcacerts
    fi

fi

af=0

if test -z "$1"; then

    echo "Creates java stores for specific subject or all?"
    echo "Type subject directory, or say '*' to try all"
    read -p "What would be your answer?" inp

    if test "$inp" = "*"; then
        inp="*/cert.pem"
    elif test -z "$inp"; then
        echo "So shall it be"
        exit 1
    else
        inp="$inp/cert.pem"
    fi

else

    af=1
    inp="$*"

fi

for i in $inp; do

    if test $af -eq 1; then
        i="$i/cert.pem"
    fi

    if ! test -f "$i"; then
        echo "$i doesn't exist, $(dirname $i) skipped"
    fi

    echo "Processing directory $(dirname $i)"

    jks="$(dirname $i)/device_connector_keystore.jks"

    if ! test -f "$jks"; then
        make_tmp pkcs12
        openssl pkcs12 -export -out "$pkcs12" -CAfile ca/ca.pem -in "$i" -inkey "$(dirname $i)/private.pem" -chain -name "xl4cert" -passout pass:${DEVICE_CONNECTOR_KEYSTORE_JKS_PWD} -caname xl4ca

    fi

    if notthere "$jks"; then

        $keytool -importkeystore -noprompt -srckeystore "$pkcs12" -srcstoretype pkcs12 \
            -srcalias "xl4cert" -destkeystore "$jks" -srcstorepass ${DEVICE_CONNECTOR_KEYSTORE_JKS_PWD} -destkeypass "${DEVICE_CONNECTOR_KEYSTORE_KEY_PWD}" \
            -deststoretype jks -deststorepass ${DEVICE_CONNECTOR_KEYSTORE_JKS_PWD} -destalias xl4cert  -storetype jks

    fi

    frontend_jks ()
    {
        if [[ $PATH_TO_FRONTEND_KEYSTORE_JKS == '' ]] ; then
            if notthere frontend.jks; then
                make_tmp frontend
                openssl pkcs12 -export -inkey ${PATH_TO_PRIVATE_KEY} -in ${PATH_TO_CRT_FILE} -certfile ${PATH_TO_BUNDLE_FILE} -name xl4cert -out "$frontend" -caname ca1 -caname ca2 -passout pass:${FRONTEND_KEYSTORE_JKS_PASSWORD}

                echo "Generating frontend.jks file"
                $keytool -importkeystore -srckeystore "$frontend" -srcstorepass ${FRONTEND_KEYSTORE_JKS_PASSWORD} -srcstoretype pkcs12 -deststoretype jks -deststorepass ${FRONTEND_KEYSTORE_JKS_PASSWORD} -destkeypass ${FRONTEND_KEYSTORE_KEY_PASSWORD} -srcalias xl4cert -destalias xl4cert -destkeystore frontend.jks
            fi
        else
            cp -rf $PATH_TO_FRONTEND_KEYSTORE_JKS $THIS_DIR
        fi
    }

    if [[ ${FRONTEND_SSL} == "enable" ]]; then frontend_jks; fi

    tsp_jks ()
    {
        if [[ $PATH_TO_TSP_TRUSTSTORE_JKS == '' ]] ; then
            if notthere tsp_truststore.jks; then
                if [[ -f ca_old/ca.pem && -f ca/ca_inter.pem ]]; then
                    cat ca_old/ca.pem ca/ca.pem > $THIS_DIR/all_ca.pem
                    CERTS=$(grep 'END CERTIFICATE' all_ca.pem | wc -l)
                    for N in $(seq 0 $(($CERTS - 1))); do
                        ALIAS="xl4ca-$N"
                        cat $THIS_DIR/all_ca.pem |
                        awk "n==$N { print }; /END CERTIFICATE/ { n++ }" |
                        keytool -noprompt -import -trustcacerts -alias $ALIAS -keystore $THIS_DIR/tsp_truststore.jks -storepass ${TSP_TRUSTSTORE_JKS_PASSWORD}
                    done
                else
                    $keytool -importcert -noprompt -v -file ca/ca.pem -alias xl4ca -keystore $THIS_DIR/tsp_truststore.jks -storepass ${TSP_TRUSTSTORE_JKS_PASSWORD} -trustcacerts
                fi
            fi
            else
                cp -rf $PATH_TO_TSP_TRUSTSTORE_JKS $THIS_DIR
        fi

        if [[ $PATH_TO_TSP_KEYSTORE_JKS == '' ]] ; then
            if notthere tsp_keystore.jks; then
                make_tmp tsp
                openssl pkcs12 -export -out "$tsp" -CAfile ca/ca.pem -in "$i" -inkey "$(dirname $i)/private.pem" -chain -name "xl4cert" -passout pass:${TSP_KEYSTORE_JKS_PASSWORD} -caname xl4ca

                echo "Generating tsp_keystore.jks file"
                $keytool -importkeystore -srckeystore "$tsp" -srcstorepass ${TSP_KEYSTORE_JKS_PASSWORD} -srcstoretype pkcs12 -deststoretype jks -deststorepass ${TSP_KEYSTORE_JKS_PASSWORD} -destkeypass ${TSP_KEYSTORE_KEY_PASSWORD} -srcalias xl4cert -destalias xl4cert -destkeystore tsp_keystore.jks
            fi
        else
            cp -rf $PATH_TO_TSP_KEYSTORE_JKS $THIS_DIR
        fi
    }

    if [[ ${TSP_SSL} == "enable" ]]; then tsp_jks; fi

    sso_jks ()
    {
        if [[ $PATH_TO_SSO_TRUSTSTORE_JKS == '' ]] ; then
            if notthere sso_truststore.jks; then
                if [[ -f ca_old/ca.pem && -f ca/ca_inter.pem ]]; then
                    cat ca_old/ca.pem ca/ca.pem > $THIS_DIR/all_ca.pem
                    CERTS=$(grep 'END CERTIFICATE' all_ca.pem | wc -l)
                    for N in $(seq 0 $(($CERTS - 1))); do
                        ALIAS="xl4ca-$N"
                        cat $THIS_DIR/all_ca.pem |
                        awk "n==$N { print }; /END CERTIFICATE/ { n++ }" |
                        keytool -noprompt -import -trustcacerts -alias $ALIAS -keystore $THIS_DIR/sso_truststore.jks -storepass ${SSO_TRUSTSTORE_JKS_PASSWORD}
                    done
                else
                    $keytool -importcert -noprompt -v -file ca/ca.pem -alias xl4ca -keystore $THIS_DIR/sso_truststore.jks -storepass ${SSO_TRUSTSTORE_JKS_PASSWORD} -trustcacerts
                fi
            fi
            else
                cp -rf $PATH_TO_SSO_TRUSTSTORE_JKS $THIS_DIR
        fi

        if [[ $PATH_TO_SSO_KEYSTORE_JKS == '' ]] ; then
            if notthere sso_keystore.jks; then
                make_tmp sso
                openssl pkcs12 -export -out "$sso" -CAfile ca/ca.pem -in "$i" -inkey "$(dirname $i)/private.pem" -chain -name "xl4cert" -passout pass:${SSO_KEYSTORE_JKS_PASSWORD} -caname xl4ca

                echo "Generating sso_keystore.jks file"
                $keytool -importkeystore -srckeystore "$sso" -srcstorepass ${SSO_KEYSTORE_JKS_PASSWORD} -srcstoretype pkcs12 -deststoretype jks -deststorepass ${SSO_KEYSTORE_JKS_PASSWORD} -destkeypass ${SSO_KEYSTORE_KEY_PASSWORD} -srcalias xl4cert -destalias xl4cert -destkeystore sso_keystore.jks
            fi
        else
            cp -rf $PATH_TO_SSO_KEYSTORE_JKS $THIS_DIR
        fi
    }

    if [[ ${SSO_SSL} == "enable" ]]; then sso_jks; fi

done
