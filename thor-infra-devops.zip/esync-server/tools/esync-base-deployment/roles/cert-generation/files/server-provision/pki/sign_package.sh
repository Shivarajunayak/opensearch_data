#!/bin/bash

# args : 
# $1 - file to sign
# $2 - signed file
# $3 - private key file
# $4... - certificates for the chain

set -e

if test "$#" -lt 4; then
    cat << _EOF_
Usage: $0 <path_orig> <path_signed> <private_key> <cert1> [... <certN>]
  path_orig - path package (.zip) to sign
  path_signed - file name (with path) to write signed pacakge to
  private_key - private key to sign with
  cert1 .. certN - certificate to include into the signature
_EOF_
    exit 1
fi

trap cleanup EXIT
trap cleanup_s 2
trap cleanup_s 3

tmpdir=
sigfile=

function cleanup_s() {
    cleanup 1
}

function cleanup() {
    local rc=$?
    # echo "EXIT : $rc -- $1"
    test -z "$GSM_IN" -a "$rc" -ne 0 && {
        echo
        echo "!!! ------------------------------------------------------ !!!"
        echo "!!! The script had failed with an unexpected error         !!!"
        echo "!!! ------------------------------------------------------ !!!"
    }

    test -n "$tmpdir" && rm -rf "$tmpdir"
    test -n "$sigfile" && rm -f "$sigfile"

    if test -n "$1"; then
        # if we are coming from a signal, let's set GSM_IN
        # to prevent duplicate error message
        export GSM_IN=1
        exit $1
    fi

    return $rc
}

function check_time() {

    openssl x509 -in $1 -noout -checkend 86400 >/dev/null || {
        cat <<_EOF_
************************************************************
* [33;41;5;1mEXPIRED CERTIFICATE WARNING![0m                             *
************************************************************
One of the Certificates that you are using in the signing chain
has either expired, or will expire in a day.

$1

(It's also possible the certificate is not active yet).
This may be a problem with the time on your system, but if
it is not, the content may not be accepted by the detination.

Current time: $(date)
Certificate validity:
_EOF_
        openssl x509 -in $1 -noout -dates
        echo '************************************************************'
    }

}

tmpdir="$(mktemp -d)"
sigfile="$(mktemp)"

to_sign="$(readlink -f "$1")"
result="$(readlink -f "$2")"
pk="$(readlink -f "$3")"

(
    cd "$tmpdir"
    unzip $to_sign
)

encrypted=false
openssl rsa -passin pass:x -in "$pk" -noout >/dev/null 2>&1 || encrypted=true

if $encrypted; then
    read -s -p "Private key password:" pkp
    echo
    if test -n "$pkp"; then
        pkp_env="$pkp"
        pkp="-passin env:pkp_env"
        export pkp_env
    fi
fi

echo "2.16.840.1.101.3.4.2.3" >> "$sigfile"

(
    cd "$tmpdir"
    # $TODO : this is intolerant of spaces in file names
    for i in $(find . -type f|cut -c3-); do
        echo "$i" >> "$sigfile"
        # openssl sha512 -sign "$pk" $pkp $i | openssl base64 -e | tr '\n' ' ' | sed 's/ //g' >> "$sigfile"
        openssl sha512 -binary $i | openssl base64 -e | tr '\n' ' ' | sed 's/ //g' >> "$sigfile"
        echo >> "$sigfile"
    done
    # echo "----- END -----" >> "$sigfile"
)

shift 3
main_cert="$(readlink -f $1)"

check_time $main_cert

add_cert=""
all_cert="$main_cert"
shift 1
while test $# -gt 0; do
    # openssl x509 -in $1 >> $sigfile
    add_cert="$add_cert -certfile $(readlink -f $1)"
    all_cert="$all_cert $1"
    check_time $1
    shift
done

rm -f "$result"

(
    cd "$tmpdir"
    cp "$sigfile" xl4-signature.txt
    openssl smime -sign -out xl4-signature.p7 -outform DER -md sha512 -binary -signer $main_cert $add_cert -inkey $pk $pkp -in xl4-signature.txt
    zip -q9r "$result"  .
)

echo "$result created successfully"

exit 0

