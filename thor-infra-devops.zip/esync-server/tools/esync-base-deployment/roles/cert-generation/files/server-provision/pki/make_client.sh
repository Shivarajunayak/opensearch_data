#!/bin/bash

cd "$(dirname $0)" || {
    echo "Can not change into my own directory?"
}

echo "Using $(pwd) directory"
cn=

setno=1

function validate_rdn() {

    dn="$1"
    rdn_key="$2"
    rdn_val="$3"

    rdn_has="$(echo "${dn}/"|grep -o -e "/$rdn_key=[^/]*")"
    rdn_need="/$rdn_key=$rdn_val"

    if test "$rdn_has" != "$rdn_need"; then
        echo "Certificate has RDN $rdn_has but we need the value to be $rdn_need" >&2
        if ! read_yn "OK to override?" "y"; then
            exit 1
        fi
        echo "$(echo $dn | sed -e "s#${rdn_has}#${rdn_need}#")"
    else
        echo "$dn"
    fi

}

function read_yn() {
    prompt="$1"
    def="$2"
    if test -n "$def"; then
        prompt="$prompt [$def]"
    fi
    while true; do
        read -p "$prompt (y/n) " yn
        if test -z "$yn" -a -n "$def"; then
            yn="$def"
        fi
        if test "$yn" = "y"; then
            return 0
        elif test "$yn" = "n"; then
            return 1
        fi

        echo "I insist you answer explicitly"
    done
}

who=
function is_user() { test "$who" = "user"; }
function is_device() { test "$who" = "device"; }
function is_server() { test "$who" = "server"; }
function is_boota() { test "$who" = "boota"; }

# $TODO: support separate path for the server, since
# now we have multiple paths.
read -p "User, Device, Server or Boota? (U/D/S/B): " ud
case "$ud" in
    u|U*) who="user"; ;;
    d|D*) who="device"; ;;
    s|S*) who="server"; ;;
    b|B*) who="boota"; ;;
    *) echo "who?" ; exit 1; ;;
esac

dcn=
sdcn=

is_boota && dcn="boota"
test -n dcn && sdcn=" [$dcn] "
read -p "Enter $who CN${sdcn}:" -r cn
test -z "$cn" && cn="$dcn"
test -z "$cn" && {
    echo "CN can not be empty, I'm so sorry"
    exit 1
}

cdir="$(echo $cn | sed 's#/#_#g')"

is_request=false
test -f "$cdir/request.csr" && is_request=true

if ! $is_request; then
    mkdir "$cdir" || {
        echo "Can't create directory \"$cdir\""
        echo "May be it already exists? Then delete it first"
        echo "If you are trying to sign an issued certificate request"
        echo "It must be at $cdir/request.csr"
        exit 1
    }
fi

vid=
vid_oid=
userid=
tenancy=
tenancies=

can_updates=0
can_sign=0

if is_device; then
    can_updates=1
    read_yn "Can device access updates?" || can_updates=0
elif is_boota; then
    can_updates=1
else
    # this is true for both user and server
    can_sign=1
fi

if test $can_updates -eq 1 && ! is_boota; then
    read -p "Enter device ID OID [1.3.6.1.4.1.45473.1.10]: " vid_oid
    test -z "$vid_oid" && vid_oid="1.3.6.1.4.1.45473.1.10"
    read -p "Enter device ID (empty to use CN): " vid
    test -z "$vid" && vid="$cn";
    read -p "Enter vehicle database tenancy code [1]: " tenancy
    test -z "$tenancy" && tenancy=1
fi

if is_user; then
    echo "WARNING! The input for the user info has changed, please read the prompts carefully"
    read -p "Enter user name (without any other IDs) (empty to use CN): " user_name
    test -z "$user_name" && user_name="$cn"
    if echo "$user_name" | fgrep '::' >/dev/null ; then
        echo "Username (or any other user data properties) must not contain sequence \"::\""
        exit 1
    fi
    read -p "Enter SSO ID (consult your SSO implementation for value): " sso_id
    if test -z "$sso_id"; then
        echo "SSO ID must be specified"
        exit 1
    fi
    userid="$sso_id"'::'"$user_name"
    echo "Full user ID: $userid"
    start=${setno}
    while true; do
        prompt="Enter user tenancy"
        if test $setno -eq $start; then
            prompt="$prompt: "
        else
            prompt="$prompt (empty to end): "
        fi
        read -p "$prompt" u_tenancy
        if test -z "$u_tenancy"; then
            if test $start -eq $setno; then
                echo "ERROR! Tenancy can not be empty"
                exit 1
            fi
            break
        fi
        tenancy=$u_tenancy
        tenancies="1.3.6.1.4.1.45473.1.11=ASN1:SET:sota_tenancies"
        tenancy_list="${tenancy_list}|f$((setno++))=UTF8String:$u_tenancy"
    done
    read -p "Enter user_display_name: " user_display_name
    test -z "$user_display_name" ;
    read -p "Enter role: " role_name
    test -z "$role_name" ;
fi

if is_server; then
    read -p "Enter full domain name (empty to use CN): " domain_name
fi

# always set domain as it shows up in .req, even if unused.
test -z "$domain_name" && domain_name="$cn"

if is_server; then
    SAN="subjectAltName = @alt_server_names"
fi

group=

if is_device; then
    read -p "Enter device group [xl4_device]: " group
    if test -z "$group"; then
       group=xl4_device
    fi
elif is_user; then
    group=xl4_developer
elif is_boota; then
    group=xl4_device
else 
    group=xl4_server
fi

if test -n "$vid"; then
    vid="${vid_oid}=ASN1:UTF8String:$vid"
fi

if test -n "$role_name"; then
    role_name="2.5.4.72=ASN1:UTF8String:$role_name"
fi

if test -n "$user_display_name"; then
    user_display_name="2.16.840.1.113730.3.1.241=ASN1:UTF8String:$user_display_name"
fi

if test -n "$userid"; then
    userid="1.3.6.1.4.1.45473.1.4=ASN1:UTF8String:$userid"
fi

if test -n "$tenancy"; then
    tenancy="1.3.6.1.4.1.45473.1.5=ASN1:UTF8String:$tenancy"
fi

if is_boota; then
    boota="1.3.6.1.4.1.45473.1.8=ASN1:BOOLEAN:true"
fi

if test $can_updates -eq 1; then
    can_updates="f${setno}=IA5:sota"
    setno=$((setno+1))
else
    can_updates=""
fi

if test $can_sign -eq 1; then
   if read_yn "Should this be used as an intermediate workflow certificate?" "n"; then
     can_sign="f${setno}=IA5:workflow"
     setno=$((setno+1))
   else
    can_sign="f${setno}=IA5:sign"
    setno=$((setno+1))
   fi
else
    can_sign=""
fi

set -e

ca_dir=ca
test -n "$USE_CA_DIR" && ca_dir="$USE_CA_DIR"

cat > "${cdir}"/ca.conf << _EOF_

HOME			= .
RANDFILE		= \$ENV::HOME/.rnd
oid_section		= new_oids

[ new_oids ]
tsa_policy1 = 1.2.3.4.1
tsa_policy2 = 1.2.3.4.5.6
tsa_policy3 = 1.2.3.4.5.7

[ ca ]
default_ca	= CA_default		# The default ca section

[ CA_default ]

dir		= $(pwd)
certs		= \$dir/issued_certs		# Where the issued certs are kept
crl_dir		= \$dir/crl		# Where the issued crl are kept
database	= \$dir/ca/index.txt	# database index file.
unique_subject	= no
new_certs_dir	= \$dir/issued_certs

certificate	= ${ca_dir}/ca.pem
serial		= ${ca_dir}/serial 		# The current serial number
crlnumber	= \$dir/crlnumber	# the current crl number
					# must be commented out to leave a V1 CRL
crl		= \$dir/crl.pem 		# The current CRL
private_key	= ${ca_dir}/ca_private.pem
RANDFILE	= \$dir/private/.rand	# private random number file

x509_extensions	= usr_cert		# The extentions to add to the cert
name_opt 	= ca_default		# Subject Name options
cert_opt 	= ca_default		# Certificate field options

default_days	= 365			# how long to certify for
default_crl_days= 30			# how long before next CRL
default_md	= default		# use public key default MD
preserve	= no			# keep passed DN ordering

policy		= policy_anything

[ policy_match ]
countryName		= match
stateOrProvinceName	= match
organizationName	= match
organizationalUnitName	= optional
commonName		= supplied
emailAddress		= optional

[ policy_anything ]
countryName		= optional
stateOrProvinceName	= optional
localityName		= optional
organizationName	= optional
organizationalUnitName	= optional
commonName		= supplied
emailAddress		= optional

[ req ]
default_bits		= 2048
default_md		= sha256
default_keyfile 	= privkey.pem
x509_extensions	= v3_ca	# The extentions to add to the self signed cert
prompt = no
distinguished_name = dn
req_extensions = ext
string_mask = utf8only

req_extensions = v3_req # The extensions to add to a certificate request

[ req_distinguished_name ]
countryName			= Country Name (2 letter code)
countryName_default		= XX
countryName_min			= 2
countryName_max			= 2

stateOrProvinceName		= State or Province Name (full name)
#stateOrProvinceName_default	= Default Province

localityName			= Locality Name (eg, city)
localityName_default	= Default City

0.organizationName		= Organization Name (eg, company)
0.organizationName_default	= Default Company Ltd

# we can do this but it is not needed normally :-)
#1.organizationName		= Second Organization Name (eg, company)
#1.organizationName_default	= World Wide Web Pty Ltd

organizationalUnitName		= Organizational Unit Name (eg, section)
#organizationalUnitName_default	=

commonName                      = Common Name (eg, your name or your server\'s hostname)
commonName_max			= 64

emailAddress			= Email Address
emailAddress_max		= 64

# SET-ex3			= SET extension number 3

[ req_attributes ]
challengePassword		= A challenge password
challengePassword_min		= 4
challengePassword_max		= 20

unstructuredName		= An optional company name

[ usr_cert ]

# These extensions are added when 'ca' signs a request.

# This goes against PKIX guidelines but some CAs do it and some software
# requires this to avoid interpreting an end user certificate as a CA.

basicConstraints=CA:FALSE

# Here are some examples of the usage of nsCertType. If it is omitted
# the certificate can be used for anything *except* object signing.

# This is OK for an SSL server.
# nsCertType			= server

# For an object signing certificate this would be used.
# nsCertType = objsign

# For normal client use this is typical
# nsCertType = client, email

# and for everything including object signing:
# nsCertType = client, email, objsign

# This is typical in keyUsage for a client certificate.
# keyUsage = nonRepudiation, digitalSignature, keyEncipherment

# This will be displayed in Netscape's comment listbox.
nsComment			= "Excelfore device cert"

# PKIX recommendations harmless if included in all certificates.
subjectKeyIdentifier=hash
authorityKeyIdentifier=keyid,issuer

# This stuff is for subjectAltName and issuerAltname.
# Import the email address.
# subjectAltName=email:copy
# An alternative to produce certificates that aren't
# deprecated according to PKIX.
# subjectAltName=email:move

# Copy subject details
# issuerAltName=issuer:copy

#nsCaRevocationUrl		= http://www.domain.dom/ca-crl.pem
#nsBaseUrl
#nsRevocationUrl
#nsRenewalUrl
#nsCaPolicyUrl
#nsSslServerName

# This is required for TSA certificates.
# extendedKeyUsage = critical,timeStamping

$vid
$userid
$tenancy
$boota
1.3.6.1.4.1.45473.1.1=ASN1:SET:device_auth
$role_name
$user_display_name
$tenancies

$AIA
# authorityInfoAccess = OCSP;URI:http://localhost:8190

$SAN
[ alt_server_names ]
DNS.1 = $domain_name

[ device_auth ]
$can_updates
$can_sign

[ v3_req ]

# Extensions to add to a certificate request

basicConstraints = CA:FALSE
keyUsage = nonRepudiation, digitalSignature, keyEncipherment

$vid
$userid
$tenancy
$boota
1.3.6.1.4.1.45473.1.1=ASN1:SET:device_auth
$role_name
$user_display_name
$tenancies

$AIA
# authorityInfoAccess = OCSP;URI:http://localhost:8190

$SAN

[ sota_tenancies ]
$(echo $tenancy_list | tr '|' '\n')

[ v3_ca ]


# Extensions for a typical CA


# PKIX recommendation.

subjectKeyIdentifier=hash

authorityKeyIdentifier=keyid:always,issuer

# This is what PKIX recommends but some broken software chokes on critical
# extensions.
#basicConstraints = critical,CA:true
# So we do this instead.
basicConstraints = CA:true

# Key usage: this is typical for a CA certificate. However since it will
# prevent it being used as an test self-signed certificate it is best
# left out by default.
# keyUsage = cRLSign, keyCertSign

# Some might want this also
# nsCertType = sslCA, emailCA

# Include email address in subject alt name: another PKIX recommendation
# subjectAltName=email:copy
# Copy issuer details
# issuerAltName=issuer:copy

# DER hex encoding of an extension: beware experts only!
# obj=DER:02:03
# Where 'obj' is a standard or added object
# You can even override a supported extension:
# basicConstraints= critical, DER:30:03:01:01:FF

[ crl_ext ]

# CRL extensions.
# Only issuerAltName and authorityKeyIdentifier make any sense in a CRL.

# issuerAltName=issuer:copy
authorityKeyIdentifier=keyid:always

[ proxy_cert_ext ]
# These extensions should be added when creating a proxy certificate

# This goes against PKIX guidelines but some CAs do it and some software
# requires this to avoid interpreting an end user certificate as a CA.

basicConstraints=CA:FALSE

# Here are some examples of the usage of nsCertType. If it is omitted
# the certificate can be used for anything *except* object signing.

# This is OK for an SSL server.
# nsCertType			= server

# For an object signing certificate this would be used.
# nsCertType = objsign

# For normal client use this is typical
# nsCertType = client, email

# and for everything including object signing:
# nsCertType = client, email, objsign

# This is typical in keyUsage for a client certificate.
# keyUsage = nonRepudiation, digitalSignature, keyEncipherment

# This will be displayed in Netscape's comment listbox.
nsComment			= "OpenSSL Generated Certificate"

# PKIX recommendations harmless if included in all certificates.
subjectKeyIdentifier=hash
authorityKeyIdentifier=keyid,issuer

# This stuff is for subjectAltName and issuerAltname.
# Import the email address.
# subjectAltName=email:copy
# An alternative to produce certificates that aren't
# deprecated according to PKIX.
# subjectAltName=email:move

# Copy subject details
# issuerAltName=issuer:copy

#nsCaRevocationUrl		= http://www.domain.dom/ca-crl.pem
#nsBaseUrl
#nsRevocationUrl
#nsRenewalUrl
#nsCaPolicyUrl
#nsSslServerName

[dn]
CN = $cn
OU = $group
O = Excelfore
L = Saratoga
ST = CA
C = US

[ext]

_EOF_

pushd "$cdir" || exit 1

# generate a private key for the device.
# we can't really encrypt it because it's to be read
# by code.
if $is_request; then

    cp request.csr cert.req

else

    echo "--- Generating private key"
    openssl genpkey -out private.pem -algorithm RSA -pkeyopt rsa_keygen_bits:2048


    # create certificate signing request
    echo "--- Generating cert request"
    openssl req -new -utf8 -nameopt multiline,utf8 -config ca.conf -key private.pem -out cert.req

fi

start=$(date -d '2 days ago' +'%y%m%d000000Z')

# sign the request
echo "--- Signing the request. Press Ctrl-C at password prompt to leave at CSR stage"

popd

! test -f "$ca_dir"/ca.pem || ! test -f "$ca_dir"/ca_private.pem && {
    echo "No CA certificate/key found in CA directory $ca_dir"
    echo "Make sure CA is created first, or use USE_CA_DIR environment"
    echo "variable to specify its location"
    exit 1
}

# if we are dealing with a request, we may need to re-write the subject.
req_subj="$(openssl req -in "$cdir"/cert.req -noout -subject)"
# subject from req is not compatible with what ca expects
# this script is not particularly well done, and is prone to special characters issues
req_subj="$(echo $req_subj | sed -e 's#^subject=#/#' -e 's/ = /=/g' -e 's#, #/#g' -e "s#//\\+#/#g")"

req_subj="$(validate_rdn "$req_subj" "CN" "$cn")"
req_subj="$(validate_rdn "$req_subj" "OU" "$group")"
echo "DN to be used: $req_subj"

read -s -r -p "Enter the CA private key password:" ppwd
batch=
tty >/dev/null || batch="-batch"
openssl ca $batch -config "$cdir"/ca.conf -startdate $start -days 365 -key "$ppwd" -out "$cdir"/cert.pem -in "$cdir"/cert.req -subj "$req_subj"

rm "$cdir"/cert.req

