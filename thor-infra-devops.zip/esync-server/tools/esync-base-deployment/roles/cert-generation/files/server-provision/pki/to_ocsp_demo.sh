#!/bin/bash

ddir=ocsp_demo_dir/ca
mkdir -p $ddir

cp ca/ca.pem $ddir

CA_DN=$(openssl x509 -in ca/ca.pem -noout -issuer|cut -c9-)

rm -f $ddir/serials

for i in $(find . -name cert.pem); do

    DN=$(openssl x509 -in $i -noout -subject|cut -c10-)
    if test "$DN" == "$CA_DN"; then continue; fi

    tg=$(basename $(dirname $i))
    echo ${tg}.pem >> $ddir/serials
    cp -v $i $ddir/${tg}.pem

done

if test ! -f $ddir/ocsp.pem; then

    echo "YOU DON't HAVE OCSP CERTIFICATE"
    echo "I need to create one"
    echo "I will need CA PK password to do that"

    # this code is straight from OCSP demo.
    # our CNF file name is ocsp.cnf, though

    cn=ocsp
    ext=xl4-ocsp

    openssl genrsa -out $ddir/ocsp_key.pem 2048
    openssl req -new -sha256 -key $ddir/ocsp_key.pem -subj "/C=US/O=Excelfore/OU=PoC/CN=$cn" -out $ddir/ocsp_req.pem -config ocsp.cnf -extensions $ext
    read -s -r -p "Enter the CA private key password:" ppwd
    openssl x509 -sha256 -req -in $ddir/ocsp_req.pem -out $ddir/ocsp_cert.pem -CA ca/ca.pem -CAkey ca/ca_private.pem -extfile ocsp.cnf -extensions $ext -passin pass:$ppwd -CAserial ca/serial

fi
