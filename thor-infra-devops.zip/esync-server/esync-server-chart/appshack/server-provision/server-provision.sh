#!/bin/bash -e

###DESCRIPTION: This script is intended to perform esync server's post deployment activiites such as certifcicate creation and provision of other configuration files such as snapstore.config e.t.c
#TODO: Add function to update the snapstore.config file with the values created by the certs generation module here.
#INFO: This initial version of this script would generate the required server certs for an eSync server deployment.

usage()
{
cat <<USAGE
Usage Options :
server-provision.sh
         -c or --create-certs)     # Generate CA, server, java keystore, pkcs12 certs.
         -u or --user-certs)       # Generate user certs.
         --reset                   # Remove / Clean the created certs.
         --user-certs-reset        # Remove / Clean the created user certs.
E.g $ ./server-provision.sh -c /opt/appshack/soft/pki

USAGE
}

THIS_DIR="$( cd -P "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"
CONFIG_FILE=$THIS_DIR/config.cfg
PKI_SCRIPTS=$THIS_DIR/pki
E=$'\e[0;31m'
W=$'\e[0;33m'
S=$'\e[0;32m'
NC=$'\e[0m'

read_config ()
{ 
  if [[ ! -f $CONFIG_FILE ]] ; then
     echo "${E}[ERROR!] Couldn't read configuration file : '$CONFIG_FILE'! Exiting the script!!! ${NC}"
     echo "${W}[Info!]: Retry by renaming the template configuration file 'confg.cfg.tmpl' as 'config.cfg' and fill in with required values. ${NC}"
     exit 1
  fi
  #TODO: Add error handling if user config.cfg contains empty/ invalid input.
  #[[ -z "$NEW_CA_PWD" ]] || && { echo -e "${RED}[Error !]: Options '-E|-F|-G' expects 'new-snapshot-version' as input argument! \n${YELLOW}[Info!]: E.g, $0 -E '4.1903.3' ${NC}"; exit 1; }
  source $CONFIG_FILE
  echo "${W}[info!]: Using configuration file $CONFIG_FILE${NC}"
}
read_config;

generate_ca ()
{
  echo "${W}[Info!]: Generating CA certificates...${NC}"
  if [[ ! -f $PKI_SCRIPTS/make_ca.sh ]]; then
     echo "${E}[Error:] Unable to find make_ca.sh file in '$PKI_SCRIPTS' directory! ${NC}"
     exit 1
  fi
  if [[ -d $PKI_SCRIPTS/ca ]]; then
     echo "${W}[Info!]: CA certificate already exists, Using the existing CA private key. Remove pki/ca to create new one. ! ${NC}"
  else
     echo "Generating new CA private key"
     echo -e "$NEW_CA_PWD\n$NEW_CA_PWD" | $PKI_SCRIPTS/make_ca.sh
     echo "${S}[Success!]: Created CA certiifcate successfully ${NC}"
fi
}

ca_present ()
{
if [[ $PATH_TO_NEW_CA == '' ]] ; then
   echo "${W}[Info!]: Pre-generated ca not present...generating new ca${NC}"
   generate_ca;
else
   echo "${W}[Info!]: Using existing ca.......${NC}"
   mkdir -p $PKI_SCRIPTS/ca
   cp -r $PATH_TO_NEW_CA/* $PKI_SCRIPTS/ca/
   if [ ! -f "$PKI_SCRIPTS/ca/index.txt" ]; then
	touch $PKI_SCRIPTS/ca/index.txt
   fi
   if [ -d "$PKI_SCRIPTS/ca/issued_certs" ]; then
   	cp -r $PKI_SCRIPTS/ca/issued_certs $PKI_SCRIPTS
   else
	mkdir -p $PKI_SCRIPTS/issued_certs
   fi
fi

if [[ $PATH_TO_OLD_CA == '' ]] ; then
   echo "${W}[Info!]: Set PATH_TO_OLD_CA to copy old ca.....${NC}"
else
   echo "${W}[Info!]: Copying the existing old ca.......${NC}"
   mkdir -p $PKI_SCRIPTS/ca_old
   cp -r $PATH_TO_OLD_CA/* $PKI_SCRIPTS/ca_old/
   if [ ! -f "$PKI_SCRIPTS/ca_old/index.txt" ]; then
	touch $PKI_SCRIPTS/ca_old/index.txt
   fi
   if [ ! -d "$PKI_SCRIPTS/ca_old/issued_certs" ]; then
   	mkdir -p $PKI_SCRIPTS/ca_old/issued_certs
   fi
fi
}

generate_user_certs ()
{
  echo "${W}[Info!]: Generating user certificates...${NC}"
  if [[ ! -f $PKI_SCRIPTS/ca/ca.pem ]]; then
     echo "${E}[Error:] Unable to find the CA key in '$PKI_SCRIPTS/ca/' directory ! Please generate the CA key first! ${NC}"
     exit 1
  fi

  IFS=","
  for var in $USER_CN; do
  echo "USER_CN=$var"
  if [[ -d $PKI_SCRIPTS/$var ]]; then
     echo "${W}[Info!]: User certificate for USER '${var}' already exists, skipping! ${NC}"
  else  
     if [[ -d $PKI_SCRIPTS/ca_old ]]; then
      echo -e "U\n$var\n$var\n$SSO_ID\n$TENANCY\n\n$var\n$USER_ROLE\n$USER_INTERMEDIATE_WORKFLOW_CERTIFICATE\n$OLD_CA_PWD\ny\ny" | $PKI_SCRIPTS/make_client.sh
     else
      echo -e "U\n$var\n$var\n$SSO_ID\n$TENANCY\n\n$var\n$USER_ROLE\n$USER_INTERMEDIATE_WORKFLOW_CERTIFICATE\n$NEW_CA_PWD\ny\ny" | $PKI_SCRIPTS/make_client.sh
     fi
     echo "${S}[Success!]: Created USER certificate's for USER '${var}' successfully, Available @ $PKI_SCRIPTS/${var} ${NC}"  
  fi
  done
  unset IFS
}

generate_server_certs ()
{
  echo "${W}[Info!]: Generating server certificates...${NC}"
  if [[ ! -f $PKI_SCRIPTS/ca/ca.pem ]]; then
     echo "${E}[Error:] Unable to find the CA key in '$PKI_SCRIPTS/ca/' directory ! Please generate the CA key first! ${NC}"
     exit 1
  fi
  IFS=","
  for var in $SERVER_DNS_NAME; do
  echo "SERVER_DNS_NAME=$var"
  if [[ -d $PKI_SCRIPTS/$var ]]; then
     echo "${W}[Info!]: Server certificate for SERVER '${SERVER_DNS_NAME}' already exists, skipping! ${NC}"
  else
     echo -e "S\n${var}\n${var}\n${SERVER_INTERMEDIATE_WORKFLOW_CERTIFICATE}\n$NEW_CA_PWD\ny\ny" | $PKI_SCRIPTS/make_client.sh
  fi
  make_java_stores;
     done
  unset IFS
     echo "${S}[Success!]: Created SERVER certificate's successfully, Available @ $PKI_SCRIPTS ${NC}"
}

make_java_stores ()
{
  echo "${W}[Info!]: Generating Java key store certificates...${NC}"
  cd $PKI_SCRIPTS
      if [[ -f $PKI_SCRIPTS/${var}/cert.pem ]]; then
         echo -e "${var}\n" | $PKI_SCRIPTS/make_java_stores.sh
         echo "${S}[Success!]: Created Java keystore.jks for '${var}' successfully, Available @ $PKI_SCRIPTS/${var} ${NC}"
      else
         echo "${E}[ERROR!]: Couldn't find server certificates for '${var}'! Make sure the server certificates are created first!! ${NC}"
      fi
}


package_server_certs ()
{
  echo "${W}[Info!]: Packaging all the generated certs...${NC}"
  rm -rf $PKI_SCRIPTS/package_cert
  export CERTS_PKG_LOC=$PKI_SCRIPTS/package_cert
  if [[ ! -z $1 ]]; then
     export CERTS_PKG_LOC=$1
  fi
  mkdir -p $CERTS_PKG_LOC/ca

  cp -rf $PKI_SCRIPTS/ca/* $CERTS_PKG_LOC/ca/
  cp -rf $PKI_SCRIPTS/${var}/*.pem $CERTS_PKG_LOC
  cp -rf $PKI_SCRIPTS/${var}/*.jks $CERTS_PKG_LOC
  cp -rf $PKI_SCRIPTS/*.jks $CERTS_PKG_LOC
  if [[ -f ca_old/ca.pem && -f ca/ca_inter.pem ]]; then
      mkdir -p $CERTS_PKG_LOC/ca_old
      cp -rf $PKI_SCRIPTS/ca_old/* $CERTS_PKG_LOC/ca_old/
      cp -rf $PKI_SCRIPTS/*.pem $CERTS_PKG_LOC
  fi
  echo "${S}[Success!]: Packaged all the generated certs @ $CERTS_PKG_LOC${NC}"
}

reset ()
{
 if [[ -d $PKI_SCRIPTS/ca ]]; then
    rm -rf $PKI_SCRIPTS/ca
    rm -rf $PKI_SCRIPTS/issued_certs
    rm -rf $PKI_SCRIPTS/*.bks
    rm -rf $PKI_SCRIPTS/*.jks
    rm -rf $PKI_SCRIPTS/*.com
    rm -rf $PKI_SCRIPTS/*.pem
    rm -rf $PKI_SCRIPTS/package_cert
    rm -rf $PKI_SCRIPTS/ca.conf
    rm -rf $PKI_SCRIPTS/ca_old
    
    IFS=","
    for var in $USER_CN; do
    rm -rf $PKI_SCRIPTS/$var
    done
    unset IFS
    echo "${S}[Success!]: Reset certificates successfully! You could now retry creating new set of certificates with $0 '-c' option ${NC}"
 fi
}

reset_user_certs ()
{
if [[ -d $PKI_SCRIPTS/ca ]]; then
    IFS=","
    for var in $USER_CN; do
    rm -rf $PKI_SCRIPTS/$var
    done
    unset IFS
    echo "${S}[Success!]: Reset certificates successfully! You could now retry creating new set of certificates with $0 '-c' option ${NC}"
 fi
}

############## MAIN ##################

if [[ $# -eq 0 ]]; then
    echo "${E}[Error !]: Input 'option' required to proceed(e.g., $0 -c )! ${NC}"; usage; exit 1
fi

export USER_INPUT=$1

case "$USER_INPUT" in
-c|--create-certs)
          ca_present;
          generate_server_certs;
          package_server_certs
;;

-u|--user-certs)
          ca_present;
          generate_user_certs;
          
;;

--user-certs-reset)
          reset_user_certs;
;;

--reset)
          reset;
;;

*)  echo "${RED}[Error !]: Invalid option: '$1' ${NOCOL}"
          usage;
          exit 1
esac


