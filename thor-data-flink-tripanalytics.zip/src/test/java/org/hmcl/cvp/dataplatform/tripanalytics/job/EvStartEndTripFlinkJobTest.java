package org.hmcl.cvp.dataplatform.tripanalytics.job;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.salesforce.kafka.test.KafkaTestCluster;
import com.salesforce.kafka.test.KafkaTestUtils;
import lombok.extern.slf4j.Slf4j;
import org.apache.flink.runtime.testutils.MiniClusterResourceConfiguration;
import org.apache.flink.test.util.MiniClusterWithClientResource;
import org.apache.http.HttpEntity;
import org.apache.http.HttpHost;
import org.apache.http.util.EntityUtils;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.apache.kafka.clients.producer.KafkaProducer;
import org.apache.kafka.clients.producer.Producer;
import org.apache.kafka.clients.producer.ProducerConfig;
import org.apache.kafka.clients.producer.ProducerRecord;
import org.apache.kafka.common.serialization.StringDeserializer;
import org.hmcl.cvp.dataplatform.commons.testdata.CampaignDataGenerator;
import org.hmcl.cvp.dataplatform.commons.testdata.UserPreferenceGenerator;
import org.hmcl.cvp.dataplatform.contract.telemetry.Telemetry;
import org.hmcl.cvp.dataplatform.contract.telemetry.Tenant;
import org.hmcl.cvp.dataplatform.contract.userpreference.UserPreference;
import org.hmcl.cvp.dataplatform.tripanalytics.utils.TripData;
import org.junit.*;
import org.opensearch.client.Request;
import org.opensearch.client.Response;
import org.opensearch.client.RestClient;
import org.opensearch.testcontainers.OpensearchContainer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testcontainers.shaded.org.awaitility.Awaitility;
import org.testcontainers.utility.DockerImageName;

import java.io.IOException;
import java.time.Duration;
import java.time.Instant;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

@Slf4j
public class EvStartEndTripFlinkJobTest {
    private static final Logger LOGGER = LoggerFactory.getLogger(EvStartEndTripFlinkJobTest.class);
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static final DockerImageName OPEN_SEARCH_IMAGE = DockerImageName.parse("opensearchproject/opensearch:2.13.0");

    private static final OpensearchContainer<?> CONTAINER = new OpensearchContainer<>(OPEN_SEARCH_IMAGE);

    private static final String TELEMETRY_INPUT_TOPIC = "telemetry";
    private static final String USER_PREF_INPUT_TOPIC = "user.preference";
    private static final String GIF_OUTPUT_TOPIC = "gif.generator";

    private static KafkaTestUtils utils;
    private static KafkaTestCluster cluster;

    @ClassRule
    public static MiniClusterWithClientResource flinkCluster =
            new MiniClusterWithClientResource(
                    new MiniClusterResourceConfiguration.Builder()
                            .setNumberSlotsPerTaskManager(2)
                            .setNumberTaskManagers(1)
                            .build());

    @BeforeClass
    public static void startKafkaCluster() throws Throwable {
        // Setup InMemory  Kafka Cluster
        cluster = new KafkaTestCluster(1);
        cluster.start();
        utils = new KafkaTestUtils(cluster);

        utils.createTopic(TELEMETRY_INPUT_TOPIC, 1, (short) 1);
        utils.createTopic(USER_PREF_INPUT_TOPIC, 1, (short) 1);
        utils.createTopic(GIF_OUTPUT_TOPIC, 1, (short) 1);
    }

    @BeforeClass
    public static void startOpenSearch() {
        // https://stackoverflow.com/questions/61108655/test-container-test-cases-are-failing-due-to-could-not-find-a-valid-docker-envi
        CONTAINER.start();
    }

    @AfterClass
    public static void stopKafkaCluster() throws Exception {
        cluster.close();
    }

    @AfterClass
    public static void closeOpenSearch() {
        LOGGER.info("Closing OpenSearch container");
        CONTAINER.stop();
    }

    private static void produceData(List<String> telemetryList) {
        Producer<String, String> producer = getProducer();
        LOGGER.info("Producing events");
        telemetryList.forEach(v -> {
            ProducerRecord<String, String> data = new ProducerRecord<>(TELEMETRY_INPUT_TOPIC, v);
            producer.send(data);
        });

        producer.flush();
        producer.close();
    }

    private void sendUserPreferenceData(UserPreference userPreference) {
        Producer<String, String> producer = getProducer();

        String message = GSON.toJson(userPreference);
        ProducerRecord<String, String> producerRecord = new ProducerRecord<>(USER_PREF_INPUT_TOPIC, message);
        producer.send(producerRecord);

        producer.flush();
        producer.close();
    }

    private static Producer<String, String> getProducer() {
        Properties props = new Properties();

        props.put(ProducerConfig.BOOTSTRAP_SERVERS_CONFIG, cluster.getKafkaConnectString());
        props.put("security.protocol", "PLAINTEXT");
        props.put(ProducerConfig.ACKS_CONFIG, "all");
        props.put(ProducerConfig.RETRIES_CONFIG, 2);
        props.put(ProducerConfig.LINGER_MS_CONFIG, 2);
        props.put(ProducerConfig.KEY_SERIALIZER_CLASS_CONFIG,"org.apache.kafka.common.serialization.StringSerializer");
        props.put(ProducerConfig.VALUE_SERIALIZER_CLASS_CONFIG,"org.apache.kafka.common.serialization.StringSerializer");

        return new KafkaProducer<>(props);
    }

    private static String[] getSystemArgs() {
        return new String[]{
                "--is.run.test.case", "TRUE",
                "--max.out.of.order.in.sec", "300",
                "--idle.timeout.in.sec", "1",
                "--aws.region", "ap-south-1",
                "--trip.ttl.in.hours", "15",
                "--trip.start.odometer.diff", "0.1",
                "--trip.break.diff.in.min", "3",
                "--end.trip.wait.timer.in.min", "3",
                "--window.duration", "90",
                "--default.to.current.rider.details", "FALSE",

                // KAFKA Telemetry PROPERTY
                "--kafka.campaign.bootstrap.brokers", cluster.getKafkaConnectString(),
                "--kafka.telemetry.campaign.input.topic", TELEMETRY_INPUT_TOPIC,
                "--kafka.campaign.group.id", "TripAnalyticsGroup",
                "--kafka.campaign.role.arn", "XXXXX",
                "--kafka.campaign.session.name", "TripAnalyticsSession",

                // KAFKA User preference PROPERTY
                "--kafka.userpref.bootstrap.brokers", cluster.getKafkaConnectString(),
                "--kafka.userpref.input.topic", USER_PREF_INPUT_TOPIC,
                "--kafka.userpref.group.id", "TripAnalyticsUserPrefGroup",
                "--kafka.userpref.role.arn", "XXXXX",
                "--kafka.userpref.session.name", "TripAnalyticsUserPrefSession",

                "--kafka.gif.generator.bootstrap.brokers", cluster.getKafkaConnectString(),
                "--kafka.gif.generator.group.id", "TripAnalyticsGifGroup",
                "--kafka.gif.generator.role.arn", "XXXXX",
                "--kafka.gif.generator.session.name", "TripAnalyticsGifSession",
                "--kafka.gif.generator.topic", GIF_OUTPUT_TOPIC,

                // OpenSearch PROPERTY - ONLY USED FOR TEST CASES
                "--opensearch.hostAddress", CONTAINER.getHttpHostAddress(),
                "--opensearch.username", CONTAINER.getUsername(),
                "--opensearch.password", CONTAINER.getPassword(),
                "--opensearch.max.retries", "3",
                "--opensearch.retry.delay.in.ms", "1000",
                "--opensearch.max.actions.to.buffer", "1",
                "--opensearch.bulk.flush.size.mb", "-1",
                "--opensearch.bulk.flush.interval.milli", "-1"
        };
    }

    private int getNumberOfRecordsInOpenSearch(String index) {

        String endpoint = String.format("/%s/_search", index);
        LOGGER.info("OpenSearch endpoint: {}", endpoint);

        RestClient client = RestClient
                .builder(HttpHost.create(CONTAINER.getHttpHostAddress()))
                .build();

        try (client) {
            Request request = new Request("GET", endpoint);
            Response response =  client.performRequest(request);
            HttpEntity entity = response.getEntity();

            String responseString = EntityUtils.toString(entity);
            LOGGER.info("Repeatable: {}, Content Type: {}, Content: {}", entity.isRepeatable(), entity.getContentType(), responseString);

            JsonElement je = GSON.fromJson(responseString, JsonElement.class);
            JsonObject jo = je.getAsJsonObject();

            JsonObject totalHits = jo.getAsJsonObject("hits").getAsJsonObject("total");
            int numHits = totalHits.get("value").getAsInt();
            LOGGER.info("Number of records: {}", numHits);
            return numHits;

        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    private int getTripGeneratorEvents() {
        List<ConsumerRecord<String, String>> consumerRecords = utils.consumeAllRecordsFromTopic(
                GIF_OUTPUT_TOPIC,
                StringDeserializer.class,
                StringDeserializer.class
        );

        for (ConsumerRecord<String, String> consumerRecord : consumerRecords) {
            log.info("{}", consumerRecord);
        }
        int count = consumerRecords.size();
        log.info("Number of records in {}: {}", GIF_OUTPUT_TOPIC, count);

        return count;
    }

    @Test
    public void testOpenSearchSink() {

        Tenant tenant = Tenant.EV;
        int countOfEachSignal = 1;

        String virtualId = TripData.getVirtualId(tenant);
        String tripId = TripData.getTripId();

        UserPreference primaryUser = UserPreferenceGenerator.getPrimaryUser(virtualId);
        sendUserPreferenceData(primaryUser);

        Awaitility.await()
                .timeout(Duration.ofSeconds(10))
                .pollDelay(Duration.ofSeconds(5))
                .untilAsserted(() -> Assert.assertTrue(true));

        List<Telemetry> tripEvents = new ArrayList<>();

        Instant initialWatermark = Instant.now().minusSeconds(16 * 60);
        Telemetry t1 = CampaignDataGenerator.getTelemetry(virtualId, tenant, initialWatermark, countOfEachSignal);
        TripData.addUserDetailsToTelemetry(t1, primaryUser, initialWatermark);
        tripEvents.add(t1);

        // Trip started ten minutes back
        Instant tripStartTime = Instant.now().minusSeconds(15 * 60);
        Telemetry tripStartFlag = TripData.getTripStartFlag(virtualId, tenant, tripId, tripStartTime, countOfEachSignal, 1);
        TripData.addUserDetailsToTelemetry(tripStartFlag, primaryUser, tripStartTime);
        tripEvents.add(tripStartFlag);

        // Trip ended after 5 minutes of trip start
        Instant tripEndTime = tripStartTime.plusSeconds(5 * 60);
        Telemetry tripEndFlag = TripData.getTripEndFlag(virtualId, tenant, tripId, tripEndTime, countOfEachSignal, 1);
        TripData.addUserDetailsToTelemetry(tripEndFlag, primaryUser, tripEndTime);
        tripEvents.add(tripEndFlag);

        // Send a new trip started 4 minutes after previous trip ended
        Instant newTripTime = tripEndTime.plusSeconds(4 * 60);
        String newTripId = TripData.getNextTripId(tripId);
        Telemetry tripEvent = TripData.getTripStartFlag(virtualId, tenant, newTripId, newTripTime, countOfEachSignal, 1);
        TripData.addUserDetailsToTelemetry(tripEvent, primaryUser, newTripTime);
        tripEvents.add(tripEvent);

        List<String> data = TripData.getJsonData(tripEvents);
        produceData(data);

        try {

            Thread startFlinkJob = new Thread(() -> {
                try {
                    TripAnalyticsFlink.main(getSystemArgs());
                } catch (Exception e) {
                    throw new RuntimeException(e);
                }
            });
            startFlinkJob.start();
            // Interrupt the thread after 60 seconds
            startFlinkJob.join(Duration.ofSeconds(60).toMillis());

            int numOfStartTrips = getNumberOfRecordsInOpenSearch(OpenSearchIndices.EV_TRIP_START_INDEX);
            Assert.assertEquals(2, numOfStartTrips);

            int numOfEndTrips = getNumberOfRecordsInOpenSearch(OpenSearchIndices.EV_TRIP_END_INDEX);
            Assert.assertEquals(1, numOfEndTrips);

            int numOfTripGifs = getTripGeneratorEvents();
            Assert.assertEquals(1, numOfTripGifs);

        } catch (Exception e) {
            LOGGER.error("Exception occurred while launching Flink opensearch consumer");
            throw new RuntimeException(e);
        }
    }
}
