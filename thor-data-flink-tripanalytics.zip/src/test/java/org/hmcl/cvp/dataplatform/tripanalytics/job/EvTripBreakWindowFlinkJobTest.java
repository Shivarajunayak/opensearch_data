package org.hmcl.cvp.dataplatform.tripanalytics.job;

import com.google.gson.Gson;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.salesforce.kafka.test.KafkaTestCluster;
import com.salesforce.kafka.test.KafkaTestUtils;
import lombok.extern.slf4j.Slf4j;
import org.apache.flink.api.java.tuple.Tuple4;
import org.apache.flink.runtime.testutils.MiniClusterResourceConfiguration;
import org.apache.flink.test.util.MiniClusterWithClientResource;
import org.apache.http.HttpEntity;
import org.apache.http.HttpHost;
import org.apache.http.util.EntityUtils;
import org.apache.kafka.clients.producer.KafkaProducer;
import org.apache.kafka.clients.producer.Producer;
import org.apache.kafka.clients.producer.ProducerConfig;
import org.apache.kafka.clients.producer.ProducerRecord;
import org.hmcl.cvp.dataplatform.commons.testdata.CampaignDataGenerator;
import org.hmcl.cvp.dataplatform.commons.testdata.UserPreferenceGenerator;
import org.hmcl.cvp.dataplatform.commons.utils.GsonUtils;
import org.hmcl.cvp.dataplatform.contract.telemetry.Telemetry;
import org.hmcl.cvp.dataplatform.contract.telemetry.Tenant;
import org.hmcl.cvp.dataplatform.contract.userpreference.UserPreference;
import org.hmcl.cvp.dataplatform.tripanalytics.utils.TripData;
import org.junit.*;
import org.opensearch.client.Request;
import org.opensearch.client.Response;
import org.opensearch.client.RestClient;
import org.opensearch.testcontainers.OpensearchContainer;
import org.testcontainers.shaded.org.awaitility.Awaitility;
import org.testcontainers.utility.DockerImageName;

import java.io.IOException;
import java.time.Duration;
import java.time.Instant;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

@Slf4j
public class EvTripBreakWindowFlinkJobTest {

    private static final Gson GSON = GsonUtils.getGson();
    private static final DockerImageName OPEN_SEARCH_IMAGE = DockerImageName.parse("opensearchproject/opensearch:2.13.0");

    private static final OpensearchContainer<?> CONTAINER = new OpensearchContainer<>(OPEN_SEARCH_IMAGE);

    private static final String TELEMETRY_INPUT_TOPIC = "telemetry";
    private static final String USER_PREF_INPUT_TOPIC = "user.preference";
    private static final String GIF_OUTPUT_TOPIC = "gif.generator";
    private static final Integer OUT_OF_ORDER = 300;

    @ClassRule
    public static MiniClusterWithClientResource flinkCluster =
            new MiniClusterWithClientResource(
                    new MiniClusterResourceConfiguration.Builder()
                            .setNumberSlotsPerTaskManager(2)
                            .setNumberTaskManagers(1)
                            .build());
    private static KafkaTestUtils utils;
    private static KafkaTestCluster cluster;

    @BeforeClass
    public static void startKafkaCluster() throws Throwable {
        // Setup InMemory  Kafka Cluster
        cluster = new KafkaTestCluster(1);
        cluster.start();
        utils = new KafkaTestUtils(cluster);

        utils.createTopic(TELEMETRY_INPUT_TOPIC, 1, (short) 1);
        utils.createTopic(USER_PREF_INPUT_TOPIC, 1, (short) 1);
        utils.createTopic(GIF_OUTPUT_TOPIC, 1, (short) 1);
    }

    @BeforeClass
    public static void startOpenSearch() {
        // https://stackoverflow.com/questions/61108655/test-container-test-cases-are-failing-due-to-could-not-find-a-valid-docker-envi
        CONTAINER.start();
    }

    @AfterClass
    public static void stopKafkaCluster() throws Exception {
        cluster.close();
    }

    @AfterClass
    public static void closeOpenSearch() {
        log.info("Closing OpenSearch container");
        CONTAINER.stop();
    }

    private static void produceData(List<String> telemetryList) {
        Producer<String, String> producer = getProducer();
        log.info("Producing events");
        telemetryList.forEach(v -> {
            ProducerRecord<String, String> data = new ProducerRecord<>(TELEMETRY_INPUT_TOPIC, v);
            producer.send(data);
        });

        producer.flush();
        producer.close();
    }

    private static Producer<String, String> getProducer() {
        Properties props = new Properties();

        props.put(ProducerConfig.BOOTSTRAP_SERVERS_CONFIG, cluster.getKafkaConnectString());
        props.put("security.protocol", "PLAINTEXT");
        props.put(ProducerConfig.ACKS_CONFIG, "all");
        props.put(ProducerConfig.RETRIES_CONFIG, 2);
        props.put(ProducerConfig.LINGER_MS_CONFIG, 2);
        props.put(ProducerConfig.KEY_SERIALIZER_CLASS_CONFIG, "org.apache.kafka.common.serialization.StringSerializer");
        props.put(ProducerConfig.VALUE_SERIALIZER_CLASS_CONFIG, "org.apache.kafka.common.serialization.StringSerializer");

        return new KafkaProducer<>(props);
    }

    private static String[] getSystemArgs() {
        return new String[]{
                "--is.run.test.case", "TRUE",
                "--max.out.of.order.in.sec", String.valueOf(OUT_OF_ORDER),
                "--idle.timeout.in.sec", "1",
                "--aws.region", "ap-south-1",
                "--trip.ttl.in.hours", "15",
                "--trip.start.odometer.diff", "0.1",
                "--trip.break.diff.in.min", "3",
                "--end.trip.wait.timer.in.min", "3",
                "--window.duration", "90",

                // KAFKA Telemetry PROPERTY
                "--kafka.campaign.bootstrap.brokers", cluster.getKafkaConnectString(),
                "--kafka.telemetry.campaign.input.topic", TELEMETRY_INPUT_TOPIC,
                "--kafka.campaign.group.id", "TripAnalyticsGroup",
                "--kafka.campaign.role.arn", "XXXXX",
                "--kafka.campaign.session.name", "TripAnalyticsSession",

                // KAFKA User preference PROPERTY
                "--kafka.userpref.bootstrap.brokers", cluster.getKafkaConnectString(),
                "--kafka.userpref.input.topic", USER_PREF_INPUT_TOPIC,
                "--kafka.userpref.group.id", "TripAnalyticsUserPrefGroup",
                "--kafka.userpref.role.arn", "XXXXX",
                "--kafka.userpref.session.name", "TripAnalyticsUserPrefSession",

                "--kafka.gif.generator.bootstrap.brokers", cluster.getKafkaConnectString(),
                "--kafka.gif.generator.group.id", "TripAnalyticsGifGroup",
                "--kafka.gif.generator.role.arn", "XXXXX",
                "--kafka.gif.generator.session.name", "TripAnalyticsGifSession",
                "--kafka.gif.generator.topic", GIF_OUTPUT_TOPIC,

                // OpenSearch PROPERTY - ONLY USED FOR TEST CASES
                "--opensearch.hostAddress", CONTAINER.getHttpHostAddress(),
                "--opensearch.username", CONTAINER.getUsername(),
                "--opensearch.password", CONTAINER.getPassword(),
                "--opensearch.max.retries", "3",
                "--opensearch.retry.delay.in.ms", "1000",
                "--opensearch.max.actions.to.buffer", "1",
                "--opensearch.bulk.flush.size.mb", "-1",
                "--opensearch.bulk.flush.interval.milli", "-1"
        };
    }

    private void sendUserPreferenceData(UserPreference userPreference) {
        Producer<String, String> producer = getProducer();

        String message = GSON.toJson(userPreference);
        ProducerRecord<String, String> producerRecord = new ProducerRecord<>(USER_PREF_INPUT_TOPIC, message);
        producer.send(producerRecord);

        producer.flush();
        producer.close();
    }

    private int getNumberOfRecordsInOpenSearch(String index) {

        String endpoint = String.format("/%s/_search", index);
        log.info("OpenSearch endpoint: {}", endpoint);

        RestClient client = RestClient
                .builder(HttpHost.create(CONTAINER.getHttpHostAddress()))
                .build();

        try (client) {
            Request request = new Request("GET", endpoint);
            Response response = client.performRequest(request);
            HttpEntity entity = response.getEntity();

            String responseString = EntityUtils.toString(entity);
            log.info("Repeatable: {}, Content Type: {}, Content: {}", entity.isRepeatable(), entity.getContentType(), responseString);

            JsonElement je = GSON.fromJson(responseString, JsonElement.class);
            JsonObject jo = je.getAsJsonObject();

            JsonObject totalHits = jo.getAsJsonObject("hits").getAsJsonObject("total");
            int numHits = totalHits.get("value").getAsInt();
            log.info("Number of records: {}", numHits);
            return numHits;

        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    @Test
    public void testOpenSearchSink() {

        Tenant tenant = Tenant.EV;
        int countOfEachSignal = 1;

        String virtualId = TripData.getVirtualId(tenant);
        String tripId = TripData.getTripId();

        UserPreference primaryUser = UserPreferenceGenerator.getPrimaryUser(virtualId);
        sendUserPreferenceData(primaryUser);

        Awaitility.await()
                .timeout(Duration.ofSeconds(7))
                .pollDelay(Duration.ofSeconds(5))
                .untilAsserted(() -> Assert.assertTrue(true));

        Instant instant = Instant.now().minusSeconds(10 * 60);
        Tuple4<Boolean, Integer, Double, Double> values = new Tuple4<>();
        values.f0 = true; // ignition
        values.f1 = 0; // vehicle speed
        values.f2 = 100.0; // odometer reading
        values.f3 = 1.0; // motor state

        List<Telemetry> tripEvents = new ArrayList<>();
        Telemetry tripStart = TripData.getTripStartFlag(virtualId, tenant, tripId, instant, countOfEachSignal, 1);
        tripStart.setEventId(1);
        TripData.addUserDetailsToTelemetry(tripStart, primaryUser, instant);
        tripEvents.add(tripStart);

        Instant firstInstant = instant.plusSeconds(30);
        Telemetry tripBreakEvent1 = TripData.getTripBreakEvent(tenant, tripStart, firstInstant, values);
        tripBreakEvent1.setEventId(2);
        TripData.addUserDetailsToTelemetry(tripBreakEvent1, primaryUser, firstInstant);
        tripEvents.add(tripBreakEvent1);

        Instant secondInstant = firstInstant.plusSeconds(30);
        Telemetry tripBreakEvent2 = TripData.getTripBreakEvent(tenant, tripStart, secondInstant, values);
        tripBreakEvent2.setEventId(3);
        TripData.addUserDetailsToTelemetry(tripBreakEvent2, primaryUser, secondInstant);
        tripEvents.add(tripBreakEvent2);

        Instant thirdInstant = secondInstant.plusSeconds(30);
        Telemetry tripBreakEvent3 = TripData.getTripBreakEvent(tenant, tripStart, thirdInstant, values);
        tripBreakEvent3.setEventId(4);
        TripData.addUserDetailsToTelemetry(tripBreakEvent3, primaryUser, thirdInstant);
        tripEvents.add(tripBreakEvent3);

        Instant fourthInstant = thirdInstant.plusSeconds(30);
        Telemetry tripBreakEvent4 = TripData.getTripBreakEvent(tenant, tripStart, fourthInstant, values);
        tripBreakEvent4.setEventId(5);
        TripData.addUserDetailsToTelemetry(tripBreakEvent4, primaryUser, fourthInstant);
        tripEvents.add(tripBreakEvent4);

        Telemetry windowForwardEvent = CampaignDataGenerator.getTelemetry(virtualId, tenant, Instant.now(), countOfEachSignal);
        windowForwardEvent.setEventId(6);
        windowForwardEvent.setCampaignName(TripData.IGNITION_RISE);
        TripData.addUserDetailsToTelemetry(windowForwardEvent, primaryUser, Instant.now());
        tripEvents.add(windowForwardEvent);

        List<String> data = TripData.getJsonData(tripEvents);
        produceData(data);

        try {

            Thread startFlinkJob = new Thread(() -> {
                try {
                    TripAnalyticsFlink.main(getSystemArgs());
                } catch (Exception e) {
                    throw new RuntimeException(e);
                }
            });
            startFlinkJob.start();
            // Interrupt the thread after 60 seconds
            startFlinkJob.join(Duration.ofSeconds(5 * 60).toMillis());

            int numOfStartTrips = getNumberOfRecordsInOpenSearch(OpenSearchIndices.EV_TRIP_START_INDEX);
            Assert.assertEquals(1, numOfStartTrips);

            int numOfBreakTrips = getNumberOfRecordsInOpenSearch(OpenSearchIndices.EV_TRIP_BREAK_INDEX);
            Assert.assertNotEquals(0, numOfBreakTrips);

        } catch (Exception e) {
            log.error("Exception occurred while launching Flink opensearch consumer");
            throw new RuntimeException(e);
        }
    }
}
