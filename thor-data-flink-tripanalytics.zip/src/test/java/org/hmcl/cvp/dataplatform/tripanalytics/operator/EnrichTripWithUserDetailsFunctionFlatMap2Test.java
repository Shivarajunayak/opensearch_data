package org.hmcl.cvp.dataplatform.tripanalytics.operator;

import org.apache.flink.api.common.state.MapState;
import org.apache.flink.api.common.typeinfo.BasicTypeInfo;
import org.apache.flink.api.java.functions.KeySelector;
import org.apache.flink.api.java.utils.ParameterTool;
import org.apache.flink.runtime.testutils.MiniClusterResourceConfiguration;
import org.apache.flink.streaming.api.operators.co.CoStreamFlatMap;
import org.apache.flink.streaming.runtime.streamrecord.StreamRecord;
import org.apache.flink.streaming.util.KeyedTwoInputStreamOperatorTestHarness;
import org.apache.flink.test.util.MiniClusterWithClientResource;
import org.hmcl.cvp.dataplatform.commons.constants.FlinkRuntime;
import org.hmcl.cvp.dataplatform.commons.testdata.UserPreferenceGenerator;
import org.hmcl.cvp.dataplatform.commons.utils.FlinkUtils;
import org.hmcl.cvp.dataplatform.commons.utils.UserPreferenceUtils;
import org.hmcl.cvp.dataplatform.contract.userpreference.UserPreference;
import org.hmcl.cvp.dataplatform.tripanalytics.contract.TripWrapper;
import org.hmcl.cvp.dataplatform.tripanalytics.utils.TripData;
import org.junit.Assert;
import org.junit.ClassRule;
import org.junit.Test;

import java.time.Instant;
import java.util.HashMap;
import java.util.Map;

public class EnrichTripWithUserDetailsFunctionFlatMap2Test {

    @ClassRule
    public static MiniClusterWithClientResource flinkCluster =
            new MiniClusterWithClientResource(
                    new MiniClusterResourceConfiguration.Builder()
                            .setNumberSlotsPerTaskManager(2)
                            .setNumberTaskManagers(1)
                            .build());

    private final KeySelector<UserPreference, String> userPreferenceStringKeySelector = UserPreference::getVid;

    private final KeySelector<TripWrapper, String> tripWrapperStringKeySelector = TripWrapper::getVirtualId;

    private final EnrichTripWithUserDetailsFunction enrichTripWithUserDetailsFunction = new EnrichTripWithUserDetailsFunction();

    private KeyedTwoInputStreamOperatorTestHarness<String, TripWrapper, UserPreference, TripWrapper> testHarness() throws Exception {
        ParameterTool parameterTool = ParameterTool.fromMap(new HashMap<>());
        parameterTool = FlinkUtils.addProperties(parameterTool, Map.of(FlinkRuntime.TripAnalytics.DEFAULT_TO_CURRENT_RIDER_DETAILS, "FALSE"));

        KeyedTwoInputStreamOperatorTestHarness<String, TripWrapper, UserPreference, TripWrapper> testHarness = new KeyedTwoInputStreamOperatorTestHarness<>(new CoStreamFlatMap<>(enrichTripWithUserDetailsFunction),
                tripWrapperStringKeySelector,
                userPreferenceStringKeySelector,
                BasicTypeInfo.STRING_TYPE_INFO);

        testHarness.getEnvironment().getExecutionConfig().setGlobalJobParameters(parameterTool);

        return testHarness;
    }

    private MapState<String, Map<String, UserPreference>> getPreferencesStateMap(KeyedTwoInputStreamOperatorTestHarness<String, TripWrapper, UserPreference, TripWrapper> testHarness) {
        return testHarness.getOperator()
                .getKeyedStateStore()
                .getMapState(StateDescriptors.userPreferenceMapStateDescriptor());
    }

    @Test
    public void testEnrichTripWithUserDetailsFunction_incomingPrimaryUser() {
        try(KeyedTwoInputStreamOperatorTestHarness<String, TripWrapper, UserPreference, TripWrapper> testHarness = testHarness()) {

            testHarness.setup();
            testHarness.open();

            UserPreference primaryRider = UserPreferenceGenerator.getPrimaryUser(TripData.VIRTUAL_ID);
            StreamRecord<UserPreference> streamRecord = new StreamRecord<>(primaryRider);

            testHarness.processElement2(streamRecord);

            MapState<String, Map<String, UserPreference>> preferencesStateMap = getPreferencesStateMap(testHarness);

            Map<String, UserPreference> preferences = preferencesStateMap.get(TripData.VIRTUAL_ID);

            Assert.assertNotNull(preferences);
            Assert.assertEquals(1, preferences.size());
            UserPreference stateValue = preferences.getOrDefault(primaryRider.getProfileId(), null);
            Assert.assertNotNull(stateValue);

        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }
    @Test
    public void testEnrichTripWithUserDetailsFunction_incomingDeletedPrimaryUser() {
        try(KeyedTwoInputStreamOperatorTestHarness<String, TripWrapper, UserPreference, TripWrapper> testHarness = testHarness()) {

            testHarness.setup();
            testHarness.open();

            UserPreference primaryRider = UserPreferenceGenerator.getPrimaryUser(TripData.VIRTUAL_ID);
            StreamRecord<UserPreference> streamRecord = new StreamRecord<>(primaryRider);

            testHarness.processElement2(streamRecord);

            MapState<String, Map<String, UserPreference>> preferencesStateMap = getPreferencesStateMap(testHarness);

            Map<String, UserPreference> preferences = preferencesStateMap.get(TripData.VIRTUAL_ID);

            Assert.assertNotNull(preferences);
            Assert.assertEquals(1, preferences.size());
            UserPreference stateValue = preferences.getOrDefault(primaryRider.getProfileId(), null);
            Assert.assertNotNull(stateValue);

            primaryRider.setProfileStatus("Deleted");
            testHarness.processElement2(streamRecord);

            preferencesStateMap = getPreferencesStateMap(testHarness);

            preferences = preferencesStateMap.get(TripData.VIRTUAL_ID);

            Assert.assertNotNull(preferences);
            Assert.assertEquals(0, preferences.size());
            stateValue = preferences.getOrDefault(primaryRider.getProfileId(), null);
            Assert.assertNull(stateValue);

        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    @Test
    public void testEnrichTripWithUserDetailsFunction_incomingLatestPrimaryUser() {
        try(KeyedTwoInputStreamOperatorTestHarness<String, TripWrapper, UserPreference, TripWrapper> testHarness = testHarness()) {

            testHarness.setup();
            testHarness.open();

            long oldTime = Instant.now().minusSeconds(60).toEpochMilli();
            long newTime = Instant.now().minusSeconds(30).toEpochMilli();

            UserPreference primaryUser1 = UserPreferenceGenerator.getPrimaryUser(TripData.VIRTUAL_ID);
            primaryUser1.setUpdatedTsp(oldTime);
            StreamRecord<UserPreference> streamRecord1 = new StreamRecord<>(primaryUser1);

            testHarness.processElement2(streamRecord1);

            UserPreference primaryUser2 = UserPreferenceUtils.deepCopy(primaryUser1);
            assert primaryUser2 != null;
            primaryUser2.setUpdatedTsp(newTime);
            StreamRecord<UserPreference> streamRecord2 = new StreamRecord<>(primaryUser2);

            testHarness.processElement2(streamRecord2);

            MapState<String, Map<String, UserPreference>> preferencesStateMap = getPreferencesStateMap(testHarness);

            Map<String, UserPreference> preferences = preferencesStateMap.get(TripData.VIRTUAL_ID);

            Assert.assertNotNull(preferences);
            Assert.assertEquals(1, preferences.size());
            UserPreference stateValue = preferences.getOrDefault(primaryUser1.getProfileId(), null);
            Assert.assertNotNull(stateValue);

            long updatedTsp = stateValue.getUpdatedTsp();
            Assert.assertEquals(newTime, updatedTsp);

        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    @Test
    public void testEnrichTripWithUserDetailsFunction_incomingOlderPrimaryUser() {
        try(KeyedTwoInputStreamOperatorTestHarness<String, TripWrapper, UserPreference, TripWrapper> testHarness = testHarness()) {

            testHarness.setup();
            testHarness.open();

            long oldTime = Instant.now().minusSeconds(60).toEpochMilli();
            long newTime = Instant.now().minusSeconds(30).toEpochMilli();

            UserPreference primaryUser1 = UserPreferenceGenerator.getPrimaryUser(TripData.VIRTUAL_ID);
            primaryUser1.setUpdatedTsp(newTime);
            StreamRecord<UserPreference> streamRecord1 = new StreamRecord<>(primaryUser1);

            testHarness.processElement2(streamRecord1);

            UserPreference primaryUser2 = UserPreferenceUtils.deepCopy(primaryUser1);
            assert primaryUser2 != null;
            primaryUser2.setUpdatedTsp(oldTime);
            StreamRecord<UserPreference> streamRecord2 = new StreamRecord<>(primaryUser2);

            testHarness.processElement2(streamRecord2);

            MapState<String, Map<String, UserPreference>> preferencesStateMap = getPreferencesStateMap(testHarness);

            Map<String, UserPreference> preferences = preferencesStateMap.get(TripData.VIRTUAL_ID);

            Assert.assertNotNull(preferences);
            Assert.assertEquals(1, preferences.size());
            UserPreference stateValue = preferences.getOrDefault(primaryUser1.getProfileId(), null);
            Assert.assertNotNull(stateValue);

            long updatedTsp = stateValue.getUpdatedTsp();
            Assert.assertEquals(newTime, updatedTsp);

        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    @Test
    public void testEnrichTripWithUserDetailsFunction_incomingSecondaryUser() {
        try(KeyedTwoInputStreamOperatorTestHarness<String, TripWrapper, UserPreference, TripWrapper> testHarness = testHarness()) {

            testHarness.setup();
            testHarness.open();

            UserPreference primaryRider = UserPreferenceGenerator.getPrimaryUser(TripData.VIRTUAL_ID);
            StreamRecord<UserPreference> primaryStreamRecord = new StreamRecord<>(primaryRider);

            testHarness.processElement2(primaryStreamRecord);

            UserPreference secondaryUser = UserPreferenceGenerator.getSecondaryUser(TripData.VIRTUAL_ID);
            StreamRecord<UserPreference> secondaryStreamRecord = new StreamRecord<>(secondaryUser);

            testHarness.processElement2(secondaryStreamRecord);

            MapState<String, Map<String, UserPreference>> preferencesStateMap = getPreferencesStateMap(testHarness);

            Map<String, UserPreference> preferences = preferencesStateMap.get(TripData.VIRTUAL_ID);

            Assert.assertNotNull(preferences);
            Assert.assertEquals(2, preferences.size());

            long primaryUserCount = preferences.values().stream().filter(UserPreferenceUtils::isPrimary).count();
            Assert.assertEquals(1, primaryUserCount);

            long secondaryUserCount = preferences.values().stream().filter(UserPreferenceUtils::isSecondary).count();
            Assert.assertEquals(1, secondaryUserCount);

        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    @Test
    public void testEnrichTripWithUserDetailsFunction_incomingPrimaryAndSecondaryUser() {
        try(KeyedTwoInputStreamOperatorTestHarness<String, TripWrapper, UserPreference, TripWrapper> testHarness = testHarness()) {

            testHarness.setup();
            testHarness.open();

            UserPreference secondaryRider = UserPreferenceGenerator.getSecondaryRider(TripData.VIRTUAL_ID);
            StreamRecord<UserPreference> streamRecord = new StreamRecord<>(secondaryRider);

            testHarness.processElement2(streamRecord);

            MapState<String, Map<String, UserPreference>> preferencesStateMap = getPreferencesStateMap(testHarness);

            Map<String, UserPreference> preferences = preferencesStateMap.get(TripData.VIRTUAL_ID);

            Assert.assertNotNull(preferences);
            Assert.assertEquals(1, preferences.size());
            UserPreference stateValue = preferences.getOrDefault(secondaryRider.getProfileId(), null);
            Assert.assertNotNull(stateValue);

        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

}
