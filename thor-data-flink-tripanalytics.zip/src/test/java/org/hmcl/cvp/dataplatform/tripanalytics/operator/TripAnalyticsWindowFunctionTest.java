package org.hmcl.cvp.dataplatform.tripanalytics.operator;

import org.apache.flink.api.common.ExecutionConfig;
import org.apache.flink.api.common.state.ListStateDescriptor;
import org.apache.flink.api.common.typeinfo.TypeHint;
import org.apache.flink.api.common.typeinfo.TypeInformation;
import org.apache.flink.api.java.functions.KeySelector;
import org.apache.flink.api.java.tuple.Tuple4;
import org.apache.flink.runtime.jobgraph.OperatorID;
import org.apache.flink.runtime.metrics.groups.InternalOperatorMetricGroup;
import org.apache.flink.runtime.metrics.util.InterceptingOperatorMetricGroup;
import org.apache.flink.runtime.metrics.util.InterceptingTaskMetricGroup;
import org.apache.flink.runtime.operators.testutils.MockEnvironment;
import org.apache.flink.runtime.operators.testutils.MockEnvironmentBuilder;
import org.apache.flink.runtime.testutils.MiniClusterResourceConfiguration;
import org.apache.flink.streaming.api.watermark.Watermark;
import org.apache.flink.streaming.api.windowing.assigners.SlidingEventTimeWindows;
import org.apache.flink.streaming.api.windowing.time.Time;
import org.apache.flink.streaming.api.windowing.triggers.EventTimeTrigger;
import org.apache.flink.streaming.api.windowing.windows.TimeWindow;
import org.apache.flink.streaming.runtime.operators.windowing.WindowOperator;
import org.apache.flink.streaming.runtime.operators.windowing.functions.InternalIterableProcessWindowFunction;
import org.apache.flink.streaming.runtime.streamrecord.StreamRecord;
import org.apache.flink.streaming.util.KeyedOneInputStreamOperatorTestHarness;
import org.apache.flink.test.util.MiniClusterWithClientResource;
import org.hmcl.cvp.dataplatform.commons.exception.FlinkRuntimeException;
import org.hmcl.cvp.dataplatform.commons.utils.DateUtils;
import org.hmcl.cvp.dataplatform.contract.telemetry.Tenant;
import org.hmcl.cvp.dataplatform.tripanalytics.contract.TripBreak;
import org.hmcl.cvp.dataplatform.tripanalytics.contract.TripBreakKey;
import org.hmcl.cvp.dataplatform.tripanalytics.contract.TripWrapper;
import org.hmcl.cvp.dataplatform.tripanalytics.contract.UserDetails;
import org.hmcl.cvp.dataplatform.tripanalytics.helper.TripAnalyticsHelper;
import org.hmcl.cvp.dataplatform.tripanalytics.utils.TripData;
import org.junit.Assert;
import org.junit.ClassRule;
import org.junit.Test;

import java.time.Instant;
import java.util.Comparator;
import java.util.List;

public class TripAnalyticsWindowFunctionTest {

    @ClassRule
    public static MiniClusterWithClientResource flinkCluster =
            new MiniClusterWithClientResource(
                    new MiniClusterResourceConfiguration.Builder()
                            .setNumberSlotsPerTaskManager(2)
                            .setNumberTaskManagers(1)
                            .build());

    private final InterceptingOperatorMetricGroup interceptingOperatorMetricGroup = new InterceptingOperatorMetricGroup();

    private final InterceptingTaskMetricGroup interceptingTaskMetricGroup = new InterceptingTaskMetricGroup() {
        @Override
        public InternalOperatorMetricGroup getOrAddOperator(OperatorID operatorID, String name) {
            return interceptingOperatorMetricGroup;
        }
    };

    private final MockEnvironment mockEnvironment = new MockEnvironmentBuilder().setMetricGroup(interceptingTaskMetricGroup).build();

    private static final TypeInformation<TripWrapper> TRIP_WRAPPER_TYPE = TypeInformation.of(new TypeHint<TripWrapper>() {});
    private static final TypeInformation<TripBreakKey> TRIP_BEAK_KEY_TYPE = TypeInformation.of(new TypeHint<TripBreakKey>() {});
    ListStateDescriptor<TripWrapper> stateDesc = new ListStateDescriptor<>("window-contents", TRIP_WRAPPER_TYPE.createSerializer(new ExecutionConfig()));

    private final KeySelector<TripWrapper, TripBreakKey> keySelector = value -> TripBreakKey.builder().tripId(value.getTripId()).virtualId(value.getVirtualId()).build();

    private final TripAnalyticsWindowFunction windowFunction = new TripAnalyticsWindowFunction();

    private KeyedOneInputStreamOperatorTestHarness<TripBreakKey, TripWrapper, TripWrapper> testHarness(int windowDuration) throws Exception {

        WindowOperator<TripBreakKey, TripWrapper, Iterable<TripWrapper>, TripWrapper, TimeWindow> operator = new WindowOperator<>(
                SlidingEventTimeWindows.of(Time.seconds(windowDuration + 1), Time.seconds(windowDuration)),
                new TimeWindow.Serializer(),
                keySelector,
                TRIP_BEAK_KEY_TYPE.createSerializer(new ExecutionConfig()),
                stateDesc,
                new InternalIterableProcessWindowFunction<>(windowFunction),
                EventTimeTrigger.create(), 0L, null);

        return new KeyedOneInputStreamOperatorTestHarness<>(operator, keySelector, TRIP_BEAK_KEY_TYPE, mockEnvironment);
    }


    private KeyedOneInputStreamOperatorTestHarness<TripBreakKey, TripWrapper, TripWrapper> testHarness() throws Exception {
        return testHarness(90);
    }

    @Test
    public void testSnapshotProcessWindowFunction_evTripBreak() throws Exception {
        Tuple4<Boolean, Integer, Double, Double> values = new Tuple4<>();
        values.f0 = true; // ignition
        values.f1 = 0; // vehicle speed
        values.f2 = 100.0; // odometer reading
        values.f3 = 1.0; // motor state

        tripBreak_userDetailsNull(testHarness(), Tenant.EV, values);
    }

    @Test
    public void testSnapshotProcessWindowFunction_iceTripBreak() throws Exception {
        Tuple4<Boolean, Integer, Double, Double> values = new Tuple4<>();
        values.f0 = true; // ignition
        values.f1 = 0; // vehicle speed
        values.f2 = 100.0; // odometer reading
        values.f3 = 880.0; // RPM

        tripBreak_userDetailsNull(testHarness(), Tenant.ICE, values);
    }

    @Test
    public void testSnapshotProcessWindowFunction_harleyTripBreak() throws Exception {
        Tuple4<Boolean, Integer, Double, Double> values = new Tuple4<>();
        values.f0 = true; // ignition
        values.f1 = 0; // vehicle speed
        values.f2 = 100.0; // odometer reading
        values.f3 = 880.0; // RPM

        tripBreak_userDetailsNull(testHarness(), Tenant.HARLEY, values);
    }

    private void tripBreak_userDetailsNull(KeyedOneInputStreamOperatorTestHarness<TripBreakKey, TripWrapper, TripWrapper> testHarness,
                           Tenant tenant,
                           Tuple4<Boolean, Integer, Double, Double> values) {
        int countOfEachSignal = 1;
        int countOfEvents = 5;

        try(testHarness) {

            testHarness.setup();
            testHarness.open();

            String virtualId = TripData.getVirtualId(tenant);
            String tripId = TripData.getTripId();

            long currentTime = DateUtils.currentEpochTime();
            testHarness.setProcessingTime(currentTime);
            testHarness.processWatermark(currentTime);

            Instant instant = Instant.now();

            List<TripWrapper> breakEvents = TripData.getTripBreakWrapperEvents(virtualId, tenant, tripId, instant, countOfEachSignal, countOfEvents, values);
            List<StreamRecord<TripWrapper>> records = TripData.getTripWrapperStreamRecords(breakEvents);

            long waterTime = breakEvents.get(0).getEvent().getCollectionEventTime();
            testHarness.processWatermark(waterTime);
            testHarness.setProcessingTime(waterTime);

            testHarness.processElements(records);

            // Progress 100 seconds
            currentTime = currentTime + 900000;
            testHarness.processWatermark(new Watermark(currentTime + 900000));

            List<TripWrapper> output = TripData.getCollectedData(testHarness.getRecordOutput());
            Assert.assertEquals(1, output.size());

            TripWrapper tripWrapper = output.get(0);
            Assert.assertTrue(tripWrapper.getIsTripBreak());
            Assert.assertNotNull(tripWrapper.getTripBreak());

            long startTime = breakEvents.stream()
                    .min(Comparator.comparing(TripWrapper::getTimestamp))
                    .map(TripWrapper::getTimestamp)
                    .orElse(0L);

            long endTime = breakEvents.stream()
                    .max(Comparator.comparing(TripWrapper::getTimestamp))
                    .map(TripWrapper::getTimestamp)
                    .orElse(0L);

            TripBreak tripBreak = tripWrapper.getTripBreak();
            Assert.assertEquals(DateUtils.formatToISO(startTime), tripBreak.getStartTimestamp());
            Assert.assertEquals(DateUtils.formatToISO(endTime), tripBreak.getEndTimestamp());
            Assert.assertEquals(TripAnalyticsHelper.DEFAULT_STRING_VALUE, tripBreak.getUserId());
            Assert.assertEquals(TripAnalyticsHelper.DEFAULT_STRING_VALUE, tripBreak.getUserName());
            Assert.assertEquals(TripAnalyticsHelper.DEFAULT_STRING_VALUE, tripBreak.getUserProfile());

        } catch (Exception e) {
            throw new FlinkRuntimeException(e);
        }
    }

    @Test
    public void testSnapshotProcessWindowFunction_evTripBreak_withUserDetails() throws Exception {
        Tuple4<Boolean, Integer, Double, Double> values = new Tuple4<>();
        values.f0 = true; // ignition
        values.f1 = 0; // vehicle speed
        values.f2 = 100.0; // odometer reading
        values.f3 = 1.0; // motor state

        tripBreak_userDetailsPresentInOneEvent(testHarness(), Tenant.EV, values);
    }

    @Test
    public void testSnapshotProcessWindowFunction_iceTripBreak_withUserDetails() throws Exception {
        Tuple4<Boolean, Integer, Double, Double> values = new Tuple4<>();
        values.f0 = true; // ignition
        values.f1 = 0; // vehicle speed
        values.f2 = 100.0; // odometer reading
        values.f3 = 880.0; // RPM

        tripBreak_userDetailsPresentInOneEvent(testHarness(), Tenant.ICE, values);
    }

    @Test
    public void testSnapshotProcessWindowFunction_harleyTripBreak_withUserDetails() throws Exception {
        Tuple4<Boolean, Integer, Double, Double> values = new Tuple4<>();
        values.f0 = true; // ignition
        values.f1 = 0; // vehicle speed
        values.f2 = 100.0; // odometer reading
        values.f3 = 880.0; // RPM

        tripBreak_userDetailsPresentInOneEvent(testHarness(), Tenant.HARLEY, values);
    }

    private void tripBreak_userDetailsPresentInOneEvent(KeyedOneInputStreamOperatorTestHarness<TripBreakKey, TripWrapper, TripWrapper> testHarness,
                                           Tenant tenant,
                                           Tuple4<Boolean, Integer, Double, Double> values) {
        int countOfEachSignal = 1;
        int countOfEvents = 5;

        try(testHarness) {

            testHarness.setup();
            testHarness.open();

            String virtualId = TripData.getVirtualId(tenant);
            String tripId = TripData.getTripId();

            long currentTime = DateUtils.currentEpochTime();
            testHarness.setProcessingTime(currentTime);
            testHarness.processWatermark(currentTime);

            Instant instant = Instant.now();

            List<TripWrapper> breakEvents = TripData.getTripBreakWrapperEvents(virtualId, tenant, tripId, instant, countOfEachSignal, countOfEvents, values);

            List<TripWrapper> breakEventsWithUserDetails = TripData.getTripBreakWrapperEvents(virtualId, tenant, tripId, instant, countOfEachSignal, 1, values);
            TripWrapper breakEventWithUserDetails = breakEventsWithUserDetails.get(0);
            UserDetails userDetails = UserDetails.builder()
                    .userId("qwerty")
                    .userProfile("Primary")
                    .userName("Test User")
                    .valid(true)
                    .build();
            breakEventWithUserDetails.setUserDetails(userDetails);
            breakEvents.add(breakEventWithUserDetails);
            List<StreamRecord<TripWrapper>> records = TripData.getTripWrapperStreamRecords(breakEvents);

            long waterTime = breakEvents.get(0).getEvent().getCollectionEventTime();
            testHarness.processWatermark(waterTime);
            testHarness.setProcessingTime(waterTime);

            testHarness.processElements(records);

            // Progress 100 seconds
            currentTime = currentTime + 900000;
            testHarness.processWatermark(new Watermark(currentTime + 900000));

            List<TripWrapper> output = TripData.getCollectedData(testHarness.getRecordOutput());
            Assert.assertEquals(1, output.size());

            TripWrapper tripWrapper = output.get(0);
            Assert.assertTrue(tripWrapper.getIsTripBreak());
            Assert.assertNotNull(tripWrapper.getTripBreak());

            long startTime = breakEvents.stream()
                    .min(Comparator.comparing(TripWrapper::getTimestamp))
                    .map(TripWrapper::getTimestamp)
                    .orElse(0L);

            long endTime = breakEvents.stream()
                    .max(Comparator.comparing(TripWrapper::getTimestamp))
                    .map(TripWrapper::getTimestamp)
                    .orElse(0L);

            TripBreak tripBreak = tripWrapper.getTripBreak();
            Assert.assertEquals(DateUtils.formatToISO(startTime), tripBreak.getStartTimestamp());
            Assert.assertEquals(DateUtils.formatToISO(endTime), tripBreak.getEndTimestamp());
            Assert.assertEquals(userDetails.getUserId(), tripBreak.getUserId());
            Assert.assertEquals(userDetails.getUserName(), tripBreak.getUserName());
            Assert.assertEquals(userDetails.getUserProfile(), tripBreak.getUserProfile());

        } catch (Exception e) {
            throw new FlinkRuntimeException(e);
        }
    }


    @Test
    public void testSnapshotProcessWindowFunction_evIgnitionOff() throws Exception {
        Tuple4<Boolean, Integer, Double, Double> values = new Tuple4<>();
        values.f0 = false; // ignition
        values.f1 = 0; // vehicle speed
        values.f2 = 1000.0; // odometer reading
        values.f3 = 1.0; // motor state

        nonTripBreak(testHarness(), Tenant.EV, values);
    }

    @Test
    public void testSnapshotProcessWindowFunction_iceIgnitionOff() throws Exception {
        Tuple4<Boolean, Integer, Double, Double> values = new Tuple4<>();
        values.f0 = false; // ignition
        values.f1 = 0; // vehicle speed
        values.f2 = 1000.0; // odometer reading
        values.f3 = 112.0; // rpm

        nonTripBreak(testHarness(), Tenant.ICE, values);
    }

    @Test
    public void testSnapshotProcessWindowFunction_harleyIgnitionOff() throws Exception {
        Tuple4<Boolean, Integer, Double, Double> values = new Tuple4<>();
        values.f0 = false; // ignition
        values.f1 = 0; // vehicle speed
        values.f2 = 1000.0; // odometer reading
        values.f3 = 136.0; // rpm

        nonTripBreak(testHarness(), Tenant.HARLEY, values);
    }

    @Test
    public void testSnapshotProcessWindowFunction_evVehicleSpeedGreaterThanZero() throws Exception {
        Tuple4<Boolean, Integer, Double, Double> values = new Tuple4<>();
        values.f0 = true; // ignition
        values.f1 = 60; // vehicle speed
        values.f2 = 100.0; // odometer reading
        values.f3 = 1.0; // motor state

        nonTripBreak(testHarness(), Tenant.EV, values);
    }

    @Test
    public void testSnapshotProcessWindowFunction_iceVehicleSpeedGreaterThanZero() throws Exception {
        Tuple4<Boolean, Integer, Double, Double> values = new Tuple4<>();
        values.f0 = true; // ignition
        values.f1 = 60; // vehicle speed
        values.f2 = 100.0; // odometer reading
        values.f3 = 1100.0; // rpm

        nonTripBreak(testHarness(), Tenant.ICE, values);
    }

    @Test
    public void testSnapshotProcessWindowFunction_harleyVehicleSpeedGreaterThanZero() throws Exception {
        Tuple4<Boolean, Integer, Double, Double> values = new Tuple4<>();
        values.f0 = true; // ignition
        values.f1 = 60; // vehicle speed
        values.f2 = 100.0; // odometer reading
        values.f3 = 8.0; // rpm

        nonTripBreak(testHarness(), Tenant.HARLEY, values);
    }

    @Test
    public void testSnapshotProcessWindowFunction_evMotorStateOn() throws Exception {
        Tuple4<Boolean, Integer, Double, Double> values = new Tuple4<>();
        values.f0 = true; // ignition
        values.f1 = 0; // vehicle speed
        values.f2 = 100.0; // odometer reading
        values.f3 = 3.0; // motor state

        nonTripBreak(testHarness(), Tenant.EV, values);
    }

    @Test
    public void testSnapshotProcessWindowFunction_iceRPMGreaterThanMin() throws Exception {
        Tuple4<Boolean, Integer, Double, Double> values = new Tuple4<>();
        values.f0 = true; // ignition
        values.f1 = 0; // vehicle speed
        values.f2 = 100.0; // odometer reading
        values.f3 = 1200.0; // RPM

        nonTripBreak(testHarness(), Tenant.ICE, values);
    }

    @Test
    public void testSnapshotProcessWindowFunction_harleyRPMGreaterThanMin() throws Exception {
        Tuple4<Boolean, Integer, Double, Double> values = new Tuple4<>();
        values.f0 = true; // ignition
        values.f1 = 0; // vehicle speed
        values.f2 = 1200.0; // odometer reading
        values.f3 = 1300.0; // RPM

        nonTripBreak(testHarness(), Tenant.HARLEY, values);
    }

    private void nonTripBreak(KeyedOneInputStreamOperatorTestHarness<TripBreakKey, TripWrapper, TripWrapper> testHarness,
                              Tenant tenant,
                              Tuple4<Boolean, Integer, Double, Double> values) {
        int countOfEachSignal = 1;
        int countOfEvents = 5;

        try(testHarness) {

            testHarness.setup();
            testHarness.open();

            String virtualId = TripData.getVirtualId(tenant);
            String tripId = TripData.getTripId();

            long currentTime = DateUtils.currentEpochTime();
            testHarness.setProcessingTime(currentTime);
            testHarness.processWatermark(currentTime);

            Instant instant = Instant.now();

            List<TripWrapper> breakEvents = TripData.getTripBreakWrapperEvents(virtualId, tenant, tripId, instant, countOfEachSignal, countOfEvents, values);
            List<StreamRecord<TripWrapper>> records = TripData.getTripWrapperStreamRecords(breakEvents);

            long waterTime = breakEvents.get(0).getEvent().getCollectionEventTime();
            testHarness.processWatermark(waterTime);
            testHarness.setProcessingTime(waterTime);

            testHarness.processElements(records);

            // Progress 100 seconds
            currentTime = currentTime + 900000;
            testHarness.processWatermark(new Watermark(currentTime + 900000));

            List<TripWrapper> output = TripData.getCollectedData(testHarness.getRecordOutput());
            Assert.assertEquals(0, output.size());

        } catch (Exception e) {
            throw new FlinkRuntimeException(e);
        }
    }

    @Test
    public void testSnapshotProcessWindowFunction_evOdometerIncreasing() throws Exception {
        nonTripBreakOdometerIncreasing(testHarness(), Tenant.EV);
    }

    @Test
    public void testSnapshotProcessWindowFunction_iceOdometerIncreasing() throws Exception {
        nonTripBreakOdometerIncreasing(testHarness(), Tenant.ICE);
    }

    @Test
    public void testSnapshotProcessWindowFunction_harleyOdometerIncreasing() throws Exception {
        nonTripBreakOdometerIncreasing(testHarness(), Tenant.HARLEY);
    }

    private void nonTripBreakOdometerIncreasing(KeyedOneInputStreamOperatorTestHarness<TripBreakKey, TripWrapper, TripWrapper> testHarness,
                                                Tenant tenant) {
        int countOfEachSignal = 1;
        int countOfEvents = 5;

        try(testHarness) {

            testHarness.setup();
            testHarness.open();

            String virtualId = TripData.getVirtualId(tenant);
            String tripId = TripData.getTripId();

            long currentTime = DateUtils.currentEpochTime();
            testHarness.setProcessingTime(currentTime);
            testHarness.processWatermark(currentTime);

            Instant instant = Instant.now();

            List<TripWrapper> breakEvents = TripData.getOdometerIncrementEvents(virtualId, tenant, tripId, instant, countOfEachSignal, countOfEvents);
            List<StreamRecord<TripWrapper>> records = TripData.getTripWrapperStreamRecords(breakEvents);

            long waterTime = breakEvents.get(0).getEvent().getCollectionEventTime();
            testHarness.processWatermark(waterTime);
            testHarness.setProcessingTime(waterTime);

            testHarness.processElements(records);

            // Progress 100 seconds
            currentTime = currentTime + 900000;
            testHarness.processWatermark(new Watermark(currentTime + 900000));

            List<TripWrapper> output = TripData.getCollectedData(testHarness.getRecordOutput());
            Assert.assertEquals(0, output.size());

        } catch (Exception e) {
            throw new FlinkRuntimeException(e);
        }
    }
}
