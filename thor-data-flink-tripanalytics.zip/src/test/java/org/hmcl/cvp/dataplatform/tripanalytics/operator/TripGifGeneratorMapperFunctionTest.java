package org.hmcl.cvp.dataplatform.tripanalytics.operator;

import com.google.gson.Gson;
import org.apache.flink.runtime.jobgraph.OperatorID;
import org.apache.flink.runtime.metrics.groups.InternalOperatorMetricGroup;
import org.apache.flink.runtime.metrics.util.InterceptingOperatorMetricGroup;
import org.apache.flink.runtime.metrics.util.InterceptingTaskMetricGroup;
import org.apache.flink.runtime.operators.testutils.MockEnvironment;
import org.apache.flink.runtime.operators.testutils.MockEnvironmentBuilder;
import org.apache.flink.runtime.testutils.MiniClusterResourceConfiguration;
import org.apache.flink.streaming.api.operators.StreamFlatMap;
import org.apache.flink.streaming.runtime.streamrecord.StreamRecord;
import org.apache.flink.streaming.util.OneInputStreamOperatorTestHarness;
import org.apache.flink.test.util.MiniClusterWithClientResource;
import org.hmcl.cvp.dataplatform.commons.exception.FlinkRuntimeException;
import org.hmcl.cvp.dataplatform.commons.utils.GsonUtils;
import org.hmcl.cvp.dataplatform.contract.telemetry.Tenant;
import org.hmcl.cvp.dataplatform.tripanalytics.contract.TripEnd;
import org.hmcl.cvp.dataplatform.tripanalytics.contract.TripForGif;
import org.hmcl.cvp.dataplatform.tripanalytics.contract.TripWrapper;
import org.hmcl.cvp.dataplatform.tripanalytics.utils.TripData;
import org.junit.Assert;
import org.junit.ClassRule;
import org.junit.Test;

import java.util.List;

public class TripGifGeneratorMapperFunctionTest {

    private static  final Gson GSON = GsonUtils.getGson();

    @ClassRule
    public static MiniClusterWithClientResource flinkCluster =
            new MiniClusterWithClientResource(
                    new MiniClusterResourceConfiguration.Builder()
                            .setNumberSlotsPerTaskManager(2)
                            .setNumberTaskManagers(1)
                            .build());

    private final InterceptingOperatorMetricGroup interceptingOperatorMetricGroup = new InterceptingOperatorMetricGroup();
    private final InterceptingTaskMetricGroup interceptingTaskMetricGroup = new InterceptingTaskMetricGroup() {
        @Override
        public InternalOperatorMetricGroup getOrAddOperator(OperatorID operatorID, String name) {
            return interceptingOperatorMetricGroup;
        }
    };

    private final MockEnvironment mockEnvironment = new MockEnvironmentBuilder().setMetricGroup(interceptingTaskMetricGroup).build();

    private final TripGifGeneratorMapperFunction tripGifGeneratorMapperFunction = new TripGifGeneratorMapperFunction();

    private OneInputStreamOperatorTestHarness<TripWrapper, String> testHarness() throws Exception {
        return new OneInputStreamOperatorTestHarness<>(new StreamFlatMap<>(tripGifGeneratorMapperFunction), mockEnvironment);
    }

    @Test
    public void testTripAnalyticsOpenSearchMapperFunction_notTripEnd() {
        Tenant tenant = Tenant.EV;
        String virtualId = TripData.getVirtualId(tenant);
        TripWrapper tripWrapper = TripData.getTripStartWrapper(virtualId, tenant, 1, 1);

        try(OneInputStreamOperatorTestHarness<TripWrapper, String> testHarness = testHarness()) {

            testHarness.setup();
            testHarness.open();

            testHarness.processElement(new StreamRecord<>(tripWrapper));

            List<String> output = TripData.getCollectedData(testHarness.getRecordOutput());
            Assert.assertEquals(0, output.size());

        } catch (Exception e) {
            throw new FlinkRuntimeException(e);
        }
    }

    @Test
    public void testTripAnalyticsOpenSearchMapperFunction_evTripEnd() throws Exception {
        Tenant tenant = Tenant.EV;
        String virtualId = TripData.getVirtualId(tenant);
        TripWrapper tripWrapper = TripData.getTripEndWrapper(virtualId, tenant, 1, 1);
        tripMapper(testHarness(), tripWrapper);
    }

    @Test
    public void testTripAnalyticsOpenSearchMapperFunction_iceTripEnd() throws Exception {
        Tenant tenant = Tenant.ICE;
        String virtualId = TripData.getVirtualId(tenant);
        TripWrapper tripWrapper = TripData.getTripEndWrapper(virtualId, tenant, 1, 1);
        tripMapper(testHarness(), tripWrapper);
    }

    @Test
    public void testTripAnalyticsOpenSearchMapperFunction_harleyTripEnd() throws Exception {
        Tenant tenant = Tenant.HARLEY;
        String virtualId = TripData.getVirtualId(tenant);
        TripWrapper tripWrapper = TripData.getTripEndWrapper(virtualId, tenant, 1, 1);
        tripMapper(testHarness(), tripWrapper);
    }

    private void tripMapper(OneInputStreamOperatorTestHarness<TripWrapper, String> testHarness,
                            TripWrapper tripWrapper) {

        try(testHarness) {

            testHarness.setup();
            testHarness.open();

            testHarness.processElement(new StreamRecord<>(tripWrapper));

            List<String> output = TripData.getCollectedData(testHarness.getRecordOutput());
            Assert.assertEquals(1, output.size());

            String value = output.get(0);
            TripForGif tripForGif = GSON.fromJson(value, TripForGif.class);
            Assert.assertNotNull(tripForGif);

            TripEnd tripEnd = tripWrapper.getTripEnd();
            Assert.assertEquals(tripForGif.getTripId(), tripWrapper.getTripId());
            Assert.assertEquals(tripForGif.getEndTime(), tripEnd.getSourceTimestamp());
            Assert.assertEquals(tripForGif.getStartTime(), tripEnd.getSourceTripStartTimestamp());

        } catch (Exception e) {
            throw new FlinkRuntimeException(e);
        }
    }

}
