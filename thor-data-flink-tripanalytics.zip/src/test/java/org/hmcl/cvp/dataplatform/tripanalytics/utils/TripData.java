package org.hmcl.cvp.dataplatform.tripanalytics.utils;


import com.google.gson.Gson;
import org.apache.flink.api.java.tuple.Tuple4;
import org.apache.flink.streaming.runtime.streamrecord.StreamRecord;
import org.hmcl.cvp.dataplatform.commons.catalogue.SignalCatalogue;
import org.hmcl.cvp.dataplatform.commons.testdata.CampaignDataGenerator;
import org.hmcl.cvp.dataplatform.commons.utils.*;
import org.hmcl.cvp.dataplatform.contract.telemetry.SignalData;
import org.hmcl.cvp.dataplatform.contract.telemetry.SignalInfo;
import org.hmcl.cvp.dataplatform.contract.telemetry.Telemetry;
import org.hmcl.cvp.dataplatform.contract.telemetry.Tenant;
import org.hmcl.cvp.dataplatform.contract.userpreference.UserPreference;
import org.hmcl.cvp.dataplatform.tripanalytics.contract.TripEndSignal;
import org.hmcl.cvp.dataplatform.tripanalytics.contract.TripStartSignal;
import org.hmcl.cvp.dataplatform.tripanalytics.contract.TripWrapper;
import org.hmcl.cvp.dataplatform.tripanalytics.contract.UserDetails;
import org.hmcl.cvp.dataplatform.tripanalytics.helper.TripAnalyticsHelper;

import java.time.Instant;
import java.util.*;
import java.util.concurrent.ThreadLocalRandom;
import java.util.stream.Collectors;

public class TripData {

    private static final Gson GSON = GsonUtils.getGson();

    public static final String VIRTUAL_ID = "test-vehicle";
    public static final String IGNITION_RISE = "hmcl-cv-fw-periodic-app-screen-telemetry-ign-rise";
    public static final String IGNITION_FALL = "hmcl-cv-fw-periodic-app-screen-telemetry-ign-fall";
    public static final Long SECONDS_TO_SUBTRACT_FROM_TRIP_END = 15L * 60L;

    public static List<String> getJsonData(List<Telemetry> data) {
        return data.stream().map(GSON::toJson).collect(Collectors.toList());
    }

    public static String getVirtualId(Tenant tenant) {
        switch (tenant) {
            case EV:
                return VIRTUAL_ID + "-ev";
            case HARLEY:
                return VIRTUAL_ID + "-harley";
            case ICE:
                return VIRTUAL_ID + "-ice";
            default:
                return VIRTUAL_ID;
        }
    }

    public static String getTripId() {
        return String.valueOf(ThreadLocalRandom.current().nextLong(10,100));
    }

    public static String getNextTripId(String existingTripId) {
        double origin = Double.parseDouble(existingTripId);
        long nextTrip = (long) (origin + 1.0);
        return String.valueOf(nextTrip);
    }

    public static SignalData getTripIdSignal(String tripId, Instant instant) {
        return new SignalData(tripId, instant.toEpochMilli(), "STRING");
    }

    public static <T> List<T> getCollectedData(Collection<StreamRecord<T>> testHarnessOutput) {
        return testHarnessOutput.stream().map(StreamRecord::getValue).collect(Collectors.toList());
    }

    public static List<StreamRecord<TripWrapper>> getTripWrapperStreamRecords(List<TripWrapper> jsonData) {
        return jsonData.stream()
                .map(t -> new StreamRecord<>(t, t.getEvent().getCollectionEventTime()))
                .collect(Collectors.toList());
    }

    public static String getTripStartValue(String tripId, Instant instant, Integer profile) {
        TripStartSignal tripStartSignal = getTripStartSignalValue(tripId,instant , profile);

        return GSON.toJson(tripStartSignal);
    }

    public static TripStartSignal getTripStartSignalValue(String tripId, Instant instant, Integer profile) {
        return TripStartSignal.builder()
                .tripId(tripId)
                .ambientTemperature(1234)
                .batteryTemperature(66.8)
                .fuelValue(10.19)
                .hDop(1.5)
                .latitude(12.971599)
                .longitude(77.594566)
                .odometer(110.0)
                .pDop(0.0)
                .remainingRange(321)
                .soc(59.1)
                .usableEnergy(187)
                .vehicleMode(0)
                .userId("qwerty")
                .userProfile(profile)
                .timestamp(instant.toEpochMilli())
                .build();
    }

    public static String getTripEndValue(String tripId, Instant instant, Integer profile) {
        TripEndSignal tripEndSignal = TripEndSignal.builder()
                .tripId(tripId)
                .ambientTemperature(8776)
                .batteryTemperature(45.9)
                .fuelValue(1.18)
                .hDop(1.5)
                .latitude(13.971599)
                .longitude(78.594566)
                .odometer(2000.0)
                .pDop(0.0)
                .remainingRange(12)
                .soc(8.1)
                .usableEnergy(7)
                .vehicleMode(1)
                .userId("qwerty")
                .userProfile(profile)
                .timestamp(instant.toEpochMilli())
                .start(getTripStartSignalValue(tripId, instant.minusSeconds(SECONDS_TO_SUBTRACT_FROM_TRIP_END), profile))
                .build();

        return GSON.toJson(tripEndSignal);
    }

    public static Telemetry getTripStartFlag(String virtualId, Tenant tenant, String tripId, Instant instant, int countOfEachSignal, Integer profile) {

        Telemetry telemetry = CampaignDataGenerator.getTelemetry(virtualId, tenant, instant, countOfEachSignal);
        telemetry.setCampaignName(IGNITION_RISE);

        SignalData tripStartFlag = getTripStartSignal(tripId, instant, profile);
        addSignal(telemetry, SignalCatalogue.getTripStartFlag(), tripStartFlag);

        addSignal(telemetry, SignalCatalogue.getTripId(), getTripIdSignal(tripId, instant));

        SignalData vehicleMode = new SignalData();
        vehicleMode.setValue(1);
        vehicleMode.setDataType("INTEGER");
        vehicleMode.setTime(instant.toEpochMilli());
        addSignal(telemetry, SignalCatalogue.getDrivingModeInfo(), vehicleMode);

        SignalData odometer = new SignalData();
        odometer.setValue(100.0);
        odometer.setDataType("DOUBLE");
        odometer.setTime(instant.toEpochMilli());
        addSignal(telemetry, SignalCatalogue.getOdometerHRInfo(), odometer);

        return telemetry;
    }

    public static SignalData getTripStartSignal(String tripId, Instant instant, Integer profile) {
        String tripStartSignal = getTripStartValue(tripId, instant, profile);
        return new SignalData(tripStartSignal, instant.toEpochMilli(), "VARCHAR");
    }

    public static Telemetry getTripEvent(Telemetry tripStartFlag, Instant instant) {
        Telemetry telemetry = TelemetryUtils.deepCopy(tripStartFlag);
        assert telemetry != null;
        telemetry.setCollectionEventTime(instant.toEpochMilli());
        telemetry.setCampaignName(IGNITION_RISE);

        removeSignal(telemetry, SignalCatalogue.getTripStartFlag());

        SignalData odometer = new SignalData();
        odometer.setValue(100.0);
        odometer.setDataType("DOUBLE");
        odometer.setTime(instant.toEpochMilli());
        addSignal(telemetry, SignalCatalogue.getOdometerHRInfo(), odometer);

        return telemetry;
    }

    public static Telemetry getTripEndFlag(String virtualId, Tenant tenant, String tripId, Instant instant, int countOfEachSignal, Integer profile) {
        Telemetry telemetry = CampaignDataGenerator.getTelemetry(virtualId, tenant, instant, countOfEachSignal);
        telemetry.setCampaignName(IGNITION_FALL);

        SignalData tripEndFlag = getTripEndSignal(tripId, instant, profile);
        addSignal(telemetry, SignalCatalogue.getTripEndFlag(), tripEndFlag);

        addSignal(telemetry, SignalCatalogue.getTripId(), getTripIdSignal(tripId, instant));

        SignalData odometer = new SignalData();
        odometer.setValue(100.0);
        odometer.setDataType("DOUBLE");
        odometer.setTime(instant.toEpochMilli());
        addSignal(telemetry, SignalCatalogue.getOdometerHRInfo(), odometer);

        return telemetry;
    }

    public static SignalData getTripEndSignal( String tripId, Instant instant, Integer profile) {
        String endTripValue = getTripEndValue(tripId, instant, profile);
        return new SignalData(endTripValue, instant.toEpochMilli(), "VARCHAR");
    }

    public static void addUserDetailsToTelemetry(Telemetry telemetry, UserPreference userPreference, Instant instant) {
        int userProfile = UserPreferenceUtils.isPrimary(userPreference) ? 1 : 2;

        SignalData userIdSignal = new SignalData();
        userIdSignal.setTime(instant.toEpochMilli());
        userIdSignal.setDataType("VARCHAR");
        userIdSignal.setValue(userPreference.getProfileId());

        SignalData userProfileSignal = new SignalData();
        userProfileSignal.setTime(instant.toEpochMilli());
        userProfileSignal.setDataType("INTEGER");
        userProfileSignal.setValue(userProfile);

        addSignal(telemetry, SignalCatalogue.getUserIdInfo(), userIdSignal);

        addSignal(telemetry, SignalCatalogue.getUserProfileInfo(), userProfileSignal);
    }

    public static TripWrapper getTripStartWrapper(String virtualId,Tenant tenant, int countOfEachSignal, Integer profile) {
        return getTripStartWrapper(virtualId, tenant, countOfEachSignal,profile, false);
    }

    public static TripWrapper getTripStartWrapper(String virtualId,Tenant tenant, int countOfEachSignal, Integer profile, boolean isTripEnd) {
        String tripId = getTripId();
        Telemetry tripStartTelemetry = getTripStartFlag(virtualId, tenant, tripId, Instant.now(), countOfEachSignal, profile);
        List<SignalData> tripStartFlags = TripAnalyticsHelper.getTripStartSignals(tripStartTelemetry);
        TripStartSignal tripStartSignal = TripAnalyticsHelper.getTripStartSignalValue(tripStartFlags.get(0));

        return TripAnalyticsHelper.getTripStart(virtualId, tripId, tripStartSignal, tripStartTelemetry, isTripEnd);
    }

    public static TripWrapper getTripEndWrapper(String virtualId,Tenant tenant, int countOfEachSignal, Integer profile) {
        String tripId = getTripId();
        Telemetry tripEndTelemetry = getTripEndFlag(virtualId, tenant, tripId, Instant.now(), countOfEachSignal, profile);
        List<SignalData> tripEndFlags = TripAnalyticsHelper.getTripEndSignals(tripEndTelemetry);
        TripEndSignal tripEndSignal = TripAnalyticsHelper.getTripEndSignalValue(tripEndFlags.get(0));

        TripWrapper tripWrapper = TripWrapper.builder().build();
        return TripAnalyticsHelper.getTripEnd(virtualId, tripId, tripEndSignal, tripWrapper, tripEndTelemetry);
    }

    public static TripWrapper getTripBreakWrapper(String virtualId, Tenant tenant, int countOfEachSignal, Integer profile) {
        String tripId = getTripId();
        String nextTripId = getNextTripId(tripId);
        Telemetry tripStartFlag = getTripEndFlag(virtualId, tenant, tripId, Instant.now(), countOfEachSignal, profile);
        Telemetry tripEvent = getTripEvent(tripStartFlag, Instant.now());

        return TripAnalyticsHelper.getTripBreak(virtualId, tripId,  nextTripId, tripEvent.getCollectionEventTime(), tripEvent);
    }

    public static void addUserDetailsToTripWrapper(TripWrapper tripWrapper, UserPreference userPreference) {
        UserDetails userDetails = UserDetails.builder()
                .userId(userPreference.getProfileId())
                .userProfile(userPreference.getProfileType().value())
                .valid(true)
                .build();

        tripWrapper.setUserDetails(userDetails);
    }

    public static Telemetry getTripBreakEvent(Tenant tenant,
                                              Telemetry tripStart,
                                              Instant instant,
                                              Tuple4<Boolean, Integer, Double, Double> values) {

        Telemetry tripEvent = getTripEvent(tripStart, instant);
        tripEvent.setCampaignName(IGNITION_RISE);

        addIgnition(tripEvent, values.f0);
        addVehicleSpeed(tripEvent, values.f1);
        addOdometer(tripEvent, values.f2);
        addSoc(tripEvent);

        if(tenant.equals(Tenant.EV)) {
            addMotorState(tripEvent, values.f3.intValue());
        } else {
            addEngineSpeed(tripEvent, values.f3);
        }

        return tripEvent;
    }

    public static List<Telemetry> getTripBreakEvents(String virtualId,
                                                              Tenant tenant,
                                                              String tripId,
                                                              Instant instant,
                                                              int countOfEachSignal,
                                                              int countOfEvents,
                                                              Tuple4<Boolean, Integer, Double, Double> values) {

        List<Telemetry> telemetries = new ArrayList<>(countOfEvents);

        Telemetry tripStart = getTripStartFlag(virtualId, tenant, tripId, instant, countOfEachSignal, 1);

        for(int i = 0; i < countOfEvents; i++) {
            Instant newInstant = instant.plusSeconds(i);
            Telemetry tripEvent = getTripBreakEvent(tenant, tripStart, newInstant, values);
            telemetries.add(tripEvent);
        }

        return telemetries;
    }

    public static List<TripWrapper> getTripBreakWrapperEvents(String virtualId,
                                                       Tenant tenant,
                                                       String tripId,
                                                       Instant instant,
                                                       int countOfEachSignal,
                                                       int countOfEvents,
                                                       Tuple4<Boolean, Integer, Double, Double> values) {

        List<Telemetry> telemetries = getTripBreakEvents(virtualId, tenant, tripId, instant, countOfEachSignal, countOfEvents, values);

        List<TripWrapper> tripWrapperList = new ArrayList<>(countOfEvents);

        telemetries.forEach(t -> {
            TripWrapper tripWrapper = new TripWrapper();
            tripWrapper.setTimestamp(t.getCollectionEventTime());
            tripWrapper.setNeededForTripBreak(true);
            tripWrapper.setEvent(t);
            tripWrapper.setTripId(tripId);
            tripWrapper.setVirtualId(virtualId);

            tripWrapperList.add(tripWrapper);
        });

        return tripWrapperList;
    }

    public static List<TripWrapper> getOdometerIncrementEvents(String virtualId,
                                                          Tenant tenant,
                                                          String tripId,
                                                          Instant instant,
                                                          int countOfEachSignal,
                                                          int countOfEvents) {

        List<TripWrapper> tripWrapperList = new ArrayList<>(countOfEvents);

        Telemetry tripStart = getTripStartFlag(virtualId, tenant, tripId, instant, countOfEachSignal, 1);

        for(int i = 0; i < countOfEvents; i++) {
            Instant newInstant = instant.plusSeconds(i);
            Telemetry tripEvent = getTripEvent(tripStart, newInstant);

            addIgnition(tripEvent, true);
            addVehicleSpeed(tripEvent, 0);
            addOdometer(tripEvent, 100.0 + i);

            if(tenant.equals(Tenant.EV)) {
                addMotorState(tripEvent, 1);
            } else {
                addEngineSpeed(tripEvent, 800.0);
            }

            TripWrapper tripWrapper = new TripWrapper();
            tripWrapper.setTimestamp(newInstant.toEpochMilli());
            tripWrapper.setNeededForTripBreak(true);
            tripWrapper.setEvent(tripEvent);
            tripWrapper.setTripId(tripId);
            tripWrapper.setVirtualId(virtualId);

            tripWrapperList.add(tripWrapper);
        }

        return tripWrapperList;
    }

    public static void addSignal(Telemetry telemetry, SignalInfo signalInfo, SignalData signalToAdd) {
        Map<String, Set<SignalData>> signalMap = telemetry.getSignals();
        Set<SignalData> signals = SignalUtils.getSignals(signalMap, signalInfo);
        signals.add(signalToAdd);

        signalMap.put(signalInfo.getKey(), signals);

        telemetry.setSignals(signalMap);
    }

    private static void removeSignal(Telemetry telemetry, SignalInfo signalInfo) {
        Map<String, Set<SignalData>> signalMap = telemetry.getSignals();
        signalMap.remove(signalInfo.getKey());
        telemetry.setSignals(signalMap);
    }

    private static void addVehicleSpeed(Telemetry telemetry, int speedValue) {
        SignalInfo signalInfo = SignalCatalogue.getVehicleSpeedDisplayInfo();

        SignalData signalData = new SignalData();
        signalData.setDataType("INTEGER");
        signalData.setTime(DateUtils.currentEpochTime());
        signalData.setValue(speedValue);

        removeSignal(telemetry, signalInfo);
        addSignal(telemetry, signalInfo, signalData);
    }

    private static void addSoc(Telemetry telemetry) {
        SignalInfo signalInfo = SignalCatalogue.getSocUserPercentageInfo();

        SignalData signalData = new SignalData();
        signalData.setDataType("DOUBLE");
        signalData.setTime(DateUtils.currentEpochTime());
        signalData.setValue(20.0);

        removeSignal(telemetry, signalInfo);
        addSignal(telemetry, signalInfo, signalData);
    }

    private static void addOdometer(Telemetry telemetry, double odometerValue) {
        SignalInfo signalInfo = SignalCatalogue.getOdometerHRInfo();

        SignalData signalData = new SignalData();
        signalData.setDataType("DOUBLE");
        signalData.setTime(DateUtils.currentEpochTime());
        signalData.setValue(odometerValue);

        removeSignal(telemetry, signalInfo);
        addSignal(telemetry, signalInfo, signalData);
    }

    private static void addIgnition(Telemetry telemetry, boolean value) {
        SignalInfo signalInfo = SignalCatalogue.getTcuIgnitionInfo();

        SignalData signalData = new SignalData();
        signalData.setDataType("BOOLEAN");
        signalData.setTime(DateUtils.currentEpochTime());
        signalData.setValue(value);

        removeSignal(telemetry, signalInfo);
        addSignal(telemetry, signalInfo, signalData);
    }

    private static void addMotorState(Telemetry telemetry, int motorStateValue) {
        SignalInfo signalInfo = SignalCatalogue.getMotorStatusInfo();

        SignalData signalData = new SignalData();
        signalData.setDataType("INTEGER");
        signalData.setTime(DateUtils.currentEpochTime());
        signalData.setValue(motorStateValue);

        removeSignal(telemetry, signalInfo);
        addSignal(telemetry, signalInfo, signalData);
    }

    private static void addEngineSpeed(Telemetry telemetry, double engineSpeed) {
        SignalInfo signalInfo = SignalCatalogue.getEngineSpeedInfo();

        SignalData signalData = new SignalData();
        signalData.setDataType("DOUBLE");
        signalData.setTime(DateUtils.currentEpochTime());
        signalData.setValue(engineSpeed);

        removeSignal(telemetry, signalInfo);
        addSignal(telemetry, signalInfo, signalData);
    }

}
