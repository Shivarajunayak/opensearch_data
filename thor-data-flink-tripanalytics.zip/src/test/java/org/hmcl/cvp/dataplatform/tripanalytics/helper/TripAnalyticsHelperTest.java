package org.hmcl.cvp.dataplatform.tripanalytics.helper;

import org.hmcl.cvp.dataplatform.commons.testdata.CampaignDataGenerator;
import org.hmcl.cvp.dataplatform.contract.telemetry.Telemetry;
import org.junit.Assert;
import org.junit.Test;

public class TripAnalyticsHelperTest {

    @Test
    public void testTripAnalyticsHelper_isIgnitionRiseCampaign() {
        Telemetry telemetry = CampaignDataGenerator.getTelemetry();
        telemetry.setCampaignName("ign-rise");
        Assert.assertTrue(TripAnalyticsHelper.isIgnitionRiseCampaign(telemetry));
    }

    @Test
    public void testTripAnalyticsHelper_isIgnitionRiseCampaign_randomCampaign() {
        Telemetry telemetry = CampaignDataGenerator.getTelemetry();
        telemetry.setCampaignName("abc");
        Assert.assertFalse(TripAnalyticsHelper.isIgnitionRiseCampaign(telemetry));
    }

    @Test
    public void testTripAnalyticsHelper_isIgnitionFallCampaign() {
        Telemetry telemetry = CampaignDataGenerator.getTelemetry();
        telemetry.setCampaignName("ign-fall");
        Assert.assertTrue(TripAnalyticsHelper.isIgnitionFallCampaign(telemetry));
    }

    @Test
    public void testTripAnalyticsHelper_isIgnitionFallCampaign_randomCampaign() {
        Telemetry telemetry = CampaignDataGenerator.getTelemetry();
        telemetry.setCampaignName("qwerty");
        Assert.assertFalse(TripAnalyticsHelper.isIgnitionFallCampaign(telemetry));
    }

    @Test
    public void testGetVehicleMode_eco() {
        String mode = TripAnalyticsHelper.getVehicleMode(0);
        Assert.assertEquals("eco", mode);
    }

    @Test
    public void testGetVehicleMode_ride() {
        String mode = TripAnalyticsHelper.getVehicleMode(1);
        Assert.assertEquals("ride", mode);
    }

    @Test
    public void testGetVehicleMode_sport() {
        String mode = TripAnalyticsHelper.getVehicleMode(2);
        Assert.assertEquals("sport", mode);
    }

    @Test
    public void testGetVehicleMode_park() {
        String mode = TripAnalyticsHelper.getVehicleMode(3);
        Assert.assertEquals("park", mode);
    }

    @Test
    public void testGetVehicleMode_telltaleBlink() {
        String mode = TripAnalyticsHelper.getVehicleMode(4);
        Assert.assertEquals("telltale blink", mode);
    }

    @Test
    public void testGetVehicleMode_allSegmentOn() {
        String mode = TripAnalyticsHelper.getVehicleMode(8);
        Assert.assertEquals("all segment on", mode);
    }

    @Test
    public void testGetVehicleMode_allSegmentOff() {
        String mode = TripAnalyticsHelper.getVehicleMode(9);
        Assert.assertEquals("all segment off", mode);
    }

    @Test
    public void testGetVehicleMode_allBlink() {
        String mode = TripAnalyticsHelper.getVehicleMode(10);
        Assert.assertEquals("all blink", mode);
    }

    @Test
    public void testGetVehicleMode_safe() {
        String mode = TripAnalyticsHelper.getVehicleMode(12);
        Assert.assertEquals("safe", mode);
    }

    @Test
    public void testGetVehicleMode_boost() {
        String mode = TripAnalyticsHelper.getVehicleMode(13);
        Assert.assertEquals("boost", mode);
    }

    @Test
    public void testGetVehicleMode_na() {
        String mode = TripAnalyticsHelper.getVehicleMode(99);
        Assert.assertEquals("na", mode);
    }
}
