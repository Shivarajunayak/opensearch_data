package org.hmcl.cvp.dataplatform.tripanalytics.operator;

import org.apache.flink.api.common.state.MapState;
import org.apache.flink.api.common.typeinfo.BasicTypeInfo;
import org.apache.flink.api.java.functions.KeySelector;
import org.apache.flink.api.java.utils.ParameterTool;
import org.apache.flink.runtime.jobgraph.OperatorID;
import org.apache.flink.runtime.metrics.groups.InternalOperatorMetricGroup;
import org.apache.flink.runtime.metrics.util.InterceptingOperatorMetricGroup;
import org.apache.flink.runtime.metrics.util.InterceptingTaskMetricGroup;
import org.apache.flink.runtime.operators.testutils.MockEnvironment;
import org.apache.flink.runtime.operators.testutils.MockEnvironmentBuilder;
import org.apache.flink.runtime.testutils.MiniClusterResourceConfiguration;
import org.apache.flink.streaming.api.operators.KeyedProcessOperator;
import org.apache.flink.streaming.runtime.streamrecord.StreamRecord;
import org.apache.flink.streaming.util.KeyedOneInputStreamOperatorTestHarness;
import org.apache.flink.test.util.MiniClusterWithClientResource;
import org.hmcl.cvp.dataplatform.commons.catalogue.SignalCatalogue;
import org.hmcl.cvp.dataplatform.commons.constants.FlinkRuntime;
import org.hmcl.cvp.dataplatform.commons.exception.FlinkRuntimeException;
import org.hmcl.cvp.dataplatform.commons.testdata.CampaignDataGenerator;
import org.hmcl.cvp.dataplatform.commons.utils.DateUtils;
import org.hmcl.cvp.dataplatform.commons.utils.FlinkUtils;
import org.hmcl.cvp.dataplatform.commons.utils.TelemetryUtils;
import org.hmcl.cvp.dataplatform.contract.telemetry.Telemetry;
import org.hmcl.cvp.dataplatform.contract.telemetry.Tenant;
import org.hmcl.cvp.dataplatform.tripanalytics.contract.*;
import org.hmcl.cvp.dataplatform.tripanalytics.utils.TripData;
import org.junit.Assert;
import org.junit.ClassRule;
import org.junit.Test;

import java.time.Instant;
import java.util.*;

public class TripAnalyticsProcessFunctionTest {

    private static final Long FLINK_STATE_TTL_IN_HOURS = 15L;

    @ClassRule
    public static MiniClusterWithClientResource flinkCluster =
            new MiniClusterWithClientResource(
                    new MiniClusterResourceConfiguration.Builder()
                            .setNumberSlotsPerTaskManager(2)
                            .setNumberTaskManagers(1)
                            .build());

    private final InterceptingOperatorMetricGroup interceptingOperatorMetricGroup = new InterceptingOperatorMetricGroup();
    private final InterceptingTaskMetricGroup interceptingTaskMetricGroup = new InterceptingTaskMetricGroup() {
        @Override
        public InternalOperatorMetricGroup getOrAddOperator(OperatorID operatorID, String name) {
            return interceptingOperatorMetricGroup;
        }
    };

    private final MockEnvironment mockEnvironment = new MockEnvironmentBuilder().setMetricGroup(interceptingTaskMetricGroup).build();

    private final TripAnalyticsProcessFunction processFunction = new TripAnalyticsProcessFunction();

    private KeyedOneInputStreamOperatorTestHarness<String, Telemetry, TripWrapper> getTestHarness() throws Exception {
        ParameterTool parameterTool = ParameterTool.fromMap(new HashMap<>());
        parameterTool = FlinkUtils.addProperties(parameterTool, Map.of(FlinkRuntime.TripAnalytics.TRIP_TTL_IN_HOURS, "15"));
        parameterTool = FlinkUtils.addProperties(parameterTool, Map.of(FlinkRuntime.TripAnalytics.TRIP_START_ODOMETER_DIFF, "0.1"));
        parameterTool = FlinkUtils.addProperties(parameterTool, Map.of(FlinkRuntime.TripAnalytics.TRIP_BREAK_DIFF_IN_MIN, "3"));
        parameterTool = FlinkUtils.addProperties(parameterTool, Map.of(FlinkRuntime.TripAnalytics.END_TRIP_WAIT_TIMER_IN_MIN, "3"));
        mockEnvironment.getExecutionConfig().setGlobalJobParameters(parameterTool);

        return new KeyedOneInputStreamOperatorTestHarness<>(
                new KeyedProcessOperator<>(processFunction),
                (KeySelector<Telemetry, String>) TelemetryUtils::getVirtualId,
                BasicTypeInfo.STRING_TYPE_INFO, mockEnvironment
        );
    }

    private MapState<String, Set<TripWrapper>> getTripsState(KeyedOneInputStreamOperatorTestHarness<String, Telemetry, TripWrapper> testHarness) {
        return testHarness.getOperator()
                .getKeyedStateStore()
                .getMapState(StateDescriptors.getTripStateDescriptor(FLINK_STATE_TTL_IN_HOURS));
    }

    private List<TripWrapper> getTripsState(KeyedOneInputStreamOperatorTestHarness<String, Telemetry, TripWrapper> testHarness, String virtualId) throws Exception {
        MapState<String, Set<TripWrapper>> tripsState = getTripsState(testHarness);
        return tripsState.contains(virtualId) ? new ArrayList<>(tripsState.get(virtualId)) : new ArrayList<>();
    }

    private MapState<String, Set<TripJoiner>> getTripJoinerState(KeyedOneInputStreamOperatorTestHarness<String, Telemetry, TripWrapper> testHarness) {
        return testHarness.getOperator()
                .getKeyedStateStore()
                .getMapState(StateDescriptors.getTripJoinerDescriptor(FLINK_STATE_TTL_IN_HOURS));
    }

    private MapState<String, Set<Trip>> getProcessedTripsState(KeyedOneInputStreamOperatorTestHarness<String, Telemetry, TripWrapper> testHarness) {
        return testHarness.getOperator()
                .getKeyedStateStore()
                .getMapState(StateDescriptors.getProcessedTripsDescriptor(FLINK_STATE_TTL_IN_HOURS));
    }

    private List<TripJoiner> getTripJoinerState(KeyedOneInputStreamOperatorTestHarness<String, Telemetry, TripWrapper> testHarness, String virtualId) throws Exception {
        MapState<String, Set<TripJoiner>> tripJoinerState = getTripJoinerState(testHarness);
        return tripJoinerState.contains(virtualId) ? new ArrayList<>(tripJoinerState.get(virtualId)) : new ArrayList<>();
    }

    private Set<Trip> getProcessedTrips(KeyedOneInputStreamOperatorTestHarness<String, Telemetry, TripWrapper> testHarness, String virtualId) throws Exception {
        MapState<String, Set<Trip>> processedTrips = getProcessedTripsState(testHarness);
        return processedTrips.contains(virtualId) ? processedTrips.get(virtualId) : new HashSet<>();
    }

    @Test
    public void testTripAnalyticsProcessFunction_evTripStart() throws Exception {
        tripStart(getTestHarness(), Tenant.EV);
    }

    @Test
    public void testTripAnalyticsProcessFunction_iceTripStart() throws Exception {
        tripStart(getTestHarness(), Tenant.ICE);
    }

    @Test
    public void testTripAnalyticsProcessFunction_harleyTripStart() throws Exception {
        tripStart(getTestHarness(), Tenant.HARLEY);
    }

    private void tripStart(KeyedOneInputStreamOperatorTestHarness<String, Telemetry, TripWrapper> testHarness, Tenant tenant) {
        int countOfEachSignal = 1;
        try(testHarness) {

            testHarness.setup();
            testHarness.open();

            String virtualId = TripData.getVirtualId(tenant);
            String tripId = TripData.getTripId();
            Telemetry tripStartEvent = TripData.getTripStartFlag(virtualId, tenant, tripId, Instant.now(), countOfEachSignal, 1);
            testHarness.processElement(new StreamRecord<>(tripStartEvent, tripStartEvent.getCollectionEventTime()));

            List<TripWrapper> output = TripData.getCollectedData(testHarness.getRecordOutput());
            Assert.assertEquals(1, output.size()); // Trip start event

            List<TripWrapper> tripState = getTripsState(testHarness, virtualId);
            Assert.assertEquals(1, tripState.size());

            TripWrapper trip = tripState.get(0);
            Assert.assertTrue(trip.getIsTripStart());
            Assert.assertNotNull(trip.getTripStart());

        } catch (Exception e) {
            throw new FlinkRuntimeException(e);
        }
    }

    @Test
    public void testTripAnalyticsProcessFunction_evTripStartFollowedByAEvent() throws Exception {
        tripStartFollowedByAEvent(getTestHarness(), Tenant.EV);
    }

    @Test
    public void testTripAnalyticsProcessFunction_iceTripStartFollowedByAEvent() throws Exception {
        tripStartFollowedByAEvent(getTestHarness(), Tenant.ICE);
    }

    @Test
    public void testTripAnalyticsProcessFunction_harleyTripStartFollowedByAEvent() throws Exception {
        tripStartFollowedByAEvent(getTestHarness(), Tenant.HARLEY);
    }

    private void tripStartFollowedByAEvent(KeyedOneInputStreamOperatorTestHarness<String, Telemetry, TripWrapper> testHarness, Tenant tenant) {
        int countOfEachSignal = 1;
        try(testHarness) {

            testHarness.setup();
            testHarness.open();

            String virtualId = TripData.getVirtualId(tenant);
            String tripId = TripData.getTripId();
            Instant tripStartTime = Instant.now().minusSeconds(60);
            Telemetry tripStartEvent = TripData.getTripStartFlag(virtualId, tenant, tripId, tripStartTime, countOfEachSignal, 1);
            testHarness.processElement(new StreamRecord<>(tripStartEvent, tripStartEvent.getCollectionEventTime()));

            Telemetry event = CampaignDataGenerator.getTelemetry(virtualId, tenant, tripStartTime.plusSeconds(10), countOfEachSignal);
            event.setCampaignName(TripData.IGNITION_RISE);
            testHarness.processElement(new StreamRecord<>(event, event.getCollectionEventTime()));


            List<TripWrapper> output = TripData.getCollectedData(testHarness.getRecordOutput());
            // One for trip start and one for trip event
            Assert.assertEquals(2, output.size());

            long countOfTripStarts = output.stream().filter(TripWrapper::getIsTripStart).count();
            Assert.assertEquals(1, countOfTripStarts);

            long countOfTripEvents = output.stream().filter(TripWrapper::isNeededForTripBreak).count();
            Assert.assertEquals(1, countOfTripEvents);

            List<TripJoiner> tripJoiners = getTripJoinerState(testHarness, virtualId);
            Assert.assertEquals(0, tripJoiners.size());

        } catch (Exception e) {
            throw new FlinkRuntimeException(e);
        }
    }

    @Test
    public void testTripAnalyticsProcessFunction_evTripEnd() throws Exception {
        tripEnd(getTestHarness(), Tenant.EV);
    }

    @Test
    public void testTripAnalyticsProcessFunction_iceTripEnd() throws Exception {
        tripEnd(getTestHarness(), Tenant.ICE);
    }

    @Test
    public void testTripAnalyticsProcessFunction_harleyTripEnd() throws Exception {
        tripEnd(getTestHarness(), Tenant.HARLEY);
    }

    private void tripEnd(KeyedOneInputStreamOperatorTestHarness<String, Telemetry, TripWrapper> testHarness, Tenant tenant) {
        int countOfEachSignal = 1;
        try(testHarness) {

            testHarness.setup();
            testHarness.open();

            String virtualId = TripData.getVirtualId(tenant);
            String tripId = TripData.getTripId();

            Instant tripStartTime = Instant.now().minusSeconds(60);
            Telemetry tripStartEvent = TripData.getTripStartFlag(virtualId, tenant, tripId, tripStartTime, countOfEachSignal, 1);
            testHarness.processElement(new StreamRecord<>(tripStartEvent, tripStartEvent.getCollectionEventTime()));

            Instant tripEndTime =  Instant.now();
            testHarness.processWatermark(tripEndTime.toEpochMilli());
            testHarness.setProcessingTime(tripEndTime.toEpochMilli());
            Telemetry tripEnd = TripData.getTripEndFlag(virtualId, tenant, tripId, tripEndTime, countOfEachSignal, 1);
            testHarness.processElement(new StreamRecord<>(tripEnd, tripEnd.getCollectionEventTime()));

            long forwardTimeFiveMin = Instant.now().plusSeconds(5 * 60).toEpochMilli();
            testHarness.processWatermark(forwardTimeFiveMin);
            testHarness.setProcessingTime(forwardTimeFiveMin);

            List<TripWrapper> output = TripData.getCollectedData(testHarness.getRecordOutput());
            // One for trip start and one for trip end
            Assert.assertEquals(2, output.size());

            long countOfTripStarts = output.stream().filter(TripWrapper::getIsTripStart).count();
            Assert.assertEquals(1, countOfTripStarts);

            long countOfTripEnds = output.stream().filter(TripWrapper::getIsTripEnd).count();
            Assert.assertEquals(1, countOfTripEnds);


        } catch (Exception e) {
            throw new FlinkRuntimeException(e);
        }
    }

    @Test
    public void testTripAnalyticsProcessFunction_evTripEndFollowedByTripStart() throws Exception {
        tripEndFollowedByTripStart(getTestHarness(), Tenant.EV);
    }

    @Test
    public void testTripAnalyticsProcessFunction_iceTripEndFollowedByTripStart() throws Exception {
        tripEndFollowedByTripStart(getTestHarness(), Tenant.ICE);
    }

    @Test
    public void testTripAnalyticsProcessFunction_harleyTripEndFollowedByTripStart() throws Exception {
        tripEndFollowedByTripStart(getTestHarness(), Tenant.HARLEY);
    }

    private void tripEndFollowedByTripStart(KeyedOneInputStreamOperatorTestHarness<String, Telemetry, TripWrapper> testHarness, Tenant tenant) {
        int countOfEachSignal = 1;
        try(testHarness) {

            testHarness.setup();
            testHarness.open();

            String virtualId = TripData.getVirtualId(tenant);
            String tripId = TripData.getTripId();
            Instant tripStartTime = Instant.now().minusSeconds(10 * 60);
            Telemetry tripStartEvent = TripData.getTripStartFlag(virtualId, tenant, tripId, tripStartTime, countOfEachSignal, 1);
            testHarness.processElement(new StreamRecord<>(tripStartEvent, tripStartEvent.getCollectionEventTime()));

            Instant tripEndTime = Instant.now().minusSeconds(9 * 60);
            Telemetry tripEnd = TripData.getTripEndFlag(virtualId, tenant, tripId, tripEndTime, countOfEachSignal, 1);
            testHarness.processElement(new StreamRecord<>(tripEnd, tripEnd.getCollectionEventTime()));

            String newTripId = TripData.getNextTripId(tripId);
            Instant newTripStartTime = Instant.now().minusSeconds(8 * 60);
            Telemetry tripStartAgain = TripData.getTripStartFlag(virtualId, tenant, newTripId, newTripStartTime, countOfEachSignal, 1);
            testHarness.processElement(new StreamRecord<>(tripStartAgain, tripStartAgain.getCollectionEventTime()));

            // Testing - After 30 seconds of trip break, we receive trip start for same trip again
            Instant newTripStartTime1 = newTripStartTime.plusSeconds(30);
            Telemetry tripStartAgain1 = TripData.getTripStartFlag(virtualId, tenant, newTripId, newTripStartTime1, countOfEachSignal, 1);
            testHarness.processElement(new StreamRecord<>(tripStartAgain1, tripStartAgain1.getCollectionEventTime()));

            Instant newTripEndTime = Instant.now().minusSeconds(7 * 60);
            Telemetry newTripEnd = TripData.getTripEndFlag(virtualId, tenant, newTripId, newTripEndTime, countOfEachSignal, 1);
            testHarness.processElement(new StreamRecord<>(newTripEnd, newTripEnd.getCollectionEventTime()));

            String anotherNewTripId = TripData.getNextTripId(newTripId);
            Instant anotherNewTripStartTime = Instant.now().minusSeconds(6 * 60);
            Telemetry anotherTripStartAgain = TripData.getTripStartFlag(virtualId, tenant, anotherNewTripId, anotherNewTripStartTime, countOfEachSignal, 1);
            testHarness.processElement(new StreamRecord<>(anotherTripStartAgain, anotherTripStartAgain.getCollectionEventTime()));

            List<TripWrapper> output = TripData.getCollectedData(testHarness.getRecordOutput());
            // One for trip start and one for trip end
            Assert.assertEquals(3, output.size());

            long countOfTripStarts = output.stream().filter(TripWrapper::getIsTripStart).count();
            Assert.assertEquals(1, countOfTripStarts);

            long countOfTripBreaks = output.stream().filter(TripWrapper::getIsTripBreak).count();
            Assert.assertEquals(2, countOfTripBreaks);

            List<TripJoiner> tripJoiners = getTripJoinerState(testHarness, virtualId);
            Assert.assertEquals(2, tripJoiners.size());

            tripJoiners.forEach(tj -> {
                String tripJoinerId = tj.getTripJoinerId();
                Assert.assertTrue(tj.getIsTripJoined());
                Assert.assertEquals(tripId, tripJoinerId);
                Assert.assertNotEquals(tripJoinerId, tj.getTripBreakId());
            });

        } catch (Exception e) {
            throw new FlinkRuntimeException(e);
        }
    }

    @Test
    public void tripEndFollowedImmediatelyByNewTripStartAndEnd_ev() throws Exception {
        tripEndFollowedImmediatelyByNewTripStartAndEnd(getTestHarness(), Tenant.EV);
    }

    @Test
    public void tripEndFollowedImmediatelyByNewTripStartAndEnd_ice() throws Exception {
        tripEndFollowedImmediatelyByNewTripStartAndEnd(getTestHarness(), Tenant.ICE);
    }

    @Test
    public void tripEndFollowedImmediatelyByNewTripStartAndEnd_harley() throws Exception {
        tripEndFollowedImmediatelyByNewTripStartAndEnd(getTestHarness(), Tenant.HARLEY);
    }

    private void tripEndFollowedImmediatelyByNewTripStartAndEnd(KeyedOneInputStreamOperatorTestHarness<String, Telemetry, TripWrapper> testHarness, Tenant tenant) {
        int countOfEachSignal = 1;
        try(testHarness) {

            testHarness.setup();
            testHarness.open();

            String virtualId = TripData.getVirtualId(tenant);
            String tripId = TripData.getTripId();
            Instant tripStartTime = Instant.now().minusSeconds(10 * 60);
            Telemetry tripStartEvent = TripData.getTripStartFlag(virtualId, tenant, tripId, tripStartTime, countOfEachSignal, 1);
            testHarness.processElement(new StreamRecord<>(tripStartEvent, tripStartEvent.getCollectionEventTime()));

            Instant tripEndTime = Instant.now().minusSeconds(9 * 60);
            Telemetry tripEnd = TripData.getTripEndFlag(virtualId, tenant, tripId, tripEndTime, countOfEachSignal, 1);
            testHarness.processElement(new StreamRecord<>(tripEnd, tripEnd.getCollectionEventTime()));

            String newTripId = TripData.getNextTripId(tripId);
            Instant newTripStartTime = Instant.now().minusSeconds(8 * 60);
            Telemetry tripStartAgain = TripData.getTripStartFlag(virtualId, tenant, newTripId, newTripStartTime, countOfEachSignal, 1);
            testHarness.processElement(new StreamRecord<>(tripStartAgain, tripStartAgain.getCollectionEventTime()));

            Instant newTripEndTime = Instant.now().minusSeconds(5 * 60);
            Telemetry newTripEnd = TripData.getTripEndFlag(virtualId, tenant, newTripId, newTripEndTime, countOfEachSignal, 1);
            testHarness.processElement(new StreamRecord<>(newTripEnd, newTripEnd.getCollectionEventTime()));

            long currentTime = Instant.now().toEpochMilli();
            testHarness.processWatermark(currentTime);
            testHarness.setProcessingTime(currentTime);

            List<TripWrapper> output = TripData.getCollectedData(testHarness.getRecordOutput());
            // One for trip start, one for trip break and one for trip end
            Assert.assertEquals(3, output.size());

            long countOfTripStarts = output.stream().filter(TripWrapper::getIsTripStart).count();
            Assert.assertEquals(1, countOfTripStarts);

            long countOfTripBreaks = output.stream().filter(TripWrapper::getIsTripBreak).count();
            Assert.assertEquals(1, countOfTripBreaks);

            long countOfTripEnds = output.stream().filter(TripWrapper::getIsTripEnd).count();
            Assert.assertEquals(1, countOfTripEnds);

            // Since the trip ended, all related cache should be cleared.
            List<TripJoiner> tripJoiners = getTripJoinerState(testHarness, virtualId);
            Assert.assertEquals(0, tripJoiners.size());

            List<TripWrapper> tripsInCache = getTripsState(testHarness, virtualId);
            Assert.assertEquals(0, tripsInCache.size());

            Optional<TripWrapper> tripBreakWrapper = output.stream().filter(TripWrapper::getIsTripBreak).findFirst();
            Assert.assertTrue(tripBreakWrapper.isPresent());
            TripBreak tripBreak = tripBreakWrapper.get().getTripBreak();
            Assert.assertEquals(newTripId, tripBreak.getTripBreakId());
            Assert.assertEquals(tripId, tripBreak.getTripId());
            Assert.assertEquals(DateUtils.formatToISO(tripEndTime.toEpochMilli()), tripBreak.getStartTimestamp());
            Assert.assertEquals(DateUtils.formatToISO(newTripStartTime.toEpochMilli()), tripBreak.getEndTimestamp());

        } catch (Exception e) {
            throw new FlinkRuntimeException(e);
        }
    }


    @Test
    public void testTripAnalyticsProcessFunction_evMultipleTripStartSignals() throws Exception {
        multipleTripStartSignals(getTestHarness(), Tenant.EV);
    }

    @Test
    public void testTripAnalyticsProcessFunction_iceMultipleTripStartSignals() throws Exception {
        multipleTripStartSignals(getTestHarness(), Tenant.ICE);
    }

    @Test
    public void testTripAnalyticsProcessFunction_harleyMultipleTripStartSignals() throws Exception {
        multipleTripStartSignals(getTestHarness(), Tenant.HARLEY);
    }

    private void multipleTripStartSignals(KeyedOneInputStreamOperatorTestHarness<String, Telemetry, TripWrapper> testHarness, Tenant tenant) {
        int countOfEachSignal = 1;
        try (testHarness) {

            testHarness.setup();
            testHarness.open();

            String virtualId = TripData.getVirtualId(tenant);

            String tripId = TripData.getTripId();
            String anotherTripId = TripData.getNextTripId(tripId);

            Instant tripStartTime = Instant.now().minusSeconds(10 * 60);
            Instant anotherTripStartTime = tripStartTime.plusSeconds(10);

            Telemetry tripStartEvent = TripData.getTripStartFlag(virtualId, tenant, tripId, tripStartTime, countOfEachSignal, 1);
            TripData.addSignal(tripStartEvent, SignalCatalogue.getTripStartFlag(), TripData.getTripStartSignal(anotherTripId, anotherTripStartTime, 1));

            testHarness.processElement(new StreamRecord<>(tripStartEvent, tripStartEvent.getCollectionEventTime()));

            List<TripWrapper> output = TripData.getCollectedData(testHarness.getRecordOutput());
            // One for trip start per signal
            Assert.assertEquals(2, output.size());

            long countOfTripStarts = output.stream().filter(TripWrapper::getIsTripStart).count();
            Assert.assertEquals(2, countOfTripStarts);

            Set<Trip> processedTrips = getProcessedTrips(testHarness, virtualId);
            Assert.assertEquals(2, processedTrips.size());

            long firstTripStart = processedTrips.stream()
                    .filter(t -> t.getTripId().equals(tripId) && t.getIsStart())
                    .count();
            Assert.assertEquals(1, firstTripStart);

            long secondTrip = processedTrips.stream()
                    .filter(t -> t.getTripId().equals(tripId) && t.getIsStart())
                    .count();
            Assert.assertEquals(1, secondTrip);

        } catch (Exception e) {
            throw new FlinkRuntimeException(e);
        }
    }

    @Test
    public void testTripAnalyticsProcessFunction_evMultipleTripEndSignals() throws Exception {
        multipleTripEndSignals(getTestHarness(), Tenant.EV);
    }

    @Test
    public void testTripAnalyticsProcessFunction_iceMultipleTripEndSignals() throws Exception {
        multipleTripEndSignals(getTestHarness(), Tenant.ICE);
    }

    @Test
    public void testTripAnalyticsProcessFunction_harleyMultipleTripEndSignals() throws Exception {
        multipleTripEndSignals(getTestHarness(), Tenant.HARLEY);
    }

    private void multipleTripEndSignals(KeyedOneInputStreamOperatorTestHarness<String, Telemetry, TripWrapper> testHarness, Tenant tenant) {
        int countOfEachSignal = 1;
        try (testHarness) {

            testHarness.setup();
            testHarness.open();

            String virtualId = TripData.getVirtualId(tenant);

            String tripId = TripData.getTripId();
            String anotherTripId = TripData.getNextTripId(tripId);

            Instant tripStartTime = Instant.now().minusSeconds(10 * 60);
            Instant anotherTripStartTime = tripStartTime.plusSeconds(10);

            Instant tripEndTime = tripStartTime.plusSeconds(5 * 60);
            Instant anotherTripEndTime = anotherTripStartTime.plusSeconds(60);

            Telemetry tripStartEndEvent = TripData.getTripStartFlag(virtualId, tenant, tripId, tripStartTime, countOfEachSignal, 1);
            TripData.addSignal(tripStartEndEvent, SignalCatalogue.getTripStartFlag(), TripData.getTripStartSignal(anotherTripId, anotherTripStartTime, 1));

            TripData.addSignal(tripStartEndEvent, SignalCatalogue.getTripEndFlag(), TripData.getTripEndSignal(tripId, tripEndTime, 1));
            TripData.addSignal(tripStartEndEvent, SignalCatalogue.getTripEndFlag(), TripData.getTripEndSignal(anotherTripId, anotherTripEndTime, 1));

            testHarness.processElement(new StreamRecord<>(tripStartEndEvent, tripStartEndEvent.getCollectionEventTime()));

            long currentTime = Instant.now().toEpochMilli();
            testHarness.processWatermark(currentTime);
            testHarness.setProcessingTime(currentTime);

            List<TripWrapper> output = TripData.getCollectedData(testHarness.getRecordOutput());
            // One for trip start per signal
            Assert.assertEquals(4, output.size());

            long countOfTripStarts = output.stream().filter(TripWrapper::getIsTripStart).count();
            Assert.assertEquals(2, countOfTripStarts);

            long countOfTripEnds = output.stream().filter(TripWrapper::getIsTripEnd).count();
            Assert.assertEquals(2, countOfTripEnds);

            Set<Trip> processedTrips = getProcessedTrips(testHarness, virtualId);
            Assert.assertEquals(4, processedTrips.size());

            long firstTripStart = processedTrips.stream()
                    .filter(t -> t.getTripId().equals(tripId) && t.getIsStart())
                    .count();
            Assert.assertEquals(1, firstTripStart);

            long secondTripStart = processedTrips.stream()
                    .filter(t -> t.getTripId().equals(tripId) && t.getIsStart())
                    .count();
            Assert.assertEquals(1, secondTripStart);

            long firstTripEnd = processedTrips.stream()
                    .filter(t -> t.getTripId().equals(tripId) && t.getIsEnd())
                    .count();
            Assert.assertEquals(1, firstTripEnd);

            long secondTripEnd = processedTrips.stream()
                    .filter(t -> t.getTripId().equals(tripId) && t.getIsEnd())
                    .count();
            Assert.assertEquals(1, secondTripEnd);

        } catch (Exception e) {
            throw new FlinkRuntimeException(e);
        }
    }

    @Test
    public void testTripAnalyticsProcessFunction_evTripStartFollowedByTripStart() throws Exception {
        tripStartFollowedByTripStart(getTestHarness(), Tenant.EV);
    }

    @Test
    public void testTripAnalyticsProcessFunction_iceTripStartFollowedByTripStart() throws Exception {
        tripStartFollowedByTripStart(getTestHarness(), Tenant.ICE);
    }

    @Test
    public void testTripAnalyticsProcessFunction_harleyTripStartFollowedByTripStart() throws Exception {
        tripStartFollowedByTripStart(getTestHarness(), Tenant.HARLEY);
    }


    private void tripStartFollowedByTripStart(KeyedOneInputStreamOperatorTestHarness<String, Telemetry, TripWrapper> testHarness, Tenant tenant) {
        int countOfEachSignal = 1;
        try (testHarness) {

            testHarness.setup();
            testHarness.open();

            String virtualId = TripData.getVirtualId(tenant);

            String tripId = TripData.getTripId();
            String anotherTripId = TripData.getNextTripId(tripId);

            Instant tripStartTime = Instant.now().minusSeconds(10 * 60);
            Instant tripEndTime = tripStartTime.plusSeconds(5 * 60);

            Instant anotherTripStartTime = tripEndTime.plusSeconds(60);
            Instant anotherTripEndTime = anotherTripStartTime.plusSeconds(60);

            Telemetry tripStartEvent1 = TripData.getTripStartFlag(virtualId, tenant, tripId, tripStartTime, countOfEachSignal, 1);
            Telemetry tripEndEvent1 = TripData.getTripEndFlag(virtualId, tenant, tripId, tripEndTime, countOfEachSignal, 1);

            Telemetry tripStartEvent2 = TripData.getTripStartFlag(virtualId, tenant, anotherTripId, anotherTripStartTime, countOfEachSignal, 1);
            Telemetry tripEndEvent2 = TripData.getTripEndFlag(virtualId, tenant, anotherTripId, anotherTripEndTime, countOfEachSignal, 1);

            testHarness.processElement(new StreamRecord<>(tripStartEvent1, tripStartEvent1.getCollectionEventTime()));
            testHarness.processElement(new StreamRecord<>(tripEndEvent1, tripEndEvent1.getCollectionEventTime()));
            testHarness.processElement(new StreamRecord<>(tripStartEvent2, tripStartEvent2.getCollectionEventTime()));
            testHarness.processElement(new StreamRecord<>(tripEndEvent2, tripEndEvent2.getCollectionEventTime()));

            long currentTime = Instant.now().toEpochMilli();
            testHarness.processWatermark(currentTime);
            testHarness.setProcessingTime(currentTime);

            List<TripWrapper> output = TripData.getCollectedData(testHarness.getRecordOutput());
            // One for trip start per signal
            Assert.assertEquals(3, output.size());

            long countOfTripStarts = output.stream().filter(TripWrapper::getIsTripStart).count();
            Assert.assertEquals(1, countOfTripStarts);

            long countOfTripEnds = output.stream().filter(TripWrapper::getIsTripEnd).count();
            Assert.assertEquals(1, countOfTripEnds);

            Set<Trip> processedTrips = getProcessedTrips(testHarness, virtualId);
            Assert.assertEquals(4, processedTrips.size());

            long firstTripStart = processedTrips.stream()
                    .filter(t -> t.getTripId().equals(tripId) && t.getIsStart())
                    .count();
            Assert.assertEquals(1, firstTripStart);

            long secondTripStart = processedTrips.stream()
                    .filter(t -> t.getTripId().equals(tripId) && t.getIsStart())
                    .count();
            Assert.assertEquals(1, secondTripStart);

            long firstTripEnd = processedTrips.stream()
                    .filter(t -> t.getTripId().equals(tripId) && t.getIsEnd())
                    .count();
            Assert.assertEquals(1, firstTripEnd);

            long secondTripEnd = processedTrips.stream()
                    .filter(t -> t.getTripId().equals(tripId) && t.getIsEnd())
                    .count();
            Assert.assertEquals(1, secondTripEnd);

        } catch (Exception e) {
            throw new FlinkRuntimeException(e);
        }
    }

    @Test
    public void testTripAnalyticsProcessFunction_evMultipleJumbledTripsSignals() throws Exception {
        multipleJumbledTripsSignals(getTestHarness(), Tenant.EV);
    }

    @Test
    public void testTripAnalyticsProcessFunction_iceMultipleJumbledTripsSignals() throws Exception {
        multipleJumbledTripsSignals(getTestHarness(), Tenant.ICE);
    }

    @Test
    public void testTripAnalyticsProcessFunction_harleyMultipleJumbledTripsSignals() throws Exception {
        multipleJumbledTripsSignals(getTestHarness(), Tenant.HARLEY);
    }

    private void multipleJumbledTripsSignals(KeyedOneInputStreamOperatorTestHarness<String, Telemetry, TripWrapper> testHarness, Tenant tenant) {
        int countOfEachSignal = 1;
        try (testHarness) {

            testHarness.setup();
            testHarness.open();

            String virtualId = TripData.getVirtualId(tenant);

            String tripId = TripData.getTripId();
            String anotherTripId = TripData.getNextTripId(tripId);

            Instant tripStartTime = Instant.now().minusSeconds(10 * 60);
            Instant anotherTripStartTime = tripStartTime.plusSeconds(10);

            Instant tripEndTime = tripStartTime.plusSeconds(5 * 60);
            Instant anotherTripEndTime = anotherTripStartTime.plusSeconds(60);

            Instant orphanTripEndTime = tripEndTime.plusSeconds(60);
            String orphanTripId = TripData.getNextTripId(anotherTripId);

            Telemetry tripStartEndEvent = TripData.getTripStartFlag(virtualId, tenant, anotherTripId, anotherTripStartTime, countOfEachSignal, 1);
            TripData.addSignal(tripStartEndEvent, SignalCatalogue.getTripStartFlag(), TripData.getTripStartSignal(tripId, tripStartTime, 1));

            // Infer trip start from this end signal
            TripData.addSignal(tripStartEndEvent, SignalCatalogue.getTripEndFlag(), TripData.getTripEndSignal(orphanTripId, orphanTripEndTime, 1));

            TripData.addSignal(tripStartEndEvent, SignalCatalogue.getTripEndFlag(), TripData.getTripEndSignal(anotherTripId, anotherTripEndTime, 1));
            TripData.addSignal(tripStartEndEvent, SignalCatalogue.getTripEndFlag(), TripData.getTripEndSignal(tripId, tripEndTime, 1));

            testHarness.processElement(new StreamRecord<>(tripStartEndEvent, tripStartEndEvent.getCollectionEventTime()));

            long currentTime = Instant.now().toEpochMilli();
            testHarness.processWatermark(currentTime);
            testHarness.setProcessingTime(currentTime);

            List<TripWrapper> output = TripData.getCollectedData(testHarness.getRecordOutput());
            // One for trip start per signal
            Assert.assertEquals(6, output.size());

            long countOfTripStarts = output.stream().filter(TripWrapper::getIsTripStart).count();
            Assert.assertEquals(3, countOfTripStarts);

            long countOfTripEnds = output.stream().filter(TripWrapper::getIsTripEnd).count();
            Assert.assertEquals(3, countOfTripEnds);

            Set<Trip> processedTrips = getProcessedTrips(testHarness, virtualId);
            Assert.assertEquals(6, processedTrips.size());

            long firstTripStart = processedTrips.stream()
                    .filter(t -> t.getTripId().equals(tripId) && t.getIsStart())
                    .count();
            Assert.assertEquals(1, firstTripStart);

            long secondTripStart = processedTrips.stream()
                    .filter(t -> t.getTripId().equals(tripId) && t.getIsStart())
                    .count();
            Assert.assertEquals(1, secondTripStart);

            long firstTripEnd = processedTrips.stream()
                    .filter(t -> t.getTripId().equals(tripId) && t.getIsEnd())
                    .count();
            Assert.assertEquals(1, firstTripEnd);

            long secondTripEnd = processedTrips.stream()
                    .filter(t -> t.getTripId().equals(tripId) && t.getIsEnd())
                    .count();
            Assert.assertEquals(1, secondTripEnd);

            long inferredTripStart = processedTrips.stream()
                    .filter(t -> t.getTripId().equals(orphanTripId) && t.getIsStart())
                    .count();
            Assert.assertEquals(1, inferredTripStart);

            long orphanTripEnd = processedTrips.stream()
                    .filter(t -> t.getTripId().equals(orphanTripId) && t.getIsEnd())
                    .count();
            Assert.assertEquals(1, orphanTripEnd);

        } catch (Exception e) {
            throw new FlinkRuntimeException(e);
        }
    }

    @Test
    public void testTripAnalyticsProcessFunction_evOnlyTripEndReceived() throws Exception {
        onlyTripEndReceived(getTestHarness(), Tenant.EV);
    }

    @Test
    public void testTripAnalyticsProcessFunction_iceOnlyTripEndReceived() throws Exception {
        onlyTripEndReceived(getTestHarness(), Tenant.ICE);
    }

    @Test
    public void testTripAnalyticsProcessFunction_harleyOnlyTripEndReceived() throws Exception {
        onlyTripEndReceived(getTestHarness(), Tenant.HARLEY);
    }

    private void onlyTripEndReceived(KeyedOneInputStreamOperatorTestHarness<String, Telemetry, TripWrapper> testHarness, Tenant tenant) {
        int countOfEachSignal = 1;
        try (testHarness) {

            testHarness.setup();
            testHarness.open();

            String virtualId = TripData.getVirtualId(tenant);

            String tripId = TripData.getTripId();
            Instant tripTime = Instant.now().minusSeconds(10 * 60);

            Telemetry tripEndEvent = TripData.getTripEndFlag(virtualId, tenant, tripId, tripTime, countOfEachSignal, 1);
            testHarness.processElement(new StreamRecord<>(tripEndEvent, tripEndEvent.getCollectionEventTime()));

            long currentTime = Instant.now().toEpochMilli();
            testHarness.processWatermark(currentTime);
            testHarness.setProcessingTime(currentTime);

            List<TripWrapper> output = TripData.getCollectedData(testHarness.getRecordOutput());
            // One for inferred trip start and one for trip end
            Assert.assertEquals(2, output.size());

            long countOfTripStarts = output.stream().filter(TripWrapper::getIsTripStart).count();
            Assert.assertEquals(1, countOfTripStarts);

            long countOfTripEnds = output.stream().filter(TripWrapper::getIsTripEnd).count();
            Assert.assertEquals(1, countOfTripEnds);

            Set<Trip> processedTrips = getProcessedTrips(testHarness, virtualId);
            Assert.assertEquals(2, processedTrips.size());

            long firstTripStart = processedTrips.stream()
                    .filter(t -> t.getTripId().equals(tripId) && t.getIsStart())
                    .count();
            Assert.assertEquals(1, firstTripStart);

            long secondTripStart = processedTrips.stream()
                    .filter(t -> t.getTripId().equals(tripId) && t.getIsStart())
                    .count();
            Assert.assertEquals(1, secondTripStart);

            List<TripWrapper> tripState = getTripsState(testHarness, virtualId);
            // State should be cleared since trip completed
            Assert.assertEquals(0, tripState.size());

        } catch (Exception e) {
            throw new FlinkRuntimeException(e);
        }
    }

    @Test
    public void testTripAnalyticsProcessFunction_evTripEndFollowedByTripStartForSameTripId() throws Exception {
        tripEndFollowedByTripStartForSameTripId(getTestHarness(), Tenant.EV);
    }

    @Test
    public void testTripAnalyticsProcessFunction_iceTripEndFollowedByTripStartForSameTripId() throws Exception {
        tripEndFollowedByTripStartForSameTripId(getTestHarness(), Tenant.ICE);
    }

    @Test
    public void testTripAnalyticsProcessFunction_harleyTripEndFollowedByTripStartForSameTripId() throws Exception {
        tripEndFollowedByTripStartForSameTripId(getTestHarness(), Tenant.HARLEY);
    }

    private void tripEndFollowedByTripStartForSameTripId(KeyedOneInputStreamOperatorTestHarness<String, Telemetry, TripWrapper> testHarness, Tenant tenant) {
        int countOfEachSignal = 1;
        try (testHarness) {

            testHarness.setup();
            testHarness.open();

            String virtualId = TripData.getVirtualId(tenant);

            String tripId = TripData.getTripId();
            Instant tripStartTime = Instant.now().minusSeconds(5 * 60);
            Instant tripEndTime = Instant.now().minusSeconds(10 * 60);

            Telemetry tripEndEvent = TripData.getTripEndFlag(virtualId, tenant, tripId, tripEndTime, countOfEachSignal, 1);
            testHarness.processElement(new StreamRecord<>(tripEndEvent, tripEndEvent.getCollectionEventTime()));

            Telemetry tripStartEvent = TripData.getTripStartFlag(virtualId, tenant, tripId, tripStartTime, countOfEachSignal, 1);
            testHarness.processElement(new StreamRecord<>(tripStartEvent, tripStartEvent.getCollectionEventTime()));

            long currentTime = Instant.now().toEpochMilli();
            testHarness.processWatermark(currentTime);
            testHarness.setProcessingTime(currentTime);

            List<TripWrapper> output = TripData.getCollectedData(testHarness.getRecordOutput());
            // One for inferred trip start and one for trip end
            Assert.assertEquals(2, output.size());

            long countOfTripStarts = output.stream().filter(TripWrapper::getIsTripStart).count();
            Assert.assertEquals(1, countOfTripStarts);

            Optional<TripWrapper> tripStart = output.stream().filter(TripWrapper::getIsTripStart).findFirst();
            Assert.assertTrue(tripStart.isPresent());
            Assert.assertEquals(TripStartSource.TRIP_END_SIGNAL.getValue(), tripStart.get().getTripStart().getTripSource());

            long countOfTripEnds = output.stream().filter(TripWrapper::getIsTripEnd).count();
            Assert.assertEquals(1, countOfTripEnds);

            Set<Trip> processedTrips = getProcessedTrips(testHarness, virtualId);
            Assert.assertEquals(2, processedTrips.size());

            long firstTripStart = processedTrips.stream()
                    .filter(t -> t.getTripId().equals(tripId) && t.getIsStart())
                    .count();
            Assert.assertEquals(1, firstTripStart);

            long firstTripEnd = processedTrips.stream()
                    .filter(t -> t.getTripId().equals(tripId) && t.getIsEnd())
                    .count();
            Assert.assertEquals(1, firstTripEnd);

            List<TripWrapper> tripState = getTripsState(testHarness, virtualId);
            // State should be cleared since trip completed
            Assert.assertEquals(0, tripState.size());

        } catch (Exception e) {
            throw new FlinkRuntimeException(e);
        }
    }

    @Test
    public void testTripAnalyticsProcessFunction_evTripEndFollowedByTripStartForADifferentTripId() throws Exception {
        tripEndFollowedByTripStartForADifferentTripId(getTestHarness(), Tenant.EV);
    }

    @Test
    public void testTripAnalyticsProcessFunction_iceTripEndFollowedByTripStartForADifferentTripId() throws Exception {
        tripEndFollowedByTripStartForADifferentTripId(getTestHarness(), Tenant.ICE);
    }

    @Test
    public void testTripAnalyticsProcessFunction_harleyTripEndFollowedByTripStartForADifferentTripId() throws Exception {
        tripEndFollowedByTripStartForADifferentTripId(getTestHarness(), Tenant.HARLEY);
    }

    private void tripEndFollowedByTripStartForADifferentTripId(KeyedOneInputStreamOperatorTestHarness<String, Telemetry, TripWrapper> testHarness, Tenant tenant) {
        int countOfEachSignal = 1;
        try (testHarness) {

            testHarness.setup();
            testHarness.open();

            String virtualId = TripData.getVirtualId(tenant);

            String tripId = TripData.getTripId();
            Instant tripEndTime = Instant.now().minusSeconds(10 * 60);

            // New trip started 2 minutes after the first trip
            String newTripId = TripData.getNextTripId(tripId);
            Instant newTripStartTime = tripEndTime.plusSeconds(2 * 60);
            Instant newTripEndTime = newTripStartTime.plusSeconds(4 * 60);

            Telemetry tripEndEvent = TripData.getTripEndFlag(virtualId, tenant, tripId, tripEndTime, countOfEachSignal, 1);
            testHarness.processElement(new StreamRecord<>(tripEndEvent, tripEndEvent.getCollectionEventTime()));

            Telemetry newStartEvent = TripData.getTripStartFlag(virtualId, tenant, newTripId, newTripStartTime, countOfEachSignal, 1);
            testHarness.processElement(new StreamRecord<>(newStartEvent, newStartEvent.getCollectionEventTime()));

            Telemetry newTripEndEvent = TripData.getTripEndFlag(virtualId, tenant, newTripId, newTripEndTime, countOfEachSignal, 1);
            testHarness.processElement(new StreamRecord<>(newTripEndEvent, newTripEndEvent.getCollectionEventTime()));

            long currentTime = Instant.now().toEpochMilli();
            testHarness.processWatermark(currentTime);
            testHarness.setProcessingTime(currentTime);

            List<TripWrapper> output = TripData.getCollectedData(testHarness.getRecordOutput());
            // One for inferred trip start, one for trip break and another for trip end
            Assert.assertEquals(3, output.size());

            long countOfTripStarts = output.stream().filter(TripWrapper::getIsTripStart).count();
            Assert.assertEquals(1, countOfTripStarts);

            Optional<TripWrapper> tripStart = output.stream().filter(TripWrapper::getIsTripStart).findFirst();
            Assert.assertTrue(tripStart.isPresent());
            Assert.assertEquals(TripStartSource.TRIP_END_SIGNAL.getValue(), tripStart.get().getTripStart().getTripSource());

            long countOfTripBreaks = output.stream().filter(TripWrapper::getIsTripBreak).count();
            Assert.assertEquals(1, countOfTripBreaks);

            Optional<TripWrapper> tripBreak = output.stream().filter(TripWrapper::getIsTripBreak).findFirst();
            Assert.assertTrue(tripBreak.isPresent());
            Assert.assertEquals(tripId, tripBreak.get().getTripBreak().getTripId());
            Assert.assertEquals(newTripId, tripBreak.get().getTripBreak().getTripBreakId());

            long countOfTripEnds = output.stream().filter(TripWrapper::getIsTripEnd).count();
            Assert.assertEquals(1, countOfTripEnds);

            Optional<TripWrapper> tripEnd = output.stream().filter(TripWrapper::getIsTripEnd).findFirst();
            Assert.assertTrue(tripEnd.isPresent());
            long tripStartTime = tripEndTime.minusSeconds(TripData.SECONDS_TO_SUBTRACT_FROM_TRIP_END).toEpochMilli();
            long actualTripStartTime = tripEnd.get().getTripEnd().getSourceTripStartTimestamp();
            Assert.assertEquals(tripStartTime, actualTripStartTime);

            Set<Trip> processedTrips = getProcessedTrips(testHarness, virtualId);
            Assert.assertEquals(4, processedTrips.size());

            long firstTripStart = processedTrips.stream()
                    .filter(t -> t.getTripId().equals(tripId) && t.getIsStart())
                    .count();
            Assert.assertEquals(1, firstTripStart);

            long firstTripEnd = processedTrips.stream()
                    .filter(t -> t.getTripId().equals(tripId) && t.getIsEnd())
                    .count();
            Assert.assertEquals(1, firstTripEnd);

            List<TripWrapper> tripState = getTripsState(testHarness, virtualId);
            // State should be cleared since trip completed
            Assert.assertEquals(0, tripState.size());

        } catch (Exception e) {
            throw new FlinkRuntimeException(e);
        }
    }

    @Test
    public void testTripAnalyticsProcessFunction_evDuplicateTripStarts() throws Exception {
        duplicateTripStarts(getTestHarness(), Tenant.EV);
    }

    @Test
    public void testTripAnalyticsProcessFunction_iceDuplicateTripStarts() throws Exception {
        duplicateTripStarts(getTestHarness(), Tenant.ICE);
    }

    @Test
    public void testTripAnalyticsProcessFunction_harleyDuplicateTripStarts() throws Exception {
        duplicateTripStarts(getTestHarness(), Tenant.HARLEY);
    }

    private void duplicateTripStarts(KeyedOneInputStreamOperatorTestHarness<String, Telemetry, TripWrapper> testHarness, Tenant tenant) {
        int countOfEachSignal = 1;
        try (testHarness) {

            testHarness.setup();
            testHarness.open();

            String virtualId = TripData.getVirtualId(tenant);

            String tripId = TripData.getTripId();
            Instant tripStartTime = Instant.now().minusSeconds(5 * 60);
            Instant tripEndTime = Instant.now().minusSeconds(10 * 60);

            Telemetry tripStartEvent = TripData.getTripStartFlag(virtualId, tenant, tripId, tripStartTime, countOfEachSignal, 1);
            testHarness.processElement(new StreamRecord<>(tripStartEvent, tripStartEvent.getCollectionEventTime()));

            // Clear the existing trip wrapper state to simulate TTL
            MapState<String, Set<TripWrapper>> tripsState = getTripsState(testHarness);
            tripsState.clear();

            // Clear processedTrips to simulate the TTL
            MapState<String, Set<Trip>> processedTripsState = getProcessedTripsState(testHarness);
            processedTripsState.clear();

            // Sending a new trip end event. Since no trip start is found, it will be inferred (a duplicate trip start)
            Telemetry tripEndEvent = TripData.getTripEndFlag(virtualId, tenant, tripId, tripEndTime, countOfEachSignal, 1);
            testHarness.processElement(new StreamRecord<>(tripEndEvent, tripEndEvent.getCollectionEventTime()));

            long currentTime = Instant.now().toEpochMilli();
            testHarness.processWatermark(currentTime);
            testHarness.setProcessingTime(currentTime);

            List<TripWrapper> output = TripData.getCollectedData(testHarness.getRecordOutput());
            // Two trip starts(one actual and one inferred) and one for trip end
            Assert.assertEquals(3, output.size());

            long countOfTripStarts = output.stream().filter(TripWrapper::getIsTripStart).count();
            Assert.assertEquals(2, countOfTripStarts);

            long countOfTripStartsFromTripStartSignal = output.stream()
                    .filter(TripWrapper::getIsTripStart)
                    .map(TripWrapper::getTripStart)
                    .filter(t -> TripStartSource.TRIP_START_SIGNAL.getValue().equals(t.getTripSource()))
                    .count();
            Assert.assertEquals(1, countOfTripStartsFromTripStartSignal);

            long countOfTripStartsFromTripEndSignal = output.stream()
                    .filter(TripWrapper::getIsTripStart)
                    .map(TripWrapper::getTripStart)
                    .filter(t -> TripStartSource.TRIP_END_SIGNAL.getValue().equals(t.getTripSource()))
                    .count();
            Assert.assertEquals(1, countOfTripStartsFromTripEndSignal);

            long countOfTripEnds = output.stream().filter(TripWrapper::getIsTripEnd).count();
            Assert.assertEquals(1, countOfTripEnds);

            Set<Trip> processedTrips = getProcessedTrips(testHarness, virtualId);
            Assert.assertEquals(2, processedTrips.size());

            long firstTripStart = processedTrips.stream()
                    .filter(t -> t.getTripId().equals(tripId) && t.getIsStart())
                    .count();
            Assert.assertEquals(1, firstTripStart);

            long firstTripEnd = processedTrips.stream()
                    .filter(t -> t.getTripId().equals(tripId) && t.getIsEnd())
                    .count();
            Assert.assertEquals(1, firstTripEnd);

            List<TripWrapper> tripState = getTripsState(testHarness, virtualId);
            // The trip start inferred from the late event will also be closed. So nothing in state
            Assert.assertEquals(0, tripState.size());

        } catch (Exception e) {
            throw new FlinkRuntimeException(e);
        }
    }

    @Test
    public void testTripAnalyticsProcessFunction_evTripEndFollowedByAnotherTripEnd() throws Exception {
        tripEndFollowedByAnotherTripEnd(getTestHarness(), Tenant.EV);
    }

    @Test
    public void testTripAnalyticsProcessFunction_iceTripEndFollowedByAnotherTripEnd() throws Exception {
        tripEndFollowedByAnotherTripEnd(getTestHarness(), Tenant.ICE);
    }

    @Test
    public void testTripAnalyticsProcessFunction_harleyTripEndFollowedByAnotherTripEnd() throws Exception {
        tripEndFollowedByAnotherTripEnd(getTestHarness(), Tenant.HARLEY);
    }

    private void tripEndFollowedByAnotherTripEnd(KeyedOneInputStreamOperatorTestHarness<String, Telemetry, TripWrapper> testHarness, Tenant tenant) {
        int countOfEachSignal = 1;
        try (testHarness) {

            testHarness.setup();
            testHarness.open();

            String virtualId = TripData.getVirtualId(tenant);

            String tripId = TripData.getTripId();
            Instant tripEndTime = Instant.now().minusSeconds(20 * 60);

            Telemetry tripEndEvent = TripData.getTripEndFlag(virtualId, tenant, tripId, tripEndTime, countOfEachSignal, 1);
            testHarness.processElement(new StreamRecord<>(tripEndEvent, tripEndEvent.getCollectionEventTime()));

            // Sending a new trip end event with 2 min apart from the previous trip.
            String newTripId = TripData.getNextTripId(tripId);
            Instant newTripEndTime = tripEndTime.plusSeconds(18 * 60);
            Instant newTripStartTime = newTripEndTime.minusSeconds(TripData.SECONDS_TO_SUBTRACT_FROM_TRIP_END);
            Telemetry newTripEndEvent = TripData.getTripEndFlag(virtualId, tenant, newTripId, newTripEndTime, countOfEachSignal, 1);
            testHarness.processElement(new StreamRecord<>(newTripEndEvent, newTripEndEvent.getCollectionEventTime()));

            long currentTime = Instant.now().toEpochMilli();
            testHarness.processWatermark(currentTime);
            testHarness.setProcessingTime(currentTime);

            List<TripWrapper> output = TripData.getCollectedData(testHarness.getRecordOutput());
            // One for inferred trip start, one for trip break and another for trip end
            Assert.assertEquals(3, output.size());

            long countOfTripStarts = output.stream().filter(TripWrapper::getIsTripStart).count();
            Assert.assertEquals(1, countOfTripStarts);

            Optional<TripWrapper> tripStart = output.stream().filter(TripWrapper::getIsTripStart).findFirst();
            Assert.assertTrue(tripStart.isPresent());
            Assert.assertEquals(TripStartSource.TRIP_END_SIGNAL.getValue(), tripStart.get().getTripStart().getTripSource());

            long countOfTripBreaks = output.stream().filter(TripWrapper::getIsTripBreak).count();
            Assert.assertEquals(1, countOfTripBreaks);

            Optional<TripWrapper> tripBreakWrapper = output.stream().filter(TripWrapper::getIsTripBreak).findFirst();
            Assert.assertTrue(tripBreakWrapper.isPresent());
            TripBreak tripBreak = tripBreakWrapper.get().getTripBreak();
            Assert.assertEquals(tripId, tripBreak.getTripId());
            Assert.assertEquals(newTripId, tripBreak.getTripBreakId());
            Assert.assertEquals(DateUtils.formatToISO(tripEndTime.toEpochMilli()), tripBreak.getStartTimestamp());
            Assert.assertEquals(DateUtils.formatToISO(newTripStartTime.toEpochMilli()), tripBreak.getEndTimestamp());

            long countOfTripEnds = output.stream().filter(TripWrapper::getIsTripEnd).count();
            Assert.assertEquals(1, countOfTripEnds);

            Optional<TripWrapper> tripEnd = output.stream().filter(TripWrapper::getIsTripEnd).findFirst();
            Assert.assertTrue(tripEnd.isPresent());
            long tripStartTime = tripEndTime.minusSeconds(TripData.SECONDS_TO_SUBTRACT_FROM_TRIP_END).toEpochMilli();
            long actualTripStartTime = tripEnd.get().getTripEnd().getSourceTripStartTimestamp();
            Assert.assertEquals(tripStartTime, actualTripStartTime);

            Set<Trip> processedTrips = getProcessedTrips(testHarness, virtualId);
            Assert.assertEquals(4, processedTrips.size());

            long firstTripStart = processedTrips.stream()
                    .filter(t -> t.getTripId().equals(tripId) && t.getIsStart())
                    .count();
            Assert.assertEquals(1, firstTripStart);

            long firstTripEnd = processedTrips.stream()
                    .filter(t -> t.getTripId().equals(tripId) && t.getIsEnd())
                    .count();
            Assert.assertEquals(1, firstTripEnd);

            List<TripWrapper> tripState = getTripsState(testHarness, virtualId);
            // State should be cleared since trip completed
            Assert.assertEquals(0, tripState.size());

        } catch (Exception e) {
            throw new FlinkRuntimeException(e);
        }
    }

}
