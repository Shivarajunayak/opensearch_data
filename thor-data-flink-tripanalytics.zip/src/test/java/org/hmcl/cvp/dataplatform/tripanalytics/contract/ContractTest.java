package org.hmcl.cvp.dataplatform.tripanalytics.contract;

import org.apache.flink.types.PojoTestUtils;
import org.hmcl.cvp.dataplatform.contract.telemetry.Telemetry;
import org.hmcl.cvp.dataplatform.contract.userpreference.UserPreference;
import org.junit.Test;

public class ContractTest {

    @Test
    public void testTelemetry() {
        PojoTestUtils.assertSerializedAsPojo(Telemetry.class);
    }

    @Test
    public void testUserPreference() {
        PojoTestUtils.assertSerializedAsPojo(UserPreference.class);
    }

    @Test
    public void testUserDetails() {
        PojoTestUtils.assertSerializedAsPojo(UserDetails.class);
    }

    @Test
    public void testTripStart() {
        PojoTestUtils.assertSerializedAsPojo(TripStart.class);
    }

    @Test
    public void testTripBreak() {
        PojoTestUtils.assertSerializedAsPojo(TripBreak.class);
    }

    @Test
    public void testTripEnd() {
        PojoTestUtils.assertSerializedAsPojo(TripEnd.class);
    }

    @Test
    public void testTripWrapper() {
        PojoTestUtils.assertSerializedAsPojo(TripWrapper.class);
    }

    @Test
    public void testTripJoiner() {
        PojoTestUtils.assertSerializedAsPojo(TripJoiner.class);
    }

    @Test
    public void testTrip() {
        PojoTestUtils.assertSerializedAsPojo(Trip.class);
    }

    @Test
    public void testTripStartSignalWrapper() {PojoTestUtils.assertSerializedAsPojo(TripStartSignalWrapper.class);}

}
