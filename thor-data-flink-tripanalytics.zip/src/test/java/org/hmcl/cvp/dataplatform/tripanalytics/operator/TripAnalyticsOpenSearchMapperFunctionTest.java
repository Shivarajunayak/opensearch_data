package org.hmcl.cvp.dataplatform.tripanalytics.operator;

import org.apache.flink.api.java.tuple.Tuple2;
import org.apache.flink.runtime.jobgraph.OperatorID;
import org.apache.flink.runtime.metrics.groups.InternalOperatorMetricGroup;
import org.apache.flink.runtime.metrics.util.InterceptingOperatorMetricGroup;
import org.apache.flink.runtime.metrics.util.InterceptingTaskMetricGroup;
import org.apache.flink.runtime.operators.testutils.MockEnvironment;
import org.apache.flink.runtime.operators.testutils.MockEnvironmentBuilder;
import org.apache.flink.runtime.testutils.MiniClusterResourceConfiguration;
import org.apache.flink.streaming.api.operators.StreamFlatMap;
import org.apache.flink.streaming.runtime.streamrecord.StreamRecord;
import org.apache.flink.streaming.util.OneInputStreamOperatorTestHarness;
import org.apache.flink.test.util.MiniClusterWithClientResource;
import org.hmcl.cvp.dataplatform.commons.exception.FlinkRuntimeException;
import org.hmcl.cvp.dataplatform.contract.telemetry.Tenant;
import org.hmcl.cvp.dataplatform.tripanalytics.contract.TripWrapper;
import org.hmcl.cvp.dataplatform.tripanalytics.job.OpenSearchIndices;
import org.hmcl.cvp.dataplatform.tripanalytics.utils.TripData;
import org.junit.Assert;
import org.junit.ClassRule;
import org.junit.Test;

import java.util.List;
import java.util.Map;

public class TripAnalyticsOpenSearchMapperFunctionTest {

    @ClassRule
    public static MiniClusterWithClientResource flinkCluster =
            new MiniClusterWithClientResource(
                    new MiniClusterResourceConfiguration.Builder()
                            .setNumberSlotsPerTaskManager(2)
                            .setNumberTaskManagers(1)
                            .build());

    private final InterceptingOperatorMetricGroup interceptingOperatorMetricGroup = new InterceptingOperatorMetricGroup();
    private final InterceptingTaskMetricGroup interceptingTaskMetricGroup = new InterceptingTaskMetricGroup() {
        @Override
        public InternalOperatorMetricGroup getOrAddOperator(OperatorID operatorID, String name) {
            return interceptingOperatorMetricGroup;
        }
    };

    private final MockEnvironment mockEnvironment = new MockEnvironmentBuilder().setMetricGroup(interceptingTaskMetricGroup).build();

    private final TripAnalyticsOpenSearchMapperFunction mapperFunction = new TripAnalyticsOpenSearchMapperFunction();

    private OneInputStreamOperatorTestHarness<TripWrapper, Tuple2<String, Map<String, Object>>> testHarness() throws Exception {
        return new OneInputStreamOperatorTestHarness<>(new StreamFlatMap<>(mapperFunction), mockEnvironment);
    }

    @Test
    public void testTripAnalyticsOpenSearchMapperFunction_evTripStart() throws Exception {
        Tenant tenant = Tenant.EV;
        String virtualId = TripData.getVirtualId(tenant);
        TripWrapper tripWrapper = TripData.getTripStartWrapper(virtualId, tenant, 1, 1);
        tripMapper(testHarness(), tripWrapper, OpenSearchIndices.EV_TRIP_START_INDEX);
    }

    @Test
    public void testTripAnalyticsOpenSearchMapperFunction_iceTripStart() throws Exception {
        Tenant tenant = Tenant.ICE;
        String virtualId = TripData.getVirtualId(tenant);
        TripWrapper tripWrapper = TripData.getTripStartWrapper(virtualId, tenant, 1, 1);
        tripMapper(testHarness(), tripWrapper, OpenSearchIndices.ICE_TRIP_START_INDEX);
    }

    @Test
    public void testTripAnalyticsOpenSearchMapperFunction_harleyTripStart() throws Exception {
        Tenant tenant = Tenant.HARLEY;
        String virtualId = TripData.getVirtualId(tenant);
        TripWrapper tripWrapper = TripData.getTripStartWrapper(virtualId, tenant, 1, 1);
        tripMapper(testHarness(), tripWrapper, OpenSearchIndices.HARLEY_TRIP_START_INDEX);
    }

    @Test
    public void testTripAnalyticsOpenSearchMapperFunction_evTripEnd() throws Exception {
        Tenant tenant = Tenant.EV;
        String virtualId = TripData.getVirtualId(tenant);
        TripWrapper tripWrapper = TripData.getTripEndWrapper(virtualId, tenant, 1, 1);
        tripMapper(testHarness(), tripWrapper, OpenSearchIndices.EV_TRIP_END_INDEX);
    }

    @Test
    public void testTripAnalyticsOpenSearchMapperFunction_iceTripEnd() throws Exception {
        Tenant tenant = Tenant.ICE;
        String virtualId = TripData.getVirtualId(tenant);
        TripWrapper tripWrapper = TripData.getTripEndWrapper(virtualId, tenant, 1, 1);
        tripMapper(testHarness(), tripWrapper, OpenSearchIndices.ICE_TRIP_END_INDEX);
    }

    @Test
    public void testTripAnalyticsOpenSearchMapperFunction_harleyTripEnd() throws Exception {
        Tenant tenant = Tenant.HARLEY;
        String virtualId = TripData.getVirtualId(tenant);
        TripWrapper tripWrapper = TripData.getTripEndWrapper(virtualId, tenant, 1, 1);
        tripMapper(testHarness(), tripWrapper, OpenSearchIndices.HARLEY_TRIP_END_INDEX);
    }

    @Test
    public void testTripAnalyticsOpenSearchMapperFunction_evTripBreak() throws Exception {
        Tenant tenant = Tenant.EV;
        String virtualId = TripData.getVirtualId(tenant);
        TripWrapper tripWrapper = TripData.getTripBreakWrapper(virtualId, tenant, 1, 1);
        tripMapper(testHarness(), tripWrapper, OpenSearchIndices.EV_TRIP_BREAK_INDEX);
    }

    @Test
    public void testTripAnalyticsOpenSearchMapperFunction_iceTripBreak() throws Exception {
        Tenant tenant = Tenant.ICE;
        String virtualId = TripData.getVirtualId(tenant);
        TripWrapper tripWrapper = TripData.getTripBreakWrapper(virtualId, tenant, 1, 1);
        tripMapper(testHarness(), tripWrapper, OpenSearchIndices.ICE_TRIP_BREAK_INDEX);
    }

    @Test
    public void testTripAnalyticsOpenSearchMapperFunction_harleyTripBreak() throws Exception {
        Tenant tenant = Tenant.HARLEY;
        String virtualId = TripData.getVirtualId(tenant);
        TripWrapper tripWrapper = TripData.getTripBreakWrapper(virtualId, tenant, 1, 1);
        tripMapper(testHarness(), tripWrapper, OpenSearchIndices.HARLEY_TRIP_BREAK_INDEX);
    }

    private void tripMapper(OneInputStreamOperatorTestHarness<TripWrapper, Tuple2<String, Map<String, Object>>> testHarness,
                           TripWrapper tripWrapper,
                           String indexName) {

        try(testHarness) {

            testHarness.setup();
            testHarness.open();

            testHarness.processElement(new StreamRecord<>(tripWrapper));

            List<Tuple2<String, Map<String, Object>>> output = TripData.getCollectedData(testHarness.getRecordOutput());
            Assert.assertEquals(1, output.size());

            Tuple2<String, Map<String, Object>> tuple2 = output.get(0);
            String index = tuple2.f0;
            Map<String, Object> osDocument = tuple2.f1;

            Assert.assertNotNull(index);
            Assert.assertEquals(indexName, index);
            Assert.assertFalse(osDocument.isEmpty());

        } catch (Exception e) {
            throw new FlinkRuntimeException(e);
        }
    }
}
