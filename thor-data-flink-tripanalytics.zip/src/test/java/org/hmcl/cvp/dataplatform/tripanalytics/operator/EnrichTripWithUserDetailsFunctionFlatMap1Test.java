package org.hmcl.cvp.dataplatform.tripanalytics.operator;

import org.apache.flink.api.common.state.MapState;
import org.apache.flink.api.common.typeinfo.BasicTypeInfo;
import org.apache.flink.api.java.functions.KeySelector;
import org.apache.flink.api.java.utils.ParameterTool;
import org.apache.flink.runtime.testutils.MiniClusterResourceConfiguration;
import org.apache.flink.streaming.api.operators.co.CoStreamFlatMap;
import org.apache.flink.streaming.runtime.streamrecord.StreamRecord;
import org.apache.flink.streaming.util.KeyedTwoInputStreamOperatorTestHarness;
import org.apache.flink.test.util.MiniClusterWithClientResource;
import org.hmcl.cvp.dataplatform.commons.constants.FlinkRuntime;
import org.hmcl.cvp.dataplatform.commons.testdata.UserPreferenceGenerator;
import org.hmcl.cvp.dataplatform.commons.utils.FlinkUtils;
import org.hmcl.cvp.dataplatform.contract.telemetry.Tenant;
import org.hmcl.cvp.dataplatform.contract.userpreference.ProfileType;
import org.hmcl.cvp.dataplatform.contract.userpreference.UserPreference;
import org.hmcl.cvp.dataplatform.tripanalytics.contract.*;
import org.hmcl.cvp.dataplatform.tripanalytics.helper.TripAnalyticsHelper;
import org.hmcl.cvp.dataplatform.tripanalytics.utils.TripData;
import org.junit.Assert;
import org.junit.ClassRule;
import org.junit.Test;

import java.time.Instant;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class EnrichTripWithUserDetailsFunctionFlatMap1Test {

    @ClassRule
    public static MiniClusterWithClientResource flinkCluster =
            new MiniClusterWithClientResource(
                    new MiniClusterResourceConfiguration.Builder()
                            .setNumberSlotsPerTaskManager(2)
                            .setNumberTaskManagers(1)
                            .build());

    private final KeySelector<UserPreference, String> userPreferenceStringKeySelector = UserPreference::getVid;

    private final KeySelector<TripWrapper, String> tripWrapperStringKeySelector = TripWrapper::getVirtualId;

    private final EnrichTripWithUserDetailsFunction enrichTripWithUserDetailsFunction = new EnrichTripWithUserDetailsFunction();

    private KeyedTwoInputStreamOperatorTestHarness<String, TripWrapper, UserPreference, TripWrapper> testHarness(String defaultToRider) throws Exception {
        ParameterTool parameterTool = ParameterTool.fromMap(new HashMap<>());
        parameterTool = FlinkUtils.addProperties(parameterTool, Map.of(FlinkRuntime.TripAnalytics.DEFAULT_TO_CURRENT_RIDER_DETAILS, defaultToRider));

        KeyedTwoInputStreamOperatorTestHarness<String, TripWrapper, UserPreference, TripWrapper> testHarness = new KeyedTwoInputStreamOperatorTestHarness<>(new CoStreamFlatMap<>(enrichTripWithUserDetailsFunction),
                tripWrapperStringKeySelector,
                userPreferenceStringKeySelector,
                BasicTypeInfo.STRING_TYPE_INFO);

        testHarness.getEnvironment().getExecutionConfig().setGlobalJobParameters(parameterTool);

        return testHarness;
    }

    private KeyedTwoInputStreamOperatorTestHarness<String, TripWrapper, UserPreference, TripWrapper> testHarness() throws Exception {
        return testHarness("FALSE");
    }

    private KeyedTwoInputStreamOperatorTestHarness<String, TripWrapper, UserPreference, TripWrapper> riderTestHarness() throws Exception {
        return testHarness("TRUE");
    }

    private MapState<String, Map<String, UserPreference>> getPreferencesStateMap(KeyedTwoInputStreamOperatorTestHarness<String, TripWrapper, UserPreference, TripWrapper> testHarness) {
        return testHarness.getOperator()
                .getKeyedStateStore()
                .getMapState(StateDescriptors.userPreferenceMapStateDescriptor());
    }

    @Test
    public void testEnrichTripWithUserDetailsFunction_tripNeededForBreak() {

        try(KeyedTwoInputStreamOperatorTestHarness<String, TripWrapper, UserPreference, TripWrapper> testHarness = testHarness()) {

            testHarness.setup();
            testHarness.open();

            UserPreference primaryRider = UserPreferenceGenerator.getPrimaryUser(TripData.VIRTUAL_ID);
            StreamRecord<UserPreference> streamRecord1 = new StreamRecord<>(primaryRider);

            testHarness.processElement2(streamRecord1);

            MapState<String, Map<String, UserPreference>> preferencesStateMap = getPreferencesStateMap(testHarness);

            Map<String, UserPreference> preferences = preferencesStateMap.get(TripData.VIRTUAL_ID);

            Assert.assertNotNull(preferences);
            Assert.assertEquals(1, preferences.size());
            UserPreference stateValue = preferences.getOrDefault(primaryRider.getProfileId(), null);
            Assert.assertNotNull(stateValue);

            TripWrapper tripWrapper =  new TripWrapper();
            tripWrapper.setNeededForTripBreak(true);
            tripWrapper.setTripId(TripData.getTripId());
            tripWrapper.setVirtualId(TripData.VIRTUAL_ID);
            StreamRecord<TripWrapper> streamRecord2 = new StreamRecord<>(tripWrapper);
            testHarness.processElement1(streamRecord2);

            List<TripWrapper> output = TripData.getCollectedData(testHarness.getRecordOutput());
            Assert.assertEquals(1, output.size());
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    @Test
    public void testEnrichTripWithUserDetailsFunction_tripStart_userDetailsNull() {

        try(KeyedTwoInputStreamOperatorTestHarness<String, TripWrapper, UserPreference, TripWrapper> testHarness = testHarness()) {

            testHarness.setup();
            testHarness.open();

            UserPreference primaryRider = UserPreferenceGenerator.getPrimaryUser(TripData.VIRTUAL_ID);
            StreamRecord<UserPreference> streamRecord1 = new StreamRecord<>(primaryRider);

            testHarness.processElement2(streamRecord1);

            MapState<String, Map<String, UserPreference>> preferencesStateMap = getPreferencesStateMap(testHarness);

            Map<String, UserPreference> preferences = preferencesStateMap.get(TripData.VIRTUAL_ID);

            Assert.assertNotNull(preferences);
            Assert.assertEquals(1, preferences.size());
            UserPreference stateValue = preferences.getOrDefault(primaryRider.getProfileId(), null);
            Assert.assertNotNull(stateValue);

            TripWrapper tripWrapper = TripData.getTripStartWrapper(TripData.VIRTUAL_ID, Tenant.EV, 1, 1);
            tripWrapper.setUserDetails(null);
            StreamRecord<TripWrapper> streamRecord2 = new StreamRecord<>(tripWrapper);
            testHarness.processElement1(streamRecord2);

            List<TripWrapper> output = TripData.getCollectedData(testHarness.getRecordOutput());
            Assert.assertEquals(1, output.size());
            TripWrapper existingTripWrapper = output.get(0);
            TripStart tripStart = existingTripWrapper.getTripStart();
            Assert.assertEquals(primaryRider.getProfileId(), tripStart.getUserId());
            Assert.assertEquals(ProfileType.PRIMARY.value(), tripStart.getUserProfile());
            Assert.assertEquals(primaryRider.getProfileName(), tripStart.getUserName());
            Assert.assertEquals(UserDetailsSource.PRIMARY_DEFAULT.getValue(), tripStart.getUserDetailsSource());

        } catch (Exception e) {
            throw new RuntimeException(e);
        }

    }

    @Test
    public void testEnrichTripWithUserDetailsFunction_tripStart_userDetailsEmpty() {

        try(KeyedTwoInputStreamOperatorTestHarness<String, TripWrapper, UserPreference, TripWrapper> testHarness = testHarness()) {

            testHarness.setup();
            testHarness.open();

            UserPreference primaryRider = UserPreferenceGenerator.getPrimaryUser(TripData.VIRTUAL_ID);
            StreamRecord<UserPreference> streamRecord1 = new StreamRecord<>(primaryRider);

            testHarness.processElement2(streamRecord1);

            MapState<String, Map<String, UserPreference>> preferencesStateMap = getPreferencesStateMap(testHarness);

            Map<String, UserPreference> preferences = preferencesStateMap.get(TripData.VIRTUAL_ID);

            Assert.assertNotNull(preferences);
            Assert.assertEquals(1, preferences.size());
            UserPreference stateValue = preferences.getOrDefault(primaryRider.getProfileId(), null);
            Assert.assertNotNull(stateValue);

            TripWrapper tripWrapper = TripData.getTripStartWrapper(TripData.VIRTUAL_ID, Tenant.EV, 1, 1);
            tripWrapper.setUserDetails(UserDetails.builder()
                            .userName(TripAnalyticsHelper.DEFAULT_STRING_VALUE)
                            .userProfile(ProfileType.PRIMARY.value())
                            .userId(TripAnalyticsHelper.DEFAULT_STRING_VALUE)
                    .build());
            StreamRecord<TripWrapper> streamRecord2 = new StreamRecord<>(tripWrapper);
            testHarness.processElement1(streamRecord2);

            List<TripWrapper> output = TripData.getCollectedData(testHarness.getRecordOutput());
            Assert.assertEquals(1, output.size());
            TripWrapper existingTripWrapper = output.get(0);
            TripStart tripStart = existingTripWrapper.getTripStart();
            Assert.assertEquals(primaryRider.getProfileId(), tripStart.getUserId());
            Assert.assertEquals(ProfileType.PRIMARY.value(), tripStart.getUserProfile());
            Assert.assertEquals(primaryRider.getProfileName(), tripStart.getUserName());
            Assert.assertEquals(UserDetailsSource.PRIMARY_DEFAULT.getValue(), tripStart.getUserDetailsSource());

        } catch (Exception e) {
            throw new RuntimeException(e);
        }

    }

    @Test
    public void testEnrichTripWithUserDetailsFunction_tripEnd_userDetailsNull() {

        try(KeyedTwoInputStreamOperatorTestHarness<String, TripWrapper, UserPreference, TripWrapper> testHarness = testHarness()) {

            testHarness.setup();
            testHarness.open();

            UserPreference primaryRider = UserPreferenceGenerator.getPrimaryUser(TripData.VIRTUAL_ID);
            StreamRecord<UserPreference> streamRecord1 = new StreamRecord<>(primaryRider);

            testHarness.processElement2(streamRecord1);

            MapState<String, Map<String, UserPreference>> preferencesStateMap = getPreferencesStateMap(testHarness);

            Map<String, UserPreference> preferences = preferencesStateMap.get(TripData.VIRTUAL_ID);

            Assert.assertNotNull(preferences);
            Assert.assertEquals(1, preferences.size());
            UserPreference stateValue = preferences.getOrDefault(primaryRider.getProfileId(), null);
            Assert.assertNotNull(stateValue);

            TripWrapper tripWrapper = TripData.getTripEndWrapper(TripData.VIRTUAL_ID, Tenant.EV, 1, 1);
            tripWrapper.setUserDetails(null);
            StreamRecord<TripWrapper> streamRecord2 = new StreamRecord<>(tripWrapper);
            testHarness.processElement1(streamRecord2);

            List<TripWrapper> output = TripData.getCollectedData(testHarness.getRecordOutput());
            Assert.assertEquals(1, output.size());
            TripWrapper existingTripWrapper = output.get(0);
            TripEnd tripEnd = existingTripWrapper.getTripEnd();
            Assert.assertEquals(primaryRider.getProfileId(), tripEnd.getUserId());
            Assert.assertEquals(ProfileType.PRIMARY.value(), tripEnd.getUserProfile());
            Assert.assertEquals(primaryRider.getProfileName(), tripEnd.getUserName());
            Assert.assertEquals(UserDetailsSource.PRIMARY_DEFAULT.getValue(), tripEnd.getUserDetailsSource());

        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    @Test
    public void testEnrichTripWithUserDetailsFunction_tripEnd_userDetailsEmpty() {

        try(KeyedTwoInputStreamOperatorTestHarness<String, TripWrapper, UserPreference, TripWrapper> testHarness = testHarness()) {

            testHarness.setup();
            testHarness.open();

            UserPreference primaryRider = UserPreferenceGenerator.getPrimaryUser(TripData.VIRTUAL_ID);
            StreamRecord<UserPreference> streamRecord1 = new StreamRecord<>(primaryRider);

            testHarness.processElement2(streamRecord1);

            MapState<String, Map<String, UserPreference>> preferencesStateMap = getPreferencesStateMap(testHarness);

            Map<String, UserPreference> preferences = preferencesStateMap.get(TripData.VIRTUAL_ID);

            Assert.assertNotNull(preferences);
            Assert.assertEquals(1, preferences.size());
            UserPreference stateValue = preferences.getOrDefault(primaryRider.getProfileId(), null);
            Assert.assertNotNull(stateValue);

            TripWrapper tripWrapper = TripData.getTripEndWrapper(TripData.VIRTUAL_ID, Tenant.EV, 1, 1);
            tripWrapper.setUserDetails(UserDetails.builder()
                    .userName(TripAnalyticsHelper.DEFAULT_STRING_VALUE)
                    .userProfile(ProfileType.PRIMARY.value())
                    .userId(TripAnalyticsHelper.DEFAULT_STRING_VALUE)
                    .build());
            StreamRecord<TripWrapper> streamRecord2 = new StreamRecord<>(tripWrapper);
            testHarness.processElement1(streamRecord2);

            List<TripWrapper> output = TripData.getCollectedData(testHarness.getRecordOutput());
            Assert.assertEquals(1, output.size());
            TripWrapper existingTripWrapper = output.get(0);
            TripEnd tripEnd = existingTripWrapper.getTripEnd();
            Assert.assertEquals(primaryRider.getProfileId(), tripEnd.getUserId());
            Assert.assertEquals(ProfileType.PRIMARY.value(), tripEnd.getUserProfile());
            Assert.assertEquals(primaryRider.getProfileName(), tripEnd.getUserName());
            Assert.assertEquals(UserDetailsSource.PRIMARY_DEFAULT.getValue(), tripEnd.getUserDetailsSource());

        } catch (Exception e) {
            throw new RuntimeException(e);
        }

    }

    @Test
    public void testEnrichTripWithUserDetailsFunction_tripBreak_userDetailsNull() {

        try(KeyedTwoInputStreamOperatorTestHarness<String, TripWrapper, UserPreference, TripWrapper> testHarness = testHarness()) {

            testHarness.setup();
            testHarness.open();

            UserPreference primaryRider = UserPreferenceGenerator.getPrimaryUser(TripData.VIRTUAL_ID);
            StreamRecord<UserPreference> streamRecord1 = new StreamRecord<>(primaryRider);

            testHarness.processElement2(streamRecord1);

            MapState<String, Map<String, UserPreference>> preferencesStateMap = getPreferencesStateMap(testHarness);

            Map<String, UserPreference> preferences = preferencesStateMap.get(TripData.VIRTUAL_ID);

            Assert.assertNotNull(preferences);
            Assert.assertEquals(1, preferences.size());
            UserPreference stateValue = preferences.getOrDefault(primaryRider.getProfileId(), null);
            Assert.assertNotNull(stateValue);

            TripWrapper tripWrapper = TripData.getTripBreakWrapper(TripData.VIRTUAL_ID, Tenant.EV, 1, 1);
            tripWrapper.setUserDetails(null);
            StreamRecord<TripWrapper> streamRecord2 = new StreamRecord<>(tripWrapper);
            testHarness.processElement1(streamRecord2);

            List<TripWrapper> output = TripData.getCollectedData(testHarness.getRecordOutput());
            Assert.assertEquals(1, output.size());
            TripWrapper existingTripWrapper = output.get(0);
            TripBreak tripBreak = existingTripWrapper.getTripBreak();
            Assert.assertEquals(primaryRider.getProfileId(), tripBreak.getUserId());
            Assert.assertEquals(ProfileType.PRIMARY.value(), tripBreak.getUserProfile());
            Assert.assertEquals(primaryRider.getProfileName(), tripBreak.getUserName());
            Assert.assertEquals(UserDetailsSource.PRIMARY_DEFAULT.getValue(), tripBreak.getUserDetailsSource());

        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    @Test
    public void testEnrichTripWithUserDetailsFunction_tripBreak_userDetailsEmpty() {

        try(KeyedTwoInputStreamOperatorTestHarness<String, TripWrapper, UserPreference, TripWrapper> testHarness = testHarness()) {

            testHarness.setup();
            testHarness.open();

            UserPreference primaryRider = UserPreferenceGenerator.getPrimaryUser(TripData.VIRTUAL_ID);
            StreamRecord<UserPreference> streamRecord1 = new StreamRecord<>(primaryRider);

            testHarness.processElement2(streamRecord1);

            MapState<String, Map<String, UserPreference>> preferencesStateMap = getPreferencesStateMap(testHarness);

            Map<String, UserPreference> preferences = preferencesStateMap.get(TripData.VIRTUAL_ID);

            Assert.assertNotNull(preferences);
            Assert.assertEquals(1, preferences.size());
            UserPreference stateValue = preferences.getOrDefault(primaryRider.getProfileId(), null);
            Assert.assertNotNull(stateValue);

            TripWrapper tripWrapper = TripData.getTripBreakWrapper(TripData.VIRTUAL_ID, Tenant.EV, 1, 1);
            tripWrapper.setUserDetails(UserDetails.builder()
                    .userName(TripAnalyticsHelper.DEFAULT_STRING_VALUE)
                    .userProfile(ProfileType.PRIMARY.value())
                    .userId(TripAnalyticsHelper.DEFAULT_STRING_VALUE)
                    .build());
            StreamRecord<TripWrapper> streamRecord2 = new StreamRecord<>(tripWrapper);
            testHarness.processElement1(streamRecord2);

            List<TripWrapper> output = TripData.getCollectedData(testHarness.getRecordOutput());
            Assert.assertEquals(1, output.size());
            TripWrapper existingTripWrapper = output.get(0);
            TripBreak tripBreak = existingTripWrapper.getTripBreak();
            Assert.assertEquals(primaryRider.getProfileId(), tripBreak.getUserId());
            Assert.assertEquals(ProfileType.PRIMARY.value(), tripBreak.getUserProfile());
            Assert.assertEquals(primaryRider.getProfileName(), tripBreak.getUserName());
            Assert.assertEquals(UserDetailsSource.PRIMARY_DEFAULT.getValue(), tripBreak.getUserDetailsSource());

        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    @Test
    public void testEnrichTripWithUserDetailsFunction_tripBreakEvent_userDetailsNull() {

        try(KeyedTwoInputStreamOperatorTestHarness<String, TripWrapper, UserPreference, TripWrapper> testHarness = testHarness()) {

            testHarness.setup();
            testHarness.open();

            UserPreference primaryRider = UserPreferenceGenerator.getPrimaryUser(TripData.VIRTUAL_ID);
            StreamRecord<UserPreference> streamRecord1 = new StreamRecord<>(primaryRider);

            testHarness.processElement2(streamRecord1);

            MapState<String, Map<String, UserPreference>> preferencesStateMap = getPreferencesStateMap(testHarness);

            Map<String, UserPreference> preferences = preferencesStateMap.get(TripData.VIRTUAL_ID);

            Assert.assertNotNull(preferences);
            Assert.assertEquals(1, preferences.size());
            UserPreference stateValue = preferences.getOrDefault(primaryRider.getProfileId(), null);
            Assert.assertNotNull(stateValue);

            TripWrapper tripWrapper =  new TripWrapper();
            tripWrapper.setUserDetails(null);
            tripWrapper.setNeededForTripBreak(true);
            tripWrapper.setTripId(TripData.getTripId());
            tripWrapper.setVirtualId(TripData.VIRTUAL_ID);
            StreamRecord<TripWrapper> streamRecord2 = new StreamRecord<>(tripWrapper);
            testHarness.processElement1(streamRecord2);

            List<TripWrapper> output = TripData.getCollectedData(testHarness.getRecordOutput());
            Assert.assertEquals(1, output.size());
            TripWrapper existingTripWrapper = output.get(0);
            UserDetails userDetails = existingTripWrapper.getUserDetails();
            Assert.assertEquals(primaryRider.getProfileId(), userDetails.getUserId());
            Assert.assertEquals(ProfileType.PRIMARY.value(), userDetails.getUserProfile());
            Assert.assertEquals(primaryRider.getProfileName(), userDetails.getUserName());
            Assert.assertEquals(UserDetailsSource.PRIMARY_DEFAULT.getValue(), userDetails.getSource());

        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    @Test
    public void testEnrichTripWithUserDetailsFunction_tripBreakEvent_userDetailsEmpty() {

        try(KeyedTwoInputStreamOperatorTestHarness<String, TripWrapper, UserPreference, TripWrapper> testHarness = testHarness()) {

            testHarness.setup();
            testHarness.open();

            UserPreference primaryRider = UserPreferenceGenerator.getPrimaryUser(TripData.VIRTUAL_ID);
            StreamRecord<UserPreference> streamRecord1 = new StreamRecord<>(primaryRider);

            testHarness.processElement2(streamRecord1);

            MapState<String, Map<String, UserPreference>> preferencesStateMap = getPreferencesStateMap(testHarness);

            Map<String, UserPreference> preferences = preferencesStateMap.get(TripData.VIRTUAL_ID);

            Assert.assertNotNull(preferences);
            Assert.assertEquals(1, preferences.size());
            UserPreference stateValue = preferences.getOrDefault(primaryRider.getProfileId(), null);
            Assert.assertNotNull(stateValue);

            TripWrapper tripWrapper =  new TripWrapper();
            tripWrapper.setUserDetails(UserDetails.builder()
                    .userName(TripAnalyticsHelper.DEFAULT_STRING_VALUE)
                    .userProfile(ProfileType.PRIMARY.value())
                    .userId(TripAnalyticsHelper.DEFAULT_STRING_VALUE)
                    .build());
            tripWrapper.setNeededForTripBreak(true);
            tripWrapper.setTripId(TripData.getTripId());
            tripWrapper.setVirtualId(TripData.VIRTUAL_ID);
            StreamRecord<TripWrapper> streamRecord2 = new StreamRecord<>(tripWrapper);
            testHarness.processElement1(streamRecord2);

            List<TripWrapper> output = TripData.getCollectedData(testHarness.getRecordOutput());
            Assert.assertEquals(1, output.size());
            TripWrapper existingTripWrapper = output.get(0);
            UserDetails userDetails = existingTripWrapper.getUserDetails();
            Assert.assertEquals(primaryRider.getProfileId(), userDetails.getUserId());
            Assert.assertEquals(ProfileType.PRIMARY.value(), userDetails.getUserProfile());
            Assert.assertEquals(primaryRider.getProfileName(), userDetails.getUserName());
            Assert.assertEquals(UserDetailsSource.PRIMARY_DEFAULT.getValue(), userDetails.getSource());

        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    @Test
    public void testEnrichTripWithUserDetailsFunction_tripStart_userDetailsPresent_userPreferenceNotPresent() {

        try(KeyedTwoInputStreamOperatorTestHarness<String, TripWrapper, UserPreference, TripWrapper> testHarness = testHarness()) {

            testHarness.setup();
            testHarness.open();

            UserPreference primary = UserPreferenceGenerator.getPrimaryRider(TripData.VIRTUAL_ID);

            TripWrapper tripWrapper = TripData.getTripStartWrapper(TripData.VIRTUAL_ID, Tenant.EV, 1, 1);
            TripData.addUserDetailsToTripWrapper(tripWrapper, primary);

            StreamRecord<TripWrapper> streamRecord1 = new StreamRecord<>(tripWrapper);
            testHarness.processElement1(streamRecord1);

            List<TripWrapper> output = TripData.getCollectedData(testHarness.getRecordOutput());
            Assert.assertEquals(1, output.size());
            TripWrapper existingTripWrapper = output.get(0);
            TripStart tripStart = existingTripWrapper.getTripStart();
            Assert.assertEquals(primary.getProfileId(), tripStart.getUserId());
            Assert.assertEquals(ProfileType.PRIMARY.value(), tripStart.getUserProfile());
            Assert.assertEquals(UserDetailsSource.PRIMARY_UNKNOWN.getValue(), tripStart.getUserDetailsSource());

        } catch (Exception e) {
            throw new RuntimeException(e);
        }

    }

    @Test
    public void testEnrichTripWithUserDetailsFunction_tripStart_userDetailsNull_userPreferenceNotPresent() {

        try(KeyedTwoInputStreamOperatorTestHarness<String, TripWrapper, UserPreference, TripWrapper> testHarness = testHarness()) {

            testHarness.setup();
            testHarness.open();

            TripWrapper tripWrapper = TripData.getTripStartWrapper(TripData.VIRTUAL_ID, Tenant.EV, 1, 1);
            tripWrapper.setUserDetails(null);
            StreamRecord<TripWrapper> streamRecord2 = new StreamRecord<>(tripWrapper);
            testHarness.processElement1(streamRecord2);

            List<TripWrapper> output = TripData.getCollectedData(testHarness.getRecordOutput());
            Assert.assertEquals(1, output.size());
            TripWrapper existingTripWrapper = output.get(0);
            TripStart tripStart = existingTripWrapper.getTripStart();
            Assert.assertEquals(TripAnalyticsHelper.DEFAULT_STRING_VALUE, tripStart.getUserId());
            Assert.assertEquals(TripAnalyticsHelper.DEFAULT_STRING_VALUE, tripStart.getUserProfile());
            Assert.assertEquals(TripAnalyticsHelper.DEFAULT_STRING_VALUE, tripStart.getUserName());
            Assert.assertEquals(UserDetailsSource.PRIMARY_UNKNOWN.getValue(), tripStart.getUserDetailsSource());

        } catch (Exception e) {
            throw new RuntimeException(e);
        }

    }

    @Test
    public void testEnrichTripWithUserDetailsFunction_tripEnd_userDetailsNull_userPreferenceNotPresent() {

        try(KeyedTwoInputStreamOperatorTestHarness<String, TripWrapper, UserPreference, TripWrapper> testHarness = testHarness()) {

            testHarness.setup();
            testHarness.open();

            TripWrapper tripWrapper = TripData.getTripEndWrapper(TripData.VIRTUAL_ID, Tenant.EV, 1, 1);
            tripWrapper.setUserDetails(null);
            StreamRecord<TripWrapper> streamRecord2 = new StreamRecord<>(tripWrapper);
            testHarness.processElement1(streamRecord2);

            List<TripWrapper> output = TripData.getCollectedData(testHarness.getRecordOutput());
            Assert.assertEquals(1, output.size());
            TripWrapper existingTripWrapper = output.get(0);
            TripEnd tripEnd = existingTripWrapper.getTripEnd();
            Assert.assertEquals(TripAnalyticsHelper.DEFAULT_STRING_VALUE, tripEnd.getUserId());
            Assert.assertEquals(TripAnalyticsHelper.DEFAULT_STRING_VALUE, tripEnd.getUserProfile());
            Assert.assertEquals(TripAnalyticsHelper.DEFAULT_STRING_VALUE, tripEnd.getUserName());
            Assert.assertEquals(UserDetailsSource.PRIMARY_UNKNOWN.getValue(), tripEnd.getUserDetailsSource());

        } catch (Exception e) {
            throw new RuntimeException(e);
        }

    }

    @Test
    public void testEnrichTripWithUserDetailsFunction_tripEnd_userDetailsPresent_userPreferenceNotPresent() {

        try(KeyedTwoInputStreamOperatorTestHarness<String, TripWrapper, UserPreference, TripWrapper> testHarness = testHarness()) {

            testHarness.setup();
            testHarness.open();

            UserPreference primary = UserPreferenceGenerator.getPrimaryRider(TripData.VIRTUAL_ID);

            TripWrapper tripWrapper = TripData.getTripEndWrapper(TripData.VIRTUAL_ID, Tenant.EV, 1, 1);
            TripData.addUserDetailsToTripWrapper(tripWrapper, primary);

            StreamRecord<TripWrapper> streamRecord1 = new StreamRecord<>(tripWrapper);
            testHarness.processElement1(streamRecord1);

            List<TripWrapper> output = TripData.getCollectedData(testHarness.getRecordOutput());
            Assert.assertEquals(1, output.size());
            TripWrapper existingTripWrapper = output.get(0);
            TripEnd tripEnd = existingTripWrapper.getTripEnd();
            Assert.assertEquals(primary.getProfileId(), tripEnd.getUserId());
            Assert.assertEquals(ProfileType.PRIMARY.value(), tripEnd.getUserProfile());
            Assert.assertEquals(UserDetailsSource.PRIMARY_UNKNOWN.getValue(), tripEnd.getUserDetailsSource());

        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    @Test
    public void testEnrichTripWithUserDetailsFunction_tripBreak_userDetailsNull_userPreferenceNotPresent() {

        try(KeyedTwoInputStreamOperatorTestHarness<String, TripWrapper, UserPreference, TripWrapper> testHarness = testHarness()) {

            testHarness.setup();
            testHarness.open();

            TripWrapper tripWrapper = TripData.getTripBreakWrapper(TripData.VIRTUAL_ID, Tenant.EV, 1, 1);
            tripWrapper.setUserDetails(null);
            StreamRecord<TripWrapper> streamRecord2 = new StreamRecord<>(tripWrapper);
            testHarness.processElement1(streamRecord2);

            List<TripWrapper> output = TripData.getCollectedData(testHarness.getRecordOutput());
            Assert.assertEquals(1, output.size());
            TripWrapper existingTripWrapper = output.get(0);
            TripBreak tripBreak = existingTripWrapper.getTripBreak();
            Assert.assertEquals(TripAnalyticsHelper.DEFAULT_STRING_VALUE, tripBreak.getUserId());
            Assert.assertEquals(TripAnalyticsHelper.DEFAULT_STRING_VALUE, tripBreak.getUserProfile());
            Assert.assertEquals(TripAnalyticsHelper.DEFAULT_STRING_VALUE, tripBreak.getUserName());
            Assert.assertEquals(UserDetailsSource.PRIMARY_UNKNOWN.getValue(), tripBreak.getUserDetailsSource());

        } catch (Exception e) {
            throw new RuntimeException(e);
        }

    }

    @Test
    public void testEnrichTripWithUserDetailsFunction_tripBreak_userDetailsPresent_userPreferenceNotPresent() {

        try(KeyedTwoInputStreamOperatorTestHarness<String, TripWrapper, UserPreference, TripWrapper> testHarness = testHarness()) {

            testHarness.setup();
            testHarness.open();

            UserPreference primary = UserPreferenceGenerator.getPrimaryRider(TripData.VIRTUAL_ID);

            TripWrapper tripWrapper = TripData.getTripBreakWrapper(TripData.VIRTUAL_ID, Tenant.EV, 1, 1);
            TripData.addUserDetailsToTripWrapper(tripWrapper, primary);

            StreamRecord<TripWrapper> streamRecord1 = new StreamRecord<>(tripWrapper);
            testHarness.processElement1(streamRecord1);

            List<TripWrapper> output = TripData.getCollectedData(testHarness.getRecordOutput());
            Assert.assertEquals(1, output.size());
            TripWrapper existingTripWrapper = output.get(0);
            TripBreak tripBreak = existingTripWrapper.getTripBreak();
            Assert.assertEquals(primary.getProfileId(), tripBreak.getUserId());
            Assert.assertEquals(ProfileType.PRIMARY.value(), tripBreak.getUserProfile());
            Assert.assertEquals(UserDetailsSource.PRIMARY_UNKNOWN.getValue(), tripBreak.getUserDetailsSource());

        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    @Test
    public void testEnrichTripWithUserDetailsFunction_tripBreakEvent_userDetailsNull_userPreferenceNotPresent() {

        try(KeyedTwoInputStreamOperatorTestHarness<String, TripWrapper, UserPreference, TripWrapper> testHarness = testHarness()) {

            testHarness.setup();
            testHarness.open();

            TripWrapper tripWrapper =  new TripWrapper();
            tripWrapper.setNeededForTripBreak(true);
            tripWrapper.setTripId(TripData.getTripId());
            tripWrapper.setVirtualId(TripData.VIRTUAL_ID);
            tripWrapper.setUserDetails(null);
            StreamRecord<TripWrapper> streamRecord2 = new StreamRecord<>(tripWrapper);
            testHarness.processElement1(streamRecord2);

            List<TripWrapper> output = TripData.getCollectedData(testHarness.getRecordOutput());
            Assert.assertEquals(1, output.size());
            TripWrapper existingTripWrapper = output.get(0);
            UserDetails userDetails = existingTripWrapper.getUserDetails();
            Assert.assertEquals(TripAnalyticsHelper.DEFAULT_STRING_VALUE, userDetails.getUserId());
            Assert.assertEquals(TripAnalyticsHelper.DEFAULT_STRING_VALUE, userDetails.getUserProfile());
            Assert.assertEquals(TripAnalyticsHelper.DEFAULT_STRING_VALUE, userDetails.getUserName());
            Assert.assertEquals(UserDetailsSource.PRIMARY_UNKNOWN.getValue(), userDetails.getSource());

        } catch (Exception e) {
            throw new RuntimeException(e);
        }

    }

    @Test
    public void testEnrichTripWithUserDetailsFunction_tripBreakEvent_userDetailsPresent_userPreferenceNotPresent() {

        try(KeyedTwoInputStreamOperatorTestHarness<String, TripWrapper, UserPreference, TripWrapper> testHarness = testHarness()) {

            testHarness.setup();
            testHarness.open();

            UserPreference primary = UserPreferenceGenerator.getPrimaryRider(TripData.VIRTUAL_ID);

            TripWrapper tripWrapper =  new TripWrapper();
            tripWrapper.setNeededForTripBreak(true);
            tripWrapper.setTripId(TripData.getTripId());
            tripWrapper.setVirtualId(TripData.VIRTUAL_ID);
            TripData.addUserDetailsToTripWrapper(tripWrapper, primary);

            StreamRecord<TripWrapper> streamRecord1 = new StreamRecord<>(tripWrapper);
            testHarness.processElement1(streamRecord1);

            List<TripWrapper> output = TripData.getCollectedData(testHarness.getRecordOutput());
            Assert.assertEquals(1, output.size());
            TripWrapper existingTripWrapper = output.get(0);
            UserDetails userDetails = existingTripWrapper.getUserDetails();
            Assert.assertEquals(primary.getProfileId(), userDetails.getUserId());
            Assert.assertEquals(ProfileType.PRIMARY.value(), userDetails.getUserProfile());
            Assert.assertEquals(UserDetailsSource.PRIMARY_UNKNOWN.getValue(), userDetails.getSource());

        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    @Test
    public void testEnrichTripWithUserDetailsFunction_tripStart_profileEmpty_userPreferenceNotPresent() {

        try(KeyedTwoInputStreamOperatorTestHarness<String, TripWrapper, UserPreference, TripWrapper> testHarness = testHarness()) {

            testHarness.setup();
            testHarness.open();

            TripWrapper tripWrapper = TripData.getTripStartWrapper(TripData.VIRTUAL_ID, Tenant.EV, 1, 0);
            tripWrapper.setUserDetails(UserDetails.builder()
                    .userProfile("")
                    .userId("")
                    .build());
            StreamRecord<TripWrapper> streamRecord2 = new StreamRecord<>(tripWrapper);
            testHarness.processElement1(streamRecord2);

            List<TripWrapper> output = TripData.getCollectedData(testHarness.getRecordOutput());
            Assert.assertEquals(1, output.size());
            TripWrapper existingTripWrapper = output.get(0);
            TripStart tripStart = existingTripWrapper.getTripStart();
            Assert.assertEquals(TripAnalyticsHelper.DEFAULT_STRING_VALUE, tripStart.getUserId());
            Assert.assertEquals(TripAnalyticsHelper.DEFAULT_STRING_VALUE, tripStart.getUserProfile());
            Assert.assertEquals(TripAnalyticsHelper.DEFAULT_STRING_VALUE, tripStart.getUserName());
            Assert.assertEquals(UserDetailsSource.PRIMARY_UNKNOWN.getValue(), tripStart.getUserDetailsSource());

        } catch (Exception e) {
            throw new RuntimeException(e);
        }

    }

    @Test
    public void testEnrichTripWithUserDetailsFunction_tripEnd_profileEmpty_userPreferenceNotPresent() {

        try(KeyedTwoInputStreamOperatorTestHarness<String, TripWrapper, UserPreference, TripWrapper> testHarness = testHarness()) {

            testHarness.setup();
            testHarness.open();

            TripWrapper tripWrapper = TripData.getTripEndWrapper(TripData.VIRTUAL_ID, Tenant.EV, 1, 0);
            tripWrapper.setUserDetails(UserDetails.builder()
                    .userProfile("")
                    .userId("")
                    .build());
            StreamRecord<TripWrapper> streamRecord2 = new StreamRecord<>(tripWrapper);
            testHarness.processElement1(streamRecord2);

            List<TripWrapper> output = TripData.getCollectedData(testHarness.getRecordOutput());
            Assert.assertEquals(1, output.size());
            TripWrapper existingTripWrapper = output.get(0);
            TripEnd tripEnd = existingTripWrapper.getTripEnd();
            Assert.assertEquals(TripAnalyticsHelper.DEFAULT_STRING_VALUE, tripEnd.getUserId());
            Assert.assertEquals(TripAnalyticsHelper.DEFAULT_STRING_VALUE, tripEnd.getUserProfile());
            Assert.assertEquals(TripAnalyticsHelper.DEFAULT_STRING_VALUE, tripEnd.getUserName());
            Assert.assertEquals(UserDetailsSource.PRIMARY_UNKNOWN.getValue(), tripEnd.getUserDetailsSource());

        } catch (Exception e) {
            throw new RuntimeException(e);
        }

    }

    @Test
    public void testEnrichTripWithUserDetailsFunction_tripBreak_profileEmpty_userPreferenceNotPresent() {

        try(KeyedTwoInputStreamOperatorTestHarness<String, TripWrapper, UserPreference, TripWrapper> testHarness = testHarness()) {

            testHarness.setup();
            testHarness.open();

            TripWrapper tripWrapper = TripData.getTripBreakWrapper(TripData.VIRTUAL_ID, Tenant.EV, 1, 0);
            tripWrapper.setUserDetails(UserDetails.builder()
                            .userProfile("")
                            .userId("")
                    .build());
            StreamRecord<TripWrapper> streamRecord2 = new StreamRecord<>(tripWrapper);
            testHarness.processElement1(streamRecord2);

            List<TripWrapper> output = TripData.getCollectedData(testHarness.getRecordOutput());
            Assert.assertEquals(1, output.size());
            TripWrapper existingTripWrapper = output.get(0);
            TripBreak tripBreak = existingTripWrapper.getTripBreak();
            Assert.assertEquals(TripAnalyticsHelper.DEFAULT_STRING_VALUE, tripBreak.getUserId());
            Assert.assertEquals(TripAnalyticsHelper.DEFAULT_STRING_VALUE, tripBreak.getUserProfile());
            Assert.assertEquals(TripAnalyticsHelper.DEFAULT_STRING_VALUE, tripBreak.getUserName());
            Assert.assertEquals(UserDetailsSource.PRIMARY_UNKNOWN.getValue(), tripBreak.getUserDetailsSource());

        } catch (Exception e) {
            throw new RuntimeException(e);
        }

    }

    @Test
    public void testEnrichTripWithUserDetailsFunction_tripBreakEvent_profileEmpty_userPreferenceNotPresent() {

        try(KeyedTwoInputStreamOperatorTestHarness<String, TripWrapper, UserPreference, TripWrapper> testHarness = testHarness()) {

            testHarness.setup();
            testHarness.open();

            TripWrapper tripWrapper =  new TripWrapper();
            tripWrapper.setNeededForTripBreak(true);
            tripWrapper.setTripId(TripData.getTripId());
            tripWrapper.setVirtualId(TripData.VIRTUAL_ID);
            tripWrapper.setUserDetails(UserDetails.builder()
                    .userProfile("")
                    .userId("")
                    .build());
            StreamRecord<TripWrapper> streamRecord2 = new StreamRecord<>(tripWrapper);
            testHarness.processElement1(streamRecord2);

            List<TripWrapper> output = TripData.getCollectedData(testHarness.getRecordOutput());
            Assert.assertEquals(1, output.size());
            TripWrapper existingTripWrapper = output.get(0);
            UserDetails userDetails = existingTripWrapper.getUserDetails();
            Assert.assertEquals(TripAnalyticsHelper.DEFAULT_STRING_VALUE, userDetails.getUserId());
            Assert.assertEquals(TripAnalyticsHelper.DEFAULT_STRING_VALUE, userDetails.getUserProfile());
            Assert.assertEquals(TripAnalyticsHelper.DEFAULT_STRING_VALUE, userDetails.getUserName());
            Assert.assertEquals(UserDetailsSource.PRIMARY_UNKNOWN.getValue(), userDetails.getSource());

        } catch (Exception e) {
            throw new RuntimeException(e);
        }

    }

    @Test
    public void testEnrichTripWithUserDetailsFunction_tripStart_profileEmpty_primaryPresent() {

        try(KeyedTwoInputStreamOperatorTestHarness<String, TripWrapper, UserPreference, TripWrapper> testHarness = testHarness()) {

            testHarness.setup();
            testHarness.open();

            UserPreference primaryRider = UserPreferenceGenerator.getPrimaryUser(TripData.VIRTUAL_ID);
            StreamRecord<UserPreference> streamRecord1 = new StreamRecord<>(primaryRider);

            testHarness.processElement2(streamRecord1);

            MapState<String, Map<String, UserPreference>> preferencesStateMap = getPreferencesStateMap(testHarness);

            Map<String, UserPreference> preferences = preferencesStateMap.get(TripData.VIRTUAL_ID);

            Assert.assertNotNull(preferences);
            Assert.assertEquals(1, preferences.size());
            UserPreference stateValue = preferences.getOrDefault(primaryRider.getProfileId(), null);
            Assert.assertNotNull(stateValue);

            TripWrapper tripWrapper = TripData.getTripStartWrapper(TripData.VIRTUAL_ID, Tenant.EV, 1, 0);
            tripWrapper.setUserDetails(UserDetails.builder()
                    .userProfile("")
                    .userId("")
                    .build());
            StreamRecord<TripWrapper> streamRecord2 = new StreamRecord<>(tripWrapper);
            testHarness.processElement1(streamRecord2);

            List<TripWrapper> output = TripData.getCollectedData(testHarness.getRecordOutput());
            Assert.assertEquals(1, output.size());
            TripWrapper existingTripWrapper = output.get(0);
            TripStart tripStart = existingTripWrapper.getTripStart();
            Assert.assertEquals(stateValue.getProfileId(), tripStart.getUserId());
            Assert.assertEquals(stateValue.getProfileType().value(), tripStart.getUserProfile());
            Assert.assertEquals(stateValue.getProfileName(), tripStart.getUserName());
            Assert.assertEquals(UserDetailsSource.PRIMARY_DEFAULT.getValue(), tripStart.getUserDetailsSource());

        } catch (Exception e) {
            throw new RuntimeException(e);
        }

    }

    @Test
    public void testEnrichTripWithUserDetailsFunction_tripEnd_profileEmpty_primaryPresent() {

        try(KeyedTwoInputStreamOperatorTestHarness<String, TripWrapper, UserPreference, TripWrapper> testHarness = testHarness()) {

            testHarness.setup();
            testHarness.open();

            UserPreference primaryRider = UserPreferenceGenerator.getPrimaryUser(TripData.VIRTUAL_ID);
            StreamRecord<UserPreference> streamRecord1 = new StreamRecord<>(primaryRider);

            testHarness.processElement2(streamRecord1);

            MapState<String, Map<String, UserPreference>> preferencesStateMap = getPreferencesStateMap(testHarness);

            Map<String, UserPreference> preferences = preferencesStateMap.get(TripData.VIRTUAL_ID);

            Assert.assertNotNull(preferences);
            Assert.assertEquals(1, preferences.size());
            UserPreference stateValue = preferences.getOrDefault(primaryRider.getProfileId(), null);
            Assert.assertNotNull(stateValue);

            TripWrapper tripWrapper = TripData.getTripEndWrapper(TripData.VIRTUAL_ID, Tenant.EV, 1, 0);
            tripWrapper.setUserDetails(UserDetails.builder()
                    .userProfile("")
                    .userId("")
                    .build());
            StreamRecord<TripWrapper> streamRecord2 = new StreamRecord<>(tripWrapper);
            testHarness.processElement1(streamRecord2);

            List<TripWrapper> output = TripData.getCollectedData(testHarness.getRecordOutput());
            Assert.assertEquals(1, output.size());
            TripWrapper existingTripWrapper = output.get(0);
            TripEnd tripEnd = existingTripWrapper.getTripEnd();
            Assert.assertEquals(stateValue.getProfileId(), tripEnd.getUserId());
            Assert.assertEquals(stateValue.getProfileType().value(), tripEnd.getUserProfile());
            Assert.assertEquals(stateValue.getProfileName(), tripEnd.getUserName());
            Assert.assertEquals(UserDetailsSource.PRIMARY_DEFAULT.getValue(), tripEnd.getUserDetailsSource());

        } catch (Exception e) {
            throw new RuntimeException(e);
        }

    }

    @Test
    public void testEnrichTripWithUserDetailsFunction_tripBreak_profileEmpty_primaryPresent() {

        try(KeyedTwoInputStreamOperatorTestHarness<String, TripWrapper, UserPreference, TripWrapper> testHarness = testHarness()) {

            testHarness.setup();
            testHarness.open();

            UserPreference primaryRider = UserPreferenceGenerator.getPrimaryUser(TripData.VIRTUAL_ID);
            StreamRecord<UserPreference> streamRecord1 = new StreamRecord<>(primaryRider);

            testHarness.processElement2(streamRecord1);

            MapState<String, Map<String, UserPreference>> preferencesStateMap = getPreferencesStateMap(testHarness);

            Map<String, UserPreference> preferences = preferencesStateMap.get(TripData.VIRTUAL_ID);

            Assert.assertNotNull(preferences);
            Assert.assertEquals(1, preferences.size());
            UserPreference stateValue = preferences.getOrDefault(primaryRider.getProfileId(), null);
            Assert.assertNotNull(stateValue);

            TripWrapper tripWrapper = TripData.getTripBreakWrapper(TripData.VIRTUAL_ID, Tenant.EV, 1, 0);
            tripWrapper.setUserDetails(UserDetails.builder()
                    .userProfile("")
                    .userId("")
                    .build());
            StreamRecord<TripWrapper> streamRecord2 = new StreamRecord<>(tripWrapper);
            testHarness.processElement1(streamRecord2);

            List<TripWrapper> output = TripData.getCollectedData(testHarness.getRecordOutput());
            Assert.assertEquals(1, output.size());
            TripWrapper existingTripWrapper = output.get(0);
            TripBreak tripBreak = existingTripWrapper.getTripBreak();
            Assert.assertEquals(stateValue.getProfileId(), tripBreak.getUserId());
            Assert.assertEquals(stateValue.getProfileType().value(), tripBreak.getUserProfile());
            Assert.assertEquals(stateValue.getProfileName(), tripBreak.getUserName());
            Assert.assertEquals(UserDetailsSource.PRIMARY_DEFAULT.getValue(), tripBreak.getUserDetailsSource());
        } catch (Exception e) {
            throw new RuntimeException(e);
        }

    }

    @Test
    public void testEnrichTripWithUserDetailsFunction_tripBreakEvent_profileEmpty_primaryPresent() {

        try(KeyedTwoInputStreamOperatorTestHarness<String, TripWrapper, UserPreference, TripWrapper> testHarness = testHarness()) {

            testHarness.setup();
            testHarness.open();

            UserPreference primaryRider = UserPreferenceGenerator.getPrimaryUser(TripData.VIRTUAL_ID);
            StreamRecord<UserPreference> streamRecord1 = new StreamRecord<>(primaryRider);

            testHarness.processElement2(streamRecord1);

            MapState<String, Map<String, UserPreference>> preferencesStateMap = getPreferencesStateMap(testHarness);

            Map<String, UserPreference> preferences = preferencesStateMap.get(TripData.VIRTUAL_ID);

            Assert.assertNotNull(preferences);
            Assert.assertEquals(1, preferences.size());
            UserPreference stateValue = preferences.getOrDefault(primaryRider.getProfileId(), null);
            Assert.assertNotNull(stateValue);

            TripWrapper tripWrapper =  new TripWrapper();
            tripWrapper.setNeededForTripBreak(true);
            tripWrapper.setTripId(TripData.getTripId());
            tripWrapper.setVirtualId(TripData.VIRTUAL_ID);
            tripWrapper.setUserDetails(UserDetails.builder()
                    .userProfile("")
                    .userId("")
                    .build());
            StreamRecord<TripWrapper> streamRecord2 = new StreamRecord<>(tripWrapper);
            testHarness.processElement1(streamRecord2);

            List<TripWrapper> output = TripData.getCollectedData(testHarness.getRecordOutput());
            Assert.assertEquals(1, output.size());
            TripWrapper existingTripWrapper = output.get(0);
            UserDetails userDetails = existingTripWrapper.getUserDetails();
            Assert.assertEquals(stateValue.getProfileId(), userDetails.getUserId());
            Assert.assertEquals(stateValue.getProfileType().value(), userDetails.getUserProfile());
            Assert.assertEquals(stateValue.getProfileName(), userDetails.getUserName());
            Assert.assertEquals(UserDetailsSource.PRIMARY_DEFAULT.getValue(), userDetails.getSource());
        } catch (Exception e) {
            throw new RuntimeException(e);
        }

    }

    @Test
    public void testEnrichTripWithUserDetailsFunction_tripStart_primaryUser() {

        try(KeyedTwoInputStreamOperatorTestHarness<String, TripWrapper, UserPreference, TripWrapper> testHarness = testHarness()) {

            testHarness.setup();
            testHarness.open();

            UserPreference primaryRider = UserPreferenceGenerator.getPrimaryUser(TripData.VIRTUAL_ID);
            StreamRecord<UserPreference> streamRecord1 = new StreamRecord<>(primaryRider);

            testHarness.processElement2(streamRecord1);

            MapState<String, Map<String, UserPreference>> preferencesStateMap = getPreferencesStateMap(testHarness);

            Map<String, UserPreference> preferences = preferencesStateMap.get(TripData.VIRTUAL_ID);

            Assert.assertNotNull(preferences);
            Assert.assertEquals(1, preferences.size());
            UserPreference stateValue = preferences.getOrDefault(primaryRider.getProfileId(), null);
            Assert.assertNotNull(stateValue);

            TripWrapper tripWrapper = TripData.getTripStartWrapper(TripData.VIRTUAL_ID, Tenant.EV, 1, 1);
            StreamRecord<TripWrapper> streamRecord2 = new StreamRecord<>(tripWrapper);
            testHarness.processElement1(streamRecord2);

            List<TripWrapper> output = TripData.getCollectedData(testHarness.getRecordOutput());
            Assert.assertEquals(1, output.size());
            TripWrapper existingTripWrapper = output.get(0);
            TripStart tripStart = existingTripWrapper.getTripStart();
            Assert.assertEquals(primaryRider.getProfileId(), tripStart.getUserId());
            Assert.assertEquals(ProfileType.PRIMARY.value(), tripStart.getUserProfile());
            Assert.assertEquals(primaryRider.getProfileName(), tripStart.getUserName());
            // Primary since userId is hardCoded while preparing this test data
            Assert.assertEquals(UserDetailsSource.PRIMARY.getValue(), tripStart.getUserDetailsSource());

        } catch (Exception e) {
            throw new RuntimeException(e);
        }

    }

    @Test
    public void testEnrichTripWithUserDetailsFunction_tripEnd_primaryUser() {

        try(KeyedTwoInputStreamOperatorTestHarness<String, TripWrapper, UserPreference, TripWrapper> testHarness = testHarness()) {

            testHarness.setup();
            testHarness.open();

            UserPreference primaryRider = UserPreferenceGenerator.getPrimaryUser(TripData.VIRTUAL_ID);
            StreamRecord<UserPreference> streamRecord1 = new StreamRecord<>(primaryRider);

            testHarness.processElement2(streamRecord1);

            MapState<String, Map<String, UserPreference>> preferencesStateMap = getPreferencesStateMap(testHarness);

            Map<String, UserPreference> preferences = preferencesStateMap.get(TripData.VIRTUAL_ID);

            Assert.assertNotNull(preferences);
            Assert.assertEquals(1, preferences.size());
            UserPreference stateValue = preferences.getOrDefault(primaryRider.getProfileId(), null);
            Assert.assertNotNull(stateValue);

            TripWrapper tripWrapper = TripData.getTripEndWrapper(TripData.VIRTUAL_ID, Tenant.EV, 1, 1);
            StreamRecord<TripWrapper> streamRecord2 = new StreamRecord<>(tripWrapper);
            testHarness.processElement1(streamRecord2);

            List<TripWrapper> output = TripData.getCollectedData(testHarness.getRecordOutput());
            Assert.assertEquals(1, output.size());
            TripWrapper existingTripWrapper = output.get(0);
            TripEnd tripEnd = existingTripWrapper.getTripEnd();
            Assert.assertEquals(primaryRider.getProfileId(), tripEnd.getUserId());
            Assert.assertEquals(ProfileType.PRIMARY.value(), tripEnd.getUserProfile());
            Assert.assertEquals(primaryRider.getProfileName(), tripEnd.getUserName());
            // Primary since userId is hardCoded while preparing this test data
            Assert.assertEquals(UserDetailsSource.PRIMARY.getValue(), tripEnd.getUserDetailsSource());

        } catch (Exception e) {
            throw new RuntimeException(e);
        }

    }

    @Test
    public void testEnrichTripWithUserDetailsFunction_tripBreak_primaryUser() {

        try(KeyedTwoInputStreamOperatorTestHarness<String, TripWrapper, UserPreference, TripWrapper> testHarness = testHarness()) {

            testHarness.setup();
            testHarness.open();

            UserPreference primaryRider = UserPreferenceGenerator.getPrimaryUser(TripData.VIRTUAL_ID);
            StreamRecord<UserPreference> streamRecord1 = new StreamRecord<>(primaryRider);

            testHarness.processElement2(streamRecord1);

            MapState<String, Map<String, UserPreference>> preferencesStateMap = getPreferencesStateMap(testHarness);

            Map<String, UserPreference> preferences = preferencesStateMap.get(TripData.VIRTUAL_ID);

            Assert.assertNotNull(preferences);
            Assert.assertEquals(1, preferences.size());
            UserPreference stateValue = preferences.getOrDefault(primaryRider.getProfileId(), null);
            Assert.assertNotNull(stateValue);

            TripWrapper tripWrapper = TripData.getTripBreakWrapper(TripData.VIRTUAL_ID, Tenant.EV, 1, 1);
            StreamRecord<TripWrapper> streamRecord2 = new StreamRecord<>(tripWrapper);
            testHarness.processElement1(streamRecord2);

            List<TripWrapper> output = TripData.getCollectedData(testHarness.getRecordOutput());
            Assert.assertEquals(1, output.size());
            TripWrapper existingTripWrapper = output.get(0);
            TripBreak tripBreak = existingTripWrapper.getTripBreak();
            Assert.assertEquals(primaryRider.getProfileId(), tripBreak.getUserId());
            Assert.assertEquals(ProfileType.PRIMARY.value(), tripBreak.getUserProfile());
            Assert.assertEquals(primaryRider.getProfileName(), tripBreak.getUserName());
            Assert.assertEquals(UserDetailsSource.PRIMARY_DEFAULT.getValue(), tripBreak.getUserDetailsSource());

        } catch (Exception e) {
            throw new RuntimeException(e);
        }

    }

    @Test
    public void testEnrichTripWithUserDetailsFunction_tripBreakEvent_primaryUser() {

        try(KeyedTwoInputStreamOperatorTestHarness<String, TripWrapper, UserPreference, TripWrapper> testHarness = testHarness()) {

            testHarness.setup();
            testHarness.open();

            UserPreference primaryRider = UserPreferenceGenerator.getPrimaryUser(TripData.VIRTUAL_ID);
            StreamRecord<UserPreference> streamRecord1 = new StreamRecord<>(primaryRider);

            testHarness.processElement2(streamRecord1);

            MapState<String, Map<String, UserPreference>> preferencesStateMap = getPreferencesStateMap(testHarness);

            Map<String, UserPreference> preferences = preferencesStateMap.get(TripData.VIRTUAL_ID);

            Assert.assertNotNull(preferences);
            Assert.assertEquals(1, preferences.size());
            UserPreference stateValue = preferences.getOrDefault(primaryRider.getProfileId(), null);
            Assert.assertNotNull(stateValue);

            TripWrapper tripWrapper =  new TripWrapper();
            tripWrapper.setNeededForTripBreak(true);
            tripWrapper.setTripId(TripData.getTripId());
            tripWrapper.setVirtualId(TripData.VIRTUAL_ID);
            StreamRecord<TripWrapper> streamRecord2 = new StreamRecord<>(tripWrapper);
            testHarness.processElement1(streamRecord2);

            List<TripWrapper> output = TripData.getCollectedData(testHarness.getRecordOutput());
            Assert.assertEquals(1, output.size());
            TripWrapper existingTripWrapper = output.get(0);
            UserDetails userDetails = existingTripWrapper.getUserDetails();
            Assert.assertEquals(primaryRider.getProfileId(), userDetails.getUserId());
            Assert.assertEquals(ProfileType.PRIMARY.value(), userDetails.getUserProfile());
            Assert.assertEquals(primaryRider.getProfileName(), userDetails.getUserName());
            Assert.assertEquals(UserDetailsSource.PRIMARY_DEFAULT.getValue(), userDetails.getSource());

        } catch (Exception e) {
            throw new RuntimeException(e);
        }

    }

    @Test
    public void testEnrichTripWithUserDetailsFunction_tripStart_secondaryUserNotPresentDefaultedToPrimaryUser() {

        try(KeyedTwoInputStreamOperatorTestHarness<String, TripWrapper, UserPreference, TripWrapper> testHarness = testHarness()) {

            testHarness.setup();
            testHarness.open();

            UserPreference primaryRider = UserPreferenceGenerator.getPrimaryUser(TripData.VIRTUAL_ID);
            StreamRecord<UserPreference> streamRecord1 = new StreamRecord<>(primaryRider);

            testHarness.processElement2(streamRecord1);

            MapState<String, Map<String, UserPreference>> preferencesStateMap = getPreferencesStateMap(testHarness);

            Map<String, UserPreference> preferences = preferencesStateMap.get(TripData.VIRTUAL_ID);

            Assert.assertNotNull(preferences);
            Assert.assertEquals(1, preferences.size());
            UserPreference stateValue = preferences.getOrDefault(primaryRider.getProfileId(), null);
            Assert.assertNotNull(stateValue);

            TripWrapper tripWrapper = TripData.getTripStartWrapper(TripData.VIRTUAL_ID, Tenant.EV, 1, 2);
            StreamRecord<TripWrapper> streamRecord2 = new StreamRecord<>(tripWrapper);
            testHarness.processElement1(streamRecord2);

            List<TripWrapper> output = TripData.getCollectedData(testHarness.getRecordOutput());
            Assert.assertEquals(1, output.size());
            TripWrapper existingTripWrapper = output.get(0);
            TripStart tripStart = existingTripWrapper.getTripStart();
            Assert.assertEquals(primaryRider.getProfileId(), tripStart.getUserId());
            Assert.assertEquals(ProfileType.PRIMARY.value(), tripStart.getUserProfile());
            Assert.assertEquals(primaryRider.getProfileName(), tripStart.getUserName());
            Assert.assertEquals(UserDetailsSource.PRIMARY_DEFAULT.getValue(), tripStart.getUserDetailsSource());

        } catch (Exception e) {
            throw new RuntimeException(e);
        }

    }

    @Test
    public void testEnrichTripWithUserDetailsFunction_tripEnd_secondaryUserNotPresentDefaultedToPrimaryUser() {

        try(KeyedTwoInputStreamOperatorTestHarness<String, TripWrapper, UserPreference, TripWrapper> testHarness = testHarness()) {

            testHarness.setup();
            testHarness.open();

            UserPreference primaryRider = UserPreferenceGenerator.getPrimaryUser(TripData.VIRTUAL_ID);
            StreamRecord<UserPreference> streamRecord1 = new StreamRecord<>(primaryRider);

            testHarness.processElement2(streamRecord1);

            MapState<String, Map<String, UserPreference>> preferencesStateMap = getPreferencesStateMap(testHarness);

            Map<String, UserPreference> preferences = preferencesStateMap.get(TripData.VIRTUAL_ID);

            Assert.assertNotNull(preferences);
            Assert.assertEquals(1, preferences.size());
            UserPreference stateValue = preferences.getOrDefault(primaryRider.getProfileId(), null);
            Assert.assertNotNull(stateValue);

            TripWrapper tripWrapper = TripData.getTripEndWrapper(TripData.VIRTUAL_ID, Tenant.EV, 1, 2);
            StreamRecord<TripWrapper> streamRecord2 = new StreamRecord<>(tripWrapper);
            testHarness.processElement1(streamRecord2);

            List<TripWrapper> output = TripData.getCollectedData(testHarness.getRecordOutput());
            Assert.assertEquals(1, output.size());
            TripWrapper existingTripWrapper = output.get(0);
            TripEnd tripEnd = existingTripWrapper.getTripEnd();
            Assert.assertEquals(primaryRider.getProfileId(), tripEnd.getUserId());
            Assert.assertEquals(ProfileType.PRIMARY.value(), tripEnd.getUserProfile());
            Assert.assertEquals(primaryRider.getProfileName(), tripEnd.getUserName());
            Assert.assertEquals(UserDetailsSource.PRIMARY_DEFAULT.getValue(), tripEnd.getUserDetailsSource());

        } catch (Exception e) {
            throw new RuntimeException(e);
        }

    }

    @Test
    public void testEnrichTripWithUserDetailsFunction_tripBreak_secondaryUserNotPresentDefaultedToPrimaryUser() {

        try(KeyedTwoInputStreamOperatorTestHarness<String, TripWrapper, UserPreference, TripWrapper> testHarness = testHarness()) {

            testHarness.setup();
            testHarness.open();

            UserPreference primaryRider = UserPreferenceGenerator.getPrimaryUser(TripData.VIRTUAL_ID);
            StreamRecord<UserPreference> streamRecord1 = new StreamRecord<>(primaryRider);

            testHarness.processElement2(streamRecord1);

            MapState<String, Map<String, UserPreference>> preferencesStateMap = getPreferencesStateMap(testHarness);

            Map<String, UserPreference> preferences = preferencesStateMap.get(TripData.VIRTUAL_ID);

            Assert.assertNotNull(preferences);
            Assert.assertEquals(1, preferences.size());
            UserPreference stateValue = preferences.getOrDefault(primaryRider.getProfileId(), null);
            Assert.assertNotNull(stateValue);

            TripWrapper tripWrapper = TripData.getTripBreakWrapper(TripData.VIRTUAL_ID, Tenant.EV, 1, 2);
            StreamRecord<TripWrapper> streamRecord2 = new StreamRecord<>(tripWrapper);
            testHarness.processElement1(streamRecord2);

            List<TripWrapper> output = TripData.getCollectedData(testHarness.getRecordOutput());
            Assert.assertEquals(1, output.size());
            TripWrapper existingTripWrapper = output.get(0);
            TripBreak tripBreak = existingTripWrapper.getTripBreak();
            Assert.assertEquals(primaryRider.getProfileId(), tripBreak.getUserId());
            Assert.assertEquals(ProfileType.PRIMARY.value(), tripBreak.getUserProfile());
            Assert.assertEquals(primaryRider.getProfileName(), tripBreak.getUserName());
            Assert.assertEquals(UserDetailsSource.PRIMARY_DEFAULT.getValue(), tripBreak.getUserDetailsSource());

        } catch (Exception e) {
            throw new RuntimeException(e);
        }

    }

    @Test
    public void testEnrichTripWithUserDetailsFunction_tripBreakEvent_secondaryUserNotPresentDefaultedToPrimaryUser() {

        try(KeyedTwoInputStreamOperatorTestHarness<String, TripWrapper, UserPreference, TripWrapper> testHarness = testHarness()) {

            testHarness.setup();
            testHarness.open();

            UserPreference primaryRider = UserPreferenceGenerator.getPrimaryUser(TripData.VIRTUAL_ID);
            StreamRecord<UserPreference> streamRecord1 = new StreamRecord<>(primaryRider);

            testHarness.processElement2(streamRecord1);

            MapState<String, Map<String, UserPreference>> preferencesStateMap = getPreferencesStateMap(testHarness);

            Map<String, UserPreference> preferences = preferencesStateMap.get(TripData.VIRTUAL_ID);

            Assert.assertNotNull(preferences);
            Assert.assertEquals(1, preferences.size());
            UserPreference stateValue = preferences.getOrDefault(primaryRider.getProfileId(), null);
            Assert.assertNotNull(stateValue);

            TripWrapper tripWrapper =  new TripWrapper();
            tripWrapper.setNeededForTripBreak(true);
            tripWrapper.setTripId(TripData.getTripId());
            tripWrapper.setVirtualId(TripData.VIRTUAL_ID);
            tripWrapper.setUserDetails(UserDetails.builder()
                            .userId("abcdef")
                            .userProfile(ProfileType.SECONDARY.value())
                            .valid(true)
                    .build());
            StreamRecord<TripWrapper> streamRecord2 = new StreamRecord<>(tripWrapper);
            testHarness.processElement1(streamRecord2);

            List<TripWrapper> output = TripData.getCollectedData(testHarness.getRecordOutput());
            Assert.assertEquals(1, output.size());
            TripWrapper existingTripWrapper = output.get(0);
            UserDetails userDetails = existingTripWrapper.getUserDetails();
            Assert.assertEquals(primaryRider.getProfileId(), userDetails.getUserId());
            Assert.assertEquals(ProfileType.PRIMARY.value(), userDetails.getUserProfile());
            Assert.assertEquals(primaryRider.getProfileName(), userDetails.getUserName());
            Assert.assertEquals(UserDetailsSource.PRIMARY_DEFAULT.getValue(), userDetails.getSource());

        } catch (Exception e) {
            throw new RuntimeException(e);
        }

    }

    @Test
    public void testEnrichTripWithUserDetailsFunction_tripStart_validSecondaryUser() {

        try(KeyedTwoInputStreamOperatorTestHarness<String, TripWrapper, UserPreference, TripWrapper> testHarness = testHarness()) {

            testHarness.setup();
            testHarness.open();

            UserPreference secondaryUser = UserPreferenceGenerator.getSecondaryUser(TripData.VIRTUAL_ID);
            StreamRecord<UserPreference> streamRecord1 = new StreamRecord<>(secondaryUser);

            testHarness.processElement2(streamRecord1);

            UserPreference primaryUser = UserPreferenceGenerator.getPrimaryUser(TripData.VIRTUAL_ID);
            StreamRecord<UserPreference> streamRecord2 = new StreamRecord<>(primaryUser);

            testHarness.processElement2(streamRecord2);

            MapState<String, Map<String, UserPreference>> preferencesStateMap = getPreferencesStateMap(testHarness);

            Map<String, UserPreference> preferences = preferencesStateMap.get(TripData.VIRTUAL_ID);

            Assert.assertNotNull(preferences);
            Assert.assertEquals(2, preferences.size());
            UserPreference stateValue = preferences.getOrDefault(secondaryUser.getProfileId(), null);
            Assert.assertNotNull(stateValue);

            TripWrapper tripWrapper = TripData.getTripStartWrapper(TripData.VIRTUAL_ID, Tenant.EV, 1, 2);
            TripData.addUserDetailsToTripWrapper(tripWrapper, secondaryUser);

            StreamRecord<TripWrapper> streamRecord3 = new StreamRecord<>(tripWrapper);
            testHarness.processElement1(streamRecord3);

            List<TripWrapper> output = TripData.getCollectedData(testHarness.getRecordOutput());
            Assert.assertEquals(1, output.size());
            TripWrapper existingTripWrapper = output.get(0);
            TripStart tripStart = existingTripWrapper.getTripStart();
            Assert.assertEquals(secondaryUser.getProfileId(), tripStart.getUserId());
            Assert.assertEquals(ProfileType.SECONDARY.value(), tripStart.getUserProfile());
            Assert.assertEquals(secondaryUser.getProfileName(), tripStart.getUserName());
            Assert.assertEquals(UserDetailsSource.SECONDARY.getValue(), tripStart.getUserDetailsSource());

        } catch (Exception e) {
            throw new RuntimeException(e);
        }

    }

    @Test
    public void testEnrichTripWithUserDetailsFunction_tripEnd_validSecondaryUser() {

        try(KeyedTwoInputStreamOperatorTestHarness<String, TripWrapper, UserPreference, TripWrapper> testHarness = testHarness()) {

            testHarness.setup();
            testHarness.open();

            UserPreference secondaryUser = UserPreferenceGenerator.getSecondaryUser(TripData.VIRTUAL_ID);
            StreamRecord<UserPreference> streamRecord1 = new StreamRecord<>(secondaryUser);

            testHarness.processElement2(streamRecord1);

            UserPreference primaryUser = UserPreferenceGenerator.getPrimaryUser(TripData.VIRTUAL_ID);
            StreamRecord<UserPreference> streamRecord2 = new StreamRecord<>(primaryUser);

            testHarness.processElement2(streamRecord2);

            MapState<String, Map<String, UserPreference>> preferencesStateMap = getPreferencesStateMap(testHarness);

            Map<String, UserPreference> preferences = preferencesStateMap.get(TripData.VIRTUAL_ID);

            Assert.assertNotNull(preferences);
            Assert.assertEquals(2, preferences.size());
            UserPreference stateValue = preferences.getOrDefault(secondaryUser.getProfileId(), null);
            Assert.assertNotNull(stateValue);

            TripWrapper tripWrapper = TripData.getTripEndWrapper(TripData.VIRTUAL_ID, Tenant.EV, 1, 2);
            TripData.addUserDetailsToTripWrapper(tripWrapper, secondaryUser);

            StreamRecord<TripWrapper> streamRecord3 = new StreamRecord<>(tripWrapper);
            testHarness.processElement1(streamRecord3);

            List<TripWrapper> output = TripData.getCollectedData(testHarness.getRecordOutput());
            Assert.assertEquals(1, output.size());
            TripWrapper existingTripWrapper = output.get(0);
            TripEnd tripEnd = existingTripWrapper.getTripEnd();
            Assert.assertEquals(secondaryUser.getProfileId(), tripEnd.getUserId());
            Assert.assertEquals(ProfileType.SECONDARY.value(), tripEnd.getUserProfile());
            Assert.assertEquals(secondaryUser.getProfileName(), tripEnd.getUserName());
            Assert.assertEquals(UserDetailsSource.SECONDARY.getValue(), tripEnd.getUserDetailsSource());

        } catch (Exception e) {
            throw new RuntimeException(e);
        }

    }

    @Test
    public void testEnrichTripWithUserDetailsFunction_tripBreak_validSecondaryUser() {

        try(KeyedTwoInputStreamOperatorTestHarness<String, TripWrapper, UserPreference, TripWrapper> testHarness = testHarness()) {

            testHarness.setup();
            testHarness.open();

            UserPreference secondaryUser = UserPreferenceGenerator.getSecondaryUser(TripData.VIRTUAL_ID);
            StreamRecord<UserPreference> streamRecord1 = new StreamRecord<>(secondaryUser);

            testHarness.processElement2(streamRecord1);

            UserPreference primaryUser = UserPreferenceGenerator.getPrimaryUser(TripData.VIRTUAL_ID);
            StreamRecord<UserPreference> streamRecord2 = new StreamRecord<>(primaryUser);

            testHarness.processElement2(streamRecord2);

            MapState<String, Map<String, UserPreference>> preferencesStateMap = getPreferencesStateMap(testHarness);

            Map<String, UserPreference> preferences = preferencesStateMap.get(TripData.VIRTUAL_ID);

            Assert.assertNotNull(preferences);
            Assert.assertEquals(2, preferences.size());
            UserPreference stateValue = preferences.getOrDefault(secondaryUser.getProfileId(), null);
            Assert.assertNotNull(stateValue);

            TripWrapper tripWrapper = TripData.getTripBreakWrapper(TripData.VIRTUAL_ID, Tenant.EV, 1, 2);
            TripData.addUserDetailsToTripWrapper(tripWrapper, secondaryUser);

            StreamRecord<TripWrapper> streamRecord3 = new StreamRecord<>(tripWrapper);
            testHarness.processElement1(streamRecord3);

            List<TripWrapper> output = TripData.getCollectedData(testHarness.getRecordOutput());
            Assert.assertEquals(1, output.size());
            TripWrapper existingTripWrapper = output.get(0);
            TripBreak tripBreak = existingTripWrapper.getTripBreak();
            Assert.assertEquals(secondaryUser.getProfileId(), tripBreak.getUserId());
            Assert.assertEquals(ProfileType.SECONDARY.value(), tripBreak.getUserProfile());
            Assert.assertEquals(secondaryUser.getProfileName(), tripBreak.getUserName());
            Assert.assertEquals(UserDetailsSource.SECONDARY.getValue(), tripBreak.getUserDetailsSource());

        } catch (Exception e) {
            throw new RuntimeException(e);
        }

    }

    @Test
    public void testEnrichTripWithUserDetailsFunction_tripBreakEvent_validSecondaryUser() {

        try(KeyedTwoInputStreamOperatorTestHarness<String, TripWrapper, UserPreference, TripWrapper> testHarness = testHarness()) {

            testHarness.setup();
            testHarness.open();

            UserPreference secondaryUser = UserPreferenceGenerator.getSecondaryUser(TripData.VIRTUAL_ID);
            StreamRecord<UserPreference> streamRecord1 = new StreamRecord<>(secondaryUser);

            testHarness.processElement2(streamRecord1);

            UserPreference primaryUser = UserPreferenceGenerator.getPrimaryUser(TripData.VIRTUAL_ID);
            StreamRecord<UserPreference> streamRecord2 = new StreamRecord<>(primaryUser);

            testHarness.processElement2(streamRecord2);

            MapState<String, Map<String, UserPreference>> preferencesStateMap = getPreferencesStateMap(testHarness);

            Map<String, UserPreference> preferences = preferencesStateMap.get(TripData.VIRTUAL_ID);

            Assert.assertNotNull(preferences);
            Assert.assertEquals(2, preferences.size());
            UserPreference stateValue = preferences.getOrDefault(secondaryUser.getProfileId(), null);
            Assert.assertNotNull(stateValue);

            TripWrapper tripWrapper =  new TripWrapper();
            tripWrapper.setNeededForTripBreak(true);
            tripWrapper.setTripId(TripData.getTripId());
            tripWrapper.setVirtualId(TripData.VIRTUAL_ID);
            tripWrapper.setTimestamp(Instant.now().toEpochMilli());
            TripData.addUserDetailsToTripWrapper(tripWrapper, secondaryUser);

            StreamRecord<TripWrapper> streamRecord3 = new StreamRecord<>(tripWrapper);
            testHarness.processElement1(streamRecord3);

            List<TripWrapper> output = TripData.getCollectedData(testHarness.getRecordOutput());
            Assert.assertEquals(1, output.size());
            TripWrapper existingTripWrapper = output.get(0);
            UserDetails userDetails = existingTripWrapper.getUserDetails();
            Assert.assertEquals(secondaryUser.getProfileId(), userDetails.getUserId());
            Assert.assertEquals(ProfileType.SECONDARY.value(), userDetails.getUserProfile());
            Assert.assertEquals(secondaryUser.getProfileName(), userDetails.getUserName());
            Assert.assertEquals(UserDetailsSource.SECONDARY.getValue(), userDetails.getSource());

        } catch (Exception e) {
            throw new RuntimeException(e);
        }

    }

    @Test
    public void testEnrichTripWithUserDetailsFunction_tripStart_expiredSecondaryUser() {

        try(KeyedTwoInputStreamOperatorTestHarness<String, TripWrapper, UserPreference, TripWrapper> testHarness = testHarness()) {

            testHarness.setup();
            testHarness.open();

            UserPreference secondaryUser = UserPreferenceGenerator.getSecondaryUser(TripData.VIRTUAL_ID);
            secondaryUser.setAccessValidTillTsp(Instant.now().minusSeconds(5L * 60).toEpochMilli());
            StreamRecord<UserPreference> streamRecord1 = new StreamRecord<>(secondaryUser);
            testHarness.processElement2(streamRecord1);

            UserPreference primaryUser = UserPreferenceGenerator.getPrimaryUser(TripData.VIRTUAL_ID);
            StreamRecord<UserPreference> streamRecord2 = new StreamRecord<>(primaryUser);
            testHarness.processElement2(streamRecord2);

            MapState<String, Map<String, UserPreference>> preferencesStateMap = getPreferencesStateMap(testHarness);

            Map<String, UserPreference> preferences = preferencesStateMap.get(TripData.VIRTUAL_ID);

            Assert.assertNotNull(preferences);
            Assert.assertEquals(2, preferences.size());

            TripWrapper tripWrapper = TripData.getTripStartWrapper(TripData.VIRTUAL_ID, Tenant.EV, 1, 2);
            TripData.addUserDetailsToTripWrapper(tripWrapper, secondaryUser);
            StreamRecord<TripWrapper> streamRecord3 = new StreamRecord<>(tripWrapper);
            testHarness.processElement1(streamRecord3);

            List<TripWrapper> output = TripData.getCollectedData(testHarness.getRecordOutput());
            Assert.assertEquals(1, output.size());
            TripWrapper existingTripWrapper = output.get(0);
            TripStart tripStart = existingTripWrapper.getTripStart();
            Assert.assertEquals(primaryUser.getProfileId(), tripStart.getUserId());
            Assert.assertEquals(ProfileType.PRIMARY.value(), tripStart.getUserProfile());
            Assert.assertEquals(primaryUser.getProfileName(), tripStart.getUserName());
            Assert.assertEquals(UserDetailsSource.PRIMARY_DEFAULT.getValue(), tripStart.getUserDetailsSource());

        } catch (Exception e) {
            throw new RuntimeException(e);
        }

    }

    @Test
    public void testEnrichTripWithUserDetailsFunction_tripEnd_expiredSecondaryUser() {

        try(KeyedTwoInputStreamOperatorTestHarness<String, TripWrapper, UserPreference, TripWrapper> testHarness = testHarness()) {

            testHarness.setup();
            testHarness.open();

            UserPreference secondaryUser = UserPreferenceGenerator.getSecondaryUser(TripData.VIRTUAL_ID);
            secondaryUser.setAccessValidTillTsp(Instant.now().minusSeconds(5L * 60).toEpochMilli());
            StreamRecord<UserPreference> streamRecord1 = new StreamRecord<>(secondaryUser);
            testHarness.processElement2(streamRecord1);

            UserPreference primaryUser = UserPreferenceGenerator.getPrimaryUser(TripData.VIRTUAL_ID);
            StreamRecord<UserPreference> streamRecord2 = new StreamRecord<>(primaryUser);
            testHarness.processElement2(streamRecord2);

            MapState<String, Map<String, UserPreference>> preferencesStateMap = getPreferencesStateMap(testHarness);

            Map<String, UserPreference> preferences = preferencesStateMap.get(TripData.VIRTUAL_ID);

            Assert.assertNotNull(preferences);
            Assert.assertEquals(2, preferences.size());

            TripWrapper tripWrapper = TripData.getTripEndWrapper(TripData.VIRTUAL_ID, Tenant.EV, 1, 2);
            TripData.addUserDetailsToTripWrapper(tripWrapper, secondaryUser);
            StreamRecord<TripWrapper> streamRecord3 = new StreamRecord<>(tripWrapper);
            testHarness.processElement1(streamRecord3);

            List<TripWrapper> output = TripData.getCollectedData(testHarness.getRecordOutput());
            Assert.assertEquals(1, output.size());
            TripWrapper existingTripWrapper = output.get(0);
            TripEnd tripEnd = existingTripWrapper.getTripEnd();
            Assert.assertEquals(primaryUser.getProfileId(), tripEnd.getUserId());
            Assert.assertEquals(ProfileType.PRIMARY.value(), tripEnd.getUserProfile());
            Assert.assertEquals(primaryUser.getProfileName(), tripEnd.getUserName());
            Assert.assertEquals(UserDetailsSource.PRIMARY_DEFAULT.getValue(), tripEnd.getUserDetailsSource());

        } catch (Exception e) {
            throw new RuntimeException(e);
        }

    }

    @Test
    public void testEnrichTripWithUserDetailsFunction_tripBreak_expiredSecondaryUser() {

        try(KeyedTwoInputStreamOperatorTestHarness<String, TripWrapper, UserPreference, TripWrapper> testHarness = testHarness()) {

            testHarness.setup();
            testHarness.open();

            UserPreference secondaryUser = UserPreferenceGenerator.getSecondaryUser(TripData.VIRTUAL_ID);
            secondaryUser.setAccessValidTillTsp(Instant.now().minusSeconds(5L * 60).toEpochMilli());
            StreamRecord<UserPreference> streamRecord1 = new StreamRecord<>(secondaryUser);
            testHarness.processElement2(streamRecord1);

            UserPreference primaryUser = UserPreferenceGenerator.getPrimaryUser(TripData.VIRTUAL_ID);
            StreamRecord<UserPreference> streamRecord2 = new StreamRecord<>(primaryUser);
            testHarness.processElement2(streamRecord2);

            MapState<String, Map<String, UserPreference>> preferencesStateMap = getPreferencesStateMap(testHarness);

            Map<String, UserPreference> preferences = preferencesStateMap.get(TripData.VIRTUAL_ID);

            Assert.assertNotNull(preferences);
            Assert.assertEquals(2, preferences.size());

            TripWrapper tripWrapper = TripData.getTripBreakWrapper(TripData.VIRTUAL_ID, Tenant.EV, 1, 2);
            TripData.addUserDetailsToTripWrapper(tripWrapper, secondaryUser);
            StreamRecord<TripWrapper> streamRecord3 = new StreamRecord<>(tripWrapper);
            testHarness.processElement1(streamRecord3);

            List<TripWrapper> output = TripData.getCollectedData(testHarness.getRecordOutput());
            Assert.assertEquals(1, output.size());
            TripWrapper existingTripWrapper = output.get(0);
            TripBreak tripBreak = existingTripWrapper.getTripBreak();
            Assert.assertEquals(primaryUser.getProfileId(), tripBreak.getUserId());
            Assert.assertEquals(ProfileType.PRIMARY.value(), tripBreak.getUserProfile());
            Assert.assertEquals(primaryUser.getProfileName(), tripBreak.getUserName());
            Assert.assertEquals(UserDetailsSource.PRIMARY_DEFAULT.getValue(), tripBreak.getUserDetailsSource());

        } catch (Exception e) {
            throw new RuntimeException(e);
        }

    }

    @Test
    public void testEnrichTripWithUserDetailsFunction_tripBreakEvent_expiredSecondaryUser() {

        try(KeyedTwoInputStreamOperatorTestHarness<String, TripWrapper, UserPreference, TripWrapper> testHarness = testHarness()) {

            testHarness.setup();
            testHarness.open();

            UserPreference secondaryUser = UserPreferenceGenerator.getSecondaryUser(TripData.VIRTUAL_ID);
            secondaryUser.setAccessValidTillTsp(Instant.now().minusSeconds(5L * 60).toEpochMilli());
            StreamRecord<UserPreference> streamRecord1 = new StreamRecord<>(secondaryUser);
            testHarness.processElement2(streamRecord1);

            UserPreference primaryUser = UserPreferenceGenerator.getPrimaryUser(TripData.VIRTUAL_ID);
            StreamRecord<UserPreference> streamRecord2 = new StreamRecord<>(primaryUser);
            testHarness.processElement2(streamRecord2);

            MapState<String, Map<String, UserPreference>> preferencesStateMap = getPreferencesStateMap(testHarness);

            Map<String, UserPreference> preferences = preferencesStateMap.get(TripData.VIRTUAL_ID);

            Assert.assertNotNull(preferences);
            Assert.assertEquals(2, preferences.size());

            TripWrapper tripWrapper =  new TripWrapper();
            tripWrapper.setNeededForTripBreak(true);
            tripWrapper.setTripId(TripData.getTripId());
            tripWrapper.setVirtualId(TripData.VIRTUAL_ID);
            tripWrapper.setTimestamp(Instant.now().toEpochMilli());
            TripData.addUserDetailsToTripWrapper(tripWrapper, secondaryUser);

            StreamRecord<TripWrapper> streamRecord3 = new StreamRecord<>(tripWrapper);
            testHarness.processElement1(streamRecord3);

            List<TripWrapper> output = TripData.getCollectedData(testHarness.getRecordOutput());
            Assert.assertEquals(1, output.size());
            TripWrapper existingTripWrapper = output.get(0);
            UserDetails userDetails = existingTripWrapper.getUserDetails();
            Assert.assertEquals(primaryUser.getProfileId(), userDetails.getUserId());
            Assert.assertEquals(ProfileType.PRIMARY.value(), userDetails.getUserProfile());
            Assert.assertEquals(primaryUser.getProfileName(), userDetails.getUserName());
            Assert.assertEquals(UserDetailsSource.PRIMARY_DEFAULT.getValue(), userDetails.getSource());

        } catch (Exception e) {
            throw new RuntimeException(e);
        }

    }

    @Test
    public void testEnrichTripWithUserDetailsFunction_tripStart_expiredSecondaryUser_noPrimaryUserPresent() {

        try(KeyedTwoInputStreamOperatorTestHarness<String, TripWrapper, UserPreference, TripWrapper> testHarness = testHarness()) {

            testHarness.setup();
            testHarness.open();

            UserPreference secondaryUser = UserPreferenceGenerator.getSecondaryUser(TripData.VIRTUAL_ID);
            secondaryUser.setAccessValidTillTsp(Instant.now().minusSeconds(5L * 60).toEpochMilli());
            StreamRecord<UserPreference> streamRecord1 = new StreamRecord<>(secondaryUser);
            testHarness.processElement2(streamRecord1);

            MapState<String, Map<String, UserPreference>> preferencesStateMap = getPreferencesStateMap(testHarness);

            Map<String, UserPreference> preferences = preferencesStateMap.get(TripData.VIRTUAL_ID);

            Assert.assertNotNull(preferences);
            Assert.assertEquals(1, preferences.size());

            TripWrapper tripWrapper = TripData.getTripStartWrapper(TripData.VIRTUAL_ID, Tenant.EV, 1, 2);
            TripData.addUserDetailsToTripWrapper(tripWrapper, secondaryUser);
            StreamRecord<TripWrapper> streamRecord2 = new StreamRecord<>(tripWrapper);
            testHarness.processElement1(streamRecord2);

            List<TripWrapper> output = TripData.getCollectedData(testHarness.getRecordOutput());
            Assert.assertEquals(1, output.size());
            TripWrapper existingTripWrapper = output.get(0);
            TripStart tripStart = existingTripWrapper.getTripStart();
            Assert.assertEquals(secondaryUser.getProfileId(), tripStart.getUserId());
            Assert.assertEquals(ProfileType.SECONDARY.value(), tripStart.getUserProfile());
            Assert.assertEquals(secondaryUser.getProfileName(), tripStart.getUserName());
            Assert.assertEquals(UserDetailsSource.SECONDARY_DEFAULT.getValue(), tripStart.getUserDetailsSource());

        } catch (Exception e) {
            throw new RuntimeException(e);
        }

    }

    @Test
    public void testEnrichTripWithUserDetailsFunction_tripEnd_expiredSecondaryUser_noPrimaryUserPresent() {

        try(KeyedTwoInputStreamOperatorTestHarness<String, TripWrapper, UserPreference, TripWrapper> testHarness = testHarness()) {

            testHarness.setup();
            testHarness.open();

            UserPreference secondaryUser = UserPreferenceGenerator.getSecondaryUser(TripData.VIRTUAL_ID);
            secondaryUser.setAccessValidTillTsp(Instant.now().minusSeconds(5L * 60).toEpochMilli());
            StreamRecord<UserPreference> streamRecord1 = new StreamRecord<>(secondaryUser);
            testHarness.processElement2(streamRecord1);

            MapState<String, Map<String, UserPreference>> preferencesStateMap = getPreferencesStateMap(testHarness);

            Map<String, UserPreference> preferences = preferencesStateMap.get(TripData.VIRTUAL_ID);

            Assert.assertNotNull(preferences);
            Assert.assertEquals(1, preferences.size());

            TripWrapper tripWrapper = TripData.getTripEndWrapper(TripData.VIRTUAL_ID, Tenant.EV, 1, 2);
            TripData.addUserDetailsToTripWrapper(tripWrapper, secondaryUser);
            StreamRecord<TripWrapper> streamRecord2 = new StreamRecord<>(tripWrapper);
            testHarness.processElement1(streamRecord2);

            List<TripWrapper> output = TripData.getCollectedData(testHarness.getRecordOutput());
            Assert.assertEquals(1, output.size());
            TripWrapper existingTripWrapper = output.get(0);
            TripEnd tripEnd = existingTripWrapper.getTripEnd();
            Assert.assertEquals(secondaryUser.getProfileId(), tripEnd.getUserId());
            Assert.assertEquals(ProfileType.SECONDARY.value(), tripEnd.getUserProfile());
            Assert.assertEquals(secondaryUser.getProfileName(), tripEnd.getUserName());
            Assert.assertEquals(UserDetailsSource.SECONDARY_DEFAULT.getValue(), tripEnd.getUserDetailsSource());

        } catch (Exception e) {
            throw new RuntimeException(e);
        }

    }

    @Test
    public void testEnrichTripWithUserDetailsFunction_tripBreak_expiredSecondaryUser_noPrimaryUserPresent() {

        try(KeyedTwoInputStreamOperatorTestHarness<String, TripWrapper, UserPreference, TripWrapper> testHarness = testHarness()) {

            testHarness.setup();
            testHarness.open();

            UserPreference secondaryUser = UserPreferenceGenerator.getSecondaryUser(TripData.VIRTUAL_ID);
            secondaryUser.setAccessValidTillTsp(Instant.now().minusSeconds(5L * 60).toEpochMilli());
            StreamRecord<UserPreference> streamRecord1 = new StreamRecord<>(secondaryUser);
            testHarness.processElement2(streamRecord1);

            MapState<String, Map<String, UserPreference>> preferencesStateMap = getPreferencesStateMap(testHarness);

            Map<String, UserPreference> preferences = preferencesStateMap.get(TripData.VIRTUAL_ID);

            Assert.assertNotNull(preferences);
            Assert.assertEquals(1, preferences.size());

            TripWrapper tripWrapper = TripData.getTripBreakWrapper(TripData.VIRTUAL_ID, Tenant.EV, 1, 2);
            TripData.addUserDetailsToTripWrapper(tripWrapper, secondaryUser);
            StreamRecord<TripWrapper> streamRecord2 = new StreamRecord<>(tripWrapper);
            testHarness.processElement1(streamRecord2);

            List<TripWrapper> output = TripData.getCollectedData(testHarness.getRecordOutput());
            Assert.assertEquals(1, output.size());
            TripWrapper existingTripWrapper = output.get(0);
            TripBreak tripBreak = existingTripWrapper.getTripBreak();
            Assert.assertEquals(secondaryUser.getProfileId(), tripBreak.getUserId());
            Assert.assertEquals(ProfileType.SECONDARY.value(), tripBreak.getUserProfile());
            Assert.assertEquals(secondaryUser.getProfileName(), tripBreak.getUserName());
            Assert.assertEquals(UserDetailsSource.SECONDARY_DEFAULT.getValue(), tripBreak.getUserDetailsSource());

        } catch (Exception e) {
            throw new RuntimeException(e);
        }

    }

    @Test
    public void testEnrichTripWithUserDetailsFunction_tripBreakEvent_expiredSecondaryUser_noPrimaryUserPresent() {

        try(KeyedTwoInputStreamOperatorTestHarness<String, TripWrapper, UserPreference, TripWrapper> testHarness = testHarness()) {

            testHarness.setup();
            testHarness.open();

            UserPreference secondaryUser = UserPreferenceGenerator.getSecondaryUser(TripData.VIRTUAL_ID);
            secondaryUser.setAccessValidTillTsp(Instant.now().minusSeconds(5L * 60).toEpochMilli());
            StreamRecord<UserPreference> streamRecord1 = new StreamRecord<>(secondaryUser);
            testHarness.processElement2(streamRecord1);

            MapState<String, Map<String, UserPreference>> preferencesStateMap = getPreferencesStateMap(testHarness);

            Map<String, UserPreference> preferences = preferencesStateMap.get(TripData.VIRTUAL_ID);

            Assert.assertNotNull(preferences);
            Assert.assertEquals(1, preferences.size());

            TripWrapper tripWrapper =  new TripWrapper();
            tripWrapper.setNeededForTripBreak(true);
            tripWrapper.setTripId(TripData.getTripId());
            tripWrapper.setVirtualId(TripData.VIRTUAL_ID);
            TripData.addUserDetailsToTripWrapper(tripWrapper, secondaryUser);

            StreamRecord<TripWrapper> streamRecord2 = new StreamRecord<>(tripWrapper);
            testHarness.processElement1(streamRecord2);

            List<TripWrapper> output = TripData.getCollectedData(testHarness.getRecordOutput());
            Assert.assertEquals(1, output.size());
            TripWrapper existingTripWrapper = output.get(0);
            UserDetails userDetails = existingTripWrapper.getUserDetails();
            Assert.assertEquals(secondaryUser.getProfileId(), userDetails.getUserId());
            Assert.assertEquals(ProfileType.SECONDARY.value(), userDetails.getUserProfile());
            Assert.assertEquals(secondaryUser.getProfileName(), userDetails.getUserName());
            Assert.assertEquals(UserDetailsSource.SECONDARY_DEFAULT.getValue(), userDetails.getSource());

        } catch (Exception e) {
            throw new RuntimeException(e);
        }

    }

    @Test
    public void testEnrichTripWithUserDetailsFunction_tripStart_defaultToRider() {

        try(KeyedTwoInputStreamOperatorTestHarness<String, TripWrapper, UserPreference, TripWrapper> testHarness = riderTestHarness()) {

            testHarness.setup();
            testHarness.open();

            UserPreference secondaryRider = UserPreferenceGenerator.getSecondaryUser(TripData.VIRTUAL_ID);
            secondaryRider.setIsRider(true);
            StreamRecord<UserPreference> streamRecord1 = new StreamRecord<>(secondaryRider);

            testHarness.processElement2(streamRecord1);

            UserPreference primaryUser = UserPreferenceGenerator.getPrimaryUser(TripData.VIRTUAL_ID);
            StreamRecord<UserPreference> streamRecord2 = new StreamRecord<>(primaryUser);

            testHarness.processElement2(streamRecord2);

            MapState<String, Map<String, UserPreference>> preferencesStateMap = getPreferencesStateMap(testHarness);

            Map<String, UserPreference> preferences = preferencesStateMap.get(TripData.VIRTUAL_ID);

            Assert.assertNotNull(preferences);
            Assert.assertEquals(2, preferences.size());
            UserPreference stateValue = preferences.getOrDefault(secondaryRider.getProfileId(), null);
            Assert.assertNotNull(stateValue);

            TripWrapper tripWrapper = TripData.getTripStartWrapper(TripData.VIRTUAL_ID, Tenant.EV, 1, 2);
            tripWrapper.setUserDetails(null);
            StreamRecord<TripWrapper> streamRecord3 = new StreamRecord<>(tripWrapper);
            testHarness.processElement1(streamRecord3);

            List<TripWrapper> output = TripData.getCollectedData(testHarness.getRecordOutput());
            Assert.assertEquals(1, output.size());
            TripWrapper existingTripWrapper = output.get(0);
            TripStart tripStart = existingTripWrapper.getTripStart();
            Assert.assertEquals(secondaryRider.getProfileId(), tripStart.getUserId());
            Assert.assertEquals(ProfileType.SECONDARY.value(), tripStart.getUserProfile());
            Assert.assertEquals(secondaryRider.getProfileName(), tripStart.getUserName());
            Assert.assertEquals(UserDetailsSource.CURRENT_RIDER_DEFAULT.getValue(), tripStart.getUserDetailsSource());

        } catch (Exception e) {
            throw new RuntimeException(e);
        }

    }

    @Test
    public void testEnrichTripWithUserDetailsFunction_tripEnd_defaultToRider() {

        try(KeyedTwoInputStreamOperatorTestHarness<String, TripWrapper, UserPreference, TripWrapper> testHarness = riderTestHarness()) {

            testHarness.setup();
            testHarness.open();

            UserPreference secondaryRider = UserPreferenceGenerator.getSecondaryUser(TripData.VIRTUAL_ID);
            secondaryRider.setIsRider(true);
            StreamRecord<UserPreference> streamRecord1 = new StreamRecord<>(secondaryRider);

            testHarness.processElement2(streamRecord1);

            UserPreference primaryUser = UserPreferenceGenerator.getPrimaryUser(TripData.VIRTUAL_ID);
            StreamRecord<UserPreference> streamRecord2 = new StreamRecord<>(primaryUser);

            testHarness.processElement2(streamRecord2);

            MapState<String, Map<String, UserPreference>> preferencesStateMap = getPreferencesStateMap(testHarness);

            Map<String, UserPreference> preferences = preferencesStateMap.get(TripData.VIRTUAL_ID);

            Assert.assertNotNull(preferences);
            Assert.assertEquals(2, preferences.size());
            UserPreference stateValue = preferences.getOrDefault(secondaryRider.getProfileId(), null);
            Assert.assertNotNull(stateValue);

            TripWrapper tripWrapper = TripData.getTripEndWrapper(TripData.VIRTUAL_ID, Tenant.EV, 1, 2);
            tripWrapper.setUserDetails(null);
            StreamRecord<TripWrapper> streamRecord3 = new StreamRecord<>(tripWrapper);
            testHarness.processElement1(streamRecord3);

            List<TripWrapper> output = TripData.getCollectedData(testHarness.getRecordOutput());
            Assert.assertEquals(1, output.size());
            TripWrapper existingTripWrapper = output.get(0);
            TripEnd tripEnd = existingTripWrapper.getTripEnd();
            Assert.assertEquals(secondaryRider.getProfileId(), tripEnd.getUserId());
            Assert.assertEquals(ProfileType.SECONDARY.value(), tripEnd.getUserProfile());
            Assert.assertEquals(secondaryRider.getProfileName(), tripEnd.getUserName());
            Assert.assertEquals(UserDetailsSource.CURRENT_RIDER_DEFAULT.getValue(), tripEnd.getUserDetailsSource());

        } catch (Exception e) {
            throw new RuntimeException(e);
        }

    }

    @Test
    public void testEnrichTripWithUserDetailsFunction_tripBreak_defaultToRider() {

        try(KeyedTwoInputStreamOperatorTestHarness<String, TripWrapper, UserPreference, TripWrapper> testHarness = riderTestHarness()) {

            testHarness.setup();
            testHarness.open();

            UserPreference secondaryRider = UserPreferenceGenerator.getSecondaryUser(TripData.VIRTUAL_ID);
            secondaryRider.setIsRider(true);
            StreamRecord<UserPreference> streamRecord1 = new StreamRecord<>(secondaryRider);

            testHarness.processElement2(streamRecord1);

            UserPreference primaryUser = UserPreferenceGenerator.getPrimaryUser(TripData.VIRTUAL_ID);
            StreamRecord<UserPreference> streamRecord2 = new StreamRecord<>(primaryUser);

            testHarness.processElement2(streamRecord2);

            MapState<String, Map<String, UserPreference>> preferencesStateMap = getPreferencesStateMap(testHarness);

            Map<String, UserPreference> preferences = preferencesStateMap.get(TripData.VIRTUAL_ID);

            Assert.assertNotNull(preferences);
            Assert.assertEquals(2, preferences.size());
            UserPreference stateValue = preferences.getOrDefault(secondaryRider.getProfileId(), null);
            Assert.assertNotNull(stateValue);

            TripWrapper tripWrapper = TripData.getTripBreakWrapper(TripData.VIRTUAL_ID, Tenant.EV, 1, 2);
            tripWrapper.setUserDetails(null);
            StreamRecord<TripWrapper> streamRecord3 = new StreamRecord<>(tripWrapper);
            testHarness.processElement1(streamRecord3);

            List<TripWrapper> output = TripData.getCollectedData(testHarness.getRecordOutput());
            Assert.assertEquals(1, output.size());
            TripWrapper existingTripWrapper = output.get(0);
            TripBreak tripBreak = existingTripWrapper.getTripBreak();
            Assert.assertEquals(secondaryRider.getProfileId(), tripBreak.getUserId());
            Assert.assertEquals(ProfileType.SECONDARY.value(), tripBreak.getUserProfile());
            Assert.assertEquals(secondaryRider.getProfileName(), tripBreak.getUserName());
            Assert.assertEquals(UserDetailsSource.CURRENT_RIDER_DEFAULT.getValue(), tripBreak.getUserDetailsSource());

        } catch (Exception e) {
            throw new RuntimeException(e);
        }

    }

    @Test
    public void testEnrichTripWithUserDetailsFunction_tripBreakEvent_defaultToRider() {

        try(KeyedTwoInputStreamOperatorTestHarness<String, TripWrapper, UserPreference, TripWrapper> testHarness = riderTestHarness()) {

            testHarness.setup();
            testHarness.open();

            UserPreference secondaryRider = UserPreferenceGenerator.getSecondaryUser(TripData.VIRTUAL_ID);
            secondaryRider.setIsRider(true);
            StreamRecord<UserPreference> streamRecord1 = new StreamRecord<>(secondaryRider);

            testHarness.processElement2(streamRecord1);

            UserPreference primaryUser = UserPreferenceGenerator.getPrimaryUser(TripData.VIRTUAL_ID);
            StreamRecord<UserPreference> streamRecord2 = new StreamRecord<>(primaryUser);

            testHarness.processElement2(streamRecord2);

            MapState<String, Map<String, UserPreference>> preferencesStateMap = getPreferencesStateMap(testHarness);

            Map<String, UserPreference> preferences = preferencesStateMap.get(TripData.VIRTUAL_ID);

            Assert.assertNotNull(preferences);
            Assert.assertEquals(2, preferences.size());
            UserPreference stateValue = preferences.getOrDefault(secondaryRider.getProfileId(), null);
            Assert.assertNotNull(stateValue);

            TripWrapper tripWrapper =  new TripWrapper();
            tripWrapper.setNeededForTripBreak(true);
            tripWrapper.setTripId(TripData.getTripId());
            tripWrapper.setVirtualId(TripData.VIRTUAL_ID);
            tripWrapper.setUserDetails(null);

            StreamRecord<TripWrapper> streamRecord3 = new StreamRecord<>(tripWrapper);
            testHarness.processElement1(streamRecord3);

            List<TripWrapper> output = TripData.getCollectedData(testHarness.getRecordOutput());
            Assert.assertEquals(1, output.size());
            TripWrapper existingTripWrapper = output.get(0);
            UserDetails userDetails = existingTripWrapper.getUserDetails();
            Assert.assertEquals(secondaryRider.getProfileId(), userDetails.getUserId());
            Assert.assertEquals(ProfileType.SECONDARY.value(), userDetails.getUserProfile());
            Assert.assertEquals(secondaryRider.getProfileName(), userDetails.getUserName());
            Assert.assertEquals(UserDetailsSource.CURRENT_RIDER_DEFAULT.getValue(), userDetails.getSource());

        } catch (Exception e) {
            throw new RuntimeException(e);
        }

    }
}
