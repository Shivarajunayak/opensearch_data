package org.hmcl.cvp.dataplatform.tripanalytics.helper;

import com.google.gson.Gson;
import lombok.extern.slf4j.Slf4j;
import org.apache.flink.api.java.tuple.Tuple2;
import org.hmcl.cvp.dataplatform.commons.catalogue.SignalCatalogue;
import org.hmcl.cvp.dataplatform.commons.utils.DateUtils;
import org.hmcl.cvp.dataplatform.commons.utils.GsonUtils;
import org.hmcl.cvp.dataplatform.commons.utils.SignalUtils;
import org.hmcl.cvp.dataplatform.commons.utils.TelemetryUtils;
import org.hmcl.cvp.dataplatform.contract.telemetry.SignalData;
import org.hmcl.cvp.dataplatform.contract.telemetry.Telemetry;
import org.hmcl.cvp.dataplatform.contract.telemetry.Tenant;
import org.hmcl.cvp.dataplatform.contract.userpreference.ProfileType;
import org.hmcl.cvp.dataplatform.tripanalytics.contract.*;

import java.time.Instant;
import java.util.*;
import java.util.stream.Collectors;

@Slf4j
public class TripAnalyticsHelper {

    private static final Gson GSON = GsonUtils.getGson();

    public static final String DEFAULT_STRING_VALUE = "";
    public static final Double DEFAULT_DOUBLE_VALUE = -1.0;
    public static final int DEFAULT_INTEGER_VALUE = -1;

    public static final int PRIMARY_PROFILE = 1;
    public static final int SECONDARY_PROFILE = 2;

    private TripAnalyticsHelper() {}

    public static boolean isIgnitionRiseCampaign(Telemetry telemetry) {
        String campaignName = telemetry.getCampaignName();
        if(Objects.isNull(campaignName)) return false;

        return campaignName.toLowerCase().contains(TripCampaign.IGNITION_RISE.getValue());
    }

    public static boolean isIgnitionFallCampaign(Telemetry telemetry) {
        String campaignName = telemetry.getCampaignName();
        if(Objects.isNull(campaignName)) return false;

        return campaignName.toLowerCase().contains(TripCampaign.IGNITION_FALL.getValue());
    }

    public static boolean isPartOfIgnitionCampaigns(Telemetry telemetry) {
        return isIgnitionRiseCampaign(telemetry) || isIgnitionFallCampaign(telemetry);
    }

    // Trip start signals will sort in ascending order
    public static List<SignalData> getTripStartSignals(Telemetry value) {
        Set<SignalData> signals = SignalUtils.getSignals(value, SignalCatalogue.getTripStartFlag());
        List<SignalData> signalList = signals.isEmpty() ? new ArrayList<>() : new ArrayList<>(signals);
        return signalList.stream().sorted(Comparator.comparing(SignalData::getTime)).collect(Collectors.toList());
    }

    public static TripStartSignal getTripStartSignalValue(SignalData signal) {
        String value = String.valueOf(signal.getValue());
        if(Objects.isNull(value)) return null;

        return GSON.fromJson(value, TripStartSignal.class);
    }

    public static TripEndSignal getTripEndSignalValue(SignalData signal) {
        String value = String.valueOf(signal.getValue());
        if(Objects.isNull(value)) return null;

        return GSON.fromJson(value, TripEndSignal.class);
    }

    // Trip end signals will sort in ascending order
    public static List<SignalData> getTripEndSignals(Telemetry value) {
        Set<SignalData> signals = SignalUtils.getSignals(value, SignalCatalogue.getTripEndFlag());
        List<SignalData> signalList = signals.isEmpty() ? new ArrayList<>() : new ArrayList<>(signals);
        return signalList.stream().sorted(Comparator.comparing(SignalData::getTime)).collect(Collectors.toList());
    }

    public static List<TripSignalData> getTripSignals(List<SignalData> tripStartFlagSignals, List<SignalData> tripEndFlagSignals) {
        List<TripSignalData> startTripSignalWrappers = tripStartFlagSignals.stream()
                .map(t -> TripSignalData.builder()
                        .isTripStartSignal(true)
                        .signalData(t)
                        .time(t.getTime())
                        .build())
                .collect(Collectors.toList());

        List<TripSignalData> endTripSignalWrappers = tripEndFlagSignals.stream()
                .map(t -> TripSignalData.builder()
                        .isTripEndSignal(true)
                        .signalData(t)
                        .time(t.getTime())
                        .build())
                .collect(Collectors.toList());

        List<TripSignalData> allTripSignals = new ArrayList<>(startTripSignalWrappers);
        allTripSignals.addAll(endTripSignalWrappers);

        return allTripSignals.stream().sorted(Comparator.comparing(TripSignalData::getTime)).collect(Collectors.toList());

    }

    public static Tuple2<Boolean, Double> getLatestLongitude(Telemetry value) {
        Set<SignalData> signals = SignalUtils.getNonNullSignals(value, SignalCatalogue.getLongitudeInfo());
        boolean valuePresent = !signals.isEmpty();
        return new Tuple2<>(valuePresent, SignalUtils.getLatestSignalValue(signals));
    }

    public static Tuple2<Boolean, Double> getLatestLatitude(Telemetry value) {
        Set<SignalData> signals = SignalUtils.getNonNullSignals(value, SignalCatalogue.getLatitudeInfo());
        boolean valuePresent = !signals.isEmpty();
        return new Tuple2<>(valuePresent, SignalUtils.getLatestSignalValue(signals));
    }

    public static Tuple2<Boolean, Integer> getLatestGpsFix(Telemetry value) {
        Set<SignalData> signals = SignalUtils.getNonNullSignals(value, SignalCatalogue.getGpsFixInfo());
        return SignalUtils.getLatestIntegerValue(signals);
    }

    public static Tuple2<Boolean, Integer> getEarliestGpsFix(Telemetry value) {
        Set<SignalData> signals = SignalUtils.getNonNullSignals(value, SignalCatalogue.getGpsFixInfo());
        return SignalUtils.getEarliestIntegerValue(signals);
    }

    public static Tuple2<Boolean, Boolean> getLatestGpsValid(Telemetry value) {
        Set<SignalData> signals = SignalUtils.getNonNullSignals(value, SignalCatalogue.getGpsValidInfo());
        boolean valuePresent = !signals.isEmpty();
        return new Tuple2<>(valuePresent, SignalUtils.getLatestSignalBooleanValue(signals));
    }

    public static Tuple2<Boolean, Boolean> getEarliestGpsValid(Telemetry value) {
        Set<SignalData> signals = SignalUtils.getNonNullSignals(value, SignalCatalogue.getGpsValidInfo());
        boolean valuePresent = !signals.isEmpty();
        return new Tuple2<>(valuePresent, SignalUtils.getEarliestSignalBooleanValue(signals));
    }

    public static Tuple2<Boolean, Double> getLatestPDop(Telemetry value) {
        Set<SignalData> signals = SignalUtils.getNonNullSignals(value, SignalCatalogue.getPDopInfo());
        boolean valuePresent = !signals.isEmpty();
        return new Tuple2<>(valuePresent, SignalUtils.getLatestSignalValue(signals));
    }

    public static Tuple2<Boolean, Double> getLatestVDop(Telemetry value) {
        Set<SignalData> signals = SignalUtils.getNonNullSignals(value, SignalCatalogue.getVDopInfo());
        boolean valuePresent = !signals.isEmpty();
        return new Tuple2<>(valuePresent, SignalUtils.getLatestSignalValue(signals));
    }

    public static Tuple2<Boolean, Double> getEarliestVDop(Telemetry value) {
        Set<SignalData> signals = SignalUtils.getNonNullSignals(value, SignalCatalogue.getVDopInfo());
        boolean valuePresent = !signals.isEmpty();
        return new Tuple2<>(valuePresent, SignalUtils.getEarliestSignalValue(signals));
    }

    public static Tuple2<Boolean, Integer> getLatestAmbientTemperature(Telemetry value) {
        Set<SignalData> signals = SignalUtils.getNonNullSignals(value, SignalCatalogue.getAmbientTemperatureInfo());
        return SignalUtils.getLatestIntegerValue(signals);
    }

    public static Tuple2<Boolean, Integer> getEarliestAmbientTemperature(Telemetry value) {
        Set<SignalData> signals = SignalUtils.getNonNullSignals(value, SignalCatalogue.getAmbientTemperatureInfo());
        return SignalUtils.getEarliestIntegerValue(signals);
    }

    public static Tuple2<Boolean, Double> getLatestBatteryTemperature1(Telemetry value) {
        Set<SignalData> signals = SignalUtils.getNonNullSignals(value, SignalCatalogue.getBMS1BatteryPackTempInfo());
        boolean valuePresent = !signals.isEmpty();
        return new Tuple2<>(valuePresent, SignalUtils.getLatestSignalValue(signals));
    }

    public static Tuple2<Boolean, Double> getEarliestBatteryTemperature1(Telemetry value) {
        Set<SignalData> signals = SignalUtils.getNonNullSignals(value, SignalCatalogue.getBMS1BatteryPackTempInfo());
        boolean valuePresent = !signals.isEmpty();
        return new Tuple2<>(valuePresent, SignalUtils.getEarliestSignalValue(signals));
    }

    public static Tuple2<Boolean, Double> getLatestBatteryTemperature2(Telemetry value) {
        Set<SignalData> signals = SignalUtils.getNonNullSignals(value, SignalCatalogue.getBMS2BatteryPackTempInfo());
        boolean valuePresent = !signals.isEmpty();
        return new Tuple2<>(valuePresent, SignalUtils.getLatestSignalValue(signals));
    }

    public static Tuple2<Boolean, Double> getEarliestBatteryTemperature2(Telemetry value) {
        Set<SignalData> signals = SignalUtils.getNonNullSignals(value, SignalCatalogue.getBMS2BatteryPackTempInfo());
        boolean valuePresent = !signals.isEmpty();
        return new Tuple2<>(valuePresent, SignalUtils.getEarliestSignalValue(signals));
    }

    public static Tuple2<Boolean, Double> getLatestFuelValue(Telemetry value) {
        Set<SignalData> signals = SignalUtils.getNonNullSignals(value, SignalCatalogue.getFuelLevelInfo());
        boolean valuePresent = !signals.isEmpty();
        return new Tuple2<>(valuePresent, SignalUtils.getLatestSignalValue(signals));
    }

    public static Tuple2<Boolean, Double> getEarliestFuelValue(Telemetry value) {
        Set<SignalData> signals = SignalUtils.getNonNullSignals(value, SignalCatalogue.getFuelLevelInfo());
        boolean valuePresent = !signals.isEmpty();
        return new Tuple2<>(valuePresent, SignalUtils.getEarliestSignalValue(signals));
    }

    public static Tuple2<Boolean, Integer> getLatestUsableEnergy(Telemetry value) {
        Set<SignalData> signals = SignalUtils.getNonNullSignals(value, SignalCatalogue.getTotalUsableEnergyInfo());
        return SignalUtils.getLatestIntegerValue(signals);
    }

    public static Tuple2<Boolean, Integer> getEarliestUsableEnergy(Telemetry value) {
        Set<SignalData> signals = SignalUtils.getNonNullSignals(value, SignalCatalogue.getTotalUsableEnergyInfo());
        return SignalUtils.getEarliestIntegerValue(signals);
    }

    public static Tuple2<Boolean, Integer> getLatestUsableCapacity(Telemetry value) {
        Set<SignalData> signals = SignalUtils.getNonNullSignals(value, SignalCatalogue.getTotalUsableCapacityInfo());
        return SignalUtils.getLatestIntegerValue(signals);
    }

    public static Tuple2<Boolean, Integer> getEarliestUsableCapacity(Telemetry value) {
        Set<SignalData> signals = SignalUtils.getNonNullSignals(value, SignalCatalogue.getTotalUsableCapacityInfo());
        return SignalUtils.getEarliestIntegerValue(signals);
    }

    public static Tuple2<Boolean, Integer> getLatestRemainingRange(Telemetry value) {
        Set<SignalData> signals = SignalUtils.getNonNullSignals(value, SignalCatalogue.getRemainingRangeInfo());
        return SignalUtils.getLatestIntegerValue(signals);
    }

    public static Tuple2<Boolean, Integer> getEarliestRemainingRange(Telemetry value) {
        Set<SignalData> signals = SignalUtils.getNonNullSignals(value, SignalCatalogue.getRemainingRangeInfo());
        return SignalUtils.getEarliestIntegerValue(signals);
    }

    public static Tuple2<Boolean, Double> getLatestSoc(Telemetry value) {
        Set<SignalData> signals = SignalUtils.getNonNullSignals(value, SignalCatalogue.getSocUserPercentageInfo());
        boolean valuePresent = !signals.isEmpty();
        return new Tuple2<>(valuePresent, SignalUtils.getLatestSignalValue(signals));
    }

    public static Tuple2<Boolean, Double> getEarliestSoc(Telemetry value) {
        Set<SignalData> signals = SignalUtils.getNonNullSignals(value, SignalCatalogue.getSocUserPercentageInfo());
        boolean valuePresent = !signals.isEmpty();
        return new Tuple2<>(valuePresent, SignalUtils.getEarliestSignalValue(signals));
    }

    public static Tuple2<Boolean, Double> getLatestSoc1(Telemetry value) {
        Set<SignalData> signals = SignalUtils.getNonNullSignals(value, SignalCatalogue.getSocUserBMS1Info());
        boolean valuePresent = !signals.isEmpty();
        return new Tuple2<>(valuePresent, SignalUtils.getLatestSignalValue(signals));
    }

    public static Tuple2<Boolean, Double> getLatestSoc2(Telemetry value) {
        Set<SignalData> signals = SignalUtils.getNonNullSignals(value, SignalCatalogue.getSocUserBMS2Info());
        boolean valuePresent = !signals.isEmpty();
        return new Tuple2<>(valuePresent, SignalUtils.getLatestSignalValue(signals));
    }

    public static Tuple2<Boolean, Double> getLatestOdometerReading(Telemetry value) {
        Set<SignalData> signals = SignalUtils.getNonNullSignals(value, SignalCatalogue.getOdometerHRInfo());
        boolean valuePresent = !signals.isEmpty();
        return new Tuple2<>(valuePresent, SignalUtils.getLatestSignalValue(signals));
    }

    public static Tuple2<Boolean, String> getUserId(Telemetry telemetry) {
        Set<SignalData> userIdSignals = SignalUtils.getNonNullSignals(telemetry, SignalCatalogue.getUserIdInfo());
        boolean valuePresent = !userIdSignals.isEmpty();

        Optional<SignalData> signalData = SignalUtils.getLatestSignal(userIdSignals);
        if (signalData.isEmpty()) {
            return new Tuple2<>(false, null);
        }
        String userId = String.valueOf(signalData.get().getValue());

        return new Tuple2<>(valuePresent, userId);
    }

    public static Tuple2<Boolean, Integer> getUserProfile(Telemetry telemetry) {
        Set<SignalData> userIdSignals = SignalUtils.getNonNullSignals(telemetry, SignalCatalogue.getUserProfileInfo());
        boolean valuePresent = !userIdSignals.isEmpty();

        Optional<SignalData> signalData = SignalUtils.getLatestSignal(userIdSignals);
        if (signalData.isEmpty()) {
            return new Tuple2<>(false, null);
        }

        int userProfileValue = SignalUtils.getIntegerSignalValue(signalData.get());

        return new Tuple2<>(valuePresent, userProfileValue);
    }

    public static Tuple2<Boolean, String> getLatestVehicleMode(Telemetry telemetry) {
        Set<SignalData> drivingModeSignals = SignalUtils.getNonNullSignals(telemetry, SignalCatalogue.getDrivingModeInfo());
        boolean valuePresent = !drivingModeSignals.isEmpty();

        int value = getLatestIntValue(drivingModeSignals);
        String mode = getVehicleMode(value);

        return new Tuple2<>(valuePresent, mode);
    }

    public static Tuple2<Boolean, String> getEarliestVehicleMode(Telemetry telemetry) {
        Set<SignalData> drivingModeSignals = SignalUtils.getNonNullSignals(telemetry, SignalCatalogue.getDrivingModeInfo());
        boolean valuePresent = !drivingModeSignals.isEmpty();

        int value = getEarliestIntValue(drivingModeSignals);
        String mode = getVehicleMode(value);

        return new Tuple2<>(valuePresent, mode);
    }

    public static String getVehicleMode(int vehicleMode) {
        String mode;

        switch (vehicleMode) {
            case 0:
                mode = "eco";
                break;
            case 1:
                mode = "ride";
                break;
            case 2:
                mode = "sport";
                break;
            case 3:
                mode = "park";
                break;
            case 4:
            case 5:
            case 6:
            case 7:
                mode = "telltale blink";
                break;
            case 8:
                mode = "all segment on";
                break;
            case 9:
                mode = "all segment off";
                break;
            case 10:
                mode = "all blink";
                break;
            case 12:
                mode = "safe";
                break;
            case 13:
                mode = "boost";
                break;
            default:
                mode = "na";
        }

        return mode;
    }

    public static UserDetails getUserDetails(Telemetry value) {

        Tuple2<Boolean, String> userId = getUserId(value);
        String userIdValue = Boolean.TRUE.equals(userId.f0) ? userId.f1 : DEFAULT_STRING_VALUE;


        Tuple2<Boolean, Integer> userProfile = getUserProfile(value);
        Integer userProfileValue = Boolean.TRUE.equals(userProfile.f0) ? userProfile.f1 : DEFAULT_INTEGER_VALUE;

        return UserDetails.builder()
                .userId(userIdValue)
                .userProfile(getProfileType(userProfileValue))
                .valid(!DEFAULT_STRING_VALUE.equalsIgnoreCase(userIdValue))
                .build();
    }

    public static UserDetails getUserDetails(Telemetry value, String userId, Integer userProfile) {

        if(Objects.isNull(userId)) {
            Tuple2<Boolean, String> userIdTuple = getUserId(value);
            userId = Boolean.TRUE.equals(userIdTuple.f0) ? userIdTuple.f1 : DEFAULT_STRING_VALUE;
        }

        if(Objects.isNull(userProfile)) {
            Tuple2<Boolean, Integer> userProfileTuple = getUserProfile(value);
            userProfile = Boolean.TRUE.equals(userProfileTuple.f0) ? userProfileTuple.f1 : DEFAULT_INTEGER_VALUE;
        }

        return UserDetails.builder()
                .userId(userId)
                .userProfile(getProfileType(userProfile))
                .valid(!DEFAULT_STRING_VALUE.equalsIgnoreCase(userId))
                .build();

    }

    public static TripStart createTripStart(String vid, String tripId, TripStartSignal tripStartSignal, Telemetry value, boolean fromTripEnd) {
        TripStart tripStart = new TripStart();
        Tenant tenant = TelemetryUtils.getTenant(value);
        tripStart.setVirtualId(vid);
        tripStart.setTripId(tripId);
        tripStart.setCampaignName(value.getCampaignName());
        tripStart.setTenantId(TelemetryUtils.getTenantId(value));
        tripStart.setB2bClientId(TelemetryUtils.getB2BClientId(value));
        tripStart.setSourceTimestamp(tripStartSignal.getTimestamp());
        tripStart.setTimestamp(DateUtils.formatToISO(tripStartSignal.getTimestamp()));
        tripStart.setCollectionEventTime(value.getCollectionEventTime());
        tripStart.setCollectionEventTimeTS(DateUtils.formatToISO(value.getCollectionEventTime()));

        if(fromTripEnd) {
            tripStart.setTripSource(TripStartSource.TRIP_END_SIGNAL.getValue());
        } else {
            tripStart.setTripSource(TripStartSource.TRIP_START_SIGNAL.getValue());
        }

        long instant = Instant.now().toEpochMilli();
        tripStart.setProcessingTime(instant);
        tripStart.setProcessingTimeTS(DateUtils.formatToISO(instant));

        // Set all the signals from telemetry
        Tuple2<Boolean, Integer> gpsFIx = getEarliestGpsFix(value);
        if(Boolean.TRUE.equals(gpsFIx.f0)) tripStart.setGpsFix(gpsFIx.f1);

        Tuple2<Boolean, Boolean> gpsValid = getEarliestGpsValid(value);
        if(Boolean.TRUE.equals(gpsValid.f0)) tripStart.setGpsValid(gpsValid.f1);

        Tuple2<Boolean, Integer> ambientTemperature = getEarliestAmbientTemperature(value);
        if(Boolean.TRUE.equals(ambientTemperature.f0)) tripStart.setAmbientTemperature(Double.valueOf(ambientTemperature.f1));

        Tuple2<Boolean, Double> batteryTemperature1 = getEarliestBatteryTemperature1(value);
        if(Boolean.TRUE.equals(batteryTemperature1.f0)) tripStart.setBatteryTemperature1(batteryTemperature1.f1);

        Tuple2<Boolean, Double> batteryTemperature2 = getEarliestBatteryTemperature2(value);
        if(Boolean.TRUE.equals(batteryTemperature2.f0)) tripStart.setBatteryTemperature2(batteryTemperature2.f1);

        Tuple2<Boolean, Double> soc = getEarliestSoc(value);
        if(Boolean.TRUE.equals(soc.f0) && tenant.equals(Tenant.EV)) tripStart.setSoc(soc.f1);

        Tuple2<Boolean, String> vehicleMode = getEarliestVehicleMode(value);
        if(Boolean.TRUE.equals(vehicleMode.f0)) tripStart.setVehicleMode(vehicleMode.f1);

        Tuple2<Boolean, Integer> usableEnergy = getEarliestUsableEnergy(value);
        if(Boolean.TRUE.equals(usableEnergy.f0)) tripStart.setUsableEnergy(Double.valueOf(usableEnergy.f1));

        Tuple2<Boolean, Integer> usableCapacity = getEarliestUsableCapacity(value);
        if(Boolean.TRUE.equals(usableCapacity.f0)) tripStart.setUsableCapacity(Double.valueOf(usableCapacity.f1));

        Tuple2<Boolean, Double> fuel = getEarliestFuelValue(value);
        if(Boolean.TRUE.equals(fuel.f0) && !tenant.equals(Tenant.EV)) tripStart.setFuelValue(fuel.f1);

        Tuple2<Boolean, Integer> remainingRange = getEarliestRemainingRange(value);
        if(Boolean.TRUE.equals(remainingRange.f0)) tripStart.setRemainingRange(remainingRange.f1);

        Tuple2<Boolean, Double> vDop = getEarliestVDop(value);
        if(Boolean.TRUE.equals(vDop.f0)) tripStart.setVDop(vDop.f1);

        // Defaulting userId and userProfile. This will get replaced in Enrich operator
        tripStart.setUserId(DEFAULT_STRING_VALUE);
        tripStart.setUserProfile(DEFAULT_STRING_VALUE);
        tripStart.setUserName(DEFAULT_STRING_VALUE);

        // Some of the fields set above will be replaced with trip start signal
        populateTripStartSignals(tripStart, tripStartSignal, tenant);

        return tripStart;
    }

    private static void populateTripStartSignals(TripStart tripStart, TripStartSignal tripStartSignal, Tenant tenant) {

        if(Objects.nonNull(tripStartSignal.getAmbientTemperature())) tripStart.setAmbientTemperature(Double.valueOf(tripStartSignal.getAmbientTemperature()));

        if(Objects.nonNull(tripStartSignal.getBatteryTemperature())) tripStart.setBatteryTemperature1(tripStartSignal.getBatteryTemperature());

        if(Objects.nonNull(tripStartSignal.getFuelValue()) && !tenant.equals(Tenant.EV)) tripStart.setFuelValue(tripStartSignal.getFuelValue());

        if(Objects.nonNull(tripStartSignal.getHDop())) tripStart.setHDop(tripStartSignal.getHDop());

        if(Objects.nonNull(tripStartSignal.getLongitude())) tripStart.setLongitude(tripStartSignal.getLongitude());

        if(Objects.nonNull(tripStartSignal.getLatitude())) tripStart.setLatitude(tripStartSignal.getLatitude());

        if(Objects.nonNull(tripStartSignal.getOdometer())) tripStart.setOdometerReading(tripStartSignal.getOdometer());

        if(Objects.nonNull(tripStartSignal.getPDop())) tripStart.setPDop(tripStartSignal.getPDop());

        if(Objects.nonNull(tripStartSignal.getRemainingRange())) tripStart.setRemainingRange(tripStartSignal.getRemainingRange());

        if(Objects.nonNull(tripStartSignal.getSoc()) && tenant.equals(Tenant.EV)) tripStart.setSoc(tripStartSignal.getSoc());

        if(Objects.nonNull(tripStartSignal.getUsableEnergy())) tripStart.setUsableEnergy(Double.valueOf(tripStartSignal.getUsableEnergy()));

        if(Objects.nonNull(tripStartSignal.getVehicleMode())) {
            int vehicleModeValue = tripStartSignal.getVehicleMode();
            String vehicleMode = getVehicleMode(vehicleModeValue);
            tripStart.setVehicleMode(vehicleMode);
        }
    }

    public static TripEnd createTripEnd(String vid, String tripId, TripEndSignal tripEndSignal, TripWrapper cachedTrip, Telemetry value) {
        TripEnd tripEnd = new TripEnd();
        Tenant tenant = TelemetryUtils.getTenant(value);
        tripEnd.setVirtualId(vid);
        tripEnd.setTripId(tripId);
        tripEnd.setCampaignName(value.getCampaignName());
        tripEnd.setTenantId(TelemetryUtils.getTenantId(value));
        tripEnd.setB2bClientId(TelemetryUtils.getB2BClientId(value));
        tripEnd.setSourceTimestamp(tripEndSignal.getTimestamp());
        tripEnd.setTimestamp(DateUtils.formatToISO(tripEndSignal.getTimestamp()));
        tripEnd.setCollectionEventTime(value.getCollectionEventTime());
        tripEnd.setCollectionEventTimeTS(DateUtils.formatToISO(value.getCollectionEventTime()));

        long instant = Instant.now().toEpochMilli();
        tripEnd.setProcessingTime(instant);
        tripEnd.setProcessingTimeTS(DateUtils.formatToISO(instant));

        setTripStartRelatedFieldsInTripEnd(tripEnd, tripEndSignal, cachedTrip);

        // Set all the signals from telemetry
        Tuple2<Boolean, Integer> gpsFIx = getLatestGpsFix(value);
        if(Boolean.TRUE.equals(gpsFIx.f0)) tripEnd.setGpsFix(gpsFIx.f1);

        Tuple2<Boolean, Boolean> gpsValid = getLatestGpsValid(value);
        if(Boolean.TRUE.equals(gpsValid.f0)) tripEnd.setGpsValid(gpsValid.f1);

        Tuple2<Boolean, Integer> ambientTemperature = getLatestAmbientTemperature(value);
        if(Boolean.TRUE.equals(ambientTemperature.f0)) tripEnd.setAmbientTemperature(Double.valueOf(ambientTemperature.f1));

        Tuple2<Boolean, Double> batteryTemperature1 = getLatestBatteryTemperature1(value);
        if(Boolean.TRUE.equals(batteryTemperature1.f0)) tripEnd.setBatteryTemperature1(batteryTemperature1.f1);

        Tuple2<Boolean, Double> batteryTemperature2 = getLatestBatteryTemperature2(value);
        if(Boolean.TRUE.equals(batteryTemperature2.f0)) tripEnd.setBatteryTemperature2(batteryTemperature2.f1);

        Tuple2<Boolean, Double> soc = getLatestSoc(value);
        if(Boolean.TRUE.equals(soc.f0) && tenant.equals(Tenant.EV)) tripEnd.setSoc(soc.f1);

        Tuple2<Boolean, String> vehicleMode = getLatestVehicleMode(value);
        if(Boolean.TRUE.equals(vehicleMode.f0)) tripEnd.setVehicleMode(vehicleMode.f1);

        Tuple2<Boolean, Integer> usableEnergy = getLatestUsableEnergy(value);
        if(Boolean.TRUE.equals(usableEnergy.f0)) tripEnd.setUsableEnergy(Double.valueOf(usableEnergy.f1));

        Tuple2<Boolean, Integer> usableCapacity = getLatestUsableCapacity(value);
        if(Boolean.TRUE.equals(usableCapacity.f0)) tripEnd.setUsableCapacity(Double.valueOf(usableCapacity.f1));

        Tuple2<Boolean, Double> fuel = getLatestFuelValue(value);
        if(Boolean.TRUE.equals(fuel.f0) && !tenant.equals(Tenant.EV)) tripEnd.setFuelValue(fuel.f1);

        Tuple2<Boolean, Integer> remainingRange = getLatestRemainingRange(value);
        if(Boolean.TRUE.equals(remainingRange.f0)) tripEnd.setRemainingRange(remainingRange.f1);

        Tuple2<Boolean, Double> vDop = getLatestVDop(value);
        if(Boolean.TRUE.equals(vDop.f0)) tripEnd.setVDop(vDop.f1);

        // Defaulting userId and userProfile. This will get replaced in Enrich operator
        tripEnd.setUserId(DEFAULT_STRING_VALUE);
        tripEnd.setUserProfile(DEFAULT_STRING_VALUE);
        tripEnd.setUserName(DEFAULT_STRING_VALUE);

        // Some of the fields set above will be replaced with trip end signal
        populateTripEndSignals(tripEnd, tripEndSignal, tenant);

        return tripEnd;
    }

    private static void populateTripEndSignals(TripEnd tripEnd, TripEndSignal tripEndSignal, Tenant tenant) {

        if(Objects.nonNull(tripEndSignal.getAmbientTemperature())) tripEnd.setAmbientTemperature(Double.valueOf(tripEndSignal.getAmbientTemperature()));

        if(Objects.nonNull(tripEndSignal.getBatteryTemperature())) tripEnd.setBatteryTemperature1(tripEndSignal.getBatteryTemperature());

        if(Objects.nonNull(tripEndSignal.getFuelValue()) && !tenant.equals(Tenant.EV)) tripEnd.setFuelValue(tripEndSignal.getFuelValue());

        if(Objects.nonNull(tripEndSignal.getHDop())) tripEnd.setHDop(tripEndSignal.getHDop());

        if(Objects.nonNull(tripEndSignal.getLongitude())) tripEnd.setLongitude(tripEndSignal.getLongitude());

        if(Objects.nonNull(tripEndSignal.getLatitude())) tripEnd.setLatitude(tripEndSignal.getLatitude());

        if(Objects.nonNull(tripEndSignal.getOdometer())) tripEnd.setOdometerReading(tripEndSignal.getOdometer());

        if(Objects.nonNull(tripEndSignal.getPDop())) tripEnd.setPDop(tripEndSignal.getPDop());

        if(Objects.nonNull(tripEndSignal.getRemainingRange())) tripEnd.setRemainingRange(tripEndSignal.getRemainingRange());

        if(Objects.nonNull(tripEndSignal.getSoc()) && tenant.equals(Tenant.EV)) tripEnd.setSoc(tripEndSignal.getSoc());

        if(Objects.nonNull(tripEndSignal.getUsableEnergy())) tripEnd.setUsableEnergy(Double.valueOf(tripEndSignal.getUsableEnergy()));

        if(Objects.nonNull(tripEndSignal.getVehicleMode())) {
            int vehicleModeValue = tripEndSignal.getVehicleMode();
            String vehicleMode = getVehicleMode(vehicleModeValue);
            tripEnd.setVehicleMode(vehicleMode);
        }

    }

    private static void setTripStartRelatedFieldsInTripEnd(TripEnd tripEnd, TripEndSignal tripEndSignal, TripWrapper cachedTrip) {

        if(Objects.nonNull(cachedTrip) && Objects.nonNull(cachedTrip.getTripStart())) {
            TripStart tripStart = cachedTrip.getTripStart();

            tripEnd.setSourceTripStartTimestamp(tripStart.getSourceTimestamp());
            tripEnd.setTripStartTimestamp(tripStart.getTimestamp());
            if(Objects.nonNull(tripStart.getOdometerReading())) tripEnd.setTripStartOdometerValue(tripStart.getOdometerReading());
        } else {
            TripStartSignal tripStartSignal = tripEndSignal.getStart();
            if(Objects.nonNull(tripStartSignal)) {

                tripEnd.setSourceTripStartTimestamp(tripStartSignal.getTimestamp());
                tripEnd.setTripStartTimestamp(DateUtils.formatToISO(tripStartSignal.getTimestamp()));
                tripEnd.setTripStartOdometerValue(tripStartSignal.getOdometer());

            }
        }
    }

    public static TripBreak createTripBreak(String vid, String tripId, String tripBreakId, long timestamp, Telemetry value) {
        TripBreak tripBreak = new TripBreak();
        Tenant tenant = TelemetryUtils.getTenant(value);
        tripBreak.setVirtualId(vid);
        tripBreak.setTripId(tripId);
        tripBreak.setTripBreakId(tripBreakId);
        tripBreak.setCampaignName(value.getCampaignName());
        tripBreak.setTenantId(TelemetryUtils.getTenantId(value));
        tripBreak.setB2bClientId(TelemetryUtils.getB2BClientId(value));
        tripBreak.setCollectionEventTime(value.getCollectionEventTime());
        tripBreak.setCollectionEventTimeTS(DateUtils.formatToISO(value.getCollectionEventTime()));

        long instant = Instant.now().toEpochMilli();
        tripBreak.setProcessingTime(instant);
        tripBreak.setProcessingTimeTS(DateUtils.formatToISO(instant));

        Tuple2<Boolean, Double> longitude = getLatestLongitude(value);
        if(Boolean.TRUE.equals(longitude.f0)) tripBreak.setLongitude(longitude.f1);

        Tuple2<Boolean, Double> latitude = getLatestLatitude(value);
        if(Boolean.TRUE.equals(latitude.f0)) tripBreak.setLatitude(latitude.f1);

        Tuple2<Boolean, Integer> gpsFIx = getLatestGpsFix(value);
        if(Boolean.TRUE.equals(gpsFIx.f0)) tripBreak.setGpsFix(gpsFIx.f1);

        Tuple2<Boolean, Boolean> gpsValid = getLatestGpsValid(value);
        if(Boolean.TRUE.equals(gpsValid.f0)) tripBreak.setGpsValid(gpsValid.f1);

        Tuple2<Boolean, Double> pDop = getLatestPDop(value);
        if(Boolean.TRUE.equals(pDop.f0)) tripBreak.setPDop(pDop.f1);

        Tuple2<Boolean, Double> vDop = getLatestVDop(value);
        if(Boolean.TRUE.equals(vDop.f0)) tripBreak.setVDop(vDop.f1);

        Tuple2<Boolean, Double> soc = getLatestSoc(value);
        if(Boolean.TRUE.equals(soc.f0) && tenant.equals(Tenant.EV)) tripBreak.setSoc(soc.f1);

        Tuple2<Boolean, Double> soc1 = getLatestSoc1(value);
        if(Boolean.TRUE.equals(soc1.f0)) tripBreak.setSocBms1(soc1.f1);

        Tuple2<Boolean, Double> soc2 = getLatestSoc2(value);
        if(Boolean.TRUE.equals(soc2.f0)) tripBreak.setSocBms2(soc2.f1);

        Tuple2<Boolean, Double> odometerReading = getLatestOdometerReading(value);
        if(Boolean.TRUE.equals(odometerReading.f0)) tripBreak.setOdometerReading(odometerReading.f1);

        Tuple2<Boolean, Double> fuel = getLatestFuelValue(value);
        if(Boolean.TRUE.equals(fuel.f0) && !tenant.equals(Tenant.EV)) tripBreak.setFuelValue(fuel.f1);

        tripBreak.setStartTimestamp(DateUtils.formatToISO((timestamp)));

        // Defaulting userId and userProfile. This will get replaced in Enrich operator
        tripBreak.setUserId(DEFAULT_STRING_VALUE);
        tripBreak.setUserProfile(DEFAULT_STRING_VALUE);
        tripBreak.setUserName(DEFAULT_STRING_VALUE);

        return tripBreak;
    }

    public static TripWrapper getTripStart(String vid, String tripId, TripStartSignal tripStartSignal, Telemetry value, boolean isTripEndSignal) {
        TripStart tripStart = createTripStart(vid, tripId, tripStartSignal, value, isTripEndSignal);
        String userId = tripStartSignal.getUserId();
        Integer userProfile = tripStartSignal.getUserProfile();
        return TripWrapper.builder()
                .virtualId(vid)
                .tenant(TelemetryUtils.getTenant(value))
                .userDetails(getUserDetails(value, userId, userProfile))
                .isTripStart(true)
                .tripStart(tripStart)
                .timestamp(tripStartSignal.getTimestamp())
                .systemTime(DateUtils.currentEpochTime())
                .tripId(tripId)
                .build();
    }

    public static TripWrapper getTripBreak(String vid, String tripId, String tripBreakId, long tripBreakTime, Telemetry value) {
        TripBreak tripBreak = createTripBreak(vid, tripId, tripBreakId, tripBreakTime, value);
        return TripWrapper.builder()
                .virtualId(vid)
                .tenant(TelemetryUtils.getTenant(value))
                .userDetails(getUserDetails(value))
                .isTripBreak(true)
                .tripBreak(tripBreak)
                .timestamp(tripBreakTime)
                .systemTime(DateUtils.currentEpochTime())
                .tripId(tripId)
                .build();
    }

    public static void updateTripBreakMetadata(TripWrapper tripBreakWrapper, BreakType breakType, String reason) {
        TripBreak tripBreak = tripBreakWrapper.getTripBreak();

        tripBreak.setBreakType(breakType.getValue());
        tripBreak.setBreakReason(reason);

        tripBreakWrapper.setTripBreak(tripBreak);
    }

    public static TripWrapper getTripEnd(String vid, String tripId, TripEndSignal tripEndSignal, TripWrapper cachedTrip, Telemetry value) {
        TripEnd tripEnd = createTripEnd(vid, tripId, tripEndSignal, cachedTrip, value);
        String userId = tripEndSignal.getUserId();
        Integer userProfile = tripEndSignal.getUserProfile();
        return TripWrapper.builder()
                .virtualId(vid)
                .tenant(TelemetryUtils.getTenant(value))
                .userDetails(getUserDetails(value, userId, userProfile))
                .isTripEnd(true)
                .tripEnd(tripEnd)
                .timestamp(tripEndSignal.getTimestamp())
                .systemTime(DateUtils.currentEpochTime())
                .tripId(tripId)
                .build();
    }

    public static String getProfileType(Integer profileType) {
        if (Objects.isNull(profileType)) return DEFAULT_STRING_VALUE;

        if(DEFAULT_INTEGER_VALUE == profileType) return DEFAULT_STRING_VALUE;

        if(PRIMARY_PROFILE == profileType) return ProfileType.PRIMARY.value();

        if(SECONDARY_PROFILE == profileType) return ProfileType.SECONDARY.value();

        return DEFAULT_STRING_VALUE;
    }

    private static int getLatestIntValue(Set<SignalData> signals) {
        if(signals.isEmpty()) return -1;

        Optional<SignalData> latestSignal = SignalUtils.getLatestSignal(signals);
        return latestSignal
                .map(SignalUtils::getIntegerSignalValue)
                .orElse(-1);
    }

    private static int getEarliestIntValue(Set<SignalData> signals) {
        if(signals.isEmpty()) return -1;

        Optional<SignalData> latestSignal = SignalUtils.getEarliestSignal(signals);
        return latestSignal
                .map(SignalUtils::getIntegerSignalValue)
                .orElse(-1);
    }

}
