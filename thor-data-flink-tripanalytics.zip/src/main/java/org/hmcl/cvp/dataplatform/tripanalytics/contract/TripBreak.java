package org.hmcl.cvp.dataplatform.tripanalytics.contract;

import com.google.gson.annotations.SerializedName;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class TripBreak implements Serializable {

    @SerializedName("vehicle_id")
    private String virtualId;

    @SerializedName("tenant_id")
    private String tenantId;

    @SerializedName("b2b_client_id")
    private String b2bClientId;

    @SerializedName("campaign_name")
    private String campaignName;

    @SerializedName("collectioneventtime")
    private Long collectionEventTime;

    @SerializedName("collectioneventtimets")
    private String collectionEventTimeTS;

    @SerializedName("processingtime")
    private Long processingTime;

    @SerializedName("processingtimets")
    private String processingTimeTS;

    @SerializedName("trip_id")
    private String tripId;

    @SerializedName("break_type")
    private String breakType;

    @SerializedName("break_reason")
    private String breakReason;

    // Timestamp is String to take care "strict_date_optional_time||epoch_millis"
    @SerializedName("break_start_timestamp")
    private String startTimestamp;

    // Timestamp is String to take care "strict_date_optional_time||epoch_millis"
    @SerializedName("break_end_timestamp")
    private String endTimestamp;

    @SerializedName("trip_break_id")
    private String tripBreakId;

    // Signals

    @SerializedName("gps_fix")
    private Integer gpsFix;

    @SerializedName("gps_valid")
    private Boolean gpsValid;

    @SerializedName("hdop")
    private Double hDop;

    @SerializedName("latitude")
    private Double latitude;

    @SerializedName("longitude")
    private Double longitude;

    @SerializedName("odometer_reading")
    private Double odometerReading;

    @SerializedName("pdop")
    private Double pDop;

    @SerializedName("soc")
    private Double soc;

    @SerializedName("fuel_value")
    private Double fuelValue;

    @SerializedName("soc_bms1")
    private Double socBms1;

    @SerializedName("soc_bms2")
    private Double socBms2;

    @SerializedName("user_id")
    private String userId;

    @SerializedName("user_profile")
    private String userProfile;

    @SerializedName("user_name")
    private String userName;

    @SerializedName("user_details_source")
    private String userDetailsSource;

    @SerializedName("vdop")
    private Double vDop;

}
