package org.hmcl.cvp.dataplatform.tripanalytics.contract;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.hmcl.cvp.dataplatform.contract.telemetry.Telemetry;
import org.hmcl.cvp.dataplatform.contract.telemetry.Tenant;

import java.io.Serializable;
import java.util.Objects;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class TripWrapper implements Serializable {

    private String virtualId;

    private Tenant tenant;

    private UserDetails userDetails;

    private long timestamp;

    private long watermark;

    private boolean isTripStart;

    private boolean isTripEnd;

    private boolean isTripBreak;

    private boolean neededForTripBreak;

    private long systemTime;

    private String tripId;

    private String incomingTripId;

    private TripStart tripStart;

    private TripBreak tripBreak;

    private TripEnd tripEnd;

    private Telemetry event;

    private boolean isTripStartLatLongInvalid;

    private double lastValidLatitude;

    private double lastValidLongitude;

    public boolean getIsTripStart() {
        return isTripStart;
    }

    public void setIsTripStart(boolean tripStart) {
        isTripStart = tripStart;
    }

    public boolean getIsTripEnd() {
        return isTripEnd;
    }

    public void setIsTripEnd(boolean tripEnd) {
        isTripEnd = tripEnd;
    }

    public boolean getIsTripBreak() {
        return isTripBreak;
    }

    public void setIsTripBreak(boolean tripBreak) {
        isTripBreak = tripBreak;
    }

    public boolean getIsTripStartLatLongInvalid() {
        return isTripStartLatLongInvalid;
    }

    public void setIsTripStartLatLongInvalid(boolean tripStartLatLongInvalid) {
        isTripStartLatLongInvalid = tripStartLatLongInvalid;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof TripWrapper)) return false;
        TripWrapper that = (TripWrapper) o;
        return isTripStart == that.isTripStart
                && isTripEnd == that.isTripEnd
                && isTripBreak == that.isTripBreak
                && neededForTripBreak == that.neededForTripBreak
                && Objects.equals(virtualId, that.virtualId)
                && Objects.equals(tripId, that.tripId);
    }

    @Override
    public int hashCode() {
        return Objects.hash(virtualId, isTripStart, isTripEnd, isTripBreak, neededForTripBreak, tripId);
    }
}
