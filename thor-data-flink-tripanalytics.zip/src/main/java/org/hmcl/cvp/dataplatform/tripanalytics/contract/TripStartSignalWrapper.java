package org.hmcl.cvp.dataplatform.tripanalytics.contract;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.hmcl.cvp.dataplatform.contract.telemetry.SignalData;
import org.hmcl.cvp.dataplatform.tripanalytics.helper.TripAnalyticsHelper;

import java.io.Serializable;
import java.util.Objects;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class TripStartSignalWrapper implements Serializable {

    private String tripId;

    private TripStartSignal tripStartSignal;

    private TripEndSignal tripEndSignal;

    private boolean isTripStartSignal;

    private boolean isTripEndSignal;

    public boolean getIsTripStartSignal() {
        return isTripStartSignal;
    }

    public void setIsTripStartSignal(boolean tripStartSignal) {
        isTripStartSignal = tripStartSignal;
    }

    public boolean getIsTripEndSignal() {
        return isTripEndSignal;
    }

    public void setIsTripEndSignal(boolean tripEndSignal) {
        isTripEndSignal = tripEndSignal;
    }

    public static TripStartSignalWrapper fromTripStartSignal(SignalData tripStartFlagSignal) {
        TripStartSignal tripStartSignal = TripAnalyticsHelper.getTripStartSignalValue(tripStartFlagSignal);
        String tripId = Objects.nonNull(tripStartSignal) ? tripStartSignal.getTripId() : null;
        return TripStartSignalWrapper.builder()
                .tripStartSignal(tripStartSignal)
                .isTripStartSignal(true)
                .tripId(tripId)
                .build();
    }

    public static TripStartSignalWrapper fromTripEndSignal(SignalData tripEndFlagSignal) {
        TripEndSignal tripEndSignal = TripAnalyticsHelper.getTripEndSignalValue(tripEndFlagSignal);
        String tripId = Objects.nonNull(tripEndSignal) ? tripEndSignal.getTripId() : null;
        return TripStartSignalWrapper.builder()
                .tripEndSignal(tripEndSignal)
                .isTripEndSignal(true)
                .tripId(tripId)
                .build();
    }


}
