package org.hmcl.cvp.dataplatform.tripanalytics.job;

public class OpenSearchIndices {
    private OpenSearchIndices() {}

    public static final String EV_TRIP_START_INDEX = "hmcl-cv-trip-start-ev-vida-stream";
    public static final String EV_TRIP_END_INDEX = "hmcl-cv-trip-end-ev-vida-stream";
    public static final String EV_TRIP_BREAK_INDEX = "hmcl-cv-trip-break-ev-vida-stream";

    public static final String ICE_TRIP_START_INDEX = "hmcl-cv-trip-start-ice-hero-stream";
    public static final String ICE_TRIP_END_INDEX = "hmcl-cv-trip-end-ice-hero-stream";
    public static final String ICE_TRIP_BREAK_INDEX = "hmcl-cv-trip-break-ice-hero-stream";

    public static final String HARLEY_TRIP_START_INDEX = "hmcl-cv-trip-start-ice-harley-stream";
    public static final String HARLEY_TRIP_END_INDEX = "hmcl-cv-trip-end-ice-harley-stream";
    public static final String HARLEY_TRIP_BREAK_INDEX = "hmcl-cv-trip-break-ice-harley-stream";
}
