package org.hmcl.cvp.dataplatform.tripanalytics.contract;

import com.google.gson.annotations.SerializedName;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class TripStartSignal implements Serializable {

    @SerializedName("ambientTemperature")
    private Integer ambientTemperature;

    @SerializedName("batteryTemperature")
    private Double batteryTemperature;

    @SerializedName("fuelPercentage")
    private Integer fuelPercentage;

    @SerializedName("fuelValue")
    private Double fuelValue;

    @SerializedName("hdop")
    private Double hDop;

    @SerializedName("latitude")
    private Double latitude;

    @SerializedName("longitude")
    private Double longitude;

    @SerializedName("odometer")
    private Double odometer;

    @SerializedName("pdop")
    private Double pDop;

    @SerializedName("remainingRange")
    private Integer remainingRange;

    @SerializedName("soc")
    private Double soc;

    @SerializedName("timestamp")
    private Long timestamp;

    @SerializedName("tripId")
    private String tripId;

    @SerializedName("usableEnergy")
    private Integer usableEnergy;

    @SerializedName("userId")
    private String userId;

    @SerializedName("userProfile")
    private Integer userProfile;

    @SerializedName("vehicleMode")
    private Integer vehicleMode;
}
