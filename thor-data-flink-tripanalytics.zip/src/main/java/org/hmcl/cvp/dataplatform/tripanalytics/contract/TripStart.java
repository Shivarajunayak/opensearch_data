package org.hmcl.cvp.dataplatform.tripanalytics.contract;

import com.google.gson.annotations.SerializedName;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.util.Objects;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class TripStart implements Serializable {

    @SerializedName("vehicle_id")
    private String virtualId;

    @SerializedName("tenant_id")
    private String tenantId;

    @SerializedName("b2b_client_id")
    private String b2bClientId;

    @SerializedName("campaign_name")
    private String campaignName;

    @SerializedName("collectioneventtime")
    private Long collectionEventTime;

    @SerializedName("collectioneventtimets")
    private String collectionEventTimeTS;

    @SerializedName("processingtime")
    private Long processingTime;

    @SerializedName("processingtimets")
    private String processingTimeTS;

    @SerializedName("trip_id")
    private String tripId;

    // Timestamp is String to take care "strict_date_optional_time||epoch_millis"
    @SerializedName("timestamp")
    private String timestamp;

    @SerializedName("source_timestamp")
    private Long sourceTimestamp;

    @SerializedName("trip_source")
    private String tripSource;

    // Signals

    @SerializedName("ambient_temperature")
    private Double ambientTemperature;

    @SerializedName("battery_temperature1")
    private Double batteryTemperature1;

    @SerializedName("battery_temperature2")
    private Double batteryTemperature2;

    @SerializedName("driving_score")
    private String drivingScore;

    @SerializedName("fuel_value")
    private Double fuelValue;

    @SerializedName("gps_fix")
    private Integer gpsFix;

    @SerializedName("gps_valid")
    private Boolean gpsValid;

    @SerializedName("harsh_acceleration")
    private String harshAcceleration;

    @SerializedName("harsh_braking")
    private String harshBraking;

    @SerializedName("hdop")
    private Double hDop;

    @SerializedName("latitude")
    private Double latitude;

    @SerializedName("longitude")
    private Double longitude;

    @SerializedName("odometer_reading")
    private Double odometerReading;

    @SerializedName("pdop")
    private Double pDop;

    @SerializedName("remaining_range")
    private Integer remainingRange;

    @SerializedName("soc")
    private Double soc;

    @SerializedName("trip_accuracy")
    private String tripAccuracy;

    @SerializedName("usable_energy")
    private Double usableEnergy;

    @SerializedName("usable_capacity")
    private Double usableCapacity;

    @SerializedName("user_id")
    private String userId;

    @SerializedName("user_profile")
    private String userProfile;

    @SerializedName("user_name")
    private String userName;

    @SerializedName("user_details_source")
    private String userDetailsSource;

    @SerializedName("vehicle_mode")
    private String vehicleMode;

    @SerializedName("vdop")
    private Double vDop;


    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof TripStart)) return false;
        TripStart tripStart = (TripStart) o;
        return Objects.equals(virtualId, tripStart.virtualId) && Objects.equals(tripId, tripStart.tripId);
    }

    @Override
    public int hashCode() {
        return Objects.hash(virtualId, tripId);
    }
}
