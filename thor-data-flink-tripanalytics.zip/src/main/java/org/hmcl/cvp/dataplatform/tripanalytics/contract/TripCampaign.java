package org.hmcl.cvp.dataplatform.tripanalytics.contract;

import lombok.Getter;

@Getter
public enum TripCampaign {

    IGNITION_RISE("ign-rise"),

    IGNITION_FALL("ign-fall");

    private final String value;

    TripCampaign(String value) {
        this.value = value;

    }
}
