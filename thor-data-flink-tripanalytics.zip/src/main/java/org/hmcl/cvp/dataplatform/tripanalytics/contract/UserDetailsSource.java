package org.hmcl.cvp.dataplatform.tripanalytics.contract;

import com.google.gson.annotations.SerializedName;
import lombok.Getter;

@Getter
public enum UserDetailsSource {

    @SerializedName("PrimarySignal")
    PRIMARY("PrimarySignal"),

    @SerializedName("SecondarySignal")
    SECONDARY("SecondarySignal"),

    @SerializedName("CurrentRiderDefault")
    CURRENT_RIDER_DEFAULT("CurrentRiderDefault"),

    @SerializedName("PrimaryDefault")
    PRIMARY_DEFAULT("PrimaryDefault"),

    @SerializedName("NoPrimaryToDefault")
    PRIMARY_UNKNOWN("NoPrimaryToDefault"),

    @SerializedName("Signal")
    SIGNAL("Signal"),

    @SerializedName("SecondaryExpired")
    SECONDARY_EXPIRED("SecondaryExpired"),

    @SerializedName("SecondaryDefault")
    SECONDARY_DEFAULT("SecondaryDefault"),

    @SerializedName("UserUnknown")
    USER_UNKNOWN("UserUnknown"),

    @SerializedName("Unknown")
    UNKNOWN("Unknown");

    private final String value;

    UserDetailsSource(String value) {
        this.value = value;
    }

}
