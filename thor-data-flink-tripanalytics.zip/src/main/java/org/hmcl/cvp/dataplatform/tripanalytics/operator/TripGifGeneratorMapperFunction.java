package org.hmcl.cvp.dataplatform.tripanalytics.operator;

import com.google.gson.Gson;
import lombok.extern.slf4j.Slf4j;
import org.apache.flink.api.common.functions.RichFlatMapFunction;
import org.apache.flink.configuration.Configuration;
import org.apache.flink.metrics.Counter;
import org.apache.flink.util.Collector;
import org.hmcl.cvp.dataplatform.commons.constants.Constants;
import org.hmcl.cvp.dataplatform.commons.utils.GsonUtils;
import org.hmcl.cvp.dataplatform.tripanalytics.contract.TripEnd;
import org.hmcl.cvp.dataplatform.tripanalytics.contract.TripForGif;
import org.hmcl.cvp.dataplatform.tripanalytics.contract.TripWrapper;

@Slf4j
public class TripGifGeneratorMapperFunction extends RichFlatMapFunction<TripWrapper, String> {

    private static final Gson GSON = GsonUtils.getGson();

    private transient Counter numCompletedTripCounter;
    private transient Counter numErrorCounter;
    private transient Counter numIgnoredTripCounter;

    private Counter counterInitializer(String counterName) {
        return getRuntimeContext()
                .getMetricGroup()
                .addGroup(Constants.METRIC_GROUP_NAME)
                .addGroup("GifGenerator")
                .counter(counterName);
    }

    @Override
    public void open(Configuration parameters) throws Exception {
        super.open(parameters);

        numCompletedTripCounter = counterInitializer("numCompletedTripCounter");
        numErrorCounter = counterInitializer("numErrorCounter");
        numIgnoredTripCounter = counterInitializer("numIgnoredTripCounter");
    }

    @Override
    public void flatMap(TripWrapper value, Collector<String> out) throws Exception {
        String vid = value.getVirtualId();
        String tripId = value.getTripId();
        try {

            if(value.getIsTripEnd()) {

                numCompletedTripCounter.inc();
                log.info("Trip {} has ended for vehicle {}", tripId, vid);

                TripEnd tripEnd = value.getTripEnd();
                TripForGif tripForGif = TripForGif.builder()
                        .vid(vid)
                        .tenantId(tripEnd.getTenantId())
                        .tripId(tripId)
                        .startTime(tripEnd.getSourceTripStartTimestamp())
                        .startTimeTS(tripEnd.getTripStartTimestamp())
                        .endTime(tripEnd.getSourceTimestamp())
                        .endTimeTS(tripEnd.getTimestamp())
                        .build();

                out.collect(GSON.toJson(tripForGif));

            } else {
                numIgnoredTripCounter.inc();
                log.info("Trip {} is not a end trip for vehicle {}. So ignoring!", tripId, vid);
            }

        } catch (Exception e) {
            log.error("Exception while mapping trips for gif for vehicle {}", vid, e);
            numErrorCounter.inc();
        }
    }

}
