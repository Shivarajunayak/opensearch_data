package org.hmcl.cvp.dataplatform.tripanalytics.operator;

import org.apache.flink.api.common.state.MapStateDescriptor;
import org.apache.flink.api.common.typeinfo.TypeHint;
import org.apache.flink.api.common.typeinfo.TypeInformation;
import org.hmcl.cvp.dataplatform.commons.utils.FlinkUtils;
import org.hmcl.cvp.dataplatform.contract.userpreference.UserPreference;
import org.hmcl.cvp.dataplatform.tripanalytics.contract.LatLongState;
import org.hmcl.cvp.dataplatform.tripanalytics.contract.Trip;
import org.hmcl.cvp.dataplatform.tripanalytics.contract.TripJoiner;
import org.hmcl.cvp.dataplatform.tripanalytics.contract.TripWrapper;

import java.util.Map;
import java.util.Set;

public class StateDescriptors {

    private StateDescriptors() {
    }

    public static MapStateDescriptor<String, Set<TripWrapper>> getTripStateDescriptor(long ttlInHours) {
        MapStateDescriptor<String, Set<TripWrapper>> tripStateDescriptor = new MapStateDescriptor<>("tripWrappersMapState",
                TypeInformation.of(String.class),
                TypeInformation.of(new TypeHint<Set<TripWrapper>>() {
                })
        );
        tripStateDescriptor.enableTimeToLive(FlinkUtils.getStateTTLInMinsConfig(ttlInHours * 60));

        return tripStateDescriptor;
    }

    public static MapStateDescriptor<String, Set<TripJoiner>> getTripJoinerDescriptor(long ttlInHours) {
        MapStateDescriptor<String, Set<TripJoiner>> tripJoinerDescriptor = new MapStateDescriptor<>("tripJoinersMapState",
                TypeInformation.of(String.class),
                TypeInformation.of(new TypeHint<Set<TripJoiner>>() {
                })
        );
        tripJoinerDescriptor.enableTimeToLive(FlinkUtils.getStateTTLInMinsConfig(ttlInHours * 60));

        return tripJoinerDescriptor;
    }

    public static MapStateDescriptor<String, Set<Trip>> getProcessedTripsDescriptor(long ttlInHours) {
        MapStateDescriptor<String, Set<Trip>> processedTripsDescriptor = new MapStateDescriptor<>("tripsMapState",
                TypeInformation.of(String.class),
                TypeInformation.of(new TypeHint<Set<Trip>>() {
                })
        );
        processedTripsDescriptor.enableTimeToLive(FlinkUtils.getStateTTLInMinsConfig(ttlInHours * 60));

        return processedTripsDescriptor;
    }

    public static MapStateDescriptor<String, Map<String, UserPreference>> userPreferenceMapStateDescriptor() {
        return new MapStateDescriptor<>("userPreferencesMapState",
                TypeInformation.of(String.class),
                TypeInformation.of(new TypeHint<Map<String, UserPreference>>() {
                })
        );
    }

    public static MapStateDescriptor<String, LatLongState> latLongMapStateDescriptor() {
        return new MapStateDescriptor<>("latLongMapState",
                String.class,
                LatLongState.class
        );
    }

}
