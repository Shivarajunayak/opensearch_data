package org.hmcl.cvp.dataplatform.tripanalytics.operator;

import lombok.extern.slf4j.Slf4j;
import org.apache.flink.configuration.Configuration;
import org.apache.flink.metrics.Counter;
import org.apache.flink.streaming.api.functions.windowing.ProcessWindowFunction;
import org.apache.flink.streaming.api.windowing.windows.TimeWindow;
import org.apache.flink.util.Collector;
import org.hmcl.cvp.dataplatform.commons.catalogue.SignalCatalogue;
import org.hmcl.cvp.dataplatform.commons.constants.Constants;
import org.hmcl.cvp.dataplatform.commons.utils.DateUtils;
import org.hmcl.cvp.dataplatform.commons.utils.SignalUtils;
import org.hmcl.cvp.dataplatform.commons.utils.TelemetryUtils;
import org.hmcl.cvp.dataplatform.contract.telemetry.LatLongPair;
import org.hmcl.cvp.dataplatform.contract.telemetry.SignalData;
import org.hmcl.cvp.dataplatform.contract.telemetry.SignalInfo;
import org.hmcl.cvp.dataplatform.contract.telemetry.Telemetry;
import org.hmcl.cvp.dataplatform.contract.telemetry.Tenant;
import org.hmcl.cvp.dataplatform.tripanalytics.contract.*;
import org.hmcl.cvp.dataplatform.tripanalytics.helper.TripAnalyticsHelper;

import java.util.*;
import java.util.stream.Collectors;

import static org.hmcl.cvp.dataplatform.tripanalytics.operator.TripAnalyticsProcessFunction.isGPSAndLatLongValid;

@Slf4j
public class TripAnalyticsWindowFunction extends ProcessWindowFunction<TripWrapper, TripWrapper, TripBreakKey, TimeWindow> {

    private static final Integer VEHICLE_SPEED = 0;
    private static final double MAX_ENGINE_RPM = 1100.0;
    private static final Integer MOTOR_ON_SIGNAL = 3;

    private transient Counter numTripBreaks;
    private transient Counter numTripWindows;

    private Counter counterInitializer(String counterName) {

        return getRuntimeContext()
                .getMetricGroup()
                .addGroup(Constants.METRIC_GROUP_NAME)
                .addGroup("TripBreaks")
                .counter(counterName);
    }

    @Override
    public void open(Configuration parameters) throws Exception {
        super.open(parameters);

        numTripBreaks = counterInitializer("numTripBreaks");
        numTripWindows = counterInitializer("numTripWindows");

    }

    /**
     * Conditions for a trip break
     * <ul>
     *     <li>Vehicle speed should be 0</li>
     *     <li>No odometer change</li>
     *     <li>Ignition should be on</li>
     *     <li>For ev, motor status signal should be 1 (OFF)</li>
     *     <li>For ICE, engine speed should be less than or equal to 1100</li>
     * </ul>
     *
     * @param tripBreakKey The key for which this window is evaluated.
     * @param context The context in which the window is being evaluated.
     * @param elements The elements in the window being evaluated.
     * @param out A collector for emitting elements.
     */
    @Override
    public void process(TripBreakKey tripBreakKey, Context context, Iterable<TripWrapper> elements, Collector<TripWrapper> out) {
        numTripWindows.inc();

        String vid = tripBreakKey.getVirtualId();
        String tripId = tripBreakKey.getTripId();

        try {

            List<TripWrapper> wrapperElements = getOrderedListOfWrapperElements(elements);

            // The list will be ordered
            List<Telemetry> telemetries = getOrderedList(wrapperElements);

            if(telemetries.isEmpty()) return;

            Tenant tenant = getTenant(telemetries);

            int sizeOfWindow = telemetries.size();
            if(sizeOfWindow == 1) {
                log.warn("Only one event is present in bucket for vehicle {} and trip {}", vid, tripId);
                return;
            }

            LatLongState latestValidLatLongs = getLatestValidLatLongs(telemetries);
            if (latestValidLatLongs == null || latestValidLatLongs.getLatitude() == 0 || latestValidLatLongs.getLongitude() == 0) {
                TripWrapper latestTripWrapper = wrapperElements.get(wrapperElements.size() - 1);
                latestValidLatLongs = LatLongState.builder()
                        .latitude(latestTripWrapper.getLastValidLatitude())
                        .longitude(latestTripWrapper.getLastValidLongitude())
                        .detectionWindowStartTimestamp(latestTripWrapper.getTimestamp())
                        .build();
            }

            Telemetry oldestTelemetry = telemetries.get(0);
            Telemetry latestTelemetry = telemetries.get(sizeOfWindow - 1);

            long startTimestamp = oldestTelemetry.getCollectionEventTime();
            long endTimestamp = latestTelemetry.getCollectionEventTime();

            log.info("Number of events in the bucket for vehicle {} and tripId {} is {} from {} to {}",
                    vid, tripId, telemetries.size(), startTimestamp, endTimestamp);

            if(isVehicleSpeedZero(vid, telemetries)
                    && isOdometerNotChanged(vid, telemetries)
                    && isIgnitionOn(vid, telemetries)
                    && (isMotorStateOff(vid, telemetries, tenant) || isEngineSpeedWithRpm(vid, telemetries, tenant))) {

                log.info("Trip {} break started at {} and ended at {} for vehicle {}", tripId, startTimestamp, endTimestamp, vid);

                numTripBreaks.inc();

                TripWrapper tripWrapper = TripAnalyticsHelper.getTripBreak(vid, tripId, null, startTimestamp, latestTelemetry);
                TripBreak tripBreak = tripWrapper.getTripBreak();

                // Set latest element timestamp as trip break
                tripBreak.setEndTimestamp(DateUtils.formatToISO(endTimestamp));
                tripBreak.setLatitude(latestValidLatLongs.getLatitude());
                tripBreak.setLongitude(latestValidLatLongs.getLongitude());

                // Set user details
                UserDetails userDetails = getUserDetails(vid, tripId, elements);
                updateUserDetails(tripBreak, userDetails);

                // Set it back to trip wrapper object
                tripWrapper.setTripBreak(tripBreak);

                updateBreakMetadata(tripWrapper, startTimestamp, endTimestamp);
                out.collect(tripWrapper);

            } else {
                log.info("No break for vehicle {} and tripId {}", vid, tripId);
            }

        } catch (Exception e) {
            log.error("Exception while processing for vehicle {}", vid, e);
        }

    }

    private LatLongState getLatestValidLatLongs(List<Telemetry> elements) {
        for (int i = elements.size() - 1; i >= 0; i--) {
            Telemetry telemetry = elements.get(i);
            List<LatLongPair> latLongPairList = SignalUtils.getLatitudeLongitude(telemetry);
            int latestLatLongIndex = latLongPairList.size() - 1;

            if (latestLatLongIndex < 0) {
                log.error("No lat longs found in telemetry data, skipping this elemnts");
                continue;
            }

            LatLongPair latLongLatest = latLongPairList.get(latestLatLongIndex);

            log.info("Checking GPS and LatLong validity for telemetry data: {}", telemetry);

            if (isGPSAndLatLongValid(latLongLatest)){
                log.info("Lat longs in telemetry data are valid, Updating state");

                return LatLongState.builder()
                        .latitude(latLongLatest.getLatitude())
                        .longitude(latLongLatest.getLongitude())
                        .detectionWindowStartTimestamp(telemetry.getCollectionEventTime())
                        .build();
            }
        }
        return null;
    }

    // Get only elements needed to calculate trip break and order them by collection event time in natural order
    private List<Telemetry> getOrderedList(List<TripWrapper> elements) {
        return elements.stream()
                .map(TripWrapper::getEvent)
                .collect(Collectors.toList());
    }

    private List<TripWrapper> getOrderedListOfWrapperElements(Iterable<TripWrapper> elements) {
        List<TripWrapper> list = new ArrayList<>();
        elements.forEach(list::add);

        return list.stream()
                .filter(t -> t.isNeededForTripBreak() && Objects.nonNull(t.getEvent()))
                .sorted(Comparator.comparing(TripWrapper::getTimestamp))
                .collect(Collectors.toList());
    }

    private UserDetails getUserDetails(String vid, String tripId, Iterable<TripWrapper> elements) {
        List<TripWrapper> list = new ArrayList<>();
        elements.forEach(list::add);

        List<UserDetails> userDetailsList = list.stream()
                .filter(t -> t.isNeededForTripBreak() && Objects.nonNull(t.getUserDetails()))
                .map(TripWrapper::getUserDetails)
                .collect(Collectors.toList());

        UserDetails userDetails = UserDetails.builder()
                .userId(TripAnalyticsHelper.DEFAULT_STRING_VALUE)
                .userProfile(TripAnalyticsHelper.DEFAULT_STRING_VALUE)
                .userName(TripAnalyticsHelper.DEFAULT_STRING_VALUE)
                .source(UserDetailsSource.UNKNOWN.getValue())
                .build();

        if(userDetailsList.isEmpty()) {
            log.info("No user details found for trip {} and vehicle {} to populate ignition on break!", tripId, vid);
            return userDetails;
        }

        return userDetailsList.stream()
                .filter(UserDetails::isValid).findFirst()
                .orElse(userDetails);
    }

    private Tenant getTenant(List<Telemetry> telemetries) {
        return TelemetryUtils.getTenant(telemetries.get(0));
    }

    private boolean isVehicleSpeedZero(String vid, List<Telemetry> telemetries) {
        SignalInfo vehicleSpeedInfo = SignalCatalogue.getVehicleSpeedDisplayInfo();

        List<SignalData> allSignals = getAllSignals(telemetries, vehicleSpeedInfo);

        log.info("Vehicle speed signals {} for vid {}", allSignals, vid);
        long countOfEvents = allSignals.stream()
                .filter(s -> VEHICLE_SPEED == Double.valueOf(String.valueOf(s.getValue())).intValue())
                .count();
        log.info("Number of events with vehicle speed 0 for vehicle {} is {}", vid, countOfEvents);

        return countOfEvents == allSignals.size();
    }

    private boolean isOdometerNotChanged(String vid, List<Telemetry> telemetries) {
        SignalInfo odometerInfo = SignalCatalogue.getOdometerHRInfo();

        List<SignalData> allSignals = getAllSignals(telemetries, odometerInfo);
        log.info("Odometer signals {} for vid {}", allSignals, vid);

        long countOfEvents = allSignals.stream()
                .map(s -> (double) s.getValue())
                .collect(Collectors.toSet())
                .size();

        log.info("Number of events with no odometer change for vehicle {} is {}", vid, countOfEvents);
        return countOfEvents == 1;
    }

    private boolean isIgnitionOn(String vid, List<Telemetry> telemetries) {
        SignalInfo ignitionInfo = SignalCatalogue.getTcuIgnitionInfo();

        List<SignalData> allSignals = getAllSignals(telemetries, ignitionInfo);

        long countOfEvents = allSignals.stream().filter(s -> (boolean) s.getValue()).count();

        log.info("Number of events with ignition on for vehicle {} is {}", vid, countOfEvents);

        return countOfEvents == allSignals.size();
    }

    private boolean isMotorStateOff(String vid, List<Telemetry> telemetries, Tenant tenant) {
        if(!Tenant.EV.equals(tenant)) return false;

        SignalInfo motorStateInfo = SignalCatalogue.getMotorStatusInfo();

        List<SignalData> allSignals = getAllSignals(telemetries, motorStateInfo);

        long countOfEvents = allSignals.stream().filter(s -> MOTOR_ON_SIGNAL != s.getValue()).count();

        log.info("Number of events with motor status not 3 for vehicle {} is {}", vid, countOfEvents);

        return countOfEvents == allSignals.size();
    }

    private boolean isEngineSpeedWithRpm(String vid, List<Telemetry> telemetries, Tenant tenant) {
        if(Tenant.EV.equals(tenant)) return false;

        SignalInfo engineRpmInfo = SignalCatalogue.getEngineSpeedInfo();

        List<SignalData> allSignals = getAllSignals(telemetries, engineRpmInfo);

        long countOfEvents = allSignals.stream()
                .filter(s -> {
                    double value = (double) s.getValue();
                    return MAX_ENGINE_RPM >= value;
                })
                .count();

        log.info("Number of events with engine speed less than or equal to {} for vehicle {} is {}", MAX_ENGINE_RPM, vid, countOfEvents);

        return countOfEvents == allSignals.size();
    }

    private List<SignalData> getAllSignals(List<Telemetry> telemetries, SignalInfo signalInfo) {
        return telemetries.stream()
                .flatMap(t -> t.getSignals().getOrDefault(signalInfo.getKey(), new HashSet<>()).stream())
                .collect(Collectors.toList());
    }

    private void updateBreakMetadata(TripWrapper tripWrapper, long start, long end) {
        String reason = String.format("Vehicle stationary from %s to %s", start, end);
        TripAnalyticsHelper.updateTripBreakMetadata(tripWrapper, BreakType.IGNITION_ON, reason);
    }

    private void updateUserDetails(TripBreak tripBreak, UserDetails userDetails) {
        String userId = Objects.isNull(userDetails.getUserId()) ? TripAnalyticsHelper.DEFAULT_STRING_VALUE : userDetails.getUserId();
        String profile = Objects.isNull(userDetails.getUserProfile()) ? TripAnalyticsHelper.DEFAULT_STRING_VALUE : userDetails.getUserProfile();
        String name = Objects.isNull(userDetails.getUserName()) ? TripAnalyticsHelper.DEFAULT_STRING_VALUE : userDetails.getUserName();
        String source = Objects.isNull(userDetails.getSource()) ? UserDetailsSource.UNKNOWN.getValue() : userDetails.getSource();

        tripBreak.setUserId(userId);
        tripBreak.setUserProfile(profile);
        tripBreak.setUserName(name);
        tripBreak.setUserDetailsSource(source);
    }

}
