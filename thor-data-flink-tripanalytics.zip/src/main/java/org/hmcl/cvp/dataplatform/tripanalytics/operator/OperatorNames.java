package org.hmcl.cvp.dataplatform.tripanalytics.operator;

public class OperatorNames {

    private OperatorNames() {}

    public static final String TRIP_SOURCE = "trip-source";
    public static final String USER_PREF_SOURCE = "user-pref-source";
    public static final String TRIP_ANALYTICS = "trip-analytics";
    public static final String TRIP_MAP_FUNCTION = "trip-mapper";
    public static final String TRIP_BREAK_MAP_FUNCTION = "trip-break-mapper";
    public static final String TRIP_SINK = "trip-sink";
    public static final String TRIP_BREAK_SINK = "trip-break-sink";
    public static final String TRIP_BREAK_WINDOW_FILTER = "trip-break-window-filter";
    public static final String TRIP_BREAK_WINDOW = "trip-break-window";
    public static final String ENRICH_TRIP = "enrich-trip";
    public static final String ENRICH_TRIP_BREAKS = "enrich-trip-breaks";
    public static final String TRIP_GIF = "trip-gif-generator";
    public static final String TRIP_GIF_SINK = "gif-generator-sink";
    public static final String TRIP_PROCESS_FILTER = "trip-process-filter";
    public static final String TRIP_GIF_FILTER = "trip-gif-filter";
}
