package org.hmcl.cvp.dataplatform.tripanalytics.contract;

public enum TripType {

    START,

    END;
}
