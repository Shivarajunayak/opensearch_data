package org.hmcl.cvp.dataplatform.tripanalytics.contract;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.hmcl.cvp.dataplatform.contract.telemetry.SignalData;

import java.io.Serializable;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class TripSignalData implements Serializable {

    private SignalData signalData;

    private boolean isTripStartSignal;

    private boolean isTripEndSignal;

    private long time;

}
