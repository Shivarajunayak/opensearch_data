package org.hmcl.cvp.dataplatform.tripanalytics.job;

import lombok.extern.slf4j.Slf4j;
import org.apache.flink.api.common.RuntimeExecutionMode;
import org.apache.flink.api.common.eventtime.WatermarkStrategy;
import org.apache.flink.api.java.functions.KeySelector;
import org.apache.flink.api.java.tuple.Tuple2;
import org.apache.flink.api.java.utils.ParameterTool;
import org.apache.flink.connector.base.DeliveryGuarantee;
import org.apache.flink.connector.kafka.sink.KafkaSink;
import org.apache.flink.connector.kafka.source.KafkaSource;
import org.apache.flink.connector.opensearch.sink.FlushBackoffType;
import org.apache.flink.connector.opensearch.sink.Opensearch2Sink;
import org.apache.flink.connector.opensearch.sink.Opensearch2SinkBuilder;
import org.apache.flink.streaming.api.datastream.KeyedStream;
import org.apache.flink.streaming.api.datastream.SingleOutputStreamOperator;
import org.apache.flink.streaming.api.environment.StreamExecutionEnvironment;
import org.apache.flink.streaming.api.windowing.assigners.SlidingEventTimeWindows;
import org.apache.flink.streaming.api.windowing.time.Time;
import org.hmcl.cvp.dataplatform.commons.connector.KafkaConnector;
import org.hmcl.cvp.dataplatform.commons.connector.OpenSearchConnector;
import org.hmcl.cvp.dataplatform.commons.constants.FlinkRuntime;
import org.hmcl.cvp.dataplatform.commons.exception.OpenSearchFailureHandler;
import org.hmcl.cvp.dataplatform.commons.operator.TelemetryFlatMapFunction;
import org.hmcl.cvp.dataplatform.commons.operator.UserPreferenceFlatMapFunction;
import org.hmcl.cvp.dataplatform.commons.stream.SourceStream;
import org.hmcl.cvp.dataplatform.commons.utils.ConnectorUtils;
import org.hmcl.cvp.dataplatform.commons.utils.TelemetryUtils;
import org.hmcl.cvp.dataplatform.contract.telemetry.Telemetry;
import org.hmcl.cvp.dataplatform.contract.userpreference.UserPreference;
import org.hmcl.cvp.dataplatform.tripanalytics.contract.TripBreakKey;
import org.hmcl.cvp.dataplatform.tripanalytics.contract.TripWrapper;
import org.hmcl.cvp.dataplatform.tripanalytics.operator.*;

import java.time.Duration;
import java.util.Map;

@Slf4j
public class TripAnalyticsFlink {

    private static final Integer DEFAULT_MAX_RETRIES = 5;
    private static final Integer DEFAULT_RETRY_DELAY_MILLI = 1000;
    private static final Integer DEFAULT_MAX_ACTIONS_TO_BUFFER = 1;
    private static final Integer DEFAULT_BULK_FLUSH_SIZE_MB = -1;
    private static final Integer DEFAULT_BULK_FLUSH_INTERVAL = -1;

    // Telemetry JSON deserializer
    private static final TelemetryFlatMapFunction telemetryFunction = new TelemetryFlatMapFunction();

    private static final UserPreferenceFlatMapFunction userPrefFlatMapFunction = new UserPreferenceFlatMapFunction();

    // Keyed process function to analyse trips
    private static final TripAnalyticsProcessFunction keyedProcessFunction = new TripAnalyticsProcessFunction();

    // Co Flat map function to connect user preference with trip data
    private static final EnrichTripWithUserDetailsFunction enrichedTripFunction = new EnrichTripWithUserDetailsFunction();

    // Window function to check for trip breaks
    private static final TripAnalyticsWindowFunction windowFunction = new TripAnalyticsWindowFunction();

    // Function to map TripWrapper function to Tuple of OpenSearch index and Map<String, Object> document
    private static final TripAnalyticsOpenSearchMapperFunction opensearchMapperFunction = new TripAnalyticsOpenSearchMapperFunction();

    // OpenSearch emitter to sink the data
    private static final TripAnalyticsOpenSearchEmitter opensearchEmitter = new TripAnalyticsOpenSearchEmitter();

    // Default failure handler which will just log the error
    private static final OpenSearchFailureHandler opensearchFailureHandler = new OpenSearchFailureHandler();

    // Mapper function to sink the trip end data into git generator kafka topic
    private static final TripGifGeneratorMapperFunction gitGeneratorMapperFunction = new TripGifGeneratorMapperFunction();

    // Key selector for trip break - windows will be per key per trip
    private static final KeySelector<TripWrapper, TripBreakKey> tripBreakWindowKey = value -> TripBreakKey.builder()
            .tripId(value.getTripId())
            .virtualId(value.getVirtualId())
            .build();

    public static void main(String[] args) throws Exception {
        final StreamExecutionEnvironment env = StreamExecutionEnvironment.getExecutionEnvironment();
        env.setRuntimeMode(RuntimeExecutionMode.STREAMING);

        final ParameterTool parameterTool = ConnectorUtils.loadApplicationParameters(args, env);
        env.getConfig().setGlobalJobParameters(parameterTool);

        log.info("Application properties:- {}", parameterTool.getProperties());

        boolean isTest = parameterTool.getBoolean(FlinkRuntime.IS_TEST, Boolean.FALSE);
        log.info("Is this being executed as part of test case? {}", isTest);

        // Ignore events older than 1 day
        int maxOutOfOrderInSec = parameterTool.getInt(FlinkRuntime.MAX_OUT_OF_ORDER_IN_SEC, 24 * 60 * 60);
        int idleTimeoutInSec = parameterTool.getInt(FlinkRuntime.IDLE_TIMEOUT_IN_SEC);
        int windowDuration = parameterTool.getInt(FlinkRuntime.TripAnalytics.WINDOW_DURATION, 90);
        int windowSlide = parameterTool.getInt(FlinkRuntime.TripAnalytics.WINDOW_SLIDE_IN_SEC, 89);

        Duration maxOutOfOrder = Duration.ofSeconds(maxOutOfOrderInSec);

        try {

            OpenSearchConnector.OpenSearchProperties openSearchProperties = OpenSearchConnector.getOpenSearchProperties(parameterTool);
            Opensearch2Sink<Tuple2<String, Map<String, Object>>> opensearchSink = getOpenSearchSink(parameterTool, openSearchProperties, isTest);

            KafkaConnector.KafkaProperties kafkaProperties = KafkaConnector.getTelemetryKafkaProperties(parameterTool);
            KafkaSource<String> telemetrySource = KafkaConnector.createStringKafkaSource(kafkaProperties, parameterTool, isTest);

            // User Preference stream KeyBy VID
            KafkaConnector.KafkaProperties thresholdKafkaProps = KafkaConnector.getThresholdKafkaProperties(parameterTool);
            KeyedStream<UserPreference, String> userPreferKeyedStream = SourceStream.getUserPreferenceStream(env,
                    parameterTool,
                    thresholdKafkaProps,
                    userPrefFlatMapFunction,
                    OperatorNames.USER_PREF_SOURCE);

            String topicName = kafkaProperties.getTopics()[0];
            SingleOutputStreamOperator<Telemetry> telemetryStreamOperator = env.fromSource(telemetrySource,
                            WatermarkStrategy.noWatermarks(),
                            topicName)
                    .flatMap(telemetryFunction)
                    .name(OperatorNames.TRIP_SOURCE)
                    .uid(OperatorNames.TRIP_SOURCE);

            WatermarkStrategy<Telemetry> watermarkStrategy = WatermarkStrategy
                    .<Telemetry>forBoundedOutOfOrderness(maxOutOfOrder)
                    .withTimestampAssigner((event, timestamp) -> event.getCollectionEventTime())
                    .withIdleness(Duration.ofSeconds(idleTimeoutInSec));

            KeyedStream<TripWrapper, String> tripAnalyticsWrapper = telemetryStreamOperator
                    // This is need for triggering trip ends after 3 minutes
                    .assignTimestampsAndWatermarks(watermarkStrategy)
                    .keyBy(TelemetryUtils::getVirtualId)
                    .process(keyedProcessFunction)
                    .name(OperatorNames.TRIP_ANALYTICS)
                    .uid(OperatorNames.TRIP_ANALYTICS)
                    .keyBy(TripWrapper::getVirtualId);

            // Connect with user preference
            SingleOutputStreamOperator<TripWrapper> enrichedTripWrapper = tripAnalyticsWrapper
                    .connect(userPreferKeyedStream)
                    .flatMap(enrichedTripFunction)
                    .name(OperatorNames.ENRICH_TRIP)
                    .uid(OperatorNames.ENRICH_TRIP);

            // Sink trip start, end and break
            SingleOutputStreamOperator<TripWrapper> tripsToSink =  enrichedTripWrapper
                    .filter(t -> t.getIsTripStart() || t.getIsTripBreak() || t.getIsTripEnd())
                    .name(OperatorNames.TRIP_PROCESS_FILTER)
                    .uid(OperatorNames.TRIP_PROCESS_FILTER);

            // process ongoing trip events every 90 seconds to check for any breaks
            WatermarkStrategy<TripWrapper> tripBreakWatermarkStrategy = WatermarkStrategy
                    .<TripWrapper>forBoundedOutOfOrderness(maxOutOfOrder)
                    .withTimestampAssigner((tripWrapper, timestamp) -> tripWrapper.getTimestamp())
                    .withIdleness(Duration.ofSeconds(idleTimeoutInSec));

            SingleOutputStreamOperator<TripWrapper> tripBreakProcessOperator = enrichedTripWrapper
                    .assignTimestampsAndWatermarks(tripBreakWatermarkStrategy)
                    .filter(TripWrapper::isNeededForTripBreak)
                    .name(OperatorNames.TRIP_BREAK_WINDOW_FILTER)
                    .uid(OperatorNames.TRIP_BREAK_WINDOW_FILTER)
                    .keyBy(tripBreakWindowKey)
                    .window(SlidingEventTimeWindows.of(Time.seconds(windowDuration), Time.seconds(windowSlide)))
                    .process(windowFunction)
                    .name(OperatorNames.TRIP_BREAK_WINDOW)
                    .uid(OperatorNames.TRIP_BREAK_WINDOW);

            tripsToSink.union(tripBreakProcessOperator)
                    .flatMap(opensearchMapperFunction)
                    .name(OperatorNames.TRIP_MAP_FUNCTION)
                    .uid(OperatorNames.TRIP_MAP_FUNCTION)
                    .sinkTo(opensearchSink)
                    .name(OperatorNames.TRIP_SINK)
                    .uid(OperatorNames.TRIP_SINK);

            //Sink to Kafka topic
            String gifGeneratorTopic = parameterTool.get(FlinkRuntime.TripAnalytics.GIF_GENERATOR_TOPIC_NAME);
            KafkaConnector.KafkaProperties gifGeneratorKafkaProps = getGifGeneratorKafkaProperties(parameterTool, gifGeneratorTopic);
            KafkaSink<String> gifGeneratorSink = KafkaConnector.getKafkaSink(gifGeneratorKafkaProps, parameterTool, isTest);

            SingleOutputStreamOperator<TripWrapper> tripEndsGifToSink = enrichedTripWrapper
                    .filter(TripWrapper::getIsTripEnd)
                    .name(OperatorNames.TRIP_GIF_FILTER)
                    .uid(OperatorNames.TRIP_GIF_FILTER);

            tripEndsGifToSink
                    .startNewChain()
                    .flatMap(gitGeneratorMapperFunction)
                    .name(OperatorNames.TRIP_GIF)
                    .uid(OperatorNames.TRIP_GIF)
                    .sinkTo(gifGeneratorSink)
                    .name(OperatorNames.TRIP_GIF_SINK)
                    .uid(OperatorNames.TRIP_GIF_SINK);

            env.execute();

        } catch (Exception e) {
            log.error("Exception in TripAnalytics flink application: ", e);
        }
    }

    public static Opensearch2Sink<Tuple2<String, Map<String, Object>>> getOpenSearchSink(final ParameterTool parameterTool, OpenSearchConnector.OpenSearchProperties openSearchProperties, boolean isTest) {
        int maxRetries = parameterTool.getInt(FlinkRuntime.OpenSearch.MAX_RETRIES, DEFAULT_MAX_RETRIES);
        int retryDelayInMs = parameterTool.getInt(FlinkRuntime.OpenSearch.RETRY_DELAY_IN_MS, DEFAULT_RETRY_DELAY_MILLI);
        int maxActionsToBuffer = parameterTool.getInt(FlinkRuntime.OpenSearch.MAX_ACTIONS_TO_BUFFER, DEFAULT_MAX_ACTIONS_TO_BUFFER);
        int bulkFlushSize = parameterTool.getInt(FlinkRuntime.OpenSearch.BULK_FLUSH_SIZE_MB, DEFAULT_BULK_FLUSH_SIZE_MB);
        int bulkFlushInterval = parameterTool.getInt(FlinkRuntime.OpenSearch.BULK_FLUSH_INTERVAL_MILLI, DEFAULT_BULK_FLUSH_INTERVAL);

        Opensearch2SinkBuilder<Tuple2<String, Map<String, Object>>> builder = new Opensearch2SinkBuilder<>()
                .setHosts(openSearchProperties.getHttpHost())
                .setEmitter(opensearchEmitter)
                .setConnectionUsername(openSearchProperties.getUsername())
                .setConnectionPassword(openSearchProperties.getPassword())
                .setDeliveryGuarantee(DeliveryGuarantee.AT_LEAST_ONCE)
                .setBulkFlushBackoffStrategy(FlushBackoffType.EXPONENTIAL, maxRetries, retryDelayInMs)
                .setBulkFlushMaxSizeMb(bulkFlushSize)
                .setBulkFlushInterval(bulkFlushInterval)
                .setBulkFlushMaxActions(maxActionsToBuffer)
                .setFailureHandler(opensearchFailureHandler);

        if (isTest) {
            // Enabling insecure access for integration testing
            builder.setAllowInsecure(true);
        }

        return builder.build();
    }

    public static KafkaConnector.KafkaProperties getGifGeneratorKafkaProperties(final ParameterTool parameterTool, final String topic) {
        KafkaConnector.KafkaProperties kafkaProperties = new KafkaConnector.KafkaProperties(parameterTool);
        kafkaProperties.setBrokerFromParams(FlinkRuntime.TripAnalytics.GIF_GENERATOR_BROKER);
        kafkaProperties.setTopics(topic);
        kafkaProperties.setConsumerNameFromParams(FlinkRuntime.TripAnalytics.GIF_GENERATOR_GROUP);
        kafkaProperties.setRoleArnFromParams(FlinkRuntime.TripAnalytics.GIF_GENERATOR_ARN);
        kafkaProperties.setSessionNameFromParams(FlinkRuntime.TripAnalytics.GIF_GENERATOR_SESSION);
        kafkaProperties.setAwsRegionFromParams(FlinkRuntime.REGION_KEY);

        return kafkaProperties;
    }
}
