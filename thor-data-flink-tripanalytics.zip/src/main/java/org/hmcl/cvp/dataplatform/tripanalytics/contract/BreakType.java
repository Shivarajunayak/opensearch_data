package org.hmcl.cvp.dataplatform.tripanalytics.contract;

import com.google.gson.annotations.SerializedName;
import lombok.Getter;

@Getter
public enum BreakType {

    @SerializedName("Ignition_On")
    IGNITION_ON("Ignition_On"),

    @SerializedName("Ignition_Off")
    IGNITION_OFF("Ignition_Off");

    private final String value;

    BreakType(String value) {
        this.value = value;
    }

}
