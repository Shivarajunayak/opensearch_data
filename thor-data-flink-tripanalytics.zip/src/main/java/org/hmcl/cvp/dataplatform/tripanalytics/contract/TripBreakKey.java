package org.hmcl.cvp.dataplatform.tripanalytics.contract;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.util.Objects;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class TripBreakKey implements Serializable {

    private String virtualId;

    private String tripId;

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof TripBreakKey)) return false;
        TripBreakKey that = (TripBreakKey) o;
        return Objects.equals(virtualId, that.virtualId) && Objects.equals(tripId, that.tripId);
    }

    @Override
    public int hashCode() {
        return Objects.hash(virtualId, tripId);
    }
}
