package org.hmcl.cvp.dataplatform.tripanalytics.contract;

import com.google.gson.annotations.SerializedName;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class TripForGif implements Serializable {

    @SerializedName("vid")
    private String vid;

    @SerializedName("tenantId")
    private String tenantId;

    @SerializedName("tripId")
    private String tripId;

    @SerializedName("startTime")
    private Long startTime;

    @SerializedName("startTimeTS")
    private String startTimeTS;

    @SerializedName("endTime")
    private Long endTime;

    @SerializedName("endTimeTS")
    private String endTimeTS;
}
