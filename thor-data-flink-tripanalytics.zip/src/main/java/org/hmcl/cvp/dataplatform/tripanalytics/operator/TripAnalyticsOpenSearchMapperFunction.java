package org.hmcl.cvp.dataplatform.tripanalytics.operator;

import lombok.extern.slf4j.Slf4j;
import org.apache.flink.api.common.functions.RichFlatMapFunction;
import org.apache.flink.api.java.tuple.Tuple2;
import org.apache.flink.configuration.Configuration;
import org.apache.flink.metrics.Counter;
import org.apache.flink.util.Collector;
import org.hmcl.cvp.dataplatform.commons.constants.Constants;
import org.hmcl.cvp.dataplatform.commons.utils.FlinkUtils;
import org.hmcl.cvp.dataplatform.contract.telemetry.Tenant;
import org.hmcl.cvp.dataplatform.tripanalytics.contract.TripBreak;
import org.hmcl.cvp.dataplatform.tripanalytics.contract.TripEnd;
import org.hmcl.cvp.dataplatform.tripanalytics.contract.TripStart;
import org.hmcl.cvp.dataplatform.tripanalytics.contract.TripWrapper;
import org.hmcl.cvp.dataplatform.tripanalytics.job.OpenSearchIndices;

import java.util.Map;
import java.util.Objects;

@Slf4j
public class TripAnalyticsOpenSearchMapperFunction extends RichFlatMapFunction<TripWrapper, Tuple2<String, Map<String, Object>>> {

    private transient Counter numEvTripStarts;
    private transient Counter numEvTripEnds;
    private transient Counter numEvTripBreaks;
    private transient Counter numIceTripStarts;
    private transient Counter numIceTripEnds;
    private transient Counter numIceTripBreaks;
    private transient Counter numHarleyTripStarts;
    private transient Counter numHarleyTripEnds;
    private transient Counter numHarleyTripBreaks;
    private transient Counter numErrorEvents;

    private Counter counterInitializer(String counterName) {

        return getRuntimeContext()
                .getMetricGroup()
                .addGroup(Constants.METRIC_GROUP_NAME)
                .addGroup("TripMapper")
                .counter(counterName);
    }

    @Override
    public void open(Configuration parameters) throws Exception {
        super.open(parameters);

        numEvTripStarts = counterInitializer("numEvTripStarts");
        numEvTripEnds = counterInitializer("numEvTripEnds");
        numEvTripBreaks = counterInitializer("numEvTripBreaks");
        numIceTripStarts = counterInitializer("numIceTripStarts");
        numIceTripEnds = counterInitializer("numIceTripEnds");
        numIceTripBreaks = counterInitializer("numIceTripBreaks");
        numHarleyTripStarts = counterInitializer("numHarleyTripStarts");
        numHarleyTripEnds = counterInitializer("numHarleyTripEnds");
        numHarleyTripBreaks = counterInitializer("numHarleyTripBreaks");
        numErrorEvents = counterInitializer("numErrorEvents");

    }

    @Override
    public void flatMap(TripWrapper value, Collector<Tuple2<String, Map<String, Object>>> out) throws Exception {

        String vid = value.getVirtualId();
        String tripId = value.getTripId();

        try {

            Tuple2<String, Map<String, Object>> tuple = null;

            if(value.getIsTripStart()) {
                log.info("Trip {} start for vehicle {}", tripId, vid);
                tuple = getTripStart(value);
            }

            if (value.getIsTripEnd()) {
                log.info("Trip {} end for vehicle {}", tripId, vid);
                tuple = getTripEnd(value);
            }

            if(value.getIsTripBreak()) {
                log.info("Trip {} break for vehicle {}", tripId, vid);
                tuple = getTripBreak(value);
            }

            if(Objects.nonNull(tuple)) {
                log.info("Sinking {} data into {} for vehicle {}", tripId, tuple.f0, vid);
                out.collect(tuple);
                return;
            }

            log.info("Trip {} was not sunk to opensearch for vehicle {}", tripId, vid);

        } catch (Exception e) {
            log.error("Exception while mapping trip events to index for trip {} and vehicle {}", tripId, vid, e);
        }

    }

    private Tuple2<String, Map<String, Object>> getTripStart(TripWrapper value) {
        String tripStartIndex = getTripStartIndex(value.getTenant());
        if(Objects.isNull(tripStartIndex)) return null;

        TripStart tripStart = value.getTripStart();
        if(Objects.isNull(tripStart)) return null;

        Map<String, Object> document = FlinkUtils.toMap(tripStart);
        return new Tuple2<>(tripStartIndex, document);
    }

    private Tuple2<String, Map<String, Object>> getTripEnd(TripWrapper value) {
        String tripEndIndex = getTripEndIndex(value.getTenant());
        if(Objects.isNull(tripEndIndex)) return null;

        TripEnd tripEnd = value.getTripEnd();
        if(Objects.isNull(tripEnd)) return null;

        Map<String, Object> document = FlinkUtils.toMap(tripEnd);
        return new Tuple2<>(tripEndIndex, document);
    }

    private Tuple2<String, Map<String, Object>> getTripBreak(TripWrapper value) {
        String tripBreakIndex = getTripBreakIndex(value.getTenant());
        if(Objects.isNull(tripBreakIndex)) return null;

        TripBreak tripBreak = value.getTripBreak();
        if(Objects.isNull(tripBreak)) return null;

        Map<String, Object> document = FlinkUtils.toMap(tripBreak);
        return new Tuple2<>(tripBreakIndex, document);
    }

    private String getTripStartIndex(Tenant tenant) {
        switch (tenant) {
            case EV:
                numEvTripStarts.inc();
                return OpenSearchIndices.EV_TRIP_START_INDEX;
            case HARLEY:
                numHarleyTripStarts.inc();
                return OpenSearchIndices.HARLEY_TRIP_START_INDEX;
            case ICE:
                numIceTripStarts.inc();
                return OpenSearchIndices.ICE_TRIP_START_INDEX;
            default:
                numErrorEvents.inc();
                throw new IllegalArgumentException("Unsupported tenant type for trip start index: " + tenant);
        }
    }

    private String getTripEndIndex(Tenant tenant) {
        switch (tenant) {
            case EV:
                numEvTripEnds.inc();
                return OpenSearchIndices.EV_TRIP_END_INDEX;
            case HARLEY:
                numHarleyTripEnds.inc();
                return OpenSearchIndices.HARLEY_TRIP_END_INDEX;
            case ICE:
                numIceTripEnds.inc();
                return OpenSearchIndices.ICE_TRIP_END_INDEX;
            default:
                numErrorEvents.inc();
                throw new IllegalArgumentException("Unsupported tenant type for trip end index: " + tenant);
        }
    }

    private String getTripBreakIndex(Tenant tenant) {
        switch (tenant) {
            case EV:
                numEvTripBreaks.inc();
                return OpenSearchIndices.EV_TRIP_BREAK_INDEX;
            case HARLEY:
                numHarleyTripBreaks.inc();
                return OpenSearchIndices.HARLEY_TRIP_BREAK_INDEX;
            case ICE:
                numIceTripBreaks.inc();
                return OpenSearchIndices.ICE_TRIP_BREAK_INDEX;
            default:
                numErrorEvents.inc();
                throw new IllegalArgumentException("Unsupported tenant type for trip break index: " + tenant);
        }
    }
}
