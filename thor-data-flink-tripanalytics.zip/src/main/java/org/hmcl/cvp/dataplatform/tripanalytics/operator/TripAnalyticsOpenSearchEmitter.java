package org.hmcl.cvp.dataplatform.tripanalytics.operator;

import org.apache.flink.api.connector.sink2.SinkWriter;
import org.apache.flink.api.java.tuple.Tuple2;
import org.apache.flink.connector.opensearch.sink.OpensearchEmitter;
import org.apache.flink.connector.opensearch.sink.RequestIndexer;
import org.opensearch.action.DocWriteRequest;
import org.opensearch.action.index.IndexRequest;
import org.opensearch.client.Requests;

import java.util.Map;

public class TripAnalyticsOpenSearchEmitter implements OpensearchEmitter<Tuple2<String, Map<String, Object>>> {

    private IndexRequest createIndexRequest(Tuple2<String, Map<String, Object>> element) {
        // Let the id be auto generated
        return Requests.indexRequest()
                .index(element.f0)
                .source(element.f1)
                .opType(DocWriteRequest.OpType.CREATE); // This is required for writing to stream indexes
    }

    @Override
    public void emit(Tuple2<String, Map<String, Object>> element, SinkWriter.Context context, RequestIndexer indexer) {
        indexer.add(createIndexRequest(element));
    }

}
