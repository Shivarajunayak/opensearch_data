package org.hmcl.cvp.dataplatform.tripanalytics.operator;

import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.extern.slf4j.Slf4j;
import org.apache.flink.api.common.state.MapState;
import org.apache.flink.api.common.state.MapStateDescriptor;
import org.apache.flink.api.java.tuple.Tuple2;
import org.apache.flink.api.java.utils.ParameterTool;
import org.apache.flink.configuration.Configuration;
import org.apache.flink.metrics.Counter;
import org.apache.flink.streaming.api.functions.KeyedProcessFunction;
import org.apache.flink.util.Collector;
import org.hmcl.cvp.dataplatform.commons.constants.Constants;
import org.hmcl.cvp.dataplatform.commons.constants.FlinkRuntime;
import org.hmcl.cvp.dataplatform.commons.utils.DateUtils;
import org.hmcl.cvp.dataplatform.commons.utils.SignalUtils;
import org.hmcl.cvp.dataplatform.commons.utils.TelemetryUtils;
import org.hmcl.cvp.dataplatform.contract.telemetry.LatLongPair;
import org.hmcl.cvp.dataplatform.contract.telemetry.SignalData;
import org.hmcl.cvp.dataplatform.contract.telemetry.Telemetry;
import org.hmcl.cvp.dataplatform.tripanalytics.contract.*;
import org.hmcl.cvp.dataplatform.tripanalytics.helper.TripAnalyticsHelper;

import java.time.Instant;
import java.util.*;
import java.util.stream.Collectors;

@Slf4j
public class TripAnalyticsProcessFunction extends KeyedProcessFunction<String, Telemetry, TripWrapper> {

    /**
     * Store trip start events
     * <p>
     * TTL -> 15 hours
     * Clearing Strategy -> Once the end trip event is received
     * Update Value Strategy -> A new trip is received before the previous trip end.
     * The previous trip will be updated as provisional
     * </p>
     * <p>
     * Key -> Virtual ID
     * Value -> Set of TripWrapper objects
     * </p>
     */
    private transient MapState<String, Set<TripWrapper>> tripsState;

    /**
     * MapState to hold tripIds which need to be joined
     * Key - vehicleId
     * Value - Set of trip joiners
     * TTL -> 15 hours
     */
    private transient MapState<String, Set<TripJoiner>> tripJoinerState;

    /**
     * MapState to hold tripIds which need to be joined
     * Key - vehicleId
     * Value - Set of processed trips
     * TTL -> 15 hours
     */
    private transient MapState<String, Set<Trip>> processedTripsState;

    private transient MapState<String, LatLongState> latLongStateMap;

    private transient Counter numTripsStarted;
    private transient Counter numTripsWithStartFlag;
    private transient Counter numTripsEnded;
    private transient Counter numTripsWithEndFlag;
    private transient Counter numTripBreaks;
    private transient Counter numTripsCollected;
    private transient Counter numTripRemoved;
    private transient Counter numEventsIgnored;

    private transient long tripStateTtlInHr;
    private transient int tripDiffForBreaksInMin;
    private transient int endTripTimerInMin;
    private static final ObjectMapper objectMapper = new ObjectMapper();

    private Counter counterInitializer(String counterName) {

        return getRuntimeContext()
                .getMetricGroup()
                .addGroup(Constants.METRIC_GROUP_NAME)
                .addGroup("TripAnalytics")
                .counter(counterName);
    }

    @Override
    public void open(Configuration parameters) throws Exception {
        super.open(parameters);

        ParameterTool parameterTool = (ParameterTool) getRuntimeContext().getExecutionConfig().getGlobalJobParameters();
        tripStateTtlInHr = parameterTool.getLong(FlinkRuntime.TripAnalytics.TRIP_TTL_IN_HOURS, 15L);
        tripDiffForBreaksInMin = parameterTool.getInt(FlinkRuntime.TripAnalytics.TRIP_BREAK_DIFF_IN_MIN, 3);
        endTripTimerInMin = parameterTool.getInt(FlinkRuntime.TripAnalytics.END_TRIP_WAIT_TIMER_IN_MIN, 3);

        numTripsStarted = counterInitializer("numTripsStarted");
        numTripsWithStartFlag = counterInitializer("numTripsWithStartFlag");
        numTripsCollected = counterInitializer("numTripsCollected");
        numTripsWithEndFlag = counterInitializer("numTripsWithEndFlag");
        numTripsEnded = counterInitializer("numTripsEnded");
        numTripBreaks = counterInitializer("numTripBreaks");
        numTripRemoved = counterInitializer("numTripRemoved");
        numEventsIgnored = counterInitializer("numEventsIgnored");

        MapStateDescriptor<String, Set<TripWrapper>> tripStateDescriptor = StateDescriptors.getTripStateDescriptor(tripStateTtlInHr);
        tripsState = getRuntimeContext().getMapState(tripStateDescriptor);

        MapStateDescriptor<String, Set<TripJoiner>> tripJoinerDescriptor = StateDescriptors.getTripJoinerDescriptor(tripStateTtlInHr);
        tripJoinerState = getRuntimeContext().getMapState(tripJoinerDescriptor);

        MapStateDescriptor<String, Set<Trip>> processedTripsDescriptor = StateDescriptors.getProcessedTripsDescriptor(tripStateTtlInHr);
        processedTripsState =  getRuntimeContext().getMapState(processedTripsDescriptor);

        MapStateDescriptor<String, LatLongState> latLongStateMapStateDescriptor = StateDescriptors.latLongMapStateDescriptor();
        latLongStateMap = getRuntimeContext().getMapState(latLongStateMapStateDescriptor);

    }

    @Override
    public void processElement(Telemetry value, Context ctx, Collector<TripWrapper> out) throws Exception {
        String incomingVid = TelemetryUtils.getVirtualId(value);

        long watermark = ctx.timerService().currentWatermark();
        long timestamp = ctx.timestamp();

        log.info("For vehicle {}, Current timestamp is {} and current watermark is {}", incomingVid, timestamp, watermark);

        LatLongState cachedLatLongState = Objects.isNull(latLongStateMap.get(incomingVid)) ? LatLongState.builder().build() : latLongStateMap.get(incomingVid);
        updateLatLongInState(value, cachedLatLongState, incomingVid);

        try {

            if(!TripAnalyticsHelper.isPartOfIgnitionCampaigns(value) ) {
                log.info("Event is not part of ignition fall or rise campaigns for vehicle {}. Ignoring!!", incomingVid);

                numEventsIgnored.inc();
                return;
            }

            List<SignalData> tripStartFlagSignals = TripAnalyticsHelper.getTripStartSignals(value);
            List<SignalData> tripEndFlagSignals = TripAnalyticsHelper.getTripEndSignals(value);

            if (tripStartFlagSignals.isEmpty() && tripEndFlagSignals.isEmpty()) {
                log.info("The incoming event for vehicle {} is not a trip start or end. Checking if a trip has started for trip break calc.", incomingVid);
                numTripsCollected.inc();
                processEventsNeededForTripBreak(incomingVid, value, out);

                return;
            }

            // Both trip start and trip end signals can come in a single packet
            List<TripSignalData> allTripSignals = TripAnalyticsHelper.getTripSignals(tripStartFlagSignals, tripEndFlagSignals);
            // alltrip signals are start and end signals sorted in natural order of packet timestamps, so they are processed, as they were generated
            for(TripSignalData tripSignal : allTripSignals) {

                if(tripSignal.isTripStartSignal()) {
                    numTripsWithStartFlag.inc();

                    SignalData tripStartFlagSignal = tripSignal.getSignalData();
                    log.info("Start trip signal {} for vehicle {}", tripStartFlagSignal, incomingVid);
                    TripStartSignalWrapper startSignalWrapper = TripStartSignalWrapper.fromTripStartSignal(tripStartFlagSignal);
                    processTripStartAndTripBreak(incomingVid, startSignalWrapper, value, ctx, out);
                }

                if(tripSignal.isTripEndSignal()) {
                    numTripsWithEndFlag.inc();

                    SignalData tripEndFlagSignal = tripSignal.getSignalData();
                    log.info("End trip signal {} for vehicle {}", tripEndFlagSignal, incomingVid);

                    processTripEnd(incomingVid, tripEndFlagSignal, value, ctx, out);

                }
            }

        } catch (Exception e) {
            log.error("Exception while processing telemetry events for vehicle {}", incomingVid, e);
        }
    }

    @Override
    public void onTimer(long timestamp, OnTimerContext ctx, Collector<TripWrapper> out) throws Exception {
        super.onTimer(timestamp, ctx, out);
        String vid = ctx.getCurrentKey();
        long watermark = ctx.timerService().currentWatermark();

        log.info("Timer triggered for vehicle {} at {} and watermark {}", vid, timestamp, watermark);

        try {

            // Get all the cached trips for the vehicle
            Set<TripWrapper> cachedTrips = getCachedTripsState(vid);
            if (cachedTrips.isEmpty()) {
                log.warn("No cached trips found for vehicle {} inside onTimer", vid);
                return;
            }

            // Get the end trips
            Set<TripWrapper> allEndTrips = cachedTrips.stream().filter(TripWrapper::getIsTripEnd).collect(Collectors.toSet());
            if (allEndTrips.isEmpty()) {
                log.warn("No end trips found for vehicle {} inside onTimer", vid);
                return;
            }

            // Get the end trips for which timer was triggered
            Set<TripWrapper> tripsThatEnded = allEndTrips.stream().filter(t -> {
                long tripEndedTime = getTimerTime(t.getWatermark());
                return tripEndedTime >= timestamp;
            }).collect(Collectors.toSet());

            if (tripsThatEnded.isEmpty()) {
                log.warn("No end trips older than the triggered time {} found for vehicle {} inside onTimer", timestamp, vid);
                return;
            }

            long currentTime = DateUtils.currentEpochTime();
            String currentTimeTs = DateUtils.formatToISO(currentTime);

            // Collect and Remove these trips from state
            collectAndRemoveTripsFromState(out, tripsThatEnded, currentTime, currentTimeTs, vid, cachedTrips);

            // Get all the trip starts and breaks older than ttl that may be present in state and remove them.
            // This is because, since the value in the map state is set, ttl will get updated for every new trip.
            // TTL will be cleared only of no trips are received new trips are received for the vehicle in 15 hours
            Instant ttlInstant = Instant.now().minusSeconds(tripStateTtlInHr * 60 * 60);
            long ttlTime = ttlInstant.toEpochMilli();
            String ttlTimeTsp = DateUtils.formatToISO(ttlTime);
            Set<TripWrapper> olderCachedTrips = getCachedTripsState(vid);
            Set<TripWrapper> olderTrips = olderCachedTrips.stream()
                    .filter(t -> ttlTime > t.getSystemTime())
                    .filter(t -> t.getIsTripStart() || t.getIsTripBreak())
                    .collect(Collectors.toSet());

            // Collect and Remove these trips from state
            for (TripWrapper olderTrip : olderTrips) {
                numTripRemoved.inc();
                long processTime = olderTrip.getSystemTime();
                String processTimeTsp = DateUtils.formatToISO(processTime);

                log.info("Trip {} which was processed at {} - {} has expired at {} - {} for vehicle {}",
                        olderTrip.getTripId(), processTime, processTimeTsp, ttlTime, ttlTimeTsp, vid);

                // Remove all the events related to this trip from trip state
                removeAllRelatedTripFromState(vid, olderTrip);

                // Remove from trip joiner
                removeTripJoinerState(vid, olderTrip);

                // Remove processed trips
                removeProcessedTripsFromState(vid, olderTrip);
            }

        } catch (Exception e) {
            log.error("Exception in onTimer for vehicle {}", vid, e);
        }
    }

    private void collectAndRemoveTripsFromState(Collector<TripWrapper> out, Set<TripWrapper> tripsThatEnded, long currentTime, String currentTimeTs, String vid, Set<TripWrapper> cachedTrips) {
        for (TripWrapper tripEndWrapper : tripsThatEnded) {
            numTripsEnded.inc();

            TripEnd tripEnd = tripEndWrapper.getTripEnd();
            tripEnd.setFlinkEndTime(currentTime);
            tripEnd.setFlinkEndTimeTs(currentTimeTs);

            tripEndWrapper.setTripEnd(tripEnd);

            log.info("Trip {} has ended for vehicle {}", tripEndWrapper.getTripId(), vid);

            // if the trip start has the invalid lat long flag still set to true,
            // collect the start trip event as it is
            Optional<TripWrapper> tripStartWrapper = cachedTrips.stream()
                    .filter(t -> t.getTripId().equals(tripEndWrapper.getTripId()) && t.getIsTripStart())
                    .findFirst();

            log.info("Fetched Trip Start Wrapper from cache, isTripStart Present: {}, trip startWrapper is:  {} for vid: {}", tripStartWrapper.isPresent(), tripStartWrapper, vid);


            tripStartWrapper.ifPresent(t -> {
                log.info("Checking if trip start has invalid latlong: {} ", t.getIsTripStartLatLongInvalid());
                if (t.getIsTripStartLatLongInvalid()) {
                    log.info("Yes lat longs are invalid for trip Start, collecting it as it is");
                    out.collect(t);
                }
            });
            try {
                log.info("Checking if trip end has invalid latlong: {} ", tripEnd);
                log.info("Parameters being checked to update lat long in tripend are: ");
                log.info("tripStartWrapper.isPresent(): {} ",tripStartWrapper.isPresent());
                log.info("tripStartWrapper.get().getTripStart().getCollectionEventTime(): {} ", tripStartWrapper.get().getTripStart().getCollectionEventTime());
                log.info("latLongStateMap.get(tripEnd.getVirtualId()).getDetectionWindowStartTimestamp(): {} ", latLongStateMap.get(tripEnd.getVirtualId()).getDetectionWindowStartTimestamp());

                if (tripStartWrapper.get().getTripStart().getCollectionEventTime() <= latLongStateMap.get(tripEnd.getVirtualId()).getDetectionWindowStartTimestamp()) {
                    log.info("Trip start is present and collection event time of trip start is less than current detection window start timestamp");
                    updateLatLongInTripEnd(tripEnd);
                }
            } catch (Exception e) {
                log.error("Error while setting latitude and longitude for trip start for vehicle inside onTimer {}", tripEnd.getVirtualId(), e);
            }
            log.info("collecting trip end wrapper, final trip end object is: {}", tripEndWrapper);

            out.collect(tripEndWrapper);

            // Remove all the events related to this trip from trip state
            removeAllRelatedTripFromState(vid, tripEndWrapper);

            // Remove from trip joiner
            removeTripJoinerState(vid, tripEndWrapper);
        }
    }

    private void updateLatLongInTripEnd(TripEnd tripEnd) throws Exception {
        log.info("Inside updateLatLongInTripEnd method for trip end:  {} ", tripEnd);
        if (tripEnd.getLatitude() == null || tripEnd.getLatitude() == 0) {
            log.info("Trip end latitude is null or 0, setting it to latlong state for trip end: {}", tripEnd);
            tripEnd.setLatitude(latLongStateMap.get(tripEnd.getVirtualId()).getLatitude());
        }

        if (tripEnd.getLongitude() == null || tripEnd.getLongitude() == 0) {
            log.info("Trip end longitude is null or 0, setting it to latlong state for trip end: {}", tripEnd);
            tripEnd.setLongitude(latLongStateMap.get(tripEnd.getVirtualId()).getLongitude());
        }
    }

    private void processTripStartAndTripBreak(String incomingVid,
                                              TripStartSignalWrapper tripStartSignalWrapper,
                                              Telemetry value,
                                              Context ctx,
                                              Collector<TripWrapper> out) {

        try {

            boolean inferTripStartFromEnd = false;
            TripStartSignal tripStartSignal = null;
            if(tripStartSignalWrapper.getIsTripStartSignal()) {
                tripStartSignal = tripStartSignalWrapper.getTripStartSignal();
            } else {
                TripEndSignal tripEndSignal = tripStartSignalWrapper.getTripEndSignal();
                if(Objects.nonNull(tripEndSignal)) {
                    inferTripStartFromEnd = true;
                    tripStartSignal = tripEndSignal.getStart();
                }
            }

            if (Objects.isNull(tripStartSignal)) {
                numEventsIgnored.inc();
                log.warn("Trip start flag is null for vehicle {}", incomingVid);
                return;
            }

            String incomingTripId = tripStartSignalWrapper.getTripId();
            if (Objects.isNull(incomingTripId)) {
                numEventsIgnored.inc();
                log.warn("Trip Id is missing while processing trip starts for vehicle {}", incomingVid);
                return;
            }

            log.info("Incoming start trip {} for vehicle {}", incomingTripId, incomingVid);
            if (isTripStartAlreadyProcessed(incomingVid, incomingTripId)) {
                numEventsIgnored.inc();
                log.warn("Trip start flag for trip {} already received for vehicle {}", incomingTripId, incomingVid);
                return;
            }

            if(inferTripStartFromEnd) log.warn("Inferring trip start for tripId {} from trip end signal for vehicle {}", incomingTripId, incomingVid);

            // Update trip start as processed in state
            updateProcessedTripStart(incomingVid, incomingTripId);

            Long tripStartTime = tripStartSignal.getTimestamp();

            // Get all the previous trip end events for the vehicle
            Set<TripWrapper> endTripsWhichHaveBroken = getPreviousTripEnds(incomingVid, incomingTripId, tripStartTime);

            if (endTripsWhichHaveBroken.isEmpty()) {
                numTripsStarted.inc();
                log.info("Incoming trip {} is not a continuation of an existing trip for vehicle {}", incomingTripId, incomingVid);

                TripWrapper wrapper = TripAnalyticsHelper.getTripStart(incomingVid, incomingTripId, tripStartSignal, value, inferTripStartFromEnd);

                // check if trip start has invalid lat longs
                TripStart tripStart = wrapper.getTripStart();
                if (tripStart.getLatitude() == null || tripStart.getLatitude() == 0 || tripStart.getLongitude() == null || tripStart.getLongitude() == 0) {
                    wrapper.setIsTripStartLatLongInvalid(true);
                    // don't collect the trip start till we have valid lat longs
                } else {
                    wrapper.setIsTripStartLatLongInvalid(false);
                    out.collect(wrapper);
                }

                updateTripsState(incomingVid, wrapper);

                return;
            }

            for (TripWrapper brokenEndTrip : endTripsWhichHaveBroken) {
                String previousTripId = brokenEndTrip.getTripId();
                long breakStartTime = brokenEndTrip.getTimestamp();
                long breakEndTime = tripStartTime;

                // Delete Trip ends
                removeTripEndsFromState(incomingVid, brokenEndTrip);

                // Process for trip breaks
                processTripBreaks(incomingVid, incomingTripId, previousTripId, breakStartTime, breakEndTime, value, out);

                // De-Register this broken trip from timer
                deRegisterTimers(incomingVid, brokenEndTrip.getWatermark(), ctx);

                // Update the trip joiner state
                updateTripJoinerState(incomingVid, incomingTripId, previousTripId);
            }

        } catch (Exception e) {
            numEventsIgnored.inc();
            log.error("Exception while processing trip start for vehicle {}", incomingVid, e);
        }
    }

    private void processTripBreaks(String incomingVid,
                                   String incomingTripId,
                                   String previousTripId,
                                   long breakStartTime,
                                   long breakEndTime,
                                   Telemetry value, Collector<TripWrapper> out) {

        numTripBreaks.inc();

        log.info("Trip {} has broken with new trip {} for vehicle {}", previousTripId, incomingTripId, incomingVid);

        TripWrapper tripBreakWrapper = TripAnalyticsHelper.getTripBreak(incomingVid, previousTripId, incomingTripId, breakStartTime, value);

        // Set latest element timestamp as trip break
        TripBreak tripBreak = tripBreakWrapper.getTripBreak();
        tripBreak.setEndTimestamp(DateUtils.formatToISO(breakEndTime));

        // update invalid lat longs in tripbreak object
        try {
            if(tripBreak.getLatitude() == null || tripBreak.getLatitude() == 0){
                tripBreak.setLatitude(latLongStateMap.get(incomingVid).getLatitude());
            }

            if(tripBreak.getLongitude() == null || tripBreak.getLongitude() == 0){
                tripBreak.setLongitude(latLongStateMap.get(incomingVid).getLongitude());
            }
        } catch (Exception e) {
            log.error("Error while setting latitude and longitude for trip start for vehicle inside processTripBreaks {}", tripBreak.getVirtualId(), e);
        }


        tripBreakWrapper.setTripBreak(tripBreak);

        String reason = String.format("%s was broken by %s", previousTripId, incomingTripId);
        TripAnalyticsHelper.updateTripBreakMetadata(tripBreakWrapper, BreakType.IGNITION_OFF, reason);

        updateTripsState(incomingVid, tripBreakWrapper);

        out.collect(tripBreakWrapper);

    }

    // We will consider trip end only if for the incoming trip, there was already a trip start flag was received
    private void processTripEnd(String incomingVid,
                                SignalData tripEndFlag,
                                Telemetry value,
                                Context ctx,
                                Collector<TripWrapper> out) {

        try {

            TripEndSignal tripEndSignal = TripAnalyticsHelper.getTripEndSignalValue(tripEndFlag);
            if (Objects.isNull(tripEndSignal)) {
                numEventsIgnored.inc();
                log.warn("Trip end flag is null for vehicle {}", incomingVid);
                return;
            }

            String incomingTripId = tripEndSignal.getTripId();
            if (Objects.isNull(incomingTripId)) {
                numEventsIgnored.inc();
                log.warn("Trip Id is missing in trip end flag is null for vehicle {}", incomingVid);
                return;
            }

            if(isTripEndAlreadyProcessed(incomingVid, incomingTripId)) {
                numEventsIgnored.inc();
                log.warn("End trip for TripId {} is already processed for vehicle {}. So ignoring.", incomingTripId, incomingVid);
                return;
            }

            Tuple2<Boolean, String> tripJoin = checkAndGetTripJoiner(incomingVid, incomingTripId);
            String joinedTripId = tripJoin.f1;
            log.info("Incoming signal trip is {} and joined trip is {} for vehicle {}", incomingTripId, joinedTripId, incomingVid);

            TripWrapper tripStart = getTripStartFromState(incomingVid, joinedTripId);
            if(Objects.isNull(tripStart)) {
                log.warn("End flag received for Trip {} and vehicle {} but no start trip found", incomingTripId, incomingVid);

                // Inferring trip start from trip end now
                TripStartSignalWrapper endSignalWrapper = TripStartSignalWrapper.fromTripEndSignal(tripEndFlag);
                processTripStartAndTripBreak(incomingVid, endSignalWrapper, value, ctx, out);

                // Get the trip start from cache again
                tripJoin = checkAndGetTripJoiner(incomingVid, incomingTripId);
                joinedTripId = tripJoin.f1;
                log.info("Incoming trip {} and joined trip {} after inferring from trip end for vehicle {}", incomingTripId, joinedTripId, incomingVid);

                tripStart = getTripStartFromState(incomingVid, joinedTripId);
            }

            // Check of trip start is still null
            if(Objects.isNull(tripStart)) {
                log.error("No Trip start found for trip {} even after inferring from trip end signal for vehicle {}", incomingTripId, incomingVid);
            }

            log.info("End flag received for Trip {} and vehicle {}", incomingTripId, incomingVid);

            long currentWatermark = ctx.timerService().currentWatermark();

            TripWrapper tripEndWrapper = TripAnalyticsHelper.getTripEnd(incomingVid, joinedTripId, tripEndSignal, tripStart, value);
            tripEndWrapper.setIncomingTripId(incomingTripId);
            tripEndWrapper.setWatermark(currentWatermark);

            updateTripsState(incomingVid, tripEndWrapper);

            //Register a timer
            registerTimers(incomingVid, currentWatermark, ctx);

            // Update this trip has processed in state
            updateProcessedTripEnd(incomingVid, incomingTripId);

        } catch (Exception e) {
            numEventsIgnored.inc();
            log.error("Exception while processing trip end for vehicle {}", incomingVid, e);
        }

    }

    private void processEventsNeededForTripBreak(String incomingVid, Telemetry value, Collector<TripWrapper> out) throws Exception {
        log.info("Incoming trip time for vehicle {} is {}", incomingVid, value.getCollectionEventTime());
        Set<TripWrapper> cachedTrips = getCachedTripsState(incomingVid);
        log.info("There are {} trips in cache for vehicle {}", cachedTrips.size(), incomingVid);

        if (cachedTrips.isEmpty()) return;

        // Get all the trip starts and sort it by latest to oldest
        Set<TripWrapper> tripStarts = cachedTrips.stream()
                .filter(TripWrapper::getIsTripStart)
                .sorted(Comparator.comparing(TripWrapper::getTimestamp).reversed())
                .collect(Collectors.toCollection(LinkedHashSet::new));

        log.info("There are {} trip starts in cache for vehicle {}", tripStarts.size(), incomingVid);
        log.info("trip starts {} in cache for vehicle {}", tripStarts, incomingVid);

        if (tripStarts.isEmpty()) {
            log.info("No trip starts found in cache for vehicle {}", incomingVid);
            return;
        }

        // Get the most recent trip compared to the incoming value
        Optional<TripWrapper> validTripForIncomingEvent = tripStarts.stream()
                .filter(t -> value.getCollectionEventTime() > t.getTimestamp())
                .findFirst();

        if (validTripForIncomingEvent.isEmpty()) {
            log.info("No valid trip starts with timeStamp less than the incoming event time found in cache for vehicle {}", incomingVid);
            return;
        }

        TripWrapper validTripStart = validTripForIncomingEvent.get();
        String tripId =validTripStart.getTripId();
        boolean isTripEndReceived = cachedTrips
                .stream()
                .anyMatch(t -> t.getIsTripEnd() && Objects.equals(t.getTripId(), tripId));

        if(isTripEndReceived) {
            log.info("Trip end already received for trip id {} for vehicle {}", tripId, incomingVid);
            return;
        }

        long eventTime = value.getCollectionEventTime();

        double validLatitude = latLongStateMap.get(incomingVid) == null ? 0.0 : latLongStateMap.get(incomingVid).getLatitude();
        double validLongitude = latLongStateMap.get(incomingVid) == null ? 0.0 : latLongStateMap.get(incomingVid).getLongitude();

        TripWrapper tripWrapper = TripWrapper.builder()
                .tripId(tripId)
                .virtualId(incomingVid)
                .neededForTripBreak(true)
                .userDetails(TripAnalyticsHelper.getUserDetails(value))
                .timestamp(eventTime)
                .event(value)
                .lastValidLatitude(validLatitude)
                .lastValidLongitude(validLongitude)
                .build();

        log.info("Inside processEventsNeededForTripBreak, for VID: {}", incomingVid);
        log.info("validTripStart.getIsTripStartLatLongInvalid():  {}, for VID: {}", validTripStart.getIsTripStartLatLongInvalid(), incomingVid);
        // check if this trip start has invalid lat long and if we have valid lat longs now
        if (validTripStart.getIsTripStartLatLongInvalid()) {
            try {
                log.info("latLongStateMap.get(incomingVid).getDetectionWindowStartTimestamp():  {} ,validTripStart.getTimestamp():{} , for VID: {}", latLongStateMap.get(incomingVid).getDetectionWindowStartTimestamp(), validTripStart.getTimestamp(), incomingVid);

                if (latLongStateMap.get(incomingVid).getDetectionWindowStartTimestamp() >= validTripStart.getTimestamp()) {
                    Optional<TripWrapper> optionalTripStartToUpdate = cachedTrips.stream()
                            .filter(TripWrapper::getIsTripStart)
                            .filter(t -> t.getTripId().equals(tripId))
                            .findFirst();
                    log.info("optionalTripStartToUpdate.isPresent(): {}, for VID: {}", optionalTripStartToUpdate.isPresent(), incomingVid);
                    if(optionalTripStartToUpdate.isPresent()){
                        TripWrapper tripStartToUpdate = optionalTripStartToUpdate.get();
                        tripStartToUpdate.getTripStart().setLatitude(validLatitude);
                        tripStartToUpdate.getTripStart().setLongitude(validLongitude);
                        tripStartToUpdate.setIsTripStartLatLongInvalid(false); // Update the field
                        updateTripsState(incomingVid, tripStartToUpdate);
                        log.info("Trip start should have been updated with false for IsTripStartLatLongInvalid vehicle {} in cache {}", incomingVid, getCachedTripsState(incomingVid));
                        out.collect(tripStartToUpdate); // Collect the updated object
                    }
                }

            } catch (Exception e) {
                log.error("Error while setting latitude and longitude for trip start for vehicle inside processEventsNeededForTripBreak {}", incomingVid, e);
            }
        }

        log.info("Event at {} is needed for trip break for vehicle {}", eventTime, incomingVid);
        out.collect(tripWrapper);
    }

    private Tuple2<Boolean, String> checkAndGetTripJoiner(String incomingVid, String incomingTripId) {
        TripJoiner tripJoiner = getTripJoiner(incomingVid, incomingTripId);
        boolean previousTripContinuation = Objects.nonNull(tripJoiner);
        String tripJoinerId = previousTripContinuation ? tripJoiner.getTripJoinerId() : incomingTripId;
        return new Tuple2<>(previousTripContinuation, tripJoinerId);
    }

    private Set<TripWrapper> getPreviousTripEnds(String vid, String incomingTripId, long currentTripStartTime) {
        Set<TripWrapper> cachedTrips = getCachedTripsState(vid);
        if (cachedTrips.isEmpty()) new HashSet<>();

        log.info("Cached trips for vehicle {} : {}", vid, cachedTrips);

        return cachedTrips.stream()
                .filter(TripWrapper::getIsTripEnd)
                .filter(tripEnd -> currentTripStartTime > tripEnd.getTimestamp())
                .filter(tripEnd -> isTripStartedImmediatelyFollowingAnotherTrip(incomingTripId, currentTripStartTime, tripEnd))
                .collect(Collectors.toSet());
    }

    private boolean isTripStartedImmediatelyFollowingAnotherTrip(String incomingTripId, long currentTripStartTime, TripWrapper previousEndTripWrapper) {
        log.info("Checking for immediate trip starts for incomingTrip {} with end trip {}", incomingTripId, previousEndTripWrapper);

        if (incomingTripId.equals(previousEndTripWrapper.getTripId())) return false;

        long timeDiff = currentTripStartTime - previousEndTripWrapper.getTimestamp();
        if (timeDiff < 0) return false;

        return DateUtils.minToMs(tripDiffForBreaksInMin) >= timeDiff;

    }

    private void registerTimers(String vid, long currentWatermark, Context ctx) {
        try {
            long timerRegistrationTime = getTimerTime(currentWatermark);
            log.info("Registering end trip timer for vehicle {} at {}", vid, timerRegistrationTime);
            ctx.timerService().registerEventTimeTimer(timerRegistrationTime);
        } catch (Exception e) {
            log.error("Error while registering timers for vehicle {}", vid);
        }

    }

    private void deRegisterTimers(String vid, long watermark, Context ctx) {
        try {
            long timerDeRegistrationTime = getTimerTime(watermark);
            log.info("De-registering end trip timer for vehicle {} at {}", vid, timerDeRegistrationTime);
            ctx.timerService().deleteEventTimeTimer(timerDeRegistrationTime);
        } catch (Exception e) {
            log.error("Error while de-registering timers for vehicle {}", vid);
        }

    }

    private long getTimerTime(long epochMilli) {
        return DateUtils.addMinutes(epochMilli, endTripTimerInMin);
    }

    private TripWrapper getTripStartFromState(String incomingVid, String joinedTripId) {
        List<TripWrapper> relatedTrips = getCachedTrip(incomingVid, joinedTripId);
        return relatedTrips.stream().filter(TripWrapper::getIsTripStart).findFirst().orElse(null);
    }

    private TripJoiner getTripJoiner(String vid, String incomingTripId) {
        try {
            Set<TripJoiner> existingMaps = getTripJoiners(vid);
            return existingMaps.stream()
                    .filter(t -> incomingTripId.equals(t.getTripBreakId()))
                    .findFirst()
                    .orElse(null);

        } catch (Exception e) {
            log.error("Exception while accessing trip joiner state for vehicle {}", vid, e);
            return null;
        }
    }

    private void updateTripJoinerState(String vid, Set<TripJoiner> existingMappers) {
        try {
            tripJoinerState.put(vid, existingMappers);
        } catch (Exception e) {
            log.error("Exception while updating trip joiner state for vehicle {}", vid, e);
        }
    }

    private void updateTripJoinerState(String vid, String incomingTripId, String joinedTripId) {
        try {

            Set<TripJoiner> existingMappers = getTripJoiners(vid);

            TripJoiner joiner = TripJoiner.builder()
                    .tripBreakId(incomingTripId)
                    .tripJoinerId(joinedTripId)
                    .isTripJoined(true)
                    .build();

            boolean tripJoined = existingMappers.add(joiner);
            if (tripJoined) {
                log.info("Trip {} joined with {} for vehicle {}", incomingTripId, joinedTripId, vid);
            }

            updateTripJoinerState(vid, existingMappers);
        } catch (Exception e) {
            log.error("Exception while updating trip joiner state for vehicle {}", vid, e);
        }
    }

    private Set<TripJoiner> getTripJoiners(String vid) {
        try {
            return tripJoinerState.contains(vid) ? tripJoinerState.get(vid) : new HashSet<>();
        } catch (Exception e) {
            log.error("Exception while accessing trip joiner state for vehicle {}", vid, e);
            return new HashSet<>();
        }
    }

    private void removeTripJoinerState(String vid, TripWrapper tripWrapper) {
        Set<TripJoiner> existingMappers = getTripJoiners(vid);
        String tripIdToRemove = tripWrapper.getTripId();

        boolean removed = existingMappers.removeIf(t -> tripIdToRemove.equals(t.getTripJoinerId()));
        if (removed) {
            log.info("Trip {} removed from trip joiners cache for vehicle {}", tripIdToRemove, vid);
        }

        updateTripJoinerState(vid, existingMappers);
    }

    private Set<TripWrapper> getCachedTripsState(String vid) {
        try {
            return tripsState.contains(vid) ? tripsState.get(vid) : new HashSet<>();
        } catch (Exception e) {
            log.error("Exception while accessing trip starts for vehicle {}", vid, e);
            return new HashSet<>();
        }
    }

    private List<TripWrapper> getCachedTrip(String vid, String tripId) {
        Set<TripWrapper> tripState = getCachedTripsState(vid);
        return tripState.stream()
                .filter(t -> tripId.equals(t.getTripId()))
                .collect(Collectors.toList());
    }

    private void updateTripsState(String vid, Set<TripWrapper> cachedTrips) {
        try {
            tripsState.put(vid, cachedTrips);
        } catch (Exception e) {
            log.error("Exception while updating trip starts for vehicle {}", vid, e);
        }
    }

    private void updateTripsState(String vid, TripWrapper tripWrapper) {
        try {
            Set<TripWrapper> cachedTrips = getCachedTripsState(vid);
            // First remove the existing object and add the latest one
            cachedTrips.remove(tripWrapper);
            boolean added = cachedTrips.add(tripWrapper);
            if (added) log.info("New Trip details added for vehicle {}", vid);

            updateTripsState(vid, cachedTrips);
        } catch (Exception e) {
            log.error("Exception while updating trip starts for vehicle {}", vid, e);
        }
    }

    private void removeAllRelatedTripFromState(String vid, TripWrapper tripWrapper) {

        Set<TripWrapper> cachedTrips = getCachedTripsState(vid);
        String tripIdToRemove = tripWrapper.getTripId();
        boolean removed = cachedTrips.removeIf(t -> tripIdToRemove.equals(t.getTripId()));

        if (removed) {
            log.info("Trip {} related is removed from trip state cache for vehicle {}", tripIdToRemove, vid);
        }

        updateTripsState(vid, cachedTrips);

    }

    private void removeTripEndsFromState(String vid, TripWrapper tripWrapper) {

        Set<TripWrapper> cachedTrips = getCachedTripsState(vid);
        String tripIdToRemove = tripWrapper.getTripId();
        boolean removed = cachedTrips.removeIf(t -> tripIdToRemove.equals(t.getTripId()) && t.getIsTripEnd());

        if (removed) {
            log.info("Trip End {} removed from trip state cache for vehicle {}", tripIdToRemove, vid);
        }

        updateTripsState(vid, cachedTrips);

    }

    private void removeProcessedTripsFromState(String vid, TripWrapper tripWrapper) {
        Set<Trip> processedTrips = getProcessedTrips(vid);
        String tripIdToRemove = tripWrapper.getTripId();

        boolean removed = processedTrips.removeIf(t -> tripIdToRemove.equals(t.getTripId()));
        if (removed) {
            log.info("Trip {} removed from processed trips cache for vehicle {}", tripIdToRemove, vid);
        }

        updateProcessedTrips(vid, processedTrips);
    }

    private Set<Trip> getProcessedTrips(String vid) {
        try {
            return processedTripsState.contains(vid) ? processedTripsState.get(vid) : new HashSet<>();

        } catch (Exception e) {
            log.error("Exception while accessing processedTrips for vehicle {}", vid, e);
        }

        return new HashSet<>();
    }

    private boolean isTripStartAlreadyProcessed(String vid, String tripId) {
        try {
            Set<Trip> existingTrips = getProcessedTrips(vid);
            if (existingTrips.isEmpty()) return false;

            Optional<Trip> processedTrip = existingTrips.stream()
                    .filter(t -> t.getIsStart() && tripId.equals(t.getTripId()))
                    .findFirst();

            return processedTrip.isPresent();
        } catch (Exception e) {
            log.error("Exception while checking if tripId start for {} and vehicle {} was already processed", tripId, vid, e);
        }

        return false;
    }

    private boolean isTripEndAlreadyProcessed(String vid, String tripId) {
        try {
            Set<Trip> existingTrips = getProcessedTrips(vid);
            if (existingTrips.isEmpty()) return false;

            Optional<Trip> processedTrip = existingTrips.stream()
                    .filter(t -> t.getIsEnd() && tripId.equals(t.getTripId()))
                    .findFirst();

            return processedTrip.isPresent();
        } catch (Exception e) {
            log.error("Exception while checking if tripId end for {} and vehicle {} was already processed", tripId, vid, e);
        }

        return false;
    }

    private void updateProcessedTripStart(String vid, String tripId) {
        log.info("Updating trip start for tripId {} as processed in state for vehicle {}", tripId, vid);
        Trip startTrip = Trip.builder()
                .tripId(tripId)
                .type(TripType.START)
                .isStart(true)
                .build();
        updateProcessedTrips(vid, startTrip);
    }

    private void updateProcessedTripEnd(String vid, String tripId) {
        log.info("Updating trip end for tripId {} as processed in state for vehicle {}", tripId, vid);
        Trip endTrip = Trip.builder()
                .tripId(tripId)
                .type(TripType.END)
                .isEnd(true)
                .build();
        updateProcessedTrips(vid, endTrip);
    }

    private void updateProcessedTrips(String vid, Trip trip) {
        try {
            Set<Trip> existingTrips = getProcessedTrips(vid);
            boolean updated = existingTrips.add(trip);
            if(updated) log.info("Updated processed trips state for tripId {} and vehicle {}", trip, vid);

            updateProcessedTrips(vid, existingTrips);

        } catch (Exception e) {
            log.error("Exception while updating processedTrips for vehicle {}", vid, e);
        }
    }

    private void updateProcessedTrips(String vid, Set<Trip> existingTrips) {
        try {
            processedTripsState.put(vid, existingTrips);

        } catch (Exception e) {
            log.error("Exception while updating processedTrips for vehicle {}", vid, e);
        }
    }

    private LatLongState updateLatLongInState(Telemetry telemetryData, LatLongState cachedLatLong, String vid) throws Exception {
        try {
            log.info("Updating lat long, received Telemetry data: {}", telemetryData);
            log.info("CurrentLat Long State for VID : {} is {}", vid, cachedLatLong);
            long packetTimeStamp = telemetryData.getCollectionEventTime();
            long lastUpdateLatLongTspFromState = cachedLatLong != null ? cachedLatLong.getDetectionWindowStartTimestamp() : 0;
            List<LatLongPair> latLongPairList = SignalUtils.getLatitudeLongitude(telemetryData);
            int latestLatLongIndex = latLongPairList.size() - 1;

            if (latestLatLongIndex < 0) {
                log.error("No lat longs found in telemetry data, returning CACHED LatLongs");
                return Objects.isNull(cachedLatLong) ? LatLongState.builder().build() : cachedLatLong;
            }

            LatLongPair latLongLatest = latLongPairList.get(latestLatLongIndex);

            log.info("Checking GPS and LatLong validity for telemetry data: {}", telemetryData);

            if (isGPSAndLatLongValid(latLongLatest) && !isUnorderedPacket(packetTimeStamp, lastUpdateLatLongTspFromState)) {
                log.info("Lat longs in telemetry data are valid, Updating state");
                LatLongState latLongState = LatLongState.builder()
                        .latitude(latLongLatest.getLatitude())
                        .longitude(latLongLatest.getLongitude())
                        .detectionWindowStartTimestamp(packetTimeStamp)
                        .build();

                latLongStateMap.put(vid, latLongState);
                return latLongState;
            } else {
                log.info("Lat longs in telemetry data are INVALID, returning CACHED LatLongs");
                if (latLongStateMap.get(vid) == null) {
                    latLongStateMap.put(vid, LatLongState.builder().build());
                }
                return Objects.isNull(cachedLatLong) ? LatLongState.builder().build() : cachedLatLong;
            }
        } catch (Exception e) {
            log.error("LATLONG Exception: ", e);
            log.error("LATLONG Exception happened while evaluating LAt longs from telematry packet : {} for vid: {}", objectMapper.writeValueAsString(telemetryData), vid);
        }
        log.info("Lat longs in telemetry data are INVALID, returning CACHED LatLongs");
        return Objects.isNull(cachedLatLong) ? LatLongState.builder().build() : cachedLatLong;
    }

    public boolean isUnorderedPacket(long packetTimeStamp, long detectionWindowStartTimestamp) {
        if (packetTimeStamp == 0)
            return true;

        // we are updating the state for first time
        if (detectionWindowStartTimestamp == 0)
            return false;

        return packetTimeStamp < detectionWindowStartTimestamp;
    }

    public static boolean isGPSAndLatLongValid(LatLongPair latLongLatest) {
        return latLongLatest.getLatitude() != 0
                && latLongLatest.getLongitude() != 0
                && latLongLatest.getHDop() <= 3
                && latLongLatest.getGpsFix() >= 2
                && latLongLatest.isGpsValid();
    }

}
