package org.hmcl.cvp.dataplatform.tripanalytics.operator;

import lombok.extern.slf4j.Slf4j;
import org.apache.flink.api.common.state.MapState;
import org.apache.flink.api.common.state.MapStateDescriptor;
import org.apache.flink.api.java.utils.ParameterTool;
import org.apache.flink.configuration.Configuration;
import org.apache.flink.metrics.Counter;
import org.apache.flink.streaming.api.functions.co.RichCoFlatMapFunction;
import org.apache.flink.util.Collector;
import org.hmcl.cvp.dataplatform.commons.constants.Constants;
import org.hmcl.cvp.dataplatform.commons.constants.FlinkRuntime;
import org.hmcl.cvp.dataplatform.commons.utils.UserPreferenceUtils;
import org.hmcl.cvp.dataplatform.contract.userpreference.ProfileType;
import org.hmcl.cvp.dataplatform.contract.userpreference.UserPreference;
import org.hmcl.cvp.dataplatform.tripanalytics.contract.*;
import org.hmcl.cvp.dataplatform.tripanalytics.helper.TripAnalyticsHelper;

import java.util.*;
import java.util.stream.Collectors;

@Slf4j
public class EnrichTripWithUserDetailsFunction extends RichCoFlatMapFunction<TripWrapper, UserPreference, TripWrapper> {

    private transient Counter numTripCounter;
    private transient Counter numTripUpdated;
    private transient Counter numTripRetained;
    private transient Counter numTripStarts;
    private transient Counter numTripEnds;
    private transient Counter numTripBreaks;
    private transient Counter numOngoingTripEvents;
    private transient Counter numUserPreference;
    private transient Counter numUserPreferenceUpdated;
    private transient Counter numUserPreferenceIgnored;

    private transient boolean defaultToCurrentRider;

    /**
     * MapState to hold userPreferences for each profile
     * Key - vehicleId
     * Value - Map of user preferences with the key being profileId and value UserPreference object
     */
    private transient MapState<String, Map<String, UserPreference>> preferencesStateMap;

    private Counter counterInitializer(String counterName) {

        return getRuntimeContext()
                .getMetricGroup()
                .addGroup(Constants.METRIC_GROUP_NAME)
                .addGroup("EnrichedTrip")
                .counter(counterName);
    }

    @Override
    public void open(Configuration parameters) throws Exception {
        super.open(parameters);

        ParameterTool parameterTool = (ParameterTool) getRuntimeContext().getExecutionConfig().getGlobalJobParameters();
        defaultToCurrentRider = parameterTool.getBoolean(FlinkRuntime.TripAnalytics.DEFAULT_TO_CURRENT_RIDER_DETAILS, false);

        MapStateDescriptor<String, Map<String, UserPreference>> userPreferencesDescriptor = StateDescriptors.userPreferenceMapStateDescriptor();
        preferencesStateMap = getRuntimeContext().getMapState(userPreferencesDescriptor);

        numTripCounter = counterInitializer("numTripCounter");
        numTripUpdated = counterInitializer("numTripUpdated");
        numTripRetained = counterInitializer("numTripRetained");
        numTripStarts = counterInitializer("numTripStarts");
        numTripEnds = counterInitializer("numTripEnds");
        numTripBreaks = counterInitializer("numTripBreaks");
        numOngoingTripEvents = counterInitializer("numOngoingTripEvents");
        numUserPreference = counterInitializer("numUserPreferences");
        numUserPreferenceUpdated = counterInitializer("numUserPreferenceUpdated");
        numUserPreferenceIgnored = counterInitializer("numUserPreferenceIgnored");

    }

    @Override
    public void flatMap1(TripWrapper value, Collector<TripWrapper> out) {

        String vid = value.getVirtualId();
        String tripId = value.getTripId();
        UserDetails userDetails = value.getUserDetails();

        try {

            numTripCounter.inc();

            if (Objects.isNull(userDetails)) userDetails = defaultUserDetails();

            Map<String, UserPreference> stateValues = getPreferencesFromState(vid);
            UserPreference primaryUser = getPrimaryUser(stateValues);

            if(userDetails.isValid()) {
                log.info("Valid user details present for trip {} vehicle {}", tripId, vid);

                processValidUserId(value, userDetails, stateValues, primaryUser, out);
                return;
            }

            log.info("Valid user details not present for trip {} vehicle {}", tripId, vid);

            if(defaultToCurrentRider) {
                UserPreference rider = getRiderFromState(vid, tripId, stateValues);
                if(Objects.nonNull(rider)) {
                    log.info("Since no user details found, defaulting to rider details for trip {} and vehicle {}", tripId, vid);
                    processUserTripDetailsFromUser(value, userDetails, rider, UserDetailsSource.CURRENT_RIDER_DEFAULT, out);
                    return;
                }
                log.info("Rider details not present for trip {} vehicle {}. So trying to default to primary", tripId, vid);
            }

            if(Objects.isNull(primaryUser))  {
                log.warn("No valid values and primary user present for trip {} and vehicle {}", tripId, vid);

                // Retain values as-is
                processUserDetailsFromTelemetry(value, userDetails, UserDetailsSource.PRIMARY_UNKNOWN, out);
                return;
            }

            log.info("Defaulting to primary user for trip {} and vehicle {}", tripId, vid);
            processUserTripDetailsFromUser(value, userDetails, primaryUser, UserDetailsSource.PRIMARY_DEFAULT, out);

        } catch (Exception e) {
            log.error("Exception while enriching trip for vehicle {}", vid, e);
            out.collect(value);
        }

    }

    @Override
    public void flatMap2(UserPreference value, Collector<TripWrapper> out) {
        numUserPreference.inc();

        String vid = value.getVid();
        String profileId = value.getProfileId();

        try {

            log.info("Received user preference value for vehicle {} with profile {}", vid, profileId);

            // Get all the current profiles from state
            Map<String, UserPreference> existingValues = getPreferencesFromState(vid);

            //Handle edge case where primary profile gets deleted manually
            if (value.getProfileType().equals(ProfileType.PRIMARY) && value.getProfileStatus().equalsIgnoreCase("deleted")) {
                log.info("Primary profile {} is deleted for vehicle {}. Deleting it from state", profileId, vid);
                numUserPreferenceUpdated.inc();

                deletePrimaryProfileFromState(existingValues, profileId, vid);

                return;
            }

            if (existingValues.isEmpty()) {
                log.warn("No profiles exist for the vehicle {}. Updating it with profile {}", vid, profileId);
                numUserPreferenceUpdated.inc();

                updateUserPreference(vid, value);
                return;
            }

            // Some profiles exist in the state for the incoming vehicle
            UserPreference valueFromState = getUserPreferenceFromState(vid, profileId);
            if (Objects.isNull(valueFromState)) {
                log.info("No data exist for the profile {} for vehicle {}. Updating it..", profileId, vid);
                numUserPreferenceUpdated.inc();

                updateUserPreference(vid, value);
                return;
            }

            // The incoming profile exists in state. Check if it latest
            if (isLatestPreference(value, valueFromState)) {
                log.info("Latest data found for the profile {} for vehicle {}. Updating it..", profileId, vid);
                numUserPreferenceUpdated.inc();

                updateUserPreference(vid, value);
                return;
            }

        } catch (Exception e) {
            log.error("Exception while processing user preference for vehicle {}", vid, e);
        }

        // Ignoring the incoming value since it is not latest
        numUserPreferenceIgnored.inc();

    }

    private void deletePrimaryProfileFromState(Map<String, UserPreference> existingValues, String profileId, String vid) {
        try {
            log.info("Existing values before deletion for vehicle {}: {}", vid, existingValues);
            // Remove the primary profile from the state
            if (!existingValues.isEmpty() && existingValues.get(profileId) != null) {
                existingValues.remove(profileId);
                preferencesStateMap.put(vid, existingValues);
                log.info("Primary profile {} deleted successfully for vehicle {}", profileId, vid);
                log.info("values after deletion for vehicle {}: {}", vid, preferencesStateMap.get(vid));
            }
        } catch (Exception e) {
           log.error("Exception while deleting primary profile {} for vehicle {}", profileId, vid, e);
        }
    }

    private void processValidUserId(TripWrapper value,
                                    UserDetails userDetails,
                                    Map<String, UserPreference> stateValues,
                                    UserPreference primaryUser,
                                    Collector<TripWrapper> out) {

        String vid = value.getVirtualId();
        String tripId = value.getTripId();
        String profile = userDetails.getUserProfile();

        if(ProfileType.SECONDARY.value().equalsIgnoreCase(profile)) {
            log.info("Rider is secondary for trip {} and vehicle {}. getting user details!!", tripId, vid);

            processUserDetailsFromSecondaryRider(value, userDetails, stateValues, primaryUser, out);
            return;
        }

        if(Objects.isNull(primaryUser)) {
            log.warn("No primary user present for trip {} and vehicle {}", tripId, vid);

            processUserDetailsFromTelemetry(value, userDetails, UserDetailsSource.PRIMARY_UNKNOWN, out);
            return;
        }

        log.info("Defaulting to primary user since profile is primary or invalid for trip {} and vehicle {}", tripId, vid);

        // Populate from primary user
        UserDetailsSource source = ProfileType.PRIMARY.value().equalsIgnoreCase(profile)
                ? UserDetailsSource.PRIMARY
                : UserDetailsSource.PRIMARY_DEFAULT;
        processUserTripDetailsFromUser(value, userDetails, primaryUser, source, out);
    }

    private void processUserDetailsFromSecondaryRider(TripWrapper value,
                                       UserDetails userDetails,
                                       Map<String, UserPreference> stateValues,
                                       UserPreference primaryUser,
                                       Collector<TripWrapper> out) {

        String vid = value.getVirtualId();
        String tripId = value.getTripId();
        String secondaryProfileId = userDetails.getUserId();

        log.info("Profile {} is a secondary profile for trip {} and vehicle {}", secondaryProfileId,tripId, vid);

        UserPreference secondaryUser = getSecondaryUser(stateValues, secondaryProfileId);
        boolean secondaryUserPresent = Objects.nonNull(secondaryUser);
        boolean primaryUserPresent = Objects.nonNull(primaryUser);

        if (!secondaryUserPresent && !primaryUserPresent) {
            log.warn("Secondary rider and Primary user is null for trip {} and vehicle {}. Retaining default values", tripId, vid);

            processUserDetailsFromTelemetry(value, userDetails, UserDetailsSource.USER_UNKNOWN, out);
            return;
        }

        if(primaryUserPresent && !secondaryUserPresent) {
            log.warn("Secondary rider {} not found in state for vehicle {}", secondaryProfileId, vid);

            processUserTripDetailsFromUser(value, userDetails, primaryUser, UserDetailsSource.PRIMARY_DEFAULT, out);
            return;
        }

        if(!primaryUserPresent) {
            log.warn("No primary user present. So defaulting to secondary without checking for expiry for vehicle {} and trip {}", vid, tripId);

            processUserTripDetailsFromUser(value, userDetails, secondaryUser, UserDetailsSource.SECONDARY_DEFAULT, out);
            return;
        }

        if (isSecondaryProfileValid(vid, secondaryProfileId, secondaryUser, value.getTimestamp())) {
            log.info("Populating secondary details for vehicle {}", vid);
            processUserTripDetailsFromUser(value, userDetails, secondaryUser, UserDetailsSource.SECONDARY, out);
            return;
        }

        log.info("Defaulting to primary details since secondary user is invalid/ expired, for vehicle {}", vid);

        processUserTripDetailsFromUser(value, userDetails, primaryUser, UserDetailsSource.PRIMARY_DEFAULT, out);
    }

    private void processUserDetailsFromTelemetry(TripWrapper value, UserDetails userDetails, UserDetailsSource source, Collector<TripWrapper> out) {

        String vid = value.getVirtualId();
        String tripId = value.getTripId();

        log.info("Populating user details from telemetry since no state values present for trip {} and vehicle {}", tripId, vid);

        numTripRetained.inc();

        populateTripWithProfileDetails(value, userDetails, source.getValue());

        out.collect(value);
    }

    private void processUserTripDetailsFromUser(TripWrapper value,
                                                UserDetails userDetails,
                                                UserPreference userPreference,
                                                UserDetailsSource source,
                                                Collector<TripWrapper> out) {
        String vid = value.getVirtualId();
        String tripId = value.getTripId();

        log.info("Populating user details from user preference for trip {} and vehicle {}", tripId, vid);

        userDetails = Objects.isNull(userDetails) ? defaultUserDetails() : userDetails;

        userDetails.setUserId(userPreference.getProfileId());
        userDetails.setUserProfile(userPreference.getProfileType().value());
        userDetails.setUserName(userPreference.getProfileName());

        populateTripWithProfileDetails(value, userDetails, source.getValue());

        numTripUpdated.inc();
        out.collect(value);
    }

    private void populateTripWithProfileDetails(TripWrapper value, UserDetails userDetails, String source) {

        String userId = Objects.isNull(userDetails.getUserId()) ? TripAnalyticsHelper.DEFAULT_STRING_VALUE : userDetails.getUserId();
        String profile = Objects.isNull(userDetails.getUserProfile()) ? TripAnalyticsHelper.DEFAULT_STRING_VALUE : userDetails.getUserProfile();
        String name = Objects.isNull(userDetails.getUserName()) ? TripAnalyticsHelper.DEFAULT_STRING_VALUE : userDetails.getUserName();

        if(value.isNeededForTripBreak()) {
            numOngoingTripEvents.inc();
            userDetails.setUserName(name);
            userDetails.setValid(!TripAnalyticsHelper.DEFAULT_STRING_VALUE.equalsIgnoreCase(userId));
            userDetails.setSource(source);
            value.setUserDetails(userDetails);
            return;
        }

        if (value.getIsTripStart()) {
            TripStart tripStart = value.getTripStart();
            if (Objects.nonNull(tripStart)) {
                numTripStarts.inc();

                tripStart.setUserId(userId);
                tripStart.setUserProfile(profile);
                tripStart.setUserName(name);
                tripStart.setUserDetailsSource(source);
            }
            return;
        }

        if (value.getIsTripEnd()) {
            TripEnd tripEnd = value.getTripEnd();
            if (Objects.nonNull(tripEnd)) {
                numTripEnds.inc();

                tripEnd.setUserId(userId);
                tripEnd.setUserProfile(profile);
                tripEnd.setUserName(name);
                tripEnd.setUserDetailsSource(source);
            }

            return;
        }

        if (value.getIsTripBreak()) {
            TripBreak tripBreak = value.getTripBreak();
            if (Objects.nonNull(tripBreak)) {
                numTripBreaks.inc();

                tripBreak.setUserId(userId);
                tripBreak.setUserProfile(profile);
                tripBreak.setUserName(name);
                tripBreak.setUserDetailsSource(source);
            }
        }
    }

    private UserDetails defaultUserDetails() {
        return UserDetails.builder()
                .userId(TripAnalyticsHelper.DEFAULT_STRING_VALUE)
                .userProfile(TripAnalyticsHelper.DEFAULT_STRING_VALUE)
                .userName(TripAnalyticsHelper.DEFAULT_STRING_VALUE)
                .valid(false)
                .source(UserDetailsSource.UNKNOWN.getValue())
                .build();
    }

    private boolean isSecondaryProfileValid(String vid, String profileId, UserPreference stateValue, Long tripTime) {
        if (Objects.isNull(stateValue)) {
            log.info("{} profile not found in state for vehicle {}", profileId, vid);
            return false;
        }

        if (Objects.isNull(stateValue.getAccessValidFromTsp()) || Objects.isNull(stateValue.getAccessValidTillTsp()))
            return false;

        long profileValidFromTsp = stateValue.getAccessValidFromTsp();
        long profileValidTillTsp = stateValue.getAccessValidTillTsp();

        return profileValidFromTsp <= tripTime && tripTime <= profileValidTillTsp;
    }

    private UserPreference getPrimaryUser(Map<String, UserPreference> stateValues) {
        if(Objects.isNull(stateValues) || stateValues.isEmpty()) return null;

        return stateValues.values().stream().filter(UserPreferenceUtils::isPrimary).findFirst().orElse(null);
    }

    private UserPreference getSecondaryUser(Map<String, UserPreference> stateValues, String profileId) {
        return stateValues.getOrDefault(profileId, null);
    }

    private boolean isLatestPreference(UserPreference incomingValue, UserPreference stateValue) {
        return incomingValue.getUpdatedTsp() > stateValue.getUpdatedTsp();
    }

    private UserPreference getRiderFromState(String vid, String tripId, Map<String, UserPreference> stateValues) {
        if(Objects.isNull(stateValues) || stateValues.isEmpty()) return null;
        List<UserPreference> riders = stateValues.values().stream().filter(UserPreference::getIsRider).collect(Collectors.toList());

        if(riders.isEmpty()) return null;

        if(riders.size() > 1) {
            List<String> riderProfileIds = riders.stream().map(UserPreference::getProfileId).collect(Collectors.toList());
            log.error("Somehow more than 1 riders {} found during trip {} for vehicle {}", riderProfileIds, tripId, vid);
            return riders.stream().max(Comparator.comparing(UserPreference::getUpdatedTsp)).orElse(null);
        }

        return riders.get(0);
    }

    private Map<String, UserPreference> getPreferencesFromState(String vid) {
        try {
            return preferencesStateMap.contains(vid) ? preferencesStateMap.get(vid) : new HashMap<>();
        } catch (Exception e) {
            log.error("Exception while getting user preference state for vehicle {}", vid, e);
        }

        return new HashMap<>();
    }

    private UserPreference getUserPreferenceFromState(String vid, String profileId) {
        try {
            log.info("Checking for existing values for vehicle {} and profile {}", vid, profileId);
            Map<String, UserPreference> existingValues = getPreferencesFromState(vid);
            log.info("Existing values in user preference for vehicle {}", vid);
            return existingValues.getOrDefault(profileId, null);
        } catch (Exception e) {
            log.error("Exception while getting user preference state for vehicle {} and profile id {}", vid, profileId, e);
        }

        return null;
    }

    private void updateUserPreference(String vid, UserPreference preference) {

        try {

            Map<String, UserPreference> existingValues = getPreferencesFromState(vid);
            existingValues.put(preference.getProfileId(), preference);

            preferencesStateMap.put(vid, existingValues);

        } catch (Exception e) {
            log.error("Exception while updating user preference state for vehicle {}", vid);
        }
    }

}
