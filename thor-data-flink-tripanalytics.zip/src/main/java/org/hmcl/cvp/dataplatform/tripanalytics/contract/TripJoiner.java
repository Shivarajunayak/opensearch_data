package org.hmcl.cvp.dataplatform.tripanalytics.contract;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.util.Objects;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class TripJoiner implements Serializable {

    private String tripBreakId;

    private String tripJoinerId;

    private boolean isTripJoined;

    public boolean getIsTripJoined() {
        return isTripJoined;
    }

    public void setIsTripJoined(boolean tripJoined) {
        isTripJoined = tripJoined;
    }

    public boolean isSameTrip() {
        if(Objects.isNull(tripBreakId)) return false;

        if(Objects.isNull(tripJoinerId)) return false;

        return tripBreakId.equals(tripJoinerId);
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof TripJoiner)) return false;
        TripJoiner that = (TripJoiner) o;
        return Objects.equals(tripBreakId, that.tripBreakId) && Objects.equals(tripJoinerId, that.tripJoinerId);
    }

    @Override
    public int hashCode() {
        return Objects.hash(tripBreakId, tripJoinerId);
    }
}
