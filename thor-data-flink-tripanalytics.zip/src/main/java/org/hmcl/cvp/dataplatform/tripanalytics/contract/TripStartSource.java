package org.hmcl.cvp.dataplatform.tripanalytics.contract;

import com.google.gson.annotations.SerializedName;
import lombok.Getter;

@Getter
public enum TripStartSource {

    @SerializedName("trip_start_signal")
    TRIP_START_SIGNAL("trip_start_signal"),

    @SerializedName("trip_end_signal")
    TRIP_END_SIGNAL("trip_end_signal");

    private final String value;

    TripStartSource(String value) {
        this.value = value;
    }
}
