# Local Deployment

## Pre-requisites
1. Docker is installed
2. Jar is built locally and present in target folder
3. Not other applications are using the below ports 
   1. `8080` (used by Kafka UI)
   2. `29092`, `9092`, `9997` (Used by Kafka)
   3. `9200` and `9600` (Used by OpenSearch)
   4. `5601` (Used by OpenSearch dashboard)
   5. `7070` (Used by flink web)
4. A `.env` file in the `local` folder as below,
```markdown
OPENSEARCH_INITIAL_ADMIN_PASSWORD=<PASSWORD CONTAINIG SPECIAL CHAR AND ALPHA NUMERIC>
FLINK_JOB_JAR=tripanalytics-1.0.0-SNAPSHOT.jar
```

## Start
1. Goto `local` folder and run `docker-compose up -d`
2. Once all the services are running, goto kafka ui and start producing messages