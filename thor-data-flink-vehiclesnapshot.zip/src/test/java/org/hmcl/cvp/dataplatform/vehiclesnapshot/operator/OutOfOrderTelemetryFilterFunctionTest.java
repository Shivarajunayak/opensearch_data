package org.hmcl.cvp.dataplatform.vehiclesnapshot.operator;

import org.apache.flink.api.common.typeinfo.Types;
import org.apache.flink.streaming.api.operators.StreamFlatMap;
import org.apache.flink.streaming.util.KeyedOneInputStreamOperatorTestHarness;
import org.apache.flink.streaming.runtime.streamrecord.StreamRecord;
import org.hmcl.cvp.dataplatform.commons.utils.TelemetryUtils;
import org.hmcl.cvp.dataplatform.contract.telemetry.Telemetry;
import org.junit.Assert;
import org.junit.Test;

import java.util.List;

public class OutOfOrderTelemetryFilterFunctionTest {

    @Test
    public void processesValidTelemetryWithNullState() throws Exception {
        try (KeyedOneInputStreamOperatorTestHarness<String, Telemetry, Telemetry> testHarness =
                     new KeyedOneInputStreamOperatorTestHarness<>(
                             new StreamFlatMap<>(new OutOfOrderTelemetryFilterFunction()),
                             TelemetryUtils::getVirtualId,
                             Types.STRING
                     )) {

            testHarness.setup();
            testHarness.open();

            Telemetry telemetry = new Telemetry();
            telemetry.setCollectionEventTime(1000L);

            testHarness.processElement(new StreamRecord<>(telemetry));

            List<Telemetry> output = testHarness.extractOutputValues();

            Assert.assertEquals(1, output.size());
            Assert.assertEquals(1000L, output.get(0).getCollectionEventTime());
        }
    }

    @Test
    public void processesValidTelemetryWithNonNullState() throws Exception {
        try (KeyedOneInputStreamOperatorTestHarness<String, Telemetry, Telemetry> testHarness =
                     new KeyedOneInputStreamOperatorTestHarness<>(
                             new StreamFlatMap<>(new OutOfOrderTelemetryFilterFunction()),
                             TelemetryUtils::getVirtualId,
                             Types.STRING
                     )) {

            testHarness.setup();
            testHarness.open();

            Telemetry firstEvent = new Telemetry();
            firstEvent.setCollectionEventTime(1000L);

            Telemetry secondEvent = new Telemetry();
            secondEvent.setCollectionEventTime(2000L);

            testHarness.processElement(new StreamRecord<>(firstEvent));
            testHarness.processElement(new StreamRecord<>(secondEvent));

            List<Telemetry> output = testHarness.extractOutputValues();

            Assert.assertEquals(2, output.size());
            Assert.assertEquals(1000L, output.get(0).getCollectionEventTime());
            Assert.assertEquals(2000L, output.get(1).getCollectionEventTime());
        }
    }


    @Test
    public void acceptsTelemetryWithSameTimestamp() throws Exception {
            try (KeyedOneInputStreamOperatorTestHarness<String, Telemetry, Telemetry> testHarness =
                         new KeyedOneInputStreamOperatorTestHarness<>(
                                 new StreamFlatMap<>(new OutOfOrderTelemetryFilterFunction()),
                                 TelemetryUtils::getVirtualId,
                                 Types.STRING
                         )) {

                testHarness.setup();
                testHarness.open();

                Telemetry firstTelemetry = new Telemetry();
                firstTelemetry.setCollectionEventTime(1500L);

                Telemetry secondTelemetry = new Telemetry();
                secondTelemetry.setCollectionEventTime(1500L);

                testHarness.processElement(new StreamRecord<>(firstTelemetry));
                testHarness.processElement(new StreamRecord<>(secondTelemetry));

                List<Telemetry> output = testHarness.extractOutputValues();

                Assert.assertEquals(2, output.size());
                Assert.assertEquals(1500L, output.get(0).getCollectionEventTime());
                Assert.assertEquals(1500L, output.get(0).getCollectionEventTime());

            }
        }

        @Test
        public void ignoresTelemetryWithOlderTimestamp() throws Exception {
            try (KeyedOneInputStreamOperatorTestHarness<String, Telemetry, Telemetry> testHarness =
                         new KeyedOneInputStreamOperatorTestHarness<>(
                                 new StreamFlatMap<>(new OutOfOrderTelemetryFilterFunction()),
                                 TelemetryUtils::getVirtualId,
                                 Types.STRING
                         )) {

                testHarness.setup();
                testHarness.open();

                Telemetry firstTelemetry = new Telemetry();
                firstTelemetry.setCollectionEventTime(1000L);

                Telemetry secondTelemetry = new Telemetry();
                secondTelemetry.setCollectionEventTime(500L);

                testHarness.processElement(new StreamRecord<>(firstTelemetry));
                testHarness.processElement(new StreamRecord<>(secondTelemetry));

                List<Telemetry> output = testHarness.extractOutputValues();

                Assert.assertEquals(1, output.size());
                Assert.assertEquals(1000L, output.get(0).getCollectionEventTime());
            }
        }
    }