package org.hmcl.cvp.dataplatform.vehiclesnapshot.operator;

import org.apache.flink.api.common.state.MapState;
import org.apache.flink.api.common.typeinfo.BasicTypeInfo;
import org.apache.flink.api.java.functions.KeySelector;
import org.apache.flink.api.java.tuple.Tuple3;
import org.apache.flink.api.java.utils.ParameterTool;
import org.apache.flink.runtime.jobgraph.OperatorID;
import org.apache.flink.runtime.metrics.groups.InternalOperatorMetricGroup;
import org.apache.flink.runtime.metrics.util.InterceptingOperatorMetricGroup;
import org.apache.flink.runtime.metrics.util.InterceptingTaskMetricGroup;
import org.apache.flink.runtime.operators.testutils.MockEnvironment;
import org.apache.flink.runtime.operators.testutils.MockEnvironmentBuilder;
import org.apache.flink.runtime.testutils.MiniClusterResourceConfiguration;
import org.apache.flink.streaming.api.operators.StreamFlatMap;
import org.apache.flink.streaming.runtime.streamrecord.StreamRecord;
import org.apache.flink.streaming.util.KeyedOneInputStreamOperatorTestHarness;
import org.apache.flink.test.util.MiniClusterWithClientResource;
import org.hmcl.cvp.dataplatform.commons.catalogue.SignalCatalogue;
import org.hmcl.cvp.dataplatform.commons.constants.FlinkRuntime;
import org.hmcl.cvp.dataplatform.commons.exception.FlinkRuntimeException;
import org.hmcl.cvp.dataplatform.commons.testdata.SignalGenerator;
import org.hmcl.cvp.dataplatform.commons.utils.FlinkUtils;
import org.hmcl.cvp.dataplatform.commons.utils.GsonUtils;
import org.hmcl.cvp.dataplatform.contract.telemetry.*;
import org.hmcl.cvp.dataplatform.vehiclesnapshot.contract.*;
import org.hmcl.cvp.dataplatform.vehiclesnapshot.utils.VehicleStateData;
import org.junit.Assert;
import org.junit.ClassRule;
import org.junit.Test;

import java.time.Instant;
import java.util.*;

public class VehicleSnapshotMapperFunctionTest {

    @ClassRule
    public static MiniClusterWithClientResource flinkCluster =
            new MiniClusterWithClientResource(
                    new MiniClusterResourceConfiguration.Builder()
                            .setNumberSlotsPerTaskManager(2)
                            .setNumberTaskManagers(1)
                            .build());

    private final InterceptingOperatorMetricGroup interceptingOperatorMetricGroup = new InterceptingOperatorMetricGroup();
    private final InterceptingTaskMetricGroup interceptingTaskMetricGroup = new InterceptingTaskMetricGroup() {
        @Override
        public InternalOperatorMetricGroup getOrAddOperator(OperatorID operatorID, String name) {
            return interceptingOperatorMetricGroup;
        }
    };

    private final MockEnvironment mockEnvironment = new MockEnvironmentBuilder().setMetricGroup(interceptingTaskMetricGroup).build();

    private final VehicleSnapshotMapperFunction mapperFunction = new VehicleSnapshotMapperFunction();

    private KeyedOneInputStreamOperatorTestHarness<String, EnrichedSnapshot, Tuple3<String, String, SnapshotWrapper>> testHarness() throws Exception {

        ParameterTool parameterTool = ParameterTool.fromMap(new HashMap<>());
        parameterTool = FlinkUtils.addProperties(parameterTool, Map.of(FlinkRuntime.VehicleSnapshot.SNAPSHOT_INDEX_EV, VehicleStateData.EV_SNAPSHOT_INDEX));
        parameterTool = FlinkUtils.addProperties(parameterTool, Map.of(FlinkRuntime.VehicleSnapshot.SNAPSHOT_INDEX_ICE, VehicleStateData.ICE_SNAPSHOT_INDEX));
        parameterTool = FlinkUtils.addProperties(parameterTool, Map.of(FlinkRuntime.VehicleSnapshot.SNAPSHOT_INDEX_HARLEY, VehicleStateData.HARLEY_SNAPSHOT_INDEX));
        parameterTool = FlinkUtils.addProperties(parameterTool, Map.of(FlinkRuntime.VALID_HDOP_THRESHOLD_VALUE, "3.0"));
        mockEnvironment.getExecutionConfig().setGlobalJobParameters(parameterTool);

        return new KeyedOneInputStreamOperatorTestHarness<>(
                new StreamFlatMap<>(mapperFunction),
                (KeySelector<EnrichedSnapshot, String>) EnrichedSnapshot::getVirtualId,
                BasicTypeInfo.STRING_TYPE_INFO,
                mockEnvironment);
    }

    private MapState<String, SnapshotWrapper> getVehicleStateMap(KeyedOneInputStreamOperatorTestHarness<String, EnrichedSnapshot, Tuple3<String, String, SnapshotWrapper>> testHarness) {
        return testHarness.getOperator()
                .getKeyedStateStore()
                .getMapState(MapStateDescriptors.getLatestSnapshotDescriptor());
    }

    @Test
    public void testVehicleSnapshotMapperFunction_ev() {
        try (KeyedOneInputStreamOperatorTestHarness<String, EnrichedSnapshot, Tuple3<String, String, SnapshotWrapper>> testHarness = testHarness()) {

            testHarness.setup();
            testHarness.open();

            EnrichedSnapshot enrichedSnapshot = VehicleStateData.getEnrichedSnapshot(Tenant.EV, Instant.now().toEpochMilli());
            testHarness.processElement(new StreamRecord<>(enrichedSnapshot));

            List<Tuple3<String, String, SnapshotWrapper>> output = VehicleStateData.getOutput(testHarness.getRecordOutput());
            Assert.assertEquals(1, output.size());

            Tuple3<String, String, SnapshotWrapper> value = output.get(0);
            Assert.assertEquals(VehicleStateData.EV_SNAPSHOT_INDEX, value.f0);
            Assert.assertEquals(VehicleStateData.VIRTUAL_ID, value.f1);

            MapState<String, SnapshotWrapper> preferencesStateMap = getVehicleStateMap(testHarness);

            SnapshotWrapper snapshotWrapper = preferencesStateMap.get(VehicleStateData.VIRTUAL_ID);
            Assert.assertNotNull(snapshotWrapper);

            CommonSnapshot commonSnapshot = snapshotWrapper.getCommonSnapshot();
            Assert.assertNotNull(commonSnapshot);

            EvSnapshot evSnapshot = snapshotWrapper.getEvSnapshot();
            Assert.assertNotNull(evSnapshot);

            IceSnapshot iceSnapshot = snapshotWrapper.getIceSnapshot();
            Assert.assertNull(iceSnapshot);

        } catch (Exception e) {
            throw new FlinkRuntimeException(e);
        }
    }

    @Test
    public void testVehicleSnapshotMapperFunction_ice() {
        try (KeyedOneInputStreamOperatorTestHarness<String, EnrichedSnapshot, Tuple3<String, String, SnapshotWrapper>> testHarness = testHarness()) {

            testHarness.setup();
            testHarness.open();

            EnrichedSnapshot enrichedSnapshot = VehicleStateData.getEnrichedSnapshot(Tenant.ICE, Instant.now().toEpochMilli());
            testHarness.processElement(new StreamRecord<>(enrichedSnapshot));

            List<Tuple3<String, String, SnapshotWrapper>> output = VehicleStateData.getOutput(testHarness.getRecordOutput());
            Assert.assertEquals(1, output.size());

            Tuple3<String, String, SnapshotWrapper> value = output.get(0);
            Assert.assertEquals(VehicleStateData.ICE_SNAPSHOT_INDEX, value.f0);
            Assert.assertEquals(VehicleStateData.VIRTUAL_ID, value.f1);

            MapState<String, SnapshotWrapper> preferencesStateMap = getVehicleStateMap(testHarness);

            SnapshotWrapper snapshotWrapper = preferencesStateMap.get(VehicleStateData.VIRTUAL_ID);
            Assert.assertNotNull(snapshotWrapper);

            CommonSnapshot commonSnapshot = snapshotWrapper.getCommonSnapshot();
            Assert.assertNotNull(commonSnapshot);

            IceSnapshot iceSnapshot = snapshotWrapper.getIceSnapshot();
            Assert.assertNotNull(iceSnapshot);

            EvSnapshot evSnapshot = snapshotWrapper.getEvSnapshot();
            Assert.assertNull(evSnapshot);

        } catch (Exception e) {
            throw new FlinkRuntimeException(e);
        }
    }

    @Test
    public void testVehicleSnapshotMapperFunction_harley() {
        try (KeyedOneInputStreamOperatorTestHarness<String, EnrichedSnapshot, Tuple3<String, String, SnapshotWrapper>> testHarness = testHarness()) {

            testHarness.setup();
            testHarness.open();

            EnrichedSnapshot enrichedSnapshot = VehicleStateData.getEnrichedSnapshot(Tenant.HARLEY, Instant.now().toEpochMilli());
            testHarness.processElement(new StreamRecord<>(enrichedSnapshot));

            List<Tuple3<String, String, SnapshotWrapper>> output = VehicleStateData.getOutput(testHarness.getRecordOutput());
            Assert.assertEquals(1, output.size());

            Tuple3<String, String, SnapshotWrapper> value = output.get(0);
            Assert.assertEquals(VehicleStateData.HARLEY_SNAPSHOT_INDEX, value.f0);
            Assert.assertEquals(VehicleStateData.VIRTUAL_ID, value.f1);

            MapState<String, SnapshotWrapper> preferencesStateMap = getVehicleStateMap(testHarness);

            SnapshotWrapper snapshotWrapper = preferencesStateMap.get(VehicleStateData.VIRTUAL_ID);
            Assert.assertNotNull(snapshotWrapper);

            CommonSnapshot commonSnapshot = snapshotWrapper.getCommonSnapshot();
            Assert.assertNotNull(commonSnapshot);

            IceSnapshot iceSnapshot = snapshotWrapper.getIceSnapshot();
            Assert.assertNotNull(iceSnapshot);

            EvSnapshot evSnapshot = snapshotWrapper.getEvSnapshot();
            Assert.assertNull(evSnapshot);

        } catch (Exception e) {
            throw new FlinkRuntimeException(e);
        }
    }

    @Test
    public void testVehicleSnapshotMapperFunction_noUpdates() {
        try (KeyedOneInputStreamOperatorTestHarness<String, EnrichedSnapshot, Tuple3<String, String, SnapshotWrapper>> testHarness = testHarness()) {

            testHarness.setup();
            testHarness.open();

            EnrichedSnapshot enrichedSnapshot = VehicleStateData.getEnrichedSnapshot(Tenant.HARLEY, Instant.now().toEpochMilli());
            testHarness.processElement(new StreamRecord<>(enrichedSnapshot));

            List<Tuple3<String, String, SnapshotWrapper>> output = VehicleStateData.getOutput(testHarness.getRecordOutput());
            Assert.assertEquals(1, output.size());

            Tuple3<String, String, SnapshotWrapper> value = output.get(0);
            Assert.assertEquals(VehicleStateData.HARLEY_SNAPSHOT_INDEX, value.f0);
            Assert.assertEquals(VehicleStateData.VIRTUAL_ID, value.f1);

            MapState<String, SnapshotWrapper> preferencesStateMap = getVehicleStateMap(testHarness);

            SnapshotWrapper snapshotWrapper = preferencesStateMap.get(VehicleStateData.VIRTUAL_ID);
            Assert.assertNotNull(snapshotWrapper);

            CommonSnapshot commonSnapshot = snapshotWrapper.getCommonSnapshot();
            Assert.assertNotNull(commonSnapshot);

            IceSnapshot iceSnapshot = snapshotWrapper.getIceSnapshot();
            Assert.assertNotNull(iceSnapshot);

            EvSnapshot evSnapshot = snapshotWrapper.getEvSnapshot();
            Assert.assertNull(evSnapshot);

            // Sending the same data with same time value
            testHarness.processElement(new StreamRecord<>(enrichedSnapshot));
            List<Tuple3<String, String, SnapshotWrapper>> output1 = VehicleStateData.getOutput(testHarness.getRecordOutput());
            Assert.assertEquals(1, output1.size());

        } catch (Exception e) {
            throw new FlinkRuntimeException(e);
        }
    }

    @Test
    public void testVehicleSnapshotMapperFunction_latestUpdates() {
        try (KeyedOneInputStreamOperatorTestHarness<String, EnrichedSnapshot, Tuple3<String, String, SnapshotWrapper>> testHarness = testHarness()) {

            testHarness.setup();
            testHarness.open();

            EnrichedSnapshot enrichedSnapshot = VehicleStateData.getEnrichedSnapshot(Tenant.HARLEY, Instant.now().toEpochMilli());
            testHarness.processElement(new StreamRecord<>(enrichedSnapshot));

            List<Tuple3<String, String, SnapshotWrapper>> output = VehicleStateData.getOutput(testHarness.getRecordOutput());
            Assert.assertEquals(1, output.size());

            Tuple3<String, String, SnapshotWrapper> value = output.get(0);
            Assert.assertEquals(VehicleStateData.HARLEY_SNAPSHOT_INDEX, value.f0);
            Assert.assertEquals(VehicleStateData.VIRTUAL_ID, value.f1);

            MapState<String, SnapshotWrapper> preferencesStateMap = getVehicleStateMap(testHarness);

            SnapshotWrapper snapshotWrapper = preferencesStateMap.get(VehicleStateData.VIRTUAL_ID);
            Assert.assertNotNull(snapshotWrapper);

            CommonSnapshot commonSnapshot = snapshotWrapper.getCommonSnapshot();
            Assert.assertNotNull(commonSnapshot);

            IceSnapshot iceSnapshot = snapshotWrapper.getIceSnapshot();
            Assert.assertNotNull(iceSnapshot);

            EvSnapshot evSnapshot = snapshotWrapper.getEvSnapshot();
            Assert.assertNull(evSnapshot);

            // Sending the data with updated time value
            EnrichedSnapshot enrichedSnapshot1 = VehicleStateData.getEnrichedSnapshot(Tenant.HARLEY, Instant.now().toEpochMilli());
            testHarness.processElement(new StreamRecord<>(enrichedSnapshot1));
            List<Tuple3<String, String, SnapshotWrapper>> output1 = VehicleStateData.getOutput(testHarness.getRecordOutput());
            Assert.assertEquals(2, output1.size());

        } catch (Exception e) {
            throw new FlinkRuntimeException(e);
        }
    }

    @Test
    public void testVehicleSnapshotMapperFunction_invalidGpsFix() {
        try (KeyedOneInputStreamOperatorTestHarness<String, EnrichedSnapshot, Tuple3<String, String, SnapshotWrapper>> testHarness = testHarness()) {

            testHarness.setup();
            testHarness.open();

            Instant instant = Instant.now();
            EnrichedSnapshot enrichedSnapshot = VehicleStateData.getEnrichedSnapshot(Tenant.HARLEY, instant.toEpochMilli());
            Map<String, SignalData> latestSignals = enrichedSnapshot.getLatestSignals();

            SignalInfo gpsFix = SignalCatalogue.getGpsFixInfo();
            latestSignals.put(gpsFix.getKey(), SignalGenerator.getSignal(gpsFix, 1.0, instant.toEpochMilli()));

            SignalInfo hDop = SignalCatalogue.getHDopInfo();
            latestSignals.put(hDop.getKey(), SignalGenerator.getSignal(hDop, 1.0, instant.toEpochMilli()));

            latestSignals.put(SignalCatalogue.getGpsValidInfo().getKey(), SignalGenerator.getSignalBoolean(true, instant.toEpochMilli()));

            enrichedSnapshot.setLatestSignals(latestSignals);

            testHarness.processElement(new StreamRecord<>(enrichedSnapshot));

            List<Tuple3<String, String, SnapshotWrapper>> output = VehicleStateData.getOutput(testHarness.getRecordOutput());
            Assert.assertEquals(1, output.size());

            Tuple3<String, String, SnapshotWrapper> value = output.get(0);
            Assert.assertEquals(VehicleStateData.HARLEY_SNAPSHOT_INDEX, value.f0);
            Assert.assertEquals(VehicleStateData.VIRTUAL_ID, value.f1);

            MapState<String, SnapshotWrapper> preferencesStateMap = getVehicleStateMap(testHarness);

            SnapshotWrapper snapshotWrapper = preferencesStateMap.get(VehicleStateData.VIRTUAL_ID);
            Assert.assertNotNull(snapshotWrapper);

            CommonSnapshot commonSnapshot = snapshotWrapper.getCommonSnapshot();
            Assert.assertNotNull(commonSnapshot);
            Assert.assertNull(commonSnapshot.getGpsFix());
            Assert.assertNull(commonSnapshot.getGpsValid());
            Assert.assertNull(commonSnapshot.getLatitude());
            Assert.assertNull(commonSnapshot.getLongitude());
            Assert.assertNull(commonSnapshot.getHDop());
            Assert.assertNull(commonSnapshot.getPDop());
            Assert.assertNull(commonSnapshot.getVDop());

            IceSnapshot iceSnapshot = snapshotWrapper.getIceSnapshot();
            Assert.assertNotNull(iceSnapshot);

            EvSnapshot evSnapshot = snapshotWrapper.getEvSnapshot();
            Assert.assertNull(evSnapshot);

            // Sending the data with updated time value
            EnrichedSnapshot enrichedSnapshot1 = VehicleStateData.getEnrichedSnapshot(Tenant.HARLEY, Instant.now().toEpochMilli());
            testHarness.processElement(new StreamRecord<>(enrichedSnapshot1));
            List<Tuple3<String, String, SnapshotWrapper>> output1 = VehicleStateData.getOutput(testHarness.getRecordOutput());
            Assert.assertEquals(2, output1.size());
            Tuple3<String, String, SnapshotWrapper> value1 = output1.get(1);
            Assert.assertEquals(5, value1.f2.getIceSnapshot().getDistanceTravelledWithMil().getValue());

        } catch (Exception e) {
            throw new FlinkRuntimeException(e);
        }
    }

    @Test
    public void testVehicleSnapshotMapperFunction_validGpsFix() {
        try (KeyedOneInputStreamOperatorTestHarness<String, EnrichedSnapshot, Tuple3<String, String, SnapshotWrapper>> testHarness = testHarness()) {

            testHarness.setup();
            testHarness.open();

            Instant instant = Instant.now();
            EnrichedSnapshot enrichedSnapshot = VehicleStateData.getEnrichedSnapshot(Tenant.HARLEY, instant.toEpochMilli());
            Map<String, SignalData> latestSignals = enrichedSnapshot.getLatestSignals();

            SignalInfo gpsFix = SignalCatalogue.getGpsFixInfo();
            latestSignals.put(gpsFix.getKey(), SignalGenerator.getSignal(gpsFix, 2.0, instant.toEpochMilli()));

            SignalInfo hDop = SignalCatalogue.getHDopInfo();
            latestSignals.put(hDop.getKey(), SignalGenerator.getSignal(hDop, 1.0, instant.toEpochMilli()));

            latestSignals.put(SignalCatalogue.getGpsValidInfo().getKey(), SignalGenerator.getSignalBoolean(true, instant.toEpochMilli()));

            enrichedSnapshot.setLatestSignals(latestSignals);

            testHarness.processElement(new StreamRecord<>(enrichedSnapshot));

            List<Tuple3<String, String, SnapshotWrapper>> output = VehicleStateData.getOutput(testHarness.getRecordOutput());
            Assert.assertEquals(1, output.size());

            Tuple3<String, String, SnapshotWrapper> value = output.get(0);
            Assert.assertEquals(VehicleStateData.HARLEY_SNAPSHOT_INDEX, value.f0);
            Assert.assertEquals(VehicleStateData.VIRTUAL_ID, value.f1);

            MapState<String, SnapshotWrapper> preferencesStateMap = getVehicleStateMap(testHarness);

            SnapshotWrapper snapshotWrapper = preferencesStateMap.get(VehicleStateData.VIRTUAL_ID);
            Assert.assertNotNull(snapshotWrapper);

            CommonSnapshot commonSnapshot = snapshotWrapper.getCommonSnapshot();
            Assert.assertNotNull(commonSnapshot);
            Assert.assertNotNull(commonSnapshot.getGpsFix());
            Assert.assertNotNull(commonSnapshot.getGpsValid());
            Assert.assertNotNull(commonSnapshot.getLatitude());
            Assert.assertNotNull(commonSnapshot.getLongitude());
            Assert.assertNotNull(commonSnapshot.getHDop());
            Assert.assertNotNull(commonSnapshot.getPDop());
            Assert.assertNotNull(commonSnapshot.getVDop());

            IceSnapshot iceSnapshot = snapshotWrapper.getIceSnapshot();
            Assert.assertNotNull(iceSnapshot);

            EvSnapshot evSnapshot = snapshotWrapper.getEvSnapshot();
            Assert.assertNull(evSnapshot);

            // Sending the data with updated time value
            EnrichedSnapshot enrichedSnapshot1 = VehicleStateData.getEnrichedSnapshot(Tenant.HARLEY, Instant.now().toEpochMilli());
            testHarness.processElement(new StreamRecord<>(enrichedSnapshot1));
            List<Tuple3<String, String, SnapshotWrapper>> output1 = VehicleStateData.getOutput(testHarness.getRecordOutput());
            Assert.assertEquals(2, output1.size());

        } catch (Exception e) {
            throw new FlinkRuntimeException(e);
        }
    }

    @Test
    public void testVehicleSnapshotMapperFunction_invalidHDop() {
        try (KeyedOneInputStreamOperatorTestHarness<String, EnrichedSnapshot, Tuple3<String, String, SnapshotWrapper>> testHarness = testHarness()) {

            testHarness.setup();
            testHarness.open();

            Instant instant = Instant.now();
            EnrichedSnapshot enrichedSnapshot = VehicleStateData.getEnrichedSnapshot(Tenant.HARLEY, instant.toEpochMilli());
            Map<String, SignalData> latestSignals = enrichedSnapshot.getLatestSignals();

            SignalInfo gpsFix = SignalCatalogue.getGpsFixInfo();
            latestSignals.put(gpsFix.getKey(), SignalGenerator.getSignal(gpsFix, 1.0, instant.toEpochMilli()));

            SignalInfo hDop = SignalCatalogue.getHDopInfo();
            latestSignals.put(hDop.getKey(), SignalGenerator.getSignal(hDop, 3.1, instant.toEpochMilli()));

            latestSignals.put(SignalCatalogue.getGpsValidInfo().getKey(), SignalGenerator.getSignalBoolean(true, instant.toEpochMilli()));

            enrichedSnapshot.setLatestSignals(latestSignals);

            testHarness.processElement(new StreamRecord<>(enrichedSnapshot));

            List<Tuple3<String, String, SnapshotWrapper>> output = VehicleStateData.getOutput(testHarness.getRecordOutput());
            Assert.assertEquals(1, output.size());

            Tuple3<String, String, SnapshotWrapper> value = output.get(0);
            Assert.assertEquals(VehicleStateData.HARLEY_SNAPSHOT_INDEX, value.f0);
            Assert.assertEquals(VehicleStateData.VIRTUAL_ID, value.f1);

            MapState<String, SnapshotWrapper> preferencesStateMap = getVehicleStateMap(testHarness);

            SnapshotWrapper snapshotWrapper = preferencesStateMap.get(VehicleStateData.VIRTUAL_ID);
            Assert.assertNotNull(snapshotWrapper);

            CommonSnapshot commonSnapshot = snapshotWrapper.getCommonSnapshot();
            Assert.assertNotNull(commonSnapshot);
            Assert.assertNull(commonSnapshot.getGpsFix());
            Assert.assertNull(commonSnapshot.getGpsValid());
            Assert.assertNull(commonSnapshot.getLatitude());
            Assert.assertNull(commonSnapshot.getLongitude());
            Assert.assertNull(commonSnapshot.getHDop());
            Assert.assertNull(commonSnapshot.getPDop());
            Assert.assertNull(commonSnapshot.getVDop());

            IceSnapshot iceSnapshot = snapshotWrapper.getIceSnapshot();
            Assert.assertNotNull(iceSnapshot);

            EvSnapshot evSnapshot = snapshotWrapper.getEvSnapshot();
            Assert.assertNull(evSnapshot);

            // Sending the data with updated time value
            EnrichedSnapshot enrichedSnapshot1 = VehicleStateData.getEnrichedSnapshot(Tenant.HARLEY, Instant.now().toEpochMilli());
            testHarness.processElement(new StreamRecord<>(enrichedSnapshot1));
            List<Tuple3<String, String, SnapshotWrapper>> output1 = VehicleStateData.getOutput(testHarness.getRecordOutput());
            Assert.assertEquals(2, output1.size());

        } catch (Exception e) {
            throw new FlinkRuntimeException(e);
        }
    }

    @Test
    public void testVehicleSnapshotMapperFunction_validHDop() {
        try (KeyedOneInputStreamOperatorTestHarness<String, EnrichedSnapshot, Tuple3<String, String, SnapshotWrapper>> testHarness = testHarness()) {

            testHarness.setup();
            testHarness.open();

            Instant instant = Instant.now();
            EnrichedSnapshot enrichedSnapshot = VehicleStateData.getEnrichedSnapshot(Tenant.HARLEY, instant.toEpochMilli());
            Map<String, SignalData> latestSignals = enrichedSnapshot.getLatestSignals();

            SignalInfo gpsFix = SignalCatalogue.getGpsFixInfo();
            latestSignals.put(gpsFix.getKey(), SignalGenerator.getSignal(gpsFix, 2.0, instant.toEpochMilli()));

            SignalInfo hDop = SignalCatalogue.getHDopInfo();
            latestSignals.put(hDop.getKey(), SignalGenerator.getSignal(hDop, 1.0, instant.toEpochMilli()));

            latestSignals.put(SignalCatalogue.getGpsValidInfo().getKey(), SignalGenerator.getSignalBoolean(true, instant.toEpochMilli()));

            enrichedSnapshot.setLatestSignals(latestSignals);

            testHarness.processElement(new StreamRecord<>(enrichedSnapshot));

            List<Tuple3<String, String, SnapshotWrapper>> output = VehicleStateData.getOutput(testHarness.getRecordOutput());
            Assert.assertEquals(1, output.size());

            Tuple3<String, String, SnapshotWrapper> value = output.get(0);
            Assert.assertEquals(VehicleStateData.HARLEY_SNAPSHOT_INDEX, value.f0);
            Assert.assertEquals(VehicleStateData.VIRTUAL_ID, value.f1);

            MapState<String, SnapshotWrapper> preferencesStateMap = getVehicleStateMap(testHarness);

            SnapshotWrapper snapshotWrapper = preferencesStateMap.get(VehicleStateData.VIRTUAL_ID);
            Assert.assertNotNull(snapshotWrapper);

            CommonSnapshot commonSnapshot = snapshotWrapper.getCommonSnapshot();
            Assert.assertNotNull(commonSnapshot);
            Assert.assertNotNull(commonSnapshot.getGpsFix());
            Assert.assertNotNull(commonSnapshot.getGpsValid());
            Assert.assertNotNull(commonSnapshot.getLatitude());
            Assert.assertNotNull(commonSnapshot.getLongitude());
            Assert.assertNotNull(commonSnapshot.getHDop());
            Assert.assertNotNull(commonSnapshot.getPDop());
            Assert.assertNotNull(commonSnapshot.getVDop());

            IceSnapshot iceSnapshot = snapshotWrapper.getIceSnapshot();
            Assert.assertNotNull(iceSnapshot);

            EvSnapshot evSnapshot = snapshotWrapper.getEvSnapshot();
            Assert.assertNull(evSnapshot);

            // Sending the data with updated time value
            EnrichedSnapshot enrichedSnapshot1 = VehicleStateData.getEnrichedSnapshot(Tenant.HARLEY, Instant.now().toEpochMilli());
            testHarness.processElement(new StreamRecord<>(enrichedSnapshot1));
            List<Tuple3<String, String, SnapshotWrapper>> output1 = VehicleStateData.getOutput(testHarness.getRecordOutput());
            Assert.assertEquals(2, output1.size());

        } catch (Exception e) {
            throw new FlinkRuntimeException(e);
        }
    }

    @Test
    public void testVehicleSnapshotMapperFunction_invalidGpsValid() {
        try (KeyedOneInputStreamOperatorTestHarness<String, EnrichedSnapshot, Tuple3<String, String, SnapshotWrapper>> testHarness = testHarness()) {

            testHarness.setup();
            testHarness.open();

            Instant instant = Instant.now();
            EnrichedSnapshot enrichedSnapshot = VehicleStateData.getEnrichedSnapshot(Tenant.HARLEY, instant.toEpochMilli());
            Map<String, SignalData> latestSignals = enrichedSnapshot.getLatestSignals();

            SignalInfo gpsFix = SignalCatalogue.getGpsFixInfo();
            latestSignals.put(gpsFix.getKey(), SignalGenerator.getSignal(gpsFix, 1.0, instant.toEpochMilli()));

            SignalInfo hDop = SignalCatalogue.getHDopInfo();
            latestSignals.put(hDop.getKey(), SignalGenerator.getSignal(hDop, 3.1, instant.toEpochMilli()));

            latestSignals.put(SignalCatalogue.getGpsValidInfo().getKey(), SignalGenerator.getSignalBoolean(false, instant.toEpochMilli()));

            enrichedSnapshot.setLatestSignals(latestSignals);

            testHarness.processElement(new StreamRecord<>(enrichedSnapshot));

            List<Tuple3<String, String, SnapshotWrapper>> output = VehicleStateData.getOutput(testHarness.getRecordOutput());
            Assert.assertEquals(1, output.size());

            Tuple3<String, String, SnapshotWrapper> value = output.get(0);
            Assert.assertEquals(VehicleStateData.HARLEY_SNAPSHOT_INDEX, value.f0);
            Assert.assertEquals(VehicleStateData.VIRTUAL_ID, value.f1);

            MapState<String, SnapshotWrapper> preferencesStateMap = getVehicleStateMap(testHarness);

            SnapshotWrapper snapshotWrapper = preferencesStateMap.get(VehicleStateData.VIRTUAL_ID);
            Assert.assertNotNull(snapshotWrapper);

            CommonSnapshot commonSnapshot = snapshotWrapper.getCommonSnapshot();
            Assert.assertNotNull(commonSnapshot);
            Assert.assertNull(commonSnapshot.getGpsFix());
            Assert.assertNull(commonSnapshot.getGpsValid());
            Assert.assertNull(commonSnapshot.getLatitude());
            Assert.assertNull(commonSnapshot.getLongitude());
            Assert.assertNull(commonSnapshot.getHDop());
            Assert.assertNull(commonSnapshot.getPDop());
            Assert.assertNull(commonSnapshot.getVDop());

            IceSnapshot iceSnapshot = snapshotWrapper.getIceSnapshot();
            Assert.assertNotNull(iceSnapshot);

            EvSnapshot evSnapshot = snapshotWrapper.getEvSnapshot();
            Assert.assertNull(evSnapshot);

            // Sending the data with updated time value
            EnrichedSnapshot enrichedSnapshot1 = VehicleStateData.getEnrichedSnapshot(Tenant.HARLEY, Instant.now().toEpochMilli());
            testHarness.processElement(new StreamRecord<>(enrichedSnapshot1));
            List<Tuple3<String, String, SnapshotWrapper>> output1 = VehicleStateData.getOutput(testHarness.getRecordOutput());
            Assert.assertEquals(2, output1.size());

        } catch (Exception e) {
            throw new FlinkRuntimeException(e);
        }
    }

    @Test
    public void testVehicleSnapshotMapperFunction_validGpsValid() {
        try (KeyedOneInputStreamOperatorTestHarness<String, EnrichedSnapshot, Tuple3<String, String, SnapshotWrapper>> testHarness = testHarness()) {

            testHarness.setup();
            testHarness.open();

            Instant instant = Instant.now();
            EnrichedSnapshot enrichedSnapshot = VehicleStateData.getEnrichedSnapshot(Tenant.HARLEY, instant.toEpochMilli());
            Map<String, SignalData> latestSignals = enrichedSnapshot.getLatestSignals();

            SignalInfo gpsFix = SignalCatalogue.getGpsFixInfo();
            latestSignals.put(gpsFix.getKey(), SignalGenerator.getSignal(gpsFix, 2.0, instant.toEpochMilli()));

            SignalInfo hDop = SignalCatalogue.getHDopInfo();
            latestSignals.put(hDop.getKey(), SignalGenerator.getSignal(hDop, 1.0, instant.toEpochMilli()));

            latestSignals.put(SignalCatalogue.getGpsValidInfo().getKey(), SignalGenerator.getSignalBoolean(true, instant.toEpochMilli()));

            enrichedSnapshot.setLatestSignals(latestSignals);

            testHarness.processElement(new StreamRecord<>(enrichedSnapshot));

            List<Tuple3<String, String, SnapshotWrapper>> output = VehicleStateData.getOutput(testHarness.getRecordOutput());
            Assert.assertEquals(1, output.size());

            Tuple3<String, String, SnapshotWrapper> value = output.get(0);
            Assert.assertEquals(VehicleStateData.HARLEY_SNAPSHOT_INDEX, value.f0);
            Assert.assertEquals(VehicleStateData.VIRTUAL_ID, value.f1);

            MapState<String, SnapshotWrapper> preferencesStateMap = getVehicleStateMap(testHarness);

            SnapshotWrapper snapshotWrapper = preferencesStateMap.get(VehicleStateData.VIRTUAL_ID);
            Assert.assertNotNull(snapshotWrapper);

            CommonSnapshot commonSnapshot = snapshotWrapper.getCommonSnapshot();
            Assert.assertNotNull(commonSnapshot);
            Assert.assertNotNull(commonSnapshot.getGpsFix());
            Assert.assertNotNull(commonSnapshot.getGpsValid());
            Assert.assertNotNull(commonSnapshot.getLatitude());
            Assert.assertNotNull(commonSnapshot.getLongitude());
            Assert.assertNotNull(commonSnapshot.getHDop());
            Assert.assertNotNull(commonSnapshot.getPDop());
            Assert.assertNotNull(commonSnapshot.getVDop());

            IceSnapshot iceSnapshot = snapshotWrapper.getIceSnapshot();
            Assert.assertNotNull(iceSnapshot);

            EvSnapshot evSnapshot = snapshotWrapper.getEvSnapshot();
            Assert.assertNull(evSnapshot);

            // Sending the data with updated time value
            EnrichedSnapshot enrichedSnapshot1 = VehicleStateData.getEnrichedSnapshot(Tenant.HARLEY, Instant.now().toEpochMilli());
            testHarness.processElement(new StreamRecord<>(enrichedSnapshot1));
            List<Tuple3<String, String, SnapshotWrapper>> output1 = VehicleStateData.getOutput(testHarness.getRecordOutput());
            Assert.assertEquals(2, output1.size());

        } catch (Exception e) {
            throw new FlinkRuntimeException(e);
        }
    }

    @Test
    public void testVehicleSnapshotMapperFunction_thermalRunawayAlert() {
        try (KeyedOneInputStreamOperatorTestHarness<String, EnrichedSnapshot, Tuple3<String, String, SnapshotWrapper>> testHarness = testHarness()) {

            testHarness.setup();
            testHarness.open();

            Instant instant = Instant.now();
            EnrichedSnapshot enrichedSnapshot = VehicleStateData.getEnrichedSnapshot(Tenant.EV, Instant.now().toEpochMilli());
            Map<String, SignalData> latestSignals = enrichedSnapshot.getLatestSignals();

            SignalInfo thermalRunaway = SignalCatalogue.getThermalRunawayWarningInfo();
            latestSignals.put(thermalRunaway.getKey(), SignalGenerator.getSignal(thermalRunaway, 5.0, instant.toEpochMilli()));

            enrichedSnapshot.setLatestSignals(latestSignals);

            testHarness.processElement(new StreamRecord<>(enrichedSnapshot));

            List<Tuple3<String, String, SnapshotWrapper>> output = VehicleStateData.getOutput(testHarness.getRecordOutput());
            Assert.assertEquals(1, output.size());

            Tuple3<String, String, SnapshotWrapper> value = output.get(0);
            Assert.assertEquals(VehicleStateData.EV_SNAPSHOT_INDEX, value.f0);
            Assert.assertEquals(VehicleStateData.VIRTUAL_ID, value.f1);

            MapState<String, SnapshotWrapper> preferencesStateMap = getVehicleStateMap(testHarness);

            SnapshotWrapper snapshotWrapper = preferencesStateMap.get(VehicleStateData.VIRTUAL_ID);
            Assert.assertNotNull(snapshotWrapper);

            CommonSnapshot commonSnapshot = snapshotWrapper.getCommonSnapshot();
            Assert.assertNotNull(commonSnapshot);
            Assert.assertEquals(1, commonSnapshot.getThermalRunaway().getValue());
            Assert.assertEquals(0, commonSnapshot.getBatteryOverHeating().getValue());

            EvSnapshot evSnapshot = snapshotWrapper.getEvSnapshot();
            Assert.assertNotNull(evSnapshot);

            IceSnapshot iceSnapshot = snapshotWrapper.getIceSnapshot();
            Assert.assertNull(iceSnapshot);

        } catch (Exception e) {
            throw new FlinkRuntimeException(e);
        }
    }

    @Test
    public void testVehicleSnapshotMapperFunction_batteryOverHeartingAlert() {
        try (KeyedOneInputStreamOperatorTestHarness<String, EnrichedSnapshot, Tuple3<String, String, SnapshotWrapper>> testHarness = testHarness()) {

            testHarness.setup();
            testHarness.open();

            Instant instant = Instant.now();
            EnrichedSnapshot enrichedSnapshot = VehicleStateData.getEnrichedSnapshot(Tenant.EV, Instant.now().toEpochMilli());
            Map<String, SignalData> latestSignals = enrichedSnapshot.getLatestSignals();

            SignalInfo thermalRunaway = SignalCatalogue.getThermalRunawayWarningInfo();
            latestSignals.put(thermalRunaway.getKey(), SignalGenerator.getSignal(thermalRunaway, 3.0, instant.toEpochMilli()));

            enrichedSnapshot.setLatestSignals(latestSignals);

            testHarness.processElement(new StreamRecord<>(enrichedSnapshot));

            List<Tuple3<String, String, SnapshotWrapper>> output = VehicleStateData.getOutput(testHarness.getRecordOutput());
            Assert.assertEquals(1, output.size());

            Tuple3<String, String, SnapshotWrapper> value = output.get(0);
            Assert.assertEquals(VehicleStateData.EV_SNAPSHOT_INDEX, value.f0);
            Assert.assertEquals(VehicleStateData.VIRTUAL_ID, value.f1);

            MapState<String, SnapshotWrapper> preferencesStateMap = getVehicleStateMap(testHarness);

            SnapshotWrapper snapshotWrapper = preferencesStateMap.get(VehicleStateData.VIRTUAL_ID);
            Assert.assertNotNull(snapshotWrapper);

            CommonSnapshot commonSnapshot = snapshotWrapper.getCommonSnapshot();
            Assert.assertNotNull(commonSnapshot);
            Assert.assertEquals(0, commonSnapshot.getThermalRunaway().getValue());
            Assert.assertEquals(1, commonSnapshot.getBatteryOverHeating().getValue());

            EvSnapshot evSnapshot = snapshotWrapper.getEvSnapshot();
            Assert.assertNotNull(evSnapshot);

            IceSnapshot iceSnapshot = snapshotWrapper.getIceSnapshot();
            Assert.assertNull(iceSnapshot);

        } catch (Exception e) {
            throw new FlinkRuntimeException(e);
        }
    }

    @Test
    public void testVehicleSnapshotMapperFunction_noThermalAlerts() {
        try (KeyedOneInputStreamOperatorTestHarness<String, EnrichedSnapshot, Tuple3<String, String, SnapshotWrapper>> testHarness = testHarness()) {

            testHarness.setup();
            testHarness.open();

            Instant instant = Instant.now();
            EnrichedSnapshot enrichedSnapshot = VehicleStateData.getEnrichedSnapshot(Tenant.EV, Instant.now().toEpochMilli());
            Map<String, SignalData> latestSignals = enrichedSnapshot.getLatestSignals();

            SignalInfo thermalRunaway = SignalCatalogue.getThermalRunawayWarningInfo();
            latestSignals.put(thermalRunaway.getKey(), SignalGenerator.getSignal(thermalRunaway, 2.0, instant.toEpochMilli()));

            enrichedSnapshot.setLatestSignals(latestSignals);

            testHarness.processElement(new StreamRecord<>(enrichedSnapshot));

            List<Tuple3<String, String, SnapshotWrapper>> output = VehicleStateData.getOutput(testHarness.getRecordOutput());
            Assert.assertEquals(1, output.size());

            Tuple3<String, String, SnapshotWrapper> value = output.get(0);
            Assert.assertEquals(VehicleStateData.EV_SNAPSHOT_INDEX, value.f0);
            Assert.assertEquals(VehicleStateData.VIRTUAL_ID, value.f1);

            MapState<String, SnapshotWrapper> preferencesStateMap = getVehicleStateMap(testHarness);

            SnapshotWrapper snapshotWrapper = preferencesStateMap.get(VehicleStateData.VIRTUAL_ID);
            Assert.assertNotNull(snapshotWrapper);

            CommonSnapshot commonSnapshot = snapshotWrapper.getCommonSnapshot();
            Assert.assertNotNull(commonSnapshot);
            Assert.assertEquals(0, commonSnapshot.getThermalRunaway().getValue());
            Assert.assertEquals(0, commonSnapshot.getBatteryOverHeating().getValue());

            EvSnapshot evSnapshot = snapshotWrapper.getEvSnapshot();
            Assert.assertNotNull(evSnapshot);

            IceSnapshot iceSnapshot = snapshotWrapper.getIceSnapshot();
            Assert.assertNull(iceSnapshot);

        } catch (Exception e) {
            throw new FlinkRuntimeException(e);
        }
    }

    @Test
    public void testVehicleSnapshotMapperFunction_multiAlertAuxBatteryLowFall() {
        try (KeyedOneInputStreamOperatorTestHarness<String, EnrichedSnapshot, Tuple3<String, String, SnapshotWrapper>> testHarness = testHarness()) {

            testHarness.setup();
            testHarness.open();

            Instant instant = Instant.now();
            EnrichedSnapshot enrichedSnapshot = VehicleStateData.getEnrichedSnapshot(Tenant.EV, Instant.now().toEpochMilli());

            List<String> alerts1 = new ArrayList<>();
            alerts1.add(MultiAlertSignals.AUX_BATTERY_LOW_ALERT_FALL_SIGNAL);
            SignalData signalData1 = new SignalData();
            signalData1.setDataType("VARCHAR");
            signalData1.setTime(instant.plusSeconds(10).toEpochMilli());
            signalData1.setValue(GsonUtils.toJson(alerts1));

            Set<SignalData> signalDataSet = new HashSet<>();
            signalDataSet.add(signalData1);

            enrichedSnapshot.setMultiAlertsData(signalDataSet);

            testHarness.processElement(new StreamRecord<>(enrichedSnapshot));

            List<Tuple3<String, String, SnapshotWrapper>> output = VehicleStateData.getOutput(testHarness.getRecordOutput());
            Assert.assertEquals(1, output.size());

            Tuple3<String, String, SnapshotWrapper> value = output.get(0);
            Assert.assertEquals(VehicleStateData.EV_SNAPSHOT_INDEX, value.f0);
            Assert.assertEquals(VehicleStateData.VIRTUAL_ID, value.f1);

            MapState<String, SnapshotWrapper> preferencesStateMap = getVehicleStateMap(testHarness);

            SnapshotWrapper snapshotWrapper = preferencesStateMap.get(VehicleStateData.VIRTUAL_ID);
            Assert.assertNotNull(snapshotWrapper);

            CommonSnapshot commonSnapshot = snapshotWrapper.getCommonSnapshot();
            Assert.assertNotNull(commonSnapshot);
            Assert.assertNotNull(commonSnapshot.getAuxBatteryLow());
            Assert.assertEquals(0, commonSnapshot.getAuxBatteryLow().getValue());

        } catch (Exception e) {
            throw new FlinkRuntimeException(e);
        }
    }

    @Test
    public void testVehicleSnapshotMapperFunction_multiAlertAuxBatteryLowRise() {
        try (KeyedOneInputStreamOperatorTestHarness<String, EnrichedSnapshot, Tuple3<String, String, SnapshotWrapper>> testHarness = testHarness()) {

            testHarness.setup();
            testHarness.open();

            Instant instant = Instant.now().minusSeconds(20);
            EnrichedSnapshot enrichedSnapshot = VehicleStateData.getEnrichedSnapshot(Tenant.EV, instant.toEpochMilli());

            List<String> alerts1 = new ArrayList<>();
            alerts1.add(MultiAlertSignals.AUX_BATTERY_LOW_ALERT_RISE_SIGNAL);
            SignalData signalData1 = new SignalData();
            signalData1.setDataType("VARCHAR");
            signalData1.setTime(instant.plusSeconds(10).toEpochMilli());
            signalData1.setValue(GsonUtils.toJson(alerts1));

            Set<SignalData> signalDataSet = new HashSet<>();
            signalDataSet.add(signalData1);

            enrichedSnapshot.setMultiAlertsData(signalDataSet);

            testHarness.processElement(new StreamRecord<>(enrichedSnapshot));

            List<Tuple3<String, String, SnapshotWrapper>> output = VehicleStateData.getOutput(testHarness.getRecordOutput());
            Assert.assertEquals(1, output.size());

            Tuple3<String, String, SnapshotWrapper> value = output.get(0);
            Assert.assertEquals(VehicleStateData.EV_SNAPSHOT_INDEX, value.f0);
            Assert.assertEquals(VehicleStateData.VIRTUAL_ID, value.f1);

            MapState<String, SnapshotWrapper> preferencesStateMap = getVehicleStateMap(testHarness);

            SnapshotWrapper snapshotWrapper = preferencesStateMap.get(VehicleStateData.VIRTUAL_ID);
            Assert.assertNotNull(snapshotWrapper);

            CommonSnapshot commonSnapshot = snapshotWrapper.getCommonSnapshot();
            Assert.assertNotNull(commonSnapshot);
            Assert.assertNotNull(commonSnapshot.getAuxBatteryLow());
            Assert.assertEquals(1, commonSnapshot.getAuxBatteryLow().getValue());

        } catch (Exception e) {
            throw new FlinkRuntimeException(e);
        }
    }

    @Test
    public void testVehicleSnapshotMapperFunction_multiAlertAuxBatteryUnpluggedFall() {
        try (KeyedOneInputStreamOperatorTestHarness<String, EnrichedSnapshot, Tuple3<String, String, SnapshotWrapper>> testHarness = testHarness()) {

            testHarness.setup();
            testHarness.open();

            Instant instant = Instant.now().minusSeconds(20);
            EnrichedSnapshot enrichedSnapshot = VehicleStateData.getEnrichedSnapshot(Tenant.EV, instant.toEpochMilli());

            List<String> alerts1 = new ArrayList<>();
            alerts1.add(MultiAlertSignals.AUX_BATTERY_UNPLUGGED_ALERT_FALL_SIGNAL);
            SignalData signalData1 = new SignalData();
            signalData1.setDataType("VARCHAR");
            signalData1.setTime(instant.plusSeconds(10).toEpochMilli());
            signalData1.setValue(GsonUtils.toJson(alerts1));

            Set<SignalData> signalDataSet = new HashSet<>();
            signalDataSet.add(signalData1);

            enrichedSnapshot.setMultiAlertsData(signalDataSet);

            testHarness.processElement(new StreamRecord<>(enrichedSnapshot));

            List<Tuple3<String, String, SnapshotWrapper>> output = VehicleStateData.getOutput(testHarness.getRecordOutput());
            Assert.assertEquals(1, output.size());

            Tuple3<String, String, SnapshotWrapper> value = output.get(0);
            Assert.assertEquals(VehicleStateData.EV_SNAPSHOT_INDEX, value.f0);
            Assert.assertEquals(VehicleStateData.VIRTUAL_ID, value.f1);

            MapState<String, SnapshotWrapper> preferencesStateMap = getVehicleStateMap(testHarness);

            SnapshotWrapper snapshotWrapper = preferencesStateMap.get(VehicleStateData.VIRTUAL_ID);
            Assert.assertNotNull(snapshotWrapper);

            CommonSnapshot commonSnapshot = snapshotWrapper.getCommonSnapshot();
            Assert.assertNotNull(commonSnapshot);
            Assert.assertNotNull(commonSnapshot.getAuxBatteryUnplugged());
            Assert.assertEquals(0, commonSnapshot.getAuxBatteryUnplugged().getValue());

        } catch (Exception e) {
            throw new FlinkRuntimeException(e);
        }
    }

    @Test
    public void testVehicleSnapshotMapperFunction_multiAlertAuxBatteryUnpluggedRise() {
        try (KeyedOneInputStreamOperatorTestHarness<String, EnrichedSnapshot, Tuple3<String, String, SnapshotWrapper>> testHarness = testHarness()) {

            testHarness.setup();
            testHarness.open();

            Instant instant = Instant.now().minusSeconds(20);
            EnrichedSnapshot enrichedSnapshot = VehicleStateData.getEnrichedSnapshot(Tenant.EV, instant.toEpochMilli());

            List<String> alerts1 = new ArrayList<>();
            alerts1.add(MultiAlertSignals.AUX_BATTERY_UNPLUGGED_ALERT_RISE_SIGNAL);
            SignalData signalData1 = new SignalData();
            signalData1.setDataType("VARCHAR");
            signalData1.setTime(instant.plusSeconds(10).toEpochMilli());
            signalData1.setValue(GsonUtils.toJson(alerts1));

            Set<SignalData> signalDataSet = new HashSet<>();
            signalDataSet.add(signalData1);

            enrichedSnapshot.setMultiAlertsData(signalDataSet);

            testHarness.processElement(new StreamRecord<>(enrichedSnapshot));

            List<Tuple3<String, String, SnapshotWrapper>> output = VehicleStateData.getOutput(testHarness.getRecordOutput());
            Assert.assertEquals(1, output.size());

            Tuple3<String, String, SnapshotWrapper> value = output.get(0);
            Assert.assertEquals(VehicleStateData.EV_SNAPSHOT_INDEX, value.f0);
            Assert.assertEquals(VehicleStateData.VIRTUAL_ID, value.f1);

            MapState<String, SnapshotWrapper> preferencesStateMap = getVehicleStateMap(testHarness);

            SnapshotWrapper snapshotWrapper = preferencesStateMap.get(VehicleStateData.VIRTUAL_ID);
            Assert.assertNotNull(snapshotWrapper);

            CommonSnapshot commonSnapshot = snapshotWrapper.getCommonSnapshot();
            Assert.assertNotNull(commonSnapshot);
            Assert.assertNotNull(commonSnapshot.getAuxBatteryUnplugged());
            Assert.assertEquals(1, commonSnapshot.getAuxBatteryUnplugged().getValue());

        } catch (Exception e) {
            throw new FlinkRuntimeException(e);
        }
    }

    @Test
    public void testVehicleSnapshotMapperFunction_multiAlertAccidentFall() {
        try (KeyedOneInputStreamOperatorTestHarness<String, EnrichedSnapshot, Tuple3<String, String, SnapshotWrapper>> testHarness = testHarness()) {

            testHarness.setup();
            testHarness.open();

            Instant instant = Instant.now().minusSeconds(20);
            EnrichedSnapshot enrichedSnapshot = VehicleStateData.getEnrichedSnapshot(Tenant.EV, instant.toEpochMilli());

            List<String> alerts1 = new ArrayList<>();
            alerts1.add(MultiAlertSignals.ACCIDENT_CRASH_ALERT_FALL_SIGNAL);
            SignalData signalData1 = new SignalData();
            signalData1.setDataType("VARCHAR");
            signalData1.setTime(instant.plusSeconds(10).toEpochMilli());
            signalData1.setValue(GsonUtils.toJson(alerts1));

            Set<SignalData> signalDataSet = new HashSet<>();
            signalDataSet.add(signalData1);

            enrichedSnapshot.setMultiAlertsData(signalDataSet);

            testHarness.processElement(new StreamRecord<>(enrichedSnapshot));

            List<Tuple3<String, String, SnapshotWrapper>> output = VehicleStateData.getOutput(testHarness.getRecordOutput());
            Assert.assertEquals(1, output.size());

            Tuple3<String, String, SnapshotWrapper> value = output.get(0);
            Assert.assertEquals(VehicleStateData.EV_SNAPSHOT_INDEX, value.f0);
            Assert.assertEquals(VehicleStateData.VIRTUAL_ID, value.f1);

            MapState<String, SnapshotWrapper> preferencesStateMap = getVehicleStateMap(testHarness);

            SnapshotWrapper snapshotWrapper = preferencesStateMap.get(VehicleStateData.VIRTUAL_ID);
            Assert.assertNotNull(snapshotWrapper);

            CommonSnapshot commonSnapshot = snapshotWrapper.getCommonSnapshot();
            Assert.assertNotNull(commonSnapshot);
            Assert.assertNotNull(commonSnapshot.getCrashAndAccident());
            Assert.assertEquals(0, commonSnapshot.getCrashAndAccident().getValue());

        } catch (Exception e) {
            throw new FlinkRuntimeException(e);
        }
    }

    @Test
    public void testVehicleSnapshotMapperFunction_multiAlertAccidentRise() {
        try (KeyedOneInputStreamOperatorTestHarness<String, EnrichedSnapshot, Tuple3<String, String, SnapshotWrapper>> testHarness = testHarness()) {

            testHarness.setup();
            testHarness.open();

            Instant instant = Instant.now().minusSeconds(20);
            EnrichedSnapshot enrichedSnapshot = VehicleStateData.getEnrichedSnapshot(Tenant.EV, instant.toEpochMilli());

            List<String> alerts1 = new ArrayList<>();
            alerts1.add(MultiAlertSignals.ACCIDENT_CRASH_ALERT_RISE_SIGNAL);
            SignalData signalData1 = new SignalData();
            signalData1.setDataType("VARCHAR");
            signalData1.setTime(instant.plusSeconds(10).toEpochMilli());
            signalData1.setValue(GsonUtils.toJson(alerts1));

            Set<SignalData> signalDataSet = new HashSet<>();
            signalDataSet.add(signalData1);

            enrichedSnapshot.setMultiAlertsData(signalDataSet);

            testHarness.processElement(new StreamRecord<>(enrichedSnapshot));

            List<Tuple3<String, String, SnapshotWrapper>> output = VehicleStateData.getOutput(testHarness.getRecordOutput());
            Assert.assertEquals(1, output.size());

            Tuple3<String, String, SnapshotWrapper> value = output.get(0);
            Assert.assertEquals(VehicleStateData.EV_SNAPSHOT_INDEX, value.f0);
            Assert.assertEquals(VehicleStateData.VIRTUAL_ID, value.f1);

            MapState<String, SnapshotWrapper> preferencesStateMap = getVehicleStateMap(testHarness);

            SnapshotWrapper snapshotWrapper = preferencesStateMap.get(VehicleStateData.VIRTUAL_ID);
            Assert.assertNotNull(snapshotWrapper);

            CommonSnapshot commonSnapshot = snapshotWrapper.getCommonSnapshot();
            Assert.assertNotNull(commonSnapshot);
            Assert.assertNotNull(commonSnapshot.getCrashAndAccident());
            Assert.assertEquals(1, commonSnapshot.getCrashAndAccident().getValue());

        } catch (Exception e) {
            throw new FlinkRuntimeException(e);
        }
    }

    @Test
    public void testVehicleSnapshotMapperFunction_multiAlertFallDownFall() {
        try (KeyedOneInputStreamOperatorTestHarness<String, EnrichedSnapshot, Tuple3<String, String, SnapshotWrapper>> testHarness = testHarness()) {

            testHarness.setup();
            testHarness.open();

            Instant instant = Instant.now().minusSeconds(20);
            EnrichedSnapshot enrichedSnapshot = VehicleStateData.getEnrichedSnapshot(Tenant.EV, instant.toEpochMilli());

            List<String> alerts1 = new ArrayList<>();
            alerts1.add(MultiAlertSignals.FALLDOWN_ALERT_FALL_SIGNAL);
            SignalData signalData1 = new SignalData();
            signalData1.setDataType("VARCHAR");
            signalData1.setTime(instant.plusSeconds(10).toEpochMilli());
            signalData1.setValue(GsonUtils.toJson(alerts1));

            Set<SignalData> signalDataSet = new HashSet<>();
            signalDataSet.add(signalData1);

            enrichedSnapshot.setMultiAlertsData(signalDataSet);

            testHarness.processElement(new StreamRecord<>(enrichedSnapshot));

            List<Tuple3<String, String, SnapshotWrapper>> output = VehicleStateData.getOutput(testHarness.getRecordOutput());
            Assert.assertEquals(1, output.size());

            Tuple3<String, String, SnapshotWrapper> value = output.get(0);
            Assert.assertEquals(VehicleStateData.EV_SNAPSHOT_INDEX, value.f0);
            Assert.assertEquals(VehicleStateData.VIRTUAL_ID, value.f1);

            MapState<String, SnapshotWrapper> preferencesStateMap = getVehicleStateMap(testHarness);

            SnapshotWrapper snapshotWrapper = preferencesStateMap.get(VehicleStateData.VIRTUAL_ID);
            Assert.assertNotNull(snapshotWrapper);

            CommonSnapshot commonSnapshot = snapshotWrapper.getCommonSnapshot();
            Assert.assertNotNull(commonSnapshot);
            Assert.assertNotNull(commonSnapshot.getFallDown());
            Assert.assertEquals(0, commonSnapshot.getFallDown().getValue());

        } catch (Exception e) {
            throw new FlinkRuntimeException(e);
        }
    }

    @Test
    public void testVehicleSnapshotMapperFunction_multiAlertFallDownRise() {
        try (KeyedOneInputStreamOperatorTestHarness<String, EnrichedSnapshot, Tuple3<String, String, SnapshotWrapper>> testHarness = testHarness()) {

            testHarness.setup();
            testHarness.open();

            Instant instant = Instant.now().minusSeconds(20);
            EnrichedSnapshot enrichedSnapshot = VehicleStateData.getEnrichedSnapshot(Tenant.EV, instant.toEpochMilli());

            List<String> alerts1 = new ArrayList<>();
            alerts1.add(MultiAlertSignals.FALLDOWN_ALERT_RISE_SIGNAL);
            SignalData signalData1 = new SignalData();
            signalData1.setDataType("VARCHAR");
            signalData1.setTime(instant.plusSeconds(10).toEpochMilli());
            signalData1.setValue(GsonUtils.toJson(alerts1));

            Set<SignalData> signalDataSet = new HashSet<>();
            signalDataSet.add(signalData1);

            enrichedSnapshot.setMultiAlertsData(signalDataSet);

            testHarness.processElement(new StreamRecord<>(enrichedSnapshot));

            List<Tuple3<String, String, SnapshotWrapper>> output = VehicleStateData.getOutput(testHarness.getRecordOutput());
            Assert.assertEquals(1, output.size());

            Tuple3<String, String, SnapshotWrapper> value = output.get(0);
            Assert.assertEquals(VehicleStateData.EV_SNAPSHOT_INDEX, value.f0);
            Assert.assertEquals(VehicleStateData.VIRTUAL_ID, value.f1);

            MapState<String, SnapshotWrapper> preferencesStateMap = getVehicleStateMap(testHarness);

            SnapshotWrapper snapshotWrapper = preferencesStateMap.get(VehicleStateData.VIRTUAL_ID);
            Assert.assertNotNull(snapshotWrapper);

            CommonSnapshot commonSnapshot = snapshotWrapper.getCommonSnapshot();
            Assert.assertNotNull(commonSnapshot);
            Assert.assertNotNull(commonSnapshot.getFallDown());
            Assert.assertEquals(1, commonSnapshot.getFallDown().getValue());

        } catch (Exception e) {
            throw new FlinkRuntimeException(e);
        }
    }

    @Test
    public void testVehicleSnapshotMapperFunction_multiAlertHarshDrivingFall() {
        try (KeyedOneInputStreamOperatorTestHarness<String, EnrichedSnapshot, Tuple3<String, String, SnapshotWrapper>> testHarness = testHarness()) {

            testHarness.setup();
            testHarness.open();

            Instant instant = Instant.now().minusSeconds(20);
            EnrichedSnapshot enrichedSnapshot = VehicleStateData.getEnrichedSnapshot(Tenant.EV, instant.toEpochMilli());

            List<String> alerts1 = new ArrayList<>();
            alerts1.add(MultiAlertSignals.HARSH_ACCELERATION_ALERT_FALL_SIGNAL);
            SignalData signalData1 = new SignalData();
            signalData1.setDataType("VARCHAR");
            signalData1.setTime(instant.plusSeconds(10).toEpochMilli());
            signalData1.setValue(GsonUtils.toJson(alerts1));

            Set<SignalData> signalDataSet = new HashSet<>();
            signalDataSet.add(signalData1);

            enrichedSnapshot.setMultiAlertsData(signalDataSet);

            testHarness.processElement(new StreamRecord<>(enrichedSnapshot));

            List<Tuple3<String, String, SnapshotWrapper>> output = VehicleStateData.getOutput(testHarness.getRecordOutput());
            Assert.assertEquals(1, output.size());

            Tuple3<String, String, SnapshotWrapper> value = output.get(0);
            Assert.assertEquals(VehicleStateData.EV_SNAPSHOT_INDEX, value.f0);
            Assert.assertEquals(VehicleStateData.VIRTUAL_ID, value.f1);

            MapState<String, SnapshotWrapper> preferencesStateMap = getVehicleStateMap(testHarness);

            SnapshotWrapper snapshotWrapper = preferencesStateMap.get(VehicleStateData.VIRTUAL_ID);
            Assert.assertNotNull(snapshotWrapper);

            CommonSnapshot commonSnapshot = snapshotWrapper.getCommonSnapshot();
            Assert.assertNotNull(commonSnapshot);
            Assert.assertNotNull(commonSnapshot.getHarshDriving());
            Assert.assertEquals(0, commonSnapshot.getHarshDriving().getValue());

        } catch (Exception e) {
            throw new FlinkRuntimeException(e);
        }
    }

    @Test
    public void testVehicleSnapshotMapperFunction_multiAlertHarshDrivingRise() {
        try (KeyedOneInputStreamOperatorTestHarness<String, EnrichedSnapshot, Tuple3<String, String, SnapshotWrapper>> testHarness = testHarness()) {

            testHarness.setup();
            testHarness.open();

            Instant instant = Instant.now().minusSeconds(20);
            EnrichedSnapshot enrichedSnapshot = VehicleStateData.getEnrichedSnapshot(Tenant.EV, instant.toEpochMilli());

            List<String> alerts1 = new ArrayList<>();
            alerts1.add(MultiAlertSignals.HARSH_ACCELERATION_ALERT_RISE_SIGNAL);
            SignalData signalData1 = new SignalData();
            signalData1.setDataType("VARCHAR");
            signalData1.setTime(instant.plusSeconds(10).toEpochMilli());
            signalData1.setValue(GsonUtils.toJson(alerts1));

            Set<SignalData> signalDataSet = new HashSet<>();
            signalDataSet.add(signalData1);

            enrichedSnapshot.setMultiAlertsData(signalDataSet);

            testHarness.processElement(new StreamRecord<>(enrichedSnapshot));

            List<Tuple3<String, String, SnapshotWrapper>> output = VehicleStateData.getOutput(testHarness.getRecordOutput());
            Assert.assertEquals(1, output.size());

            Tuple3<String, String, SnapshotWrapper> value = output.get(0);
            Assert.assertEquals(VehicleStateData.EV_SNAPSHOT_INDEX, value.f0);
            Assert.assertEquals(VehicleStateData.VIRTUAL_ID, value.f1);

            MapState<String, SnapshotWrapper> preferencesStateMap = getVehicleStateMap(testHarness);

            SnapshotWrapper snapshotWrapper = preferencesStateMap.get(VehicleStateData.VIRTUAL_ID);
            Assert.assertNotNull(snapshotWrapper);

            CommonSnapshot commonSnapshot = snapshotWrapper.getCommonSnapshot();
            Assert.assertNotNull(commonSnapshot);
            Assert.assertNotNull(commonSnapshot.getHarshDriving());
            Assert.assertEquals(1, commonSnapshot.getHarshDriving().getValue());

        } catch (Exception e) {
            throw new FlinkRuntimeException(e);
        }
    }

    @Test
    public void testVehicleSnapshotMapperFunction_multiAlertHarshBrakingFall() {
        try (KeyedOneInputStreamOperatorTestHarness<String, EnrichedSnapshot, Tuple3<String, String, SnapshotWrapper>> testHarness = testHarness()) {

            testHarness.setup();
            testHarness.open();

            Instant instant = Instant.now().minusSeconds(20);
            EnrichedSnapshot enrichedSnapshot = VehicleStateData.getEnrichedSnapshot(Tenant.EV, instant.toEpochMilli());

            List<String> alerts1 = new ArrayList<>();
            alerts1.add(MultiAlertSignals.HARSH_BRAKING_ALERT_FALL_SIGNAL);
            SignalData signalData1 = new SignalData();
            signalData1.setDataType("VARCHAR");
            signalData1.setTime(instant.plusSeconds(10).toEpochMilli());
            signalData1.setValue(GsonUtils.toJson(alerts1));

            Set<SignalData> signalDataSet = new HashSet<>();
            signalDataSet.add(signalData1);

            enrichedSnapshot.setMultiAlertsData(signalDataSet);

            testHarness.processElement(new StreamRecord<>(enrichedSnapshot));

            List<Tuple3<String, String, SnapshotWrapper>> output = VehicleStateData.getOutput(testHarness.getRecordOutput());
            Assert.assertEquals(1, output.size());

            Tuple3<String, String, SnapshotWrapper> value = output.get(0);
            Assert.assertEquals(VehicleStateData.EV_SNAPSHOT_INDEX, value.f0);
            Assert.assertEquals(VehicleStateData.VIRTUAL_ID, value.f1);

            MapState<String, SnapshotWrapper> preferencesStateMap = getVehicleStateMap(testHarness);

            SnapshotWrapper snapshotWrapper = preferencesStateMap.get(VehicleStateData.VIRTUAL_ID);
            Assert.assertNotNull(snapshotWrapper);

            CommonSnapshot commonSnapshot = snapshotWrapper.getCommonSnapshot();
            Assert.assertNotNull(commonSnapshot);
            Assert.assertNotNull(commonSnapshot.getHarshBraking());
            Assert.assertEquals(0, commonSnapshot.getHarshBraking().getValue());

        } catch (Exception e) {
            throw new FlinkRuntimeException(e);
        }
    }

    @Test
    public void testVehicleSnapshotMapperFunction_multiAlertHarshBrakingRise() {
        try (KeyedOneInputStreamOperatorTestHarness<String, EnrichedSnapshot, Tuple3<String, String, SnapshotWrapper>> testHarness = testHarness()) {

            testHarness.setup();
            testHarness.open();

            Instant instant = Instant.now().minusSeconds(20);
            EnrichedSnapshot enrichedSnapshot = VehicleStateData.getEnrichedSnapshot(Tenant.EV, instant.toEpochMilli());

            List<String> alerts1 = new ArrayList<>();
            alerts1.add(MultiAlertSignals.HARSH_BRAKING_ALERT_RISE_SIGNAL);
            SignalData signalData1 = new SignalData();
            signalData1.setDataType("VARCHAR");
            signalData1.setTime(instant.plusSeconds(10).toEpochMilli());
            signalData1.setValue(GsonUtils.toJson(alerts1));

            Set<SignalData> signalDataSet = new HashSet<>();
            signalDataSet.add(signalData1);

            enrichedSnapshot.setMultiAlertsData(signalDataSet);

            testHarness.processElement(new StreamRecord<>(enrichedSnapshot));

            List<Tuple3<String, String, SnapshotWrapper>> output = VehicleStateData.getOutput(testHarness.getRecordOutput());
            Assert.assertEquals(1, output.size());

            Tuple3<String, String, SnapshotWrapper> value = output.get(0);
            Assert.assertEquals(VehicleStateData.EV_SNAPSHOT_INDEX, value.f0);
            Assert.assertEquals(VehicleStateData.VIRTUAL_ID, value.f1);

            MapState<String, SnapshotWrapper> preferencesStateMap = getVehicleStateMap(testHarness);

            SnapshotWrapper snapshotWrapper = preferencesStateMap.get(VehicleStateData.VIRTUAL_ID);
            Assert.assertNotNull(snapshotWrapper);

            CommonSnapshot commonSnapshot = snapshotWrapper.getCommonSnapshot();
            Assert.assertNotNull(commonSnapshot);
            Assert.assertNotNull(commonSnapshot.getHarshBraking());
            Assert.assertEquals(1, commonSnapshot.getHarshBraking().getValue());

        } catch (Exception e) {
            throw new FlinkRuntimeException(e);
        }
    }

    @Test
    public void testVehicleSnapshotMapperFunction_multiAlertMovementFall() {
        try (KeyedOneInputStreamOperatorTestHarness<String, EnrichedSnapshot, Tuple3<String, String, SnapshotWrapper>> testHarness = testHarness()) {

            testHarness.setup();
            testHarness.open();

            Instant instant = Instant.now().minusSeconds(20);
            EnrichedSnapshot enrichedSnapshot = VehicleStateData.getEnrichedSnapshot(Tenant.EV, instant.toEpochMilli());

            List<String> alerts1 = new ArrayList<>();
            alerts1.add(MultiAlertSignals.MOVEMENT_ALERT_FALL_SIGNAL);
            SignalData signalData1 = new SignalData();
            signalData1.setDataType("VARCHAR");
            signalData1.setTime(instant.plusSeconds(10).toEpochMilli());
            signalData1.setValue(GsonUtils.toJson(alerts1));

            Set<SignalData> signalDataSet = new HashSet<>();
            signalDataSet.add(signalData1);

            enrichedSnapshot.setMultiAlertsData(signalDataSet);

            testHarness.processElement(new StreamRecord<>(enrichedSnapshot));

            List<Tuple3<String, String, SnapshotWrapper>> output = VehicleStateData.getOutput(testHarness.getRecordOutput());
            Assert.assertEquals(1, output.size());

            Tuple3<String, String, SnapshotWrapper> value = output.get(0);
            Assert.assertEquals(VehicleStateData.EV_SNAPSHOT_INDEX, value.f0);
            Assert.assertEquals(VehicleStateData.VIRTUAL_ID, value.f1);

            MapState<String, SnapshotWrapper> preferencesStateMap = getVehicleStateMap(testHarness);

            SnapshotWrapper snapshotWrapper = preferencesStateMap.get(VehicleStateData.VIRTUAL_ID);
            Assert.assertNotNull(snapshotWrapper);

            CommonSnapshot commonSnapshot = snapshotWrapper.getCommonSnapshot();
            Assert.assertNotNull(commonSnapshot);
            Assert.assertNotNull(commonSnapshot.getMovementDetection());
            Assert.assertEquals(0, commonSnapshot.getMovementDetection().getValue());

        } catch (Exception e) {
            throw new FlinkRuntimeException(e);
        }
    }

    @Test
    public void testVehicleSnapshotMapperFunction_multiAlertMovementRise() {
        try (KeyedOneInputStreamOperatorTestHarness<String, EnrichedSnapshot, Tuple3<String, String, SnapshotWrapper>> testHarness = testHarness()) {

            testHarness.setup();
            testHarness.open();

            Instant instant = Instant.now().minusSeconds(20);
            EnrichedSnapshot enrichedSnapshot = VehicleStateData.getEnrichedSnapshot(Tenant.EV, instant.toEpochMilli());

            List<String> alerts1 = new ArrayList<>();
            alerts1.add(MultiAlertSignals.MOVEMENT_ALERT_RISE_SIGNAL);
            SignalData signalData1 = new SignalData();
            signalData1.setDataType("VARCHAR");
            signalData1.setTime(instant.plusSeconds(10).toEpochMilli());
            signalData1.setValue(GsonUtils.toJson(alerts1));

            Set<SignalData> signalDataSet = new HashSet<>();
            signalDataSet.add(signalData1);

            enrichedSnapshot.setMultiAlertsData(signalDataSet);

            testHarness.processElement(new StreamRecord<>(enrichedSnapshot));

            List<Tuple3<String, String, SnapshotWrapper>> output = VehicleStateData.getOutput(testHarness.getRecordOutput());
            Assert.assertEquals(1, output.size());

            Tuple3<String, String, SnapshotWrapper> value = output.get(0);
            Assert.assertEquals(VehicleStateData.EV_SNAPSHOT_INDEX, value.f0);
            Assert.assertEquals(VehicleStateData.VIRTUAL_ID, value.f1);

            MapState<String, SnapshotWrapper> preferencesStateMap = getVehicleStateMap(testHarness);

            SnapshotWrapper snapshotWrapper = preferencesStateMap.get(VehicleStateData.VIRTUAL_ID);
            Assert.assertNotNull(snapshotWrapper);

            CommonSnapshot commonSnapshot = snapshotWrapper.getCommonSnapshot();
            Assert.assertNotNull(commonSnapshot);
            Assert.assertNotNull(commonSnapshot.getMovementDetection());
            Assert.assertEquals(1, commonSnapshot.getMovementDetection().getValue());

        } catch (Exception e) {
            throw new FlinkRuntimeException(e);
        }
    }

    @Test
    public void testVehicleSnapshotMapperFunction_multiAlertOverSpeedFall() {
        try (KeyedOneInputStreamOperatorTestHarness<String, EnrichedSnapshot, Tuple3<String, String, SnapshotWrapper>> testHarness = testHarness()) {

            testHarness.setup();
            testHarness.open();

            Instant instant = Instant.now().minusSeconds(20);
            EnrichedSnapshot enrichedSnapshot = VehicleStateData.getEnrichedSnapshot(Tenant.EV, instant.toEpochMilli());

            List<String> alerts1 = new ArrayList<>();
            alerts1.add(MultiAlertSignals.OVERSPEED_ALERT_FALL_SIGNAL);
            SignalData signalData1 = new SignalData();
            signalData1.setDataType("VARCHAR");
            signalData1.setTime(instant.plusSeconds(10).toEpochMilli());
            signalData1.setValue(GsonUtils.toJson(alerts1));

            Set<SignalData> signalDataSet = new HashSet<>();
            signalDataSet.add(signalData1);

            enrichedSnapshot.setMultiAlertsData(signalDataSet);

            testHarness.processElement(new StreamRecord<>(enrichedSnapshot));

            List<Tuple3<String, String, SnapshotWrapper>> output = VehicleStateData.getOutput(testHarness.getRecordOutput());
            Assert.assertEquals(1, output.size());

            Tuple3<String, String, SnapshotWrapper> value = output.get(0);
            Assert.assertEquals(VehicleStateData.EV_SNAPSHOT_INDEX, value.f0);
            Assert.assertEquals(VehicleStateData.VIRTUAL_ID, value.f1);

            MapState<String, SnapshotWrapper> preferencesStateMap = getVehicleStateMap(testHarness);

            SnapshotWrapper snapshotWrapper = preferencesStateMap.get(VehicleStateData.VIRTUAL_ID);
            Assert.assertNotNull(snapshotWrapper);

            CommonSnapshot commonSnapshot = snapshotWrapper.getCommonSnapshot();
            Assert.assertNotNull(commonSnapshot);
            Assert.assertNotNull(commonSnapshot.getOverSpeed());
            Assert.assertEquals(0, commonSnapshot.getOverSpeed().getValue());

        } catch (Exception e) {
            throw new FlinkRuntimeException(e);
        }
    }

    @Test
    public void testVehicleSnapshotMapperFunction_multiAlertOverSpeedRise() {
        try (KeyedOneInputStreamOperatorTestHarness<String, EnrichedSnapshot, Tuple3<String, String, SnapshotWrapper>> testHarness = testHarness()) {

            testHarness.setup();
            testHarness.open();

            Instant instant = Instant.now().minusSeconds(20);
            EnrichedSnapshot enrichedSnapshot = VehicleStateData.getEnrichedSnapshot(Tenant.EV, instant.toEpochMilli());

            List<String> alerts1 = new ArrayList<>();
            alerts1.add(MultiAlertSignals.OVERSPEED_ALERT_RISE_SIGNAL);
            SignalData signalData1 = new SignalData();
            signalData1.setDataType("VARCHAR");
            signalData1.setTime(instant.plusSeconds(10).toEpochMilli());
            signalData1.setValue(GsonUtils.toJson(alerts1));

            Set<SignalData> signalDataSet = new HashSet<>();
            signalDataSet.add(signalData1);

            enrichedSnapshot.setMultiAlertsData(signalDataSet);

            testHarness.processElement(new StreamRecord<>(enrichedSnapshot));

            List<Tuple3<String, String, SnapshotWrapper>> output = VehicleStateData.getOutput(testHarness.getRecordOutput());
            Assert.assertEquals(1, output.size());

            Tuple3<String, String, SnapshotWrapper> value = output.get(0);
            Assert.assertEquals(VehicleStateData.EV_SNAPSHOT_INDEX, value.f0);
            Assert.assertEquals(VehicleStateData.VIRTUAL_ID, value.f1);

            MapState<String, SnapshotWrapper> preferencesStateMap = getVehicleStateMap(testHarness);

            SnapshotWrapper snapshotWrapper = preferencesStateMap.get(VehicleStateData.VIRTUAL_ID);
            Assert.assertNotNull(snapshotWrapper);

            CommonSnapshot commonSnapshot = snapshotWrapper.getCommonSnapshot();
            Assert.assertNotNull(commonSnapshot);
            Assert.assertNotNull(commonSnapshot.getOverSpeed());
            Assert.assertEquals(1, commonSnapshot.getOverSpeed().getValue());

        } catch (Exception e) {
            throw new FlinkRuntimeException(e);
        }
    }

    @Test
    public void testVehicleSnapshotMapperFunction_multiAlertPanicFall() {
        try (KeyedOneInputStreamOperatorTestHarness<String, EnrichedSnapshot, Tuple3<String, String, SnapshotWrapper>> testHarness = testHarness()) {

            testHarness.setup();
            testHarness.open();

            Instant instant = Instant.now().minusSeconds(20);
            EnrichedSnapshot enrichedSnapshot = VehicleStateData.getEnrichedSnapshot(Tenant.EV, instant.toEpochMilli());

            List<String> alerts1 = new ArrayList<>();
            alerts1.add(MultiAlertSignals.PANIC_ALERT_FALL_SIGNAL);
            SignalData signalData1 = new SignalData();
            signalData1.setDataType("VARCHAR");
            signalData1.setTime(instant.plusSeconds(10).toEpochMilli());
            signalData1.setValue(GsonUtils.toJson(alerts1));

            Set<SignalData> signalDataSet = new HashSet<>();
            signalDataSet.add(signalData1);

            enrichedSnapshot.setMultiAlertsData(signalDataSet);

            testHarness.processElement(new StreamRecord<>(enrichedSnapshot));

            List<Tuple3<String, String, SnapshotWrapper>> output = VehicleStateData.getOutput(testHarness.getRecordOutput());
            Assert.assertEquals(1, output.size());

            Tuple3<String, String, SnapshotWrapper> value = output.get(0);
            Assert.assertEquals(VehicleStateData.EV_SNAPSHOT_INDEX, value.f0);
            Assert.assertEquals(VehicleStateData.VIRTUAL_ID, value.f1);

            MapState<String, SnapshotWrapper> preferencesStateMap = getVehicleStateMap(testHarness);

            SnapshotWrapper snapshotWrapper = preferencesStateMap.get(VehicleStateData.VIRTUAL_ID);
            Assert.assertNotNull(snapshotWrapper);

            CommonSnapshot commonSnapshot = snapshotWrapper.getCommonSnapshot();
            Assert.assertNotNull(commonSnapshot);
            Assert.assertNotNull(commonSnapshot.getPanic());
            Assert.assertEquals(0, commonSnapshot.getPanic().getValue());

        } catch (Exception e) {
            throw new FlinkRuntimeException(e);
        }
    }

    @Test
    public void testVehicleSnapshotMapperFunction_multiAlertPanicRise() {
        try (KeyedOneInputStreamOperatorTestHarness<String, EnrichedSnapshot, Tuple3<String, String, SnapshotWrapper>> testHarness = testHarness()) {

            testHarness.setup();
            testHarness.open();

            Instant instant = Instant.now().minusSeconds(20);
            EnrichedSnapshot enrichedSnapshot = VehicleStateData.getEnrichedSnapshot(Tenant.EV, instant.toEpochMilli());

            List<String> alerts1 = new ArrayList<>();
            alerts1.add(MultiAlertSignals.PANIC_ALERT_RISE_SIGNAL);
            SignalData signalData1 = new SignalData();
            signalData1.setDataType("VARCHAR");
            signalData1.setTime(instant.plusSeconds(10).toEpochMilli());
            signalData1.setValue(GsonUtils.toJson(alerts1));

            Set<SignalData> signalDataSet = new HashSet<>();
            signalDataSet.add(signalData1);

            enrichedSnapshot.setMultiAlertsData(signalDataSet);

            testHarness.processElement(new StreamRecord<>(enrichedSnapshot));

            List<Tuple3<String, String, SnapshotWrapper>> output = VehicleStateData.getOutput(testHarness.getRecordOutput());
            Assert.assertEquals(1, output.size());

            Tuple3<String, String, SnapshotWrapper> value = output.get(0);
            Assert.assertEquals(VehicleStateData.EV_SNAPSHOT_INDEX, value.f0);
            Assert.assertEquals(VehicleStateData.VIRTUAL_ID, value.f1);

            MapState<String, SnapshotWrapper> preferencesStateMap = getVehicleStateMap(testHarness);

            SnapshotWrapper snapshotWrapper = preferencesStateMap.get(VehicleStateData.VIRTUAL_ID);
            Assert.assertNotNull(snapshotWrapper);

            CommonSnapshot commonSnapshot = snapshotWrapper.getCommonSnapshot();
            Assert.assertNotNull(commonSnapshot);
            Assert.assertNotNull(commonSnapshot.getPanic());
            Assert.assertEquals(1, commonSnapshot.getPanic().getValue());

        } catch (Exception e) {
            throw new FlinkRuntimeException(e);
        }
    }

    @Test
    public void testVehicleSnapshotMapperFunction_multiAlertTowTheftFall() {
        try (KeyedOneInputStreamOperatorTestHarness<String, EnrichedSnapshot, Tuple3<String, String, SnapshotWrapper>> testHarness = testHarness()) {

            testHarness.setup();
            testHarness.open();

            Instant instant = Instant.now().minusSeconds(20);
            EnrichedSnapshot enrichedSnapshot = VehicleStateData.getEnrichedSnapshot(Tenant.EV, instant.toEpochMilli());

            List<String> alerts1 = new ArrayList<>();
            alerts1.add(MultiAlertSignals.TOW_THEFT_ALERT_FALL_SIGNAL);
            SignalData signalData1 = new SignalData();
            signalData1.setDataType("VARCHAR");
            signalData1.setTime(instant.plusSeconds(10).toEpochMilli());
            signalData1.setValue(GsonUtils.toJson(alerts1));

            Set<SignalData> signalDataSet = new HashSet<>();
            signalDataSet.add(signalData1);

            enrichedSnapshot.setMultiAlertsData(signalDataSet);

            testHarness.processElement(new StreamRecord<>(enrichedSnapshot));

            List<Tuple3<String, String, SnapshotWrapper>> output = VehicleStateData.getOutput(testHarness.getRecordOutput());
            Assert.assertEquals(1, output.size());

            Tuple3<String, String, SnapshotWrapper> value = output.get(0);
            Assert.assertEquals(VehicleStateData.EV_SNAPSHOT_INDEX, value.f0);
            Assert.assertEquals(VehicleStateData.VIRTUAL_ID, value.f1);

            MapState<String, SnapshotWrapper> preferencesStateMap = getVehicleStateMap(testHarness);

            SnapshotWrapper snapshotWrapper = preferencesStateMap.get(VehicleStateData.VIRTUAL_ID);
            Assert.assertNotNull(snapshotWrapper);

            CommonSnapshot commonSnapshot = snapshotWrapper.getCommonSnapshot();
            Assert.assertNotNull(commonSnapshot);
            Assert.assertNotNull(commonSnapshot.getTowOrTheft());
            Assert.assertEquals(0, commonSnapshot.getTowOrTheft().getValue());

        } catch (Exception e) {
            throw new FlinkRuntimeException(e);
        }
    }

    @Test
    public void testVehicleSnapshotMapperFunction_multiAlertTowTheftRise() {
        try (KeyedOneInputStreamOperatorTestHarness<String, EnrichedSnapshot, Tuple3<String, String, SnapshotWrapper>> testHarness = testHarness()) {

            testHarness.setup();
            testHarness.open();

            Instant instant = Instant.now().minusSeconds(20);
            EnrichedSnapshot enrichedSnapshot = VehicleStateData.getEnrichedSnapshot(Tenant.EV, instant.toEpochMilli());

            List<String> alerts1 = new ArrayList<>();
            alerts1.add(MultiAlertSignals.TOW_THEFT_ALERT_RISE_SIGNAL);
            SignalData signalData1 = new SignalData();
            signalData1.setDataType("VARCHAR");
            signalData1.setTime(instant.plusSeconds(10).toEpochMilli());
            signalData1.setValue(GsonUtils.toJson(alerts1));

            Set<SignalData> signalDataSet = new HashSet<>();
            signalDataSet.add(signalData1);

            enrichedSnapshot.setMultiAlertsData(signalDataSet);

            testHarness.processElement(new StreamRecord<>(enrichedSnapshot));

            List<Tuple3<String, String, SnapshotWrapper>> output = VehicleStateData.getOutput(testHarness.getRecordOutput());
            Assert.assertEquals(1, output.size());

            Tuple3<String, String, SnapshotWrapper> value = output.get(0);
            Assert.assertEquals(VehicleStateData.EV_SNAPSHOT_INDEX, value.f0);
            Assert.assertEquals(VehicleStateData.VIRTUAL_ID, value.f1);

            MapState<String, SnapshotWrapper> preferencesStateMap = getVehicleStateMap(testHarness);

            SnapshotWrapper snapshotWrapper = preferencesStateMap.get(VehicleStateData.VIRTUAL_ID);
            Assert.assertNotNull(snapshotWrapper);

            CommonSnapshot commonSnapshot = snapshotWrapper.getCommonSnapshot();
            Assert.assertNotNull(commonSnapshot);
            Assert.assertNotNull(commonSnapshot.getTowOrTheft());
            Assert.assertEquals(1, commonSnapshot.getTowOrTheft().getValue());

        } catch (Exception e) {
            throw new FlinkRuntimeException(e);
        }
    }

    @Test
    public void testVehicleSnapshotMapperFunction_multiAlertRandom() {
        try (KeyedOneInputStreamOperatorTestHarness<String, EnrichedSnapshot, Tuple3<String, String, SnapshotWrapper>> testHarness = testHarness()) {

            testHarness.setup();
            testHarness.open();

            Instant instant = Instant.now().minusSeconds(20);
            EnrichedSnapshot enrichedSnapshot = VehicleStateData.getEnrichedSnapshot(Tenant.EV, instant.toEpochMilli());

            List<String> alerts1 = new ArrayList<>();
            alerts1.add(MultiAlertSignals.ACCIDENT_CRASH_ALERT_FALL_SIGNAL);
            alerts1.add(MultiAlertSignals.TOW_THEFT_ALERT_RISE_SIGNAL);
            alerts1.add(MultiAlertSignals.MOVEMENT_ALERT_RISE_SIGNAL);
            alerts1.add(MultiAlertSignals.TOW_THEFT_ALERT_RISE_SIGNAL);
            SignalData signalData1 = new SignalData();
            signalData1.setDataType("VARCHAR");
            signalData1.setTime(instant.plusSeconds(10).toEpochMilli());
            signalData1.setValue(GsonUtils.toJson(alerts1));

            Set<SignalData> signalDataSet = new HashSet<>();
            signalDataSet.add(signalData1);

            enrichedSnapshot.setMultiAlertsData(signalDataSet);

            testHarness.processElement(new StreamRecord<>(enrichedSnapshot));

            List<Tuple3<String, String, SnapshotWrapper>> output = VehicleStateData.getOutput(testHarness.getRecordOutput());
            Assert.assertEquals(1, output.size());

            Tuple3<String, String, SnapshotWrapper> value = output.get(0);
            Assert.assertEquals(VehicleStateData.EV_SNAPSHOT_INDEX, value.f0);
            Assert.assertEquals(VehicleStateData.VIRTUAL_ID, value.f1);

            MapState<String, SnapshotWrapper> preferencesStateMap = getVehicleStateMap(testHarness);

            SnapshotWrapper snapshotWrapper = preferencesStateMap.get(VehicleStateData.VIRTUAL_ID);
            Assert.assertNotNull(snapshotWrapper);

            CommonSnapshot commonSnapshot = snapshotWrapper.getCommonSnapshot();
            Assert.assertNotNull(commonSnapshot);

            Assert.assertNotNull(commonSnapshot.getCrashAndAccident());
            Assert.assertEquals(0, commonSnapshot.getCrashAndAccident().getValue());

            Assert.assertNotNull(commonSnapshot.getTowOrTheft());
            Assert.assertEquals(1, commonSnapshot.getTowOrTheft().getValue());

            Assert.assertNotNull(commonSnapshot.getMovementDetection());
            Assert.assertEquals(1, commonSnapshot.getMovementDetection().getValue());

        } catch (Exception e) {
            throw new FlinkRuntimeException(e);
        }
    }

}
