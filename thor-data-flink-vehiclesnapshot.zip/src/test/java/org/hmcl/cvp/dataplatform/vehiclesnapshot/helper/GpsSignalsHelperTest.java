package org.hmcl.cvp.dataplatform.vehiclesnapshot.helper;

import org.hmcl.cvp.dataplatform.vehiclesnapshot.contract.LatestValue;
import org.hmcl.cvp.dataplatform.vehiclesnapshot.contract.SignalSnapshot;
import org.hmcl.cvp.dataplatform.vehiclesnapshot.utils.VehicleStateData;
import org.junit.Assert;
import org.junit.Test;

public class GpsSignalsHelperTest {

    @Test
    public void testGpsFix_latestValueNull() {
        LatestValue gpsFix = LatestValue.builder().build();
        Assert.assertFalse(GpsSignalsHelper.isGpsFixSignalValid(VehicleStateData.VIRTUAL_ID, gpsFix));
    }

    @Test
    public void testGpsFix_invalid() {
        LatestValue gpsFix0 = LatestValue.builder()
                .signalSnapshot(SignalSnapshot.builder()
                        .value(0)
                        .build())
                .build();
        Assert.assertFalse(GpsSignalsHelper.isGpsFixSignalValid(VehicleStateData.VIRTUAL_ID, gpsFix0));

        LatestValue gpsFix1 = LatestValue.builder()
                .signalSnapshot(SignalSnapshot.builder()
                        .value(1)
                        .build())
                .build();
        Assert.assertFalse(GpsSignalsHelper.isGpsFixSignalValid(VehicleStateData.VIRTUAL_ID, gpsFix1));
    }

    @Test
    public void testGpsFix_valid() {
        LatestValue gpsFix2 = LatestValue.builder()
                .signalSnapshot(SignalSnapshot.builder()
                        .value(2)
                        .build())
                .build();
        Assert.assertTrue(GpsSignalsHelper.isGpsFixSignalValid(VehicleStateData.VIRTUAL_ID, gpsFix2));

        LatestValue gpsFix3 = LatestValue.builder()
                .signalSnapshot(SignalSnapshot.builder()
                        .value(3)
                        .build())
                .build();
        Assert.assertTrue(GpsSignalsHelper.isGpsFixSignalValid(VehicleStateData.VIRTUAL_ID, gpsFix3));
    }

    @Test
    public void testHDop_latestValueNull() {
        LatestValue hDop = LatestValue.builder().build();
        Assert.assertFalse(GpsSignalsHelper.isHDopSignalValid(VehicleStateData.VIRTUAL_ID, hDop, 0));
    }

    @Test
    public void testHDop_valueLessThanThreshold() {
        LatestValue hDop = LatestValue.builder()
                .signalSnapshot(SignalSnapshot.builder()
                        .value(2.0)
                        .build())
                .build();
        Assert.assertTrue(GpsSignalsHelper.isHDopSignalValid(VehicleStateData.VIRTUAL_ID, hDop, 3.0));
    }

    @Test
    public void testHDop_valueEqualToThreshold() {
        LatestValue hDop = LatestValue.builder()
                .signalSnapshot(SignalSnapshot.builder()
                        .value(2.0)
                        .build())
                .build();
        Assert.assertTrue(GpsSignalsHelper.isHDopSignalValid(VehicleStateData.VIRTUAL_ID, hDop, 2.0));
    }

    @Test
    public void testHDop_valueGreaterThanThreshold() {
        LatestValue hDop = LatestValue.builder()
                .signalSnapshot(SignalSnapshot.builder()
                        .value(3.1)
                        .build())
                .build();
        Assert.assertFalse(GpsSignalsHelper.isHDopSignalValid(VehicleStateData.VIRTUAL_ID, hDop, 3.0));
    }

    @Test
    public void testGpsValid_latestValueNull() {
        LatestValue gpsValid = LatestValue.builder().build();
        Assert.assertFalse(GpsSignalsHelper.isGpsValidSignalValid(VehicleStateData.VIRTUAL_ID, gpsValid));
    }

    @Test
    public void testGpsValid_false() {
        LatestValue gpsValid = LatestValue.builder()
                .signalSnapshot(SignalSnapshot.builder()
                        .value(false)
                        .build())
                .build();
        Assert.assertFalse(GpsSignalsHelper.isGpsValidSignalValid(VehicleStateData.VIRTUAL_ID, gpsValid));
    }

    @Test
    public void testGpsValid_true() {
        LatestValue gpsValid = LatestValue.builder()
                .signalSnapshot(SignalSnapshot.builder()
                        .value(true)
                        .build())
                .build();
        Assert.assertTrue(GpsSignalsHelper.isGpsValidSignalValid(VehicleStateData.VIRTUAL_ID, gpsValid));
    }

}
