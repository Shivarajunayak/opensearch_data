package org.hmcl.cvp.dataplatform.vehiclesnapshot.contract;

import org.apache.flink.types.PojoTestUtils;
import org.junit.Test;

public class ContractTest {

    @Test
    public void testSignalSnapshot() {
        PojoTestUtils.assertSerializedAsPojo(SignalSnapshot.class);
    }

    @Test
    public void testCommonSnapshot() {
        PojoTestUtils.assertSerializedAsPojo(CommonSnapshot.class);
    }

    @Test
    public void testEvSnapshot() {
        PojoTestUtils.assertSerializedAsPojo(EvSnapshot.class);
    }

    @Test
    public void testIceSnapshot() {
        PojoTestUtils.assertSerializedAsPojo(IceSnapshot.class);
    }

    @Test
    public void testSnapshotWrapper() {
        PojoTestUtils.assertSerializedAsPojo(SnapshotWrapper.class);
    }

}
