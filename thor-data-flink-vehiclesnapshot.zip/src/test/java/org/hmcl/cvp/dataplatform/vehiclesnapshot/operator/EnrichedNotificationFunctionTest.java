package org.hmcl.cvp.dataplatform.vehiclesnapshot.operator;

import org.apache.flink.runtime.jobgraph.OperatorID;
import org.apache.flink.runtime.metrics.groups.InternalOperatorMetricGroup;
import org.apache.flink.runtime.metrics.util.InterceptingOperatorMetricGroup;
import org.apache.flink.runtime.metrics.util.InterceptingTaskMetricGroup;
import org.apache.flink.runtime.operators.testutils.MockEnvironment;
import org.apache.flink.runtime.operators.testutils.MockEnvironmentBuilder;
import org.apache.flink.runtime.testutils.MiniClusterResourceConfiguration;
import org.apache.flink.streaming.api.operators.StreamFlatMap;
import org.apache.flink.streaming.runtime.streamrecord.StreamRecord;
import org.apache.flink.streaming.util.OneInputStreamOperatorTestHarness;
import org.apache.flink.test.util.MiniClusterWithClientResource;
import org.hmcl.cvp.dataplatform.contract.notification.AlertDetails;
import org.hmcl.cvp.dataplatform.contract.notification.GeoFenceType;
import org.hmcl.cvp.dataplatform.contract.notification.Notification;
import org.hmcl.cvp.dataplatform.contract.telemetry.Tenant;
import org.hmcl.cvp.dataplatform.vehiclesnapshot.contract.EnrichedSnapshot;
import org.hmcl.cvp.dataplatform.vehiclesnapshot.utils.VehicleStateData;
import org.junit.Assert;
import org.junit.ClassRule;
import org.junit.Test;

import java.time.Instant;
import java.util.List;

public class EnrichedNotificationFunctionTest {

    @ClassRule
    public static MiniClusterWithClientResource flinkCluster =
            new MiniClusterWithClientResource(
                    new MiniClusterResourceConfiguration.Builder()
                            .setNumberSlotsPerTaskManager(2)
                            .setNumberTaskManagers(1)
                            .build());

    private final InterceptingOperatorMetricGroup interceptingOperatorMetricGroup = new InterceptingOperatorMetricGroup();
    private final InterceptingTaskMetricGroup interceptingTaskMetricGroup = new InterceptingTaskMetricGroup() {
        @Override
        public InternalOperatorMetricGroup getOrAddOperator(OperatorID operatorID, String name) {
            return interceptingOperatorMetricGroup;
        }
    };

    private final MockEnvironment mockEnvironment = new MockEnvironmentBuilder().setMetricGroup(interceptingTaskMetricGroup).build();

    private final EnrichedNotificationFunction enrichedNotificationFunction = new EnrichedNotificationFunction();

    private OneInputStreamOperatorTestHarness<String, EnrichedSnapshot> testHarness() throws Exception {
        return new OneInputStreamOperatorTestHarness<>(new StreamFlatMap<>(enrichedNotificationFunction), mockEnvironment);
    }

    @Test
    public void testEnrichedNotificationFunction_evEntry() {
        testMapperFunction(Tenant.EV, GeoFenceType.ENTRY, Instant.now());
    }

    @Test
    public void testEnrichedNotificationFunction_iceEntry() {
        testMapperFunction(Tenant.ICE, GeoFenceType.ENTRY, Instant.now());
    }

    @Test
    public void testEnrichedNotificationFunction_harleyEntry() {
        testMapperFunction(Tenant.HARLEY, GeoFenceType.ENTRY, Instant.now());
    }

    @Test
    public void testEnrichedNotificationFunction_evExit() {
        testMapperFunction(Tenant.EV, GeoFenceType.EXIT, Instant.now());
    }

    @Test
    public void testEnrichedNotificationFunction_iceExit() {
        testMapperFunction(Tenant.ICE, GeoFenceType.EXIT, Instant.now());
    }

    @Test
    public void testEnrichedNotificationFunction_harleyExit() {
        testMapperFunction(Tenant.HARLEY, GeoFenceType.EXIT, Instant.now());
    }

    private void testMapperFunction(Tenant tenant, GeoFenceType geoFenceType, Instant instant) {
        try(OneInputStreamOperatorTestHarness<String, EnrichedSnapshot> testHarness = testHarness()) {

            testHarness.setup();
            testHarness.open();

            String notification = VehicleStateData.getNotificationString(tenant, geoFenceType, instant);
            testHarness.processElement(new StreamRecord<>(notification));

            List<EnrichedSnapshot> output = VehicleStateData.getOutput(testHarness.getRecordOutput());
            Assert.assertNotNull(output);
            Assert.assertEquals(1, output.size());

        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    @Test
    public void testEnrichedNotificationFunction_assertDetailsNotPresent() {
        try(OneInputStreamOperatorTestHarness<String, EnrichedSnapshot> testHarness = testHarness()) {

            testHarness.setup();
            testHarness.open();

            Notification notification = VehicleStateData.getNotificationData(Tenant.EV, GeoFenceType.ENTRY, Instant.now());
            notification.setAlertDetails(null);
            String input = VehicleStateData.toJson(notification);
            testHarness.processElement(new StreamRecord<>(input));

            List<EnrichedSnapshot> output = VehicleStateData.getOutput(testHarness.getRecordOutput());
            Assert.assertEquals(0, output.size());

        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    @Test
    public void testEnrichedNotificationFunction_geoFenceTypeNotPresent() {
        try(OneInputStreamOperatorTestHarness<String, EnrichedSnapshot> testHarness = testHarness()) {

            testHarness.setup();
            testHarness.open();

            Notification notification = VehicleStateData.getNotificationData(Tenant.EV, GeoFenceType.ENTRY, Instant.now());
            AlertDetails alertDetails = notification.getAlertDetails();
            alertDetails.setBoundaryCondition(null);
            notification.setAlertDetails(alertDetails);

            String input = VehicleStateData.toJson(notification);
            testHarness.processElement(new StreamRecord<>(input));

            List<EnrichedSnapshot> output = VehicleStateData.getOutput(testHarness.getRecordOutput());
            Assert.assertEquals(0, output.size());

        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    @Test
    public void testEnrichedNotificationFunction_notAGeoFenceAlert() {
        try(OneInputStreamOperatorTestHarness<String, EnrichedSnapshot> testHarness = testHarness()) {

            testHarness.setup();
            testHarness.open();

            Notification notification = VehicleStateData.getNotificationData(Tenant.EV, GeoFenceType.ENTRY, Instant.now());
            notification.setGeofenceId("");

            String input = VehicleStateData.toJson(notification);
            testHarness.processElement(new StreamRecord<>(input));

            List<EnrichedSnapshot> output = VehicleStateData.getOutput(testHarness.getRecordOutput());
            Assert.assertEquals(0, output.size());

        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

}
