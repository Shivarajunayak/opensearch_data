package org.hmcl.cvp.dataplatform.vehiclesnapshot.operator;

import org.apache.flink.api.java.tuple.Tuple3;
import org.apache.flink.runtime.jobgraph.OperatorID;
import org.apache.flink.runtime.metrics.groups.InternalOperatorMetricGroup;
import org.apache.flink.runtime.metrics.util.InterceptingOperatorMetricGroup;
import org.apache.flink.runtime.metrics.util.InterceptingTaskMetricGroup;
import org.apache.flink.runtime.operators.testutils.MockEnvironment;
import org.apache.flink.runtime.operators.testutils.MockEnvironmentBuilder;
import org.apache.flink.runtime.testutils.MiniClusterResourceConfiguration;
import org.apache.flink.streaming.api.operators.StreamFlatMap;
import org.apache.flink.streaming.runtime.streamrecord.StreamRecord;
import org.apache.flink.streaming.util.OneInputStreamOperatorTestHarness;
import org.apache.flink.test.util.MiniClusterWithClientResource;
import org.hmcl.cvp.dataplatform.commons.exception.FlinkRuntimeException;
import org.hmcl.cvp.dataplatform.contract.telemetry.Tenant;
import org.hmcl.cvp.dataplatform.vehiclesnapshot.contract.SnapshotWrapper;
import org.hmcl.cvp.dataplatform.vehiclesnapshot.utils.VehicleStateData;
import org.junit.Assert;
import org.junit.ClassRule;
import org.junit.Test;

import java.util.List;

public class SnapshotWrapperKafkaFlatMapFunctionTest {

    @ClassRule
    public static MiniClusterWithClientResource flinkCluster =
            new MiniClusterWithClientResource(
                    new MiniClusterResourceConfiguration.Builder()
                            .setNumberSlotsPerTaskManager(2)
                            .setNumberTaskManagers(1)
                            .build());

    private final InterceptingOperatorMetricGroup interceptingOperatorMetricGroup = new InterceptingOperatorMetricGroup();
    private final InterceptingTaskMetricGroup interceptingTaskMetricGroup = new InterceptingTaskMetricGroup() {
        @Override
        public InternalOperatorMetricGroup getOrAddOperator(OperatorID operatorID, String name) {
            return interceptingOperatorMetricGroup;
        }
    };

    private final MockEnvironment mockEnvironment = new MockEnvironmentBuilder().setMetricGroup(interceptingTaskMetricGroup).build();

    private final SnapshotWrapperKafkaFlatMapFunction mapFunction = new SnapshotWrapperKafkaFlatMapFunction();

    private OneInputStreamOperatorTestHarness<Tuple3<String, String, SnapshotWrapper>, String> testHarness() throws Exception {
        return new OneInputStreamOperatorTestHarness<>(new StreamFlatMap<>(mapFunction), mockEnvironment);
    }

    @Test
    public void testSnapshotWrapperKafkaFlatMapFunction_ev() {
        testMapperFunction(Tenant.EV);
    }

    @Test
    public void testSnapshotWrapperKafkaFlatMapFunction_ice() {
        testMapperFunction(Tenant.ICE);
    }

    @Test
    public void testSnapshotWrapperKafkaFlatMapFunction_harley() {
        testMapperFunction(Tenant.HARLEY);
    }

    private void testMapperFunction(Tenant tenant) {
        try (OneInputStreamOperatorTestHarness<Tuple3<String, String, SnapshotWrapper>, String> testHarness = testHarness()) {

            testHarness.setup();
            testHarness.open();

            SnapshotWrapper snapshotWrapper = VehicleStateData.getSnapShotWrapper(tenant);
            String index = getIndex(tenant);
            String vid = VehicleStateData.VIRTUAL_ID;
            Tuple3<String, String, SnapshotWrapper> tuple = new Tuple3<>(index, vid, snapshotWrapper);

            testHarness.processElement(new StreamRecord<>(tuple));

            List<String> output = VehicleStateData.getOutput(testHarness.getRecordOutput());
            Assert.assertNotNull(output);
            Assert.assertEquals(1, output.size());

        } catch (Exception e) {
            throw new FlinkRuntimeException(e);
        }
    }

    private String getIndex(Tenant tenant) {
        switch (tenant) {
            case ICE:
                return VehicleStateData.ICE_SNAPSHOT_INDEX;
            case HARLEY:
                return VehicleStateData.HARLEY_SNAPSHOT_INDEX;
            default:
                return VehicleStateData.EV_SNAPSHOT_INDEX;
        }
    }


}

