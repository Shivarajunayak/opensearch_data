package org.hmcl.cvp.dataplatform.vehiclesnapshot.job;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.salesforce.kafka.test.KafkaTestCluster;
import com.salesforce.kafka.test.KafkaTestUtils;
import lombok.extern.slf4j.Slf4j;
import org.apache.flink.runtime.testutils.MiniClusterResourceConfiguration;
import org.apache.flink.test.util.MiniClusterWithClientResource;
import org.apache.http.HttpEntity;
import org.apache.http.HttpHost;
import org.apache.http.util.EntityUtils;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.apache.kafka.clients.producer.KafkaProducer;
import org.apache.kafka.clients.producer.Producer;
import org.apache.kafka.clients.producer.ProducerConfig;
import org.apache.kafka.clients.producer.ProducerRecord;
import org.apache.kafka.common.serialization.StringDeserializer;
import org.hmcl.cvp.dataplatform.contract.notification.GeoFenceType;
import org.hmcl.cvp.dataplatform.contract.telemetry.Tenant;
import org.hmcl.cvp.dataplatform.vehiclesnapshot.utils.VehicleStateData;
import org.junit.*;
import org.opensearch.client.Request;
import org.opensearch.client.Response;
import org.opensearch.client.RestClient;
import org.opensearch.testcontainers.OpensearchContainer;
import org.testcontainers.shaded.org.awaitility.Awaitility;
import org.testcontainers.utility.DockerImageName;

import java.io.IOException;
import java.time.Duration;
import java.time.Instant;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

@Slf4j
public class VehicleSnapshotNotificationEvFlinkJobTest {

    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static final DockerImageName OPEN_SEARCH_IMAGE = DockerImageName.parse("opensearchproject/opensearch:2.13.0");

    private static final OpensearchContainer<?> CONTAINER = new OpensearchContainer<>(OPEN_SEARCH_IMAGE);

    private static final String TELEMETRY_INPUT_TOPIC = "hmcl-thor-rfw-telemetry-per-mstr-v1-k2";
    private static final String GEO_INPUT_TOPIC = "hmcl-thor-rfw-geofence-cond-mstr-v1-k2";
    private static final String LKS_INPUT_TOPIC = "hmcl-thor-rfw-fetchapi-lks-mstr-v1-k2";
    private static final String CHARGING_INPUT_TOPIC = "hmcl-thor-rfw-charging-analytics";
    private static final String MULTI_ALERTS_TOPIC = "hmcl-thor-rfw-multi-alert-cond-mstr-v1-k2";
    private static final String SNAPSHOT_OUTPUT_TOPIC = "hmcl-thor-vehicle-state-management";
    private static final String PRIORITY_OUTPUT_TOPIC = "hmcl-thor-priority-alert-topic";

    @ClassRule
    public static MiniClusterWithClientResource flinkCluster =
            new MiniClusterWithClientResource(
                    new MiniClusterResourceConfiguration.Builder()
                            .setNumberSlotsPerTaskManager(2)
                            .setNumberTaskManagers(1)
                            .build());
    private static KafkaTestUtils utils;
    private static KafkaTestCluster cluster;

    @BeforeClass
    public static void startKafkaCluster() throws Throwable {
        // Setup InMemory  Kafka Cluster
        cluster = new KafkaTestCluster(1);
        cluster.start();
        utils = new KafkaTestUtils(cluster);

        utils.createTopic(TELEMETRY_INPUT_TOPIC, 1, (short) 1);
        utils.createTopic(GEO_INPUT_TOPIC, 1, (short) 1);
        utils.createTopic(LKS_INPUT_TOPIC, 1, (short) 1);
        utils.createTopic(CHARGING_INPUT_TOPIC, 1, (short) 1);
        utils.createTopic(MULTI_ALERTS_TOPIC, 1, (short) 1);
        utils.createTopic(SNAPSHOT_OUTPUT_TOPIC, 1, (short) 1);
        utils.createTopic(PRIORITY_OUTPUT_TOPIC, 1, (short) 1);
    }

    @BeforeClass
    public static void startOpenSearch() {
        // https://stackoverflow.com/questions/61108655/test-container-test-cases-are-failing-due-to-could-not-find-a-valid-docker-envi
        CONTAINER.start();
    }

    @AfterClass
    public static void stopKafkaCluster() throws Exception {
        cluster.close();
    }

    @AfterClass
    public static void closeOpenSearch() {
        log.info("Closing OpenSearch container");
        CONTAINER.stop();
    }

    private static void produceData(List<String> telemetryList) {
        Producer<String, String> producer = getProducer();
        log.info("Producing events");
        telemetryList.forEach(v -> {
            ProducerRecord<String, String> data = new ProducerRecord<>(PRIORITY_OUTPUT_TOPIC, v);
            producer.send(data);
        });

        producer.flush();
        producer.close();
    }

    private static Producer<String, String> getProducer() {
        Properties props = new Properties();

        props.put(ProducerConfig.BOOTSTRAP_SERVERS_CONFIG, cluster.getKafkaConnectString());
        props.put("security.protocol", "PLAINTEXT");
        props.put(ProducerConfig.ACKS_CONFIG, "all");
        props.put(ProducerConfig.RETRIES_CONFIG, 2);
        props.put(ProducerConfig.LINGER_MS_CONFIG, 2);
        props.put(ProducerConfig.KEY_SERIALIZER_CLASS_CONFIG, "org.apache.kafka.common.serialization.StringSerializer");
        props.put(ProducerConfig.VALUE_SERIALIZER_CLASS_CONFIG, "org.apache.kafka.common.serialization.StringSerializer");

        return new KafkaProducer<>(props);
    }

    private static String[] getSystemArgs() {
        return new String[]{
                // SET ONLY WHILE RUNNING TEST - DEFAULT VALUE FALSE
                "--is.run.test.case", "TRUE",
                "--is.file.sink", "TRUE",
                "--aws.region", "ap-south-1",
                "--max.out.of.order.in.sec", "31",
                "--idle.timeout.in.sec", "5",
                "--window.duration", "30",
                "--can.speed.in.km.per.hr", "5.0",
                "--rpm.threshold.value", "1100.0",
                "--hdop.value.should.be.less.than", "3.0",
                "--need.snapshot.insert.index", "TRUE",

                // KAFKA Geo Campaign PROPERTY
                "--kafka.campaign.bootstrap.brokers", cluster.getKafkaConnectString(),
                "--kafka.telemetry.campaign.input.topic", TELEMETRY_INPUT_TOPIC,
                "--kafka.geofence.campaign.input.topic", GEO_INPUT_TOPIC,
                "--kafka.charging.campaign.input.topic", CHARGING_INPUT_TOPIC,
                "--kafka.edge.multi.alerts.campaign.input.topic", MULTI_ALERTS_TOPIC,
                "--kafka.campaign.group.id", "VehicleSnapshotGroup",
                "--kafka.campaign.role.arn", "XXXXX",
                "--kafka.campaign.session.name", "VehicleSnapshotSession",

                "--kafka.lks.bootstrap.brokers", cluster.getKafkaConnectString(),
                "--kafka.lks.group.id", "VehicleSnapshotLKSGroup",
                "--kafka.lks.role.arn", "XXXX",
                "--kafka.lks.session.name", "VehicleSnapshotLKSSession",
                "--kafka.lsk.fetchapi.json.topic", LKS_INPUT_TOPIC,

                // OpenSearch PROPERTY - ONLY USED FOR TEST CASES
                "--opensearch.hostAddress", CONTAINER.getHttpHostAddress(),
                "--opensearch.username", CONTAINER.getUsername(),
                "--opensearch.password", CONTAINER.getPassword(),
                "--opensearch.max.retries", "3",
                "--opensearch.retry.delay.in.ms", "1000",
                "--opensearch.max.actions.to.buffer", "1",
                "--opensearch.bulk.flush.size.mb", "-1",
                "--opensearch.bulk.flush.interval.milli", "-1",

                "--snapshot.index.ev", VehicleStateData.EV_SNAPSHOT_INDEX,
                "--snapshot.index.ice", VehicleStateData.ICE_SNAPSHOT_INDEX,
                "--snapshot.index.harley", VehicleStateData.HARLEY_SNAPSHOT_INDEX,

                "--kafka.snapshot.bootstrap.brokers", cluster.getKafkaConnectString(),
                "--kafka.snapshot.group.id", "VehicleSnapshotGroup",
                "--kafka.snapshot.role.arn", "XXXX",
                "--kafka.snapshot.session.name", "VehicleSnapshotSession",
                "--kafka.snapshot.topic", SNAPSHOT_OUTPUT_TOPIC,

                // KAFKA Notification
                "--kafka.notification.bootstrap.brokers", cluster.getKafkaConnectString(),
                "--kafka.notification.priority.topic", PRIORITY_OUTPUT_TOPIC,
                "--kafka.notification.group.id", "VehicleSnapshotNotificationGroup",
                "--kafka.notification.role.arn", "XXXXX",
                "--kafka.notification.session.name", "VehicleSnapshotNotificationSession"
        };
    }

    private int getNumberOfRecordsInOpenSearch(String index) {

        String endpoint = String.format("/%s/_search", index);
        log.info("OpenSearch endpoint: {}", endpoint);

        RestClient client = RestClient
                .builder(HttpHost.create(CONTAINER.getHttpHostAddress()))
                .build();

        try (client) {
            Request request = new Request("GET", endpoint);
            Response response = client.performRequest(request);
            HttpEntity entity = response.getEntity();

            String responseString = EntityUtils.toString(entity);
            log.info("Repeatable: {}, Content Type: {}, Content: {}", entity.isRepeatable(), entity.getContentType(), responseString);

            JsonElement je = GSON.fromJson(responseString, JsonElement.class);
            JsonObject jo = je.getAsJsonObject();

            JsonObject totalHits = jo.getAsJsonObject("hits").getAsJsonObject("total");
            int numHits = totalHits.get("value").getAsInt();
            log.info("Number of records: {}", numHits);
            return numHits;

        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    @Test
    public void testOpenSearchSink() {

        Instant entryTime = Instant.now().minusSeconds(5 * 60);
        Instant exitTime = entryTime.plusSeconds(2 * 60);

        String entry = VehicleStateData.getNotificationString(Tenant.EV, GeoFenceType.ENTRY, entryTime);
        String exit = VehicleStateData.getNotificationString(Tenant.EV, GeoFenceType.EXIT, exitTime);

        List<String> entryData = new ArrayList<>();
        entryData.add(entry);

        List<String> exitData = new ArrayList<>();
        exitData.add(exit);

        produceData(entryData);

        Awaitility.await()
                .timeout(Duration.ofSeconds(15))
                .pollDelay(Duration.ofSeconds(10))
                .untilAsserted(() -> Assert.assertTrue(true));

        produceData(exitData);

        try {

            Thread startFlinkJob = new Thread(() -> {
                try {
                    log.info("Flink job started");
                    VehicleSnapshotFlink.main(getSystemArgs());
                } catch (Exception e) {
                    throw new RuntimeException(e);
                }
            });
            startFlinkJob.start();
            // Interrupt the thread after 60 seconds
            startFlinkJob.join(Duration.ofSeconds(2 * 60).toMillis());
            log.info("Flink job completed");

            int numOfEvHits = getNumberOfRecordsInOpenSearch(VehicleStateData.EV_SNAPSHOT_INDEX);
            Assert.assertEquals(1, numOfEvHits);

            long numOfOutput = getKafkaEvents();
            Assert.assertEquals(2, numOfOutput);

            int numOfHits = getNumberOfRecordsInOpenSearch(VehicleStateData.TEMP_INDEX);
            Assert.assertEquals(2, numOfHits);


        } catch (Exception e) {
            log.error("Exception occurred while launching Flink opensearch consumer");
            throw new RuntimeException(e);
        }
    }

    private Long getKafkaEvents() {
        List<ConsumerRecord<String, String>> consumerRecords = utils.consumeAllRecordsFromTopic(
                SNAPSHOT_OUTPUT_TOPIC,
                StringDeserializer.class,
                StringDeserializer.class
        );

        for (ConsumerRecord<String, String> consumerRecord : consumerRecords) {
            log.info("{}", consumerRecord);
        }
        int count = consumerRecords.size();
        log.info("Number of records in {}: {}", SNAPSHOT_OUTPUT_TOPIC, count);

        return (long) count;
    }

}
