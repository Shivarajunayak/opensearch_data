package org.hmcl.cvp.dataplatform.vehiclesnapshot.helper;

import org.hmcl.cvp.dataplatform.commons.catalogue.SignalCatalogue;
import org.hmcl.cvp.dataplatform.commons.testdata.CampaignDataGenerator;
import org.hmcl.cvp.dataplatform.commons.testdata.SignalGenerator;
import org.hmcl.cvp.dataplatform.contract.telemetry.SignalData;
import org.hmcl.cvp.dataplatform.contract.telemetry.SignalInfo;
import org.hmcl.cvp.dataplatform.contract.telemetry.Telemetry;
import org.hmcl.cvp.dataplatform.vehiclesnapshot.contract.ChargingState;
import org.hmcl.cvp.dataplatform.vehiclesnapshot.contract.StateInfo;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.Parameterized;

import java.time.Instant;
import java.util.Arrays;
import java.util.Collection;
import java.util.Map;
import java.util.Set;

@RunWith(Parameterized.class)
public class VehicleSnapshotHelperChargingTest {

    @Parameterized.Parameters(name = "{index}: signal={0}, value={1}")
    public static Collection<Object[]> notChargingSignalData() {
        return Arrays.asList(new Object[][]{
                {SignalCatalogue.getBMSBDUConnectionRequestInfo(), 3.0},
                {SignalCatalogue.getChargerStateInfo(), 3.0},
                {SignalCatalogue.getChargerPowerStateInfo(), 3.0}
        });
    }

    @Parameterized.Parameter(0)
    public SignalInfo signalInfo;

    @Parameterized.Parameter(1)
    public double notChargingValue;

    @Test
    public void testVehicleSnapshotHelper_getChargingState_notChargingDueToSignal() {
        int countOfEachSignal = 2;
        Instant instant = Instant.now();

        Set<SignalData> bmsBduRequest = SignalGenerator.getSignals(SignalCatalogue.getBMSBDUConnectionRequestInfo(),
                signalInfo == SignalCatalogue.getBMSBDUConnectionRequestInfo() ? notChargingValue : 2.0, instant, countOfEachSignal);
        Set<SignalData> chargerState = SignalGenerator.getSignals(SignalCatalogue.getChargerStateInfo(),
                signalInfo == SignalCatalogue.getChargerStateInfo() ? notChargingValue : 2.0, instant, countOfEachSignal);
        Set<SignalData> chargerPowerState = SignalGenerator.getSignals(SignalCatalogue.getChargerPowerStateInfo(),
                signalInfo == SignalCatalogue.getChargerPowerStateInfo() ? notChargingValue : 2.0, instant, countOfEachSignal);

        Telemetry telemetry = CampaignDataGenerator.getTelemetry();
        telemetry.setCampaignName("charging-periodic");
        updateTelemetry(telemetry, SignalCatalogue.getBMSBDUConnectionRequestInfo(), bmsBduRequest);
        updateTelemetry(telemetry, SignalCatalogue.getChargerStateInfo(), chargerState);
        updateTelemetry(telemetry, SignalCatalogue.getChargerPowerStateInfo(), chargerPowerState);

        StateInfo stateInfo = VehicleSnapshotHelper.getChargingState(telemetry);
        Assert.assertNotNull(stateInfo);
        Assert.assertEquals(ChargingState.NOT_CHARGING.value(), stateInfo.getValue());
    }

    private void updateTelemetry(Telemetry telemetry, SignalInfo signalInfo, Set<SignalData> signalDataSet) {
        Map<String, Set<SignalData>> signals = telemetry.getSignals();
        signals.put(signalInfo.getKey(), signalDataSet);
        telemetry.setSignals(signals);
    }
}