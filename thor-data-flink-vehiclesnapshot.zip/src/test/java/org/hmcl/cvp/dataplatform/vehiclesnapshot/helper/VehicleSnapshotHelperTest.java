package org.hmcl.cvp.dataplatform.vehiclesnapshot.helper;

import org.hmcl.cvp.dataplatform.commons.catalogue.SignalCatalogue;
import org.hmcl.cvp.dataplatform.commons.testdata.CampaignDataGenerator;
import org.hmcl.cvp.dataplatform.commons.testdata.SignalGenerator;
import org.hmcl.cvp.dataplatform.contract.telemetry.SignalData;
import org.hmcl.cvp.dataplatform.contract.telemetry.SignalInfo;
import org.hmcl.cvp.dataplatform.contract.telemetry.Telemetry;
import org.hmcl.cvp.dataplatform.contract.telemetry.Tenant;
import org.hmcl.cvp.dataplatform.vehiclesnapshot.contract.ChargingState;
import org.hmcl.cvp.dataplatform.vehiclesnapshot.contract.ConnectionState;
import org.hmcl.cvp.dataplatform.vehiclesnapshot.contract.DriveState;
import org.hmcl.cvp.dataplatform.vehiclesnapshot.contract.IgnitionState;
import org.hmcl.cvp.dataplatform.vehiclesnapshot.contract.StateInfo;
import org.hmcl.cvp.dataplatform.vehiclesnapshot.utils.VehicleStateData;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.Parameterized;

import java.time.Instant;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.Set;

@RunWith(Parameterized.class)
public class VehicleSnapshotHelperTest {
    private final double motorSignalValue;
    private final String expectedDriveState;

    public VehicleSnapshotHelperTest(double motorSignalValue, String expectedDriveState) {
        this.motorSignalValue = motorSignalValue;
        this.expectedDriveState = expectedDriveState;
    }

    @Test
    public void testVehicleSnapshotHelper_getConnectionState() {
        StateInfo stateInfo = VehicleSnapshotHelper.getConnectionState("Connected");
        Assert.assertNotNull(stateInfo);
        Assert.assertEquals(ConnectionState.Connected.value(), stateInfo.getValue());
    }

    @Test
    public void testVehicleSnapshotHelper_getIgnitionsState_tcuIgnition() {
        Instant instant = Instant.now();
        Set<SignalData> signalDataSet = SignalGenerator.getBooleanSignals(true, instant);
        List<Telemetry> telemetries = getTelemetries(instant, Tenant.EV, 3, 2);
        updateTelemetries(telemetries, SignalCatalogue.getTcuIgnitionInfo(), signalDataSet);

        StateInfo stateInfo = VehicleSnapshotHelper.getIgnitionsState(telemetries);
        Assert.assertNotNull(stateInfo);
        Assert.assertEquals(IgnitionState.ON.value(), stateInfo.getValue());
    }

    @Test
    public void testVehicleSnapshotHelper_getIgnitionsState_ignitionAlert() {
        Instant instant = Instant.now();
        Set<SignalData> signalDataSet = SignalGenerator.getBooleanSignals(false, instant);
        List<Telemetry> telemetries = getTelemetries(instant, Tenant.EV, 1, 1);
        updateTelemetries(telemetries, SignalCatalogue.getTcuIgnitionInfo(), signalDataSet);

        Set<SignalData> ignitionAlertSignal = SignalGenerator.getBooleanSignals(true, instant);
        updateRandomTelemetry(telemetries, SignalCatalogue.getIgnitionAlertInfo(), ignitionAlertSignal);

        StateInfo stateInfo = VehicleSnapshotHelper.getIgnitionsState(telemetries);
        Assert.assertNotNull(stateInfo);
        Assert.assertEquals(IgnitionState.ON.value(), stateInfo.getValue());
    }

    @Test
    public void testVehicleSnapshotHelper_getIgnitionsState_ignitionOff() {
        Instant instant = Instant.now();
        Set<SignalData> signalDataSet = SignalGenerator.getBooleanSignals(false, instant);
        List<Telemetry> telemetries = getTelemetries(instant, Tenant.EV, 1, 1);
        updateTelemetries(telemetries, SignalCatalogue.getTcuIgnitionInfo(), signalDataSet);

        StateInfo stateInfo = VehicleSnapshotHelper.getIgnitionsState(telemetries);
        Assert.assertNotNull(stateInfo);
        Assert.assertEquals(IgnitionState.OFF.value(), stateInfo.getValue());
    }

    @Test
    public void testVehicleSnapshotHelper_getIgnitionsState_ignitionOff_allSignalsAreAbsent() {
        Instant instant = Instant.now();
        List<Telemetry> telemetries = getTelemetries(instant, Tenant.EV, 1, 1);

        telemetries.forEach(telemetry -> {
            Map<String, Set<SignalData>> signals = telemetry.getSignals();
            signals.put(SignalCatalogue.getTcuIgnitionInfo().getKey(), null);
            signals.put(SignalCatalogue.getIgnitionAlertInfo().getKey(), null);
            telemetry.setSignals(signals);
        });

        StateInfo stateInfo = VehicleSnapshotHelper.getIgnitionsState(telemetries);
        Assert.assertNotNull(stateInfo);
        Assert.assertEquals(IgnitionState.OFF.value(), stateInfo.getValue());
    }

    @Test
    public void testVehicleSnapshotHelper_getDriveState_evStopped() {
        int countOfEachSignal = 2;
        Instant instant = Instant.now();
        Set<SignalData> ignitionSignals = SignalGenerator.getBooleanSignals(false, instant);
        Set<SignalData> motorSignals = SignalGenerator.getSignals(SignalCatalogue.getMotorStatusInfo(), randomDouble(2), instant, countOfEachSignal);

        List<Telemetry> telemetries = getTelemetries(instant, Tenant.EV, 3, countOfEachSignal);
        updateTelemetries(telemetries, SignalCatalogue.getTcuIgnitionInfo(), ignitionSignals);
        updateTelemetries(telemetries, SignalCatalogue.getMotorStatusInfo(), motorSignals);

        StateInfo stateInfo = VehicleSnapshotHelper.getDriveState(telemetries, VehicleSnapshotHelper.DEFAULT_SPEED, VehicleSnapshotHelper.DEFAULT_RPM);
        Assert.assertNotNull(stateInfo);
        Assert.assertEquals(DriveState.STOPPED.value(), stateInfo.getValue());
    }

    @Test
    public void testVehicleSnapshotHelper_getDriveState_iceStopped() {
        int countOfEachSignal = 2;
        Instant instant = Instant.now();
        Set<SignalData> ignitionSignals = SignalGenerator.getBooleanSignals(false, instant);
        Set<SignalData> engineSpeedSignals = SignalGenerator.getSignals(SignalCatalogue.getEngineSpeedInfo(), randomDouble(1099), instant, countOfEachSignal);

        List<Telemetry> telemetries = getTelemetries(instant, Tenant.ICE, 3, countOfEachSignal);
        updateTelemetries(telemetries, SignalCatalogue.getTcuIgnitionInfo(), ignitionSignals);
        updateTelemetries(telemetries, SignalCatalogue.getEngineSpeedInfo(), engineSpeedSignals);

        StateInfo stateInfo = VehicleSnapshotHelper.getDriveState(telemetries, VehicleSnapshotHelper.DEFAULT_SPEED, VehicleSnapshotHelper.DEFAULT_RPM);
        Assert.assertNotNull(stateInfo);
        Assert.assertEquals(DriveState.STOPPED.value(), stateInfo.getValue());
    }

    @Test
    public void testVehicleSnapshotHelper_getDriveState_harleyStopped() {
        int countOfEachSignal = 2;
        Instant instant = Instant.now();
        Set<SignalData> ignitionSignals = SignalGenerator.getBooleanSignals(false, instant);
        Set<SignalData> engineSpeedSignals = SignalGenerator.getSignals(SignalCatalogue.getEngineSpeedInfo(), randomDouble(1099), instant, countOfEachSignal);

        List<Telemetry> telemetries = getTelemetries(instant, Tenant.HARLEY, 3, countOfEachSignal);
        updateTelemetries(telemetries, SignalCatalogue.getTcuIgnitionInfo(), ignitionSignals);
        updateTelemetries(telemetries, SignalCatalogue.getEngineSpeedInfo(), engineSpeedSignals);

        StateInfo stateInfo = VehicleSnapshotHelper.getDriveState(telemetries, VehicleSnapshotHelper.DEFAULT_SPEED, VehicleSnapshotHelper.DEFAULT_RPM);
        Assert.assertNotNull(stateInfo);
        Assert.assertEquals(DriveState.STOPPED.value(), stateInfo.getValue());
    }

    @Test
    public void testVehicleSnapshotHelper_getDriveState_evMoving() {
        int countOfEachSignal = 2;
        Instant instant = Instant.now();
        Set<SignalData> motorSignals = SignalGenerator.getSignals(SignalCatalogue.getMotorStatusInfo(),
                Double.valueOf(VehicleStateData.MOTOR_ON_SIGNAL), instant, countOfEachSignal);
        Set<SignalData> clusterSpeedSignals = SignalGenerator.getSignals(SignalCatalogue.getVehicleSpeedDisplayInfo(),
                10.0, instant, countOfEachSignal);

        List<Telemetry> telemetries = getTelemetries(instant, Tenant.EV, 3, countOfEachSignal);
        updateTelemetries(telemetries, SignalCatalogue.getMotorStatusInfo(), motorSignals);
        updateTelemetries(telemetries, SignalCatalogue.getVehicleSpeedDisplayInfo(), clusterSpeedSignals);

        StateInfo stateInfo = VehicleSnapshotHelper.getDriveState(telemetries, VehicleSnapshotHelper.DEFAULT_SPEED, VehicleSnapshotHelper.DEFAULT_RPM);
        Assert.assertNotNull(stateInfo);
        Assert.assertEquals(DriveState.MOVING.value(), stateInfo.getValue());

    }

    @Test
    public void testVehicleSnapshotHelper_getDriveState_iceMoving() {
        int countOfEachSignal = 2;
        Instant instant = Instant.now();
        Set<SignalData> engineSpeedSignals = SignalGenerator.getSignals(SignalCatalogue.getEngineSpeedInfo(), 2000.0, instant, countOfEachSignal);
        Set<SignalData> clusterSpeedSignals = SignalGenerator.getSignals(SignalCatalogue.getVehicleSpeedDisplayInfo(),
                10.0, instant, countOfEachSignal);

        List<Telemetry> telemetries = getTelemetries(instant, Tenant.ICE, 3, countOfEachSignal);
        updateTelemetries(telemetries, SignalCatalogue.getEngineSpeedInfo(), engineSpeedSignals);
        updateTelemetries(telemetries, SignalCatalogue.getVehicleSpeedDisplayInfo(), clusterSpeedSignals);

        StateInfo stateInfo = VehicleSnapshotHelper.getDriveState(telemetries, VehicleSnapshotHelper.DEFAULT_SPEED, VehicleSnapshotHelper.DEFAULT_RPM);
        Assert.assertNotNull(stateInfo);
        Assert.assertEquals(DriveState.MOVING.value(), stateInfo.getValue());

    }

    @Test
    public void testVehicleSnapshotHelper_getDriveState_harleyMoving() {
        int countOfEachSignal = 2;
        Instant instant = Instant.now();
        Set<SignalData> engineSpeedSignals = SignalGenerator.getSignals(SignalCatalogue.getEngineSpeedInfo(), 2000.0, instant, countOfEachSignal);
        Set<SignalData> clusterSpeedSignals = SignalGenerator.getSignals(SignalCatalogue.getVehicleSpeedDisplayInfo(),
                10.0, instant, countOfEachSignal);

        List<Telemetry> telemetries = getTelemetries(instant, Tenant.HARLEY, 3, countOfEachSignal);
        updateTelemetries(telemetries, SignalCatalogue.getEngineSpeedInfo(), engineSpeedSignals);
        updateTelemetries(telemetries, SignalCatalogue.getVehicleSpeedDisplayInfo(), clusterSpeedSignals);

        StateInfo stateInfo = VehicleSnapshotHelper.getDriveState(telemetries, VehicleSnapshotHelper.DEFAULT_SPEED, VehicleSnapshotHelper.DEFAULT_RPM);
        Assert.assertNotNull(stateInfo);
        Assert.assertEquals(DriveState.MOVING.value(), stateInfo.getValue());

    }

    @Parameterized.Parameters
    public static Collection<Object[]> data() {
        return Arrays.asList(new Object[][]{
                {1.0, DriveState.IDLE.value()},
                {2.0, DriveState.IDLE.value()},
                {3.0, DriveState.IDLE.value()},
                {0.0, DriveState.IDLE.value()}
        });
    }

    @Test
    public void testVehicleSnapshotHelper_getDriveState_evIdle() {
        int countOfEachSignal = 2;
        Instant instant = Instant.now();
        Set<SignalData> ignitionSignals = SignalGenerator.getBooleanSignals(true, instant);
        Set<SignalData> motorSignals = SignalGenerator.getSignals(SignalCatalogue.getMotorStatusInfo(), motorSignalValue, instant, countOfEachSignal);
        Set<SignalData> clusterSpeedSignals = SignalGenerator.getSignals(SignalCatalogue.getVehicleSpeedDisplayInfo(), 4.9, instant, countOfEachSignal);

        List<Telemetry> telemetries = getTelemetries(instant, Tenant.EV, 3, countOfEachSignal);
        updateTelemetries(telemetries, SignalCatalogue.getTcuIgnitionInfo(), ignitionSignals);
        updateTelemetries(telemetries, SignalCatalogue.getMotorStatusInfo(), motorSignals);
        updateTelemetries(telemetries, SignalCatalogue.getVehicleSpeedDisplayInfo(), clusterSpeedSignals);

        StateInfo stateInfo = VehicleSnapshotHelper.getDriveState(telemetries, VehicleSnapshotHelper.DEFAULT_SPEED, VehicleSnapshotHelper.DEFAULT_RPM);
        Assert.assertNotNull(stateInfo);
        Assert.assertEquals(expectedDriveState, stateInfo.getValue());
    }


    @Test
    public void testVehicleSnapshotHelper_getDriveState_iceIdle() {
        int countOfEachSignal = 2;
        Instant instant = Instant.now();
        Set<SignalData> ignitionSignals = SignalGenerator.getBooleanSignals(true, instant);
        Set<SignalData> engineSpeedSignals = SignalGenerator.getSignals(SignalCatalogue.getEngineSpeedInfo(), 1099.0, instant, countOfEachSignal);
        Set<SignalData> clusterSpeedSignals = SignalGenerator.getSignals(SignalCatalogue.getVehicleSpeedDisplayInfo(),
                4.9, instant, countOfEachSignal);

        List<Telemetry> telemetries = getTelemetries(instant, Tenant.ICE, 3, countOfEachSignal);
        updateTelemetries(telemetries, SignalCatalogue.getTcuIgnitionInfo(), ignitionSignals);
        updateTelemetries(telemetries, SignalCatalogue.getEngineSpeedInfo(), engineSpeedSignals);
        updateTelemetries(telemetries, SignalCatalogue.getVehicleSpeedDisplayInfo(), clusterSpeedSignals);

        StateInfo stateInfo = VehicleSnapshotHelper.getDriveState(telemetries, VehicleSnapshotHelper.DEFAULT_SPEED, VehicleSnapshotHelper.DEFAULT_RPM);
        Assert.assertNotNull(stateInfo);
        Assert.assertEquals(DriveState.IDLE.value(), stateInfo.getValue());
    }

    @Test
    public void testVehicleSnapshotHelper_getDriveState_harleyIdle() {
        int countOfEachSignal = 2;
        Instant instant = Instant.now();
        Set<SignalData> ignitionSignals = SignalGenerator.getBooleanSignals(true, instant);
        Set<SignalData> engineSpeedSignals = SignalGenerator.getSignals(SignalCatalogue.getEngineSpeedInfo(), 1099.0, instant, countOfEachSignal);
        Set<SignalData> clusterSpeedSignals = SignalGenerator.getSignals(SignalCatalogue.getVehicleSpeedDisplayInfo(),
                4.9, instant, countOfEachSignal);

        List<Telemetry> telemetries = getTelemetries(instant, Tenant.HARLEY, 3, countOfEachSignal);
        updateTelemetries(telemetries, SignalCatalogue.getTcuIgnitionInfo(), ignitionSignals);
        updateTelemetries(telemetries, SignalCatalogue.getEngineSpeedInfo(), engineSpeedSignals);
        updateTelemetries(telemetries, SignalCatalogue.getVehicleSpeedDisplayInfo(), clusterSpeedSignals);

        StateInfo stateInfo = VehicleSnapshotHelper.getDriveState(telemetries, VehicleSnapshotHelper.DEFAULT_SPEED, VehicleSnapshotHelper.DEFAULT_RPM);
        Assert.assertNotNull(stateInfo);
        Assert.assertEquals(DriveState.IDLE.value(), stateInfo.getValue());
    }

    @Test
    public void testVehicleSnapshotHelper_getDriveState_iceNull() {
        int countOfEachSignal = 2;
        Instant instant = Instant.now();
        Set<SignalData> ignitionSignals = SignalGenerator.getBooleanSignals(true, instant);
        Set<SignalData> engineSpeedSignals = SignalGenerator.getSignals(SignalCatalogue.getEngineSpeedInfo(), 1200.0, instant, countOfEachSignal);
        Set<SignalData> clusterSpeedSignals = SignalGenerator.getSignals(SignalCatalogue.getVehicleSpeedDisplayInfo(),
                4.9, instant, countOfEachSignal);

        List<Telemetry> telemetries = getTelemetries(instant, Tenant.ICE, 3, countOfEachSignal);
        updateTelemetries(telemetries, SignalCatalogue.getTcuIgnitionInfo(), ignitionSignals);
        updateTelemetries(telemetries, SignalCatalogue.getEngineSpeedInfo(), engineSpeedSignals);
        updateTelemetries(telemetries, SignalCatalogue.getVehicleSpeedDisplayInfo(), clusterSpeedSignals);

        StateInfo stateInfo = VehicleSnapshotHelper.getDriveState(telemetries, VehicleSnapshotHelper.DEFAULT_SPEED, VehicleSnapshotHelper.DEFAULT_RPM);
        Assert.assertNull(stateInfo);
    }

    @Test
    public void testVehicleSnapshotHelper_getDriveState_harleyNull() {
        int countOfEachSignal = 2;
        Instant instant = Instant.now();
        Set<SignalData> ignitionSignals = SignalGenerator.getBooleanSignals(true, instant);
        Set<SignalData> engineSpeedSignals = SignalGenerator.getSignals(SignalCatalogue.getEngineSpeedInfo(), 1200.0, instant, countOfEachSignal);
        Set<SignalData> clusterSpeedSignals = SignalGenerator.getSignals(SignalCatalogue.getVehicleSpeedDisplayInfo(),
                4.9, instant, countOfEachSignal);

        List<Telemetry> telemetries = getTelemetries(instant, Tenant.HARLEY, 3, countOfEachSignal);
        updateTelemetries(telemetries, SignalCatalogue.getTcuIgnitionInfo(), ignitionSignals);
        updateTelemetries(telemetries, SignalCatalogue.getEngineSpeedInfo(), engineSpeedSignals);
        updateTelemetries(telemetries, SignalCatalogue.getVehicleSpeedDisplayInfo(), clusterSpeedSignals);

        StateInfo stateInfo = VehicleSnapshotHelper.getDriveState(telemetries, VehicleSnapshotHelper.DEFAULT_SPEED, VehicleSnapshotHelper.DEFAULT_RPM);
        Assert.assertNull(stateInfo);
    }

    @Test
    public void testVehicleSnapshotHelper_getChargingState_charging() {
        int countOfEachSignal = 2;
        Instant instant = Instant.now();
        Set<SignalData> bmsBduRequest = SignalGenerator.getSignals(SignalCatalogue.getBMSBDUConnectionRequestInfo(),
                2.0, instant, countOfEachSignal);
        Set<SignalData> chargerState = SignalGenerator.getSignals(SignalCatalogue.getChargerStateInfo(),
                2.0, instant, countOfEachSignal);
        Set<SignalData> chargerPowerState = SignalGenerator.getSignals(SignalCatalogue.getChargerPowerStateInfo(),
                2.0, instant, countOfEachSignal);

        Telemetry telemetry = CampaignDataGenerator.getTelemetry();
        telemetry.setCampaignName("charging-periodic");
        updateTelemetry(telemetry, SignalCatalogue.getBMSBDUConnectionRequestInfo(), bmsBduRequest);
        updateTelemetry(telemetry, SignalCatalogue.getChargerStateInfo(), chargerState);
        updateTelemetry(telemetry, SignalCatalogue.getChargerPowerStateInfo(), chargerPowerState);

        StateInfo stateInfo = VehicleSnapshotHelper.getChargingState(telemetry);
        Assert.assertNotNull(stateInfo);
        Assert.assertEquals(ChargingState.CHARGING.value(), stateInfo.getValue());

    }

    @Test
    public void testVehicleSnapshotHelper_getChargingState_notChargingDueToBMSBDU() {
        int countOfEachSignal = 2;
        Instant instant = Instant.now();
        Set<SignalData> bmsBduRequest = SignalGenerator.getSignals(SignalCatalogue.getBMSBDUConnectionRequestInfo(),
                3.0, instant, countOfEachSignal);
        Set<SignalData> chargerState = SignalGenerator.getSignals(SignalCatalogue.getChargerStateInfo(),
                3.0, instant, countOfEachSignal);
        Set<SignalData> chargerPowerState = SignalGenerator.getSignals(SignalCatalogue.getChargerPowerStateInfo(),
                3.0, instant, countOfEachSignal);

        Telemetry telemetry = CampaignDataGenerator.getTelemetry();
        telemetry.setCampaignName("charging-periodic");
        updateTelemetry(telemetry, SignalCatalogue.getBMSBDUConnectionRequestInfo(), bmsBduRequest);
        updateTelemetry(telemetry, SignalCatalogue.getChargerStateInfo(), chargerState);
        updateTelemetry(telemetry, SignalCatalogue.getChargerPowerStateInfo(), chargerPowerState);

        StateInfo stateInfo = VehicleSnapshotHelper.getChargingState(telemetry);
        Assert.assertNotNull(stateInfo);
        Assert.assertEquals(ChargingState.NOT_CHARGING.value(), stateInfo.getValue());

    }

    @Test
    public void testVehicleSnapshotHelper_getChargingState_notChargingDueToChargerState() {
        int countOfEachSignal = 2;
        Instant instant = Instant.now();
        Set<SignalData> bmsBduRequest = SignalGenerator.getSignals(SignalCatalogue.getBMSBDUConnectionRequestInfo(),
                2.0, instant, countOfEachSignal);
        Set<SignalData> chargerState = SignalGenerator.getSignals(SignalCatalogue.getChargerStateInfo(),
                3.0, instant, countOfEachSignal);
        Set<SignalData> chargerPowerState = SignalGenerator.getSignals(SignalCatalogue.getChargerPowerStateInfo(),
                3.0, instant, countOfEachSignal);

        Telemetry telemetry = CampaignDataGenerator.getTelemetry();
        telemetry.setCampaignName("charging-periodic");
        updateTelemetry(telemetry, SignalCatalogue.getBMSBDUConnectionRequestInfo(), bmsBduRequest);
        updateTelemetry(telemetry, SignalCatalogue.getChargerStateInfo(), chargerState);
        updateTelemetry(telemetry, SignalCatalogue.getChargerPowerStateInfo(), chargerPowerState);

        StateInfo stateInfo = VehicleSnapshotHelper.getChargingState(telemetry);
        Assert.assertNotNull(stateInfo);
        Assert.assertEquals(ChargingState.NOT_CHARGING.value(), stateInfo.getValue());

    }

    @Test
    public void testVehicleSnapshotHelper_getChargingState_notChargingDueToChargerPowerState() {
        int countOfEachSignal = 2;
        Instant instant = Instant.now();
        Set<SignalData> bmsBduRequest = SignalGenerator.getSignals(SignalCatalogue.getBMSBDUConnectionRequestInfo(),
                2.0, instant, countOfEachSignal);
        Set<SignalData> chargerState = SignalGenerator.getSignals(SignalCatalogue.getChargerStateInfo(),
                2.0, instant, countOfEachSignal);
        Set<SignalData> chargerPowerState = SignalGenerator.getSignals(SignalCatalogue.getChargerPowerStateInfo(),
                3.0, instant, countOfEachSignal);

        Telemetry telemetry = CampaignDataGenerator.getTelemetry();
        telemetry.setCampaignName("charging-periodic");
        updateTelemetry(telemetry, SignalCatalogue.getBMSBDUConnectionRequestInfo(), bmsBduRequest);
        updateTelemetry(telemetry, SignalCatalogue.getChargerStateInfo(), chargerState);
        updateTelemetry(telemetry, SignalCatalogue.getChargerPowerStateInfo(), chargerPowerState);

        StateInfo stateInfo = VehicleSnapshotHelper.getChargingState(telemetry);
        Assert.assertNotNull(stateInfo);
        Assert.assertEquals(ChargingState.NOT_CHARGING.value(), stateInfo.getValue());

    }

    @Test
    public void testVehicleSnapshotHelper_getChargingState_notChargingCampaign() {
        int countOfEachSignal = 2;
        Instant instant = Instant.now();
        Set<SignalData> bmsBduRequest = SignalGenerator.getSignals(SignalCatalogue.getBMSBDUConnectionRequestInfo(),
                2.0, instant, countOfEachSignal);
        Set<SignalData> chargerState = SignalGenerator.getSignals(SignalCatalogue.getChargerStateInfo(),
                2.0, instant, countOfEachSignal);
        Set<SignalData> chargerPowerState = SignalGenerator.getSignals(SignalCatalogue.getChargerPowerStateInfo(),
                2.0, instant, countOfEachSignal);

        Telemetry telemetry = CampaignDataGenerator.getTelemetry();
        telemetry.setCampaignName("some-ignition-campaign");
        updateTelemetry(telemetry, SignalCatalogue.getBMSBDUConnectionRequestInfo(), bmsBduRequest);
        updateTelemetry(telemetry, SignalCatalogue.getChargerStateInfo(), chargerState);
        updateTelemetry(telemetry, SignalCatalogue.getChargerPowerStateInfo(), chargerPowerState);

        StateInfo stateInfo = VehicleSnapshotHelper.getChargingState(telemetry);
        Assert.assertNull(stateInfo);
    }


    @Test
    public void testVehicleSnapshotHelper_getChargingState_chargerPowerStateSignalIsMissing() {
        int countOfEachSignal = 2;
        Instant instant = Instant.now();
        Set<SignalData> bmsBduRequest = SignalGenerator.getSignals(SignalCatalogue.getBMSBDUConnectionRequestInfo(),
                2.0, instant, countOfEachSignal);
        Set<SignalData> chargerState = SignalGenerator.getSignals(SignalCatalogue.getChargerStateInfo(),
                2.0, instant, countOfEachSignal);

        Telemetry telemetry = CampaignDataGenerator.getTelemetry();
        telemetry.setCampaignName("charging-periodic");
        updateTelemetry(telemetry, SignalCatalogue.getBMSBDUConnectionRequestInfo(), bmsBduRequest);
        updateTelemetry(telemetry, SignalCatalogue.getChargerStateInfo(), chargerState);
        updateTelemetry(telemetry, SignalCatalogue.getChargerPowerStateInfo(), null);

        StateInfo stateInfo = VehicleSnapshotHelper.getChargingState(telemetry);
        Assert.assertNull(stateInfo);
    }

    @Test
    public void testVehicleSnapshotHelper_getChargingState_chargerStateSignalIsMissing() {
        int countOfEachSignal = 2;
        Instant instant = Instant.now();
        Set<SignalData> bmsBduRequest = SignalGenerator.getSignals(SignalCatalogue.getBMSBDUConnectionRequestInfo(),
                2.0, instant, countOfEachSignal);
        Set<SignalData> chargerPowerState = SignalGenerator.getSignals(SignalCatalogue.getChargerPowerStateInfo(),
                2.0, instant, countOfEachSignal);

        Telemetry telemetry = CampaignDataGenerator.getTelemetry();
        telemetry.setCampaignName("charging-periodic");
        updateTelemetry(telemetry, SignalCatalogue.getBMSBDUConnectionRequestInfo(), bmsBduRequest);
        updateTelemetry(telemetry, SignalCatalogue.getChargerPowerStateInfo(), chargerPowerState);
        updateTelemetry(telemetry, SignalCatalogue.getChargerStateInfo(), null);

        StateInfo stateInfo = VehicleSnapshotHelper.getChargingState(telemetry);
         Assert.assertNull(stateInfo);
    }

    @Test
    public void testVehicleSnapshotHelper_getChargingState_bmsBduRequestSignalIsMissing() {
        int countOfEachSignal = 2;
        Instant instant = Instant.now();
        Set<SignalData> chargerState = SignalGenerator.getSignals(SignalCatalogue.getChargerStateInfo(),
                2.0, instant, countOfEachSignal);
        Set<SignalData> chargerPowerState = SignalGenerator.getSignals(SignalCatalogue.getChargerPowerStateInfo(),
                2.0, instant, countOfEachSignal);

        Telemetry telemetry = CampaignDataGenerator.getTelemetry();
        telemetry.setCampaignName("charging-campaign");
        updateTelemetry(telemetry, SignalCatalogue.getChargerStateInfo(), chargerState);
        updateTelemetry(telemetry, SignalCatalogue.getChargerPowerStateInfo(), chargerPowerState);
        updateTelemetry(telemetry, SignalCatalogue.getBMSBDUConnectionRequestInfo(), null);

        StateInfo stateInfo = VehicleSnapshotHelper.getChargingState(telemetry);
        Assert.assertNull(stateInfo);
    }

    private List<Telemetry> getTelemetries(Instant instant, Tenant tenant, int countOfEvents, int countOfEachSignal) {
        List<Telemetry> telemetries = new ArrayList<>(countOfEvents);
        for (int i = 0; i < countOfEvents; i++) {
            Instant instant1 = instant.plusSeconds(2L * i);
            Telemetry telemetry = CampaignDataGenerator.getTelemetry(VehicleStateData.VIRTUAL_ID, tenant, instant1, countOfEachSignal);
            telemetries.add(telemetry);
        }

        return telemetries;
    }

    private void updateTelemetries(List<Telemetry> telemetries, SignalInfo signalInfo, Set<SignalData> signalDataSet) {
        telemetries.forEach(telemetry -> {
            Map<String, Set<SignalData>> signals = telemetry.getSignals();
            signals.put(signalInfo.getKey(), signalDataSet);
            telemetry.setSignals(signals);
        });
    }

    private void updateTelemetry(Telemetry telemetry, SignalInfo signalInfo, Set<SignalData> signalDataSet) {
        Map<String, Set<SignalData>> signals = telemetry.getSignals();
        signals.put(signalInfo.getKey(), signalDataSet);
        telemetry.setSignals(signals);
    }

    private void updateRandomTelemetry(List<Telemetry> telemetries, SignalInfo signalInfo, Set<SignalData> signalDataSet) {
        int randomIndex = new Random().nextInt(telemetries.size());

        Telemetry telemetry = telemetries.get(randomIndex);
        telemetries.remove(randomIndex);

        Map<String, Set<SignalData>> signals = telemetry.getSignals();
        signals.put(signalInfo.getKey(), signalDataSet);
        telemetry.setSignals(signals);

        telemetries.add(telemetry);
    }

    private static double randomDouble(int bound) {
        return new Random().nextInt(bound);
    }
}
