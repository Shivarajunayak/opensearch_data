package org.hmcl.cvp.dataplatform.vehiclesnapshot.operator;

import org.apache.flink.runtime.jobgraph.OperatorID;
import org.apache.flink.runtime.metrics.groups.InternalOperatorMetricGroup;
import org.apache.flink.runtime.metrics.util.InterceptingOperatorMetricGroup;
import org.apache.flink.runtime.metrics.util.InterceptingTaskMetricGroup;
import org.apache.flink.runtime.operators.testutils.MockEnvironment;
import org.apache.flink.runtime.operators.testutils.MockEnvironmentBuilder;
import org.apache.flink.runtime.testutils.MiniClusterResourceConfiguration;
import org.apache.flink.streaming.api.operators.StreamFlatMap;
import org.apache.flink.streaming.runtime.streamrecord.StreamRecord;
import org.apache.flink.streaming.util.OneInputStreamOperatorTestHarness;
import org.apache.flink.test.util.MiniClusterWithClientResource;
import org.hmcl.cvp.dataplatform.contract.connectionstatus.ConnectionStatus;
import org.hmcl.cvp.dataplatform.vehiclesnapshot.contract.EnrichedSnapshot;
import org.hmcl.cvp.dataplatform.vehiclesnapshot.utils.VehicleStateData;
import org.junit.Assert;
import org.junit.ClassRule;
import org.junit.Test;

import java.util.List;

public class EnrichConnectionStatusFunctionTest {
    @ClassRule
    public static MiniClusterWithClientResource flinkCluster =
            new MiniClusterWithClientResource(
                    new MiniClusterResourceConfiguration.Builder()
                            .setNumberSlotsPerTaskManager(2)
                            .setNumberTaskManagers(1)
                            .build());

    private final InterceptingOperatorMetricGroup interceptingOperatorMetricGroup = new InterceptingOperatorMetricGroup();
    private final InterceptingTaskMetricGroup interceptingTaskMetricGroup = new InterceptingTaskMetricGroup() {
        @Override
        public InternalOperatorMetricGroup getOrAddOperator(OperatorID operatorID, String name) {
            return interceptingOperatorMetricGroup;
        }
    };

    private final MockEnvironment mockEnvironment = new MockEnvironmentBuilder().setMetricGroup(interceptingTaskMetricGroup).build();

    private final EnrichConnectionStatusFunction enrichConnectionStatusFunction = new EnrichConnectionStatusFunction();

    private OneInputStreamOperatorTestHarness<ConnectionStatus, EnrichedSnapshot> testHarness() throws Exception {
        return new OneInputStreamOperatorTestHarness<>(new StreamFlatMap<>(enrichConnectionStatusFunction), mockEnvironment);
    }

    @Test
    public void testEnrichConnectionStatusFunction() {
        try (OneInputStreamOperatorTestHarness<ConnectionStatus, EnrichedSnapshot> testHarness = testHarness()) {

            testHarness.setup();
            testHarness.open();

            ConnectionStatus connectionStatus = getConnectionStatus();
            testHarness.processElement(new StreamRecord<>(connectionStatus));

            List<EnrichedSnapshot> enrichedSnapshotList = VehicleStateData.getOutput(testHarness.getRecordOutput());
            Assert.assertEquals(1, enrichedSnapshotList.size());

        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    public static ConnectionStatus getConnectionStatus() {
        return ConnectionStatus.builder().vid("vid").status("Connected").tcuId("tcuID").timestamp(123L).tenantId("EV-VIDA").build();
    }
}
