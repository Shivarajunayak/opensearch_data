package org.hmcl.cvp.dataplatform.vehiclesnapshot.utils;

import com.google.gson.Gson;
import org.apache.flink.streaming.runtime.streamrecord.StreamRecord;
import org.hmcl.cvp.dataplatform.commons.catalogue.SignalCatalogue;
import org.hmcl.cvp.dataplatform.commons.testdata.CampaignDataGenerator;
import org.hmcl.cvp.dataplatform.commons.testdata.LKSGenerator;
import org.hmcl.cvp.dataplatform.commons.testdata.SignalGenerator;
import org.hmcl.cvp.dataplatform.commons.utils.GsonUtils;
import org.hmcl.cvp.dataplatform.contract.lks.LKSMessage;
import org.hmcl.cvp.dataplatform.contract.lks.LKSMessagePayload;
import org.hmcl.cvp.dataplatform.contract.lks.LKSSignal;
import org.hmcl.cvp.dataplatform.contract.notification.AlertDetails;
import org.hmcl.cvp.dataplatform.contract.notification.GeoFenceType;
import org.hmcl.cvp.dataplatform.contract.notification.Notification;
import org.hmcl.cvp.dataplatform.contract.telemetry.SignalData;
import org.hmcl.cvp.dataplatform.contract.telemetry.SignalInfo;
import org.hmcl.cvp.dataplatform.contract.telemetry.Telemetry;
import org.hmcl.cvp.dataplatform.contract.telemetry.Tenant;
import org.hmcl.cvp.dataplatform.vehiclesnapshot.contract.*;

import java.time.Instant;
import java.util.*;
import java.util.stream.Collectors;

public class VehicleStateData {

    public static final String VIRTUAL_ID = "test-vehicle";
    public static final String EV_SNAPSHOT_INDEX = "hmcl-cv-ev-vida-vehicle-snapshot";
    public static final String ICE_SNAPSHOT_INDEX = "hmcl-cv-ice-hero-vehicle-snapshot";
    public static final String HARLEY_SNAPSHOT_INDEX = "hmcl-cv-ice-harley-vehicle-snapshot";
    public static final String TEMP_INDEX = "hmcl-cv-ev-vida-vehicle-snapshot-insert";
    public static final Integer MOTOR_ON_SIGNAL = 3;
    public static final Integer CHARGING_SIGNAL = 2;
    public static final Double RPM = 1200.0;
    public static final Double SPEED = 6.0;
    private static final Gson GSON = GsonUtils.getGson();

    private VehicleStateData() {
    }

    public static <T> List<String> getJsonData(List<T> data) {
        return data.stream().map(GSON::toJson).collect(Collectors.toList());
    }

    public static <T> String toJson(T data) {
        return GSON.toJson(data);
    }

    public static Telemetry getVehicleSnapshotTelemetry(Tenant tenant, Instant instant, boolean includeNeededSignals, int countOfEachSignal) {
        Telemetry telemetry = CampaignDataGenerator.getTelemetry(VIRTUAL_ID, tenant, instant, countOfEachSignal);

        Map<String, Set<SignalData>>  signals = CampaignDataGenerator.getChargingRelatedSignals(instant, countOfEachSignal);

        if (includeNeededSignals) {
            updateIgnitionSignal(signals, true, instant);
            updateMotorSignal(signals, MOTOR_ON_SIGNAL, instant, countOfEachSignal);
            updateEngineSignal(signals, RPM, instant, countOfEachSignal);
            updateSpeedSignal(signals, SPEED, instant, countOfEachSignal);
            updateChargingSignal(signals, CHARGING_SIGNAL, instant, countOfEachSignal);
            updateChargerPluggedSignal(signals, instant, countOfEachSignal);
        }

        telemetry.setSignals(signals);

        return telemetry;
    }

    public static List<Telemetry> getVehicleSnapshotTelemetries(Tenant tenant, Instant instant, boolean includeNeededSignals, int numOfEvents, int countOfEachSignal) {
        List<Telemetry> data = new ArrayList<>(numOfEvents);

        for (int i = 0; i < numOfEvents; i++) {
            instant = instant.plusSeconds(i * 5000L);
            Telemetry telemetry = getVehicleSnapshotTelemetry(tenant, instant, includeNeededSignals, countOfEachSignal);
            data.add(telemetry);
        }
        return data;
    }

    public static List<Telemetry> getVehicleSnapshotTelemetries(Tenant tenant, Instant instant, int numOfEvents, int countOfEachSignal) {
        return getVehicleSnapshotTelemetries(tenant, instant, true, numOfEvents, countOfEachSignal);
    }

    public static List<String> getVehicleSnapshotData(Tenant tenant, Instant instant, int numOfEvents, int countOfEachSignal) {
        return getJsonData(getVehicleSnapshotTelemetries(tenant, instant, numOfEvents, countOfEachSignal));
    }

    public static <T> List<StreamRecord<T>> getStreamRecords(List<T> jsonData) {
        return jsonData.stream().map(StreamRecord::new).collect(Collectors.toList());
    }

    public static List<StreamRecord<Telemetry>> getTelemetryStreamRecords(List<Telemetry> jsonData) {
        return jsonData.stream()
                .map(t -> new StreamRecord<>(t, t.getCollectionEventTime()))
                .collect(Collectors.toList());
    }

    public static <T> List<T> getOutput(Collection<StreamRecord<T>> streamOutput) {
        return streamOutput.stream().map(StreamRecord::getValue).collect(Collectors.toList());
    }

    public static List<String> getLKSData(Tenant tenant, int numOfEvents) {
        List<LKSMessage> data = LKSGenerator.getLastKnowStateMessages(VIRTUAL_ID, tenant, numOfEvents);
        for (LKSMessage lksMessage : data) {
            updateLKSMessage(lksMessage);
        }
        return getJsonData(data);
    }

    public static void updateLKSMessage(LKSMessage lksMessage) {
        LKSMessagePayload payload = lksMessage.getLksMessagePayload();
        List<LKSSignal> lksSignals = payload.getSignals();
        lksSignals.add(getLKSSignal(SignalCatalogue.getTcuIgnitionInfo(), true));
        lksSignals.add(getLKSSignal(SignalCatalogue.getMotorStatusInfo(), 2.0));
        lksSignals.add(getLKSSignal(SignalCatalogue.getEngineSpeedInfo(), RPM));
        lksSignals.add(getLKSSignal(SignalCatalogue.getVehicleSpeedInfo(), 10.0));
        lksSignals.add(getLKSSignal(SignalCatalogue.getVehicleSpeedHighResInfo(), 10.0));
        payload.setSignals(lksSignals);
        lksMessage.setLksMessagePayload(payload);
    }

    public static LKSSignal getLKSSignal(SignalInfo signalInfo, Double value) {
        return LKSSignal.builder()
                .name(signalInfo.getKey())
                .int8Value(value)
                .build();
    }

    public static LKSSignal getLKSSignal(SignalInfo signalInfo, Boolean value) {
        return LKSSignal.builder()
                .name(signalInfo.getKey())
                .booleanValue(value)
                .build();
    }

    public static String getLKSDataWithMultipleValues(Tenant tenant, int numOfValues) {
        LKSMessage data = LKSGenerator.getLastKnowStateMessage(VIRTUAL_ID, tenant);

        if (numOfValues > 1) {
            LKSMessagePayload payload = data.getLksMessagePayload();
            List<LKSSignal> signals = new ArrayList<>();
            for (int i = 0; i < numOfValues; i++) {
                signals.addAll(LKSGenerator.getFetchApiSignals(tenant));
            }

            payload.setSignals(signals);
            data.setLksMessagePayload(payload);
        }


        return GSON.toJson(data);
    }

    public static String getNotificationString(Tenant tenant, GeoFenceType geoFenceType, Instant instant) {
        Notification notification = getNotificationData(tenant, geoFenceType, instant);

        return GSON.toJson(notification);
    }

    public static Notification getNotificationData(Tenant tenant, GeoFenceType geoFenceType, Instant instant) {
        Notification notification = new Notification();
        notification.setVehicleVid(VIRTUAL_ID);
        notification.setTenantId(tenant.value());
        notification.setEventTimestamp(String.valueOf(instant.toEpochMilli()));
        notification.setGeofenceId(UUID.randomUUID().toString());
        notification.setTcuId(VIRTUAL_ID);

        AlertDetails alertDetails = new AlertDetails();
        alertDetails.setBoundaryCondition(geoFenceType);

        notification.setAlertDetails(alertDetails);

        return notification;

    }

    public static SnapshotWrapper getSnapShotWrapper(Tenant tenant) {
        boolean isEv = Tenant.EV.equals(tenant);
        SnapshotWrapper snapshotWrapper = new SnapshotWrapper();
        snapshotWrapper.setIsEv(isEv);

        CommonSnapshot commonSnapshot = new CommonSnapshot();
        commonSnapshot.setVid(VIRTUAL_ID);
        commonSnapshot.setVehicleName(VIRTUAL_ID);
        commonSnapshot.setCreatedTsp(Instant.now().toEpochMilli());
        commonSnapshot.setUpdatedTsp(Instant.now().toEpochMilli());

        snapshotWrapper.setCommonSnapshot(commonSnapshot);

        if(isEv) {
            EvSnapshot evSnapshot = new EvSnapshot();
            SignalSnapshot motorStatus = new SignalSnapshot();
            motorStatus.setValue(2);
            motorStatus.setUpdatedTsp(Instant.now().toEpochMilli());
            motorStatus.setCreatedTsp(Instant.now().toEpochMilli());
            motorStatus.setIncomingTsp(Instant.now().toEpochMilli());
            evSnapshot.setMotorStatus(motorStatus);

            snapshotWrapper.setEvSnapshot(evSnapshot);
        } else {
            IceSnapshot iceSnapshot = new IceSnapshot();
            SignalSnapshot engineSpeed = new SignalSnapshot();
            engineSpeed.setValue(1800);
            engineSpeed.setUpdatedTsp(Instant.now().toEpochMilli());
            engineSpeed.setCreatedTsp(Instant.now().toEpochMilli());
            engineSpeed.setIncomingTsp(Instant.now().toEpochMilli());

            iceSnapshot.setEngineSpeed(engineSpeed);

            snapshotWrapper.setIceSnapshot(iceSnapshot);
        }

        return snapshotWrapper;
    }

    public static void updateIgnitionSignal(Map<String, Set<SignalData>> signals, boolean value, Instant instant) {
        signals.put(SignalCatalogue.getTcuIgnitionInfo().getKey(), SignalGenerator.getBooleanSignals(value, instant));
    }

    public static void updateIgnitionSignal(Telemetry telemetry, boolean value, Instant instant) {
        Map<String, Set<SignalData>> signals = telemetry.getSignals();
        updateIgnitionSignal(signals, value, instant);
        telemetry.setSignals(signals);
    }

    public static void updateIgnitionAlertSignal(Map<String, Set<SignalData>> signals, boolean value) {
        signals.put(SignalCatalogue.getIgnitionAlertInfo().getKey(), SignalGenerator.getBooleanSignals(value));
    }

    public static void updateIgnitionAlertSignal(Telemetry telemetry, boolean value) {
        Map<String, Set<SignalData>> signals = telemetry.getSignals();
        updateIgnitionAlertSignal(signals, value);
        telemetry.setSignals(signals);
    }

    public static void updateMotorSignal(Map<String, Set<SignalData>> signals, double value, Instant instant, int countOfEachSignal) {
        SignalInfo signalInfo = SignalCatalogue.getMotorStatusInfo();
        signals.put(signalInfo.getKey(), SignalGenerator.getSignals(signalInfo, value, instant, countOfEachSignal));
    }

    public static void updateMotorSignal(Telemetry telemetry, double value, Instant instant, int countOfEachSignal) {
        Map<String, Set<SignalData>> signals = telemetry.getSignals();
        updateMotorSignal(signals, value, instant, countOfEachSignal);
        telemetry.setSignals(signals);
    }

    public static void updateEngineSignal(Map<String, Set<SignalData>> signals, double value, Instant instant, int countOfEachSignal) {
        SignalInfo signalInfo = SignalCatalogue.getEngineSpeedInfo();
        signals.put(signalInfo.getKey(), SignalGenerator.getSignals(signalInfo, value, instant, countOfEachSignal));
    }

    public static void updateEngineSignal(Telemetry telemetry, double value, Instant instant, int countOfEachSignal) {
        Map<String, Set<SignalData>> signals = telemetry.getSignals();
        updateEngineSignal(signals, value, instant, countOfEachSignal);
        telemetry.setSignals(signals);
    }

    public static void updateSpeedSignal(Map<String, Set<SignalData>> signals, double value, Instant instant, int countOfEachSignal) {
        SignalInfo vehicleSpeed = SignalCatalogue.getVehicleSpeedDisplayInfo();
        signals.put(vehicleSpeed.getKey(), SignalGenerator.getSignals(vehicleSpeed, value, instant, countOfEachSignal));
    }

    public static void updateSpeedSignal(Telemetry telemetry, double value, Instant instant, int countOfEachSignal) {
        Map<String, Set<SignalData>> signals = telemetry.getSignals();
        updateSpeedSignal(signals, value, instant, countOfEachSignal);
        telemetry.setSignals(signals);
    }

    public static void updateThermalRunawaySignal(Map<String, Set<SignalData>> signals, int value, Instant instant, int countOfEachSignal) {
        SignalInfo thermalRunaway = SignalCatalogue.getThermalRunawayWarningInfo();
        signals.put(thermalRunaway.getKey(), SignalGenerator.getSignalsInteger(value, instant, countOfEachSignal));
    }

    public static void updateThermalRunawaySignal(Telemetry telemetry, int value, Instant instant, int countOfEachSignal) {
        Map<String, Set<SignalData>> signals = telemetry.getSignals();
        updateThermalRunawaySignal(signals, value, instant, countOfEachSignal);
        telemetry.setSignals(signals);
    }

    public static void updateChargingSignal(Map<String, Set<SignalData>> signals, int value, Instant instant, int countOfEachSignal) {
        SignalInfo bmsBduConnectionRequest = SignalCatalogue.getBMSBDUConnectionRequestInfo();
        signals.put(bmsBduConnectionRequest.getKey(), SignalGenerator.getSignalsInteger(value, instant, countOfEachSignal));
    }

    public static void updateChargingSignal(Telemetry telemetry, int value, Instant instant, int countOfEachSignal) {
        Map<String, Set<SignalData>> signals = telemetry.getSignals();
        updateChargingSignal(signals, value, instant, countOfEachSignal);
        telemetry.setSignals(signals);
    }

    public static void updateChargerPluggedSignal(Map<String, Set<SignalData>> signals, Instant instant, int countOfEachSignal) {
        signals.put(SignalCatalogue.getChargerIdentityInfo().getKey(), SignalGenerator.getSignalsInteger(instant, 1, 3, countOfEachSignal));
    }

    public static void updateChargerPluggedSignalBmsBduConn(Map<String, Set<SignalData>> signals, Instant instant, int countOfEachSignal) {
        signals.put(SignalCatalogue.getBMSBDUConnectionRequestInfo().getKey(), SignalGenerator.getSignalsInteger(instant, 1, 1, countOfEachSignal));
    }

    public static void updateChargerPluggedSignal(Telemetry telemetry, Instant instant, int countOfEachSignal) {
        Map<String, Set<SignalData>> signals = telemetry.getSignals();
        updateChargerPluggedSignal(signals, instant, countOfEachSignal);
        telemetry.setSignals(signals);
    }

    public static void updateChargerPluggedSignalBmsBduConn(Telemetry telemetry, Instant instant, int countOfEachSignal) {
        Map<String, Set<SignalData>> signals = telemetry.getSignals();
        updateChargerPluggedSignalBmsBduConn(signals, instant, countOfEachSignal);
        telemetry.setSignals(signals);
    }

    public static void removeSignal(Telemetry telemetry, SignalInfo signalInfo) {
        Map<String, Set<SignalData>> signals = telemetry.getSignals();
        signals.remove(signalInfo.getKey());
        telemetry.setSignals(signals);
    }

    public static EnrichedSnapshot getEnrichedSnapshot(Tenant tenant, long time) {
        EnrichedSnapshot enrichedSnapshot = new EnrichedSnapshot();
        enrichedSnapshot.setVirtualId(VIRTUAL_ID);
        enrichedSnapshot.setTenant(tenant);
        enrichedSnapshot.setTenantId(tenant.value());

        // Set states
        enrichedSnapshot.setConnectionState(StateInfo.builder().time(time).value(ConnectionState.Connected.value()).build());
        enrichedSnapshot.setIgnitionState(StateInfo.builder().time(time).value(IgnitionState.ON.value()).build());
        enrichedSnapshot.setDriveState(StateInfo.builder().time(time).value(DriveState.MOVING.value()).build());
        enrichedSnapshot.setChargingState(StateInfo.builder().time(time).value(ChargingState.NOT_CHARGING.value()).build());

        Map<String, SignalData> latestSignals = new HashMap<>();

        // Set some alerts
        SignalInfo panic = SignalCatalogue.getPanicAlertInfo();
        latestSignals.put(panic.getKey(), SignalGenerator.getSignal(panic, 2.0, time));

        SignalInfo crash = SignalCatalogue.getAccidentAlertInfo();
        latestSignals.put(crash.getKey(), SignalGenerator.getSignalBoolean(false));

        SignalInfo thermalRunaway = SignalCatalogue.getThermalRunawayWarningInfo();
        latestSignals.put(thermalRunaway.getKey(), SignalGenerator.getSignal(thermalRunaway, 5.0, time));

        // Set some common signals
        SignalInfo gpsFix = SignalCatalogue.getGpsFixInfo();
        latestSignals.put(gpsFix.getKey(), SignalGenerator.getSignal(gpsFix, 3.0, time));

        latestSignals.put(SignalCatalogue.getGpsValidInfo().getKey(), SignalGenerator.getSignalBoolean(true, time));

        SignalInfo latitude = SignalCatalogue.getLatitudeInfo();
        latestSignals.put(latitude.getKey(), SignalGenerator.getSignal(latitude, 12.971599, time));

        SignalInfo longitude = SignalCatalogue.getLongitudeInfo();
        latestSignals.put(longitude.getKey(), SignalGenerator.getSignal(longitude, 77.594566, time));

        SignalInfo hDop = SignalCatalogue.getHDopInfo();
        latestSignals.put(hDop.getKey(), SignalGenerator.getSignal(hDop, 1.0, time));

        SignalInfo pDop = SignalCatalogue.getPDopInfo();
        latestSignals.put(pDop.getKey(), SignalGenerator.getSignal(pDop, 5.0, time));

        SignalInfo vDop = SignalCatalogue.getVDopInfo();
        latestSignals.put(vDop.getKey(), SignalGenerator.getSignal(vDop, 5.0, time));
        SignalInfo distanceTravelledWithMilInfo = SignalCatalogue.getDistanceTravelledWithMilInfo();
        latestSignals.put(distanceTravelledWithMilInfo.getKey(), SignalGenerator.getSignal(distanceTravelledWithMilInfo, 5.0, time));
        SignalInfo odometerHr = SignalCatalogue.getOdometerHRInfo();
        latestSignals.put(odometerHr.getKey(), SignalGenerator.getSignal(odometerHr, 120.0, time));
        SignalInfo odometer = SignalCatalogue.getOdometerInfo();
        latestSignals.put(odometer.getKey(), SignalGenerator.getSignal(odometer, 0.0, time));

        SignalData signalData = new SignalData();
        signalData.setTime(time);
        signalData.setDataType("VARCHAR");
        signalData.setValue(UUID.randomUUID().toString());
        latestSignals.put(SignalCatalogue.getUserIdInfo().getKey(),signalData);

        // Some tenant specific signals
        if (tenant.equals(Tenant.EV)) {

            SignalInfo motorStatus = SignalCatalogue.getMotorStatusInfo();
            latestSignals.put(motorStatus.getKey(), SignalGenerator.getSignal(motorStatus, 3.0, time));
        } else {
            SignalInfo vehicleSpeedHighRes = SignalCatalogue.getVehicleSpeedHighResInfo();
            latestSignals.put(vehicleSpeedHighRes.getKey(), SignalGenerator.getSignal(vehicleSpeedHighRes, 60.0, time));
        }

        enrichedSnapshot.setLatestSignals(latestSignals);
        return enrichedSnapshot;
    }

}
