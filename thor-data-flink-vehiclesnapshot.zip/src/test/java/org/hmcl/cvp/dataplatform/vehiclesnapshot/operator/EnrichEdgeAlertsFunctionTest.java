package org.hmcl.cvp.dataplatform.vehiclesnapshot.operator;

import org.apache.flink.runtime.jobgraph.OperatorID;
import org.apache.flink.runtime.metrics.groups.InternalOperatorMetricGroup;
import org.apache.flink.runtime.metrics.util.InterceptingOperatorMetricGroup;
import org.apache.flink.runtime.metrics.util.InterceptingTaskMetricGroup;
import org.apache.flink.runtime.operators.testutils.MockEnvironment;
import org.apache.flink.runtime.operators.testutils.MockEnvironmentBuilder;
import org.apache.flink.runtime.testutils.MiniClusterResourceConfiguration;
import org.apache.flink.streaming.api.operators.StreamFlatMap;
import org.apache.flink.streaming.runtime.streamrecord.StreamRecord;
import org.apache.flink.streaming.util.OneInputStreamOperatorTestHarness;
import org.apache.flink.test.util.MiniClusterWithClientResource;
import org.hmcl.cvp.dataplatform.commons.catalogue.SignalCatalogue;
import org.hmcl.cvp.dataplatform.commons.testdata.CampaignDataGenerator;
import org.hmcl.cvp.dataplatform.commons.utils.GsonUtils;
import org.hmcl.cvp.dataplatform.commons.utils.TelemetryUtils;
import org.hmcl.cvp.dataplatform.contract.telemetry.MultiAlertSignals;
import org.hmcl.cvp.dataplatform.contract.telemetry.SignalData;
import org.hmcl.cvp.dataplatform.contract.telemetry.Telemetry;
import org.hmcl.cvp.dataplatform.vehiclesnapshot.contract.EnrichedSnapshot;
import org.hmcl.cvp.dataplatform.vehiclesnapshot.utils.VehicleStateData;
import org.junit.Assert;
import org.junit.ClassRule;
import org.junit.Test;

import java.time.Instant;
import java.util.*;

public class EnrichEdgeAlertsFunctionTest {

    @ClassRule
    public static MiniClusterWithClientResource flinkCluster =
            new MiniClusterWithClientResource(
                    new MiniClusterResourceConfiguration.Builder()
                            .setNumberSlotsPerTaskManager(2)
                            .setNumberTaskManagers(1)
                            .build());

    private final InterceptingOperatorMetricGroup interceptingOperatorMetricGroup = new InterceptingOperatorMetricGroup();
    private final InterceptingTaskMetricGroup interceptingTaskMetricGroup = new InterceptingTaskMetricGroup() {
        @Override
        public InternalOperatorMetricGroup getOrAddOperator(OperatorID operatorID, String name) {
            return interceptingOperatorMetricGroup;
        }
    };

    private final MockEnvironment mockEnvironment = new MockEnvironmentBuilder().setMetricGroup(interceptingTaskMetricGroup).build();

    private final EnrichEdgeAlertsFunction enrichEdgeAlertsFunction = new EnrichEdgeAlertsFunction();

    private OneInputStreamOperatorTestHarness<String, EnrichedSnapshot> testHarness() throws Exception {
        return new OneInputStreamOperatorTestHarness<>(new StreamFlatMap<>(enrichEdgeAlertsFunction), mockEnvironment);
    }

    @Test
    public void testEnrichEdgeAlertsFunction() {
        try(OneInputStreamOperatorTestHarness<String, EnrichedSnapshot> testHarness = testHarness()) {

            testHarness.setup();
            testHarness.open();

            Telemetry telemetry = CampaignDataGenerator.getTelemetry();

            List<String> alerts1 = new ArrayList<>();
            alerts1.add(MultiAlertSignals.ACCIDENT_CRASH_ALERT_RISE_SIGNAL);
            alerts1.add(MultiAlertSignals.FALLDOWN_ALERT_FALL_SIGNAL);
            SignalData signalData1 = new SignalData();
            signalData1.setDataType("VARCHAR");
            signalData1.setTime(telemetry.getCollectionEventTime());
            signalData1.setValue(GsonUtils.toJson(alerts1));

            List<String> alerts2 = new ArrayList<>();
            alerts2.add(MultiAlertSignals.OVERSPEED_ALERT_RISE_SIGNAL);
            alerts2.add(MultiAlertSignals.AUX_BATTERY_LOW_ALERT_FALL_SIGNAL);
            SignalData signalData2 = new SignalData();
            signalData2.setDataType("VARCHAR");
            signalData2.setTime(telemetry.getCollectionEventTime());
            signalData2.setValue(GsonUtils.toJson(alerts2));

            Set<SignalData> signalDataSet = new HashSet<>();
            signalDataSet.add(signalData1);
            signalDataSet.add(signalData2);

            Map<String, Set<SignalData>> signals = telemetry.getSignals();
            signals.put(SignalCatalogue.getMultiAlertInfo().getKey(), signalDataSet);
            telemetry.setSignals(signals);

            String telemetryJson = TelemetryUtils.toJson(telemetry);
            testHarness.processElement(new StreamRecord<>(telemetryJson));

            List<EnrichedSnapshot> enrichedSnapshotList = VehicleStateData.getOutput(testHarness.getRecordOutput());
            Assert.assertEquals(1, enrichedSnapshotList.size());

            EnrichedSnapshot enrichedSnapshot = enrichedSnapshotList.get(0);
            Set<SignalData> multiAlertSignals = enrichedSnapshot.getMultiAlertsData();
            Assert.assertEquals(2, multiAlertSignals.size());

        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    @Test
    public void testEnrichEdgeAlertsFunction_invalidString() {
        try(OneInputStreamOperatorTestHarness<String, EnrichedSnapshot> testHarness = testHarness()) {

            testHarness.setup();
            testHarness.open();

            String telemetryJson = "test";
            testHarness.processElement(new StreamRecord<>(telemetryJson));

            List<EnrichedSnapshot> enrichedSnapshotList = VehicleStateData.getOutput(testHarness.getRecordOutput());
            Assert.assertEquals(0, enrichedSnapshotList.size());

        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    @Test
    public void testEnrichEdgeAlertsFunction_dimensionsNotPresent() {
        try(OneInputStreamOperatorTestHarness<String, EnrichedSnapshot> testHarness = testHarness()) {

            testHarness.setup();
            testHarness.open();

            Telemetry telemetry = CampaignDataGenerator.getTelemetry();
            telemetry.setDimensions(new HashMap<>());

            String telemetryJson = TelemetryUtils.toJson(telemetry);
            testHarness.processElement(new StreamRecord<>(telemetryJson));

            List<EnrichedSnapshot> enrichedSnapshotList = VehicleStateData.getOutput(testHarness.getRecordOutput());
            Assert.assertEquals(0, enrichedSnapshotList.size());

        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    @Test
    public void testEnrichEdgeAlertsFunction_signalsNotPresent() {
        try(OneInputStreamOperatorTestHarness<String, EnrichedSnapshot> testHarness = testHarness()) {

            testHarness.setup();
            testHarness.open();

            Telemetry telemetry = CampaignDataGenerator.getTelemetry();
            telemetry.setSignals(new HashMap<>());

            String telemetryJson = TelemetryUtils.toJson(telemetry);
            testHarness.processElement(new StreamRecord<>(telemetryJson));

            List<EnrichedSnapshot> enrichedSnapshotList = VehicleStateData.getOutput(testHarness.getRecordOutput());
            Assert.assertEquals(0, enrichedSnapshotList.size());

        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    @Test
    public void testEnrichEdgeAlertsFunction_futureEvent() {
        try(OneInputStreamOperatorTestHarness<String, EnrichedSnapshot> testHarness = testHarness()) {

            testHarness.setup();
            testHarness.open();

            Telemetry telemetry = CampaignDataGenerator.getTelemetry();
            telemetry.setCollectionEventTime(Instant.now().plusSeconds(10).toEpochMilli());
            String telemetryJson = TelemetryUtils.toJson(telemetry);
            testHarness.processElement(new StreamRecord<>(telemetryJson));

            List<EnrichedSnapshot> enrichedSnapshotList = VehicleStateData.getOutput(testHarness.getRecordOutput());
            Assert.assertEquals(0, enrichedSnapshotList.size());

        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

}
