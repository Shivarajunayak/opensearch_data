package org.hmcl.cvp.dataplatform.vehiclesnapshot.operator;

import org.apache.flink.api.common.typeinfo.Types;
import org.apache.flink.streaming.api.operators.StreamFlatMap;
import org.apache.flink.streaming.runtime.streamrecord.StreamRecord;
import org.apache.flink.streaming.util.KeyedOneInputStreamOperatorTestHarness;
import org.hmcl.cvp.dataplatform.contract.connectionstatus.ConnectionStatus;
import org.junit.Assert;
import org.junit.Test;

import java.util.List;

public class OutOfOrderConnectionStatusEventsFilterFunctionTest {
    @Test
    public void processesValidConnectionStatusWithNullState() throws Exception {
        try (KeyedOneInputStreamOperatorTestHarness<String, ConnectionStatus, ConnectionStatus> testHarness =
                     new KeyedOneInputStreamOperatorTestHarness<>(
                             new StreamFlatMap<>(new OutOfOrderConnectionStatusEventsFilterFunction()),
                             ConnectionStatus::getVid,
                             Types.STRING
                     )) {

            testHarness.setup();
            testHarness.open();

            ConnectionStatus connectionStatus = new ConnectionStatus();
            connectionStatus.setTimestamp(1000L);
            connectionStatus.setVid("vid1");

            testHarness.processElement(new StreamRecord<>(connectionStatus));

            List<ConnectionStatus> output = testHarness.extractOutputValues();

            Assert.assertEquals(1, output.size());
            Assert.assertEquals(1000L, output.get(0).getTimestamp());
        }
    }

    @Test
    public void processesValidConnectionStatusWithNonNullState() throws Exception {
        try (KeyedOneInputStreamOperatorTestHarness<String, ConnectionStatus, ConnectionStatus> testHarness =
                     new KeyedOneInputStreamOperatorTestHarness<>(
                             new StreamFlatMap<>(new OutOfOrderConnectionStatusEventsFilterFunction()),
                             ConnectionStatus::getVid,
                             Types.STRING
                     )) {

            testHarness.setup();
            testHarness.open();

            ConnectionStatus firstEvent = new ConnectionStatus();
            firstEvent.setTimestamp(1000L);
            firstEvent.setVid("vid1");

            ConnectionStatus secondEvent = new ConnectionStatus();
            secondEvent.setTimestamp(2000L);
            secondEvent.setVid("vid1");

            testHarness.processElement(new StreamRecord<>(firstEvent));
            testHarness.processElement(new StreamRecord<>(secondEvent));

            List<ConnectionStatus> output = testHarness.extractOutputValues();

            Assert.assertEquals(2, output.size());
            Assert.assertEquals(1000L, output.get(0).getTimestamp());
            Assert.assertEquals(2000L, output.get(1).getTimestamp());
        }
    }


    @Test
    public void acceptsConnectionStatusWithSameTimestamp() throws Exception {
        try (KeyedOneInputStreamOperatorTestHarness<String, ConnectionStatus, ConnectionStatus> testHarness =
                     new KeyedOneInputStreamOperatorTestHarness<>(
                             new StreamFlatMap<>(new OutOfOrderConnectionStatusEventsFilterFunction()),
                             ConnectionStatus::getVid,
                             Types.STRING
                     )) {

            testHarness.setup();
            testHarness.open();

            ConnectionStatus firstConnectionStatus = new ConnectionStatus();
            firstConnectionStatus.setTimestamp(1500L);
            firstConnectionStatus.setVid("vid1");

            ConnectionStatus secondConnectionStatus = new ConnectionStatus();
            secondConnectionStatus.setTimestamp(1500L);
            secondConnectionStatus.setVid("vid1");

            testHarness.processElement(new StreamRecord<>(firstConnectionStatus));
            testHarness.processElement(new StreamRecord<>(secondConnectionStatus));

            List<ConnectionStatus> output = testHarness.extractOutputValues();

            Assert.assertEquals(2, output.size());
            Assert.assertEquals(1500L, output.get(0).getTimestamp());
            Assert.assertEquals(1500L, output.get(0).getTimestamp());

        }
    }

    @Test
    public void ignoresConnectionStatusWithOlderTimestamp() throws Exception {
        try (KeyedOneInputStreamOperatorTestHarness<String, ConnectionStatus, ConnectionStatus> testHarness =
                     new KeyedOneInputStreamOperatorTestHarness<>(
                             new StreamFlatMap<>(new OutOfOrderConnectionStatusEventsFilterFunction()),
                             ConnectionStatus::getVid,
                             Types.STRING
                     )) {

            testHarness.setup();
            testHarness.open();

            ConnectionStatus firstConnectionStatus = new ConnectionStatus();
            firstConnectionStatus.setTimestamp(1000L);
            firstConnectionStatus.setVid("vid1");

            ConnectionStatus secondConnectionStatus = new ConnectionStatus();
            secondConnectionStatus.setTimestamp(500L);
            secondConnectionStatus.setVid("vid1");

            testHarness.processElement(new StreamRecord<>(firstConnectionStatus));
            testHarness.processElement(new StreamRecord<>(secondConnectionStatus));

            List<ConnectionStatus> output = testHarness.extractOutputValues();

            Assert.assertEquals(1, output.size());
            Assert.assertEquals(1000L, output.get(0).getTimestamp());
        }
    }
}
