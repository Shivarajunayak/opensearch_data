package org.hmcl.cvp.dataplatform.vehiclesnapshot.operator;

import org.apache.flink.api.java.tuple.Tuple3;
import org.hmcl.cvp.dataplatform.vehiclesnapshot.contract.SnapshotWrapper;
import org.hmcl.cvp.dataplatform.vehiclesnapshot.helper.VehicleSnapshotHelper;
import org.junit.Test;
import org.mockito.MockedStatic;

import java.util.Map;

import static org.junit.Assert.assertNotNull;
import static org.mockito.Mockito.any;
import static org.mockito.Mockito.anyString;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.mockStatic;
import static org.mockito.Mockito.verify;

public class VehicleSnapshotRedisMapperFunctionTest {

    @Test
    public void snapshotRedisMapper_shouldMapCorrectly() throws Exception {
        // Arrange
        SnapshotRedisMapper mapper = new SnapshotRedisMapper();
        Tuple3<String, String, SnapshotWrapper> input = new Tuple3<>("key1", "key2", new SnapshotWrapper());
        Map<String, Object> mockMap = mock(Map.class);

        try (MockedStatic<VehicleSnapshotHelper> mockedStatic = mockStatic(VehicleSnapshotHelper.class)) {
            mockedStatic.when(() -> VehicleSnapshotHelper.getOpenSearchDocument(anyString(), any(SnapshotWrapper.class))).thenReturn(mockMap);

            // Act
            Map<String, Object> result = mapper.map(input);

            // Assert
            assertNotNull(result);
            verify(mockMap).put("_key", "key2");
        }
    }


    @Test
    public void snapshotRedisMapper_shouldHandleEmptyStrings() throws Exception {
        // Arrange
        SnapshotRedisMapper mapper = new SnapshotRedisMapper();
        Tuple3<String, String, SnapshotWrapper> input = new Tuple3<>("", "", new SnapshotWrapper());
        Map<String, Object> mockMap = mock(Map.class);

        try (MockedStatic<VehicleSnapshotHelper> mockedStatic = mockStatic(VehicleSnapshotHelper.class)) {
            mockedStatic.when(() -> VehicleSnapshotHelper.getOpenSearchDocument(anyString(), any(SnapshotWrapper.class))).thenReturn(mockMap);

            // Act
            Map<String, Object> result = mapper.map(input);

            // Assert
            assertNotNull(result);
            verify(mockMap).put("_key", "");
        }
    }
}