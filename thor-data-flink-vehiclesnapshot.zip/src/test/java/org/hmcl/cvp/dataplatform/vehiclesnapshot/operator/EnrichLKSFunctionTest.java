package org.hmcl.cvp.dataplatform.vehiclesnapshot.operator;

import lombok.extern.slf4j.Slf4j;
import org.apache.flink.api.java.utils.ParameterTool;
import org.apache.flink.runtime.jobgraph.OperatorID;
import org.apache.flink.runtime.metrics.groups.InternalOperatorMetricGroup;
import org.apache.flink.runtime.metrics.util.InterceptingOperatorMetricGroup;
import org.apache.flink.runtime.metrics.util.InterceptingTaskMetricGroup;
import org.apache.flink.runtime.operators.testutils.MockEnvironment;
import org.apache.flink.runtime.operators.testutils.MockEnvironmentBuilder;
import org.apache.flink.runtime.testutils.MiniClusterResourceConfiguration;
import org.apache.flink.streaming.api.operators.StreamFlatMap;
import org.apache.flink.streaming.runtime.streamrecord.StreamRecord;
import org.apache.flink.streaming.util.OneInputStreamOperatorTestHarness;
import org.apache.flink.test.util.MiniClusterWithClientResource;
import org.hmcl.cvp.dataplatform.commons.constants.FlinkRuntime;
import org.hmcl.cvp.dataplatform.commons.testdata.LKSGenerator;
import org.hmcl.cvp.dataplatform.commons.utils.FlinkUtils;
import org.hmcl.cvp.dataplatform.contract.lks.LKSMessage;
import org.hmcl.cvp.dataplatform.contract.lks.MqttUserProperties;
import org.hmcl.cvp.dataplatform.contract.telemetry.Tenant;
import org.hmcl.cvp.dataplatform.vehiclesnapshot.contract.EnrichedSnapshot;
import org.hmcl.cvp.dataplatform.vehiclesnapshot.utils.VehicleStateData;
import org.junit.Assert;
import org.junit.ClassRule;
import org.junit.Test;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Slf4j
public class EnrichLKSFunctionTest {

    @ClassRule
    public static MiniClusterWithClientResource flinkCluster =
            new MiniClusterWithClientResource(
                    new MiniClusterResourceConfiguration.Builder()
                            .setNumberSlotsPerTaskManager(2)
                            .setNumberTaskManagers(1)
                            .build());

    private final InterceptingOperatorMetricGroup interceptingOperatorMetricGroup = new InterceptingOperatorMetricGroup();
    private final InterceptingTaskMetricGroup interceptingTaskMetricGroup = new InterceptingTaskMetricGroup() {
        @Override
        public InternalOperatorMetricGroup getOrAddOperator(OperatorID operatorID, String name) {
            return interceptingOperatorMetricGroup;
        }
    };

    private final MockEnvironment mockEnvironment = new MockEnvironmentBuilder().setMetricGroup(interceptingTaskMetricGroup).build();
    private final EnrichLKSFunction enrichLKSFunction = new EnrichLKSFunction();

    private OneInputStreamOperatorTestHarness<String, EnrichedSnapshot> testHarness() throws Exception {
        ParameterTool parameterTool = ParameterTool.fromMap(new HashMap<>());
        parameterTool = FlinkUtils.addProperties(parameterTool, Map.of(FlinkRuntime.VehicleSnapshot.CAN_SPEED_IN_KM_PER_HOUR, "5.0"));
        parameterTool = FlinkUtils.addProperties(parameterTool, Map.of(FlinkRuntime.VehicleSnapshot.RPM_THRESHOLD_VALUE, "1100.0"));
        mockEnvironment.getExecutionConfig().setGlobalJobParameters(parameterTool);

        return new OneInputStreamOperatorTestHarness<>(new StreamFlatMap<>(enrichLKSFunction), mockEnvironment);
    }

    @Test
    public void testEnrichLKSFunctionTest() {
        try (OneInputStreamOperatorTestHarness<String, EnrichedSnapshot> testHarness = testHarness()) {

            testHarness.setup();
            testHarness.open();

            int numOfEvents = 5;

            List<String> lksData = VehicleStateData.getLKSData(Tenant.EV, numOfEvents);
            List<StreamRecord<String>> streamRecords = VehicleStateData.getStreamRecords(lksData);

            testHarness.processElements(streamRecords);

            List<EnrichedSnapshot> output = VehicleStateData.getOutput(testHarness.getRecordOutput());
            Assert.assertNotEquals(0, output.size());

        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    @Test
    public void testEnrichLKSFunctionTest_noPropertiesPresent() {
        try (OneInputStreamOperatorTestHarness<String, EnrichedSnapshot> testHarness = testHarness()) {

            testHarness.setup();
            testHarness.open();

            LKSMessage lksMessage = LKSGenerator.getLastKnowStateMessage(VehicleStateData.VIRTUAL_ID, Tenant.EV);
            lksMessage.setMqttUserProperties(null);

            List<String> jsonData = VehicleStateData.getJsonData(List.of(lksMessage));
            List<StreamRecord<String>> streamRecords = VehicleStateData.getStreamRecords(jsonData);

            testHarness.processElements(streamRecords);

            List<EnrichedSnapshot> output = VehicleStateData.getOutput(testHarness.getRecordOutput());
            Assert.assertEquals(0, output.size());

        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    @Test
    public void testEnrichLKSFunctionTest_noPropertiesPresentFuturePacket() {
        try (OneInputStreamOperatorTestHarness<String, EnrichedSnapshot> testHarness = testHarness()) {

            testHarness.setup();
            testHarness.open();

            LKSMessage lksMessage = LKSGenerator.getLastKnowStateMessage(VehicleStateData.VIRTUAL_ID, Tenant.EV);
            lksMessage.setMqttUserProperties(null);

            List<String> jsonData = VehicleStateData.getJsonData(List.of(lksMessage));
            List<StreamRecord<String>> streamRecords = VehicleStateData.getStreamRecords(jsonData);
            lksMessage.getLksMessagePayload().setTimeMs(System.currentTimeMillis() + 10000);

            testHarness.processElements(streamRecords);

            List<EnrichedSnapshot> output = VehicleStateData.getOutput(testHarness.getRecordOutput());
            Assert.assertEquals(0, output.size());

        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    @Test
    public void testEnrichLKSFunctionTest_noVID() {
        try (OneInputStreamOperatorTestHarness<String, EnrichedSnapshot> testHarness = testHarness()) {

            testHarness.setup();
            testHarness.open();

            LKSMessage lksMessage = LKSGenerator.getLastKnowStateMessage(VehicleStateData.VIRTUAL_ID, Tenant.EV);
            lksMessage.setMqttUserProperties(List.of(new MqttUserProperties()));

            List<String> jsonData = VehicleStateData.getJsonData(List.of(lksMessage));
            List<StreamRecord<String>> streamRecords = VehicleStateData.getStreamRecords(jsonData);
            lksMessage.getLksMessagePayload().setTimeMs(System.currentTimeMillis() + 10000);

            testHarness.processElements(streamRecords);

            List<EnrichedSnapshot> output = VehicleStateData.getOutput(testHarness.getRecordOutput());
            Assert.assertEquals(0, output.size());

        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    @Test
    public void testEnrichLKSFunctionTest_noPayloadPresent() {
        try (OneInputStreamOperatorTestHarness<String, EnrichedSnapshot> testHarness = testHarness()) {

            testHarness.setup();
            testHarness.open();

            LKSMessage lksMessage = LKSGenerator.getLastKnowStateMessage(VehicleStateData.VIRTUAL_ID, Tenant.EV);
            lksMessage.setLksMessagePayload(null);

            List<String> jsonData = VehicleStateData.getJsonData(List.of(lksMessage));
            List<StreamRecord<String>> streamRecords = VehicleStateData.getStreamRecords(jsonData);

            testHarness.processElements(streamRecords);

            List<EnrichedSnapshot> output = VehicleStateData.getOutput(testHarness.getRecordOutput());
            Assert.assertEquals(0, output.size());

        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

}