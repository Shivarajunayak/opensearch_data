package org.hmcl.cvp.dataplatform.vehiclesnapshot.operator;

import org.apache.flink.runtime.jobgraph.OperatorID;
import org.apache.flink.runtime.metrics.groups.InternalOperatorMetricGroup;
import org.apache.flink.runtime.metrics.util.InterceptingOperatorMetricGroup;
import org.apache.flink.runtime.metrics.util.InterceptingTaskMetricGroup;
import org.apache.flink.runtime.operators.testutils.MockEnvironment;
import org.apache.flink.runtime.operators.testutils.MockEnvironmentBuilder;
import org.apache.flink.runtime.testutils.MiniClusterResourceConfiguration;
import org.apache.flink.streaming.api.operators.StreamFlatMap;
import org.apache.flink.streaming.runtime.streamrecord.StreamRecord;
import org.apache.flink.streaming.util.OneInputStreamOperatorTestHarness;
import org.apache.flink.test.util.MiniClusterWithClientResource;
import org.hmcl.cvp.dataplatform.commons.testdata.CampaignDataGenerator;
import org.hmcl.cvp.dataplatform.contract.telemetry.Telemetry;
import org.hmcl.cvp.dataplatform.vehiclesnapshot.contract.EnrichedSnapshot;
import org.hmcl.cvp.dataplatform.vehiclesnapshot.utils.VehicleStateData;
import org.junit.Assert;
import org.junit.ClassRule;
import org.junit.Test;

import java.util.*;

public class EnrichTelemetryFunctionTest {

    @ClassRule
    public static MiniClusterWithClientResource flinkCluster =
            new MiniClusterWithClientResource(
                    new MiniClusterResourceConfiguration.Builder()
                            .setNumberSlotsPerTaskManager(2)
                            .setNumberTaskManagers(1)
                            .build());

    private final InterceptingOperatorMetricGroup interceptingOperatorMetricGroup = new InterceptingOperatorMetricGroup();
    private final InterceptingTaskMetricGroup interceptingTaskMetricGroup = new InterceptingTaskMetricGroup() {
        @Override
        public InternalOperatorMetricGroup getOrAddOperator(OperatorID operatorID, String name) {
            return interceptingOperatorMetricGroup;
        }
    };

    private final MockEnvironment mockEnvironment = new MockEnvironmentBuilder().setMetricGroup(interceptingTaskMetricGroup).build();

    private final EnrichTelemetryFunction enrichTelemetryFunction = new EnrichTelemetryFunction();

    private OneInputStreamOperatorTestHarness<Telemetry, EnrichedSnapshot> testHarness() throws Exception {
        return new OneInputStreamOperatorTestHarness<>(new StreamFlatMap<>(enrichTelemetryFunction), mockEnvironment);
    }

    @Test
    public void testEnrichEdgeAlertsFunction() {
        try(OneInputStreamOperatorTestHarness<Telemetry, EnrichedSnapshot> testHarness = testHarness()) {

            testHarness.setup();
            testHarness.open();

            Telemetry telemetry = CampaignDataGenerator.getTelemetry();
            testHarness.processElement(new StreamRecord<>(telemetry));

            List<EnrichedSnapshot> enrichedSnapshotList = VehicleStateData.getOutput(testHarness.getRecordOutput());
            Assert.assertEquals(1, enrichedSnapshotList.size());

            EnrichedSnapshot enrichedSnapshot = enrichedSnapshotList.get(0);
            Assert.assertNotEquals(1, enrichedSnapshot.getLatestSignals().size());

        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

}
