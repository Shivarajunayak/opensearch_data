package org.hmcl.cvp.dataplatform.vehiclesnapshot.operator;

import org.apache.flink.api.common.typeinfo.Types;
import org.apache.flink.streaming.api.operators.StreamFlatMap;
import org.apache.flink.streaming.runtime.streamrecord.StreamRecord;
import org.apache.flink.streaming.util.KeyedOneInputStreamOperatorTestHarness;
import org.hmcl.cvp.dataplatform.vehiclesnapshot.contract.EnrichedSnapshot;
import org.junit.Assert;
import org.junit.Test;

import java.util.List;

public class OutOfOrderEnrichedSnapshotFilterFunctionTest {

    @Test
    public void processesValidEventWithNullState() throws Exception {
        try (KeyedOneInputStreamOperatorTestHarness<String, EnrichedSnapshot, EnrichedSnapshot> testHarness =
                     new KeyedOneInputStreamOperatorTestHarness<>(
                             new StreamFlatMap<>(new OutOfOrderEnrichedSnapshotFilterFunction()),
                            EnrichedSnapshot::getVirtualId, // Key selector
                             Types.STRING // Key type information
                     )) {

            testHarness.setup();
            testHarness.open();

            EnrichedSnapshot event = new EnrichedSnapshot();
            event.setVirtualId("vehicle-1");
            event.setLatestEventCollectionTsp(1000L);

            testHarness.processElement(new StreamRecord<>(event));

            List<EnrichedSnapshot> output = testHarness.extractOutputValues();

            Assert.assertEquals(1, output.size());
            Assert.assertEquals(1000L, output.get(0).getLatestEventCollectionTsp());
        }
    }

    @Test
    public void ignoresEventWithOlderTimestamp() throws Exception {
        try (KeyedOneInputStreamOperatorTestHarness<String, EnrichedSnapshot, EnrichedSnapshot> testHarness =
                     new KeyedOneInputStreamOperatorTestHarness<>(
                             new StreamFlatMap<>(new OutOfOrderEnrichedSnapshotFilterFunction()),
                             EnrichedSnapshot::getVirtualId,
                             Types.STRING
                     )) {

            testHarness.setup();
            testHarness.open();

            EnrichedSnapshot firstEvent = new EnrichedSnapshot();
            firstEvent.setVirtualId("vehicle-1");
            firstEvent.setLatestEventCollectionTsp(1000L);

            EnrichedSnapshot secondEvent = new EnrichedSnapshot();
            secondEvent.setVirtualId("vehicle-1");
            secondEvent.setLatestEventCollectionTsp(500L);

            testHarness.processElement(new StreamRecord<>(firstEvent));
            testHarness.processElement(new StreamRecord<>(secondEvent));

            List<EnrichedSnapshot> output = testHarness.extractOutputValues();

            Assert.assertEquals(1, output.size());
            Assert.assertEquals(1000L, output.get(0).getLatestEventCollectionTsp());
        }
    }

    @Test
    public void processesEventWithSameTimestamp() throws Exception {
        try (KeyedOneInputStreamOperatorTestHarness<String, EnrichedSnapshot, EnrichedSnapshot> testHarness =
                     new KeyedOneInputStreamOperatorTestHarness<>(
                             new StreamFlatMap<>(new OutOfOrderEnrichedSnapshotFilterFunction()),
                             EnrichedSnapshot::getVirtualId,
                             Types.STRING
                     )) {

            testHarness.setup();
            testHarness.open();

            EnrichedSnapshot firstEvent = new EnrichedSnapshot();
            firstEvent.setVirtualId("vehicle-1");
            firstEvent.setLatestEventCollectionTsp(1000L);

            EnrichedSnapshot secondEvent = new EnrichedSnapshot();
            secondEvent.setVirtualId("vehicle-1");
            secondEvent.setLatestEventCollectionTsp(1000L);

            testHarness.processElement(new StreamRecord<>(firstEvent));
            testHarness.processElement(new StreamRecord<>(secondEvent));

            List<EnrichedSnapshot> output = testHarness.extractOutputValues();

            Assert.assertEquals(2, output.size());
            Assert.assertEquals(1000L, output.get(0).getLatestEventCollectionTsp());
            Assert.assertEquals(1000L, output.get(0).getLatestEventCollectionTsp());
        }
    }

    @Test
    public void processesEventsInOrder() throws Exception {
        try (KeyedOneInputStreamOperatorTestHarness<String, EnrichedSnapshot, EnrichedSnapshot> testHarness =
                     new KeyedOneInputStreamOperatorTestHarness<>(
                             new StreamFlatMap<>(new OutOfOrderEnrichedSnapshotFilterFunction()),
                             EnrichedSnapshot::getVirtualId,
                             Types.STRING
                     )) {

            testHarness.setup();
            testHarness.open();

            EnrichedSnapshot firstEvent = new EnrichedSnapshot();
            firstEvent.setVirtualId("vehicle-1");
            firstEvent.setLatestEventCollectionTsp(1000L);

            EnrichedSnapshot secondEvent = new EnrichedSnapshot();
            secondEvent.setVirtualId("vehicle-2");
            secondEvent.setLatestEventCollectionTsp(1500L);

            testHarness.processElement(new StreamRecord<>(firstEvent));
            testHarness.processElement(new StreamRecord<>(secondEvent));

            List<EnrichedSnapshot> output = testHarness.extractOutputValues();

            Assert.assertEquals(2, output.size());
            Assert.assertEquals(1000L, output.get(0).getLatestEventCollectionTsp());
            Assert.assertEquals(1500L, output.get(1).getLatestEventCollectionTsp());
        }
    }
}