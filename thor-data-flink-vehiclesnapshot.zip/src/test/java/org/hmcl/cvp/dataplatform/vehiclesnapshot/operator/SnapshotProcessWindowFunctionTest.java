package org.hmcl.cvp.dataplatform.vehiclesnapshot.operator;

import org.apache.flink.api.common.ExecutionConfig;
import org.apache.flink.api.common.state.ListStateDescriptor;
import org.apache.flink.api.common.typeinfo.BasicTypeInfo;
import org.apache.flink.api.common.typeinfo.TypeHint;
import org.apache.flink.api.common.typeinfo.TypeInformation;
import org.apache.flink.api.java.functions.KeySelector;
import org.apache.flink.api.java.utils.ParameterTool;
import org.apache.flink.runtime.jobgraph.OperatorID;
import org.apache.flink.runtime.metrics.groups.InternalOperatorMetricGroup;
import org.apache.flink.runtime.metrics.util.InterceptingOperatorMetricGroup;
import org.apache.flink.runtime.metrics.util.InterceptingTaskMetricGroup;
import org.apache.flink.runtime.operators.testutils.MockEnvironment;
import org.apache.flink.runtime.operators.testutils.MockEnvironmentBuilder;
import org.apache.flink.runtime.testutils.MiniClusterResourceConfiguration;
import org.apache.flink.streaming.api.watermark.Watermark;
import org.apache.flink.streaming.api.windowing.assigners.SlidingEventTimeWindows;
import org.apache.flink.streaming.api.windowing.time.Time;
import org.apache.flink.streaming.api.windowing.triggers.EventTimeTrigger;
import org.apache.flink.streaming.api.windowing.windows.TimeWindow;
import org.apache.flink.streaming.runtime.operators.windowing.WindowOperator;
import org.apache.flink.streaming.runtime.operators.windowing.functions.InternalIterableProcessWindowFunction;
import org.apache.flink.streaming.runtime.streamrecord.StreamRecord;
import org.apache.flink.streaming.util.KeyedOneInputStreamOperatorTestHarness;
import org.apache.flink.streaming.util.OneInputStreamOperatorTestHarness;
import org.apache.flink.test.util.MiniClusterWithClientResource;
import org.hmcl.cvp.dataplatform.commons.catalogue.SignalCatalogue;
import org.hmcl.cvp.dataplatform.commons.constants.FlinkRuntime;
import org.hmcl.cvp.dataplatform.commons.exception.FlinkRuntimeException;
import org.hmcl.cvp.dataplatform.commons.utils.DateUtils;
import org.hmcl.cvp.dataplatform.commons.utils.FlinkUtils;
import org.hmcl.cvp.dataplatform.commons.utils.TelemetryUtils;
import org.hmcl.cvp.dataplatform.contract.telemetry.Telemetry;
import org.hmcl.cvp.dataplatform.contract.telemetry.Tenant;
import org.hmcl.cvp.dataplatform.vehiclesnapshot.contract.DriveState;
import org.hmcl.cvp.dataplatform.vehiclesnapshot.contract.EnrichedSnapshot;
import org.hmcl.cvp.dataplatform.vehiclesnapshot.contract.IgnitionState;
import org.hmcl.cvp.dataplatform.vehiclesnapshot.utils.VehicleStateData;
import org.junit.Assert;
import org.junit.ClassRule;
import org.junit.Test;

import java.time.Instant;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class SnapshotProcessWindowFunctionTest {

    private static final TypeInformation<Telemetry> TELEMETRY_TYPE_INFO = TypeInformation.of(new TypeHint<Telemetry>() {
    });
    @ClassRule
    public static MiniClusterWithClientResource flinkCluster =
            new MiniClusterWithClientResource(
                    new MiniClusterResourceConfiguration.Builder()
                            .setNumberSlotsPerTaskManager(2)
                            .setNumberTaskManagers(1)
                            .build());
    private final InterceptingOperatorMetricGroup interceptingOperatorMetricGroup = new InterceptingOperatorMetricGroup();
    private final InterceptingTaskMetricGroup interceptingTaskMetricGroup = new InterceptingTaskMetricGroup() {
        @Override
        public InternalOperatorMetricGroup getOrAddOperator(OperatorID operatorID, String name) {
            return interceptingOperatorMetricGroup;
        }
    };
    private final MockEnvironment mockEnvironment = new MockEnvironmentBuilder().setMetricGroup(interceptingTaskMetricGroup).build();
    private final KeySelector<Telemetry, String> telemetryKeySelector = TelemetryUtils::getVirtualId;
    private final SnapshotProcessWindowFunction processWindowFunction = new SnapshotProcessWindowFunction();
    ListStateDescriptor<Telemetry> stateDesc = new ListStateDescriptor<>("window-contents", TELEMETRY_TYPE_INFO.createSerializer(new ExecutionConfig()));

    private OneInputStreamOperatorTestHarness<Telemetry, EnrichedSnapshot> testHarness(int windowDuration) throws Exception {
        ParameterTool parameterTool = ParameterTool.fromMap(new HashMap<>());
        parameterTool = FlinkUtils.addProperties(parameterTool, Map.of(FlinkRuntime.MAX_OUT_OF_ORDER_IN_SEC, "30"));
        parameterTool = FlinkUtils.addProperties(parameterTool, Map.of(FlinkRuntime.IDLE_TIMEOUT_IN_SEC, "5"));
        parameterTool = FlinkUtils.addProperties(parameterTool, Map.of(FlinkRuntime.VehicleSnapshot.WINDOW_DURATION, String.valueOf(windowDuration)));
        parameterTool = FlinkUtils.addProperties(parameterTool, Map.of(FlinkRuntime.VehicleSnapshot.CAN_SPEED_IN_KM_PER_HOUR, "5.0"));
        parameterTool = FlinkUtils.addProperties(parameterTool, Map.of(FlinkRuntime.VehicleSnapshot.RPM_THRESHOLD_VALUE, "1100.0"));
        mockEnvironment.getExecutionConfig().setGlobalJobParameters(parameterTool);

        WindowOperator<String, Telemetry, Iterable<Telemetry>, EnrichedSnapshot, TimeWindow> operator = new WindowOperator<>(
                SlidingEventTimeWindows.of(Time.seconds(windowDuration + 1), Time.seconds(windowDuration)),
                new TimeWindow.Serializer(),
                telemetryKeySelector,
                BasicTypeInfo.STRING_TYPE_INFO.createSerializer(new ExecutionConfig()),
                stateDesc,
                new InternalIterableProcessWindowFunction<>(processWindowFunction),
                EventTimeTrigger.create(), 0L, null);

        return new KeyedOneInputStreamOperatorTestHarness<>(operator, telemetryKeySelector, BasicTypeInfo.STRING_TYPE_INFO, mockEnvironment);
    }

    private OneInputStreamOperatorTestHarness<Telemetry, EnrichedSnapshot> testHarness() throws Exception {
        return testHarness(30);
    }

    @Test
    public void testSnapshotProcessWindowFunction_vehicleMoving() {
        int numOfEvents = 4;
        int countOfEachSignal = 1;

        try (OneInputStreamOperatorTestHarness<Telemetry, EnrichedSnapshot> testHarness = testHarness()) {

            testHarness.setup();
            testHarness.open();

            Instant instant = Instant.now();
            long currentTime = DateUtils.currentEpochTime();
            testHarness.setProcessingTime(currentTime);
            testHarness.processWatermark(currentTime);

            List<Telemetry> data = VehicleStateData.getVehicleSnapshotTelemetries(Tenant.EV, instant, false, numOfEvents, countOfEachSignal);
            for (Telemetry telemetry : data) {
                VehicleStateData.updateIgnitionSignal(telemetry, true, instant);
                VehicleStateData.updateMotorSignal(telemetry, VehicleStateData.MOTOR_ON_SIGNAL, instant, countOfEachSignal);
                VehicleStateData.updateEngineSignal(telemetry, VehicleStateData.RPM, instant, countOfEachSignal);
                VehicleStateData.updateSpeedSignal(telemetry, VehicleStateData.SPEED, instant, countOfEachSignal);
                VehicleStateData.updateChargingSignal(telemetry, 3, instant, countOfEachSignal);
                VehicleStateData.removeSignal(telemetry, SignalCatalogue.getChargerIdentityInfo());
            }

            List<StreamRecord<Telemetry>> streamRecords = VehicleStateData.getTelemetryStreamRecords(data);

            long waterTime = data.get(0).getCollectionEventTime();
            testHarness.processWatermark(waterTime);
            testHarness.setProcessingTime(waterTime);

            testHarness.processElements(streamRecords);

            currentTime = currentTime + 30000;
            testHarness.processWatermark(new Watermark(currentTime + 35000));

            List<EnrichedSnapshot> output = VehicleStateData.getOutput(testHarness.getRecordOutput());
            Assert.assertEquals(1, output.size());

            EnrichedSnapshot enrichedSnapshot = output.get(0);

            Assert.assertNotNull(enrichedSnapshot.getDriveState());
            Assert.assertEquals(DriveState.MOVING.value(), enrichedSnapshot.getDriveState().getValue());

            Assert.assertNotNull(enrichedSnapshot.getIgnitionState());
            Assert.assertEquals(IgnitionState.ON.value(), enrichedSnapshot.getIgnitionState().getValue());

            
        } catch (Exception e) {
            throw new FlinkRuntimeException(e);
        }
    }

    @Test
    public void testSnapshotProcessWindowFunction_vehicleMovingAtFourKmHr() {
        int numOfEvents = 4;
        int countOfEachSignal = 1;
        try (OneInputStreamOperatorTestHarness<Telemetry, EnrichedSnapshot> testHarness = testHarness()) {

            testHarness.setup();
            testHarness.open();

            Instant instant = Instant.now();
            long currentTime = DateUtils.currentEpochTime();
            testHarness.setProcessingTime(currentTime);
            testHarness.processWatermark(currentTime);

            List<Telemetry> data = VehicleStateData.getVehicleSnapshotTelemetries(Tenant.EV, instant, false, numOfEvents, countOfEachSignal);
            for (Telemetry telemetry : data) {
                VehicleStateData.updateSpeedSignal(telemetry, 4.0, instant, 1);
                VehicleStateData.updateIgnitionSignal(telemetry, true, instant);
                VehicleStateData.updateMotorSignal(telemetry, 1, instant, countOfEachSignal);
                VehicleStateData.updateEngineSignal(telemetry, 1000, instant, countOfEachSignal);
                VehicleStateData.updateChargingSignal(telemetry, 3, instant, countOfEachSignal);
                VehicleStateData.updateChargingSignal(telemetry, 3, instant, countOfEachSignal);
                VehicleStateData.removeSignal(telemetry, SignalCatalogue.getChargerIdentityInfo());
            }

            List<StreamRecord<Telemetry>> streamRecords = VehicleStateData.getTelemetryStreamRecords(data);

            long waterTime = data.get(0).getCollectionEventTime();
            testHarness.processWatermark(waterTime);
            testHarness.setProcessingTime(waterTime);

            testHarness.processElements(streamRecords);

            currentTime = currentTime + 30000;
            testHarness.processWatermark(new Watermark(currentTime + 35000));

            List<EnrichedSnapshot> output = VehicleStateData.getOutput(testHarness.getRecordOutput());
            Assert.assertEquals(1, output.size());

            EnrichedSnapshot enrichedSnapshot = output.get(0);

            Assert.assertNotNull(enrichedSnapshot.getDriveState());
            Assert.assertEquals(DriveState.IDLE.value(), enrichedSnapshot.getDriveState().getValue());

            Assert.assertNotNull(enrichedSnapshot.getIgnitionState());
            Assert.assertEquals(IgnitionState.ON.value(), enrichedSnapshot.getIgnitionState().getValue());

            
        } catch (Exception e) {
            throw new FlinkRuntimeException(e);
        }
    }

    @Test
    public void testSnapshotProcessWindowFunction_ignitionAndMotorEngineOff() {
        int numOfEvents = 4;
        int countOfEachSignal = 1;
        try (OneInputStreamOperatorTestHarness<Telemetry, EnrichedSnapshot> testHarness = testHarness()) {

            testHarness.setup();
            testHarness.open();

            Instant instant = Instant.now();
            long currentTime = DateUtils.currentEpochTime();
            testHarness.setProcessingTime(currentTime);
            testHarness.processWatermark(currentTime);

            List<Telemetry> data = VehicleStateData.getVehicleSnapshotTelemetries(Tenant.EV, instant, false, numOfEvents, countOfEachSignal);
            for (Telemetry telemetry : data) {
                VehicleStateData.updateIgnitionSignal(telemetry, false, instant);
                VehicleStateData.updateMotorSignal(telemetry, 1.0, instant, 2);
                VehicleStateData.updateChargingSignal(telemetry, 3, instant, countOfEachSignal);
                VehicleStateData.removeSignal(telemetry, SignalCatalogue.getChargerIdentityInfo());
            }

            List<StreamRecord<Telemetry>> streamRecords = VehicleStateData.getTelemetryStreamRecords(data);

            long waterTime = data.get(0).getCollectionEventTime();
            testHarness.processWatermark(waterTime);
            testHarness.setProcessingTime(waterTime);

            testHarness.processElements(streamRecords);

            currentTime = currentTime + 30000;
            testHarness.processWatermark(new Watermark(currentTime + 35000));

            List<EnrichedSnapshot> output = VehicleStateData.getOutput(testHarness.getRecordOutput());
            Assert.assertEquals(1, output.size());

            EnrichedSnapshot enrichedSnapshot = output.get(0);

            Assert.assertNotNull(enrichedSnapshot.getDriveState());
            Assert.assertEquals(DriveState.STOPPED.value(), enrichedSnapshot.getDriveState().getValue());

            Assert.assertNotNull(enrichedSnapshot.getIgnitionState());
            Assert.assertEquals(IgnitionState.OFF.value(), enrichedSnapshot.getIgnitionState().getValue());

            
        } catch (Exception e) {
            throw new FlinkRuntimeException(e);
        }
    }

    @Test
    public void testSnapshotProcessWindowFunction_notCharging() {
        int numOfEvents = 4;
        int countOfEachSignal = 1;

        try (OneInputStreamOperatorTestHarness<Telemetry, EnrichedSnapshot> testHarness = testHarness()) {

            testHarness.setup();
            testHarness.open();

            Instant instant = Instant.now();
            long currentTime = DateUtils.currentEpochTime();
            testHarness.setProcessingTime(currentTime);
            testHarness.processWatermark(currentTime);

            List<Telemetry> data = VehicleStateData.getVehicleSnapshotTelemetries(Tenant.EV, instant, false, numOfEvents, countOfEachSignal);
            for (Telemetry telemetry : data) {
                VehicleStateData.updateSpeedSignal(telemetry, 4.0, instant, 1);
                VehicleStateData.updateIgnitionSignal(telemetry, true, instant);
                VehicleStateData.updateMotorSignal(telemetry, 1, instant, countOfEachSignal);
                VehicleStateData.updateEngineSignal(telemetry, 1000, instant, countOfEachSignal);
                VehicleStateData.updateChargingSignal(telemetry, 3, instant, countOfEachSignal);
                VehicleStateData.removeSignal(telemetry, SignalCatalogue.getChargerIdentityInfo());
            }

            List<StreamRecord<Telemetry>> streamRecords = VehicleStateData.getTelemetryStreamRecords(data);

            long waterTime = data.get(0).getCollectionEventTime();
            testHarness.processWatermark(waterTime);
            testHarness.setProcessingTime(waterTime);

            testHarness.processElements(streamRecords);

            currentTime = currentTime + 30000;
            testHarness.processWatermark(new Watermark(currentTime + 35000));

            List<EnrichedSnapshot> output = VehicleStateData.getOutput(testHarness.getRecordOutput());
            Assert.assertEquals(1, output.size());

            EnrichedSnapshot enrichedSnapshot = output.get(0);

            Assert.assertNotNull(enrichedSnapshot.getDriveState());
            Assert.assertEquals(DriveState.IDLE.value(), enrichedSnapshot.getDriveState().getValue());

            Assert.assertNotNull(enrichedSnapshot.getIgnitionState());
            Assert.assertEquals(IgnitionState.ON.value(), enrichedSnapshot.getIgnitionState().getValue());

            
        } catch (Exception e) {
            throw new FlinkRuntimeException(e);
        }
    }
}
