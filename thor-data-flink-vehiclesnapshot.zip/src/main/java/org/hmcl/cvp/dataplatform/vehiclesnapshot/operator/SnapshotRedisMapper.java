package org.hmcl.cvp.dataplatform.vehiclesnapshot.operator;

import org.apache.flink.api.common.functions.MapFunction;
import org.apache.flink.api.java.tuple.Tuple3;
import org.hmcl.cvp.dataplatform.vehiclesnapshot.contract.SnapshotWrapper;
import org.hmcl.cvp.dataplatform.vehiclesnapshot.helper.VehicleSnapshotHelper;

import java.util.Map;

public class SnapshotRedisMapper implements MapFunction<Tuple3<String, String, SnapshotWrapper>, Map<String, Object>> {

    @Override
    public Map<String, Object> map(Tuple3<String, String, SnapshotWrapper> value) throws Exception {
        // getOpenSearchDocument function only converts POJO to Hashmap, nothing OS specific
        Map<String, Object> redisEntry = VehicleSnapshotHelper.getOpenSearchDocument(value.f1, value.f2);
        redisEntry.put("_key", value.f1);
        return redisEntry;
    }
}
