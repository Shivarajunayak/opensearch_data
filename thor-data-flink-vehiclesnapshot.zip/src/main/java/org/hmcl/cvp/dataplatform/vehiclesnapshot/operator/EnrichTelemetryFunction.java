package org.hmcl.cvp.dataplatform.vehiclesnapshot.operator;

import lombok.extern.slf4j.Slf4j;
import org.apache.flink.api.common.functions.RichFlatMapFunction;
import org.apache.flink.configuration.Configuration;
import org.apache.flink.metrics.Counter;
import org.apache.flink.util.Collector;
import org.hmcl.cvp.dataplatform.commons.constants.Constants;
import org.hmcl.cvp.dataplatform.commons.utils.TelemetryUtils;
import org.hmcl.cvp.dataplatform.contract.telemetry.SignalData;
import org.hmcl.cvp.dataplatform.contract.telemetry.Telemetry;
import org.hmcl.cvp.dataplatform.contract.telemetry.Tenant;
import org.hmcl.cvp.dataplatform.vehiclesnapshot.contract.EnrichedSnapshot;
import org.hmcl.cvp.dataplatform.vehiclesnapshot.contract.Source;
import org.hmcl.cvp.dataplatform.vehiclesnapshot.helper.VehicleSnapshotHelper;

import java.util.*;

@Slf4j
public class EnrichTelemetryFunction extends RichFlatMapFunction<Telemetry, EnrichedSnapshot> {

    private transient Counter numInputCounter;
    private transient Counter numErrorCounter;

    private Counter counterInitializer(String counterName) {
        return getRuntimeContext()
                .getMetricGroup()
                .addGroup(Constants.METRIC_GROUP_NAME)
                .addGroup("EnrichTelemetry")
                .counter(counterName);
    }

    @Override
    public void open(Configuration parameters) throws Exception {
        super.open(parameters);
        numInputCounter = counterInitializer("numInputEvents");
        numErrorCounter = counterInitializer("numErrorEvents");
    }

    @Override
    public void flatMap(Telemetry value, Collector<EnrichedSnapshot> out) {
        try {
            numInputCounter.inc();

            String vid = TelemetryUtils.getVirtualId(value);
            String tenantId = TelemetryUtils.getTenantId(value);

            Tenant tenant = TelemetryUtils.getTenant(value);

            EnrichedSnapshot enrichedSnapshot = new EnrichedSnapshot();
            enrichedSnapshot.setVirtualId(vid);
            enrichedSnapshot.setVehicleName(value.getVehicleName());
            enrichedSnapshot.setTenant(tenant);
            enrichedSnapshot.setTenantId(tenantId);
            enrichedSnapshot.setSource(Source.TELEMETRY_OR_CHARGING);
            enrichedSnapshot.setLatestSignals(getLatestSignals(value));
            enrichedSnapshot.setLatestEventCollectionTsp(value.getCollectionEventTime());

            VehicleSnapshotHelper.setChargingState(vid, enrichedSnapshot, value);

            out.collect(enrichedSnapshot);

        } catch (Exception e) {
            log.error("Exception while processing edge alerts data {}", value, e);
            numErrorCounter.inc();
        }
    }

    private Map<String, SignalData> getLatestSignals(Telemetry telemetry) {
        Map<String, SignalData> latestSignalData = new HashMap<>();
        Map<String, Set<SignalData>> signals = telemetry.getSignals();
        signals.forEach((k, v) -> {
            Optional<SignalData> latestSignal = v.stream().max(Comparator.comparing(SignalData::getTime));
            latestSignal.ifPresent(signalData -> latestSignalData.put(k, signalData));
        });

        return latestSignalData;
    }

}
