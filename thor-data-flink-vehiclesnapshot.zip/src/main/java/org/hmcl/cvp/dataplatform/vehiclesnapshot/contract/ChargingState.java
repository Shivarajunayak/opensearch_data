package org.hmcl.cvp.dataplatform.vehiclesnapshot.contract;

import com.google.gson.annotations.SerializedName;

import java.util.HashMap;
import java.util.Map;

public enum ChargingState {

    @SerializedName("Charging")
    CHARGING("Charging"),

    @SerializedName("Not Charging")
    NOT_CHARGING("Not Charging");


    private static final Map<String, ChargingState> CONSTANTS = new HashMap<>();

    static {
        for (ChargingState c : values()) {
            CONSTANTS.put(c.value, c);
        }
    }

    private final String value;

    ChargingState(String value) {
        this.value = value;
    }

    public static ChargingState fromValue(String value) {
        ChargingState constant = CONSTANTS.get(value);
        if (constant == null) {
            throw new IllegalArgumentException(value);
        } else {
            return constant;
        }
    }

    @Override
    public String toString() {
        return this.value;
    }

    public String value() {
        return this.value;
    }
}
