package org.hmcl.cvp.dataplatform.vehiclesnapshot.operator;

import lombok.extern.slf4j.Slf4j;
import org.apache.flink.api.common.functions.RichFlatMapFunction;
import org.apache.flink.api.common.state.MapState;
import org.apache.flink.api.common.state.MapStateDescriptor;
import org.apache.flink.api.java.tuple.Tuple2;
import org.apache.flink.api.java.tuple.Tuple3;
import org.apache.flink.api.java.utils.ParameterTool;
import org.apache.flink.configuration.Configuration;
import org.apache.flink.metrics.Counter;
import org.apache.flink.util.Collector;
import org.hmcl.cvp.dataplatform.commons.catalogue.SignalCatalogue;
import org.hmcl.cvp.dataplatform.commons.constants.Constants;
import org.hmcl.cvp.dataplatform.commons.constants.FlinkRuntime;
import org.hmcl.cvp.dataplatform.commons.utils.DateUtils;
import org.hmcl.cvp.dataplatform.commons.utils.SignalUtils;
import org.hmcl.cvp.dataplatform.contract.telemetry.*;
import org.hmcl.cvp.dataplatform.vehiclesnapshot.contract.*;
import org.hmcl.cvp.dataplatform.vehiclesnapshot.helper.GpsSignalsHelper;

import java.util.*;

// Output is Tuple3<Index, vid, SnapshotWrapper>
@Slf4j
public class VehicleSnapshotMapperFunction extends RichFlatMapFunction<EnrichedSnapshot, Tuple3<String, String, SnapshotWrapper>> {

    private static final int DEFAULT_ALERT_VALUE = 0;

    /**
     * Store the last processed lat-long time for a vehicle
     * Key - VirtualId
     * Value - lat-long time
     * VirtualId -> epoch milliseconds
     */
    private transient MapState<String, SnapshotWrapper> latestSnapshot;

    private transient Counter numInputEventCounter;
    private transient Counter numErrorEventCounter;
    private transient Counter numEvCounter;
    private transient Counter numIceCounter;
    private transient Counter numHarleyCounter;

    private transient String evIndex;
    private transient String iceIndex;
    private transient String harleyIndex;

    private transient Double hDopThresholdValue;

    private Counter counterInitializer(String counterName) {
        return getRuntimeContext()
                .getMetricGroup()
                .addGroup(Constants.METRIC_GROUP_NAME)
                .addGroup("VehicleSnapshot")
                .counter(counterName);
    }

    @Override
    public void open(Configuration parameters) throws Exception {
        super.open(parameters);

        numInputEventCounter = counterInitializer("numInputEvents");
        numErrorEventCounter = counterInitializer("numErrorEvents");
        numEvCounter = counterInitializer("numEvEvents");
        numIceCounter = counterInitializer("numIceEvents");
        numHarleyCounter = counterInitializer("numHarleyEvents");

        // No TTL for this
        MapStateDescriptor<String, SnapshotWrapper> lastProcessedTimeDescriptor = MapStateDescriptors.getLatestSnapshotDescriptor();
        latestSnapshot = getRuntimeContext().getMapState(lastProcessedTimeDescriptor);

        ParameterTool parameterTool = (ParameterTool) getRuntimeContext().getExecutionConfig().getGlobalJobParameters();

        evIndex = parameterTool.getRequired(FlinkRuntime.VehicleSnapshot.SNAPSHOT_INDEX_EV);
        iceIndex = parameterTool.getRequired(FlinkRuntime.VehicleSnapshot.SNAPSHOT_INDEX_ICE);
        harleyIndex = parameterTool.getRequired(FlinkRuntime.VehicleSnapshot.SNAPSHOT_INDEX_HARLEY);

        hDopThresholdValue = parameterTool.getDouble(FlinkRuntime.VALID_HDOP_THRESHOLD_VALUE);

    }

    // Tuple3<Index, vid, map>
    @Override
    public void flatMap(EnrichedSnapshot value, Collector<Tuple3<String, String, SnapshotWrapper>> out) {
        numInputEventCounter.inc();
        long incomingTime = DateUtils.currentEpochTime();
        String incomingVid = value.getVirtualId();

        log.debug("Received mapper request for vehicle {} at {}. This is for LKS? {}", incomingVid,
                incomingTime, value.isLks());

        try {
            String index = getOpenSearchIndex(value.getTenant());

            // Get the latest snapshot from cache
            SnapshotWrapper cachedSnapshot = getLatestSnapshotFromCache(incomingVid);

            log.debug("Cached snapshot {} for vehicle {}", cachedSnapshot, incomingVid);
            log.debug("Incoming snapshot {} for vehicle {}", value, incomingVid);

            Tuple2<Boolean, SnapshotWrapper> updatedSnapshotTuple = getUpdatedSnapshot(incomingVid, value, cachedSnapshot);

            if (Boolean.FALSE.equals(updatedSnapshotTuple.f0)) {
                log.debug("No updates found for vehicle {}. So ignoring the incoming.", incomingVid);
                return;
            }

            SnapshotWrapper updatedSnapshot = updatedSnapshotTuple.f1;
            updatedSnapshot.setLatestEventCollectionTsp(value.getLatestEventCollectionTsp());
            updatedSnapshot.setIsLks(value.isLks());

            long snapshotUpdatedTime = DateUtils.currentEpochTime();
            long timeTakenToUpdate = snapshotUpdatedTime - incomingTime;
            log.debug("Snapshot was updated for vehicle {} in {}", incomingVid, timeTakenToUpdate);
            updateLatestSnapshot(incomingVid, updatedSnapshot);

            out.collect(new Tuple3<>(index, incomingVid, updatedSnapshot));

        } catch (Exception e) {
            log.error("Error while processing vehicle snapshots for vehicle {}", incomingVid, e);
            numErrorEventCounter.inc();
        }
    }

    private Tuple2<Boolean, SnapshotWrapper> getUpdatedSnapshot(String incomingVid, EnrichedSnapshot incomingEnrichedSnapshot, SnapshotWrapper cachedSnapshot) {
        long currentTime = DateUtils.currentEpochTime();
        CommonSnapshot cachedCommonSnapshot = cachedSnapshot.getCommonSnapshot();

        if (Objects.isNull(cachedCommonSnapshot)) {
            cachedCommonSnapshot = new CommonSnapshot();
            cachedCommonSnapshot.setVid(incomingVid);
            cachedCommonSnapshot.setVehicleName(incomingEnrichedSnapshot.getVehicleName());
            cachedCommonSnapshot.setTenantId(incomingEnrichedSnapshot.getTenantId());
            cachedCommonSnapshot.setCreatedTsp(currentTime);
            cachedCommonSnapshot.setUpdatedTsp(currentTime);
            cachedCommonSnapshot.setUpdatedBySource(incomingEnrichedSnapshot.getSource());
            cachedCommonSnapshot.setUpdatedTspIST(DateUtils.formatToISO(currentTime));
        }

        boolean anyStateValueUpdated = updateStateValues(incomingEnrichedSnapshot, cachedCommonSnapshot, currentTime);

        Map<String, SignalData> latestSignals = incomingEnrichedSnapshot.getLatestSignals();
        if ((Objects.isNull(latestSignals) || latestSignals.isEmpty()) && anyStateValueUpdated) {
            cachedCommonSnapshot.setUpdatedTsp(currentTime);
            cachedCommonSnapshot.setUpdatedBySource(incomingEnrichedSnapshot.getSource());
            cachedCommonSnapshot.setUpdatedTspIST(DateUtils.formatToISO(currentTime));
            cachedSnapshot.setCommonSnapshot(cachedCommonSnapshot);
            return new Tuple2<>(true, cachedSnapshot);
        }

        boolean anyAlertsUpdated = updateAlertValues(incomingEnrichedSnapshot, cachedCommonSnapshot, currentTime);

        boolean anyCommonSignalsUpdated = updateCommonSignalValues(incomingVid, latestSignals, cachedCommonSnapshot, currentTime);

        Tenant tenant = incomingEnrichedSnapshot.getTenant();
        boolean anyTenantSpecificSignalsUpdated = updateTenantSpecificSignals(incomingVid, tenant, latestSignals, cachedSnapshot, currentTime);

        boolean cacheUpdated = anyStateValueUpdated || anyAlertsUpdated || anyCommonSignalsUpdated || anyTenantSpecificSignalsUpdated;
        if (cacheUpdated) {
            cachedCommonSnapshot.setUpdatedTsp(currentTime);
            cachedCommonSnapshot.setUpdatedBySource(incomingEnrichedSnapshot.getSource());
            cachedCommonSnapshot.setUpdatedTspIST(DateUtils.formatToISO(currentTime));
            cachedSnapshot.setCommonSnapshot(cachedCommonSnapshot);
        }
        return new Tuple2<>(cacheUpdated, cachedSnapshot);
    }

    private boolean updateStateValues(EnrichedSnapshot incomingEnrichedSnapshot, CommonSnapshot cachedCommonSnapshot, long currentTime) {

        boolean updated = updateCloudAlertValues(incomingEnrichedSnapshot, cachedCommonSnapshot, currentTime);

        // Connection state
        LatestValue latestConnectionState = getLatestStateValue(incomingEnrichedSnapshot.getConnectionState(), cachedCommonSnapshot.getConnectionStatus(), currentTime);
        if (latestConnectionState.isLatest()) {
            updated = true;
            cachedCommonSnapshot.setConnectionStatus(latestConnectionState.getSignalSnapshot());
        }

        // Charging state
        LatestValue latestChargingState = getLatestStateValue(incomingEnrichedSnapshot.getChargingState(), cachedCommonSnapshot.getChargingStatus(), currentTime);
        if (latestChargingState.isLatest()) {
            updated = true;
            cachedCommonSnapshot.setChargingStatus(latestChargingState.getSignalSnapshot());
        }

        // Driving state
        LatestValue latestDrivingState = getLatestStateValue(incomingEnrichedSnapshot.getDriveState(), cachedCommonSnapshot.getDriveStatus(), currentTime);
        if (latestDrivingState.isLatest()) {
            updated = true;
            cachedCommonSnapshot.setDriveStatus(latestDrivingState.getSignalSnapshot());
        }

        // Ignition state
        LatestValue latestIgnitionState = getLatestStateValue(incomingEnrichedSnapshot.getIgnitionState(), cachedCommonSnapshot.getIgnitionStatus(), currentTime);
        if (latestIgnitionState.isLatest()) {
            updated = true;
            cachedCommonSnapshot.setIgnitionStatus(latestIgnitionState.getSignalSnapshot());
        }

        return updated;
    }

    private boolean updateCloudAlertValues(EnrichedSnapshot incomingEnrichedSnapshot, CommonSnapshot cachedCommonSnapshot, long currentTime) {

        boolean updated = false;

        // GeoFence state
        LatestValue latestGeoFenceAlert = getLatestStateValue(incomingEnrichedSnapshot.getGeoFenceAlert(), cachedCommonSnapshot.getGeoFenceAlert(), currentTime);
        if (latestGeoFenceAlert.isLatest()) {
            updated = true;
            cachedCommonSnapshot.setGeoFenceAlert(latestGeoFenceAlert.getSignalSnapshot());
        }

        return updated;
    }

    private boolean updateAlertValues(EnrichedSnapshot enrichedSnapshot, CommonSnapshot cachedCommonSnapshot, long currentTime) {
        boolean updated = updateMultiAlertsFields(enrichedSnapshot.getMultiAlertsData(), cachedCommonSnapshot, currentTime);

        Map<String, SignalData> latestSignals = enrichedSnapshot.getLatestSignals();

        // Thermal runaway
        LatestValue thermalRunaway = getLatestAlertValue(latestSignals, SignalCatalogue.getThermalRunawayWarningInfo(), cachedCommonSnapshot.getThermalRunaway(), currentTime);
        if (thermalRunaway.isLatest()) {
            // Set to 1 only when signal value is 5
            SignalSnapshot thermalRunawaySnapshot = thermalRunaway.getSignalSnapshot();
            if ((int) thermalRunawaySnapshot.getValue() == 5) {
                thermalRunawaySnapshot.setValue(1);
            } else {
                thermalRunawaySnapshot.setValue(0);
            }
            cachedCommonSnapshot.setThermalRunaway(thermalRunawaySnapshot);
            updated = true;
        }

        // Battery overheating
        LatestValue batteryOverHeating = getLatestAlertValue(latestSignals, SignalCatalogue.getThermalRunawayWarningInfo(), cachedCommonSnapshot.getBatteryOverHeating(), currentTime);
        if (batteryOverHeating.isLatest()) {
            // Set to 1 only when signal value is 3
            SignalSnapshot thermalRunawaySnapshot = batteryOverHeating.getSignalSnapshot();
            if ((int) thermalRunawaySnapshot.getValue() == 3) {
                thermalRunawaySnapshot.setValue(1);
            } else {
                thermalRunawaySnapshot.setValue(0);
            }
            cachedCommonSnapshot.setBatteryOverHeating(thermalRunawaySnapshot);
            updated = true;
        }

        return updated;

    }

    private boolean updateMultiAlertsFields(Set<SignalData> multiAlertsSignalData, CommonSnapshot cachedCommonSnapshot, long currentTime) {
        if(Objects.isNull(multiAlertsSignalData) || multiAlertsSignalData.isEmpty()) return false;

        Set<MultiAlertEvent> multiAlertEvents = SignalUtils.getMultiAlertValues(multiAlertsSignalData);
        if(multiAlertsSignalData.isEmpty()) return false;

        boolean updated = false;

        List<String> latestAuxBatteryLowSignals = List.of(
                MultiAlertSignals.AUX_BATTERY_LOW_ALERT_RISE_SIGNAL.toLowerCase(),
                MultiAlertSignals.AUX_BATTERY_LOW_ALERT_FALL_SIGNAL.toLowerCase()
        );
        LatestValue latestAuxBatteryLow = getLatestMultiAlertValue(multiAlertEvents, latestAuxBatteryLowSignals, cachedCommonSnapshot.getAuxBatteryLow(), currentTime);
        if (latestAuxBatteryLow.isLatest()) {
            cachedCommonSnapshot.setAuxBatteryLow(latestAuxBatteryLow.getSignalSnapshot());
            updated = true;
        }

        List<String> auxBatteryUnPluggedAlertSignals = List.of(
                MultiAlertSignals.AUX_BATTERY_UNPLUGGED_ALERT_RISE_SIGNAL.toLowerCase(),
                MultiAlertSignals.AUX_BATTERY_UNPLUGGED_ALERT_FALL_SIGNAL.toLowerCase()
        );
        LatestValue auxBatteryUnPluggedAlert = getLatestMultiAlertValue(multiAlertEvents, auxBatteryUnPluggedAlertSignals, cachedCommonSnapshot.getAuxBatteryUnplugged(), currentTime);
        if (auxBatteryUnPluggedAlert.isLatest()) {
            cachedCommonSnapshot.setAuxBatteryUnplugged(auxBatteryUnPluggedAlert.getSignalSnapshot());
            updated = true;
        }

        List<String> crashAlertSignals = List.of(
                MultiAlertSignals.ACCIDENT_CRASH_ALERT_RISE_SIGNAL.toLowerCase(),
                MultiAlertSignals.ACCIDENT_CRASH_ALERT_FALL_SIGNAL.toLowerCase()
        );
        LatestValue crashAlert = getLatestMultiAlertValue(multiAlertEvents, crashAlertSignals, cachedCommonSnapshot.getCrashAndAccident(), currentTime);
        if (crashAlert.isLatest()) {
            cachedCommonSnapshot.setCrashAndAccident(crashAlert.getSignalSnapshot());
            updated = true;
        }

        List<String> fallDownAlertSignals = List.of(
                MultiAlertSignals.FALLDOWN_ALERT_RISE_SIGNAL.toLowerCase(),
                MultiAlertSignals.FALLDOWN_ALERT_FALL_SIGNAL.toLowerCase()
        );
        LatestValue fallDownAlert = getLatestMultiAlertValue(multiAlertEvents, fallDownAlertSignals, cachedCommonSnapshot.getFallDown(), currentTime);
        if (fallDownAlert.isLatest()) {
            cachedCommonSnapshot.setFallDown(fallDownAlert.getSignalSnapshot());
            updated = true;
        }

        List<String> harshDrivingSignals = List.of(
                MultiAlertSignals.HARSH_ACCELERATION_ALERT_RISE_SIGNAL.toLowerCase(),
                MultiAlertSignals.HARSH_ACCELERATION_ALERT_FALL_SIGNAL.toLowerCase()
        );
        LatestValue harshDriving = getLatestMultiAlertValue(multiAlertEvents, harshDrivingSignals, cachedCommonSnapshot.getHarshDriving(), currentTime);
        if (harshDriving.isLatest()) {
            cachedCommonSnapshot.setHarshDriving(harshDriving.getSignalSnapshot());
            updated = true;
        }

        List<String> harshBrakingSignals = List.of(
                MultiAlertSignals.HARSH_BRAKING_ALERT_RISE_SIGNAL.toLowerCase(),
                MultiAlertSignals.HARSH_BRAKING_ALERT_FALL_SIGNAL.toLowerCase()
        );
        LatestValue harshBraking = getLatestMultiAlertValue(multiAlertEvents, harshBrakingSignals, cachedCommonSnapshot.getHarshBraking(), currentTime);
        if (harshBraking.isLatest()) {
            cachedCommonSnapshot.setHarshBraking(harshBraking.getSignalSnapshot());
            updated = true;
        }

        List<String> movementSignals = List.of(
                MultiAlertSignals.MOVEMENT_ALERT_RISE_SIGNAL.toLowerCase(),
                MultiAlertSignals.MOVEMENT_ALERT_FALL_SIGNAL.toLowerCase()
        );
        LatestValue movement = getLatestMultiAlertValue(multiAlertEvents, movementSignals, cachedCommonSnapshot.getMovementDetection(), currentTime);
        if (movement.isLatest()) {
            cachedCommonSnapshot.setMovementDetection(movement.getSignalSnapshot());
            updated = true;
        }

        List<String> overSpeedSignals = List.of(
                MultiAlertSignals.OVERSPEED_ALERT_RISE_SIGNAL.toLowerCase(),
                MultiAlertSignals.OVERSPEED_ALERT_FALL_SIGNAL.toLowerCase()
        );
        LatestValue overSpeed = getLatestMultiAlertValue(multiAlertEvents, overSpeedSignals, cachedCommonSnapshot.getOverSpeed(), currentTime);
        if (overSpeed.isLatest()) {
            cachedCommonSnapshot.setOverSpeed(overSpeed.getSignalSnapshot());
            updated = true;
        }

        List<String> panicSignals = List.of(
                MultiAlertSignals.PANIC_ALERT_RISE_SIGNAL.toLowerCase(),
                MultiAlertSignals.PANIC_ALERT_FALL_SIGNAL.toLowerCase()
        );
        LatestValue panic = getLatestMultiAlertValue(multiAlertEvents, panicSignals, cachedCommonSnapshot.getPanic(), currentTime);
        if (panic.isLatest()) {
            cachedCommonSnapshot.setPanic(panic.getSignalSnapshot());
            updated = true;
        }

        List<String> towTheftSignals = List.of(
                MultiAlertSignals.TOW_THEFT_ALERT_RISE_SIGNAL.toLowerCase(),
                MultiAlertSignals.TOW_THEFT_ALERT_FALL_SIGNAL.toLowerCase()
        );
        LatestValue towTheft = getLatestMultiAlertValue(multiAlertEvents, towTheftSignals, cachedCommonSnapshot.getTowOrTheft(), currentTime);
        if (towTheft.isLatest()) {
            cachedCommonSnapshot.setTowOrTheft(towTheft.getSignalSnapshot());
            updated = true;
        }

        List<String> dtcMILAlertSignals = List.of(
                MultiAlertSignals.DTC_MIL_ALERT_FALL_SIGNAL.toLowerCase(),
                MultiAlertSignals.DTC_MIL_ALERT_RISE_SIGNAL.toLowerCase()
        );
        LatestValue dtcMilAlert = getLatestMultiAlertValue(multiAlertEvents, dtcMILAlertSignals, cachedCommonSnapshot.getDtc(), currentTime);
        if (dtcMilAlert.isLatest()) {
            cachedCommonSnapshot.setDtc(dtcMilAlert.getSignalSnapshot());
            updated = true;
        }

        return updated;
    }

    private LatestValue getLatestMultiAlertValue(Set<MultiAlertEvent> multiAlertEvents, List<String> signals, SignalSnapshot signalSnapshot, long currentTime) {
        MultiAlertEvent multiAlertEvent = multiAlertEvents.stream()
                .filter(m -> Objects.nonNull(m.getAlertSignal()))
                .filter(m -> signals.contains(m.getAlertSignal().toLowerCase()))
                .max(Comparator.comparing(MultiAlertEvent::getTimestamp))
                .orElse(null);

        return getLatestMultiAlertValue(multiAlertEvent, signalSnapshot, currentTime);
    }

    private boolean updateCommonSignalValues(String incomingVid, Map<String, SignalData> latestSignals, CommonSnapshot cachedCommonSnapshot, long currentTime) {

        // All GPS related signals
        boolean updated = updateGpsRelatedSignalValues(incomingVid, latestSignals, cachedCommonSnapshot, currentTime);

        LatestValue bleConnectivity = getLatestSignalValue(latestSignals, SignalCatalogue.getBLEConnectivityInfo(), cachedCommonSnapshot.getBleConnectivity(), currentTime);
        if (bleConnectivity.isLatest()) {
            cachedCommonSnapshot.setBleConnectivity(bleConnectivity.getSignalSnapshot());
            updated = true;
        }

        LatestValue immoState = getLatestSignalValue(latestSignals, SignalCatalogue.getImmoStateInfo(), cachedCommonSnapshot.getImmoState(), currentTime);
        if (immoState.isLatest()) {
            cachedCommonSnapshot.setImmoState(immoState.getSignalSnapshot());
            updated = true;
        }

        LatestValue mainVoltage = getLatestSignalValue(latestSignals, SignalCatalogue.getTcuMainVoltageInfo(), cachedCommonSnapshot.getMainVoltage(), currentTime);
        if (mainVoltage.isLatest()) {
            cachedCommonSnapshot.setMainVoltage(mainVoltage.getSignalSnapshot());
            updated = true;
        }

        LatestValue odoSignal = getLatestSignalValue(latestSignals, SignalCatalogue.getOdometerInfo(), cachedCommonSnapshot.getOdoSignal(), currentTime);
        if (odoSignal.isLatest() && Double.parseDouble(odoSignal.getSignalSnapshot().getValue().toString()) > 0) {
            cachedCommonSnapshot.setOdoSignal(odoSignal.getSignalSnapshot());
            updated = true;
        }

        LatestValue riderInfoUserId = getLatestSignalValue(latestSignals, SignalCatalogue.getUserIdInfo(), cachedCommonSnapshot.getRiderInfoUserId(), currentTime);
        if (riderInfoUserId.isLatest()) {
            cachedCommonSnapshot.setRiderInfoUserId(riderInfoUserId.getSignalSnapshot());
            updated = true;
        }

        LatestValue riderInfoUserType = getLatestSignalValue(latestSignals, SignalCatalogue.getUserProfileInfo(), cachedCommonSnapshot.getRiderInfoUserType(), currentTime);
        if (riderInfoUserType.isLatest()) {
            cachedCommonSnapshot.setRiderInfoUserType(riderInfoUserType.getSignalSnapshot());
            updated = true;
        }

        LatestValue tcuIgnition = getLatestSignalValue(latestSignals, SignalCatalogue.getTcuIgnitionInfo(), cachedCommonSnapshot.getTcuIgnition(), currentTime);
        if (tcuIgnition.isLatest()) {
            cachedCommonSnapshot.setTcuIgnition(tcuIgnition.getSignalSnapshot());
            updated = true;
        }

        return updated;
    }

    private boolean updateGpsRelatedSignalValues(String incomingVid, Map<String, SignalData> latestSignals, CommonSnapshot cachedCommonSnapshot, long currentTime) {
        boolean updated = false;

        LatestValue gpsFix = getLatestSignalValue(latestSignals, SignalCatalogue.getGpsFixInfo(), cachedCommonSnapshot.getGpsFix(), currentTime);
        LatestValue gpsValid = getLatestSignalValue(latestSignals, SignalCatalogue.getGpsValidInfo(), cachedCommonSnapshot.getGpsValid(), currentTime);
        LatestValue hDop = getLatestSignalValue(latestSignals, SignalCatalogue.getHDopInfo(), cachedCommonSnapshot.getHDop(), currentTime);

        try {
            if(!GpsSignalsHelper.isGpsSignalsValid(incomingVid, gpsFix, hDop, hDopThresholdValue, gpsValid)) {
                log.debug("Incoming GPS signals are invalid for vehicle {}", incomingVid);
                return false;
            }
        } catch (Exception e) {
            log.error("Exception while checking for gps validity for vehicle {}", incomingVid, e);
            return false;
        }

        log.debug("Incoming GPS signals are valid for vehicle {}", incomingVid);

        if (gpsFix.isLatest()) {
            cachedCommonSnapshot.setGpsFix(gpsFix.getSignalSnapshot());
            updated = true;
        }

        if (gpsValid.isLatest()) {
            cachedCommonSnapshot.setGpsValid(gpsValid.getSignalSnapshot());
            updated = true;
        }

        if (hDop.isLatest()) {
            cachedCommonSnapshot.setHDop(hDop.getSignalSnapshot());
            updated = true;
        }

        LatestValue latitude = getLatestSignalValue(latestSignals, SignalCatalogue.getLatitudeInfo(), cachedCommonSnapshot.getLatitude(), currentTime);
        if (latitude.isLatest()) {
            cachedCommonSnapshot.setLatitude(latitude.getSignalSnapshot());
            updated = true;
        }

        LatestValue longitude = getLatestSignalValue(latestSignals, SignalCatalogue.getLongitudeInfo(), cachedCommonSnapshot.getLongitude(), currentTime);
        if (longitude.isLatest()) {
            cachedCommonSnapshot.setLongitude(longitude.getSignalSnapshot());
            updated = true;
        }

        LatestValue pDop = getLatestSignalValue(latestSignals, SignalCatalogue.getPDopInfo(), cachedCommonSnapshot.getPDop(), currentTime);
        if (pDop.isLatest()) {
            cachedCommonSnapshot.setPDop(pDop.getSignalSnapshot());
            updated = true;
        }

        LatestValue vDop = getLatestSignalValue(latestSignals, SignalCatalogue.getVDopInfo(), cachedCommonSnapshot.getVDop(), currentTime);
        if (vDop.isLatest()) {
            cachedCommonSnapshot.setVDop(vDop.getSignalSnapshot());
            updated = true;
        }

        LatestValue cog = getLatestSignalValue(latestSignals, SignalCatalogue.getCogInfo(), cachedCommonSnapshot.getCog(), currentTime);
        if (cog.isLatest()) {
            cachedCommonSnapshot.setCog(cog.getSignalSnapshot());
            updated = true;
        }

        log.debug("GPS signals updated? {} for vehicle {}", updated, incomingVid);
        return updated;
    }

    private boolean updateTenantSpecificSignals(String incomingVid, Tenant tenant, Map<String, SignalData> latestSignals, SnapshotWrapper cachedSnapshot, long currentTime) {
        boolean anyTenantSpecificSignalsUpdated;
        if (Tenant.EV.equals(tenant)) {
            EvSnapshot cachedEvSnapshot = cachedSnapshot.getEvSnapshot();
            if (Objects.isNull(cachedEvSnapshot)) cachedEvSnapshot = new EvSnapshot();
            anyTenantSpecificSignalsUpdated = updateEvSignalValues(latestSignals, cachedEvSnapshot, currentTime);

            if (anyTenantSpecificSignalsUpdated) {
                cachedSnapshot.setIsEv(true);
                cachedSnapshot.setEvSnapshot(cachedEvSnapshot);
                log.debug("Ev signals updated for vehicle {}", incomingVid);
            }
        } else {
            IceSnapshot cachedIceSnapshot = cachedSnapshot.getIceSnapshot();
            if (Objects.isNull(cachedIceSnapshot)) cachedIceSnapshot = new IceSnapshot();
            anyTenantSpecificSignalsUpdated = updateIceSignalValues(latestSignals, cachedIceSnapshot, currentTime);

            if (anyTenantSpecificSignalsUpdated) {
                cachedSnapshot.setIsEv(false);
                cachedSnapshot.setIceSnapshot(cachedIceSnapshot);
                log.debug("Ice signals updated for vehicle {}", incomingVid);
            }
        }

        return anyTenantSpecificSignalsUpdated;
    }

    private boolean updateEvSignalValues(Map<String, SignalData> latestSignals, EvSnapshot cachedEvSnapshot, long currentTime) {

        // Charging and battery related signals
        boolean updated = updateEvBatteryAndChargeRelatedSignals(latestSignals, cachedEvSnapshot, currentTime);

        LatestValue brakeInputSignal = getLatestSignalValue(latestSignals, SignalCatalogue.getBrakeStatusInfo(), cachedEvSnapshot.getBrakeInputSignal(), currentTime);
        if (brakeInputSignal.isLatest()) {
            cachedEvSnapshot.setBrakeInputSignal(brakeInputSignal.getSignalSnapshot());
            updated = true;
        }

        LatestValue cruiseControlState = getLatestSignalValue(latestSignals, SignalCatalogue.getCruiseControlInfo(), cachedEvSnapshot.getCruiseControlState(), currentTime);
        if (cruiseControlState.isLatest()) {
            cachedEvSnapshot.setCruiseControlState(cruiseControlState.getSignalSnapshot());
            updated = true;
        }

        LatestValue driveModeSignal = getLatestSignalValue(latestSignals, SignalCatalogue.getDrivingModeInfo(), cachedEvSnapshot.getDriveModeSignal(), currentTime);
        if (driveModeSignal.isLatest()) {
            cachedEvSnapshot.setDriveModeSignal(driveModeSignal.getSignalSnapshot());
            updated = true;
        }

        LatestValue motorStatus = getLatestSignalValue(latestSignals, SignalCatalogue.getMotorStatusInfo(), cachedEvSnapshot.getMotorStatus(), currentTime);
        if (motorStatus.isLatest()) {
            cachedEvSnapshot.setMotorStatus(motorStatus.getSignalSnapshot());
            updated = true;
        }

        LatestValue odoSignalHr = getLatestSignalValue(latestSignals, SignalCatalogue.getOdometerHRInfo(), cachedEvSnapshot.getOdoSignalHr(), currentTime);
        if (odoSignalHr.isLatest() && Double.parseDouble(odoSignalHr.getSignalSnapshot().getValue().toString()) > 0) {
            cachedEvSnapshot.setOdoSignalHr(odoSignalHr.getSignalSnapshot());
            updated = true;
        }

        LatestValue readyStatus = getLatestSignalValue(latestSignals, SignalCatalogue.getMotorStatusInfo(), cachedEvSnapshot.getReadyStatus(), currentTime);
        if (readyStatus.isLatest()) {
            cachedEvSnapshot.setReadyStatus(readyStatus.getSignalSnapshot());
            updated = true;
        }

        LatestValue remainingRangeInKm = getLatestSignalValue(latestSignals, SignalCatalogue.getRemainingRangeInfo(), cachedEvSnapshot.getRemainingRangeInKm(), currentTime);
        if (remainingRangeInKm.isLatest()) {
            cachedEvSnapshot.setRemainingRangeInKm(remainingRangeInKm.getSignalSnapshot());
            updated = true;
        }

        LatestValue sideStand = getLatestSignalValue(latestSignals, SignalCatalogue.getSideStandStatusInfo(), cachedEvSnapshot.getSideStand(), currentTime);
        if (sideStand.isLatest()) {
            cachedEvSnapshot.setSideStand(sideStand.getSignalSnapshot());
            updated = true;
        }

        LatestValue socUserBms1 = getLatestSignalValue(latestSignals, SignalCatalogue.getSocUserBMS1Info(), cachedEvSnapshot.getSocUserBms1(), currentTime);
        if (socUserBms1.isLatest()) {
            cachedEvSnapshot.setSocUserBms1(socUserBms1.getSignalSnapshot());
            updated = true;
        }

        LatestValue socUserBms2 = getLatestSignalValue(latestSignals, SignalCatalogue.getSocUserBMS2Info(), cachedEvSnapshot.getSocUserBms2(), currentTime);
        if (socUserBms2.isLatest()) {
            cachedEvSnapshot.setSocUserBms2(socUserBms2.getSignalSnapshot());
            updated = true;
        }

        LatestValue socUser = getLatestSignalValue(latestSignals, SignalCatalogue.getSocUserPercentageInfo(), cachedEvSnapshot.getSocUser(), currentTime);
        if (socUser.isLatest()) {
            cachedEvSnapshot.setSocUser(socUser.getSignalSnapshot());
            updated = true;
        }

        LatestValue throttle = getLatestSignalValue(latestSignals, SignalCatalogue.getThrottlePercentageInfo(), cachedEvSnapshot.getThrottle(), currentTime);
        if (throttle.isLatest()) {
            cachedEvSnapshot.setThrottle(throttle.getSignalSnapshot());
            updated = true;
        }

        LatestValue vehicleSpeedDisplay = getLatestSignalValue(latestSignals, SignalCatalogue.getVehicleSpeedDisplayInfo(), cachedEvSnapshot.getVehicleSpeedDisplay(), currentTime);
        if (vehicleSpeedDisplay.isLatest()) {
            cachedEvSnapshot.setVehicleSpeedDisplay(vehicleSpeedDisplay.getSignalSnapshot());
            updated = true;
        }

        LatestValue idBMS1 = getLatestSignalValue(latestSignals, SignalCatalogue.getBMS1Id(), cachedEvSnapshot.getIdBMS1(), currentTime);
        if (idBMS1.isLatest()) {
            cachedEvSnapshot.setIdBMS1(idBMS1.getSignalSnapshot());
            updated = true;
        }

        LatestValue idBMS2 = getLatestSignalValue(latestSignals, SignalCatalogue.getBMS2Id(), cachedEvSnapshot.getIdBMS2(), currentTime);
        if (idBMS2.isLatest()) {
            cachedEvSnapshot.setIdBMS2(idBMS2.getSignalSnapshot());
            updated = true;
        }

        return updated;
    }

    private boolean updateEvBatteryAndChargeRelatedSignals(Map<String, SignalData> latestSignals, EvSnapshot cachedEvSnapshot, long currentTime) {
        boolean updated = updateEvChargeRelatedSignals(latestSignals, cachedEvSnapshot, currentTime);

        LatestValue batteryDetection = getLatestSignalValue(latestSignals, SignalCatalogue.getBatteryDetectionInfo(), cachedEvSnapshot.getBatteryDetection(), currentTime);
        if (batteryDetection.isLatest()) {
            cachedEvSnapshot.setBatteryDetection(batteryDetection.getSignalSnapshot());
            updated = true;
        }

        LatestValue batterySlotIdentityFront = getLatestSignalValue(latestSignals, SignalCatalogue.getBatterySlotIdentityFrontInfo(), cachedEvSnapshot.getBatterySlotIdentityFront(), currentTime);
        if (batterySlotIdentityFront.isLatest()) {
            cachedEvSnapshot.setBatterySlotIdentityFront(batterySlotIdentityFront.getSignalSnapshot());
            updated = true;
        }

        LatestValue batterySlotIdentityRear = getLatestSignalValue(latestSignals, SignalCatalogue.getBatterySlotIdentityRearInfo(), cachedEvSnapshot.getBatterySlotIdentityRear(), currentTime);
        if (batterySlotIdentityRear.isLatest()) {
            cachedEvSnapshot.setBatterySlotIdentityRear(batterySlotIdentityRear.getSignalSnapshot());
            updated = true;
        }

        LatestValue batteryChargingStatus = getLatestSignalValue(latestSignals, SignalCatalogue.getBatteryChargingStatusInfo(), cachedEvSnapshot.getBatteryChargingStatus(), currentTime);
        if (batteryChargingStatus.isLatest()) {
            cachedEvSnapshot.setBatteryChargingStatus(batteryChargingStatus.getSignalSnapshot());
            updated = true;
        }

        LatestValue batteryOperationModeBms1 = getLatestSignalValue(latestSignals, SignalCatalogue.getBMS1BatteryOperationModeInfo(), cachedEvSnapshot.getBatteryOperationModeBms1(), currentTime);
        if (batteryOperationModeBms1.isLatest()) {
            cachedEvSnapshot.setBatteryOperationModeBms1(batteryOperationModeBms1.getSignalSnapshot());
            updated = true;
        }

        LatestValue batteryOperationModeBms2 = getLatestSignalValue(latestSignals, SignalCatalogue.getBMS2BatteryOperationModeInfo(), cachedEvSnapshot.getBatteryOperationModeBms2(), currentTime);
        if (batteryOperationModeBms2.isLatest()) {
            cachedEvSnapshot.setBatteryOperationModeBms2(batteryOperationModeBms2.getSignalSnapshot());
            updated = true;
        }

        LatestValue bms1BatteryPackTemperature = getLatestSignalValue(latestSignals, SignalCatalogue.getBMS1BatteryPackTempInfo(),
                cachedEvSnapshot.getBms1BatteryPackTemperature(), currentTime);
        if (bms1BatteryPackTemperature.isLatest()) {
            cachedEvSnapshot.setBms1BatteryPackTemperature(bms1BatteryPackTemperature.getSignalSnapshot());
            updated = true;
        }

        LatestValue bms2BatteryPackTemperature = getLatestSignalValue(latestSignals, SignalCatalogue.getBMS2BatteryPackTempInfo(),
                cachedEvSnapshot.getBms2BatteryPackTemperature(), currentTime);
        if (bms2BatteryPackTemperature.isLatest()) {
            cachedEvSnapshot.setBms2BatteryPackTemperature(bms2BatteryPackTemperature.getSignalSnapshot());
            updated = true;
        }

        LatestValue bmsBduStatus = getLatestSignalValue(latestSignals, SignalCatalogue.getBMSBDUStatusInfo(), cachedEvSnapshot.getBmsBduStatus(), currentTime);
        if (bmsBduStatus.isLatest()) {
            cachedEvSnapshot.setBmsBduStatus(bmsBduStatus.getSignalSnapshot());
            updated = true;
        }

        LatestValue bmsBduConnectionRequest = getLatestSignalValue(latestSignals, SignalCatalogue.getBMSBDUConnectionRequestInfo(), cachedEvSnapshot.getBmsBduConnectionRequest(), currentTime);
        if (bmsBduConnectionRequest.isLatest()) {
            cachedEvSnapshot.setBmsBduConnectionRequest(bmsBduConnectionRequest.getSignalSnapshot());
            updated = true;
        }

        LatestValue bmsChargeStartRequest = getLatestSignalValue(latestSignals, SignalCatalogue.getBMSChargeStartRequestInfo(),
                cachedEvSnapshot.getBmsChargeStartRequest(), currentTime);
        if (bmsChargeStartRequest.isLatest()) {
            cachedEvSnapshot.setBmsChargeStartRequest(bmsChargeStartRequest.getSignalSnapshot());
            updated = true;
        }

        LatestValue bmsStatus = getLatestSignalValue(latestSignals, SignalCatalogue.getBMSStatusInfo(), cachedEvSnapshot.getBmsStatus(), currentTime);
        if (bmsStatus.isLatest()) {
            cachedEvSnapshot.setBmsStatus(bmsStatus.getSignalSnapshot());
            updated = true;
        }

        LatestValue bms1SohPercentage = getLatestSignalValue(latestSignals, SignalCatalogue.getBMS1SohPercentage(), cachedEvSnapshot.getBms1SohPercentage(), currentTime);
        if (bms1SohPercentage.isLatest()) {
            cachedEvSnapshot.setBms1SohPercentage(bms1SohPercentage.getSignalSnapshot());
            updated = true;
        }

        LatestValue bms2SohPercentage = getLatestSignalValue(latestSignals, SignalCatalogue.getBMS2SohPercentage(), cachedEvSnapshot.getBms2SohPercentage(), currentTime);
        if (bms2SohPercentage.isLatest()) {
            cachedEvSnapshot.setBms2SohPercentage(bms2SohPercentage.getSignalSnapshot());
            updated = true;
        }

        return updated;
    }

    private boolean updateEvChargeRelatedSignals(Map<String, SignalData> latestSignals, EvSnapshot cachedEvSnapshot, long currentTime) {
        boolean updated = updateEvChargingEnergyRelatedSignals(latestSignals, cachedEvSnapshot, currentTime);

        LatestValue chargeCurrentSet = getLatestSignalValue(latestSignals, SignalCatalogue.getChargeCurrentSetInfo(), cachedEvSnapshot.getChargeCurrentSet(), currentTime);
        if (chargeCurrentSet.isLatest()) {
            cachedEvSnapshot.setChargeCurrentSet(chargeCurrentSet.getSignalSnapshot());
            updated = true;
        }

        LatestValue chargerIdentity = getLatestSignalValue(latestSignals, SignalCatalogue.getChargerIdentityInfo(), cachedEvSnapshot.getChargerIdentity(), currentTime);
        if (chargerIdentity.isLatest()) {
            cachedEvSnapshot.setChargerIdentity(chargerIdentity.getSignalSnapshot());
            updated = true;
        }

        LatestValue chargerPowerState = getLatestSignalValue(latestSignals, SignalCatalogue.getChargerPowerStateInfo(), cachedEvSnapshot.getChargerPowerState(), currentTime);
        if (chargerPowerState.isLatest()) {
            cachedEvSnapshot.setChargerPowerState(chargerPowerState.getSignalSnapshot());
            updated = true;
        }

        LatestValue chargerStatus = getLatestSignalValue(latestSignals, SignalCatalogue.getChargerStatusInfo(), cachedEvSnapshot.getChargerStatus(), currentTime);
        if (chargerStatus.isLatest()) {
            cachedEvSnapshot.setChargerStatus(chargerStatus.getSignalSnapshot());
            updated = true;
        }

        LatestValue chargerState = getLatestSignalValue(latestSignals, SignalCatalogue.getChargerStateInfo(), cachedEvSnapshot.getChargerState(), currentTime);
        if (chargerState.isLatest()) {
            cachedEvSnapshot.setChargerState(chargerState.getSignalSnapshot());
            updated = true;
        }

        LatestValue chargerVoltageSet = getLatestSignalValue(latestSignals, SignalCatalogue.getChargerVoltageSetInfo(), cachedEvSnapshot.getChargerVoltageSet(), currentTime);
        if (chargerVoltageSet.isLatest()) {
            cachedEvSnapshot.setChargerVoltageSet(chargerVoltageSet.getSignalSnapshot());
            updated = true;
        }

        LatestValue cutOffCurrent = getLatestSignalValue(latestSignals, SignalCatalogue.getCutOffCurrentInfo(), cachedEvSnapshot.getCutOffCurrent(), currentTime);
        if (cutOffCurrent.isLatest()) {
            cachedEvSnapshot.setCutOffCurrent(cutOffCurrent.getSignalSnapshot());
            updated = true;
        }

        LatestValue estimatedChargingTime = getLatestSignalValue(latestSignals, SignalCatalogue.getEstimatedChargingTimeInfo(), cachedEvSnapshot.getEstimatedChargingTime(), currentTime);
        if (estimatedChargingTime.isLatest()) {
            cachedEvSnapshot.setEstimatedChargingTime(estimatedChargingTime.getSignalSnapshot());
            updated = true;
        }

        LatestValue packCurrent = getLatestSignalValue(latestSignals, SignalCatalogue.getPackCurrentInfo(), cachedEvSnapshot.getPackCurrent(), currentTime);
        if (packCurrent.isLatest()) {
            cachedEvSnapshot.setPackCurrent(packCurrent.getSignalSnapshot());
            updated = true;
        }

        LatestValue packVoltage = getLatestSignalValue(latestSignals, SignalCatalogue.getPackVoltageInfo(), cachedEvSnapshot.getPackVoltage(), currentTime);
        if (packVoltage.isLatest()) {
            cachedEvSnapshot.setPackVoltage(packVoltage.getSignalSnapshot());
            updated = true;
        }

        LatestValue preChargeCurrent = getLatestSignalValue(latestSignals, SignalCatalogue.getPreChargeCurrentInfo(), cachedEvSnapshot.getPreChargeCurrent(), currentTime);
        if (preChargeCurrent.isLatest()) {
            cachedEvSnapshot.setPreChargeCurrent(preChargeCurrent.getSignalSnapshot());
            updated = true;
        }

        LatestValue remainingCapacity = getLatestSignalValue(latestSignals, SignalCatalogue.getRemainingCapacityInfo(), cachedEvSnapshot.getRemainingCapacity(), currentTime);
        if (remainingCapacity.isLatest()) {
            cachedEvSnapshot.setRemainingCapacity(remainingCapacity.getSignalSnapshot());
            updated = true;
        }

        LatestValue satelliteInUse = getLatestSignalValue(latestSignals, SignalCatalogue.getSatelliteInUseInfo(), cachedEvSnapshot.getSatelliteInUse(), currentTime);
        if (satelliteInUse.isLatest()) {
            cachedEvSnapshot.setSatelliteInUse(satelliteInUse.getSignalSnapshot());
            updated = true;
        }

        LatestValue satelliteInView = getLatestSignalValue(latestSignals, SignalCatalogue.getSatelliteInViewInfo(), cachedEvSnapshot.getSatelliteInView(), currentTime);
        if (satelliteInView.isLatest()) {
            cachedEvSnapshot.setSatelliteInView(satelliteInView.getSignalSnapshot());
            updated = true;
        }

        return updated;

    }

    private boolean updateEvChargingEnergyRelatedSignals(Map<String, SignalData> latestSignals, EvSnapshot cachedEvSnapshot, long currentTime) {
        boolean updated = false;

        LatestValue temperatureStatusVcu = getLatestSignalValue(latestSignals, SignalCatalogue.getTemperatureStatusVCUInfo(), cachedEvSnapshot.getTemperatureStatusVcu(), currentTime);
        if (temperatureStatusVcu.isLatest()) {
            cachedEvSnapshot.setTemperatureStatusVcu(temperatureStatusVcu.getSignalSnapshot());
            updated = true;
        }

        LatestValue thermalRunStatusAggregate = getLatestSignalValue(latestSignals, SignalCatalogue.getThermalRunStatusAggregateInfo(), cachedEvSnapshot.getThermalRunStatusAggregate(), currentTime);
        if (thermalRunStatusAggregate.isLatest()) {
            cachedEvSnapshot.setThermalRunStatusAggregate(thermalRunStatusAggregate.getSignalSnapshot());
            updated = true;
        }

        LatestValue thermalRunawayWarning = getLatestSignalValue(latestSignals, SignalCatalogue.getThermalRunawayWarningInfo(), cachedEvSnapshot.getThermalRunawayWarning(), currentTime);
        if (thermalRunawayWarning.isLatest()) {
            cachedEvSnapshot.setThermalRunawayWarning(thermalRunawayWarning.getSignalSnapshot());
            updated = true;
        }

        LatestValue totalUsableCapacity = getLatestSignalValue(latestSignals, SignalCatalogue.getTotalUsableCapacityInfo(), cachedEvSnapshot.getTotalUsableCapacity(), currentTime);
        if (totalUsableCapacity.isLatest()) {
            cachedEvSnapshot.setTotalUsableCapacity(totalUsableCapacity.getSignalSnapshot());
            updated = true;
        }

        LatestValue totalUsableEnergy = getLatestSignalValue(latestSignals, SignalCatalogue.getTotalUsableEnergyInfo(), cachedEvSnapshot.getTotalUsableEnergy(), currentTime);
        if (totalUsableEnergy.isLatest()) {
            cachedEvSnapshot.setTotalUsableEnergy(totalUsableEnergy.getSignalSnapshot());
            updated = true;
        }

        LatestValue totalUsableEnergyBms1 = getLatestSignalValue(latestSignals, SignalCatalogue.getTotalUsableEnergyBMS1Info(), cachedEvSnapshot.getTotalUsableEnergyBms1(), currentTime);
        if (totalUsableEnergyBms1.isLatest()) {
            cachedEvSnapshot.setTotalUsableEnergyBms1(totalUsableEnergyBms1.getSignalSnapshot());
            updated = true;
        }

        LatestValue totalUsableEnergyBms2 = getLatestSignalValue(latestSignals, SignalCatalogue.getTotalUsableEnergyBMS2Info(), cachedEvSnapshot.getTotalUsableEnergyBms2(), currentTime);
        if (totalUsableEnergyBms2.isLatest()) {
            cachedEvSnapshot.setTotalUsableEnergyBms2(totalUsableEnergyBms2.getSignalSnapshot());
            updated = true;
        }

        return updated;
    }

    private boolean updateIceSignalValues(Map<String, SignalData> latestSignals, IceSnapshot cachedIceSnapshot, long currentTime) {
        boolean updated = false;

        LatestValue engineSpeed = getLatestSignalValue(latestSignals, SignalCatalogue.getEngineSpeedInfo(), cachedIceSnapshot.getEngineSpeed(), currentTime);
        if (engineSpeed.isLatest()) {
            cachedIceSnapshot.setEngineSpeed(engineSpeed.getSignalSnapshot());
            updated = true;
        }

        LatestValue engineRunStatus = getLatestSignalValue(latestSignals, SignalCatalogue.getEngineRunStatusInfo(), cachedIceSnapshot.getEngineRunStatus(), currentTime);
        if (engineRunStatus.isLatest()) {
            cachedIceSnapshot.setEngineRunStatus(engineRunStatus.getSignalSnapshot());
            updated = true;
        }

        LatestValue engineTemperature = getLatestSignalValue(latestSignals, SignalCatalogue.getEngineTemperatureInfo(), cachedIceSnapshot.getEngineTemperature(), currentTime);
        if (engineTemperature.isLatest()) {
            cachedIceSnapshot.setEngineTemperature(engineTemperature.getSignalSnapshot());
            updated = true;
        }

        LatestValue fuelLevel = getLatestSignalValue(latestSignals, SignalCatalogue.getFuelLevelInfo(), cachedIceSnapshot.getFuelLevel(), currentTime);
        if (fuelLevel.isLatest()) {
            cachedIceSnapshot.setFuelLevel(fuelLevel.getSignalSnapshot());
            updated = true;
        }

        LatestValue fuelLevelIndication = getLatestSignalValue(latestSignals, SignalCatalogue.getFuelLevelIndicationInfo(), cachedIceSnapshot.getFuelLevelIndication(), currentTime);
        if (fuelLevelIndication.isLatest()) {
            cachedIceSnapshot.setFuelLevelIndication(fuelLevelIndication.getSignalSnapshot());
            updated = true;
        }

        LatestValue gearPositionSensor = getLatestSignalValue(latestSignals, SignalCatalogue.getGearPositionSensorInfo(), cachedIceSnapshot.getGearPositionSensor(), currentTime);
        if (gearPositionSensor.isLatest()) {
            cachedIceSnapshot.setGearPositionSensor(gearPositionSensor.getSignalSnapshot());
            updated = true;
        }

        LatestValue mil = getLatestSignalValue(latestSignals, SignalCatalogue.getMilInfo(), cachedIceSnapshot.getMil(), currentTime);
        if (mil.isLatest()) {
            cachedIceSnapshot.setMil(mil.getSignalSnapshot());
            updated = true;
        }

        LatestValue sideStandSensor = getLatestSignalValue(latestSignals, SignalCatalogue.getSideStandSensorStatusInfo(), cachedIceSnapshot.getSideStandSensor(), currentTime);
        if (sideStandSensor.isLatest()) {
            cachedIceSnapshot.setSideStandSensor(sideStandSensor.getSignalSnapshot());
            updated = true;
        }

        LatestValue vehicleSpeedDisplay = getLatestSignalValue(latestSignals, SignalCatalogue.getVehicleSpeedDisplayInfo(), cachedIceSnapshot.getVehicleSpeedDisplay(), currentTime);
        if (vehicleSpeedDisplay.isLatest()) {
            cachedIceSnapshot.setVehicleSpeedDisplay(vehicleSpeedDisplay.getSignalSnapshot());
            updated = true;
        }

        LatestValue throttlePositionSensor = getLatestSignalValue(latestSignals, SignalCatalogue.getThrottlePositionInfo(), cachedIceSnapshot.getThrottlePositionSensor(), currentTime);
        if (throttlePositionSensor.isLatest()) {
            cachedIceSnapshot.setThrottlePositionSensor(throttlePositionSensor.getSignalSnapshot());
            updated = true;
        }

        LatestValue distanceTravelledWithMil = getLatestSignalValue(latestSignals, SignalCatalogue.getDistanceTravelledWithMilInfo(), cachedIceSnapshot.getDistanceTravelledWithMil(), currentTime);
        if (distanceTravelledWithMil.isLatest()) {
            cachedIceSnapshot.setDistanceTravelledWithMil(distanceTravelledWithMil.getSignalSnapshot());
            updated = true;
        }

        LatestValue odoSignalHr = getLatestSignalValue(latestSignals, SignalCatalogue.getOdometerHRInfo(), cachedIceSnapshot.getOdoSignalHr(), currentTime);
        if (odoSignalHr.isLatest() && Double.parseDouble(odoSignalHr.getSignalSnapshot().getValue().toString()) > 0) {
            cachedIceSnapshot.setOdoSignalHr(odoSignalHr.getSignalSnapshot());
            updated = true;
        }

        return updated;
    }

    private LatestValue getLatestValue(long incomingSignalTime, Object incomingValue, SignalSnapshot cache, long currentTime) {
        // Nothing in cache, so incoming is latest
        if (Objects.isNull(cache)) {
            return LatestValue.builder()
                    .isLatest(true)
                    .isFirstTime(true)
                    .signalSnapshot(SignalSnapshot.builder()
                            .createdTsp(currentTime)
                            .updatedTsp(currentTime)
                            .updatedTspIST(DateUtils.formatToISO(currentTime))
                            .incomingTsp(incomingSignalTime)
                            .incomingTspIST(DateUtils.formatToISO(incomingSignalTime))
                            .value(incomingValue)
                            .build())
                    .build();
        }

        long cachedIncomingTime = cache.getIncomingTsp();
        boolean isLatest = incomingSignalTime > cachedIncomingTime;
        if(cachedIncomingTime > currentTime) {
            log.warn("Corrupted data found in cache with incoming time in the future {}", cache);
            isLatest = true;
        }

        return LatestValue.builder()
                .isLatest(isLatest)
                .isFirstTime(false)
                .signalSnapshot(SignalSnapshot.builder()
                        .createdTsp(cache.getCreatedTsp())
                        .updatedTsp(DateUtils.currentEpochTime())
                        .updatedTspIST(DateUtils.formatToISO(currentTime))
                        .incomingTsp(incomingSignalTime)
                        .incomingTspIST(DateUtils.formatToISO(incomingSignalTime))
                        .value(incomingValue)
                        .build())
                .build();
    }

    private LatestValue getLatestStateValue(StateInfo incomingStateInfo, SignalSnapshot cache, long currentTime) {
        // state info is null, so it is not the latest
        if (Objects.isNull(incomingStateInfo) || Objects.isNull(incomingStateInfo.getTime()) || Objects.isNull(incomingStateInfo.getValue())) {
            return LatestValue.builder()
                    .isFirstTime(false)
                    .isLatest(false)
                    .build();
        }

        return getLatestValue(incomingStateInfo.getTime(), incomingStateInfo.getValue(), cache, currentTime);
    }

    private LatestValue getLatestSignalValue(Map<String, SignalData> incomingSignals, SignalInfo signalInfo, SignalSnapshot cache, long currentTime) {
        SignalData signal = incomingSignals.getOrDefault(signalInfo.getKey(), null);

        try {
            if (Objects.isNull(signal)
                    || Objects.isNull(signal.getValue())
                    || Objects.isNull(signal.getTime())) {
                return LatestValue.builder()
                        .isFirstTime(false)
                        .isLatest(false)
                        .build();
            }

            long time = signal.getTime();
            if(time > currentTime) {
                log.debug("Somehow signal time {} is in for {} future as compared to current time {}", time, signalInfo.getKey(), currentTime);
                return LatestValue.builder()
                        .isFirstTime(false)
                        .isLatest(false)
                        .build();
            }

            // Casting the values to primitives
            if (signalInfo.isDouble()) {
                double value = (double) signal.getValue();
                return getLatestValue(signal.getTime(), value, cache, currentTime);
            }

            if (signalInfo.isInteger()) {
                Integer value = SignalUtils.getIntegerSignalValue(signal);
                return getLatestValue(signal.getTime(), value, cache, currentTime);
            }

            if (signalInfo.isLong()) {
                Long value = SignalUtils.getLongSignalValue(signal);
                return getLatestValue(signal.getTime(), value, cache, currentTime);
            }

            // The signal will be boolean or string, which is fine
            return getLatestValue(signal.getTime(), signal.getValue(), cache, currentTime);
        } catch (Exception e) {
            log.error("Exception while fetching the latest value for signal {} from signalsList {}" , signalInfo.getKey(), incomingSignals, e);
            return LatestValue.builder()
                    .isFirstTime(false)
                    .isLatest(false)
                    .build();
        }

    }

    private LatestValue getLatestAlertValue(Map<String, SignalData> incomingSignals, SignalInfo signalInfo, SignalSnapshot cache, long currentTime) {
        SignalData signal = incomingSignals.getOrDefault(signalInfo.getKey(), null);

        if (Objects.isNull(signal) && Objects.isNull(cache)) {
            return getLatestValue(DateUtils.currentEpochTime(), DEFAULT_ALERT_VALUE, null, currentTime);
        }

        if (Objects.isNull(signal)
                || Objects.isNull(signal.getValue())
                || Objects.isNull(signal.getTime())) {
            return LatestValue.builder()
                    .isFirstTime(false)
                    .isLatest(false)
                    .build();
        }

        int value;
        if (signalInfo.isBoolean()) {
            value = (boolean) signal.getValue() ? 1 : 0;
        } else {
            value = SignalUtils.getIntegerSignalValue(signal);
        }

        return getLatestValue(signal.getTime(), value, cache, currentTime);
    }

    private LatestValue getLatestMultiAlertValue(MultiAlertEvent multiAlertEvent,  SignalSnapshot cache, long currentTime) {

        if (Objects.isNull(multiAlertEvent) && Objects.isNull(cache)) {
            return getLatestValue(DateUtils.currentEpochTime(), DEFAULT_ALERT_VALUE, null, currentTime);
        }

        if (Objects.isNull(multiAlertEvent)
                || Objects.isNull(multiAlertEvent.getAlertSignal())
                || Objects.isNull(multiAlertEvent.getTimestamp())) {
            return LatestValue.builder()
                    .isFirstTime(false)
                    .isLatest(false)
                    .build();
        }

        int value = multiAlertEvent.getAlertSignal().contains("0") ? 0 : 1;
        return getLatestValue(multiAlertEvent.getTimestamp(), value, cache, currentTime);
    }

    private String getOpenSearchIndex(Tenant tenant) {

        switch (tenant) {
            case EV:
                numEvCounter.inc();
                return evIndex;
            case HARLEY:
                numHarleyCounter.inc();
                return harleyIndex;
            case ICE:
                numIceCounter.inc();
                return iceIndex;
            default:
                numErrorEventCounter.inc();
                return null;
        }
    }

    private SnapshotWrapper getLatestSnapshotFromCache(String incomingVid) {
        try {

            if (latestSnapshot.contains(incomingVid)) return latestSnapshot.get(incomingVid);

        } catch (Exception e) {
            numErrorEventCounter.inc();
            log.error("Exception while fetching latest snapshot from cache for vehicle {}", incomingVid, e);
        }

        return SnapshotWrapper.create();
    }

    private void updateLatestSnapshot(String incomingVid, SnapshotWrapper vehicleSnapshot) {
        try {
            log.debug("Updating snapshot for vehicle {}", incomingVid);
            latestSnapshot.put(incomingVid, vehicleSnapshot);
        } catch (Exception e) {
            numErrorEventCounter.inc();
            log.error("Exception while updating latest snapshot from cache for vehicle {}", incomingVid, e);
        }
    }

}
