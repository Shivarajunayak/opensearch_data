package org.hmcl.cvp.dataplatform.vehiclesnapshot.contract;

import com.google.gson.annotations.SerializedName;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class IceSnapshot {

    @SerializedName("engineSpeed")
    private SignalSnapshot engineSpeed;

    @SerializedName("engineRunStatus")
    private SignalSnapshot engineRunStatus;

    @SerializedName("engineTemperature")
    private SignalSnapshot engineTemperature;

    @SerializedName("fuelLevel")
    private SignalSnapshot fuelLevel;

    @SerializedName("fuelLevelIndication")
    private SignalSnapshot fuelLevelIndication;

    @SerializedName("gearPositionSensor")
    private SignalSnapshot gearPositionSensor;

    @SerializedName("mil")
    private SignalSnapshot mil;

    @SerializedName("sideStandSensor")
    private SignalSnapshot sideStandSensor;

    @SerializedName("vehicleSpeedDisplay")
    private SignalSnapshot vehicleSpeedDisplay;

    @SerializedName("throttlePositionSensor")
    private SignalSnapshot throttlePositionSensor;

    @SerializedName("distanceTravelledWithMil")
    private SignalSnapshot distanceTravelledWithMil;

    @SerializedName("odoSignalHr")
    private SignalSnapshot odoSignalHr;

}
