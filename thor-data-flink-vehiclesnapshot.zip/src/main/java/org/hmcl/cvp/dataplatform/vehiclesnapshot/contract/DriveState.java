package org.hmcl.cvp.dataplatform.vehiclesnapshot.contract;

import com.google.gson.annotations.SerializedName;

import java.util.HashMap;
import java.util.Map;

public enum DriveState {

    @SerializedName("Moving")
    MOVING("Moving"),

    @SerializedName("Idle")
    IDLE("Idle"),

    @SerializedName("Stopped")
    STOPPED("Stopped");

    private static final Map<String, DriveState> CONSTANTS = new HashMap<>();

    static {
        for (DriveState c : values()) {
            CONSTANTS.put(c.value, c);
        }
    }

    private final String value;

    DriveState(String value) {
        this.value = value;
    }

    public static DriveState fromValue(String value) {
        DriveState constant = CONSTANTS.get(value);
        if (constant == null) {
            throw new IllegalArgumentException(value);
        } else {
            return constant;
        }
    }

    @Override
    public String toString() {
        return this.value;
    }

    public String value() {
        return this.value;
    }
}
