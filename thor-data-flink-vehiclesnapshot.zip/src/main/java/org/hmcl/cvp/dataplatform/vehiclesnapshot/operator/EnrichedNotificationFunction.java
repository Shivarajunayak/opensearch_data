package org.hmcl.cvp.dataplatform.vehiclesnapshot.operator;

import com.google.gson.Gson;
import lombok.extern.slf4j.Slf4j;
import org.apache.flink.api.common.functions.RichFlatMapFunction;
import org.apache.flink.configuration.Configuration;
import org.apache.flink.metrics.Counter;
import org.apache.flink.util.Collector;
import org.hmcl.cvp.dataplatform.commons.constants.Constants;
import org.hmcl.cvp.dataplatform.commons.utils.GsonUtils;
import org.hmcl.cvp.dataplatform.contract.notification.AlertDetails;
import org.hmcl.cvp.dataplatform.contract.notification.GeoFenceType;
import org.hmcl.cvp.dataplatform.contract.notification.Notification;
import org.hmcl.cvp.dataplatform.contract.telemetry.Tenant;
import org.hmcl.cvp.dataplatform.vehiclesnapshot.contract.EnrichedSnapshot;
import org.hmcl.cvp.dataplatform.vehiclesnapshot.contract.Source;
import org.hmcl.cvp.dataplatform.vehiclesnapshot.contract.StateInfo;

import java.util.HashMap;
import java.util.Objects;

@Slf4j
public class EnrichedNotificationFunction extends RichFlatMapFunction<String, EnrichedSnapshot> {

    private static final Gson GSON = GsonUtils.getGson();

    private transient Counter numInputCounter;
    private transient Counter numGeoFenceCounter;
    private transient Counter numIgnoredCounter;
    private transient Counter numErrorCounter;

    private Counter counterInitializer(String counterName) {
        return getRuntimeContext()
                .getMetricGroup()
                .addGroup(Constants.METRIC_GROUP_NAME)
                .addGroup("EnrichLKS")
                .counter(counterName);
    }

    @Override
    public void open(Configuration parameters) throws Exception {
        super.open(parameters);
        numInputCounter = counterInitializer("numInputEvents");
        numGeoFenceCounter = counterInitializer("numGeoFenceCounter");
        numErrorCounter = counterInitializer("numErrorEvents");
        numIgnoredCounter = counterInitializer("numIgnoredCounter");
    }

    @Override
    public void flatMap(String value, Collector<EnrichedSnapshot> out) {

        try {

            numInputCounter.inc();
            Notification notification = GSON.fromJson(value, Notification.class);
            if(Objects.isNull(notification)) {
                log.debug("Notification is null for {}", value);
                numIgnoredCounter.inc();
                return;
            }

            AlertDetails alertDetails = notification.getAlertDetails();
            if(Objects.isNull(alertDetails)) {
                log.debug("AlertDetails is null for {}", value);
                numIgnoredCounter.inc();
                return;
            }

            String vid = notification.getVehicleVid();
            boolean isGeoFenceAlert = isGeoFenceAlert(notification);
            GeoFenceType geoFenceAlertType = alertDetails.getBoundaryCondition();

            if(Objects.isNull(geoFenceAlertType)) {
                log.debug("GeoFenceType is null for {}", value);
                numIgnoredCounter.inc();
                return;
            }

            if(isGeoFenceAlert) {
                StateInfo geoFenceState = getGeoFenceState(notification, geoFenceAlertType);
                EnrichedSnapshot enrichedSnapshot = new EnrichedSnapshot();
                enrichedSnapshot.setVirtualId(vid);
                enrichedSnapshot.setVehicleName(notification.getTcuId());
                enrichedSnapshot.setTenant(Tenant.fromTenantId(notification.getTenantId()));
                enrichedSnapshot.setTenantId(notification.getTenantId());
                enrichedSnapshot.setGeoFenceAlert(geoFenceState);
                enrichedSnapshot.setLatestSignals(new HashMap<>());
                enrichedSnapshot.setSource(Source.NOTIFICATION);
                enrichedSnapshot.setLatestEventCollectionTsp(Long.parseLong(notification.getEventTimestamp()));

                log.debug("Collected geoFence alert of type {} for vehicle {}", geoFenceAlertType.value(), vid);
                numGeoFenceCounter.inc();
                out.collect(enrichedSnapshot);

            } else {
                log.debug("Incoming alert is not a geoFence Alert for vehicle {}", vid);
                numIgnoredCounter.inc();
            }

        } catch (Exception e) {
            numErrorCounter.inc();
            log.error("An error occurred while normalising cloud alert notification {} to Telemetry: ", value, e);
        }

    }

    private boolean isGeoFenceAlert(Notification notification) {

         String geoFenceId = notification.getGeofenceId();

         if(Objects.isNull(geoFenceId)) return false;

         return !geoFenceId.trim().isEmpty();
    }

    private StateInfo getGeoFenceState(Notification notification,  GeoFenceType geoFenceAlertType) {
        return StateInfo.builder()
                .time(getTime(notification))
                .value(geoFenceAlertType.value())
                .build();
    }

    private long getTime(Notification notification) {
        return Long.parseLong(notification.getEventTimestamp());
    }

}
