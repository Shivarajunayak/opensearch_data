package org.hmcl.cvp.dataplatform.vehiclesnapshot.contract;

import com.google.gson.annotations.SerializedName;

import java.util.HashMap;
import java.util.Map;

public enum ConnectionState {

    @SerializedName("Connected")
    Connected("Connected"),

    @SerializedName("Not Connected")
    NOT_Connected("Not Connected");

    private static final Map<String, ConnectionState> CONSTANTS = new HashMap<>();

    static {
        for (ConnectionState c : values()) {
            CONSTANTS.put(c.value, c);
        }
    }

    private final String value;

    ConnectionState(String value) {
        this.value = value;
    }

    public static ConnectionState fromValue(String value) {
        ConnectionState constant = CONSTANTS.get(value);
        if (constant == null) {
            throw new IllegalArgumentException(value);
        } else {
            return constant;
        }
    }

    @Override
    public String toString() {
        return this.value;
    }

    public String value() {
        return this.value;
    }
}
