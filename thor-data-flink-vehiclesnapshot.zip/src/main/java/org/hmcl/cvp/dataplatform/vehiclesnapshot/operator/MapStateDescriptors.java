package org.hmcl.cvp.dataplatform.vehiclesnapshot.operator;

import org.apache.flink.api.common.state.MapStateDescriptor;
import org.apache.flink.api.common.typeinfo.TypeHint;
import org.apache.flink.api.common.typeinfo.TypeInformation;
import org.hmcl.cvp.dataplatform.vehiclesnapshot.contract.SnapshotWrapper;

public class MapStateDescriptors {

    private MapStateDescriptors() {
    }

    public static MapStateDescriptor<String, SnapshotWrapper> getLatestSnapshotDescriptor() {
        return new MapStateDescriptor<>("latestSnapshotMapState",
                TypeInformation.of(String.class),
                TypeInformation.of(new TypeHint<SnapshotWrapper>() {
                })
        );
    }
}
