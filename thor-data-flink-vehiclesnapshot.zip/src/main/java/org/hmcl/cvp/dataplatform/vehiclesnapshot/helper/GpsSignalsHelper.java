package org.hmcl.cvp.dataplatform.vehiclesnapshot.helper;

import lombok.extern.slf4j.Slf4j;
import org.hmcl.cvp.dataplatform.vehiclesnapshot.contract.LatestValue;

import java.util.List;
import java.util.Objects;

@Slf4j
public class GpsSignalsHelper {

    private static final List<Integer> VALID_GPS_FIX_VALUES = List.of(2, 3);

    private GpsSignalsHelper() {}

    public static boolean isGpsFixSignalValid(String incomingVid, LatestValue gpsFix) {
        if(Objects.isNull(gpsFix.getSignalSnapshot())) return false;
        log.debug("GpsFix value {} for vehicle {}", gpsFix.getSignalSnapshot().getValue(), incomingVid);
        Integer value = (Integer) gpsFix.getSignalSnapshot().getValue();
        return VALID_GPS_FIX_VALUES.contains(value);
    }

    public static boolean isHDopSignalValid(String incomingVid, LatestValue hDop, double hDopThresholdValue) {
        if(Objects.isNull(hDop.getSignalSnapshot())) return false;
        log.debug("HDop value {} for vehicle {}", hDop.getSignalSnapshot().getValue(), incomingVid);
        double value = (double) hDop.getSignalSnapshot().getValue();
        return value <= hDopThresholdValue;
    }

    public static boolean isGpsValidSignalValid(String incomingVid, LatestValue gpsValid) {
        if(Objects.isNull(gpsValid.getSignalSnapshot())) return false;

        log.debug("GPS Valid value {} for vehicle {}", gpsValid.getSignalSnapshot().getValue(), incomingVid);
        return (boolean) gpsValid.getSignalSnapshot().getValue();
    }

    public static boolean isGpsSignalsValid(String incomingVid, LatestValue gpsFix, LatestValue hDop, double hDopThresholdValue, LatestValue gpsValid) {
        return isGpsValidSignalValid(incomingVid, gpsValid)
                && isHDopSignalValid(incomingVid, hDop, hDopThresholdValue)
                && isGpsFixSignalValid(incomingVid, gpsFix);
    }
}
