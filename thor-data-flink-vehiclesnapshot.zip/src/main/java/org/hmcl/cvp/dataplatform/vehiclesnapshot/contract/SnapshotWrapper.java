package org.hmcl.cvp.dataplatform.vehiclesnapshot.contract;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Objects;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class SnapshotWrapper {

    private CommonSnapshot commonSnapshot;

    private EvSnapshot evSnapshot;

    private IceSnapshot iceSnapshot;

    private boolean isEv;

    private boolean isLks;

    private long latestEventCollectionTsp;

    public boolean getIsEv() {
        return isEv;
    }

    public void setIsEv(boolean ev) {
        isEv = ev;
    }

    public boolean getIsLks() {
        return isLks;
    }

    public void setIsLks(boolean lks) {
        isLks = lks;
    }

    public static SnapshotWrapper create() {
        return SnapshotWrapper.builder()
                .build();
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof SnapshotWrapper)) return false;
        SnapshotWrapper that = (SnapshotWrapper) o;
        return Objects.equals(commonSnapshot, that.commonSnapshot);
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(commonSnapshot);
    }
}
