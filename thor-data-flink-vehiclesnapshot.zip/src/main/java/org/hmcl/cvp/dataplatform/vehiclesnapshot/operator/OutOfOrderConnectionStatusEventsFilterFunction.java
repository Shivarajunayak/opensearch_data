package org.hmcl.cvp.dataplatform.vehiclesnapshot.operator;

import lombok.extern.slf4j.Slf4j;
import org.apache.flink.api.common.functions.RichFlatMapFunction;
import org.apache.flink.api.common.state.MapState;
import org.apache.flink.api.common.state.MapStateDescriptor;
import org.apache.flink.api.common.typeinfo.Types;
import org.apache.flink.configuration.Configuration;
import org.apache.flink.util.Collector;
import org.hmcl.cvp.dataplatform.contract.connectionstatus.ConnectionStatus;

@Slf4j
public class OutOfOrderConnectionStatusEventsFilterFunction extends RichFlatMapFunction<ConnectionStatus, ConnectionStatus> {

    private transient MapState<String, Long> lastProcessedEventTimeState;

    @Override
    public void open(Configuration parameters) {
        MapStateDescriptor<String, Long> descriptor = new MapStateDescriptor<>(
                "lastProcessedEventTimeByVidConnectionStatus",
                Types.STRING, // Tuple2<String, String> for documentType and vid
                Types.LONG // Long for last processed event time
        );
        lastProcessedEventTimeState = getRuntimeContext().getMapState(descriptor);
    }

    @Override
    public void flatMap(ConnectionStatus value, Collector<ConnectionStatus> out) throws Exception {


        String vid = value.getVid();
        Long currentEventTime = value.getTimestamp();

        // Get the last processed event time for this key
        Long lastProcessedEventTime = lastProcessedEventTimeState.get(vid);

        if (lastProcessedEventTime == null || currentEventTime >= lastProcessedEventTime) {
            // Update the state for this key
            lastProcessedEventTimeState.put(vid, currentEventTime);

            // Forward the event
            out.collect(value);
        } else {
            log.info("ignoring ConnectionStatus data for VID: {}, due to late event, event TSP: {} against cached lastProcessedEventTime: {}", vid, currentEventTime, lastProcessedEventTime);
        }
    }
}