package org.hmcl.cvp.dataplatform.vehiclesnapshot.contract;

import lombok.*;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class RedisConfig {
    private int batchSize;
    private String redisUrl;
    private int redisPort;
    private int redisPoolMaxConnections;
    private int redisPoolMaxIdle;
    private int redisPoolMinIdle;
    private String redisUsername;
    private String redisPassword;
    private String redisMode;
    private long sinkTimerIntervalInMS;
}
