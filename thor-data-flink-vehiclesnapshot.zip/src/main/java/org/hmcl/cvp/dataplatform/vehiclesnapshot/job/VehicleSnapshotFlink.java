package org.hmcl.cvp.dataplatform.vehiclesnapshot.job;

import lombok.extern.slf4j.Slf4j;
import org.apache.flink.api.common.eventtime.WatermarkStrategy;
import org.apache.flink.api.common.functions.FlatMapFunction;
import org.apache.flink.api.java.tuple.Tuple3;
import org.apache.flink.api.java.utils.ParameterTool;
import org.apache.flink.connector.base.DeliveryGuarantee;
import org.apache.flink.connector.kafka.source.KafkaSource;
import org.apache.flink.connector.opensearch.sink.FlushBackoffType;
import org.apache.flink.connector.opensearch.sink.Opensearch2Sink;
import org.apache.flink.connector.opensearch.sink.Opensearch2SinkBuilder;
import org.apache.flink.connector.opensearch.sink.OpensearchEmitter;
import org.apache.flink.streaming.api.datastream.DataStream;
import org.apache.flink.streaming.api.datastream.SingleOutputStreamOperator;
import org.apache.flink.streaming.api.environment.StreamExecutionEnvironment;
import org.apache.flink.streaming.api.functions.ProcessFunction;
import org.apache.flink.streaming.api.functions.windowing.ProcessWindowFunction;
import org.apache.flink.streaming.api.windowing.assigners.SlidingEventTimeWindows;
import org.apache.flink.streaming.api.windowing.time.Time;
import org.apache.flink.streaming.api.windowing.windows.TimeWindow;
import org.hmcl.cvp.dataplatform.commons.connector.KafkaConnector;
import org.hmcl.cvp.dataplatform.commons.connector.OpenSearchConnector;
import org.hmcl.cvp.dataplatform.commons.constants.FlinkRuntime;
import org.hmcl.cvp.dataplatform.commons.exception.OpenSearchFailureHandler;
import org.hmcl.cvp.dataplatform.commons.operator.ConnectionStatusFlatMapFunction;
import org.hmcl.cvp.dataplatform.commons.operator.TelemetryFlatMapFunction;
import org.hmcl.cvp.dataplatform.commons.utils.ConnectorUtils;
import org.hmcl.cvp.dataplatform.commons.utils.TelemetryUtils;
import org.hmcl.cvp.dataplatform.contract.connectionstatus.ConnectionStatus;
import org.hmcl.cvp.dataplatform.contract.telemetry.Telemetry;
import org.hmcl.cvp.dataplatform.vehiclesnapshot.contract.EnrichedSnapshot;
import org.hmcl.cvp.dataplatform.vehiclesnapshot.contract.RedisConfig;
import org.hmcl.cvp.dataplatform.vehiclesnapshot.contract.SnapshotWrapper;
import org.hmcl.cvp.dataplatform.vehiclesnapshot.helper.JobConfigs;
import org.hmcl.cvp.dataplatform.vehiclesnapshot.operator.EnrichConnectionStatusFunction;
import org.hmcl.cvp.dataplatform.vehiclesnapshot.operator.EnrichEdgeAlertsFunction;
import org.hmcl.cvp.dataplatform.vehiclesnapshot.operator.EnrichLKSFunction;
import org.hmcl.cvp.dataplatform.vehiclesnapshot.operator.EnrichTelemetryFunction;
import org.hmcl.cvp.dataplatform.vehiclesnapshot.operator.EnrichedNotificationFunction;
import org.hmcl.cvp.dataplatform.vehiclesnapshot.operator.OperatorNames;
import org.hmcl.cvp.dataplatform.vehiclesnapshot.operator.OutOfOrderConnectionStatusEventsFilterFunction;
import org.hmcl.cvp.dataplatform.vehiclesnapshot.operator.OutOfOrderEnrichedSnapshotFilterFunction;
import org.hmcl.cvp.dataplatform.vehiclesnapshot.operator.OutOfOrderTelemetryFilterFunction;
import org.hmcl.cvp.dataplatform.vehiclesnapshot.operator.RedisSinkConnector;
import org.hmcl.cvp.dataplatform.vehiclesnapshot.operator.SnapshotProcessWindowFunction;
import org.hmcl.cvp.dataplatform.vehiclesnapshot.operator.SnapshotRedisMapper;
import org.hmcl.cvp.dataplatform.vehiclesnapshot.operator.SnapshotWrapperKafkaFlatMapFunction;
import org.hmcl.cvp.dataplatform.vehiclesnapshot.operator.VehicleSnapshotMapperFunction;
import org.hmcl.cvp.dataplatform.vehiclesnapshot.operator.VehicleSnapshotOpenSearchEmitter;
import org.hmcl.cvp.dataplatform.vehiclesnapshot.operator.VehicleSnapshotOpenSearchEmitterInsert;

import java.io.IOException;
import java.time.Duration;
import java.util.Map;

@Slf4j
public class VehicleSnapshotFlink {

    private static final Integer DEFAULT_MAX_RETRIES = 5;
    private static final Integer DEFAULT_RETRY_DELAY_MILLI = 1000;
    private static final Integer DEFAULT_MAX_ACTIONS_TO_BUFFER = 1;
    private static final Integer DEFAULT_BULK_FLUSH_SIZE_MB = -1;
    private static final Integer DEFAULT_BULK_FLUSH_INTERVAL = -1;

    // Function to deserialize string to telemetry pojo
    private static final FlatMapFunction<String, Telemetry> telemetryMapFunction = new TelemetryFlatMapFunction();

    private static final FlatMapFunction<String, ConnectionStatus> connectionStatusFlatMapFunction = new ConnectionStatusFlatMapFunction();

    // Function to normalize LKS deserialized string data to telemetry pojo
    private static final FlatMapFunction<String, EnrichedSnapshot> lksMapperFunction = new EnrichLKSFunction();

    // Function to convert telemetry to enrichedSnapshot
    private static final FlatMapFunction<Telemetry, EnrichedSnapshot> enrichTelemetryFunction = new EnrichTelemetryFunction();

    private static final FlatMapFunction<ConnectionStatus, EnrichedSnapshot> enrichConnectionStatusFunctions = new EnrichConnectionStatusFunction();

    // Function to process incoming events in a window of 30 seconds
    private static final ProcessWindowFunction<Telemetry, EnrichedSnapshot, String, TimeWindow> processWindowFunction = new SnapshotProcessWindowFunction();

    // Function to Tuple3<Index, vehicleId, Map>
    private static final FlatMapFunction<EnrichedSnapshot, Tuple3<String, String, SnapshotWrapper>> vehicleSnapshotMapper = new VehicleSnapshotMapperFunction();

    // OpenSearch emitter to prepare the payload that will be inserted to openSearch and the respective index.
    private static final OpensearchEmitter<Tuple3<String, String, SnapshotWrapper>> opensearchEmitter = new VehicleSnapshotOpenSearchEmitter();

    // Function to convert priority notification to enriched snapshot object
    private static final FlatMapFunction<String, EnrichedSnapshot> notificationMapperFunction = new EnrichedNotificationFunction();

    // Function to convert edge alert event to enriched snapshot object
    private static final FlatMapFunction<String, EnrichedSnapshot> edgeAlertsMapperFunction = new EnrichEdgeAlertsFunction();

    // Function to sink all updates to opensearch index
    private static final OpensearchEmitter<Tuple3<String, String, SnapshotWrapper>> opensearchEmitterInsert = new VehicleSnapshotOpenSearchEmitterInsert();

    private static final FlatMapFunction<Tuple3<String, String, SnapshotWrapper>, String> snapshotWrapperFlatMapFunction = new SnapshotWrapperKafkaFlatMapFunction();

    // Default opensearch failure handler
    private static final OpenSearchFailureHandler opensearchFailureHandler = new OpenSearchFailureHandler();

    public static void main(String[] args) throws IOException {
        final StreamExecutionEnvironment env = StreamExecutionEnvironment.getExecutionEnvironment();
        final ParameterTool parameterTool = ConnectorUtils.loadApplicationParameters(args, env);
        env.getConfig().setGlobalJobParameters(parameterTool);

        boolean isTest = parameterTool.getBoolean(FlinkRuntime.IS_TEST, Boolean.FALSE);
        log.info("Is this being executed as part of test case? {}", isTest);

        int maxOutOfOrderInSec = parameterTool.getInt(FlinkRuntime.MAX_OUT_OF_ORDER_IN_SEC, 5);
        int idleTimeoutInSec = parameterTool.getInt(FlinkRuntime.IDLE_TIMEOUT_IN_SEC);
        int windowDuration = parameterTool.getInt(FlinkRuntime.VehicleSnapshot.WINDOW_DURATION, 30);
        int windowSlide = parameterTool.getInt(FlinkRuntime.VehicleSnapshot.WINDOW_SLIDE_IN_SEC, 10);

        try {

            // Get the telemetry streams. This will be a union of master and charging campaigns
            DataStream<Telemetry> telemetryStream = getTelemetryStream(env, parameterTool, isTest);

            DataStream<ConnectionStatus> connectionStatusDataStream = getConnectionStatusDataStream(env, parameterTool, isTest);

            // Ignore events older than 5 seconds
            WatermarkStrategy<Telemetry> watermarkStrategy = WatermarkStrategy
                    .<Telemetry>forBoundedOutOfOrderness(Duration.ofSeconds(maxOutOfOrderInSec))
                    .withTimestampAssigner((element, recordTimestamp) -> element.getCollectionEventTime())
                    .withIdleness(Duration.ofSeconds(idleTimeoutInSec));

            SingleOutputStreamOperator<EnrichedSnapshot> windowedStream = telemetryStream
                    .assignTimestampsAndWatermarks(watermarkStrategy)
                    .name(OperatorNames.COMBINED_SOURCES)
                    .uid(OperatorNames.COMBINED_SOURCES)
                    .keyBy(TelemetryUtils::getVirtualId)
                    .window(SlidingEventTimeWindows.of(Time.seconds(windowDuration), Time.seconds(windowSlide)))
                    .process(processWindowFunction)
                    .name(OperatorNames.PROCESS_WINDOW)
                    .uid(OperatorNames.PROCESS_WINDOW);

            // Convert telemetry data into EnrichedSnapshot object
            DataStream<EnrichedSnapshot> enrichedTelemetry = telemetryStream
                    .flatMap(enrichTelemetryFunction)
                    .name(OperatorNames.ENRICH_CAMPAIGN_SOURCE)
                    .uid(OperatorNames.ENRICH_CAMPAIGN_SOURCE);

            DataStream<EnrichedSnapshot> enrichedConnectionStatus = connectionStatusDataStream
                    .flatMap(enrichConnectionStatusFunctions)
                    .name(OperatorNames.ENRICH_CONNECTION_STATUS_SOURCE)
                    .uid(OperatorNames.ENRICH_CONNECTION_STATUS_SOURCE);

            // Get the LKS data
            DataStream<EnrichedSnapshot> enrichedLksStream = getEnrichedLKSDataStream(env, parameterTool, isTest)
                    .keyBy(EnrichedSnapshot::getVirtualId)
                    .flatMap(new OutOfOrderEnrichedSnapshotFilterFunction())
                    .name("OutOfOrderFilterFunctionLksStream")
                    .uid("OutOfOrderFilterFunctionLksStream");

            // Get priority notification data
            DataStream<EnrichedSnapshot> enrichedNotificationStream = getEnrichedNotificationDataStream(env, parameterTool, isTest)
                    .keyBy(EnrichedSnapshot::getVirtualId)
                    .flatMap(new OutOfOrderEnrichedSnapshotFilterFunction())
                    .name("OutOfOrderFilterFunctionNotificationStream")
                    .uid("OutOfOrderFilterFunctionNotificationStream");

            // Get edge alerts data
            DataStream<EnrichedSnapshot> enrichedEdgeAlertsStream = getEnrichedEdgeAlertsDataStream(env, parameterTool, isTest)
                    .keyBy(EnrichedSnapshot::getVirtualId)
                    .flatMap(new OutOfOrderEnrichedSnapshotFilterFunction())
                    .name("OutOfOrderFilterFunctionAlertStream")
                    .uid("OutOfOrderFilterFunctionAlertStream");

            SingleOutputStreamOperator<Tuple3<String, String, SnapshotWrapper>> snapshotMapper = enrichedTelemetry
                    .union(enrichedLksStream)
                    .union(enrichedNotificationStream)
                    .union(enrichedEdgeAlertsStream)
                    .union(windowedStream)
                    .union(enrichedConnectionStatus)
                    .keyBy(EnrichedSnapshot::getVirtualId)
                    .flatMap(vehicleSnapshotMapper)
                    .name(OperatorNames.SNAPSHOT_MAPPER)
                    .uid(OperatorNames.SNAPSHOT_MAPPER);

            OpenSearchConnector.OpenSearchProperties openSearchProperties = OpenSearchConnector.getOpenSearchProperties(parameterTool);
            Opensearch2Sink<Tuple3<String, String, SnapshotWrapper>> opensearchUpsertSink = getOpenSearchSink(parameterTool, openSearchProperties, isTest);

            // Sink to opensearch*/
            snapshotMapper
                    .startNewChain()
                    .keyBy(event -> event.f1) //keying by vid to distribute load across sink subtasks
                    .sinkTo(opensearchUpsertSink)
                    .name(OperatorNames.OPEN_SEARCH_SINK)
                    .uid(OperatorNames.OPEN_SEARCH_SINK);

            // Sink to Redis*/
            if (parameterTool.getBoolean(JobConfigs.REDIS_SINK_ENABLED, false)) {
                int redisWriteBufferBatchSize = parameterTool.getInt(JobConfigs.REDIS_WRITE_BUFFER_BATCH_SIZE, 1);
                String redisUrl = parameterTool.get(JobConfigs.REDIS_URL, "localhost");
                int redisPort = parameterTool.getInt(JobConfigs.REDIS_PORT, 6379);
                int redisMaxConnections = parameterTool.getInt(JobConfigs.REDIS_POOL_MAX_CONNECTIONS, 5);
                int redisMaxIdle = parameterTool.getInt(JobConfigs.REDIS_POOL_MAX_IDLE, 2);
                int redisMinIdle = parameterTool.getInt(JobConfigs.REDIS_POOL_MIN_IDLE, 1);
                String redisUsername = parameterTool.get(JobConfigs.REDIS_USERNAME, "default");
                String redisPassword = parameterTool.get(JobConfigs.REDIS_PASSWORD, "default");
                String redisMode = parameterTool.get(JobConfigs.REDIS_MODE, "standalone");
                int sinkTimerIntervalInMS = parameterTool.getInt(JobConfigs.REDIS_SINK_FLUSH_TIMER_INTERVAL, 60000);

                // Function to write records to connect using buffer-flush strategy, sink connector is deprecated, hence process function
                RedisConfig redisConfig = RedisConfig.builder().batchSize(redisWriteBufferBatchSize)
                        .redisUrl(redisUrl).redisPort(redisPort).redisPoolMaxConnections(redisMaxConnections)
                        .redisPoolMinIdle(redisMinIdle).redisPoolMaxIdle(redisMaxIdle).redisUsername(redisUsername)
                        .redisPassword(redisPassword).redisMode(redisMode).sinkTimerIntervalInMS(sinkTimerIntervalInMS).build();
                final ProcessFunction<Map<String, Object>, Void> redisSinkConnector = new RedisSinkConnector(redisConfig);

                snapshotMapper
                        .startNewChain()
                        .map(new SnapshotRedisMapper())// Mapper to convert SnapshotWrapper POJO into Hashmap to be used for Redis Sink
                        .name(OperatorNames.REDIS_MAPPER).uid(OperatorNames.REDIS_MAPPER)
                        .keyBy(event -> event.get("_key"))
                        .process(redisSinkConnector)
                        .name(OperatorNames.REDIS_SINK).uid(OperatorNames.REDIS_SINK);
            }

            //Sink to Kafka topic
            snapshotMapper
                    .startNewChain()
                    .keyBy(event -> event.f1)//keying by vid to distribute load across sink subtasks
                    .flatMap(snapshotWrapperFlatMapFunction)
                    .name(OperatorNames.KAFKA_MAPPER)
                    .uid(OperatorNames.KAFKA_MAPPER)
                    .sinkTo(KafkaConnector.getKafkaSink(getVehicleSnapshotProperties(parameterTool, parameterTool.get(FlinkRuntime.VehicleSnapshot.SNAPSHOT_TOPIC_NAME)), parameterTool, isTest))
                    .name(OperatorNames.KAFKA_SINK)
                    .uid(OperatorNames.KAFKA_SINK);

            env.execute();

        } catch (Exception e) {
            log.error("Error executing vehicle snapshot job: ", e);
        }

    }

    // Union of master campaign and charging campaign
    private static DataStream<Telemetry> getTelemetryStream(final StreamExecutionEnvironment env,
                                                            final ParameterTool parameterTool,
                                                            boolean isTest) {
        String telemetryCampaignTopic = parameterTool.get(FlinkRuntime.Kafka.TELEMETRY_CAMPAIGN_TOPIC);
        String telemetryConsumer = parameterTool.get(FlinkRuntime.Kafka.CAMPAIGN_GROUP) + "Master";
        KafkaConnector.KafkaProperties telemetryKafkaProps = KafkaConnector.getTelemetryKafkaProperties(parameterTool, telemetryConsumer, telemetryCampaignTopic);
        KafkaSource<String> masterCampaignSource = KafkaConnector.createStringKafkaSource(telemetryKafkaProps, parameterTool, isTest);

        // Data stream created from telemetry campaign
        DataStream<Telemetry> masterCampaignDataStream = env.fromSource(masterCampaignSource,
                        WatermarkStrategy.noWatermarks(),
                        telemetryCampaignTopic)
                .flatMap(telemetryMapFunction)
                .name(OperatorNames.MASTER_CAMPAIGN_SOURCE)
                .uid(OperatorNames.MASTER_CAMPAIGN_SOURCE)
                .keyBy(TelemetryUtils::getVirtualId)
                .flatMap(new OutOfOrderTelemetryFilterFunction())
                .name("OutOfOrderFilterFunctionMasterCampaign")
                .uid("OutOfOrderFilterFunctionMasterCampaign");

        String chargingCampaignTopic = parameterTool.get(FlinkRuntime.Kafka.CHARGING_CAMPAIGN_TOPIC);
        String chargingConsumer = parameterTool.get(FlinkRuntime.Kafka.CAMPAIGN_GROUP) + "Charging";
        KafkaConnector.KafkaProperties chargingKafkaProps = KafkaConnector.getTelemetryKafkaProperties(parameterTool, chargingConsumer, chargingCampaignTopic);
        KafkaSource<String> chargingCampaignSource = KafkaConnector.createStringKafkaSource(chargingKafkaProps, parameterTool, isTest);

        // Data stream created from charging campaigns
        DataStream<Telemetry> chargingCampaignDataStream = env.fromSource(chargingCampaignSource,
                        WatermarkStrategy.noWatermarks(),
                        chargingCampaignTopic)
                .flatMap(telemetryMapFunction)
                .name(OperatorNames.CHARGING_CAMPAIGN_SOURCE)
                .uid(OperatorNames.CHARGING_CAMPAIGN_SOURCE)
                .keyBy(TelemetryUtils::getVirtualId)
                .flatMap(new OutOfOrderTelemetryFilterFunction())
                .name("OutOfOrderFilterFunctionChargingCampaign")
                .uid("OutOfOrderFilterFunctionChargingCampaign");

        return masterCampaignDataStream
                .union(chargingCampaignDataStream);
    }

    private static DataStream<EnrichedSnapshot> getEnrichedLKSDataStream(final StreamExecutionEnvironment env,
                                                                         final ParameterTool parameterTool,
                                                                         boolean isTest) {
        // Data stream created from LKS source
        String lksTopic = parameterTool.get(FlinkRuntime.Kafka.LKS_FETCH_API_K2_TOPIC);
        KafkaConnector.KafkaProperties lksFenceKafkaProps = getLKSKafkaProperties(parameterTool, lksTopic);
        KafkaSource<String> lksSource = KafkaConnector.createStringKafkaSource(lksFenceKafkaProps, parameterTool, isTest);

        return env.fromSource(lksSource,
                        WatermarkStrategy.noWatermarks(),
                        lksTopic)
                .flatMap(lksMapperFunction)
                .name(OperatorNames.LKS_FETCH_JSON_SOURCE)
                .uid(OperatorNames.LKS_FETCH_JSON_SOURCE);
    }

    private static DataStream<EnrichedSnapshot> getEnrichedNotificationDataStream(final StreamExecutionEnvironment env,
                                                                                  final ParameterTool parameterTool,
                                                                                  boolean isTest) {
        String priorityTopic = parameterTool.get(FlinkRuntime.Kafka.NOTIFICATION_PRIORITY_TOPIC);
        KafkaConnector.KafkaProperties prioritySinkProperties = KafkaConnector.getNotificationKafkaProperties(parameterTool, priorityTopic);
        KafkaSource<String> notificationSource = KafkaConnector.createStringKafkaSource(prioritySinkProperties, parameterTool, isTest);

        return env.fromSource(notificationSource,
                        WatermarkStrategy.noWatermarks(),
                        priorityTopic)
                .flatMap(notificationMapperFunction)
                .name(OperatorNames.NOTIFICATION_JSON_SOURCE)
                .uid(OperatorNames.NOTIFICATION_JSON_SOURCE);
    }

    private static DataStream<ConnectionStatus> getConnectionStatusDataStream(final StreamExecutionEnvironment env,
                                                                              final ParameterTool parameterTool,
                                                                              boolean isTest) {
        String groupId = parameterTool.get(FlinkRuntime.Kafka.CAMPAIGN_GROUP) + "ConnectionStatus";
        String sessionName = parameterTool.get(FlinkRuntime.Kafka.CAMPAIGN_SESSION) + "ConnectionStatus";
        KafkaConnector.KafkaProperties connectionStatusTopicKafkaProps = KafkaConnector.getConnectionStatusKafkaProperties(parameterTool, groupId, sessionName);
        KafkaSource<String> connectionStatusSource = KafkaConnector.createStringKafkaSource(connectionStatusTopicKafkaProps, parameterTool, isTest);

        String connectionStatusTopic = parameterTool.get(FlinkRuntime.Kafka.CONNECTION_STATUS_TOPIC);

        return env.fromSource(connectionStatusSource,
                        WatermarkStrategy.noWatermarks(),
                        connectionStatusTopic)
                .flatMap(connectionStatusFlatMapFunction)
                .name(OperatorNames.CONNECTION_STATUS_SOURCE)
                .uid(OperatorNames.CONNECTION_STATUS_SOURCE)
                .keyBy(ConnectionStatus::getVid)
                .flatMap(new OutOfOrderConnectionStatusEventsFilterFunction())
                .name("OutOfOrderFilterFunctionConnectionStatus")
                .uid("OutOfOrderFilterFunctionConnectionStatus");
    }

    private static DataStream<EnrichedSnapshot> getEnrichedEdgeAlertsDataStream(final StreamExecutionEnvironment env,
                                                                                final ParameterTool parameterTool,
                                                                                boolean isTest) {

        String edgeAlertsCampaignTopic = parameterTool.get(FlinkRuntime.Kafka.MULTI_ALERTS_CAMPAIGN_TOPIC);
        String edgeAlertsConsumer = parameterTool.get(FlinkRuntime.Kafka.CAMPAIGN_GROUP) + "EdgeAlerts";
        KafkaConnector.KafkaProperties edgeAlertsKafkaProps = KafkaConnector.getTelemetryKafkaProperties(parameterTool, edgeAlertsConsumer, edgeAlertsCampaignTopic);
        KafkaSource<String> edgeAlertsCampaignSource = KafkaConnector.createStringKafkaSource(edgeAlertsKafkaProps, parameterTool, isTest);

        // Data stream created from edge alert campaigns
        return env.fromSource(edgeAlertsCampaignSource,
                        WatermarkStrategy.noWatermarks(),
                        edgeAlertsCampaignTopic)
                .flatMap(edgeAlertsMapperFunction)
                .name(OperatorNames.EDGE_ALERTS_SOURCE)
                .uid(OperatorNames.EDGE_ALERTS_SOURCE);
    }

    public static KafkaConnector.KafkaProperties getLKSKafkaProperties(final ParameterTool parameterTool, final String topic) {
        KafkaConnector.KafkaProperties kafkaProperties = new KafkaConnector.KafkaProperties(parameterTool);
        kafkaProperties.setBrokerFromParams(FlinkRuntime.Kafka.LKS_BROKER);
        kafkaProperties.setTopics(topic);
        kafkaProperties.setConsumerNameFromParams(FlinkRuntime.Kafka.LKS_GROUP);
        kafkaProperties.setRoleArnFromParams(FlinkRuntime.Kafka.LKS_ARN);
        kafkaProperties.setSessionNameFromParams(FlinkRuntime.Kafka.LKS_SESSION);
        kafkaProperties.setAwsRegionFromParams(FlinkRuntime.REGION_KEY);

        return kafkaProperties;
    }

    public static KafkaConnector.KafkaProperties getVehicleSnapshotProperties(final ParameterTool parameterTool, final String topic) {
        KafkaConnector.KafkaProperties kafkaProperties = new KafkaConnector.KafkaProperties(parameterTool);
        kafkaProperties.setBrokerFromParams(FlinkRuntime.VehicleSnapshot.SNAPSHOT_BROKER);
        kafkaProperties.setTopics(topic);
        kafkaProperties.setConsumerNameFromParams(FlinkRuntime.VehicleSnapshot.SNAPSHOT_GROUP);
        kafkaProperties.setRoleArnFromParams(FlinkRuntime.VehicleSnapshot.SNAPSHOT_ARN);
        kafkaProperties.setSessionNameFromParams(FlinkRuntime.VehicleSnapshot.SNAPSHOT_SESSION);
        kafkaProperties.setAwsRegionFromParams(FlinkRuntime.REGION_KEY);

        return kafkaProperties;
    }

    public static Opensearch2Sink<Tuple3<String, String, SnapshotWrapper>> getOpenSearchSink(final ParameterTool parameterTool, OpenSearchConnector.OpenSearchProperties openSearchProperties, boolean isTest) {
        int maxRetries = parameterTool.getInt(FlinkRuntime.OpenSearch.MAX_RETRIES, DEFAULT_MAX_RETRIES);
        int retryDelayInMs = parameterTool.getInt(FlinkRuntime.OpenSearch.RETRY_DELAY_IN_MS, DEFAULT_RETRY_DELAY_MILLI);
        int maxActionsToBuffer = parameterTool.getInt(FlinkRuntime.OpenSearch.MAX_ACTIONS_TO_BUFFER, DEFAULT_MAX_ACTIONS_TO_BUFFER);
        int bulkFlushSize = parameterTool.getInt(FlinkRuntime.OpenSearch.BULK_FLUSH_SIZE_MB, DEFAULT_BULK_FLUSH_SIZE_MB);
        int bulkFlushInterval = parameterTool.getInt(FlinkRuntime.OpenSearch.BULK_FLUSH_INTERVAL_MILLI, DEFAULT_BULK_FLUSH_INTERVAL);

        Opensearch2SinkBuilder<Tuple3<String, String, SnapshotWrapper>> builder = new Opensearch2SinkBuilder<>()
                .setHosts(openSearchProperties.getHttpHost())
                .setEmitter(opensearchEmitter)
                .setConnectionUsername(openSearchProperties.getUsername())
                .setConnectionPassword(openSearchProperties.getPassword())
                .setDeliveryGuarantee(DeliveryGuarantee.AT_LEAST_ONCE)
                .setBulkFlushBackoffStrategy(FlushBackoffType.EXPONENTIAL, maxRetries, retryDelayInMs)
                .setBulkFlushMaxSizeMb(bulkFlushSize)
                .setBulkFlushInterval(bulkFlushInterval)
                .setBulkFlushMaxActions(maxActionsToBuffer);

        if (isTest) {
            // Enabling insecure access for integration testing
            builder.setAllowInsecure(true);
        }

        return builder.build();
    }

    public static Opensearch2Sink<Tuple3<String, String, SnapshotWrapper>> getOpenSearchSinkInsert(final ParameterTool parameterTool, OpenSearchConnector.OpenSearchProperties openSearchProperties, boolean isTest) {
        int maxRetries = parameterTool.getInt(FlinkRuntime.OpenSearch.MAX_RETRIES, DEFAULT_MAX_RETRIES);
        int retryDelayInMs = parameterTool.getInt(FlinkRuntime.OpenSearch.RETRY_DELAY_IN_MS, DEFAULT_RETRY_DELAY_MILLI);
        int maxActionsToBuffer = parameterTool.getInt(FlinkRuntime.OpenSearch.MAX_ACTIONS_TO_BUFFER, DEFAULT_MAX_ACTIONS_TO_BUFFER);
        int bulkFlushSize = parameterTool.getInt(FlinkRuntime.OpenSearch.BULK_FLUSH_SIZE_MB, DEFAULT_BULK_FLUSH_SIZE_MB);
        int bulkFlushInterval = parameterTool.getInt(FlinkRuntime.OpenSearch.BULK_FLUSH_INTERVAL_MILLI, DEFAULT_BULK_FLUSH_INTERVAL);

        Opensearch2SinkBuilder<Tuple3<String, String, SnapshotWrapper>> builder = new Opensearch2SinkBuilder<>()
                .setHosts(openSearchProperties.getHttpHost())
                .setEmitter(opensearchEmitterInsert)
                .setConnectionUsername(openSearchProperties.getUsername())
                .setConnectionPassword(openSearchProperties.getPassword())
                .setDeliveryGuarantee(DeliveryGuarantee.AT_LEAST_ONCE)
                .setBulkFlushBackoffStrategy(FlushBackoffType.EXPONENTIAL, maxRetries, retryDelayInMs)
                .setBulkFlushMaxSizeMb(bulkFlushSize)
                .setBulkFlushInterval(bulkFlushInterval)
                .setBulkFlushMaxActions(maxActionsToBuffer)
                .setFailureHandler(opensearchFailureHandler);

        if (isTest) {
            // Enabling insecure access for integration testing
            builder.setAllowInsecure(true);
        }

        return builder.build();
    }
}
