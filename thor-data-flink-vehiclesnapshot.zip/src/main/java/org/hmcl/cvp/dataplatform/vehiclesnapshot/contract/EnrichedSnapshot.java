package org.hmcl.cvp.dataplatform.vehiclesnapshot.contract;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.hmcl.cvp.dataplatform.contract.telemetry.SignalData;
import org.hmcl.cvp.dataplatform.contract.telemetry.Tenant;

import java.util.Map;
import java.util.Set;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class EnrichedSnapshot {

    private Tenant tenant;

    private String virtualId;

    private String vehicleName;

    private String tenantId;

    private StateInfo connectionState;

    private StateInfo ignitionState;

    private StateInfo driveState;

    private StateInfo chargingState;

    private StateInfo geoFenceAlert;

    private boolean isLks;

    private Source source;

    private Map<String, SignalData> latestSignals;

    private Set<SignalData> multiAlertsData;

    private long latestEventCollectionTsp;

}
