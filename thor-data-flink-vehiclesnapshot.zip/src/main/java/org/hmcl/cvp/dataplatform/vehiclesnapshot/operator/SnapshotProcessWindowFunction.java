package org.hmcl.cvp.dataplatform.vehiclesnapshot.operator;

import lombok.extern.slf4j.Slf4j;
import org.apache.flink.api.java.utils.ParameterTool;
import org.apache.flink.configuration.Configuration;
import org.apache.flink.streaming.api.functions.windowing.ProcessWindowFunction;
import org.apache.flink.streaming.api.windowing.windows.TimeWindow;
import org.apache.flink.util.Collector;
import org.hmcl.cvp.dataplatform.commons.constants.FlinkRuntime;
import org.hmcl.cvp.dataplatform.commons.utils.TelemetryUtils;
import org.hmcl.cvp.dataplatform.contract.telemetry.Telemetry;
import org.hmcl.cvp.dataplatform.contract.telemetry.Tenant;
import org.hmcl.cvp.dataplatform.vehiclesnapshot.contract.EnrichedSnapshot;
import org.hmcl.cvp.dataplatform.vehiclesnapshot.contract.Source;
import org.hmcl.cvp.dataplatform.vehiclesnapshot.helper.VehicleSnapshotHelper;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Objects;

@Slf4j
public class SnapshotProcessWindowFunction extends ProcessWindowFunction<Telemetry, EnrichedSnapshot, String, TimeWindow> {

    private transient double configurableSpeed;
    private transient double configurableRPM;


    @Override
    public void open(Configuration parameters) throws Exception {
        super.open(parameters);

        ParameterTool parameterTool = (ParameterTool) getRuntimeContext().getExecutionConfig().getGlobalJobParameters();

        configurableSpeed = parameterTool.getDouble(FlinkRuntime.VehicleSnapshot.CAN_SPEED_IN_KM_PER_HOUR, VehicleSnapshotHelper.DEFAULT_SPEED);
        configurableRPM = parameterTool.getDouble(FlinkRuntime.VehicleSnapshot.RPM_THRESHOLD_VALUE, VehicleSnapshotHelper.DEFAULT_RPM);
    }

    @Override
    public void process(String key, Context context, Iterable<Telemetry> elements, Collector<EnrichedSnapshot> out) {

        try {
            List<Telemetry> telemetryList = toList(elements);
            if (telemetryList.isEmpty()) return;

            Tenant tenant = getTenant(telemetryList);
            String tenantId = getTenantId(telemetryList);
            String vehicleName = getVehicleName(telemetryList);
            long latestCollectionEventTime = telemetryList.stream().max(Comparator.comparingLong(Telemetry::getCollectionEventTime)).get().getCollectionEventTime();
            if (Tenant.UNKNOWN.equals(tenant) || Objects.isNull(vehicleName)) {
                log.error("No tenant or vehicle name found for vehicle {}", key);
                return;
            }

            log.debug("Incoming vehicle name {} and tenant {}", key, tenant);

            EnrichedSnapshot enrichedSnapshot = new EnrichedSnapshot();
            enrichedSnapshot.setVirtualId(key);
            enrichedSnapshot.setVehicleName(vehicleName);
            enrichedSnapshot.setTenant(tenant);
            enrichedSnapshot.setTenantId(tenantId);
            enrichedSnapshot.setSource(Source.WINDOW);
            enrichedSnapshot.setLatestSignals(new HashMap<>());
            enrichedSnapshot.setLatestEventCollectionTsp(latestCollectionEventTime);

            // Calculate and get the ignition state.
            // Note - If none of the conditions are satisfied, it will be null
            enrichedSnapshot.setIgnitionState(VehicleSnapshotHelper.getIgnitionsState(telemetryList));

            // Calculate and get the driving state
            // Note - If none of the conditions are satisfied, it will be null
            enrichedSnapshot.setDriveState(VehicleSnapshotHelper.getDriveState(telemetryList, configurableSpeed, configurableRPM));

            out.collect(enrichedSnapshot);
        } catch (Exception e) {
            log.error("Exception while process incoming events for vehicle {}: ", key, e);
        }

    }

    private List<Telemetry> toList(Iterable<Telemetry> elements) {
        List<Telemetry> list = new ArrayList<>();
        elements.forEach(list::add);

        return list;
    }

    private Tenant getTenant(List<Telemetry> telemetries) {
        return TelemetryUtils.getTenant(telemetries.get(0));
    }

    private String getTenantId(List<Telemetry> telemetries) {
        return TelemetryUtils.getTenantId(telemetries.get(0));
    }

    private String getVehicleName(List<Telemetry> telemetries) {
        return telemetries.get(0).getVehicleName();
    }

}
