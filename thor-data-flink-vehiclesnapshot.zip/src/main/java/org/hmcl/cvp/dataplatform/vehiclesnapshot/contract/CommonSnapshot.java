package org.hmcl.cvp.dataplatform.vehiclesnapshot.contract;

import com.google.gson.annotations.SerializedName;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Objects;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class CommonSnapshot {

    @SerializedName("vid")
    private String vid;

    @SerializedName("vehicleName")
    private String vehicleName;

    @SerializedName("tenantId")
    private String tenantId;

    @SerializedName("updatedBySource")
    private Source updatedBySource;

    @SerializedName("createdTsp")
    private Long createdTsp;

    @SerializedName("updatedTsp")
    private Long updatedTsp;

    @SerializedName("updatedTspIST")
    private String updatedTspIST;

    // Cloud calculated
    @SerializedName("connectionStatus")
    private SignalSnapshot connectionStatus;

    @SerializedName("ignitionStatus")
    private SignalSnapshot ignitionStatus;

    @SerializedName("chargingStatus")
    private SignalSnapshot chargingStatus;

    @SerializedName("driveStatus")
    private SignalSnapshot driveStatus;

    // Alerts
    @SerializedName("fallDown")
    private SignalSnapshot fallDown;

    @SerializedName("panic")
    private SignalSnapshot panic;

    @SerializedName("crashAndAccident")
    private SignalSnapshot crashAndAccident;

    @SerializedName("towOrTheft")
    private SignalSnapshot towOrTheft;

    @SerializedName("auxBatteryLow")
    private SignalSnapshot auxBatteryLow;

    @SerializedName("auxBatteryUnplugged")
    private SignalSnapshot auxBatteryUnplugged;

    @SerializedName("overSpeed")
    private SignalSnapshot overSpeed;

    @SerializedName("harshDriving")
    private SignalSnapshot harshDriving;

    @SerializedName("harshBraking")
    private SignalSnapshot harshBraking;

    @SerializedName("movementDetection")
    private SignalSnapshot movementDetection;

    @SerializedName("thermalRunaway")
    private SignalSnapshot thermalRunaway;

    @SerializedName("batteryOverHeating")
    private SignalSnapshot batteryOverHeating;

    // Cloud Alerts
    @SerializedName("geoFenceAlert")
    private SignalSnapshot geoFenceAlert;

    @SerializedName("lowTractionBattery")
    private SignalSnapshot lowTractionBattery;

    @SerializedName("lowFuel")
    private SignalSnapshot lowFuel;

    @SerializedName("dtc")
    private SignalSnapshot dtc;

    // LKS Common Signals
    @SerializedName("bleConnectivity")
    private SignalSnapshot bleConnectivity;

    @SerializedName("cog")
    private SignalSnapshot cog;

    @SerializedName("gpsFix")
    private SignalSnapshot gpsFix;

    @SerializedName("gpsValid")
    private SignalSnapshot gpsValid;

    @SerializedName("hDop")
    private SignalSnapshot hDop;

    @SerializedName("immoState")
    private SignalSnapshot immoState;

    @SerializedName("longitude")
    private SignalSnapshot longitude;

    @SerializedName("latitude")
    private SignalSnapshot latitude;

    @SerializedName("mainVoltage")
    private SignalSnapshot mainVoltage;

    @SerializedName("odoSignal")
    private SignalSnapshot odoSignal;

    @SerializedName("pDop")
    private SignalSnapshot pDop;

    @SerializedName("riderInfoUserId")
    private SignalSnapshot riderInfoUserId;

    @SerializedName("riderInfoUserType")
    private SignalSnapshot riderInfoUserType;

    @SerializedName("tcuIgnition")
    private SignalSnapshot tcuIgnition;

    @SerializedName("vDop")
    private SignalSnapshot vDop;

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof CommonSnapshot)) return false;
        CommonSnapshot that = (CommonSnapshot) o;
        return Objects.equals(vid, that.vid);
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(vid);
    }
}
