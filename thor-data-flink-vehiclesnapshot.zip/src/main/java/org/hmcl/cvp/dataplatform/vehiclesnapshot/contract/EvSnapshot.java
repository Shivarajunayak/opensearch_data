package org.hmcl.cvp.dataplatform.vehiclesnapshot.contract;

import com.google.gson.annotations.SerializedName;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class EvSnapshot {

    @SerializedName("batteryChargingStatus")
    private SignalSnapshot batteryChargingStatus;

    @SerializedName("batteryDetection")
    private SignalSnapshot batteryDetection;

    @SerializedName("batteryOperationModeBms1")
    private SignalSnapshot batteryOperationModeBms1;

    @SerializedName("batteryOperationModeBms2")
    private SignalSnapshot batteryOperationModeBms2;

    @SerializedName("batterySlotIdentityFront")
    private SignalSnapshot batterySlotIdentityFront;

    @SerializedName("batterySlotIdentityRear")
    private SignalSnapshot batterySlotIdentityRear;

    @SerializedName("bmsBduStatus")
    private SignalSnapshot bmsBduStatus;

    @SerializedName("bmsBduConnectionRequest")
    private SignalSnapshot bmsBduConnectionRequest;

    @SerializedName("bmsChargeStartRequest")
    private SignalSnapshot bmsChargeStartRequest;

    @SerializedName("bmsStatus")
    private SignalSnapshot bmsStatus;

    @SerializedName("bms1BatteryPackTemperature")
    private SignalSnapshot bms1BatteryPackTemperature;

    @SerializedName("bms2BatteryPackTemperature")
    private SignalSnapshot bms2BatteryPackTemperature;

    @SerializedName("bms1SohPercentage")
    private SignalSnapshot bms1SohPercentage;

    @SerializedName("bms2SohPercentage")
    private SignalSnapshot bms2SohPercentage;

    @SerializedName("brakeInputSignal")
    private SignalSnapshot brakeInputSignal;

    @SerializedName("chargeCurrentSet")
    private SignalSnapshot chargeCurrentSet;

    @SerializedName("chargerIdentity")
    private SignalSnapshot chargerIdentity;

    @SerializedName("chargerPowerState")
    private SignalSnapshot chargerPowerState;

    @SerializedName("chargerState")
    private SignalSnapshot chargerState;

    @SerializedName("chargerStatus")
    private SignalSnapshot chargerStatus;

    @SerializedName("chargerVoltageSet")
    private SignalSnapshot chargerVoltageSet;

    @SerializedName("cruiseControlState")
    private SignalSnapshot cruiseControlState;

    @SerializedName("cutOffCurrent")
    private SignalSnapshot cutOffCurrent;

    @SerializedName("driveModeSignal")
    private SignalSnapshot driveModeSignal;

    @SerializedName("estimatedChargingTime")
    private SignalSnapshot estimatedChargingTime;

    @SerializedName("motorStatus")
    private SignalSnapshot motorStatus;

    @SerializedName("odoSignalHr")
    private SignalSnapshot odoSignalHr;

    @SerializedName("packCurrent")
    private SignalSnapshot packCurrent;

    @SerializedName("packVoltage")
    private SignalSnapshot packVoltage;

    @SerializedName("preChargeCurrent")
    private SignalSnapshot preChargeCurrent;

    @SerializedName("readyStatus")
    private SignalSnapshot readyStatus;

    @SerializedName("remainingCapacity")
    private SignalSnapshot remainingCapacity;

    @SerializedName("remainingRangeInKm")
    private SignalSnapshot remainingRangeInKm;

    @SerializedName("satelliteInUse")
    private SignalSnapshot satelliteInUse;

    @SerializedName("satelliteInView")
    private SignalSnapshot satelliteInView;

    @SerializedName("sideStand")
    private SignalSnapshot sideStand;

    @SerializedName("socUserBms1")
    private SignalSnapshot socUserBms1;

    @SerializedName("socUserBms2")
    private SignalSnapshot socUserBms2;

    @SerializedName("socUser")
    private SignalSnapshot socUser;

    @SerializedName("temperatureStatusVcu")
    private SignalSnapshot temperatureStatusVcu;

    @SerializedName("thermalRunStatusAggregate")
    private SignalSnapshot thermalRunStatusAggregate;

    @SerializedName("thermalRunawayWarning")
    private SignalSnapshot thermalRunawayWarning;

    @SerializedName("throttle")
    private SignalSnapshot throttle;

    @SerializedName("totalUsableCapacity")
    private SignalSnapshot totalUsableCapacity;

    @SerializedName("totalUsableEnergy")
    private SignalSnapshot totalUsableEnergy;

    @SerializedName("totalUsableEnergyBms1")
    private SignalSnapshot totalUsableEnergyBms1;

    @SerializedName("totalUsableEnergyBms2")
    private SignalSnapshot totalUsableEnergyBms2;

    @SerializedName("vehicleSpeedDisplay")
    private SignalSnapshot vehicleSpeedDisplay;

    @SerializedName("idBMS1")
    private SignalSnapshot idBMS1;

    @SerializedName("idBMS2")
    private SignalSnapshot idBMS2;
}
