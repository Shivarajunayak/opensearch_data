package org.hmcl.cvp.dataplatform.vehiclesnapshot.helper;

import com.google.gson.JsonElement;
import lombok.extern.slf4j.Slf4j;
import org.hmcl.cvp.dataplatform.commons.catalogue.SignalCatalogue;
import org.hmcl.cvp.dataplatform.commons.utils.DateUtils;
import org.hmcl.cvp.dataplatform.commons.utils.FlinkUtils;
import org.hmcl.cvp.dataplatform.commons.utils.SignalUtils;
import org.hmcl.cvp.dataplatform.commons.utils.TelemetryUtils;
import org.hmcl.cvp.dataplatform.contract.telemetry.SignalData;
import org.hmcl.cvp.dataplatform.contract.telemetry.Telemetry;
import org.hmcl.cvp.dataplatform.contract.telemetry.Tenant;
import org.hmcl.cvp.dataplatform.vehiclesnapshot.contract.ChargingState;
import org.hmcl.cvp.dataplatform.vehiclesnapshot.contract.CommonSnapshot;
import org.hmcl.cvp.dataplatform.vehiclesnapshot.contract.DriveState;
import org.hmcl.cvp.dataplatform.vehiclesnapshot.contract.EnrichedSnapshot;
import org.hmcl.cvp.dataplatform.vehiclesnapshot.contract.EvSnapshot;
import org.hmcl.cvp.dataplatform.vehiclesnapshot.contract.IceSnapshot;
import org.hmcl.cvp.dataplatform.vehiclesnapshot.contract.IgnitionState;
import org.hmcl.cvp.dataplatform.vehiclesnapshot.contract.SnapshotWrapper;
import org.hmcl.cvp.dataplatform.vehiclesnapshot.contract.StateInfo;

import java.util.Arrays;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.Set;

@Slf4j
public class VehicleSnapshotHelper {

    public static final Double DEFAULT_SPEED = 5.0;
    public static final Double DEFAULT_RPM = 1100.0;
    public static final String CHARGING = "charging";
    public static final String CHARGE = "charge";

    private static final Integer MOTOR_DEFAULT_SIGNAL = 0;
    private static final Integer MOTOR_ON_SIGNAL = 3;
    private static final Integer CHARGING_SIGNAL = 2;


    private VehicleSnapshotHelper() {
    }

    public static StateInfo getConnectionState(String connectionStatus) {
        // Since data is coming to flink
        return StateInfo.builder()
                .value(connectionStatus)
                .time(DateUtils.currentEpochTime())
                .build();
    }

    public static StateInfo getIgnitionsState(List<Telemetry> elements) {

        // Check if ignition alert signal is present
        Optional<SignalData> latestIgnitionAlert = elements.stream()
                .flatMap(t -> SignalUtils.getSignals(t, SignalCatalogue.getIgnitionAlertInfo()).stream())
                .max(Comparator.comparing(SignalData::getTime));

        if (latestIgnitionAlert.isPresent()) {
            SignalData signal = latestIgnitionAlert.get();
            boolean isIgnitionOn = (boolean) signal.getValue();
            return StateInfo.builder()
                    .value(isIgnitionOn ? IgnitionState.ON.value() : IgnitionState.OFF.value())
                    .time(signal.getTime())
                    .build();
        }

        // Get the latest TCU ignition signal
        Optional<SignalData> latestTcuIgnitionSignal = elements.stream()
                .flatMap(t -> SignalUtils.getSignals(t, SignalCatalogue.getTcuIgnitionInfo()).stream())
                .max(Comparator.comparing(SignalData::getTime));

        if (latestTcuIgnitionSignal.isPresent()) {
            SignalData signal = latestTcuIgnitionSignal.get();
            boolean isIgnitionOn = (boolean) signal.getValue();
            return StateInfo.builder()
                    .value(isIgnitionOn ? IgnitionState.ON.value() : IgnitionState.OFF.value())
                    .time(signal.getTime())
                    .build();
        }

        long latestTelemetryTime = getLatestTelemetry(elements);

        return StateInfo.builder()
                .value(IgnitionState.OFF.value())
                .time(latestTelemetryTime)
                .build();
    }

    public static StateInfo getDriveState(List<Telemetry> elements, double configurableSpeed, double configurableRPM) {
        long totalCount = elements.size();

        // Get all the events where ignition is off and engine (in case of Ice) and motor(in case of EV) is off
        long countOfStoppedEvents = elements.stream()
                .filter(t -> {
                    Tenant tenant = TelemetryUtils.getTenant(t);
                    return !isIgnitionOn(t) && !isEngineOrMotorOn(t, tenant, configurableRPM);
                })
                .count();

        // If all the events for the latest 30 seconds satisfy the stopped condition, then the vehicle has stopped
        if (countOfStoppedEvents == totalCount) {
            return StateInfo.builder()
                    .value(DriveState.STOPPED.value())
                    .time(getLatestTelemetry(elements))
                    .build();
        }

        // Get all the events where ignition is on and engine (in case of Ice) and motor(in case of EV) is on and speed is over 5km
        long countOfMovingEvents = elements.stream()
                .filter(t -> {
                    Tenant tenant = TelemetryUtils.getTenant(t);
                    return isEngineOrMotorOn(t, tenant, configurableRPM) && !isSpeedLessThanSomeValue(t, configurableSpeed);
                })
                .count();

        if (countOfMovingEvents == totalCount) {
            return StateInfo.builder()
                    .value(DriveState.MOVING.value())
                    .time(getLatestTelemetry(elements))
                    .build();
        }

        // Get all the events where ignition is on and engine (in case of Ice) should be less than 1100 RPM
        // and motor(in case of EV) is 1 or 2 or 3 and speed is less 5 km
        long countOfIdleEvents = elements.stream()
                .filter(t ->
                        isIgnitionOn(t)
                                && (!isEngineOn(t, configurableRPM) || isMotorSignalValid(t))
                                && isSpeedLessThanSomeValue(t, configurableSpeed))
                .count();

        if (countOfIdleEvents == totalCount) {
            return StateInfo.builder()
                    .value(DriveState.IDLE.value())
                    .time(getLatestTelemetry(elements))
                    .build();
        }

        return null;
    }

    public static void setChargingState(String vid, EnrichedSnapshot enrichedSnapshot, Telemetry telemetry) {
        try {
            enrichedSnapshot.setChargingState(getChargingState(telemetry));
        } catch (Exception e) {
            log.error("Exception while calculating charging state for vehicle {}", vid, e);
        }
    }

    public static StateInfo getChargingState(Telemetry chargingElement) {
        // Check if any charging related events are present, if not, then return null so state is not updated
        if (!isChargingCampaign(chargingElement)) {
            log.info("getChargingState: No relevant charging events found, returning null and not updating state");
            return null;
        }

        // Fetch the latest BDU connection request signal
        Set<SignalData> bduConnectionRequestSignals = SignalUtils.getSignals(chargingElement, SignalCatalogue.getBMSBDUConnectionRequestInfo());
        Optional<SignalData> bduConnectionRequestLatestSignal = SignalUtils.getLatestSignal(bduConnectionRequestSignals);
        Integer bduConnectionRequestLatestValue = bduConnectionRequestLatestSignal
                .map(SignalUtils::getIntegerSignalValue)
                .orElse(null);

        // Fetch the latest charger state signal
        Set<SignalData> chargerStateSignals = SignalUtils.getSignals(chargingElement, SignalCatalogue.getChargerStateInfo());
        Optional<SignalData> chargerStateLatestSignal = SignalUtils.getLatestSignal(chargerStateSignals);
        Integer chargerStateLatestValue = chargerStateLatestSignal
                .map(SignalUtils::getIntegerSignalValue)
                .orElse(null);

        // Fetch the latest charger power state signal
        Set<SignalData> chargerPowerStateSignals = SignalUtils.getSignals(chargingElement, SignalCatalogue.getChargerPowerStateInfo());
        Optional<SignalData> chargerPowerStateLatestSignal = SignalUtils.getLatestSignal(chargerPowerStateSignals);
        Integer chargerPowerStateLatestValue = chargerPowerStateLatestSignal
                .map(SignalUtils::getIntegerSignalValue)
                .orElse(null);

        if (bduConnectionRequestLatestValue == null || chargerStateLatestValue == null || chargerPowerStateLatestValue == null) {
            log.info("isCharging: One or more signals are null, returning null and not updating state");
            return null;
        }

        boolean isCharging = Objects.equals(bduConnectionRequestLatestValue, CHARGING_SIGNAL)
                && Objects.equals(chargerStateLatestValue, CHARGING_SIGNAL)
                && Objects.equals(chargerPowerStateLatestValue, CHARGING_SIGNAL);

        if (isCharging) {
            return StateInfo.builder()
                    .value(ChargingState.CHARGING.value())
                    .time(chargingElement.getCollectionEventTime())
                    .build();
        }

        // Get all the events with charging_state is false.
        return StateInfo.builder()
                .value(ChargingState.NOT_CHARGING.value())
                .time(chargingElement.getCollectionEventTime())
                .build();
    }

    public static boolean isIgnitionOn(Telemetry value) {
        Set<SignalData> ignitionSignals = SignalUtils.getSignals(value, SignalCatalogue.getTcuIgnitionInfo());
        if (ignitionSignals.isEmpty()) {
            ignitionSignals = SignalUtils.getSignals(value, SignalCatalogue.getIgnitionAlertInfo());
        }
        return SignalUtils.getLatestSignalBooleanValue(ignitionSignals);
    }

    public static boolean isEngineOrMotorOn(Telemetry value, Tenant tenant, double configurableRPM) {
        if (tenant.equals(Tenant.EV)) {
            return isMotorOn(value);
        }

        return isEngineOn(value, configurableRPM);
    }

    public static boolean isMotorOn(Telemetry value) {
        Set<SignalData> motorSignals = SignalUtils.getSignals(value, SignalCatalogue.getMotorStatusInfo());
        Optional<SignalData> latestSignal = SignalUtils.getLatestSignal(motorSignals);
        if (latestSignal.isEmpty()) return false;

        int signalValue = SignalUtils.getIntegerSignalValue(latestSignal.get());

        return signalValue == MOTOR_ON_SIGNAL;
    }

    public static boolean isMotorSignalValid(Telemetry value) {
        Set<SignalData> motorSignals = SignalUtils.getSignals(value, SignalCatalogue.getMotorStatusInfo());
        Optional<SignalData> latestSignal = SignalUtils.getLatestSignal(motorSignals);
        if (latestSignal.isEmpty()) return false;

        int signalValue = SignalUtils.getIntegerSignalValue(latestSignal.get());

        return signalValue != MOTOR_DEFAULT_SIGNAL;
    }

    public static boolean isEngineOn(Telemetry value, double configurableRPM) {
        Set<SignalData> engineRunSignals = SignalUtils.getSignals(value, SignalCatalogue.getEngineRunStatusInfo());
        if (engineRunSignals.isEmpty()) {
            // Some older vehicles don't have engine status signal. So checking RPM
            Set<SignalData> engineSpeedSignals = SignalUtils.getSignals(value, SignalCatalogue.getEngineSpeedInfo());
            Optional<SignalData> latestSignal = SignalUtils.getLatestSignal(engineSpeedSignals);
            if (latestSignal.isEmpty()) return false;

            int signalValue = SignalUtils.getIntegerSignalValue(latestSignal.get());

            return signalValue > configurableRPM;
        }
        return SignalUtils.getLatestSignalBooleanValue(engineRunSignals);
    }

    public static boolean isSpeedLessThanSomeValue(Telemetry value, double configurableSpeed) {

        Set<SignalData> clusterSpeedSignals = SignalUtils.getSignals(value, SignalCatalogue.getVehicleSpeedDisplayInfo());
        Optional<SignalData> latestSignal = SignalUtils.getLatestSignal(clusterSpeedSignals);
        if (latestSignal.isEmpty()) return false;
        int latestValue = SignalUtils.getIntegerSignalValue(latestSignal.get());

        return configurableSpeed > latestValue;

    }

    public static long getLatestTelemetry(List<Telemetry> telemetries) {
        return telemetries
                .stream()
                .map(Telemetry::getCollectionEventTime)
                .max(Comparator.comparing(k -> k))
                .orElse(DateUtils.currentEpochTime());

    }

    public static Map<String, Object> getOpenSearchDocument(String incomingVid, SnapshotWrapper snapshotWrapper) {
        try {
            CommonSnapshot commonSnapshot = snapshotWrapper.getCommonSnapshot();
            Map<String, Object> commonMap = FlinkUtils.toMap(commonSnapshot);

            if (snapshotWrapper.getIsEv()) {
                EvSnapshot evSnapshot = snapshotWrapper.getEvSnapshot();
                Map<String, Object> evMap = FlinkUtils.toMap(evSnapshot);

                if (Objects.nonNull(evMap) && !evMap.isEmpty()) {
                    commonMap.putAll(evMap);
                }

            } else {
                IceSnapshot iceSnapshot = snapshotWrapper.getIceSnapshot();
                Map<String, Object> iceMap = FlinkUtils.toMap(iceSnapshot);

                if (Objects.nonNull(iceMap) && !iceMap.isEmpty()) {
                    commonMap.putAll(iceMap);
                }

            }
            commonMap.put("latestEventCollectionTsp", snapshotWrapper.getLatestEventCollectionTsp());

            return commonMap;
        } catch (Exception e) {
            log.error("Error while converting POJO to HashMap for vehicle {}", incomingVid);
        }

        return new HashMap<>();
    }

    public static Map<String, JsonElement> getMapOfJsonElements(String incomingVid, SnapshotWrapper snapshotWrapper) {
        try {
            String[] fields = {
                    "vid", "vehicleName", "updatedBySource", "createdTsp", "thermalRunaway", "batteryOverHeating",
                    "batteryOperationModeBms2", "brakeInputSignal", "readyStatus", "auxBatteryLow", "harshBraking",
                    "riderInfoUserId", "sideStand", "geoFenceAlert", "bmsChargeStartRequest", "fuelLevel", "updatedTsp",
                    "updatedTspIST", "connectionStatus", "ignitionStatus", "driveStatus", "immoState", "riderInfoUserType",
                    "batteryOperationModeBms1", "driveModeSignal", "throttle", "fallDown", "crashAndAccident", "towOrTheft",
                    "auxBatteryUnplugged", "overSpeed", "movementDetection", "odoSignal", "batteryChargingStatus",
                    "vehicleSpeedDisplay", "chargeCurrentSet", "chargerVoltageSet", "cutOffCurrent", "estimatedChargingTime",
                    "preChargeCurrent", "distanceTravelledWithMil", "tenantId"
            };

            Set<String> allowedKeys = new HashSet<>(Arrays.asList(fields));

            CommonSnapshot commonSnapshot = snapshotWrapper.getCommonSnapshot();
            Map<String, JsonElement> commonMap = FlinkUtils.toJsonElement(commonSnapshot);

            if (snapshotWrapper.getIsEv()) {
                EvSnapshot evSnapshot = snapshotWrapper.getEvSnapshot();
                Map<String, JsonElement> evMap = FlinkUtils.toJsonElement(evSnapshot);
                if (evMap != null && !evMap.isEmpty()) {
                    commonMap.putAll(evMap);
                }
            } else {
                IceSnapshot iceSnapshot = snapshotWrapper.getIceSnapshot();
                Map<String, JsonElement> iceMap = FlinkUtils.toJsonElement(iceSnapshot);
                if (iceMap != null && !iceMap.isEmpty()) {
                    commonMap.putAll(iceMap);
                }
            }

            // Keep only allowed keys
            commonMap.keySet().retainAll(allowedKeys);

            return commonMap;
        } catch (Exception e) {
            log.error("Error while converting POJO to HashMap of json elements for vehicle {}", incomingVid, e);
        }

        return new HashMap<>();
    }



    private static boolean isChargingCampaign(Telemetry telemetry) {
        String campaignName = telemetry.getCampaignName();
        if (Objects.isNull(campaignName)) return false;

        return campaignName.toLowerCase().contains(CHARGING) || campaignName.toLowerCase().contains(CHARGE);
    }


}
