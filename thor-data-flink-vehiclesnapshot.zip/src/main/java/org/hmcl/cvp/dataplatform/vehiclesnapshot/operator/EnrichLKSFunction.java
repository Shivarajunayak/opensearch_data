package org.hmcl.cvp.dataplatform.vehiclesnapshot.operator;

import com.google.gson.Gson;
import lombok.extern.slf4j.Slf4j;
import org.apache.flink.api.common.functions.RichFlatMapFunction;
import org.apache.flink.api.java.tuple.Tuple2;
import org.apache.flink.api.java.utils.ParameterTool;
import org.apache.flink.configuration.Configuration;
import org.apache.flink.metrics.Counter;
import org.apache.flink.util.Collector;
import org.hmcl.cvp.dataplatform.commons.catalogue.DimensionCatalogue;
import org.hmcl.cvp.dataplatform.commons.constants.Constants;
import org.hmcl.cvp.dataplatform.commons.constants.FlinkRuntime;
import org.hmcl.cvp.dataplatform.commons.utils.DateUtils;
import org.hmcl.cvp.dataplatform.commons.utils.GsonUtils;
import org.hmcl.cvp.dataplatform.contract.lks.LKSMessage;
import org.hmcl.cvp.dataplatform.contract.lks.LKSMessagePayload;
import org.hmcl.cvp.dataplatform.contract.lks.LKSSignal;
import org.hmcl.cvp.dataplatform.contract.lks.MqttUserProperties;
import org.hmcl.cvp.dataplatform.contract.telemetry.SignalData;
import org.hmcl.cvp.dataplatform.contract.telemetry.Telemetry;
import org.hmcl.cvp.dataplatform.contract.telemetry.Tenant;
import org.hmcl.cvp.dataplatform.vehiclesnapshot.contract.EnrichedSnapshot;
import org.hmcl.cvp.dataplatform.vehiclesnapshot.contract.Source;
import org.hmcl.cvp.dataplatform.vehiclesnapshot.helper.VehicleSnapshotHelper;

import java.time.Instant;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Set;

@Slf4j
public class EnrichLKSFunction extends RichFlatMapFunction<String, EnrichedSnapshot> {
    private static final Gson GSON = GsonUtils.getGson();

    private transient double configurableSpeed;
    private transient double configurableRPM;

    private transient Counter numInputCounter;
    private transient Counter numSuccessCounter;
    private transient Counter numErrorCounter;

    private Counter counterInitializer(String counterName) {
        return getRuntimeContext()
                .getMetricGroup()
                .addGroup(Constants.METRIC_GROUP_NAME)
                .addGroup("EnrichLKS")
                .counter(counterName);
    }

    @Override
    public void open(Configuration parameters) throws Exception {
        super.open(parameters);
        numInputCounter = counterInitializer("numInputEvents");
        numSuccessCounter = counterInitializer("numSuccessEvents");
        numErrorCounter = counterInitializer("numErrorEvents");

        ParameterTool parameterTool = (ParameterTool) getRuntimeContext().getExecutionConfig().getGlobalJobParameters();

        configurableSpeed = parameterTool.getDouble(FlinkRuntime.VehicleSnapshot.CAN_SPEED_IN_KM_PER_HOUR, VehicleSnapshotHelper.DEFAULT_SPEED);
        configurableRPM = parameterTool.getDouble(FlinkRuntime.VehicleSnapshot.RPM_THRESHOLD_VALUE, VehicleSnapshotHelper.DEFAULT_RPM);
    }

    @Override
    public void flatMap(String value, Collector<EnrichedSnapshot> out) {
        log.debug("Received at {} with LKS Value - {}", DateUtils.currentEpochTime(), value);
        try {
            numInputCounter.inc();
            LKSMessage lksMessage = GSON.fromJson(value, LKSMessage.class);

            Tuple2<Boolean, String> valid = validate(lksMessage);

            // LKS Message is not valid
            if (Boolean.FALSE.equals(valid.f0)) {
                numErrorCounter.inc();
                log.error(valid.f1);
                return;
            }

            MqttUserProperties mqttProps = getUserProperties(lksMessage.getMqttUserProperties());
            LKSMessagePayload payload = lksMessage.getLksMessagePayload();

            String vid = mqttProps.getVirtualId();

            long time = payload.getTimeMs();
            long currentTime = Instant.now().toEpochMilli();
            if(time > currentTime) {
                log.debug("Somehow event time {} is in future as compared to current time {} for vehicle {}", time, currentTime, vid);
                numErrorCounter.inc();
                return;
            }

            EnrichedSnapshot enrichedSnapshot = new EnrichedSnapshot();
            enrichedSnapshot.setVirtualId(vid);
            enrichedSnapshot.setVehicleName(mqttProps.getVehicleName());
            enrichedSnapshot.setTenant(Tenant.fromTenantId(mqttProps.getTenantId()));
            enrichedSnapshot.setTenantId(mqttProps.getTenantId());
            enrichedSnapshot.setLks(true);
            enrichedSnapshot.setSource(Source.LKS);
            enrichedSnapshot.setLatestEventCollectionTsp(time);

            // This is needed for state calculation
            Telemetry telemetry = convertToTelemetry(lksMessage);

            setIgnitionState(vid, enrichedSnapshot, telemetry);

            setDriveState(vid, enrichedSnapshot, telemetry);

            VehicleSnapshotHelper.setChargingState(vid, enrichedSnapshot, telemetry);

            Map<String, SignalData> signalMap = getSignalMap(payload);
            enrichedSnapshot.setLatestSignals(signalMap);

            numSuccessCounter.inc();
            out.collect(enrichedSnapshot);

        } catch (Exception e) {
            numErrorCounter.inc();
            log.error("An error occurred while normalising EnrichedLKS {} to Telemetry: ", value, e);
        }

    }


    private void setIgnitionState(String vid, EnrichedSnapshot enrichedSnapshot, Telemetry telemetry) {
        try {
            enrichedSnapshot.setIgnitionState(VehicleSnapshotHelper.getIgnitionsState(List.of(telemetry)));
        } catch (Exception e) {
            log.error("Exception while calculating ignition state for vehicle {}", vid, e);
        }
    }

    private void setDriveState(String vid, EnrichedSnapshot enrichedSnapshot, Telemetry telemetry) {
        try {
            enrichedSnapshot.setDriveState(VehicleSnapshotHelper.getDriveState(List.of(telemetry), configurableSpeed, configurableRPM));
        } catch (Exception e) {
            log.error("Exception while calculating drive state for vehicle {}", vid, e);
        }
    }

    private Tuple2<Boolean, String> validate(LKSMessage lksMessage) {
        List<MqttUserProperties> mqttProps = lksMessage.getMqttUserProperties();
        if (Objects.isNull(mqttProps) || mqttProps.isEmpty()) {
            return new Tuple2<>(false, "MqttUserProperties is missing");
        }


        MqttUserProperties mqttUserProperties = getUserProperties(mqttProps);
        log.info("MqttUserProperties: {}", mqttUserProperties);
        if (Objects.isNull(mqttUserProperties.getTenantId())
                || Objects.isNull(mqttUserProperties.getVirtualId())
                || Objects.isNull(mqttUserProperties.getVehicleName())) {
            return new Tuple2<>(false, "TenantId or VirtualId is missing");
        }

        LKSMessagePayload payload = lksMessage.getLksMessagePayload();
        if (Objects.isNull(payload) || (Objects.isNull(payload.getSignals())) || (payload.getSignals().isEmpty())) {
            return new Tuple2<>(false, "Signals are missing");
        }

        return new Tuple2<>(true, "Valid");
    }

    private MqttUserProperties getUserProperties(List<MqttUserProperties> mqttProps) {
        MqttUserProperties mqttUserProperties = new MqttUserProperties();

        for (MqttUserProperties props : mqttProps) {

            if (Objects.nonNull(props.getVehicleName())) {
                mqttUserProperties.setVehicleName(props.getVehicleName());
            }

            if (Objects.nonNull(props.getVirtualId())) {
                mqttUserProperties.setVirtualId(props.getVirtualId());
            }

            if (Objects.nonNull(props.getTenantId())) {
                mqttUserProperties.setTenantId(props.getTenantId());
            }

            if (Objects.nonNull(props.getTemplateName())) {
                mqttUserProperties.setTemplateName(props.getTemplateName());
            }

        }
        return mqttUserProperties;

    }

    private Map<String, SignalData> getSignalMap(LKSMessagePayload payload) {
        Map<String, SignalData> signalDataMap = new HashMap<>();
        List<LKSSignal> lskSignals = payload.getSignals();
        long time = payload.getTimeMs();

        for (LKSSignal lskSignal : lskSignals) {
            String name = lskSignal.getName();
            SignalData signalData = getSignalData(lskSignal, time);
            signalDataMap.put(name, signalData);
        }

        return signalDataMap;
    }

    private SignalData getSignalData(LKSSignal lskSignal, long time) {
        SignalData signalData = new SignalData();
        signalData.setTime(time);

        if (Objects.nonNull(lskSignal.getBooleanValue())) {
            signalData.setDataType("BOOLEAN");
            signalData.setValue(lskSignal.getBooleanValue());
        } else {
            signalData.setDataType("DOUBLE");
            signalData.setValue(lskSignal.getDoubleValue());
        }

        return signalData;
    }

    private Telemetry convertToTelemetry(LKSMessage lksMessage) {
        MqttUserProperties mqttProps = getUserProperties(lksMessage.getMqttUserProperties());
        LKSMessagePayload payload = lksMessage.getLksMessagePayload();

        Telemetry telemetry = new Telemetry();
        telemetry.setDimensions(getDimensions(mqttProps));
        telemetry.setVehicleName(mqttProps.getVehicleName());
        telemetry.setSignals(getSignals(payload));
        telemetry.setCollectionEventTime(payload.getTimeMs());

        return telemetry;
    }

    private Map<String, String> getDimensions(MqttUserProperties mqttProps) {
        Map<String, String> dimensions = new HashMap<>();
        dimensions.put(DimensionCatalogue.getTenantIdKey(), mqttProps.getTenantId());
        dimensions.put(DimensionCatalogue.getVirtualIdKey(), mqttProps.getVirtualId());
        return dimensions;
    }

    private Map<String, Set<SignalData>> getSignals(LKSMessagePayload payload) {
        Map<String, Set<SignalData>> signals = new HashMap<>();
        List<LKSSignal> lskSignals = payload.getSignals();
        long time = payload.getTimeMs();

        for (LKSSignal lskSignal : lskSignals) {
            String name = lskSignal.getName();
            SignalData signalData = getSignalData(lskSignal, time);
            Set<SignalData> existingSignals = signals.getOrDefault(name, new HashSet<>());
            existingSignals.add(signalData);
            signals.put(name, existingSignals);
        }
        return signals;
    }

}