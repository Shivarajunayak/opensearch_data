package org.hmcl.cvp.dataplatform.vehiclesnapshot.contract;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class LatestValue {

    private boolean isLatest;

    private boolean isFirstTime;

    private SignalSnapshot signalSnapshot;
}
