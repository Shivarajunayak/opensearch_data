package org.hmcl.cvp.dataplatform.vehiclesnapshot.operator;

import lombok.extern.slf4j.Slf4j;
import org.apache.flink.api.connector.sink2.SinkWriter;
import org.apache.flink.api.java.tuple.Tuple3;
import org.apache.flink.connector.opensearch.sink.OpensearchEmitter;
import org.apache.flink.connector.opensearch.sink.RequestIndexer;
import org.hmcl.cvp.dataplatform.commons.utils.DateUtils;
import org.hmcl.cvp.dataplatform.vehiclesnapshot.contract.SnapshotWrapper;
import org.hmcl.cvp.dataplatform.vehiclesnapshot.helper.VehicleSnapshotHelper;
import org.opensearch.action.DocWriteRequest;
import org.opensearch.action.index.IndexRequest;
import org.opensearch.action.update.UpdateRequest;
import org.opensearch.client.Requests;

import java.util.Map;

@Slf4j
public class VehicleSnapshotOpenSearchEmitter implements OpensearchEmitter<Tuple3<String, String, SnapshotWrapper>> {

    /**
     * One use case for using UpdateRequest is that when state is cleared for some reason,
     * the whole doc will not get replaced.
     */
    private UpdateRequest createUpdateRequest(String index, String vid, Map<String, Object> document) {
        UpdateRequest updateRequest = new UpdateRequest();
        updateRequest.docAsUpsert(true);
        updateRequest.id(vid);
        updateRequest.index(index);
        updateRequest.doc(document);
        return updateRequest;
    }

    @Override
    public void emit(Tuple3<String, String, SnapshotWrapper> element, SinkWriter.Context context, RequestIndexer indexer) {
        String index = element.f0;
        String incomingVid = element.f1;

        SnapshotWrapper snapshotWrapper = element.f2;
        Map<String, Object> opensearchDocument = VehicleSnapshotHelper.getOpenSearchDocument(incomingVid, snapshotWrapper);

        if (opensearchDocument.isEmpty()) {
            log.error("Insertion of {} into index {} for vehicle {} failed", snapshotWrapper, index, indexer);
            return;
        }

        log.debug("Document index request created at {} for vehicle {}. For lks? {}", DateUtils.currentEpochTime(),
                incomingVid, snapshotWrapper.getIsLks());

        UpdateRequest updateRequest = createUpdateRequest(index, incomingVid, opensearchDocument);
        indexer.add(updateRequest);
    }

}
