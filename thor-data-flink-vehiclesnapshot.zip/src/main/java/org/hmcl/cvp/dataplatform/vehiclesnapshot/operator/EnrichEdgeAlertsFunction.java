package org.hmcl.cvp.dataplatform.vehiclesnapshot.operator;

import lombok.extern.slf4j.Slf4j;
import org.apache.flink.api.common.functions.RichFlatMapFunction;
import org.apache.flink.configuration.Configuration;
import org.apache.flink.metrics.Counter;
import org.apache.flink.util.Collector;
import org.hmcl.cvp.dataplatform.commons.catalogue.SignalCatalogue;
import org.hmcl.cvp.dataplatform.commons.constants.Constants;
import org.hmcl.cvp.dataplatform.commons.utils.SignalUtils;
import org.hmcl.cvp.dataplatform.commons.utils.TelemetryUtils;
import org.hmcl.cvp.dataplatform.contract.telemetry.SignalData;
import org.hmcl.cvp.dataplatform.contract.telemetry.Telemetry;
import org.hmcl.cvp.dataplatform.contract.telemetry.Tenant;
import org.hmcl.cvp.dataplatform.vehiclesnapshot.contract.EnrichedSnapshot;
import org.hmcl.cvp.dataplatform.vehiclesnapshot.contract.Source;

import java.time.Instant;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.Set;

@Slf4j
public class EnrichEdgeAlertsFunction extends RichFlatMapFunction<String, EnrichedSnapshot> {

    private transient Counter numInputCounter;
    private transient Counter numErrorCounter;

    private Counter counterInitializer(String counterName) {
        return getRuntimeContext()
                .getMetricGroup()
                .addGroup(Constants.METRIC_GROUP_NAME)
                .addGroup("EnrichEdgeAlert")
                .counter(counterName);
    }

    @Override
    public void open(Configuration parameters) throws Exception {
        super.open(parameters);
        numInputCounter = counterInitializer("numInputEvents");
        numErrorCounter = counterInitializer("numErrorEvents");
    }

    @Override
    public void flatMap(String value, Collector<EnrichedSnapshot> out) {
        try {
            numInputCounter.inc();
            Telemetry telemetry = TelemetryUtils.fromJson(value);

            if (Objects.isNull(telemetry)) {
                log.error("Deserialization failed for {}", value);
                numErrorCounter.inc();
                return;
            }

            Map<String, String> dimensions = telemetry.getDimensions();
            Map<String, Set<SignalData>> signals = telemetry.getSignals();

            if (Objects.isNull(dimensions) || Objects.isNull(signals)) {
                log.error("Dimensions or signals not present");
                numErrorCounter.inc();
                return;
            }

            String vid = TelemetryUtils.getVirtualId(dimensions);
            String tenantId = TelemetryUtils.getTenantId(telemetry);

            if (Objects.isNull(vid) || Objects.isNull(tenantId)) {
                log.error("TenantId or VirtualId not present");
                numErrorCounter.inc();
                return;
            }

            // Rogue Telemetry data needs to be filtered
            long currentTime = Instant.now().toEpochMilli();
            long collectionEventTime = telemetry.getCollectionEventTime();
            if (collectionEventTime > currentTime) {
                numErrorCounter.inc();
                log.warn("Incoming event for vehicle {} is in the future!. Incoming time {} and current time {}", vid,
                        collectionEventTime, currentTime);
                return;
            }

            Set<SignalData> multiAlertsData = SignalUtils.getSignals(telemetry, SignalCatalogue.getMultiAlertInfo());
            if (multiAlertsData.isEmpty()) {
                numErrorCounter.inc();
                log.warn("Incoming event for vehicle {} is not having multi alerts", vid);
                return;
            }

            Tenant tenant = TelemetryUtils.getTenant(telemetry);

            EnrichedSnapshot enrichedSnapshot = new EnrichedSnapshot();
            enrichedSnapshot.setVirtualId(vid);
            enrichedSnapshot.setVehicleName(telemetry.getVehicleName());
            enrichedSnapshot.setTenant(tenant);
            enrichedSnapshot.setTenantId(tenantId);
            enrichedSnapshot.setSource(Source.MULTI_EDGE_ALERTS);
            enrichedSnapshot.setLatestSignals(getLatestSignals(telemetry));
            enrichedSnapshot.setLatestEventCollectionTsp(collectionEventTime);

            enrichedSnapshot.setMultiAlertsData(multiAlertsData);

            out.collect(enrichedSnapshot);

        } catch (Exception e) {
            log.error("Exception while processing edge alerts data {}", value, e);
            numErrorCounter.inc();
        }
    }

    private Map<String, SignalData> getLatestSignals(Telemetry telemetry) {
        Map<String, SignalData> latestSignalData = new HashMap<>();
        Map<String, Set<SignalData>> signals = telemetry.getSignals();
        signals.forEach((k, v) -> {
            Optional<SignalData> latestSignal = v.stream().max(Comparator.comparing(SignalData::getTime));
            latestSignal.ifPresent(signalData -> latestSignalData.put(k, signalData));
        });

        return latestSignalData;
    }

}
