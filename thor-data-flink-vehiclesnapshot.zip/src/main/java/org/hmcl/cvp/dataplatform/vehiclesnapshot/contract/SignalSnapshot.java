package org.hmcl.cvp.dataplatform.vehiclesnapshot.contract;

import com.google.gson.annotations.SerializedName;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class SignalSnapshot {

    @SerializedName("createdTsp")
    private Long createdTsp;

    @SerializedName("updatedTsp")
    private Long updatedTsp;

    @SerializedName("updatedTspIST")
    private String updatedTspIST;

    @SerializedName("incomingTsp")
    private Long incomingTsp;

    @SerializedName("incomingTspIST")
    private String incomingTspIST;

    @SerializedName("value")
    private Object value;
}
