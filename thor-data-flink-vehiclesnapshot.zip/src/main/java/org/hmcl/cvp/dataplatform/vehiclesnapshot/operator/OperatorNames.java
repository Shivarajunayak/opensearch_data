package org.hmcl.cvp.dataplatform.vehiclesnapshot.operator;

public class OperatorNames {

    public static final String MASTER_CAMPAIGN_SOURCE = "master-campaign-source";
    public static final String CHARGING_CAMPAIGN_SOURCE = "charging-campaign-source";
    public static final String ENRICH_CAMPAIGN_SOURCE = "enrich-campaigns-source";
    public static final String LKS_FETCH_JSON_SOURCE = "lks-fetchapi-json-source";
    public static final String NOTIFICATION_JSON_SOURCE = "notification-json-source";
    public static final String CONNECTION_STATUS_SOURCE = "connection-status-json-source";
    public static final String ENRICH_CONNECTION_STATUS_SOURCE = "enrich-connection-status-json-source";
    public static final String EDGE_ALERTS_SOURCE = "edge-alerts-source";
    public static final String COMBINED_SOURCES = "combined-watermarked-source";
    public static final String PROCESS_WINDOW = "process-window";
    public static final String SNAPSHOT_MAPPER = "snapshot-mapper";
    public static final String OPEN_SEARCH_SINK = "opensearch-sink";
    public static final String KAFKA_SINK = "kafka-sink";
    public static final String KAFKA_MAPPER = "kafka-mapper";
    public static final String REDIS_MAPPER = "redis-mapper";
    public static final String REDIS_SINK = "redis-sink";

    private OperatorNames() {
    }
}
