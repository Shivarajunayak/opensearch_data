package org.hmcl.cvp.dataplatform.vehiclesnapshot.helper;

public class JobConfigs {
    public static final String REDIS_SINK_ENABLED = "redis.sink.enabled";
    public static final String REDIS_URL = "redis.host";
    public static final String REDIS_PORT = "redis.port";
    public static final String REDIS_POOL_MAX_CONNECTIONS = "redis.pool.max.connections";
    public static final String REDIS_POOL_MAX_IDLE = "redis.pool.max.idle";
    public static final String REDIS_POOL_MIN_IDLE = "redis.pool.min.idle";
    public static final String REDIS_WRITE_BUFFER_BATCH_SIZE = "redis.write.buffer.batch.size";
    public static final String REDIS_USERNAME = "redis.username";
    public static final String REDIS_PASSWORD = "redis.password";
    public static final String REDIS_MODE = "redis.mode";
    public static final String REDIS_SINK_FLUSH_TIMER_INTERVAL = "redis.sink.flush.timer.interval";
}
