package org.hmcl.cvp.dataplatform.vehiclesnapshot.operator;

import com.google.gson.*;
import lombok.extern.slf4j.Slf4j;
import org.apache.flink.api.common.functions.RichFlatMapFunction;
import org.apache.flink.api.java.tuple.Tuple3;
import org.apache.flink.configuration.Configuration;
import org.apache.flink.metrics.Counter;
import org.apache.flink.util.Collector;
import org.hmcl.cvp.dataplatform.commons.constants.Constants;
import org.hmcl.cvp.dataplatform.commons.utils.GsonUtils;
import org.hmcl.cvp.dataplatform.vehiclesnapshot.contract.SnapshotWrapper;
import org.hmcl.cvp.dataplatform.vehiclesnapshot.helper.VehicleSnapshotHelper;

import java.util.Map;

@Slf4j
public class SnapshotWrapperKafkaFlatMapFunction extends RichFlatMapFunction<Tuple3<String, String, SnapshotWrapper>, String> {

    private static final Gson GSON = new GsonBuilder()
            .setObjectToNumberStrategy(ToNumberPolicy.DOUBLE)
            .create();

    private transient Counter numInputCounter;
    private transient Counter numSuccessCounter;
    private transient Counter numErrorCounter;

    private Counter counterInitializer(String counterName) {
        return getRuntimeContext()
                .getMetricGroup()
                .addGroup(Constants.METRIC_GROUP_NAME)
                .addGroup("EnrichLKS")
                .counter(counterName);
    }

    @Override
    public void open(Configuration parameters) throws Exception {
        super.open(parameters);
        numInputCounter = counterInitializer("numInputEvents");
        numSuccessCounter = counterInitializer("numSuccessEvents");
        numErrorCounter = counterInitializer("numErrorEvents");
    }

    @Override
    public void flatMap(Tuple3<String, String, SnapshotWrapper> value, Collector<String> out) {
        numInputCounter.inc();
        String incomingVid = value.f1;
        SnapshotWrapper snapshotWrapper = value.f2;
        log.debug("Extracting snapshot Wrapper for VID {}", incomingVid);
        try {
            Map<String, JsonElement> opensearchDocument = VehicleSnapshotHelper.getMapOfJsonElements(incomingVid, snapshotWrapper);
            String sinkToKafka = GSON.toJson(opensearchDocument);
            out.collect(sinkToKafka);
            numSuccessCounter.inc();
        } catch (Exception e) {
            numErrorCounter.inc();
            log.error("An error occurred while processing information for VID {} to Kafka: ", incomingVid, e);

        }
    }
}
