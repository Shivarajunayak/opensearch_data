package org.hmcl.cvp.dataplatform.vehiclesnapshot.operator;

import lombok.extern.slf4j.Slf4j;
import org.apache.flink.api.common.functions.RichFlatMapFunction;
import org.apache.flink.util.Collector;
import org.hmcl.cvp.dataplatform.contract.connectionstatus.ConnectionStatus;
import org.hmcl.cvp.dataplatform.contract.telemetry.Tenant;
import org.hmcl.cvp.dataplatform.vehiclesnapshot.contract.EnrichedSnapshot;
import org.hmcl.cvp.dataplatform.vehiclesnapshot.contract.Source;
import org.hmcl.cvp.dataplatform.vehiclesnapshot.helper.VehicleSnapshotHelper;

@Slf4j
public class EnrichConnectionStatusFunction extends RichFlatMapFunction<ConnectionStatus, EnrichedSnapshot> {

    @Override
    public void flatMap(ConnectionStatus value, Collector<EnrichedSnapshot> out) {
        try {

            String vid = value.getVid();
            String tenantId = value.getTenantId();

            Tenant tenant = Tenant.fromTenantId(tenantId);

            EnrichedSnapshot enrichedSnapshot = new EnrichedSnapshot();
            enrichedSnapshot.setVirtualId(vid);
            enrichedSnapshot.setVehicleName(vid);
            enrichedSnapshot.setTenant(tenant);
            enrichedSnapshot.setTenantId(tenantId);
            enrichedSnapshot.setSource(Source.CONNECTION_STATUS);
            enrichedSnapshot.setLatestEventCollectionTsp(value.getTimestamp());
            enrichedSnapshot.setConnectionState(VehicleSnapshotHelper.getConnectionState(value.getStatus()));

            out.collect(enrichedSnapshot);

        } catch (Exception e) {
            log.error("Exception while processing connection status data {}", value, e);
        }
    }


}
