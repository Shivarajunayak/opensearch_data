package org.hmcl.cvp.dataplatform.vehiclesnapshot.contract;

import com.google.gson.annotations.SerializedName;

public enum Source {

    @SerializedName("LKS")
    LKS("LKS"),

    @SerializedName("TELEMETRY/CHARGING")
    TELEMETRY_OR_CHARGING("TELEMETRY/CHARGING"),

    @SerializedName("NOTIFICATION")
    NOTIFICATION("NOTIFICATION"),

    @SerializedName("MULTI_EDGE_ALERTS")
    MULTI_EDGE_ALERTS("MULTI_EDGE_ALERTS"),

    @SerializedName("WINDOW")
    WINDOW("WINDOW"),

    @SerializedName("CONNECTION_STATUS")
    CONNECTION_STATUS("CONNECTION_STATUS");

    private final String value;

    Source(String value) {
        this.value = value;
    }

    @Override
    public String toString() {
        return this.value;
    }

    public String value() {
        return this.value;
    }
}
