package org.hmcl.cvp.dataplatform.vehiclesnapshot.operator;

import lombok.extern.slf4j.Slf4j;
import org.apache.flink.api.connector.sink2.SinkWriter;
import org.apache.flink.api.java.tuple.Tuple3;
import org.apache.flink.connector.opensearch.sink.OpensearchEmitter;
import org.apache.flink.connector.opensearch.sink.RequestIndexer;
import org.hmcl.cvp.dataplatform.commons.utils.DateUtils;
import org.hmcl.cvp.dataplatform.vehiclesnapshot.contract.SnapshotWrapper;
import org.hmcl.cvp.dataplatform.vehiclesnapshot.helper.VehicleSnapshotHelper;
import org.opensearch.action.index.IndexRequest;
import org.opensearch.client.Requests;

import java.util.Map;

@Slf4j
public class VehicleSnapshotOpenSearchEmitterInsert implements OpensearchEmitter<Tuple3<String, String, SnapshotWrapper>> {

    private IndexRequest createIndexRequest(Map<String, Object> document) {

        return Requests.indexRequest()
                .index("hmcl-cv-ev-vida-vehicle-snapshot-insert")
                .source(document);
    }

    @Override
    public void emit(Tuple3<String, String, SnapshotWrapper> element, SinkWriter.Context context, RequestIndexer indexer) {
        String index = element.f0;
        String incomingVid = element.f1;

        SnapshotWrapper snapshotWrapper = element.f2;
        Map<String, Object> opensearchDocument = VehicleSnapshotHelper.getOpenSearchDocument(incomingVid, snapshotWrapper);

        if (opensearchDocument.isEmpty()) {
            log.error("Insertion of {} into index {} for vehicle {} failed", snapshotWrapper, index, indexer);
            return;
        }
        IndexRequest indexRequest = createIndexRequest(opensearchDocument);

        log.debug("Document index request created at {} for vehicle {}. For lks? {}", DateUtils.currentEpochTime(),
                incomingVid, snapshotWrapper.getIsLks());
        indexer.add(indexRequest);
    }

}
