package org.hmcl.cvp.dataplatform.vehiclesnapshot.contract;

import java.util.HashMap;
import java.util.Map;

public enum IgnitionState {

    ON("On"),

    OFF("Off");

    private static final Map<String, IgnitionState> CONSTANTS = new HashMap<>();

    static {
        for (IgnitionState c : values()) {
            CONSTANTS.put(c.value, c);
        }
    }

    private final String value;

    IgnitionState(String value) {
        this.value = value;
    }

    public static IgnitionState fromValue(String value) {
        IgnitionState constant = CONSTANTS.get(value);
        if (constant == null) {
            throw new IllegalArgumentException(value);
        } else {
            return constant;
        }
    }

    @Override
    public String toString() {
        return this.value;
    }

    public String value() {
        return this.value;
    }
}
