package org.hmcl.cvp.dataplatform.edgealerts.alerts;

import org.hmcl.cvp.dataplatform.contract.notification.AlertPriority;
import org.hmcl.cvp.dataplatform.contract.telemetry.Telemetry;
import org.hmcl.cvp.dataplatform.edgealerts.contracts.AlertMapping;
import org.hmcl.cvp.dataplatform.edgealerts.model.MultiAlertEvent;
import org.hmcl.cvp.dataplatform.contract.telemetry.MultiAlertSignals;

public class IgnitionOnAlert implements EdgeAlertType {

    @Override
    public AlertMapping getAlertMapping(Telemetry value) {
        return AlertMapping.IGNITION_ON;
    }

    @Override
    public String getFeatureName() {
        return "Ignition On/Off";
    }

    @Override
    public AlertPriority getAlertPriority() {
        return AlertPriority.HIGH;
    }

    @Override
    public boolean isNotificationRequired(Telemetry value, MultiAlertEvent alertEvent) {
        return true;
    }

    @Override
    public boolean isSignalPresentForMultiAlert(String alertSignal) {
        return alertSignal.equals(MultiAlertSignals.IGNITION_ALERT_RISE_SIGNAL);
    }
}
