package org.hmcl.cvp.dataplatform.edgealerts.operator;

import org.apache.flink.api.common.functions.FilterFunction;
import org.hmcl.cvp.dataplatform.contract.enriched.AlertNotification;
import org.hmcl.cvp.dataplatform.contract.enriched.EnrichedTelemetry;

import java.util.Objects;

public class PriorityAlertsFilter implements FilterFunction<EnrichedTelemetry> {

    @Override
    public boolean filter(EnrichedTelemetry value) throws Exception {
        if (Objects.isNull(value)) return false;

        AlertNotification alertNotification = value.getNotification();
        return alertNotification.isNotify();
    }
}
