package org.hmcl.cvp.dataplatform.edgealerts.operator;

public class OperatorNames {

    public static final String CAMPAIGN_SOURCE = "campaign-source";
    public static final String MASTER_CAMPAIGN_SOURCE = "master-campaign-source";
    public static final String USER_PREFERENCE_SOURCE = "user-preference-source";
    public static final String ENRICHMENT = "enrich-and-check-alerts";
    public static final String PRIORITY_NOTIFICATION_FILTER = "priority-notification-filter";
    public static final String STANDARD_NOTIFICATION_FILTER = "standard-notification-filter";
    public static final String PRIORITY_NOTIFICATION_MAPPER = "priority-notification-mapper";
    public static final String STANDARD_NOTIFICATION_MAPPER = "standard-notification-mapper";
    public static final String PRIORITY_NOTIFICATION_SINK = "priority-notification-sink";
    public static final String STANDARD_NOTIFICATION_SINK = "standard-notification-sink";
    private OperatorNames() {
    }
}
