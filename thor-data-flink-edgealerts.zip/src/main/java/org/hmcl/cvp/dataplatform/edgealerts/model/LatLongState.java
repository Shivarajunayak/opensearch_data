package org.hmcl.cvp.dataplatform.edgealerts.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class LatLongState implements Serializable{
    private double latitude;
    private double longitude;
    private long detectionWindowStartTimestamp;
}
