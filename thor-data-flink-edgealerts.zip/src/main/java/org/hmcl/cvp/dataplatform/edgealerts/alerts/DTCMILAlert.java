package org.hmcl.cvp.dataplatform.edgealerts.alerts;

import org.hmcl.cvp.dataplatform.contract.notification.AlertPriority;
import org.hmcl.cvp.dataplatform.contract.telemetry.MultiAlertSignals;
import org.hmcl.cvp.dataplatform.contract.telemetry.Telemetry;
import org.hmcl.cvp.dataplatform.edgealerts.contracts.AlertMapping;
import org.hmcl.cvp.dataplatform.edgealerts.model.MultiAlertEvent;

public class DTCMILAlert implements EdgeAlertType {

    @Override
    public AlertMapping getAlertMapping(Telemetry value) {
        return AlertMapping.DTC_MIL_ALERT;
    }

    @Override
    public String getFeatureName() {
        return "DTC/MIL";
    }

    @Override
    public AlertPriority getAlertPriority() {
        return AlertPriority.HIGH;
    }

    @Override
    public boolean isRisingSignal(MultiAlertEvent alertEvent) {
        return alertEvent.getAlertSignal().equals(MultiAlertSignals.DTC_MIL_ALERT_RISE_SIGNAL);
    }

    @Override
    public boolean isSignalPresentForMultiAlert(String alertSignal) {
        return alertSignal.equals(MultiAlertSignals.DTC_MIL_ALERT_RISE_SIGNAL);
    }
}
