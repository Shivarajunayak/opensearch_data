package org.hmcl.cvp.dataplatform.edgealerts.alerts;

import org.hmcl.cvp.dataplatform.contract.notification.AlertPriority;
import org.hmcl.cvp.dataplatform.contract.telemetry.Telemetry;
import org.hmcl.cvp.dataplatform.edgealerts.contracts.AlertMapping;
import org.hmcl.cvp.dataplatform.edgealerts.model.MultiAlertEvent;
import org.hmcl.cvp.dataplatform.contract.telemetry.MultiAlertSignals;

public class HarshAccelerationAlert implements EdgeAlertType {

    @Override
    public AlertMapping getAlertMapping(Telemetry value) {
        return AlertMapping.HARSH_ACCELERATION;
    }

    @Override
    public String getFeatureName() {
        return "Harsh Driving";
    }

    @Override
    public AlertPriority getAlertPriority() {
        return AlertPriority.HIGH;
    }

    @Override
    public boolean isRisingSignal(MultiAlertEvent alertEvent) {
        return alertEvent.getAlertSignal().equals(MultiAlertSignals.HARSH_ACCELERATION_ALERT_RISE_SIGNAL);
    }

    @Override
    public boolean isSignalPresentForMultiAlert(String alertSignal) {
        return alertSignal.equals(MultiAlertSignals.HARSH_ACCELERATION_ALERT_RISE_SIGNAL);
    }

}
