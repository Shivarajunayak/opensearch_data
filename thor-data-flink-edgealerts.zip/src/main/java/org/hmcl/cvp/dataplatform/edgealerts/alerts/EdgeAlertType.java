package org.hmcl.cvp.dataplatform.edgealerts.alerts;

import org.hmcl.cvp.dataplatform.commons.utils.UserPreferenceUtils;
import org.hmcl.cvp.dataplatform.contract.notification.AlertPriority;
import org.hmcl.cvp.dataplatform.contract.telemetry.Telemetry;
import org.hmcl.cvp.dataplatform.contract.userpreference.StandardFeature;
import org.hmcl.cvp.dataplatform.contract.userpreference.UserPreference;
import org.hmcl.cvp.dataplatform.edgealerts.contracts.AlertMapping;
import org.hmcl.cvp.dataplatform.edgealerts.model.MultiAlertEvent;

import java.util.Objects;
import java.util.Optional;

public interface EdgeAlertType {

    AlertMapping getAlertMapping(Telemetry value);

    String getFeatureName();

    AlertPriority getAlertPriority();

    default boolean isNotificationRequired(Telemetry value, MultiAlertEvent alertEvent){
        return !Objects.isNull(value) && !Objects.isNull(value.getDimensions()) && isRisingSignal(alertEvent);
    }

    boolean isSignalPresentForMultiAlert(String alertSignal);

    default Optional<StandardFeature> getAlertFeature(UserPreference userPreference) {
        return UserPreferenceUtils.getStandardFeature(userPreference, getFeatureName());
    }

    default boolean isRisingSignal(MultiAlertEvent alertEvent) {
        return alertEvent.getAlertSignal().contains("1");
    }

    default String toString(EdgeAlertType alert) {
        return alert.getFeatureName() + " with priority: " + alert.getAlertPriority();
    }

}
