package org.hmcl.cvp.dataplatform.edgealerts.operator;

import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.extern.slf4j.Slf4j;
import org.apache.flink.api.common.state.MapState;
import org.apache.flink.api.common.state.MapStateDescriptor;
import org.apache.flink.api.common.state.StateTtlConfig;
import org.apache.flink.api.java.tuple.Tuple3;
import org.apache.flink.api.java.utils.ParameterTool;
import org.apache.flink.configuration.Configuration;
import org.apache.flink.metrics.Counter;
import org.apache.flink.streaming.api.functions.co.RichCoFlatMapFunction;
import org.apache.flink.util.Collector;
import org.hmcl.cvp.dataplatform.commons.catalogue.SignalCatalogue;
import org.hmcl.cvp.dataplatform.commons.constants.Constants;
import org.hmcl.cvp.dataplatform.commons.constants.FlinkRuntime;
import org.hmcl.cvp.dataplatform.commons.utils.SignalUtils;
import org.hmcl.cvp.dataplatform.commons.utils.TelemetryUtils;
import org.hmcl.cvp.dataplatform.commons.utils.UserPreferenceUtils;
import org.hmcl.cvp.dataplatform.contract.enriched.AlertNotification;
import org.hmcl.cvp.dataplatform.contract.enriched.EnrichedTelemetry;
import org.hmcl.cvp.dataplatform.contract.notification.AlertInfo;
import org.hmcl.cvp.dataplatform.contract.notification.AlertPriority;
import org.hmcl.cvp.dataplatform.contract.telemetry.LatLongPair;
import org.hmcl.cvp.dataplatform.contract.telemetry.SignalData;
import org.hmcl.cvp.dataplatform.contract.telemetry.Telemetry;
import org.hmcl.cvp.dataplatform.contract.userpreference.UserPreference;
import org.hmcl.cvp.dataplatform.edgealerts.alerts.AccidentCrashAlert;
import org.hmcl.cvp.dataplatform.edgealerts.alerts.AuxBatterLowAlert;
import org.hmcl.cvp.dataplatform.edgealerts.alerts.AuxBatterUnpluggedAlert;
import org.hmcl.cvp.dataplatform.edgealerts.alerts.BatteryOverheatingAlert;
import org.hmcl.cvp.dataplatform.edgealerts.alerts.DTCMILAlert;
import org.hmcl.cvp.dataplatform.edgealerts.alerts.EdgeAlertType;
import org.hmcl.cvp.dataplatform.edgealerts.alerts.FallAlert;
import org.hmcl.cvp.dataplatform.edgealerts.alerts.HarshAccelerationAlert;
import org.hmcl.cvp.dataplatform.edgealerts.alerts.HarshBrakingAlert;
import org.hmcl.cvp.dataplatform.edgealerts.alerts.IgnitionOffAlert;
import org.hmcl.cvp.dataplatform.edgealerts.alerts.IgnitionOnAlert;
import org.hmcl.cvp.dataplatform.edgealerts.alerts.MotorOffAlert;
import org.hmcl.cvp.dataplatform.edgealerts.alerts.MotorOnAlert;
import org.hmcl.cvp.dataplatform.edgealerts.alerts.MovementAlert;
import org.hmcl.cvp.dataplatform.edgealerts.alerts.OverSpeedAlert;
import org.hmcl.cvp.dataplatform.edgealerts.alerts.PanicAlert;
import org.hmcl.cvp.dataplatform.edgealerts.alerts.ThermalRunawayAlert;
import org.hmcl.cvp.dataplatform.edgealerts.alerts.TowOrTheftAlert;
import org.hmcl.cvp.dataplatform.edgealerts.contracts.AlertMapping;
import org.hmcl.cvp.dataplatform.edgealerts.helper.EdgeAlertsHelper;
import org.hmcl.cvp.dataplatform.edgealerts.model.LatLongState;
import org.hmcl.cvp.dataplatform.edgealerts.model.MultiAlertEvent;

import java.time.Instant;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.Set;
import java.util.TreeSet;

@Slf4j
public class EnrichedMultiAlertsFunction extends RichCoFlatMapFunction<Telemetry, UserPreference, EnrichedTelemetry> {

    // This Alert class are final implicitly
    private static final EdgeAlertType accidentCrashAlert = new AccidentCrashAlert();
    private static final EdgeAlertType fallAlert = new FallAlert();
    private static final EdgeAlertType harshAccelerationAlert = new HarshAccelerationAlert();
    private static final EdgeAlertType harshBrakingAlert = new HarshBrakingAlert();
    private static final EdgeAlertType overSpeedAlert = new OverSpeedAlert();
    private static final EdgeAlertType panicAlert = new PanicAlert();
    private static final EdgeAlertType auxBatterLowAlert = new AuxBatterLowAlert();
    private static final EdgeAlertType auxBatterUnpluggedAlert = new AuxBatterUnpluggedAlert();
    private static final EdgeAlertType towOrTheftAlert = new TowOrTheftAlert();
    private static final EdgeAlertType motorOnAlert = new MotorOnAlert();
    private static final EdgeAlertType thermalRunawayAlert = new ThermalRunawayAlert();
    private static final EdgeAlertType ignitionOnAlert = new IgnitionOnAlert();
    private static final EdgeAlertType motorOffAlert = new MotorOffAlert();
    private static final EdgeAlertType batteryOverheatingAlert = new BatteryOverheatingAlert();
    private static final EdgeAlertType ignitionOffAlert = new IgnitionOffAlert();
    private static final EdgeAlertType movementAlert = new MovementAlert();
    private static final EdgeAlertType dtcMILAlert = new DTCMILAlert();

    /**
     * MapState to hold userPreferences for each profile
     * Key - vehicleId
     * Value - Map of user preferences with the key being profileId and value UserPreference object
     */
    private transient MapState<String, Map<String, UserPreference>> preferencesStateMap;

    private transient MapState<String, LatLongState> latLongStateMap;

    private transient MapState<String, Long> idempotencyStateMap;

    private transient Counter numInputAlertEventCounter;
    private transient Counter rougeAlertEventsCounter;
    private transient Counter numUserPreferenceCounter;
    private transient Counter numUserPreferenceUpdatedCounter;
    private transient Counter numUserPreferenceIgnoredCounter;
    private transient Counter numEnrichedAlertCounter;
    private transient Counter numNotEnrichedAlertCounter;
    private transient Counter numNoRiderEventCounter;

    private transient int allowedAlertLateness;
    private transient String env;
    private static final ObjectMapper objectMapper = new ObjectMapper();

    private transient Map<String, AlertInfo> alertMappingsMap;
    private transient List<EdgeAlertType> supportedAlerts;

    private Counter counterInitializer(String counterName) {

        return getRuntimeContext()
                .getMetricGroup()
                .addGroup(Constants.METRIC_GROUP_NAME)
                .addGroup("EnrichedMultiAlert")
                .counter(counterName);
    }

    @Override
    public void open(Configuration parameters) throws Exception {
        super.open(parameters);

        ParameterTool parameterTool = (ParameterTool) getRuntimeContext().getExecutionConfig().getGlobalJobParameters();
        allowedAlertLateness = parameterTool.getInt(FlinkRuntime.EdgeAlerts.ALERTS_ALLOWED_LATENESS_IN_MAX, 1);
        env = parameterTool.getRequired(FlinkRuntime.ENV);

        MapStateDescriptor<String, Map<String, UserPreference>> userPreferencesDescriptor = MultiAlertMapStateDescriptors.multiAlertUserPreferenceMapStateDescriptor();
        preferencesStateMap = getRuntimeContext().getMapState(userPreferencesDescriptor);

        MapStateDescriptor<String, LatLongState> latLongStateMapStateDescriptor = MultiAlertMapStateDescriptors.multiAlertLatLongMapStateDescriptor();
        latLongStateMap = getRuntimeContext().getMapState(latLongStateMapStateDescriptor);

        StateTtlConfig ttlConfig = StateTtlConfig.newBuilder(org.apache.flink.api.common.time.Time.seconds(1800)).build();
        MapStateDescriptor<String, Long> idempotencyStateDescriptor = MultiAlertMapStateDescriptors.multiAlertIdempotencyDescriptor();
        idempotencyStateDescriptor.enableTimeToLive(ttlConfig);
        idempotencyStateMap = getRuntimeContext().getMapState(idempotencyStateDescriptor);

        numInputAlertEventCounter = counterInitializer("numInputAlertMultiEvents");
        rougeAlertEventsCounter = counterInitializer("rougeAlertMultiEvents");
        numUserPreferenceCounter = counterInitializer("numUserPreferencesMultiAlert");
        numUserPreferenceUpdatedCounter = counterInitializer("numUserPreferenceUpdatedMultiAlert");
        numUserPreferenceIgnoredCounter = counterInitializer("numUserPreferenceIgnoredMultiAlert");
        numEnrichedAlertCounter = counterInitializer("numEnrichedMultiAlert");
        numNotEnrichedAlertCounter = counterInitializer("numNotEnrichedMultiAlert");
        numNoRiderEventCounter = counterInitializer("numNoRiderEventsMultiAlert");

        // Populate supported alerts
        supportedAlerts = getSupportedAlerts();

        // Get Alert mappings
        log.info("Fetching alert mappings for env {}", env);
        alertMappingsMap = EdgeAlertsHelper.getAlertInfos(env);

        log.info("Allowed lateness is {}", allowedAlertLateness);
    }

    @Override
    public void flatMap1(Telemetry value, Collector<EnrichedTelemetry> out) throws Exception {
        numInputAlertEventCounter.inc();
        String idempotencyKey = TelemetryUtils.getVirtualId(value) + "_" + value.getEventId();
        if (isDuplicateEvent(idempotencyKey, value)) return;

        if (isRogueTelemetry(value)) return;

        String vid = TelemetryUtils.getVirtualId(value);
        // Validate and put valid Lat Longs into cache
        LatLongState cachedLatLongState = Objects.isNull(latLongStateMap.get(vid)) ? LatLongState.builder().build() : latLongStateMap.get(vid);
        LatLongState updatedLatLongState = updateLatLongInState(value, cachedLatLongState, vid);
        Set<SignalData> multiAlertList = value.getSignals().get(SignalCatalogue.getMultiAlertInfo().getKey());
        if (multiAlertList == null || multiAlertList.isEmpty()) {
            log.warn("No multi alert signals found for vehicle {}", vid);
            numNotEnrichedAlertCounter.inc();
            return;
        }
        Map<String, UserPreference> preferences = preferencesStateMap.get(vid);
        if (Objects.isNull(preferences)) {
            log.warn("User preference not found for vehicle {}", vid);
            numNotEnrichedAlertCounter.inc();
            return;
        }
        EnrichedTelemetry enrichedTelemetry = new EnrichedTelemetry();
        enrichedTelemetry.setUserPreferences(preferences);
        enrichedTelemetry.setTelemetry(value);
        enrichedTelemetry.setLatitude(updatedLatLongState.getLatitude());
        enrichedTelemetry.setLongitude(updatedLatLongState.getLongitude());
        Optional<UserPreference> rider = UserPreferenceUtils.getRider(enrichedTelemetry);
        if (rider.isEmpty()) {
            numNoRiderEventCounter.inc();
            log.error("No rider found for enriched vehicle {}", vid);
            return;
        }
        Set<MultiAlertEvent> alertEvents = extractMultiAlertValues(multiAlertList);
        log.info("Alert codes detected for vehicle {} are {}", vid, alertEvents);

        alertEvents.forEach(alertEvent -> {
            EdgeAlertType detectedAlertOpt = getDetectedAlert(alertEvent);
            log.info("detectedAlertOpt for vehicle {} are {}", vid, detectedAlertOpt);

            if (detectedAlertOpt == null) {
                log.warn("No edge alert detected for enriched vehicle {}", vid);
                return;
            }
            numEnrichedAlertCounter.inc();
            String featureName = detectedAlertOpt.getFeatureName();

            AlertMapping alertMapping = detectedAlertOpt.getAlertMapping(value);
            if (Objects.isNull(alertMapping)) {
                log.error("No alert mapping found for vehicle {} and alert {} ", vid, featureName);
                return;
            }

            AlertInfo alertInfo = getAlertInfo(alertMapping);
            if (Objects.isNull(alertInfo)) {
                log.error("No alert info found for alert {} and vehicle {}", featureName, vid);
                return;
            }

            String alertName = alertInfo.getName();
            String alertCode = alertInfo.getCode();
            log.info("{} alert detected for vehicle {}", alertName, vid);

            log.debug("updating state for alert {} and vid {}", alertCode, vid);
            long alertTimeStamp = alertEvent.getTimestamp() != null ? alertEvent.getTimestamp() : value.getCollectionEventTime();

            // Tuple of isNotificationRequired and Reasoning for Notification to be Generated or not
            Tuple3<Boolean, String, Boolean> notificationRequiredAndReasoning = getNotificationRequiredDetails(detectedAlertOpt, alertTimeStamp, value, alertEvent);

            // AlertNotification is the notification Object being created from Telemetry, this supports schema evolution downstream
            AlertNotification notification = AlertNotification.builder()
                    .notify(notificationRequiredAndReasoning.f0)
                    .alertCode(alertCode)
                    .alertName(alertName)
                    .alertType(alertInfo.getType())
                    .alertPriority(getAlertOrStatePriority(detectedAlertOpt, value, alertEvent))
                    .alertEventTimeStamp(value.getCollectionEventTime())
                    .notificationSystemTimeStamp(Instant.now().toEpochMilli())
                    .notificationReasoning(notificationRequiredAndReasoning.f1)
                    .isAlert(notificationRequiredAndReasoning.f2)
                    .build();

            enrichedTelemetry.setNotification(notification);
            log.info("generating alert for {}: {}", detectedAlertOpt, notification);
            out.collect(enrichedTelemetry);
        });

    }

    @Override
    public void flatMap2(UserPreference value, Collector<EnrichedTelemetry> out) {

        numUserPreferenceCounter.inc();

        try {

            String vid = value.getVid();
            boolean isRider = value.getIsRider();

            // Only having getUpdatedTsp >= to allow for state to be updated once per week.
            // A Job will scan the UserPreference DB and Push it to UserPreference MSK topic
            Map<String, UserPreference> cachedUserPreferences = Objects.isNull(preferencesStateMap.get(vid)) ? new HashMap<>() : preferencesStateMap.get(vid);

            UserPreference existingUserPreference = cachedUserPreferences.getOrDefault(value.getProfileId(), null);
            if (isRider && isLatestPreference(value, existingUserPreference)) {
                log.info("The user is rider and latest event received. Updating state for vehicle {}!", vid);
                numUserPreferenceUpdatedCounter.inc();
                updateState(value, cachedUserPreferences);
                return;
            }

            if (!isRider && Objects.nonNull(existingUserPreference)) {
                log.info("Incoming user is not a rider and present in state. Removing from state for vehicle {}!", vid);
                final Map<String, UserPreference> finalCachedUserPreferences = new HashMap<>(cachedUserPreferences);
                finalCachedUserPreferences.remove(value.getProfileId());
                preferencesStateMap.put(vid, finalCachedUserPreferences);
            } else {
                numUserPreferenceIgnoredCounter.inc();
                log.debug("Incoming user is secondary and is not a rider and not present in state. Ignoring for vehicle {}!", vid);
            }
        } catch (Exception e) {
            log.error("Exception occurred while processing user preference", e);
        }

    }

    private boolean isDuplicateEvent(String idempotencyKey, Telemetry value) throws Exception {
        if (idempotencyStateMap.get(idempotencyKey) != null) {
            log.error("Duplicate Event: vid_eventId: {}", idempotencyKey);
            numNotEnrichedAlertCounter.inc();
            return true;
        } else {
            idempotencyStateMap.put(idempotencyKey, value.getCollectionEventTime());
            return false;
        }
    }

    private boolean isRogueTelemetry(Telemetry value) {
        if (value.getCollectionEventTime() > Instant.now().toEpochMilli()) {
            rougeAlertEventsCounter.inc();
            log.warn("Somehow the incoming event for vehicle {} is in the future!!", TelemetryUtils.getTenantId(value));
            return true;
        }
        return false;
    }

    private void updateState(UserPreference value, Map<String, UserPreference> cachedUserPreferences) throws Exception {
        log.debug("Updating Threshold inside  EnrichTelemetryWithThresholdValues {} ", value);

        final Map<String, UserPreference> finalCachedUserPreferences = new HashMap<>(cachedUserPreferences);

        // If any non-riders are present in state, removing them
        cachedUserPreferences.forEach((k, v) -> {
            if (!v.getIsRider()) {
                log.debug("{} is not riding. So removing from state", v.getProfileId());
                finalCachedUserPreferences.remove(v.getProfileId());
            }
        });

        finalCachedUserPreferences.put(value.getProfileId(), value);

        // Handle the case where there are multiple riders. Have only the latest rider details
        Optional<UserPreference> latestRider = finalCachedUserPreferences.values()
                .stream()
                .max(Comparator.comparing(UserPreference::getUpdatedTsp));

        final Map<String, UserPreference> singleRider = new HashMap<>();
        singleRider.put(latestRider.get().getProfileId(), latestRider.get());
        preferencesStateMap.put(value.getVid(), singleRider);
    }

    private boolean isLatestPreference(UserPreference incomingUserPref, UserPreference existingUserPref) {
        if (Objects.isNull(existingUserPref)) return true;

        return incomingUserPref.getUpdatedTsp() >= existingUserPref.getUpdatedTsp();
    }

    private EdgeAlertType getDetectedAlert(MultiAlertEvent alertEvent) {
        if (!supportedAlerts.isEmpty()) {
            return supportedAlerts.stream()
                    .filter(alert -> alert.isSignalPresentForMultiAlert(alertEvent.getAlertSignal()))
                    .findFirst()
                    .orElse(null);
        }
        return null;
    }

    private List<EdgeAlertType> getSupportedAlerts() {
        List<EdgeAlertType> alerts = new ArrayList<>();
        // EdgeAlertType is the Base class of which All AlertTypes has been created
        alerts.add(accidentCrashAlert);
        alerts.add(fallAlert);
        alerts.add(harshAccelerationAlert);
        alerts.add(harshBrakingAlert);
        alerts.add(overSpeedAlert);
        alerts.add(panicAlert);
        alerts.add(auxBatterLowAlert);
        alerts.add(auxBatterUnpluggedAlert);
        alerts.add(towOrTheftAlert);
        alerts.add(motorOnAlert);
        alerts.add(motorOffAlert);
        alerts.add(batteryOverheatingAlert);
        alerts.add(thermalRunawayAlert);
        alerts.add(ignitionOnAlert);
        alerts.add(ignitionOffAlert);
        alerts.add(movementAlert);
        alerts.add(dtcMILAlert);

        return alerts;
    }

    private Tuple3<Boolean, String, Boolean> getNotificationRequiredDetails(EdgeAlertType detectedAlert,
                                                                            long alertTimeStamp,
                                                                            Telemetry value,
                                                                            MultiAlertEvent alertEvent) {

        boolean isLateAlert = isAlertOlderThanAllowedTime(alertTimeStamp);
        boolean notificationRequired = detectedAlert.isNotificationRequired(value, alertEvent);

        String notificationReasoning = String.format("LateAlert :  %s ; NotificationRequiredAsPerPRD:  %s",
                isLateAlert, notificationRequired);

        // Just pass all rising edge alerts irrespective of out of order alerts
        boolean isNotificationRequired = !isLateAlert && notificationRequired;

        return new Tuple3<>(isNotificationRequired, notificationReasoning, notificationRequired);
    }

    private AlertPriority getAlertOrStatePriority(EdgeAlertType edgeAlert, Telemetry value, MultiAlertEvent alertEvent) {
        // For state alerts, setting priority as STANDARD by default
        if (!edgeAlert.isNotificationRequired(value, alertEvent)) return AlertPriority.STANDARD;
        return edgeAlert.getAlertPriority();
    }


    private boolean isAlertOlderThanAllowedTime(long alertTimeStamp) {
        long seconds = allowedAlertLateness * 60L;
        long someSecondsBack = Instant.now().minusSeconds(seconds).toEpochMilli();
        return someSecondsBack >= alertTimeStamp;
    }

    private AlertInfo getAlertInfo(AlertMapping alertMapping) {

        if (alertMappingsMap.isEmpty()) {
            log.info("Alert mappings is empty. Populating it again..");
            alertMappingsMap = EdgeAlertsHelper.getAlertInfos(env);
        }

        String key = alertMapping.value();
        if (alertMappingsMap.containsKey(key)) {
            return alertMappingsMap.get(key);
        }
        return null;
    }

    public static Set<MultiAlertEvent> extractMultiAlertValues(Set<SignalData> multiAlertList) {
        Set<MultiAlertEvent> alertEvents = new TreeSet<>(
                Comparator.comparingLong(MultiAlertEvent::getTimestamp)
                        .thenComparing(MultiAlertEvent::getAlertSignal)
        );
        ObjectMapper objectMapper = new ObjectMapper();
        if (multiAlertList != null) {
            for (SignalData alert : multiAlertList) {
                String value = (String) alert.getValue();
                if (value != null) {
                    try {
                        // Parse the stringified array
                        String[] parsedValues = objectMapper.readValue(value, String[].class);
                        for (String parsedValue : parsedValues) {
                            alertEvents.add(new MultiAlertEvent(parsedValue, alert.getTime()));
                        }
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
            }
        }

        log.info("=============Multi Alert events detected are");
        alertEvents.forEach(alertEvent -> log.info("AlertName: {} , Timestamp: {}", alertEvent.getAlertSignal(), alertEvent.getTimestamp()));

        return alertEvents;
    }

    private LatLongState updateLatLongInState(Telemetry telemetryData, LatLongState cachedLatLong, String vid) throws Exception {
        try {
            log.info("Updating lat long");
            log.info("CurrentLat Long State for VID : {} is {}", vid, cachedLatLong);
            long packetTimeStamp = telemetryData.getCollectionEventTime();
            long lastUpdateLatLongTspFromState = cachedLatLong != null ? cachedLatLong.getDetectionWindowStartTimestamp() : 0;
            List<LatLongPair> latLongPairList = SignalUtils.getLatitudeLongitude(telemetryData);
            int latestLatLongIndex = latLongPairList.size() - 1;

            if (latestLatLongIndex < 0) {
                log.error("No lat longs found in telemetry data, returning CACHED LatLongs");
                return Objects.isNull(cachedLatLong) ? LatLongState.builder().build() : cachedLatLong;
            }

            LatLongPair latLongLatest = latLongPairList.get(latestLatLongIndex);

            log.info("Checking GPS and LatLong validity for telemetry data: {}", telemetryData);

            if (isGPSAndLatLongValid(latLongLatest) && !isUnorderedPacket(packetTimeStamp, lastUpdateLatLongTspFromState)) {
                log.info("Lat longs in telemetry data are valid, Updating state");
                LatLongState latLongState = LatLongState.builder()
                        .latitude(latLongLatest.getLatitude())
                        .longitude(latLongLatest.getLongitude())
                        .detectionWindowStartTimestamp(packetTimeStamp)
                        .build();

                latLongStateMap.put(vid, latLongState);
                return latLongState;
            } else {
                log.info("Lat longs in telemetry data are INVALID, returning CACHED LatLongs");
                return Objects.isNull(cachedLatLong) ? LatLongState.builder().build() : cachedLatLong;
            }
        } catch (Exception e) {
            log.error("LATLONG Exception: ", e);
            log.error("LATLONG Exception happened while evaluating LAt longs from telematry packet : {} for vid: {}", objectMapper.writeValueAsString(telemetryData), vid);
        }
        log.info("Lat longs in telemetry data are INVALID, returning CACHED LatLongs");
        return Objects.isNull(cachedLatLong) ? LatLongState.builder().build() : cachedLatLong;
    }

    public boolean isUnorderedPacket(long packetTimeStamp, long detectionWindowStartTimestamp) {
        if (packetTimeStamp == 0)
            return true;

        // we are updating the state for first time
        if (detectionWindowStartTimestamp == 0)
            return false;

        return packetTimeStamp < detectionWindowStartTimestamp;
    }

    public static boolean isGPSAndLatLongValid(LatLongPair latLongLatest) {
        return latLongLatest.getLatitude() != 0
                && latLongLatest.getLongitude() != 0
                && latLongLatest.getHDop() <= 3
                && latLongLatest.getGpsFix() >= 2
                && latLongLatest.isGpsValid();
    }
}