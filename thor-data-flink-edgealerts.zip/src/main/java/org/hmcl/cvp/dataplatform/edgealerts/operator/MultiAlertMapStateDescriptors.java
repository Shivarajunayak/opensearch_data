package org.hmcl.cvp.dataplatform.edgealerts.operator;

import org.apache.flink.api.common.state.MapStateDescriptor;
import org.apache.flink.api.common.typeinfo.TypeHint;
import org.apache.flink.api.common.typeinfo.TypeInformation;
import org.hmcl.cvp.dataplatform.contract.userpreference.UserPreference;
import org.hmcl.cvp.dataplatform.edgealerts.model.LatLongState;

import java.util.Map;

public class MultiAlertMapStateDescriptors {

    private MultiAlertMapStateDescriptors() {
    }

    public static MapStateDescriptor<String, Map<String, UserPreference>> multiAlertUserPreferenceMapStateDescriptor() {
        return new MapStateDescriptor<>("multiAlertUserPreferenceMapState",
                TypeInformation.of(String.class),
                TypeInformation.of(new TypeHint<Map<String, UserPreference>>() {
                })
        );
    }

    public static MapStateDescriptor<String, LatLongState> multiAlertLatLongMapStateDescriptor() {
        return new MapStateDescriptor<>("multiAlertLatLongMapState",
                String.class,
                LatLongState.class
        );
    }

    public static MapStateDescriptor<String, Long> multiAlertIdempotencyDescriptor() {
        return new MapStateDescriptor<>("multiAlertIdempotencyDescriptor",
                String.class,
                Long.class
        );
    }

}
