package org.hmcl.cvp.dataplatform.edgealerts.alerts;

import org.hmcl.cvp.dataplatform.contract.notification.AlertPriority;
import org.hmcl.cvp.dataplatform.contract.telemetry.Telemetry;
import org.hmcl.cvp.dataplatform.edgealerts.contracts.AlertMapping;
import org.hmcl.cvp.dataplatform.edgealerts.model.MultiAlertEvent;
import org.hmcl.cvp.dataplatform.contract.telemetry.MultiAlertSignals;

public class AccidentCrashAlert implements EdgeAlertType {

    @Override
    public AlertMapping getAlertMapping(Telemetry value) {
        return AlertMapping.CRASH;
    }

    @Override
    public String getFeatureName() {
        return "Crash";
    }

    @Override
    public AlertPriority getAlertPriority() {
        return AlertPriority.HIGH;
    }

    @Override
    public boolean isRisingSignal(MultiAlertEvent alertEvent) {
        return alertEvent.getAlertSignal().equals(MultiAlertSignals.ACCIDENT_CRASH_ALERT_RISE_SIGNAL);
    }

    @Override
    public boolean isSignalPresentForMultiAlert(String alertSignal) {
        return alertSignal.equals(MultiAlertSignals.ACCIDENT_CRASH_ALERT_RISE_SIGNAL);
    }
}
