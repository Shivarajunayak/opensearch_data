package org.hmcl.cvp.dataplatform.edgealerts.model;

import lombok.Getter;

@Getter
public class MultiAlertEvent {
    private final String alertSignal;
    private final Long timestamp;

    public MultiAlertEvent(String alertSignal, long timestamp) {
        this.alertSignal = alertSignal;
        this.timestamp = timestamp;
    }

}

