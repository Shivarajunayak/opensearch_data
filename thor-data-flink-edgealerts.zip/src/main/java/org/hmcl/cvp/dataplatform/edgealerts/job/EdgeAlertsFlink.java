package org.hmcl.cvp.dataplatform.edgealerts.job;

import lombok.extern.slf4j.Slf4j;
import org.apache.flink.api.common.functions.FlatMapFunction;
import org.apache.flink.api.java.utils.ParameterTool;
import org.apache.flink.connector.kafka.sink.KafkaSink;
import org.apache.flink.streaming.api.datastream.DataStream;
import org.apache.flink.streaming.api.datastream.KeyedStream;
import org.apache.flink.streaming.api.datastream.SingleOutputStreamOperator;
import org.apache.flink.streaming.api.environment.StreamExecutionEnvironment;
import org.apache.flink.streaming.api.functions.co.RichCoFlatMapFunction;
import org.hmcl.cvp.dataplatform.commons.connector.KafkaConnector;
import org.hmcl.cvp.dataplatform.commons.constants.FlinkRuntime;
import org.hmcl.cvp.dataplatform.commons.operator.AlertNotificationFlatMap;
import org.hmcl.cvp.dataplatform.commons.operator.TelemetryFlatMapFunction;
import org.hmcl.cvp.dataplatform.commons.operator.UserPreferenceFlatMapFunction;
import org.hmcl.cvp.dataplatform.commons.stream.SourceStream;
import org.hmcl.cvp.dataplatform.commons.utils.ConnectorUtils;
import org.hmcl.cvp.dataplatform.commons.utils.TelemetryUtils;
import org.hmcl.cvp.dataplatform.contract.enriched.EnrichedTelemetry;
import org.hmcl.cvp.dataplatform.contract.telemetry.Telemetry;
import org.hmcl.cvp.dataplatform.contract.userpreference.UserPreference;
import org.hmcl.cvp.dataplatform.edgealerts.operator.EnrichedMultiAlertsFunction;
import org.hmcl.cvp.dataplatform.edgealerts.operator.OperatorNames;
import org.hmcl.cvp.dataplatform.edgealerts.operator.PriorityAlertsFilter;

import java.io.IOException;

/**
 * Assumptions:
 * 1. All alert campaigns will be landing into one single MSK topic
 * 2. Rise alerts will in a campaign containing "alert" word in the name.
 * 3. For each signal change, only one packet will be received
 * 4. Only one alert per packet.
 */
@Slf4j
public class EdgeAlertsFlink {
    private static final EnrichedMultiAlertsFunction enrichedMultiAlertsFunction = new EnrichedMultiAlertsFunction();

    // Converts JSON -> Telemetry Object
    private static final FlatMapFunction<String, Telemetry> telemetryFlatMapFunction = new TelemetryFlatMapFunction();

    // Converts JSON -> UserPreference Object
    private static final FlatMapFunction<String, UserPreference> userPrefFlatMapFunction = new UserPreferenceFlatMapFunction();

    // AlertNotification Class Mapped to Notification Class and sent to Priority and Standard Kafka Topics
    private static final AlertNotificationFlatMap<EnrichedTelemetry> notificationMap = new AlertNotificationFlatMap<>();

    // Filter Notification Object Stream  to be sent to Standard Notification Kakfa Topic
//    private static final StandardAlertsFilter standardFilter = new StandardAlertsFilter();

    // Filter Notification Object Stream  to be sent to Standard Notification Kakfa Topic
    private static final PriorityAlertsFilter priorityFilter = new PriorityAlertsFilter();

    public static void main(String[] args) throws IOException {
        final StreamExecutionEnvironment env = StreamExecutionEnvironment.getExecutionEnvironment();
        final ParameterTool parameterTool = ConnectorUtils.loadApplicationParameters(args, env);
        env.getConfig().setGlobalJobParameters(parameterTool);

        boolean isTest = parameterTool.getBoolean(FlinkRuntime.IS_TEST, Boolean.FALSE);
        log.info("Is this being executed as part of test case? {}", isTest);

        String multiAlertCampaignInputTopic = parameterTool.get(FlinkRuntime.Kafka.MULTI_ALERTS_CAMPAIGN_TOPIC);

        // Sink Notification Topic priorityTopic, standardTopic
        String priorityTopic = parameterTool.get(FlinkRuntime.Kafka.NOTIFICATION_PRIORITY_TOPIC);
//        String standardTopic = parameterTool.get(FlinkRuntime.Kafka.NOTIFICATION_STANDARD_TOPIC);

        try {

            KafkaConnector.KafkaProperties thresholdKafkaProps = KafkaConnector.getThresholdKafkaProperties(parameterTool);

            // User Preference stream KeyBy VID
            KeyedStream<UserPreference, String> userPreferKeyedStream = SourceStream.getUserPreferenceStream(env,
                    parameterTool,
                    thresholdKafkaProps,
                    userPrefFlatMapFunction,
                    OperatorNames.USER_PREFERENCE_SOURCE);

//             Join Telemetry data and UserPreference data to create EnrichedTelemetry (Encapsulating Class) and Key By VID
            KeyedStream<EnrichedTelemetry, String> enrichedMultiAlertCampaignStream = getKeyedStreamWithMultiAlert(env, parameterTool, userPreferKeyedStream, multiAlertCampaignInputTopic);

            // SINK for priorityNotificationSink Kafka Topic
            KafkaConnector.KafkaProperties prioritySinkProperties = KafkaConnector.getNotificationKafkaProperties(parameterTool, priorityTopic);
            KafkaSink<String> priorityNotificationSink = KafkaConnector.getKafkaSink(prioritySinkProperties, parameterTool, isTest);

            // SINK for standardNotificationSink Kafka Topic
//            KafkaConnector.KafkaProperties standardSinkProperties = KafkaConnector.getNotificationKafkaProperties(parameterTool, standardTopic);
//            KafkaSink<String> standardNotificationSink = KafkaConnector.getKafkaSink(standardSinkProperties, parameterTool, isTest);

            // Starting a new chain for better visualization
            // Priority notifications
            enrichedMultiAlertCampaignStream
                    .filter(priorityFilter)
                    .name(OperatorNames.PRIORITY_NOTIFICATION_FILTER)
                    .uid(OperatorNames.PRIORITY_NOTIFICATION_FILTER)
                    .startNewChain()
                    .flatMap(notificationMap)
                    .name(OperatorNames.PRIORITY_NOTIFICATION_MAPPER)
                    .uid(OperatorNames.PRIORITY_NOTIFICATION_MAPPER)
                    .sinkTo(priorityNotificationSink)
                    .name(OperatorNames.PRIORITY_NOTIFICATION_SINK)
                    .uid(OperatorNames.PRIORITY_NOTIFICATION_SINK);

            // Starting a new chain for better visualization
            // Standard notifications
//            enrichedMultiAlertCampaignStream.filter(standardFilter)
//                    .name(OperatorNames.STANDARD_NOTIFICATION_FILTER)
//                    .uid(OperatorNames.STANDARD_NOTIFICATION_FILTER)
//                    .startNewChain()
//                    .flatMap(notificationMap)
//                    .name(OperatorNames.STANDARD_NOTIFICATION_MAPPER)
//                    .uid(OperatorNames.STANDARD_NOTIFICATION_MAPPER)
//                    .sinkTo(standardNotificationSink)
//                    .name(OperatorNames.STANDARD_NOTIFICATION_SINK)
//                    .uid(OperatorNames.STANDARD_NOTIFICATION_SINK);

            env.execute();

        } catch (Exception e) {
            log.error("Error executing Edge alerts job", e);
        }
    }

    private static KeyedStream<EnrichedTelemetry, String> getKeyedStreamWithMultiAlert(final StreamExecutionEnvironment env,
                                                                                       final ParameterTool parameterTool,
                                                                                       final KeyedStream<UserPreference, String> userPreferKeyedStream,
                                                                                       final String inputTopic) {

        String telemetryMasterCampaignTopic = parameterTool.get(FlinkRuntime.Kafka.TELEMETRY_CAMPAIGN_TOPIC);
        String telemetryMasterConsumer = parameterTool.get(FlinkRuntime.Kafka.CAMPAIGN_GROUP);
        KafkaConnector.KafkaProperties telemetryMasterKafkaProps = KafkaConnector.getTelemetryKafkaProperties(parameterTool, telemetryMasterConsumer, telemetryMasterCampaignTopic);
        DataStream<Telemetry> telemetryMasterKeyedStream = SourceStream.getDataStream(
                env,
                parameterTool,
                telemetryMasterKafkaProps,
                telemetryFlatMapFunction,
                "Kafka Master Telemetry Campaign Source",
                OperatorNames.MASTER_CAMPAIGN_SOURCE);

        KafkaConnector.KafkaProperties telemetryKafkaProps = KafkaConnector.getTelemetryKafkaProperties(parameterTool, inputTopic);
        DataStream<Telemetry> multiAlertCondStream = SourceStream.getDataStream(
                env,
                parameterTool,
                telemetryKafkaProps,
                telemetryFlatMapFunction,
                "Kafka Multi Alert Campaign Source",
                OperatorNames.CAMPAIGN_SOURCE);

        KeyedStream<Telemetry, String> unionMasterTelemetryAndMultiCampaignTelemetryStream = telemetryMasterKeyedStream.union(multiAlertCondStream).keyBy(TelemetryUtils::getVirtualId);
        SingleOutputStreamOperator<EnrichedTelemetry> enrichedTelemetryStringStream = getTelemetryUserPreferenceStream(
                OperatorNames.ENRICHMENT,
                unionMasterTelemetryAndMultiCampaignTelemetryStream,
                userPreferKeyedStream,
                enrichedMultiAlertsFunction);

        return enrichedTelemetryStringStream.keyBy(SourceStream.getEnrichedTelemetryKey());
    }

    public static SingleOutputStreamOperator<EnrichedTelemetry> getTelemetryUserPreferenceStream(final String operatorName,
                                                                                                 final KeyedStream<Telemetry, String> telemetryKeyedStream,
                                                                                                 final KeyedStream<UserPreference, String> userPreferKeyedStream,
                                                                                                 final RichCoFlatMapFunction<Telemetry, UserPreference, EnrichedTelemetry> coMapperFunction) {
        log.info("Connecting telemetry keyed streams and user preference keyed streams with id {}", operatorName);

        return telemetryKeyedStream
                .connect(userPreferKeyedStream)
                .keyBy(TelemetryUtils::getVirtualId, UserPreference::getVid)
                .flatMap(coMapperFunction)
                .name(operatorName)
                .uid(operatorName);
    }
}
