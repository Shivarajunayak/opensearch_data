package org.hmcl.cvp.dataplatform.edgealerts.helper;


import lombok.extern.slf4j.Slf4j;
import org.hmcl.cvp.dataplatform.contract.notification.AlertInfo;
import org.hmcl.cvp.dataplatform.contract.notification.AlertType;
import org.hmcl.cvp.dataplatform.edgealerts.contracts.AlertMapping;

import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Properties;

@Slf4j
public class EdgeAlertsHelper {

    private EdgeAlertsHelper() {}

    public static String getAlertMappingFileName(String env) {
        return String.format("alert-mappings-%s.properties", env);
    }

    public static Properties getProperties(String env) {
        final String fileName = getAlertMappingFileName(env);
        final Properties properties = new Properties();
        ClassLoader classLoader = EdgeAlertsHelper.class.getClassLoader();
        try
        {
            var fileInputStream = classLoader.getResourceAsStream(fileName);
            properties.load(fileInputStream);
        } catch(IOException e) {
            log.error("Exception while loading {} ", fileName, e);
        }
        log.info("properties extracted from resource file is {} ",properties);
        return properties;
    }

    public static AlertInfo getAlertInfo(AlertMapping alertMapping, Properties properties) {
        if(Objects.isNull(properties) || properties.isEmpty()) return null;

        String baseKey = alertMapping.value();
        String code = baseKey + ".code";
        String name = baseKey + ".name";
        String type = baseKey + ".type";

        if(!properties.containsKey(code) || !properties.containsKey(name) || !properties.containsKey(type)) return null;

        String typeString = properties.getProperty(type);
        AlertType alertType = AlertType.fromValue(typeString);

        return AlertInfo.builder()
                .code(properties.getProperty(code))
                .type(alertType)
                .name(properties.getProperty(name))
                .build();
    }

    public static Map<String, AlertInfo> getAlertInfos(String env) {
        Map<String, AlertInfo> alertInfoMap = new HashMap<>();

        Properties properties = getProperties(env);

        if(properties.isEmpty()) return alertInfoMap;

        List<AlertMapping> mappings = AlertMapping.getAllAlertMapping();

        for (AlertMapping mapping : mappings) {
            AlertInfo alertInfo = getAlertInfo(mapping, properties);

            if(Objects.nonNull(alertInfo)) {
                alertInfoMap.put(mapping.value(), alertInfo);
            }

        }

        log.debug("alertInfoMap is {} ",alertInfoMap);
        return alertInfoMap;

    }

}
