package org.hmcl.cvp.dataplatform.edgealerts.contracts;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public enum AlertMapping {

    AUX_BATTERY_UNPLUGGED("aux-battery-unplugged"),

    AUX_BATTERY_LOW("aux-battery-low"),

    BATTERY_OVERHEATING("battery-overheating"),

    CRASH("crash"),

    FALL_DOWN("fall-down"),

    HARSH_ACCELERATION("harsh-acceleration"),

    HARSH_BRAKING("harsh-braking"),

    IGNITION_ON("ignition-on"),

    IGNITION_OFF("ignition-off"),

    MOTOR_ON("motor-on"),

    MOTOR_OFF("motor-off"),

    MOVEMENT("movement"),

    OVER_SPEED("over-speed"),

    PANIC("panic"),

    THERMAL_RUNAWAY("thermal-runaway"),

    TOW_THEFT("tow-theft"),

    TRACTION_BATTERY_UNPLUGGED("traction-battery-unplugged"),

    DTC_MIL_ALERT("dtc-mil"),

    ;

    private static final Map<String, AlertMapping> CONSTANTS = new HashMap<>();

    private final String value;

    AlertMapping(String value) {
        this.value = value;
    }

    static {
        for (AlertMapping c : values()) {
            CONSTANTS.put(c.value, c);
        }
    }

    public static List<AlertMapping> getAllAlertMapping() {
        return new ArrayList<>(CONSTANTS.values());
    }

    public String value() {
        return value;
    }


}
