package org.hmcl.cvp.dataplatform.edgealerts.alerts;

import org.hmcl.cvp.dataplatform.commons.testdata.UserPreferenceGenerator;
import org.hmcl.cvp.dataplatform.contract.notification.AlertPriority;
import org.hmcl.cvp.dataplatform.contract.telemetry.CommonSignals;
import org.hmcl.cvp.dataplatform.contract.telemetry.Telemetry;
import org.hmcl.cvp.dataplatform.contract.userpreference.UserPreference;
import org.hmcl.cvp.dataplatform.edgealerts.contracts.AlertMapping;
import org.hmcl.cvp.dataplatform.edgealerts.model.MultiAlertEvent;
import org.hmcl.cvp.dataplatform.contract.telemetry.MultiAlertSignals;
import org.hmcl.cvp.dataplatform.edgealerts.utils.AlertsData;
import org.junit.Assert;
import org.junit.Test;

import java.time.Instant;

public class MotorOnAlertTest {
    MultiAlertEvent alertEvent = new MultiAlertEvent(MultiAlertSignals.MOTOR_ALERT_RISE_SIGNAL, Instant.now().toEpochMilli());

    private Telemetry getTelemetry(MultiAlertEvent alertEvent) {
        UserPreference primaryRider = UserPreferenceGenerator.getPrimaryRider(AlertsData.VIRTUAL_ID);
        Instant instant = Instant.now();

        return AlertsData.getAlertEvent(primaryRider, CommonSignals.MULTI_ALERT.key(), instant, alertEvent == null ? null : alertEvent.getAlertSignal());
    }

    @Test
    public void testMotorOnAlert_getAlertMapping() {
        Telemetry telemetry = getTelemetry(alertEvent);
        MotorOnAlert motorOnAlert = new MotorOnAlert();
        AlertMapping alertMapping = motorOnAlert.getAlertMapping(telemetry);

        Assert.assertEquals(AlertMapping.MOTOR_ON, alertMapping);
    }

    @Test
    public void testMotorOnAlert_isNotificationRequired() {
        Telemetry telemetry = getTelemetry(alertEvent);
        MotorOnAlert motorOnAlert = new MotorOnAlert();
        boolean isNotificationRequired = motorOnAlert.isNotificationRequired(telemetry, alertEvent);
        Assert.assertTrue(isNotificationRequired);
    }

    @Test
    public void testMotorOnAlert_getAlertPriority() {
        Assert.assertEquals(AlertPriority.HIGH, new MotorOnAlert().getAlertPriority());
    }

    @Test
    public void testMotorOnAlert_getFeatureName() {
        Assert.assertEquals("Motor On/Off", new MotorOnAlert().getFeatureName());
    }

    @Test
    public void testMotorOnAlert_isSignalPresentForMultiAlert() {
        Assert.assertTrue(new MotorOnAlert().isSignalPresentForMultiAlert(MultiAlertSignals.MOTOR_ALERT_RISE_SIGNAL));
    }

}
