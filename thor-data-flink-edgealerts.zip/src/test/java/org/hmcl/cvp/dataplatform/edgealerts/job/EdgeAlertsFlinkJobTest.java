package org.hmcl.cvp.dataplatform.edgealerts.job;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.salesforce.kafka.test.KafkaTestCluster;
import com.salesforce.kafka.test.KafkaTestUtils;
import lombok.extern.slf4j.Slf4j;
import net.datafaker.Faker;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.apache.kafka.clients.producer.KafkaProducer;
import org.apache.kafka.clients.producer.Producer;
import org.apache.kafka.clients.producer.ProducerConfig;
import org.apache.kafka.clients.producer.ProducerRecord;
import org.apache.kafka.common.serialization.StringDeserializer;
import org.hmcl.cvp.dataplatform.commons.catalogue.DimensionCatalogue;
import org.hmcl.cvp.dataplatform.commons.catalogue.SignalCatalogue;
import org.hmcl.cvp.dataplatform.commons.testdata.CampaignDataGenerator;
import org.hmcl.cvp.dataplatform.commons.testdata.SignalGenerator;
import org.hmcl.cvp.dataplatform.commons.testdata.UserPreferenceGenerator;
import org.hmcl.cvp.dataplatform.commons.testdata.faker.BikeFaker;
import org.hmcl.cvp.dataplatform.contract.telemetry.SignalData;
import org.hmcl.cvp.dataplatform.contract.telemetry.SignalInfo;
import org.hmcl.cvp.dataplatform.contract.telemetry.Telemetry;
import org.hmcl.cvp.dataplatform.contract.telemetry.Tenant;
import org.hmcl.cvp.dataplatform.contract.userpreference.Circle;
import org.hmcl.cvp.dataplatform.contract.userpreference.Coordinate;
import org.hmcl.cvp.dataplatform.contract.userpreference.GeoFenceFeature;
import org.hmcl.cvp.dataplatform.contract.userpreference.Polygon;
import org.hmcl.cvp.dataplatform.contract.userpreference.UserPreference;
import org.junit.AfterClass;
import org.junit.Assert;
import org.junit.BeforeClass;
import org.junit.Test;
import org.testcontainers.shaded.org.awaitility.Awaitility;

import java.time.Duration;
import java.time.Instant;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.Set;

@Slf4j
public class EdgeAlertsFlinkJobTest {

    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static final BikeFaker BIKE_FAKER = new BikeFaker();

    private static final String INPUT_TOPIC = "telemetry";
    private static final String USER_PREF_INPUT_TOPIC = "user.preference";
    private static final String PRIORITY_OUTPUT_TOPIC = "priority";
    private static final String STANDARD_OUTPUT_TOPIC = "standard";

    private static final String VIRTUAL_ID = "0666ae1e-e3a4-7205-8000-9a0e2487ffa9";
    private static final String ALERT_CAMPAIGN = "thor_alert_cond_v1";

    private static KafkaTestUtils utils;
    private static KafkaTestCluster cluster;

    @BeforeClass
    public static void startKafkaCluster() throws Throwable {
        // Setup InMemory  Kafka Cluster
        cluster = new KafkaTestCluster(1);
        cluster.start();
        utils = new KafkaTestUtils(cluster);

        utils.createTopic(INPUT_TOPIC, 1, (short) 1);
        utils.createTopic(USER_PREF_INPUT_TOPIC, 1, (short) 1);
        utils.createTopic(PRIORITY_OUTPUT_TOPIC, 1, (short) 1);
        utils.createTopic(STANDARD_OUTPUT_TOPIC, 1, (short) 1);
    }

    @AfterClass
    public static void stopKafkaCluster() throws Exception {
        cluster.close();
    }

    private static String[] getSystemArgs() {
        return new String[]{
                // SET ONLY WHILE RUNNING TEST - DEFAULT VALUE FALSE
                "--env", "dev",
                "--is.run.test.case", "TRUE",
                "--aws.region", "ap-south-1",
                "--alerts.suppression.in.min", "1",
                "--alerts.allowed.lateness.in.min", "1000",
                "--alerts.allowed.burst.rate.per.sec", "10",
                "--user.preference.state.ttl.in.days", "1",

                // KAFKA Telemetry PROPERTY
                "--kafka.campaign.bootstrap.brokers", cluster.getKafkaConnectString(),
                "--kafka.edge.alerts.campaign.input.topic", INPUT_TOPIC,
                "--kafka.campaign.group.id", "EdgeAlertsCampaignGroup",
                "--kafka.campaign.role.arn", "XXXXX",
                "--kafka.campaign.session.name", "EdgeAlertsCampaignSession",

                // KAFKA User preference PROPERTY
                "--kafka.userpref.bootstrap.brokers", cluster.getKafkaConnectString(),
                "--kafka.userpref.input.topic", USER_PREF_INPUT_TOPIC,
                "--kafka.userpref.group.id", "EdgeAlertsUserPrefGroup",
                "--kafka.userpref.role.arn", "XXXXX",
                "--kafka.userpref.session.name", "EdgeAlertsUserPrefSession",

                // KAFKA Notification
                "--kafka.notification.bootstrap.brokers", cluster.getKafkaConnectString(),
                "--kafka.notification.priority.topic", PRIORITY_OUTPUT_TOPIC,
                "--kafka.notification.standard.topic", STANDARD_OUTPUT_TOPIC,
                "--kafka.notification.group.id", "EdgeAlertsNotificationGroup",
                "--kafka.notification.role.arn", "XXXXX",
                "--kafka.notification.session.name", "EdgeAlertsNotificationSession",
                "--sink.acks", "all"
        };
    }

    private static Producer<String, String> getProducer() {
        Properties props = new Properties();

        props.put(ProducerConfig.BOOTSTRAP_SERVERS_CONFIG, cluster.getKafkaConnectString());
        props.put("security.protocol", "PLAINTEXT");
        props.put(ProducerConfig.ACKS_CONFIG, "all");
        props.put(ProducerConfig.RETRIES_CONFIG, 2);
        props.put(ProducerConfig.LINGER_MS_CONFIG, 2);
        props.put(ProducerConfig.KEY_SERIALIZER_CLASS_CONFIG, "org.apache.kafka.common.serialization.StringSerializer");
        props.put(ProducerConfig.VALUE_SERIALIZER_CLASS_CONFIG, "org.apache.kafka.common.serialization.StringSerializer");

        return new KafkaProducer<>(props);
    }

    private void sendUserPreferenceData(List<UserPreference> userPreferences) {
        Producer<String, String> producer = getProducer();

        userPreferences.forEach(v -> {
            String message = GSON.toJson(v);
            ProducerRecord<String, String> producerRecord = new ProducerRecord<>(USER_PREF_INPUT_TOPIC, message);
            producer.send(producerRecord);
        });

        producer.flush();
        producer.close();
    }

    private List<UserPreference> produceUserPreferenceData() {
        List<UserPreference> userPreferencesSent = new ArrayList<>();

        UserPreference primaryUser = UserPreferenceGenerator.getPrimaryUser(VIRTUAL_ID);
        UserPreference secondaryRider = UserPreferenceGenerator.getSecondaryRider(VIRTUAL_ID);

        userPreferencesSent.add(primaryUser);
        userPreferencesSent.add(secondaryRider);

        return userPreferencesSent;
    }

    private Telemetry getTelemetry(GeoFenceFeature geoFenceFeature, SignalInfo signalInfo) {
        return getAlert(signalInfo.getKey(),
                ALERT_CAMPAIGN,
                VIRTUAL_ID,
                geoFenceFeature,
                SignalGenerator.getAlertSignal());
    }

    public static Telemetry getAlert(String key, String campaignName, String virtualId, GeoFenceFeature geoFenceFeature, Set<SignalData> signalData) {
        Telemetry telemetry = getAlertTelemetry(campaignName, virtualId, geoFenceFeature);
        telemetry.getSignals().put(key, signalData);
        return telemetry;
    }

    public static Telemetry getAlertTelemetry(String campaignName, String virtualId, GeoFenceFeature geoFenceFeature) {
        return getAlertTelemetry(campaignName, virtualId, getCoordinates(geoFenceFeature));
    }

    public static List<Coordinate> getCoordinates(GeoFenceFeature geoFenceFeature) {
        boolean isCircle = geoFenceFeature.getIsFenceTypeCircle();
        if (isCircle) {
            Circle circle = geoFenceFeature.getCircle();
            return List.of(circle.getCoordinates());
        } else {
            Polygon polygon = geoFenceFeature.getPolygon();
            return polygon.getCoordinates();
        }
    }

    public static Telemetry getAlertTelemetry(String campaignName, String virtualId, List<Coordinate> coordinates) {
        return getAlertTelemetry(campaignName, virtualId, coordinates, BIKE_FAKER.fuelType().random());
    }

    public static Telemetry getAlertTelemetry(String campaignName, String virtualId, List<Coordinate> coordinates, Tenant tenant) {
        int countOfEachSignal = 1;
        Telemetry telemetry = getTelemetry(campaignName, (String) virtualId, (Tenant) tenant, countOfEachSignal);
        Map<String, Set<SignalData>> signals = getMandatoryAlertSignals(coordinates, tenant, Instant.now(), countOfEachSignal);
        telemetry.setSignals(signals);
        return telemetry;
    }

    public static Telemetry getTelemetry(String campaignName, String virtualId, Tenant tenant, int countOfEachSignal) {
        return getTelemetry(campaignName, virtualId, tenant, Instant.now(), countOfEachSignal);
    }

    private static final Faker FAKER = new Faker();

    public static Map<String, String> getDimensions(String virtualId, Tenant tenant) {
        Map<String, String> dimensions = new HashMap();
        dimensions.put(DimensionCatalogue.getTenantIdKey(), tenant.value());
        dimensions.put(DimensionCatalogue.getVirtualIdKey(), virtualId);
        return dimensions;
    }

    public static Telemetry getTelemetry(String campaignName, String virtualId, Tenant tenant, Instant instant, int countOfEachSignal) {
        Telemetry telemetry = new Telemetry();
        telemetry.setCampaignName(campaignName);
        telemetry.setVehicleName(FAKER.vehicle().model());
        telemetry.setEventId(FAKER.number().positive());
        telemetry.setCollectionEventTime(instant.toEpochMilli());
        telemetry.setDimensions(getDimensions(virtualId, tenant));
        telemetry.setSignals(getAdditionalSignals(tenant, instant, countOfEachSignal));
        return telemetry;
    }

    public static Map<String, Set<SignalData>> getAdditionalSignals(Tenant tenant, Instant instant, int countOfEachSignal) {
        Coordinate coordinate = new Coordinate();
        coordinate.setLatitude(12.862668998147448);
        coordinate.setLongitude(77.7061196254997);
        Map<String, Set<SignalData>> signals = getMandatoryAlertSignals(List.of(coordinate), tenant, instant, countOfEachSignal);
        SignalInfo distanceAccumulation = SignalCatalogue.getDistanceAccumulationInfo();
        signals.put(distanceAccumulation.getKey(), SignalGenerator.getRandomSignals(distanceAccumulation, countOfEachSignal, instant));
        return signals;
    }

    public static Map<String, Set<SignalData>> getMandatoryAlertSignals(List<Coordinate> coordinates, Tenant tenant, Instant instant, int countOfEachSignal) {
        Map<String, Set<SignalData>> signals = SignalGenerator.getLatLongSignals(coordinates, instant);
        SignalInfo socUser = SignalCatalogue.getSocUserPercentageInfo();
        signals.put(socUser.getKey(), SignalGenerator.getRandomSignals(socUser, countOfEachSignal, instant));
        SignalInfo socUserBms1 = SignalCatalogue.getSocUserBMS1Info();
        signals.put(socUserBms1.getKey(), SignalGenerator.getRandomSignals(socUserBms1, countOfEachSignal, instant));
        SignalInfo socUserBms2 = SignalCatalogue.getSocUserBMS2Info();
        signals.put(socUserBms2.getKey(), SignalGenerator.getRandomSignals(socUserBms2, countOfEachSignal, instant));
        SignalInfo tcuIgnition = SignalCatalogue.getTcuIgnitionInfo();
        signals.put(tcuIgnition.getKey(), SignalGenerator.getBooleanSignals(true, instant, countOfEachSignal));
        SignalInfo gpsFix = SignalCatalogue.getGpsFixInfo();
        signals.put(gpsFix.getKey(), SignalGenerator.getRandomSignals(gpsFix, countOfEachSignal, instant));
        SignalInfo chargerState = SignalCatalogue.getChargerStateInfo();
        signals.put(chargerState.getKey(), SignalGenerator.getRandomSignals(chargerState, countOfEachSignal, instant));
        SignalInfo driveTrainStatus = SignalCatalogue.getDriveTrainStatusInfo();
        signals.put(driveTrainStatus.getKey(), SignalGenerator.getRandomSignals(driveTrainStatus, countOfEachSignal, instant));
        SignalInfo drivingMode = SignalCatalogue.getDrivingModeInfo();
        signals.put(drivingMode.getKey(), SignalGenerator.getRandomSignals(drivingMode, countOfEachSignal, instant));
        SignalInfo fuelLevel = SignalCatalogue.getFuelLevelInfo();
        signals.put(fuelLevel.getKey(), SignalGenerator.getRandomSignals(fuelLevel, countOfEachSignal, instant));
        SignalInfo odometer = SignalCatalogue.getOdometerInfo();
        signals.put(odometer.getKey(), SignalGenerator.getRandomSignals(odometer, countOfEachSignal, instant));
        SignalInfo vDop = SignalCatalogue.getVDopInfo();
        signals.put(vDop.getKey(), SignalGenerator.getRandomSignals(vDop, countOfEachSignal, instant));
        SignalInfo pDop = SignalCatalogue.getPDopInfo();
        signals.put(pDop.getKey(), SignalGenerator.getRandomSignals(pDop, countOfEachSignal, instant));
        SignalInfo hDop = SignalCatalogue.getHDopInfo();
        signals.put(hDop.getKey(), SignalGenerator.getSignals(hDop, 0.5, instant, countOfEachSignal));
        SignalInfo gpsValid = SignalCatalogue.getGpsValidInfo();
        signals.put(gpsValid.getKey(), SignalGenerator.getBooleanSignals(true, instant, countOfEachSignal));
        if (tenant.equals(Tenant.EV)) {
            SignalInfo sideStandStatus = SignalCatalogue.getSideStandStatusInfo();
            signals.put(sideStandStatus.getKey(), SignalGenerator.getRandomSignals(sideStandStatus, countOfEachSignal, instant));
        } else {
            signals.put(SignalCatalogue.getSideStandSensorStatusInfo().getKey(), SignalGenerator.getBooleanSignals(false, instant));
        }

        return signals;
    }


    private List<Telemetry> getTelemetriesForAllEdge(GeoFenceFeature geoFenceFeature) {
        List<Telemetry> telemetryData = new ArrayList<>();

        telemetryData.add(getTelemetry(geoFenceFeature, SignalCatalogue.getOverSpeedAlertInfo()));

        telemetryData.add(getTelemetry(geoFenceFeature, SignalCatalogue.getAccidentAlertInfo()));

        telemetryData.add(getTelemetry(geoFenceFeature, SignalCatalogue.getHarshDrivingAlertInfo()));

        telemetryData.add(getTelemetry(geoFenceFeature, SignalCatalogue.getPanicAlertInfo()));

        telemetryData.add(getTelemetry(geoFenceFeature, SignalCatalogue.getFallAlertInfo()));

        telemetryData.add(getTelemetry(geoFenceFeature, SignalCatalogue.getAuxBatteryAlertLowInfo()));

        telemetryData.add(getTelemetry(geoFenceFeature, SignalCatalogue.getAuxBatteryRemovalInfo()));

        telemetryData.add(getTelemetry(geoFenceFeature, SignalCatalogue.getTheftTowAlertInfo()));

        telemetryData.add(getTelemetry(geoFenceFeature, SignalCatalogue.getMovementAlertInfo()));

        // Dummy signal
        SignalInfo dummyAlert = SignalInfo.doubleValue("hmcl.common.vcan0.dummy.alert", "Dummy alert");
        telemetryData.add(getTelemetry(geoFenceFeature, dummyAlert));

        return telemetryData;
    }

    private Telemetry getIgnitionAlert(GeoFenceFeature geoFenceFeature, boolean value) {
        SignalData ignitionAlert = new SignalData();
        ignitionAlert.setTime(Instant.now().toEpochMilli());
        ignitionAlert.setDataType("BOOLEAN");
        ignitionAlert.setValue(value);

        Set<SignalData> ignitionAlertDataSet = new HashSet<>();
        ignitionAlertDataSet.add(ignitionAlert);

        return CampaignDataGenerator.getAlert(SignalCatalogue.getIgnitionAlertInfo().getKey(),
                ALERT_CAMPAIGN,
                VIRTUAL_ID,
                geoFenceFeature,
                ignitionAlertDataSet);

    }

    private Telemetry getMotorAlert(GeoFenceFeature geoFenceFeature, int value) {
        SignalData motorAlert = new SignalData();
        motorAlert.setTime(Instant.now().toEpochMilli());
        motorAlert.setDataType("INTEGER");
        motorAlert.setValue(value);

        Set<SignalData> motorAlertSignals = new HashSet<>();
        motorAlertSignals.add(motorAlert);

        return CampaignDataGenerator.getAlert(SignalCatalogue.getMotorStatusInfo().getKey(),
                ALERT_CAMPAIGN,
                VIRTUAL_ID,
                geoFenceFeature,
                motorAlertSignals);

    }

    private Telemetry getThermalRunawayAlert(GeoFenceFeature geoFenceFeature, int value) {

        SignalData thermalRunawaySignal = new SignalData();
        thermalRunawaySignal.setTime(Instant.now().toEpochMilli());
        thermalRunawaySignal.setDataType("Integer");
        thermalRunawaySignal.setValue(value);

        Set<SignalData> thermalRunawayDataSet = new HashSet<>();
        thermalRunawayDataSet.add(thermalRunawaySignal);

        return CampaignDataGenerator.getAlert(SignalCatalogue.getThermalRunawayWarningInfo().getKey(),
                ALERT_CAMPAIGN,
                VIRTUAL_ID,
                geoFenceFeature,
                thermalRunawayDataSet);

    }

    private void sendCampaignData(List<Telemetry> telemetryData) {
        Producer<String, String> producer = getProducer();

        telemetryData.forEach(v -> {
            String message = GSON.toJson(v);
            ProducerRecord<String, String> producerRecord = new ProducerRecord<>(EdgeAlertsFlinkJobTest.INPUT_TOPIC, message);
            producer.send(producerRecord);
            producer.flush();
        });

        producer.close();
    }

    private Long getNotificationEvents(String topic) {

        // READ DATA FROM NOTIFICATION_OUTPUT_TOPIC and display it
        List<ConsumerRecord<String, String>> consumerRecords = utils.consumeAllRecordsFromTopic(
                topic,
                StringDeserializer.class,
                StringDeserializer.class
        );

        for (ConsumerRecord<String, String> consumerRecord : consumerRecords) {
            log.info("{}", consumerRecord);
        }
        int count = consumerRecords.size();
        log.info("Number of records in {}: {}", topic, count);

        return (long) count;
    }

    @Test
    public void testEdgeAlerts_allAlerts() throws InterruptedException {
        List<UserPreference> userPreferences = produceUserPreferenceData();
        // Send user preference data in separate thread and wait for 5 seconds to make sure data is sent and reaches flink.
        userPreferenceThread(userPreferences);

        Awaitility.await()
                .timeout(Duration.ofSeconds(15))
                .pollDelay(Duration.ofSeconds(10))
                .untilAsserted(() -> Assert.assertTrue(true));

        List<GeoFenceFeature> geoFenceFeatures = userPreferences.get(0).getAssignedFeatures().getGeoFenceFeatures();
        GeoFenceFeature geoFenceFeature = geoFenceFeatures.get(0);

        List<Telemetry> alertData = getTelemetriesForAllEdge(geoFenceFeature);

        alertData.add(getIgnitionAlert(geoFenceFeature, true)); // Ignition On
        alertData.add(getIgnitionAlert(geoFenceFeature, false)); // Ignition Off
        alertData.add(getMotorAlert(geoFenceFeature, 3)); // Motor On
        alertData.add(getMotorAlert(geoFenceFeature, 0)); // Motor Off
        alertData.add(getThermalRunawayAlert(geoFenceFeature, 5)); // Thermal runaway
        alertData.add(getThermalRunawayAlert(geoFenceFeature, 3)); // Battery overheating

        sendCampaignData(alertData);

        Awaitility.await()
                .timeout(Duration.ofSeconds(15))
                .pollDelay(Duration.ofSeconds(10))
                .untilAsserted(() -> Assert.assertTrue(true));

        Thread flinkJob = new Thread(() -> {
            try {
                EdgeAlertsFlink.main(getSystemArgs());
            } catch (Exception e) {
                throw new RuntimeException(e);
            }
        });
        flinkJob.start();

        // Interrupt the thread after 10 seconds
        flinkJob.join(Duration.ofSeconds(60).toMillis());

        long outputStandardEvents = getNotificationEvents(STANDARD_OUTPUT_TOPIC);
        log.info("Number of standard events: {}", outputStandardEvents);
        Assert.assertEquals(0, outputStandardEvents);

        // There should be 15 alerts.All alerts will be priority.
        long outputPriorityEvents = getNotificationEvents(PRIORITY_OUTPUT_TOPIC);
        log.info("Number of priority events: {}", outputPriorityEvents);
        Assert.assertEquals(15, outputPriorityEvents);

    }

    private void userPreferenceThread(List<UserPreference> userPreferences) throws InterruptedException {
        Thread sendUserPreference = new Thread(() -> {
            try {
                sendUserPreferenceData(userPreferences);
            } catch (Exception e) {
                throw new RuntimeException(e);
            }
        });
        sendUserPreference.start();
        sendUserPreference.join(Duration.ofSeconds(5).toMillis());
    }

}
