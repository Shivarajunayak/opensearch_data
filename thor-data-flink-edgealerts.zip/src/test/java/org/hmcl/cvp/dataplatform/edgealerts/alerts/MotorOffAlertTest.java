package org.hmcl.cvp.dataplatform.edgealerts.alerts;

import org.hmcl.cvp.dataplatform.commons.testdata.UserPreferenceGenerator;
import org.hmcl.cvp.dataplatform.contract.notification.AlertPriority;
import org.hmcl.cvp.dataplatform.contract.telemetry.CommonSignals;
import org.hmcl.cvp.dataplatform.contract.telemetry.Telemetry;
import org.hmcl.cvp.dataplatform.contract.userpreference.UserPreference;
import org.hmcl.cvp.dataplatform.edgealerts.contracts.AlertMapping;
import org.hmcl.cvp.dataplatform.edgealerts.model.MultiAlertEvent;
import org.hmcl.cvp.dataplatform.contract.telemetry.MultiAlertSignals;
import org.hmcl.cvp.dataplatform.edgealerts.utils.AlertsData;
import org.junit.Assert;
import org.junit.Test;

import java.time.Instant;

public class MotorOffAlertTest {
    MultiAlertEvent alertEvent = new MultiAlertEvent(MultiAlertSignals.MOTOR_ALERT_FALL_SIGNAL, Instant.now().toEpochMilli());

    private Telemetry getTelemetry(MultiAlertEvent alertEvent) {
        UserPreference primaryRider = UserPreferenceGenerator.getPrimaryRider(AlertsData.VIRTUAL_ID);
        Instant instant = Instant.now();

        return AlertsData.getAlertEvent(primaryRider, CommonSignals.MULTI_ALERT.key(),instant, alertEvent == null? null:alertEvent.getAlertSignal());
    }

    @Test
    public void testMotorOffAlert_getAlertMapping() {
        Telemetry telemetry = getTelemetry(alertEvent);
        MotorOffAlert motorOffAlert = new MotorOffAlert();
        AlertMapping alertMapping = motorOffAlert.getAlertMapping(telemetry);

        Assert.assertEquals(AlertMapping.MOTOR_OFF, alertMapping);
    }

    @Test
    public void testMotorOffAlert_isNotificationRequired() {
        Telemetry telemetry = getTelemetry(alertEvent);
        MotorOffAlert motorOffAlert = new MotorOffAlert();
        boolean isNotificationRequired = motorOffAlert.isNotificationRequired(telemetry, alertEvent);
        Assert.assertTrue(isNotificationRequired);
    }

    @Test
    public void testMotorOffAlert_getAlertPriority() {
        Assert.assertEquals(AlertPriority.HIGH, new MotorOffAlert().getAlertPriority());
    }

    @Test
    public void testMotorOffAlert_getFeatureName() {
        Assert.assertEquals("Motor On/Off", new MotorOffAlert().getFeatureName());
    }

    @Test
    public void testMotorOffAlert_isSignalPresentForMultiAlert() {
        Assert.assertTrue(new MotorOffAlert().isSignalPresentForMultiAlert(MultiAlertSignals.MOTOR_ALERT_FALL_SIGNAL));
    }

}
