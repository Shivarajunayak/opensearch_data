package org.hmcl.cvp.dataplatform.edgealerts.utils;

import org.apache.flink.streaming.runtime.streamrecord.StreamRecord;
import org.hmcl.cvp.dataplatform.commons.testdata.CampaignDataGenerator;
import org.hmcl.cvp.dataplatform.contract.enriched.EnrichedTelemetry;
import org.hmcl.cvp.dataplatform.contract.telemetry.SignalData;
import org.hmcl.cvp.dataplatform.contract.telemetry.Telemetry;
import org.hmcl.cvp.dataplatform.contract.userpreference.GeoFenceFeature;
import org.hmcl.cvp.dataplatform.contract.userpreference.UserPreference;

import java.time.Instant;
import java.util.Collection;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

public class AlertsData {

    public static final String VIRTUAL_ID = "0666ae1e-e3a4-7205-8000-9a0e2487ffa9";

    private AlertsData() {
    }

    public static List<EnrichedTelemetry> getEnrichedTelemetryOutputs(Collection<StreamRecord<EnrichedTelemetry>> output) {
        return output.stream().map(StreamRecord::getValue).collect(Collectors.toList());
    }

    public static Set<SignalData> getSignals(Instant instant, String alertEvent) {
        Set<SignalData> data = new HashSet<>();
        data.add(new SignalData("[\"" + alertEvent + "\"]", instant.toEpochMilli(), "VARCHAR"));
        return data;
    }

    public static Telemetry getTelemetry(GeoFenceFeature geoFenceFeature, String key, Instant instant, String alertEvent) {
        Telemetry telemetry = CampaignDataGenerator.getAlert(key,
                "campaign-name",
                VIRTUAL_ID,
                geoFenceFeature,
                getSignals(instant, alertEvent));

        telemetry.setCollectionEventTime(instant.toEpochMilli());

        return telemetry;
    }

    public static Set<SignalData> getSignals(int value, Instant instant) {
        SignalData signalData = new SignalData();
        signalData.setDataType("INTEGER");
        signalData.setTime(instant.toEpochMilli());
        signalData.setValue(value);

        HashSet<SignalData> signals = new HashSet<>();
        signals.add(signalData);

        return signals;
    }

    public static GeoFenceFeature getGeoFenceFeature(UserPreference userPreference) {
        List<GeoFenceFeature> geoFenceFeatures = userPreference.getAssignedFeatures().getGeoFenceFeatures();
        return geoFenceFeatures.get(0);
    }

    public static Telemetry getAlertEvent(UserPreference userPreference, String key, Instant instant, String alertEvent) {
        GeoFenceFeature geoFenceFeature = getGeoFenceFeature(userPreference);
        return getTelemetry(geoFenceFeature, key, instant, alertEvent);
    }

    public static Telemetry getAlertEvent(UserPreference userPreference, String key, SignalData signalData) {
        Set<SignalData> signalDataSet = new HashSet<>();
        signalDataSet.add(signalData);

        GeoFenceFeature geoFenceFeature = getGeoFenceFeature(userPreference);
        return CampaignDataGenerator.getAlert(key,
                "campaign-name",
                VIRTUAL_ID,
                geoFenceFeature,
                signalDataSet);
    }

    public static StreamRecord<Telemetry> getAlertStreamRecord(Telemetry telemetry) {
        return new StreamRecord<>(telemetry);
    }

    public static List<EnrichedTelemetry> getOutputRecords(Collection<StreamRecord<EnrichedTelemetry>> outputRecords) {
        return outputRecords.stream().map(StreamRecord::getValue).collect(Collectors.toList());
    }
}
