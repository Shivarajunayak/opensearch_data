package org.hmcl.cvp.dataplatform.edgealerts.operator;

import org.apache.flink.api.common.typeinfo.BasicTypeInfo;
import org.apache.flink.api.java.functions.KeySelector;
import org.apache.flink.api.java.utils.ParameterTool;
import org.apache.flink.runtime.testutils.MiniClusterResourceConfiguration;
import org.apache.flink.streaming.api.operators.co.CoStreamFlatMap;
import org.apache.flink.streaming.runtime.streamrecord.StreamRecord;
import org.apache.flink.streaming.util.KeyedTwoInputStreamOperatorTestHarness;
import org.apache.flink.test.util.MiniClusterWithClientResource;
import org.hmcl.cvp.dataplatform.commons.constants.FlinkRuntime;
import org.hmcl.cvp.dataplatform.commons.testdata.UserPreferenceGenerator;
import org.hmcl.cvp.dataplatform.commons.utils.FlinkUtils;
import org.hmcl.cvp.dataplatform.commons.utils.TelemetryUtils;
import org.hmcl.cvp.dataplatform.contract.enriched.AlertNotification;
import org.hmcl.cvp.dataplatform.contract.enriched.EnrichedTelemetry;
import org.hmcl.cvp.dataplatform.contract.telemetry.CommonSignals;
import org.hmcl.cvp.dataplatform.contract.telemetry.LatLongPair;
import org.hmcl.cvp.dataplatform.contract.telemetry.MultiAlertSignals;
import org.hmcl.cvp.dataplatform.contract.telemetry.SignalData;
import org.hmcl.cvp.dataplatform.contract.telemetry.Telemetry;
import org.hmcl.cvp.dataplatform.contract.userpreference.UserPreference;
import org.hmcl.cvp.dataplatform.edgealerts.model.MultiAlertEvent;
import org.hmcl.cvp.dataplatform.edgealerts.utils.AlertsData;
import org.junit.Assert;
import org.junit.ClassRule;
import org.junit.Test;

import java.time.Instant;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

public class EnrichedAlertsFunctionFlatMap1Test {

    @ClassRule
    public static MiniClusterWithClientResource flinkCluster =
            new MiniClusterWithClientResource(
                    new MiniClusterResourceConfiguration.Builder()
                            .setNumberSlotsPerTaskManager(2)
                            .setNumberTaskManagers(1)
                            .build());

    private final EnrichedMultiAlertsFunction telemetryUsePreferenceFunction = new EnrichedMultiAlertsFunction();

    private final KeySelector<Telemetry, String> telemetryKeySelector = TelemetryUtils::getVirtualId;

    private final KeySelector<UserPreference, String> userPreferenceStringKeySelector = UserPreference::getVid;

    private KeyedTwoInputStreamOperatorTestHarness<String, Telemetry, UserPreference, EnrichedTelemetry> testHarness(String env) throws Exception {
        ParameterTool parameterTool = ParameterTool.fromMap(new HashMap<>());
        parameterTool = FlinkUtils.addProperties(parameterTool, Map.of(FlinkRuntime.USER_PREFERENCE_STATE_TTL_IN_DAYS, "1"));
        parameterTool = FlinkUtils.addProperties(parameterTool, FlinkRuntime.EdgeAlerts.ALERTS_ALLOWED_LATENESS_IN_MAX, "2");
        parameterTool = FlinkUtils.addProperties(parameterTool, FlinkRuntime.ENV, env);

        KeyedTwoInputStreamOperatorTestHarness<String, Telemetry, UserPreference, EnrichedTelemetry> testHarness = new KeyedTwoInputStreamOperatorTestHarness<>(new CoStreamFlatMap<>(telemetryUsePreferenceFunction),
                telemetryKeySelector,
                userPreferenceStringKeySelector,
                BasicTypeInfo.STRING_TYPE_INFO);

        testHarness.getEnvironment().getExecutionConfig().setGlobalJobParameters(parameterTool);

        return testHarness;
    }

    private KeyedTwoInputStreamOperatorTestHarness<String, Telemetry, UserPreference, EnrichedTelemetry> testHarness() throws Exception {
        return testHarness("dev");
    }

    @Test
    public void testEnrichedAlertsFunction_lateAlerts() {
        try (KeyedTwoInputStreamOperatorTestHarness<String, Telemetry, UserPreference, EnrichedTelemetry> testHarness = testHarness()) {

            testHarness.setup();
            testHarness.open();

            UserPreference primaryRider = UserPreferenceGenerator.getPrimaryRider(AlertsData.VIRTUAL_ID);
            StreamRecord<UserPreference> primaryRiderRecord = new StreamRecord<>(primaryRider);
            testHarness.processElement2(primaryRiderRecord);

            Instant lateInstant = Instant.now().minusSeconds(120);
            MultiAlertEvent alertEvent = new MultiAlertEvent(MultiAlertSignals.OVERSPEED_ALERT_RISE_SIGNAL, Instant.now().toEpochMilli());
            Telemetry telemetry = AlertsData.getAlertEvent(primaryRider, CommonSignals.MULTI_ALERT.key(), lateInstant, alertEvent.getAlertSignal());
            StreamRecord<Telemetry> streamRecord = AlertsData.getAlertStreamRecord(telemetry);

            testHarness.processElement1(streamRecord);

            List<EnrichedTelemetry> outputRecords = AlertsData.getOutputRecords(testHarness.getRecordOutput());
            Assert.assertEquals(1, outputRecords.size());

            AlertNotification alertNotification = outputRecords.get(0).getNotification();
            assertFalse(alertNotification.isNotify());

        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    @Test
    public void testEnrichedAlertsFunction_outOfOrder() {
        try (KeyedTwoInputStreamOperatorTestHarness<String, Telemetry, UserPreference, EnrichedTelemetry> testHarness = testHarness()) {

            testHarness.setup();
            testHarness.open();

            UserPreference primaryRider = UserPreferenceGenerator.getPrimaryRider(AlertsData.VIRTUAL_ID);
            StreamRecord<UserPreference> primaryRiderRecord = new StreamRecord<>(primaryRider);
            testHarness.processElement2(primaryRiderRecord);

            Instant instant = Instant.now();
            MultiAlertEvent alertEventLatest = new MultiAlertEvent(MultiAlertSignals.OVERSPEED_ALERT_RISE_SIGNAL, instant.toEpochMilli());
            Telemetry latestAlert = AlertsData.getAlertEvent(primaryRider, CommonSignals.MULTI_ALERT.key(), instant, alertEventLatest.getAlertSignal());

            Instant olderInstant = instant.minusSeconds(60);
            MultiAlertEvent alertEventOlder = new MultiAlertEvent(MultiAlertSignals.OVERSPEED_ALERT_RISE_SIGNAL, olderInstant.toEpochMilli());
            Telemetry olderAlert = AlertsData.getAlertEvent(primaryRider, CommonSignals.MULTI_ALERT.key(), olderInstant, alertEventOlder.getAlertSignal());

            StreamRecord<Telemetry> latestAlertRecord = AlertsData.getAlertStreamRecord(latestAlert);
            StreamRecord<Telemetry> olderAlertRecord = AlertsData.getAlertStreamRecord(olderAlert);

            testHarness.processElement1(latestAlertRecord);
            testHarness.processElement1(olderAlertRecord);

            List<EnrichedTelemetry> outputRecords = AlertsData.getOutputRecords(testHarness.getRecordOutput());
            Assert.assertEquals(2, outputRecords.size());

            int notifyAlertCount = (int) outputRecords.stream().filter(v -> {
                AlertNotification alertNotification = v.getNotification();
                return alertNotification.isNotify();
            }).count();
            Assert.assertEquals(2, notifyAlertCount);

        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    @Test
    public void testEnrichedAlertsFunction_dev_auxBatteryUnpluggedAlert() {
        testEnrichedAlertsFunction_auxBatteryUnpluggedAlerts("dev", "ALEBFADA");
    }

    @Test
    public void testEnrichedAlertsFunction_dev_auxBatteryUnpluggedState() {
        testEnrichedAlertsFunction_auxBatteryUnpluggedAlerts("dev", "ALEBFADA");
    }

    @Test
    public void testEnrichedAlertsFunction_qa_auxBatteryUnpluggedAlert() {
        testEnrichedAlertsFunction_auxBatteryUnpluggedAlerts("qa", "ALEBFADA");
    }

    @Test
    public void testEnrichedAlertsFunction_qa_auxBatteryUnpluggedState() {
        testEnrichedAlertsFunction_auxBatteryUnpluggedAlerts("qa", "ALEBFADA");
    }

    @Test
    public void testEnrichedAlertsFunction_dev_auxBatteryLowAlert() {
        testEnrichedAlertsFunction_auxBatteryLowAlerts("dev", "AL234BEF");
    }

    @Test
    public void testEnrichedAlertsFunction_NoMultiAlerts() {
        testEnrichedAlertsFunction_NoMultiAlerts("dev");
    }

    @Test
    public void testEnrichedAlertsFunction_withInvalidLatLongs() {
        testEnrichedAlertsFunction_withInvalidLatLongs("dev", "AL234BEF");
    }

    @Test
    public void testEnrichedAlertsFunction_withMissingLatLongs() {
        testEnrichedAlertsFunction_withMissingLatLongs("dev", "AL234BEF");
    }

    @Test
    public void testEnrichedAlertsFunction_dev_auxBatteryLowState() {
        testEnrichedAlertsFunction_auxBatteryLowAlerts("dev", "AL234BEF");
    }

    @Test
    public void testEnrichedAlertsFunction_qa_auxBatteryLowAlert() {
        testEnrichedAlertsFunction_auxBatteryLowAlerts("qa", "AL234BEF");
    }

    @Test
    public void testEnrichedAlertsFunction_qa_auxBatteryLowState() {
        testEnrichedAlertsFunction_auxBatteryLowAlerts("qa", "AL234BEF");
    }

    @Test
    public void testEnrichedAlertsFunction_dev_batteryOverheatingAlert() {
        testEnrichedAlertsFunction_batteryOverheatingAlerts("dev", "ALF712DE");
    }

    @Test
    public void testEnrichedAlertsFunction_qa_batteryOverheatingAlert() {
        testEnrichedAlertsFunction_batteryOverheatingAlerts("qa", "ALF712DE");
    }

    @Test
    public void testEnrichedAlertsFunction_dev_crashAlert() {
        testEnrichedAlertsFunction_crashAlerts("dev", "AL81D68B");
    }

    @Test
    public void testEnrichedAlertsFunction_dev_crashState() {
        testEnrichedAlertsFunction_crashAlerts("dev", "AL81D68B");
    }

    @Test
    public void testEnrichedAlertsFunction_qa_crashAlert() {
        testEnrichedAlertsFunction_crashAlerts("qa", "AL81D68B");
    }

    @Test
    public void testEnrichedAlertsFunction_qa_crashState() {
        testEnrichedAlertsFunction_crashAlerts("qa", "AL81D68B");
    }

    @Test
    public void testEnrichedAlertsFunction_dev_fallDownAlert() {
        testEnrichedAlertsFunction_fallDownAlerts("dev", "ALDCD4EC");
    }

    @Test
    public void testEnrichedAlertsFunction_qa_fallDownAlert() {
        testEnrichedAlertsFunction_fallDownAlerts("qa", "ALDCD4EC");
    }

    @Test
    public void testEnrichedAlertsFunction_dev_harshDrivingAlert() {
        testEnrichedAlertsFunction_harshDrivingAlerts("dev", "AL625A03");
    }

    @Test
    public void testEnrichedAlertsFunction_qa_harshDrivingAlert() {
        testEnrichedAlertsFunction_harshDrivingAlerts("qa", "AL625A03");
    }

    @Test
    public void testEnrichedAlertsFunction_dev_ignitionOnAlert() {
        testEnrichedAlertsFunction_ignitionOnAlerts("dev", "AL0358CD");
    }

    @Test
    public void testEnrichedAlertsFunction_qa_ignitionOnAlert() {
        testEnrichedAlertsFunction_ignitionOnAlerts("qa", "AL0358CD");
    }

    @Test
    public void testEnrichedAlertsFunction_dev_ignitionOffAlert() {
        testEnrichedAlertsFunction_ignitionOffAlerts("dev", "AL0863DB");
    }

    @Test
    public void testEnrichedAlertsFunction_qa_ignitionOffAlert() {
        testEnrichedAlertsFunction_ignitionOffAlerts("qa", "AL0863DB");
    }

    @Test
    public void testEnrichedAlertsFunction_dev_motorOnAlert() {
        testEnrichedAlertsFunction_motorOnAlerts("dev", "ALBAA7EB");
    }

    @Test
    public void testEnrichedAlertsFunction_dev_motorOffAlert() {
        testEnrichedAlertsFunction_motorOffAlerts("dev", "ALE19535");
    }

    @Test
    public void testEnrichedAlertsFunction_qa_motorOnAlert() {
        testEnrichedAlertsFunction_motorOnAlerts("qa", "ALBAA7EB");
    }

    @Test
    public void testEnrichedAlertsFunction_qa_motorOffAlert() {
        testEnrichedAlertsFunction_motorOffAlerts("qa", "ALE19535");
    }

    @Test
    public void testEnrichedAlertsFunction_dev_overSpeedAlert() {
        testEnrichedAlertsFunction_overSpeedAlerts("dev", "AL2EAFC1");
    }

    @Test
    public void testEnrichedAlertsFunction_qa_overSpeedAlert() {
        testEnrichedAlertsFunction_overSpeedAlerts("qa", "AL2EAFC1");
    }

    @Test
    public void testEnrichedAlertsFunction_dev_panicAlert() {
        testEnrichedAlertsFunction_panicAlerts("dev", "ALB3BEAA");
    }

    @Test
    public void testEnrichedAlertsFunction_qa_panicAlert() {
        testEnrichedAlertsFunction_panicAlerts("qa", "ALB3BEAA");
    }

    @Test
    public void testEnrichedAlertsFunction_dev_thermalRunawayAlert() {
        testEnrichedAlertsFunction_thermalAlerts("dev", "AL691F3C");
    }

    @Test
    public void testEnrichedAlertsFunction_qa_thermalRunawayAlert() {
        testEnrichedAlertsFunction_thermalAlerts("qa", "AL691F3C");
    }

    @Test
    public void testEnrichedAlertsFunction_dev_theftAlert() {
        testEnrichedAlertsFunction_theftAlerts("dev", "AL5A88B9");
    }

    @Test
    public void testEnrichedAlertsFunction_qa_theftAlert() {
        testEnrichedAlertsFunction_theftAlerts("qa", "AL5A88B9");
    }

    @Test
    public void testEnrichedAlertsFunction_dev_movementAlert() {
        testEnrichedAlertsFunction_movementAlerts("dev", "AL0F6D21");
    }

    @Test
    public void testEnrichedAlertsFunction_qa_movementAlert() {
        testEnrichedAlertsFunction_movementAlerts("qa", "AL0F6D21");
    }

    private void testEnrichedAlertsFunction_auxBatteryLowAlerts(String env, String alertCode) {
        SignalData auxBatteryLow = new SignalData();
        auxBatteryLow.setTime(Instant.now().toEpochMilli());
        auxBatteryLow.setDataType("VARCHAR");
        auxBatteryLow.setValue("[\"" + MultiAlertSignals.AUX_BATTERY_LOW_ALERT_RISE_SIGNAL + "\"]");

        testEnrichedAlertsFunction_alert(env, alertCode, auxBatteryLow);
    }

    private void testEnrichedAlertsFunction_NoMultiAlerts(String env) {
        testEnrichedAlertsFunction_noAlert(env);
    }

    private void testEnrichedAlertsFunction_withInvalidLatLongs(String env, String alertCode) {
        SignalData auxBatteryLow = new SignalData();
        auxBatteryLow.setTime(Instant.now().toEpochMilli());
        auxBatteryLow.setDataType("VARCHAR");
        auxBatteryLow.setValue("[\"" + MultiAlertSignals.AUX_BATTERY_LOW_ALERT_RISE_SIGNAL + "\"]");

        testEnrichedAlertsFunction_alert_withInvalidLatLongs(env, alertCode, auxBatteryLow);
    }
    private void testEnrichedAlertsFunction_withMissingLatLongs(String env, String alertCode) {
        SignalData auxBatteryLow = new SignalData();
        auxBatteryLow.setTime(Instant.now().toEpochMilli());
        auxBatteryLow.setDataType("VARCHAR");
        auxBatteryLow.setValue("[\"" + MultiAlertSignals.AUX_BATTERY_LOW_ALERT_RISE_SIGNAL + "\"]");

        testEnrichedAlertsFunction_alert_withMissingLatLongs(env, alertCode, auxBatteryLow);
    }

    private void testEnrichedAlertsFunction_auxBatteryUnpluggedAlerts(String env, String alertCode) {
        SignalData auxBatteryUnplugged = new SignalData();
        auxBatteryUnplugged.setTime(Instant.now().toEpochMilli());
        auxBatteryUnplugged.setDataType("VARCHAR");
        auxBatteryUnplugged.setValue("[\"" + MultiAlertSignals.AUX_BATTERY_UNPLUGGED_ALERT_RISE_SIGNAL + "\"]");

        testEnrichedAlertsFunction_alert(env, alertCode, auxBatteryUnplugged);
    }

    private void testEnrichedAlertsFunction_crashAlerts(String env, String alertCode) {
        SignalData crash = new SignalData();
        crash.setTime(Instant.now().toEpochMilli());
        crash.setDataType("VARCHAR");
        crash.setValue("[\"" + MultiAlertSignals.ACCIDENT_CRASH_ALERT_RISE_SIGNAL + "\"]");

        testEnrichedAlertsFunction_alert(env, alertCode, crash);
    }

    private void testEnrichedAlertsFunction_fallDownAlerts(String env, String alertCode) {
        SignalData fallDown = new SignalData();
        fallDown.setTime(Instant.now().toEpochMilli());
        fallDown.setDataType("VARCHAR");
        fallDown.setValue("[\"" + MultiAlertSignals.FALLDOWN_ALERT_RISE_SIGNAL + "\"]");

        testEnrichedAlertsFunction_alert(env, alertCode, fallDown);
    }

    private void testEnrichedAlertsFunction_harshDrivingAlerts(String env, String alertCode) {
        SignalData harshDriving = new SignalData();
        harshDriving.setTime(Instant.now().toEpochMilli());
        harshDriving.setDataType("VARCHAR");
        harshDriving.setValue("[\"" + MultiAlertSignals.HARSH_ACCELERATION_ALERT_RISE_SIGNAL + "\"]");

        testEnrichedAlertsFunction_alert(env, alertCode, harshDriving);
    }

    private void testEnrichedAlertsFunction_ignitionOnAlerts(String env, String alertCode) {
        SignalData ignitionAlert = new SignalData();
        ignitionAlert.setTime(Instant.now().toEpochMilli());
        ignitionAlert.setDataType("VARCHAR");
        ignitionAlert.setValue("[\"" + MultiAlertSignals.IGNITION_ALERT_RISE_SIGNAL + "\"]");

        testEnrichedAlertsFunction_alert(env, alertCode, ignitionAlert);
    }

    private void testEnrichedAlertsFunction_ignitionOffAlerts(String env, String alertCode) {
        SignalData ignitionAlert = new SignalData();
        ignitionAlert.setTime(Instant.now().toEpochMilli());
        ignitionAlert.setDataType("VARCHAR");
        ignitionAlert.setValue("[\"" + MultiAlertSignals.IGNITION_ALERT_FALL_SIGNAL + "\"]");

        testEnrichedAlertsFunction_alert(env, alertCode, ignitionAlert);
    }

    private void testEnrichedAlertsFunction_motorOnAlerts(String env, String alertCode) {
        SignalData motorAlert = new SignalData();
        motorAlert.setTime(Instant.now().toEpochMilli());
        motorAlert.setDataType("VARCHAR");
        motorAlert.setValue("[\"" + MultiAlertSignals.MOTOR_ALERT_RISE_SIGNAL + "\"]");

        testEnrichedAlertsFunction_alert(env, alertCode, motorAlert);
    }

    private void testEnrichedAlertsFunction_motorOffAlerts(String env, String alertCode) {
        SignalData motorAlert = new SignalData();
        motorAlert.setTime(Instant.now().toEpochMilli());
        motorAlert.setDataType("VARCHAR");
        motorAlert.setValue("[\"" + MultiAlertSignals.MOTOR_ALERT_FALL_SIGNAL + "\"]");

        testEnrichedAlertsFunction_alert(env, alertCode, motorAlert);
    }

    private void testEnrichedAlertsFunction_overSpeedAlerts(String env, String alertCode) {
        SignalData overSpeed = new SignalData();
        overSpeed.setTime(Instant.now().toEpochMilli());
        overSpeed.setDataType("VARCHAR");
        overSpeed.setValue("[\"" + MultiAlertSignals.OVERSPEED_ALERT_RISE_SIGNAL + "\"]");

        testEnrichedAlertsFunction_alert(env, alertCode, overSpeed);
    }

    private void testEnrichedAlertsFunction_panicAlerts(String env, String alertCode) {
        SignalData panic = new SignalData();
        panic.setTime(Instant.now().toEpochMilli());
        panic.setDataType("VARCHAR");
        panic.setValue("[\"" + MultiAlertSignals.PANIC_ALERT_RISE_SIGNAL + "\"]");

        testEnrichedAlertsFunction_alert(env, alertCode, panic);
    }

    private void testEnrichedAlertsFunction_thermalAlerts(String env, String alertCode) {
        SignalData thermalRunaway = new SignalData();
        thermalRunaway.setTime(Instant.now().toEpochMilli());
        thermalRunaway.setDataType("VARCHAR");
        thermalRunaway.setValue("[\"" + MultiAlertSignals.THERMAL_RUNAWAY_ALERT_RISE_SIGNAL + "\"]");

        testEnrichedAlertsFunction_alert(env, alertCode, thermalRunaway);
    }

    private void testEnrichedAlertsFunction_batteryOverheatingAlerts(String env, String alertCode) {
        SignalData thermalRunaway = new SignalData();
        thermalRunaway.setTime(Instant.now().toEpochMilli());
        thermalRunaway.setDataType("VARCHAR");
        thermalRunaway.setValue("[\"" + MultiAlertSignals.BATTERY_OVERHEATING_ALERT_RISE_SIGNAL + "\"]");

        testEnrichedAlertsFunction_alert(env, alertCode, thermalRunaway);
    }

    private void testEnrichedAlertsFunction_theftAlerts(String env, String alertCode) {
        SignalData theft = new SignalData();
        theft.setTime(Instant.now().toEpochMilli());
        theft.setDataType("VARCHAR");
        theft.setValue("[\"" + MultiAlertSignals.TOW_THEFT_ALERT_RISE_SIGNAL + "\"]");

        testEnrichedAlertsFunction_alert(env, alertCode, theft);
    }

    private void testEnrichedAlertsFunction_movementAlerts(String env, String alertCode) {
        SignalData movement = new SignalData();
        movement.setTime(Instant.now().toEpochMilli());
        movement.setDataType("VARCHAR");
        movement.setValue("[\"" + MultiAlertSignals.MOVEMENT_ALERT_RISE_SIGNAL + "\"]");

        testEnrichedAlertsFunction_alert(env, alertCode, movement);
    }

    private void testEnrichedAlertsFunction_alert(String env, String alertCode, SignalData signalData) {
        try (KeyedTwoInputStreamOperatorTestHarness<String, Telemetry, UserPreference, EnrichedTelemetry> testHarness = testHarness(env)) {

            testHarness.setup();
            testHarness.open();

            UserPreference primaryRider = UserPreferenceGenerator.getPrimaryRider(AlertsData.VIRTUAL_ID);
            StreamRecord<UserPreference> primaryRiderRecord = new StreamRecord<>(primaryRider);
            testHarness.processElement2(primaryRiderRecord);

            Telemetry telemetry = AlertsData.getAlertEvent(primaryRider, CommonSignals.MULTI_ALERT.key(), signalData);

            SignalData latitude = new SignalData();
            latitude.setTime(Instant.now().toEpochMilli());
            latitude.setDataType("DOUBLE");
            latitude.setValue(77.0);
            telemetry.getSignals().put(CommonSignals.LATITUDE.key(), new HashSet<>(List.of(latitude)));

            SignalData longitude = new SignalData();
            longitude.setTime(Instant.now().toEpochMilli());
            longitude.setDataType("DOUBLE");
            longitude.setValue(77.0);
            telemetry.getSignals().put(CommonSignals.LONGITUDE.key(), new HashSet<>(List.of(longitude)));

            SignalData gpsFix = new SignalData();
            gpsFix.setTime(Instant.now().toEpochMilli());
            gpsFix.setDataType("DOUBLE");
            gpsFix.setValue(3.0);
            telemetry.getSignals().put(CommonSignals.GPS_FIX.key(), new HashSet<>(List.of(gpsFix)));

            SignalData gpsValid = new SignalData();
            gpsValid.setTime(Instant.now().toEpochMilli());
            gpsValid.setDataType("BOOLEAN");
            gpsValid.setValue(true);
            telemetry.getSignals().put(CommonSignals.GPS_VALID.key(), new HashSet<>(List.of(gpsValid)));
            SignalData hDop = new SignalData();
            hDop.setTime(Instant.now().toEpochMilli());
            hDop.setDataType("DOUBLE");
            hDop.setValue(3.0);
            telemetry.getSignals().put(CommonSignals.HDOP.key(),new HashSet<>(List.of(hDop)));
            StreamRecord<Telemetry> streamRecord = AlertsData.getAlertStreamRecord(telemetry);

            testHarness.processElement1(streamRecord);

            Assert.assertEquals(1, testHarness.getRecordOutput().size());
            List<EnrichedTelemetry> enrichedTelemetries = AlertsData.getEnrichedTelemetryOutputs(testHarness.getRecordOutput());
            EnrichedTelemetry enrichedTelemetry = enrichedTelemetries.get(0);
            Assert.assertNotNull(enrichedTelemetry.getNotification());

            AlertNotification alertNotification = enrichedTelemetry.getNotification();
            Assert.assertNotNull(alertNotification.getAlertCode());
            Assert.assertNotNull(alertNotification.getAlertName());
            Assert.assertNotNull(alertNotification.getAlertType());

            Assert.assertEquals(alertCode, alertNotification.getAlertCode());

        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    private void testEnrichedAlertsFunction_alert_withInvalidLatLongs(String env, String alertCode, SignalData signalData) {
        try (KeyedTwoInputStreamOperatorTestHarness<String, Telemetry, UserPreference, EnrichedTelemetry> testHarness = testHarness(env)) {

            testHarness.setup();
            testHarness.open();

            UserPreference primaryRider = UserPreferenceGenerator.getPrimaryRider(AlertsData.VIRTUAL_ID);
            StreamRecord<UserPreference> primaryRiderRecord = new StreamRecord<>(primaryRider);
            testHarness.processElement2(primaryRiderRecord);

            Telemetry telemetry = AlertsData.getAlertEvent(primaryRider, CommonSignals.MULTI_ALERT.key(), signalData);

            SignalData latitude = new SignalData();
            latitude.setTime(Instant.now().toEpochMilli());
            latitude.setDataType("DOUBLE");
            latitude.setValue(77.0);
            telemetry.getSignals().put(CommonSignals.LATITUDE.key(), new HashSet<>(List.of(latitude)));

            SignalData longitude = new SignalData();
            longitude.setTime(Instant.now().toEpochMilli());
            longitude.setDataType("DOUBLE");
            longitude.setValue(77.0);
            telemetry.getSignals().put(CommonSignals.LONGITUDE.key(), new HashSet<>(List.of(longitude)));

            SignalData gpsFix = new SignalData();
            gpsFix.setTime(Instant.now().toEpochMilli());
            gpsFix.setDataType("DOUBLE");
            gpsFix.setValue(3.0);
            telemetry.getSignals().put(CommonSignals.GPS_FIX.key(), new HashSet<>(List.of(gpsFix)));

            SignalData gpsValid = new SignalData();
            gpsValid.setTime(Instant.now().toEpochMilli());
            gpsValid.setDataType("BOOLEAN");
            gpsValid.setValue(true);
            telemetry.getSignals().put(CommonSignals.GPS_VALID.key(), new HashSet<>(List.of(gpsValid)));
            SignalData hDop = new SignalData();
            hDop.setTime(Instant.now().toEpochMilli());
            hDop.setDataType("DOUBLE");
            hDop.setValue(4.0);
            telemetry.getSignals().put(CommonSignals.HDOP.key(),new HashSet<>(List.of(hDop)));
            StreamRecord<Telemetry> streamRecord = AlertsData.getAlertStreamRecord(telemetry);

            testHarness.processElement1(streamRecord);

            //run again for idempotency test coverage
            testHarness.processElement1(streamRecord);

            Assert.assertEquals(1, testHarness.getRecordOutput().size());
            List<EnrichedTelemetry> enrichedTelemetries = AlertsData.getEnrichedTelemetryOutputs(testHarness.getRecordOutput());
            EnrichedTelemetry enrichedTelemetry = enrichedTelemetries.get(0);
            Assert.assertNotNull(enrichedTelemetry.getNotification());

            AlertNotification alertNotification = enrichedTelemetry.getNotification();
            Assert.assertNotNull(alertNotification.getAlertCode());
            Assert.assertNotNull(alertNotification.getAlertName());
            Assert.assertNotNull(alertNotification.getAlertType());

            Assert.assertEquals(alertCode, alertNotification.getAlertCode());

        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    private void testEnrichedAlertsFunction_alert_withMissingLatLongs(String env, String alertCode, SignalData signalData) {
        try (KeyedTwoInputStreamOperatorTestHarness<String, Telemetry, UserPreference, EnrichedTelemetry> testHarness = testHarness(env)) {

            testHarness.setup();
            testHarness.open();

            UserPreference primaryRider = UserPreferenceGenerator.getPrimaryRider(AlertsData.VIRTUAL_ID);
            StreamRecord<UserPreference> primaryRiderRecord = new StreamRecord<>(primaryRider);
            testHarness.processElement2(primaryRiderRecord);

            Telemetry telemetry = AlertsData.getAlertEvent(primaryRider, CommonSignals.MULTI_ALERT.key(), signalData);

            telemetry.getSignals().put(CommonSignals.GPS_VALID.key(), null);

            StreamRecord<Telemetry> streamRecord = AlertsData.getAlertStreamRecord(telemetry);

            testHarness.processElement1(streamRecord);

            Assert.assertEquals(1, testHarness.getRecordOutput().size());
            List<EnrichedTelemetry> enrichedTelemetries = AlertsData.getEnrichedTelemetryOutputs(testHarness.getRecordOutput());
            EnrichedTelemetry enrichedTelemetry = enrichedTelemetries.get(0);
            Assert.assertNotNull(enrichedTelemetry.getNotification());

            AlertNotification alertNotification = enrichedTelemetry.getNotification();
            Assert.assertNotNull(alertNotification.getAlertCode());
            Assert.assertNotNull(alertNotification.getAlertName());
            Assert.assertNotNull(alertNotification.getAlertType());

            Assert.assertEquals(alertCode, alertNotification.getAlertCode());

        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    private void testEnrichedAlertsFunction_noAlert(String env) {
        try (KeyedTwoInputStreamOperatorTestHarness<String, Telemetry, UserPreference, EnrichedTelemetry> testHarness = testHarness(env)) {

            testHarness.setup();
            testHarness.open();

            UserPreference primaryRider = UserPreferenceGenerator.getPrimaryRider(AlertsData.VIRTUAL_ID);
            StreamRecord<UserPreference> primaryRiderRecord = new StreamRecord<>(primaryRider);
            testHarness.processElement2(primaryRiderRecord);

            Telemetry telemetry = AlertsData.getAlertEvent(primaryRider, CommonSignals.ALTITUDE.key(), null);

            StreamRecord<Telemetry> streamRecord = AlertsData.getAlertStreamRecord(telemetry);

            testHarness.processElement1(streamRecord);

            Assert.assertEquals(0, testHarness.getRecordOutput().size());

        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    @Test
    public void testIsUnorderedPacket() {
        EnrichedMultiAlertsFunction function = new EnrichedMultiAlertsFunction();

        // Test case: packetTimeStamp is 0
        assertTrue(function.isUnorderedPacket(0, 1000));

        // Test case: detectionWindowStartTimestamp is 0
        assertFalse(function.isUnorderedPacket(1000, 0));

        // Test case: packetTimeStamp is less than detectionWindowStartTimestamp
        assertTrue(function.isUnorderedPacket(1000, 2000));

        // Test case: packetTimeStamp is greater than detectionWindowStartTimestamp
        assertFalse(function.isUnorderedPacket(2000, 1000));
    }

    @Test
    public void testIsGPSAndLatLongValid() {
        LatLongPair validLatLong = new LatLongPair(10.0, 20.0, true, 3.0, 1L, 3.0);
        LatLongPair invalidLatLong1 = new LatLongPair(0, 20.0, true, 3.0, 1L, 3.0);
        LatLongPair invalidLatLong2 = new LatLongPair(10.0, 0, true, 3.0, 1L, 3.0);
        LatLongPair invalidLatLong3 = new LatLongPair(10.0, 20.0, true, 4, 1L, 3.0);
        LatLongPair invalidLatLong4 = new LatLongPair(10.0, 20.0, true, 3.0, 1L, 0);

        assertTrue(EnrichedMultiAlertsFunction.isGPSAndLatLongValid(validLatLong));
        assertFalse(EnrichedMultiAlertsFunction.isGPSAndLatLongValid(invalidLatLong1));
        assertFalse(EnrichedMultiAlertsFunction.isGPSAndLatLongValid(invalidLatLong2));
        assertFalse(EnrichedMultiAlertsFunction.isGPSAndLatLongValid(invalidLatLong3));
        assertFalse(EnrichedMultiAlertsFunction.isGPSAndLatLongValid(invalidLatLong4));
    }

}
