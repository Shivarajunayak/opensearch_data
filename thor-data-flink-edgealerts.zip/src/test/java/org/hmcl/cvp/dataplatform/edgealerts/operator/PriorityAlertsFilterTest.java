package org.hmcl.cvp.dataplatform.edgealerts.operator;

import org.hmcl.cvp.dataplatform.contract.enriched.AlertNotification;
import org.hmcl.cvp.dataplatform.contract.enriched.EnrichedTelemetry;
import org.junit.Assert;
import org.junit.Test;

public class PriorityAlertsFilterTest {

    private final PriorityAlertsFilter filter = new PriorityAlertsFilter();

    @Test
    public void filter_shouldReturnTrue_whenNotificationIsNotNullAndNotifyIsTrue() throws Exception {
        AlertNotification alertNotification = new AlertNotification();
        alertNotification.setNotify(true);
        EnrichedTelemetry enrichedTelemetry = new EnrichedTelemetry();
        enrichedTelemetry.setNotification(alertNotification);

        boolean result = filter.filter(enrichedTelemetry);

        Assert.assertTrue(result);
    }

    @Test
    public void filter_shouldReturnFalse_whenNotificationIsNotNullAndNotifyIsFalse() throws Exception {
        AlertNotification alertNotification = new AlertNotification();
        alertNotification.setNotify(false);
        EnrichedTelemetry enrichedTelemetry = new EnrichedTelemetry();
        enrichedTelemetry.setNotification(alertNotification);

        boolean result = filter.filter(enrichedTelemetry);

        Assert.assertFalse(result);
    }

    @Test
    public void filter_shouldReturnFalse_whenEnrichedTelemetryIsNull() throws Exception {
        boolean result = filter.filter(null);

        Assert.assertFalse(result);
    }
}