package org.hmcl.cvp.dataplatform.edgealerts.operator;

import org.apache.flink.api.common.state.MapState;
import org.apache.flink.api.common.typeinfo.BasicTypeInfo;
import org.apache.flink.api.java.functions.KeySelector;
import org.apache.flink.api.java.utils.ParameterTool;
import org.apache.flink.runtime.testutils.MiniClusterResourceConfiguration;
import org.apache.flink.streaming.api.operators.co.CoStreamFlatMap;
import org.apache.flink.streaming.runtime.streamrecord.StreamRecord;
import org.apache.flink.streaming.util.KeyedTwoInputStreamOperatorTestHarness;
import org.apache.flink.test.util.MiniClusterWithClientResource;
import org.hmcl.cvp.dataplatform.commons.constants.FlinkRuntime;
import org.hmcl.cvp.dataplatform.commons.testdata.UserPreferenceGenerator;
import org.hmcl.cvp.dataplatform.commons.utils.FlinkUtils;
import org.hmcl.cvp.dataplatform.commons.utils.TelemetryUtils;
import org.hmcl.cvp.dataplatform.commons.utils.UserPreferenceUtils;
import org.hmcl.cvp.dataplatform.contract.enriched.EnrichedTelemetry;
import org.hmcl.cvp.dataplatform.contract.telemetry.Telemetry;
import org.hmcl.cvp.dataplatform.contract.userpreference.UserPreference;
import org.hmcl.cvp.dataplatform.edgealerts.utils.AlertsData;
import org.junit.Assert;
import org.junit.ClassRule;
import org.junit.Test;

import java.time.Instant;
import java.util.HashMap;
import java.util.Map;

public class EnrichedAlertsFunctionFlatMap2Test {

    @ClassRule
    public static MiniClusterWithClientResource flinkCluster =
            new MiniClusterWithClientResource(
                    new MiniClusterResourceConfiguration.Builder()
                            .setNumberSlotsPerTaskManager(2)
                            .setNumberTaskManagers(1)
                            .build());

    private final EnrichedMultiAlertsFunction telemetryUsePreferenceFunction = new EnrichedMultiAlertsFunction();

    private final KeySelector<Telemetry, String> telemetryKeySelector = TelemetryUtils::getVirtualId;

    private final KeySelector<UserPreference, String> userPreferenceStringKeySelector = UserPreference::getVid;

    private KeyedTwoInputStreamOperatorTestHarness<String, Telemetry, UserPreference, EnrichedTelemetry> testHarness() throws Exception {
        ParameterTool parameterTool = ParameterTool.fromMap(new HashMap<>());
        parameterTool = FlinkUtils.addProperties(parameterTool, Map.of(FlinkRuntime.USER_PREFERENCE_STATE_TTL_IN_DAYS, "1"));
        parameterTool = FlinkUtils.addProperties(parameterTool, FlinkRuntime.EdgeAlerts.ALERTS_ALLOWED_LATENESS_IN_MAX, "1");
        parameterTool = FlinkUtils.addProperties(parameterTool, FlinkRuntime.ENV, "dev");

        KeyedTwoInputStreamOperatorTestHarness<String, Telemetry, UserPreference, EnrichedTelemetry> testHarness = new KeyedTwoInputStreamOperatorTestHarness<>(new CoStreamFlatMap<>(telemetryUsePreferenceFunction),
                telemetryKeySelector,
                userPreferenceStringKeySelector,
                BasicTypeInfo.STRING_TYPE_INFO);

        testHarness.getEnvironment().getExecutionConfig().setGlobalJobParameters(parameterTool);

        return testHarness;
    }

    private MapState<String, Map<String, UserPreference>> getPreferencesStateMap(KeyedTwoInputStreamOperatorTestHarness<String, Telemetry, UserPreference, EnrichedTelemetry> testHarness) {
        return testHarness.getOperator()
                .getKeyedStateStore()
                .getMapState(MultiAlertMapStateDescriptors.multiAlertUserPreferenceMapStateDescriptor());
    }

    @Test
    public void testEnrichedAlertsFunction_incomingPrimaryNonRider() {
        try (KeyedTwoInputStreamOperatorTestHarness<String, Telemetry, UserPreference, EnrichedTelemetry> testHarness = testHarness()) {

            testHarness.setup();
            testHarness.open();

            UserPreference primaryRider = UserPreferenceGenerator.getPrimaryUser(AlertsData.VIRTUAL_ID);
            StreamRecord<UserPreference> streamRecord = new StreamRecord<>(primaryRider);

            testHarness.processElement2(streamRecord);

            MapState<String, Map<String, UserPreference>> preferencesStateMap = getPreferencesStateMap(testHarness);

            Map<String, UserPreference> preferences = preferencesStateMap.get(AlertsData.VIRTUAL_ID);

            Assert.assertNull(preferences);

        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    @Test
    public void testEnrichedAlertsFunction_incomingPrimaryRider() {
        try (KeyedTwoInputStreamOperatorTestHarness<String, Telemetry, UserPreference, EnrichedTelemetry> testHarness = testHarness()) {

            testHarness.setup();
            testHarness.open();

            UserPreference primaryRider = UserPreferenceGenerator.getPrimaryRider(AlertsData.VIRTUAL_ID);
            StreamRecord<UserPreference> streamRecord = new StreamRecord<>(primaryRider);

            testHarness.processElement2(streamRecord);

            MapState<String, Map<String, UserPreference>> preferencesStateMap = getPreferencesStateMap(testHarness);

            Map<String, UserPreference> preferences = preferencesStateMap.get(AlertsData.VIRTUAL_ID);

            Assert.assertNotNull(preferences);
            Assert.assertEquals(1, preferences.size());
            Assert.assertNotNull(preferences.get(primaryRider.getProfileId()));


        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    @Test
    public void testEnrichedAlertsFunction_incomingSecondaryRider() {
        try (KeyedTwoInputStreamOperatorTestHarness<String, Telemetry, UserPreference, EnrichedTelemetry> testHarness = testHarness()) {

            testHarness.setup();
            testHarness.open();

            UserPreference secondaryRider = UserPreferenceGenerator.getSecondaryRider(AlertsData.VIRTUAL_ID);
            StreamRecord<UserPreference> streamRecord = new StreamRecord<>(secondaryRider);

            testHarness.processElement2(streamRecord);

            MapState<String, Map<String, UserPreference>> preferencesStateMap = getPreferencesStateMap(testHarness);

            Map<String, UserPreference> preferences = preferencesStateMap.get(AlertsData.VIRTUAL_ID);

            Assert.assertNotNull(preferences);
            Assert.assertEquals(1, preferences.size());
            Assert.assertNotNull(preferences.get(secondaryRider.getProfileId()));


        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    @Test
    public void testEnrichedAlertsFunction_incomingSecondaryNonRider() {
        try (KeyedTwoInputStreamOperatorTestHarness<String, Telemetry, UserPreference, EnrichedTelemetry> testHarness = testHarness()) {

            testHarness.setup();
            testHarness.open();

            UserPreference secondaryNonRider = UserPreferenceGenerator.getSecondaryUser(AlertsData.VIRTUAL_ID);
            StreamRecord<UserPreference> secondaryRecord = new StreamRecord<>(secondaryNonRider);

            testHarness.processElement2(secondaryRecord);

            MapState<String, Map<String, UserPreference>> preferencesStateMap = getPreferencesStateMap(testHarness);

            Map<String, UserPreference> preferences = preferencesStateMap.get(AlertsData.VIRTUAL_ID);

            Assert.assertNull(preferences);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    @Test
    public void testEnrichedAlertsFunction_firstPrimaryRiderThenSecondaryRider() {
        try (KeyedTwoInputStreamOperatorTestHarness<String, Telemetry, UserPreference, EnrichedTelemetry> testHarness = testHarness()) {

            testHarness.setup();
            testHarness.open();

            UserPreference primaryRider = UserPreferenceGenerator.getPrimaryRider(AlertsData.VIRTUAL_ID);
            UserPreference primaryUser = UserPreferenceUtils.deepCopy(primaryRider);
            assert primaryUser != null;
            primaryUser.setIsRider(false);

            UserPreference secondaryRider = UserPreferenceGenerator.getSecondaryRider(AlertsData.VIRTUAL_ID);

            StreamRecord<UserPreference> primaryRiderRecord = new StreamRecord<>(primaryRider);
            StreamRecord<UserPreference> primaryUserRecord = new StreamRecord<>(primaryUser);
            StreamRecord<UserPreference> secondaryRiderRecord = new StreamRecord<>(secondaryRider);

            testHarness.processElement2(primaryRiderRecord);
            MapState<String, Map<String, UserPreference>> preferencesStateMap1 = getPreferencesStateMap(testHarness);
            Map<String, UserPreference> preferences1 = preferencesStateMap1.get(AlertsData.VIRTUAL_ID);

            Assert.assertNotNull(preferences1);
            Assert.assertEquals(1, preferences1.size());
            Assert.assertNotNull(preferences1.get(primaryRider.getProfileId()));

            testHarness.processElement2(primaryUserRecord);
            MapState<String, Map<String, UserPreference>> preferencesStateMap2 = getPreferencesStateMap(testHarness);
            Map<String, UserPreference> preferences2 = preferencesStateMap2.get(AlertsData.VIRTUAL_ID);

            Assert.assertEquals(0, preferences2.size());

            testHarness.processElement2(secondaryRiderRecord);
            MapState<String, Map<String, UserPreference>> preferencesStateMap3 = getPreferencesStateMap(testHarness);
            Map<String, UserPreference> preferences3 = preferencesStateMap3.get(AlertsData.VIRTUAL_ID);

            Assert.assertNotNull(preferences3);
            Assert.assertEquals(1, preferences3.size());
            Assert.assertNotNull(preferences3.get(secondaryRider.getProfileId()));

        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    @Test
    public void testEnrichedAlertsFunction_firstPrimaryRiderThenSecondaryRider_withoutPrimaryRiderFalse() {
        try (KeyedTwoInputStreamOperatorTestHarness<String, Telemetry, UserPreference, EnrichedTelemetry> testHarness = testHarness()) {

            testHarness.setup();
            testHarness.open();

            UserPreference primaryRider = UserPreferenceGenerator.getPrimaryRider(AlertsData.VIRTUAL_ID);
            primaryRider.setUpdatedTsp(Instant.now().minusSeconds(60).toEpochMilli());

            UserPreference secondaryRider = UserPreferenceGenerator.getSecondaryRider(AlertsData.VIRTUAL_ID);
            secondaryRider.setUpdatedTsp(Instant.now().toEpochMilli());

            StreamRecord<UserPreference> primaryRiderRecord = new StreamRecord<>(primaryRider);
            StreamRecord<UserPreference> secondaryRiderRecord = new StreamRecord<>(secondaryRider);

            testHarness.processElement2(primaryRiderRecord);
            MapState<String, Map<String, UserPreference>> preferencesStateMap1 = getPreferencesStateMap(testHarness);
            Map<String, UserPreference> preferences1 = preferencesStateMap1.get(AlertsData.VIRTUAL_ID);

            Assert.assertNotNull(preferences1);
            Assert.assertEquals(1, preferences1.size());
            Assert.assertNotNull(preferences1.get(primaryRider.getProfileId()));

            testHarness.processElement2(secondaryRiderRecord);
            MapState<String, Map<String, UserPreference>> preferencesStateMap2 = getPreferencesStateMap(testHarness);
            Map<String, UserPreference> preferences2 = preferencesStateMap2.get(AlertsData.VIRTUAL_ID);

            Assert.assertNotNull(preferences2);
            Assert.assertEquals(1, preferences2.size());
            Assert.assertNotNull(preferences2.get(secondaryRider.getProfileId()));

        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    @Test
    public void testEnrichedAlertsFunction_incomingSecondaryIsRiderFlagChange() {
        try (KeyedTwoInputStreamOperatorTestHarness<String, Telemetry, UserPreference, EnrichedTelemetry> testHarness = testHarness()) {

            testHarness.setup();
            testHarness.open();

            UserPreference primaryUser = UserPreferenceGenerator.getPrimaryUser(AlertsData.VIRTUAL_ID);
            UserPreference secondaryRider = UserPreferenceGenerator.getSecondaryRider(AlertsData.VIRTUAL_ID);

            StreamRecord<UserPreference> primaryRecord = new StreamRecord<>(primaryUser);
            StreamRecord<UserPreference> secondaryRecord = new StreamRecord<>(secondaryRider);

            testHarness.processElement2(primaryRecord);
            testHarness.processElement2(secondaryRecord);

            MapState<String, Map<String, UserPreference>> preferencesStateMap = getPreferencesStateMap(testHarness);

            Map<String, UserPreference> preferences = preferencesStateMap.get(AlertsData.VIRTUAL_ID);

            Assert.assertNotNull(preferences);
            Assert.assertEquals(1, preferences.size());
            Assert.assertNotNull(preferences.get(secondaryRider.getProfileId()));

            UserPreference secondaryNonRider = UserPreferenceUtils.deepCopy(secondaryRider);
            assert secondaryNonRider != null;
            secondaryNonRider.setIsRider(false);

            StreamRecord<UserPreference> secondaryRecord1 = new StreamRecord<>(secondaryNonRider);
            testHarness.processElement2(secondaryRecord1);

            MapState<String, Map<String, UserPreference>> preferencesStateMap1 = getPreferencesStateMap(testHarness);

            Map<String, UserPreference> preferences1 = preferencesStateMap1.get(AlertsData.VIRTUAL_ID);
            Assert.assertEquals(0, preferences1.size());

        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }
}
