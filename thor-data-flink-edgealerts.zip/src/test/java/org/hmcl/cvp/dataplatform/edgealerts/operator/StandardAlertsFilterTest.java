package org.hmcl.cvp.dataplatform.edgealerts.operator;

import org.hmcl.cvp.dataplatform.contract.enriched.AlertNotification;
import org.hmcl.cvp.dataplatform.contract.enriched.EnrichedTelemetry;
import org.junit.Assert;
import org.junit.Test;

public class StandardAlertsFilterTest {

    private final StandardAlertsFilter filter = new StandardAlertsFilter();

    @Test
    public void filter_shouldReturnFalse_whenEnrichedTelemetryIsNull() throws Exception {
        boolean result = filter.filter(null);

        Assert.assertFalse(result);
    }

    @Test
    public void filter_shouldReturnFalse_whenNotificationIsNotNullAndNotifyIsTrue() throws Exception {
        AlertNotification alertNotification = new AlertNotification();
        alertNotification.setNotify(true);
        EnrichedTelemetry enrichedTelemetry = new EnrichedTelemetry();
        enrichedTelemetry.setNotification(alertNotification);

        boolean result = filter.filter(enrichedTelemetry);

        Assert.assertFalse(result);
    }

    @Test
    public void filter_shouldReturnTrue_whenNotificationIsNotNullAndNotifyIsFalse() throws Exception {
        AlertNotification alertNotification = new AlertNotification();
        alertNotification.setNotify(false);
        EnrichedTelemetry enrichedTelemetry = new EnrichedTelemetry();
        enrichedTelemetry.setNotification(alertNotification);

        boolean result = filter.filter(enrichedTelemetry);

        Assert.assertTrue(result);
    }
}